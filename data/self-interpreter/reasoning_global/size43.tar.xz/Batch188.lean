import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2388005599770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388005599770 : Closed e2388005599770 ∧ code e2388005599770 = 11184098621978 := by decide
theorem cert_e2388005599770 : check e2388005599770 [[],[.left]] .chain = true := by decide
def e2388005612058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388005612058 : Closed e2388005612058 ∧ code e2388005612058 = 11184098634266 := by decide
theorem cert_e2388005612058 : check e2388005612058 [[],[.left]] .chain = true := by decide
def e2388005804570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388005804570 : Closed e2388005804570 ∧ code e2388005804570 = 11184098826778 := by decide
theorem cert_e2388005804570 : check e2388005804570 [[],[.left]] .chain = true := by decide
def e2388005808666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388005808666 : Closed e2388005808666 ∧ code e2388005808666 = 11184098830874 := by decide
theorem cert_e2388005808666 : check e2388005808666 [[],[.left]] .chain = true := by decide
def e2388013803546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388013803546 : Closed e2388013803546 ∧ code e2388013803546 = 11184106825754 := by decide
theorem cert_e2388013803546 : check e2388013803546 [[],[.left]] .smaller = true := by decide
def e2388013808154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388013808154 : Closed e2388013808154 ∧ code e2388013808154 = 11184106830362 := by decide
theorem cert_e2388013808154 : check e2388013808154 [[]] .width = true := by decide
def e2388013836314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388013836314 : Closed e2388013836314 ∧ code e2388013836314 = 11184106858522 := by decide
theorem cert_e2388013836314 : check e2388013836314 [[],[.left]] .smaller = true := by decide
def e2388013840922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388013840922 : Closed e2388013840922 ∧ code e2388013840922 = 11184106863130 := by decide
theorem cert_e2388013840922 : check e2388013840922 [[],[.left]] .chain = true := by decide
def e2388013857306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388013857306 : Closed e2388013857306 ∧ code e2388013857306 = 11184106879514 := by decide
theorem cert_e2388013857306 : check e2388013857306 [[],[.left]] .chain = true := by decide
def e2388013865498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388013865498 : Closed e2388013865498 ∧ code e2388013865498 = 11184106887706 := by decide
theorem cert_e2388013865498 : check e2388013865498 [[]] .width = true := by decide
def e2388014065690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388014065690 : Closed e2388014065690 ∧ code e2388014065690 = 11184107087898 := by decide
theorem cert_e2388014065690 : check e2388014065690 [[],[.left]] .smaller = true := by decide
def e2388014070298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388014070298 : Closed e2388014070298 ∧ code e2388014070298 = 11184107092506 := by decide
theorem cert_e2388014070298 : check e2388014070298 [[]] .width = true := by decide
def e2388014114842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388014114842 : Closed e2388014114842 ∧ code e2388014114842 = 11184107137050 := by decide
theorem cert_e2388014114842 : check e2388014114842 [[],[.left]] .smaller = true := by decide
def e2388014131738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388014131738 : Closed e2388014131738 ∧ code e2388014131738 = 11184107153946 := by decide
theorem cert_e2388014131738 : check e2388014131738 [[]] .width = true := by decide
def e2388014229530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388014229530 : Closed e2388014229530 ∧ code e2388014229530 = 11184107251738 := by decide
theorem cert_e2388014229530 : check e2388014229530 [[],[.left]] .smaller = true := by decide
def e2388014234138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388014234138 : Closed e2388014234138 ∧ code e2388014234138 = 11184107256346 := by decide
theorem cert_e2388014234138 : check e2388014234138 [[],[.left]] .chain = true := by decide
def e2388014245914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388014245914 : Closed e2388014245914 ∧ code e2388014245914 = 11184107268122 := by decide
theorem cert_e2388014245914 : check e2388014245914 [[],[.left]] .smaller = true := by decide
def e2388014262810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388014262810 : Closed e2388014262810 ∧ code e2388014262810 = 11184107285018 := by decide
theorem cert_e2388014262810 : check e2388014262810 [[],[.left]] .chain = true := by decide
def e2388014316058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388014316058 : Closed e2388014316058 ∧ code e2388014316058 = 11184107338266 := by decide
theorem cert_e2388014316058 : check e2388014316058 [[],[.left]] .chain = true := by decide
def e2388014328346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388014328346 : Closed e2388014328346 ∧ code e2388014328346 = 11184107350554 := by decide
theorem cert_e2388014328346 : check e2388014328346 [[],[.left]] .chain = true := by decide
def e2388014357018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388014357018 : Closed e2388014357018 ∧ code e2388014357018 = 11184107379226 := by decide
theorem cert_e2388014357018 : check e2388014357018 [[]] .width = true := by decide
def e2388014361114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388014361114 : Closed e2388014361114 ∧ code e2388014361114 = 11184107383322 := by decide
theorem cert_e2388014361114 : check e2388014361114 [[]] .width = true := by decide
def e2388015376410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388015376410 : Closed e2388015376410 ∧ code e2388015376410 = 11184108398618 := by decide
theorem cert_e2388015376410 : check e2388015376410 [[],[.left]] .smaller = true := by decide
def e2388015381018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388015381018 : Closed e2388015381018 ∧ code e2388015381018 = 11184108403226 := by decide
theorem cert_e2388015381018 : check e2388015381018 [[]] .width = true := by decide
def e2388015409178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388015409178 : Closed e2388015409178 ∧ code e2388015409178 = 11184108431386 := by decide
theorem cert_e2388015409178 : check e2388015409178 [[],[.left]] .smaller = true := by decide
def e2388015413786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388015413786 : Closed e2388015413786 ∧ code e2388015413786 = 11184108435994 := by decide
theorem cert_e2388015413786 : check e2388015413786 [[],[.left]] .chain = true := by decide
def e2388015430170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388015430170 : Closed e2388015430170 ∧ code e2388015430170 = 11184108452378 := by decide
theorem cert_e2388015430170 : check e2388015430170 [[],[.left]] .chain = true := by decide
def e2388015438362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388015438362 : Closed e2388015438362 ∧ code e2388015438362 = 11184108460570 := by decide
theorem cert_e2388015438362 : check e2388015438362 [[]] .width = true := by decide
def e2388016949274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388016949274 : Closed e2388016949274 ∧ code e2388016949274 = 11184109971482 := by decide
theorem cert_e2388016949274 : check e2388016949274 [[],[.left]] .smaller = true := by decide
def e2388016953882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388016953882 : Closed e2388016953882 ∧ code e2388016953882 = 11184109976090 := by decide
theorem cert_e2388016953882 : check e2388016953882 [[]] .width = true := by decide
def e2388016998426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388016998426 : Closed e2388016998426 ∧ code e2388016998426 = 11184110020634 := by decide
theorem cert_e2388016998426 : check e2388016998426 [[],[.left]] .smaller = true := by decide
def e2388017015322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388017015322 : Closed e2388017015322 ∧ code e2388017015322 = 11184110037530 := by decide
theorem cert_e2388017015322 : check e2388017015322 [[]] .width = true := by decide
def e2388017768474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388017768474 : Closed e2388017768474 ∧ code e2388017768474 = 11184110790682 := by decide
theorem cert_e2388017768474 : check e2388017768474 [[],[.left]] .smaller = true := by decide
def e2388017773082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388017773082 : Closed e2388017773082 ∧ code e2388017773082 = 11184110795290 := by decide
theorem cert_e2388017773082 : check e2388017773082 [[],[.left]] .chain = true := by decide
def e2388017784858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388017784858 : Closed e2388017784858 ∧ code e2388017784858 = 11184110807066 := by decide
theorem cert_e2388017784858 : check e2388017784858 [[],[.left]] .smaller = true := by decide
def e2388017801754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388017801754 : Closed e2388017801754 ∧ code e2388017801754 = 11184110823962 := by decide
theorem cert_e2388017801754 : check e2388017801754 [[],[.left]] .chain = true := by decide
def e2388018182682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388018182682 : Closed e2388018182682 ∧ code e2388018182682 = 11184111204890 := by decide
theorem cert_e2388018182682 : check e2388018182682 [[],[.left]] .chain = true := by decide
def e2388018194970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388018194970 : Closed e2388018194970 ∧ code e2388018194970 = 11184111217178 := by decide
theorem cert_e2388018194970 : check e2388018194970 [[],[.left]] .chain = true := by decide
def e2388018387482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388018387482 : Closed e2388018387482 ∧ code e2388018387482 = 11184111409690 := by decide
theorem cert_e2388018387482 : check e2388018387482 [[]] .width = true := by decide
def e2388018391578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388018391578 : Closed e2388018391578 ∧ code e2388018391578 = 11184111413786 := by decide
theorem cert_e2388018391578 : check e2388018391578 [[]] .width = true := by decide
def e2388047280666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047280666 : Closed e2388047280666 ∧ code e2388047280666 = 11184140302874 := by decide
theorem cert_e2388047280666 : check e2388047280666 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388047288858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047288858 : Closed e2388047288858 ∧ code e2388047288858 = 11184140311066 := by decide
theorem cert_e2388047288858 : check e2388047288858 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388047346202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047346202 : Closed e2388047346202 ∧ code e2388047346202 = 11184140368410 := by decide
theorem cert_e2388047346202 : check e2388047346202 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388047358490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047358490 : Closed e2388047358490 ∧ code e2388047358490 = 11184140380698 := by decide
theorem cert_e2388047358490 : check e2388047358490 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388047387162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047387162 : Closed e2388047387162 ∧ code e2388047387162 = 11184140409370 := by decide
theorem cert_e2388047387162 : check e2388047387162 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388047391258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047391258 : Closed e2388047391258 ∧ code e2388047391258 = 11184140413466 := by decide
theorem cert_e2388047391258 : check e2388047391258 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388047608346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047608346 : Closed e2388047608346 ∧ code e2388047608346 = 11184140630554 := by decide
theorem cert_e2388047608346 : check e2388047608346 [[],[.left],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388047620634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047620634 : Closed e2388047620634 ∧ code e2388047620634 = 11184140642842 := by decide
theorem cert_e2388047620634 : check e2388047620634 [[],[.left],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388047669786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047669786 : Closed e2388047669786 ∧ code e2388047669786 = 11184140691994 := by decide
theorem cert_e2388047669786 : check e2388047669786 [[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2388047780378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047780378 : Closed e2388047780378 ∧ code e2388047780378 = 11184140802586 := by decide
theorem cert_e2388047780378 : check e2388047780378 [[],[.left],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388047784474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047784474 : Closed e2388047784474 ∧ code e2388047784474 = 11184140806682 := by decide
theorem cert_e2388047784474 : check e2388047784474 [[],[.left],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388047800858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388047800858 : Closed e2388047800858 ∧ code e2388047800858 = 11184140823066 := by decide
theorem cert_e2388047800858 : check e2388047800858 [[],[.left],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388048443930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388048443930 : Closed e2388048443930 ∧ code e2388048443930 = 11184141466138 := by decide
theorem cert_e2388048443930 : check e2388048443930 [[]] .width = true := by decide
def e2388048468506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388048468506 : Closed e2388048468506 ∧ code e2388048468506 = 11184141490714 := by decide
theorem cert_e2388048468506 : check e2388048468506 [[]] .width = true := by decide
def e2388048853530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388048853530 : Closed e2388048853530 ∧ code e2388048853530 = 11184141875738 := by decide
theorem cert_e2388048853530 : check e2388048853530 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388048861722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388048861722 : Closed e2388048861722 ∧ code e2388048861722 = 11184141883930 := by decide
theorem cert_e2388048861722 : check e2388048861722 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388048919066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388048919066 : Closed e2388048919066 ∧ code e2388048919066 = 11184141941274 := by decide
theorem cert_e2388048919066 : check e2388048919066 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388048931354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388048931354 : Closed e2388048931354 ∧ code e2388048931354 = 11184141953562 := by decide
theorem cert_e2388048931354 : check e2388048931354 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388048960026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388048960026 : Closed e2388048960026 ∧ code e2388048960026 = 11184141982234 := by decide
theorem cert_e2388048960026 : check e2388048960026 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388048964122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388048964122 : Closed e2388048964122 ∧ code e2388048964122 = 11184141986330 := by decide
theorem cert_e2388048964122 : check e2388048964122 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388049246746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049246746 : Closed e2388049246746 ∧ code e2388049246746 = 11184142268954 := by decide
theorem cert_e2388049246746 : check e2388049246746 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388049254938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049254938 : Closed e2388049254938 ∧ code e2388049254938 = 11184142277146 := by decide
theorem cert_e2388049254938 : check e2388049254938 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388049590810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049590810 : Closed e2388049590810 ∧ code e2388049590810 = 11184142613018 := by decide
theorem cert_e2388049590810 : check e2388049590810 [[]] .width = true := by decide
def e2388049639962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049639962 : Closed e2388049639962 ∧ code e2388049639962 = 11184142662170 := by decide
theorem cert_e2388049639962 : check e2388049639962 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388049652250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049652250 : Closed e2388049652250 ∧ code e2388049652250 = 11184142674458 := by decide
theorem cert_e2388049652250 : check e2388049652250 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388049762842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049762842 : Closed e2388049762842 ∧ code e2388049762842 = 11184142785050 := by decide
theorem cert_e2388049762842 : check e2388049762842 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388049764378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388049764378 : Closed e2388049764378 ∧ code e2388049764378 = 11184142786586 := by decide
theorem cert_e2388049764378 : check e2388049764378 [[],[.left]] .smaller = true := by decide
def e2388049764470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388049764470 : Closed e2388049764470 ∧ code e2388049764470 = 11184142786678 := by decide
theorem cert_e2388049764470 : check e2388049764470 [[],[.left]] .chain = true := by decide
def e2388049764714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388049764714 : Closed e2388049764714 ∧ code e2388049764714 = 11184142786922 := by decide
theorem cert_e2388049764714 : check e2388049764714 [[],[.left]] .chain = true := by decide
def e2388049764762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388049764762 : Closed e2388049764762 ∧ code e2388049764762 = 11184142786970 := by decide
theorem cert_e2388049764762 : check e2388049764762 [[],[.left]] .chain = true := by decide
def e2388049774106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049774106 : Closed e2388049774106 ∧ code e2388049774106 = 11184142796314 := by decide
theorem cert_e2388049774106 : check e2388049774106 [[]] .width = true := by decide
def e2388049776838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388049776838 : Closed e2388049776838 ∧ code e2388049776838 = 11184142799046 := by decide
theorem cert_e2388049776838 : check e2388049776838 [[]] .width = true := by decide
def e2388049844762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049844762 : Closed e2388049844762 ∧ code e2388049844762 = 11184142866970 := by decide
theorem cert_e2388049844762 : check e2388049844762 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388049848858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049848858 : Closed e2388049848858 ∧ code e2388049848858 = 11184142871066 := by decide
theorem cert_e2388049848858 : check e2388049848858 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388049893914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049893914 : Closed e2388049893914 ∧ code e2388049893914 = 11184142916122 := by decide
theorem cert_e2388049893914 : check e2388049893914 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388049895450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388049895450 : Closed e2388049895450 ∧ code e2388049895450 = 11184142917658 := by decide
theorem cert_e2388049895450 : check e2388049895450 [[],[.left]] .smaller = true := by decide
def e2388049895542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388049895542 : Closed e2388049895542 ∧ code e2388049895542 = 11184142917750 := by decide
theorem cert_e2388049895542 : check e2388049895542 [[],[.left]] .chain = true := by decide
def e2388049895786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388049895786 : Closed e2388049895786 ∧ code e2388049895786 = 11184142917994 := by decide
theorem cert_e2388049895786 : check e2388049895786 [[],[.left]] .chain = true := by decide
def e2388049895834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388049895834 : Closed e2388049895834 ∧ code e2388049895834 = 11184142918042 := by decide
theorem cert_e2388049895834 : check e2388049895834 [[],[.left]] .chain = true := by decide
def e2388049913882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388049913882 : Closed e2388049913882 ∧ code e2388049913882 = 11184142936090 := by decide
theorem cert_e2388049913882 : check e2388049913882 [[]] .width = true := by decide
def e2388049934874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049934874 : Closed e2388049934874 ∧ code e2388049934874 = 11184142957082 := by decide
theorem cert_e2388049934874 : check e2388049934874 [[]] .width = true := by decide
def e2388049970714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388049970714 : Closed e2388049970714 ∧ code e2388049970714 = 11184142992922 := by decide
theorem cert_e2388049970714 : check e2388049970714 [[]] .width = true := by decide
def e2388049973446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388049973446 : Closed e2388049973446 ∧ code e2388049973446 = 11184142995654 := by decide
theorem cert_e2388049973446 : check e2388049973446 [[]] .width = true := by decide
def e2388049979418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388049979418 : Closed e2388049979418 ∧ code e2388049979418 = 11184143001626 := by decide
theorem cert_e2388049979418 : check e2388049979418 [[]] .width = true := by decide
def e2388050278938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050278938 : Closed e2388050278938 ∧ code e2388050278938 = 11184143301146 := by decide
theorem cert_e2388050278938 : check e2388050278938 [[]] .width = true := by decide
def e2388050307610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050307610 : Closed e2388050307610 ∧ code e2388050307610 = 11184143329818 := by decide
theorem cert_e2388050307610 : check e2388050307610 [[]] .width = true := by decide
def e2388050491930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050491930 : Closed e2388050491930 ∧ code e2388050491930 = 11184143514138 := by decide
theorem cert_e2388050491930 : check e2388050491930 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388050504218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050504218 : Closed e2388050504218 ∧ code e2388050504218 = 11184143526426 := by decide
theorem cert_e2388050504218 : check e2388050504218 [[],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2388050553370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050553370 : Closed e2388050553370 ∧ code e2388050553370 = 11184143575578 := by decide
theorem cert_e2388050553370 : check e2388050553370 [[],[.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2388050639386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050639386 : Closed e2388050639386 ∧ code e2388050639386 = 11184143661594 := by decide
theorem cert_e2388050639386 : check e2388050639386 [[]] .width = true := by decide
def e2388050688538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050688538 : Closed e2388050688538 ∧ code e2388050688538 = 11184143710746 := by decide
theorem cert_e2388050688538 : check e2388050688538 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388050700826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050700826 : Closed e2388050700826 ∧ code e2388050700826 = 11184143723034 := by decide
theorem cert_e2388050700826 : check e2388050700826 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388050811418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050811418 : Closed e2388050811418 ∧ code e2388050811418 = 11184143833626 := by decide
private def t_e2388050811418 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e2388050811418 : ¬ IsSelfInterpreter e2388050811418 :=
  wSource (t := t_e2388050811418) (replay_sound (ps := [[],[.left],[.left],[]]) (t := e2388050811418) (by decide)) (by decide)
def e2388050812954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388050812954 : Closed e2388050812954 ∧ code e2388050812954 = 11184143835162 := by decide
theorem cert_e2388050812954 : check e2388050812954 [[],[.left]] .smaller = true := by decide
def e2388050813046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388050813046 : Closed e2388050813046 ∧ code e2388050813046 = 11184143835254 := by decide
theorem cert_e2388050813046 : check e2388050813046 [[],[.left]] .chain = true := by decide
def e2388050813290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388050813290 : Closed e2388050813290 ∧ code e2388050813290 = 11184143835498 := by decide
theorem cert_e2388050813290 : check e2388050813290 [[],[.left]] .chain = true := by decide
def e2388050813338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388050813338 : Closed e2388050813338 ∧ code e2388050813338 = 11184143835546 := by decide
theorem cert_e2388050813338 : check e2388050813338 [[],[.left]] .chain = true := by decide
def e2388050822682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050822682 : Closed e2388050822682 ∧ code e2388050822682 = 11184143844890 := by decide
theorem cert_e2388050822682 : check e2388050822682 [[]] .width = true := by decide
def e2388050825414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388050825414 : Closed e2388050825414 ∧ code e2388050825414 = 11184143847622 := by decide
theorem cert_e2388050825414 : check e2388050825414 [[]] .width = true := by decide
def e2388050995738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388050995738 : Closed e2388050995738 ∧ code e2388050995738 = 11184144017946 := by decide
theorem cert_e2388050995738 : check e2388050995738 [[],[.left],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2388051008026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051008026 : Closed e2388051008026 ∧ code e2388051008026 = 11184144030234 := by decide
private def t_e2388051008026 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0)))
theorem cert_e2388051008026 : ¬ IsSelfInterpreter e2388051008026 :=
  wSource (t := t_e2388051008026) (replay_sound (ps := [[],[.left],[.left],[]]) (t := e2388051008026) (by decide)) (by decide)
def e2388051009562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388051009562 : Closed e2388051009562 ∧ code e2388051009562 = 11184144031770 := by decide
theorem cert_e2388051009562 : check e2388051009562 [[],[.left]] .smaller = true := by decide
def e2388051009654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388051009654 : Closed e2388051009654 ∧ code e2388051009654 = 11184144031862 := by decide
theorem cert_e2388051009654 : check e2388051009654 [[],[.left]] .chain = true := by decide
def e2388051009898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388051009898 : Closed e2388051009898 ∧ code e2388051009898 = 11184144032106 := by decide
theorem cert_e2388051009898 : check e2388051009898 [[],[.left]] .chain = true := by decide
def e2388051009946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388051009946 : Closed e2388051009946 ∧ code e2388051009946 = 11184144032154 := by decide
theorem cert_e2388051009946 : check e2388051009946 [[],[.left]] .chain = true := by decide
def e2388051040794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051040794 : Closed e2388051040794 ∧ code e2388051040794 = 11184144063002 := by decide
theorem cert_e2388051040794 : check e2388051040794 [[]] .width = true := by decide
def e2388051052058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051052058 : Closed e2388051052058 ∧ code e2388051052058 = 11184144074266 := by decide
theorem cert_e2388051052058 : check e2388051052058 [[]] .width = true := by decide
def e2388051054790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388051054790 : Closed e2388051054790 ∧ code e2388051054790 = 11184144076998 := by decide
theorem cert_e2388051054790 : check e2388051054790 [[]] .width = true := by decide
def e2388051319322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051319322 : Closed e2388051319322 ∧ code e2388051319322 = 11184144341530 := by decide
theorem cert_e2388051319322 : check e2388051319322 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388051323418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051323418 : Closed e2388051323418 ∧ code e2388051323418 = 11184144345626 := by decide
theorem cert_e2388051323418 : check e2388051323418 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388051339802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051339802 : Closed e2388051339802 ∧ code e2388051339802 = 11184144362010 := by decide
theorem cert_e2388051339802 : check e2388051339802 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388051417626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051417626 : Closed e2388051417626 ∧ code e2388051417626 = 11184144439834 := by decide
theorem cert_e2388051417626 : check e2388051417626 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388051421722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051421722 : Closed e2388051421722 ∧ code e2388051421722 = 11184144443930 := by decide
theorem cert_e2388051421722 : check e2388051421722 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388051466778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051466778 : Closed e2388051466778 ∧ code e2388051466778 = 11184144488986 := by decide
theorem cert_e2388051466778 : check e2388051466778 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388051468314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388051468314 : Closed e2388051468314 ∧ code e2388051468314 = 11184144490522 := by decide
theorem cert_e2388051468314 : check e2388051468314 [[],[.left]] .smaller = true := by decide
def e2388051468406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388051468406 : Closed e2388051468406 ∧ code e2388051468406 = 11184144490614 := by decide
theorem cert_e2388051468406 : check e2388051468406 [[],[.left]] .chain = true := by decide
def e2388051468650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388051468650 : Closed e2388051468650 ∧ code e2388051468650 = 11184144490858 := by decide
theorem cert_e2388051468650 : check e2388051468650 [[],[.left]] .chain = true := by decide
def e2388051468698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388051468698 : Closed e2388051468698 ∧ code e2388051468698 = 11184144490906 := by decide
theorem cert_e2388051468698 : check e2388051468698 [[],[.left]] .chain = true := by decide
def e2388051486746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388051486746 : Closed e2388051486746 ∧ code e2388051486746 = 11184144508954 := by decide
theorem cert_e2388051486746 : check e2388051486746 [[]] .width = true := by decide
def e2388051520026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051520026 : Closed e2388051520026 ∧ code e2388051520026 = 11184144542234 := by decide
theorem cert_e2388051520026 : check e2388051520026 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388051532314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051532314 : Closed e2388051532314 ∧ code e2388051532314 = 11184144554522 := by decide
theorem cert_e2388051532314 : check e2388051532314 [[],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388051533850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388051533850 : Closed e2388051533850 ∧ code e2388051533850 = 11184144556058 := by decide
theorem cert_e2388051533850 : check e2388051533850 [[],[.left]] .smaller = true := by decide
def e2388051533942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388051533942 : Closed e2388051533942 ∧ code e2388051533942 = 11184144556150 := by decide
theorem cert_e2388051533942 : check e2388051533942 [[],[.left]] .chain = true := by decide
def e2388051534186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388051534186 : Closed e2388051534186 ∧ code e2388051534186 = 11184144556394 := by decide
theorem cert_e2388051534186 : check e2388051534186 [[],[.left]] .chain = true := by decide
def e2388051534234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388051534234 : Closed e2388051534234 ∧ code e2388051534234 = 11184144556442 := by decide
theorem cert_e2388051534234 : check e2388051534234 [[],[.left]] .chain = true := by decide
def e2388051601434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388051601434 : Closed e2388051601434 ∧ code e2388051601434 = 11184144623642 := by decide
theorem cert_e2388051601434 : check e2388051601434 [[]] .width = true := by decide
def e2388051679770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051679770 : Closed e2388051679770 ∧ code e2388051679770 = 11184144701978 := by decide
theorem cert_e2388051679770 : check e2388051679770 [[]] .width = true := by decide
def e2388051683866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051683866 : Closed e2388051683866 ∧ code e2388051683866 = 11184144706074 := by decide
theorem cert_e2388051683866 : check e2388051683866 [[]] .width = true := by decide
def e2388051769882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051769882 : Closed e2388051769882 ∧ code e2388051769882 = 11184144792090 := by decide
theorem cert_e2388051769882 : check e2388051769882 [[]] .width = true := by decide
def e2388051805722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051805722 : Closed e2388051805722 ∧ code e2388051805722 = 11184144827930 := by decide
theorem cert_e2388051805722 : check e2388051805722 [[]] .width = true := by decide
def e2388051808454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388051808454 : Closed e2388051808454 ∧ code e2388051808454 = 11184144830662 := by decide
theorem cert_e2388051808454 : check e2388051808454 [[]] .width = true := by decide
def e2388051814426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388051814426 : Closed e2388051814426 ∧ code e2388051814426 = 11184144836634 := by decide
theorem cert_e2388051814426 : check e2388051814426 [[]] .width = true := by decide
def e2388051827226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051827226 : Closed e2388051827226 ∧ code e2388051827226 = 11184144849434 := by decide
theorem cert_e2388051827226 : check e2388051827226 [[]] .width = true := by decide
def e2388051838490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388051838490 : Closed e2388051838490 ∧ code e2388051838490 = 11184144860698 := by decide
theorem cert_e2388051838490 : check e2388051838490 [[]] .width = true := by decide
def e2388051841222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388051841222 : Closed e2388051841222 ∧ code e2388051841222 = 11184144863430 := by decide
theorem cert_e2388051841222 : check e2388051841222 [[]] .width = true := by decide
def e2388051863578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388051863578 : Closed e2388051863578 ∧ code e2388051863578 = 11184144885786 := by decide
theorem cert_e2388051863578 : check e2388051863578 [[]] .width = true := by decide
def e2388053162522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388053162522 : Closed e2388053162522 ∧ code e2388053162522 = 11184146184730 := by decide
theorem cert_e2388053162522 : check e2388053162522 [[],[.left]] .chain = true := by decide
def e2388053178906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388053178906 : Closed e2388053178906 ∧ code e2388053178906 = 11184146201114 := by decide
theorem cert_e2388053178906 : check e2388053178906 [[],[.left]] .chain = true := by decide
def e2388055144986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055144986 : Closed e2388055144986 ∧ code e2388055144986 = 11184148167194 := by decide
theorem cert_e2388055144986 : check e2388055144986 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388055153178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055153178 : Closed e2388055153178 ∧ code e2388055153178 = 11184148175386 := by decide
theorem cert_e2388055153178 : check e2388055153178 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388055210522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055210522 : Closed e2388055210522 ∧ code e2388055210522 = 11184148232730 := by decide
theorem cert_e2388055210522 : check e2388055210522 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388055222810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055222810 : Closed e2388055222810 ∧ code e2388055222810 = 11184148245018 := by decide
theorem cert_e2388055222810 : check e2388055222810 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388055251482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055251482 : Closed e2388055251482 ∧ code e2388055251482 = 11184148273690 := by decide
theorem cert_e2388055251482 : check e2388055251482 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388055255578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055255578 : Closed e2388055255578 ∧ code e2388055255578 = 11184148277786 := by decide
theorem cert_e2388055255578 : check e2388055255578 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388055538202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055538202 : Closed e2388055538202 ∧ code e2388055538202 = 11184148560410 := by decide
theorem cert_e2388055538202 : check e2388055538202 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388055546394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055546394 : Closed e2388055546394 ∧ code e2388055546394 = 11184148568602 := by decide
theorem cert_e2388055546394 : check e2388055546394 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388055882266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055882266 : Closed e2388055882266 ∧ code e2388055882266 = 11184148904474 := by decide
theorem cert_e2388055882266 : check e2388055882266 [[]] .width = true := by decide
def e2388055931418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055931418 : Closed e2388055931418 ∧ code e2388055931418 = 11184148953626 := by decide
theorem cert_e2388055931418 : check e2388055931418 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388055943706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388055943706 : Closed e2388055943706 ∧ code e2388055943706 = 11184148965914 := by decide
theorem cert_e2388055943706 : check e2388055943706 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388056054298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388056054298 : Closed e2388056054298 ∧ code e2388056054298 = 11184149076506 := by decide
theorem cert_e2388056054298 : check e2388056054298 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388056055834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388056055834 : Closed e2388056055834 ∧ code e2388056055834 = 11184149078042 := by decide
theorem cert_e2388056055834 : check e2388056055834 [[],[.left]] .smaller = true := by decide
def e2388056055926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388056055926 : Closed e2388056055926 ∧ code e2388056055926 = 11184149078134 := by decide
theorem cert_e2388056055926 : check e2388056055926 [[],[.left]] .chain = true := by decide
def e2388056056170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388056056170 : Closed e2388056056170 ∧ code e2388056056170 = 11184149078378 := by decide
theorem cert_e2388056056170 : check e2388056056170 [[],[.left]] .chain = true := by decide
def e2388056056218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388056056218 : Closed e2388056056218 ∧ code e2388056056218 = 11184149078426 := by decide
theorem cert_e2388056056218 : check e2388056056218 [[],[.left]] .chain = true := by decide
def e2388056065562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388056065562 : Closed e2388056065562 ∧ code e2388056065562 = 11184149087770 := by decide
theorem cert_e2388056065562 : check e2388056065562 [[]] .width = true := by decide
def e2388056068294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388056068294 : Closed e2388056068294 ∧ code e2388056068294 = 11184149090502 := by decide
theorem cert_e2388056068294 : check e2388056068294 [[]] .width = true := by decide
def e2388056136218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388056136218 : Closed e2388056136218 ∧ code e2388056136218 = 11184149158426 := by decide
theorem cert_e2388056136218 : check e2388056136218 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388056140314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388056140314 : Closed e2388056140314 ∧ code e2388056140314 = 11184149162522 := by decide
theorem cert_e2388056140314 : check e2388056140314 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388056185370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388056185370 : Closed e2388056185370 ∧ code e2388056185370 = 11184149207578 := by decide
theorem cert_e2388056185370 : check e2388056185370 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2388056186906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388056186906 : Closed e2388056186906 ∧ code e2388056186906 = 11184149209114 := by decide
theorem cert_e2388056186906 : check e2388056186906 [[],[.left]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2388050811418
#print axioms Blc.Floor43.cert_e2388051008026
