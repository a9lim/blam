import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e725047365354 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)) (.var 0)))
theorem wire_e725047365354 : Closed e725047365354 ∧ code e725047365354 = 9521140387562 := by decide
theorem cert_e725047365354 : check e725047365354 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047365482 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)) (.var 0)))
theorem wire_e725047365482 : Closed e725047365482 ∧ code e725047365482 = 9521140387690 := by decide
theorem cert_e725047365482 : check e725047365482 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047371498 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)) (.var 0)))
theorem wire_e725047371498 : Closed e725047371498 ∧ code e725047371498 = 9521140393706 := by decide
theorem cert_e725047371498 : check e725047371498 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047371690 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725047371690 : Closed e725047371690 ∧ code e725047371690 = 9521140393898 := by decide
theorem cert_e725047371690 : check e725047371690 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047374698 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)) (.var 0)))
theorem wire_e725047374698 : Closed e725047374698 ∧ code e725047374698 = 9521140396906 := by decide
theorem cert_e725047374698 : check e725047374698 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725047374762 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725047374762 : Closed e725047374762 ∧ code e725047374762 = 9521140396970 := by decide
theorem cert_e725047374762 : check e725047374762 [[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e725056796394 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725056796394 : Closed e725056796394 ∧ code e725056796394 = 9521149818602 := by decide
theorem cert_e725056796394 : check e725056796394 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e725056796522 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725056796522 : Closed e725056796522 ∧ code e725056796522 = 9521149818730 := by decide
theorem cert_e725056796522 : check e725056796522 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e725056797418 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)) (.var 0)))
theorem wire_e725056797418 : Closed e725056797418 ∧ code e725056797418 = 9521149819626 := by decide
theorem cert_e725056797418 : check e725056797418 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e725056797610 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725056797610 : Closed e725056797610 ∧ code e725056797610 = 9521149819818 := by decide
private def t_e725056797610 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)) (.var 0)))
theorem cert_e725056797610 : ¬ IsSelfInterpreter e725056797610 :=
  wSource (t := t_e725056797610) (replay_sound (ps := []) (t := e725056797610) (by decide)) (by decide)
def e725056798058 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)) (.var 0)))
theorem wire_e725056798058 : Closed e725056798058 ∧ code e725056798058 = 9521149820266 := by decide
theorem cert_e725056798058 : check e725056798058 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e725056798122 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)) (.var 0)))
theorem wire_e725056798122 : Closed e725056798122 ∧ code e725056798122 = 9521149820330 := by decide
private def t_e725056798122 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)) (.var 0)))
theorem cert_e725056798122 : ¬ IsSelfInterpreter e725056798122 :=
  wSource (t := t_e725056798122) (replay_sound (ps := []) (t := e725056798122) (by decide)) (by decide)
def e725056802538 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)) (.var 0)))
theorem wire_e725056802538 : Closed e725056802538 ∧ code e725056802538 = 9521149824746 := by decide
theorem cert_e725056802538 : check e725056802538 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e725056802666 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)) (.var 0)))
theorem wire_e725056802666 : Closed e725056802666 ∧ code e725056802666 = 9521149824874 := by decide
theorem cert_e725056802666 : check e725056802666 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e725056808682 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)) (.var 0)))
theorem wire_e725056808682 : Closed e725056808682 ∧ code e725056808682 = 9521149830890 := by decide
theorem cert_e725056808682 : check e725056808682 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e725056808874 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725056808874 : Closed e725056808874 ∧ code e725056808874 = 9521149831082 := by decide
theorem cert_e725056808874 : check e725056808874 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e725056811882 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)) (.var 0)))
theorem wire_e725056811882 : Closed e725056811882 ∧ code e725056811882 = 9521149834090 := by decide
theorem cert_e725056811882 : check e725056811882 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e725056811946 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)) (.var 0)))
theorem wire_e725056811946 : Closed e725056811946 ∧ code e725056811946 = 9521149834154 := by decide
theorem cert_e725056811946 : check e725056811946 [[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e738779838570 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738779838570 : Closed e738779838570 ∧ code e738779838570 = 9534872860778 := by decide
theorem cert_e738779838570 : check e738779838570 [] .sourceHead = true := by decide
def e738779839002 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738779839002 : Closed e738779839002 ∧ code e738779839002 = 9534872861210 := by decide
theorem cert_e738779839002 : check e738779839002 [] .sourceHead = true := by decide
def e738779846762 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738779846762 : Closed e738779846762 ∧ code e738779846762 = 9534872868970 := by decide
theorem cert_e738779846762 : check e738779846762 [] .sourceHead = true := by decide
def e738779847194 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738779847194 : Closed e738779847194 ∧ code e738779847194 = 9534872869402 := by decide
theorem cert_e738779847194 : check e738779847194 [] .sourceHead = true := by decide
def e738779904106 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738779904106 : Closed e738779904106 ∧ code e738779904106 = 9534872926314 := by decide
theorem cert_e738779904106 : check e738779904106 [] .sourceHead = true := by decide
def e738779904538 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738779904538 : Closed e738779904538 ∧ code e738779904538 = 9534872926746 := by decide
theorem cert_e738779904538 : check e738779904538 [] .sourceHead = true := by decide
def e738779916394 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738779916394 : Closed e738779916394 ∧ code e738779916394 = 9534872938602 := by decide
theorem cert_e738779916394 : check e738779916394 [] .sourceHead = true := by decide
def e738779916826 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738779916826 : Closed e738779916826 ∧ code e738779916826 = 9534872939034 := by decide
theorem cert_e738779916826 : check e738779916826 [] .sourceHead = true := by decide
def e738779945066 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738779945066 : Closed e738779945066 ∧ code e738779945066 = 9534872967274 := by decide
theorem cert_e738779945066 : check e738779945066 [] .sourceHead = true := by decide
def e738779945498 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738779945498 : Closed e738779945498 ∧ code e738779945498 = 9534872967706 := by decide
theorem cert_e738779945498 : check e738779945498 [] .sourceHead = true := by decide
def e738779949162 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738779949162 : Closed e738779949162 ∧ code e738779949162 = 9534872971370 := by decide
theorem cert_e738779949162 : check e738779949162 [] .sourceHead = true := by decide
def e738779949594 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738779949594 : Closed e738779949594 ∧ code e738779949594 = 9534872971802 := by decide
theorem cert_e738779949594 : check e738779949594 [] .sourceHead = true := by decide
def e738780166250 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738780166250 : Closed e738780166250 ∧ code e738780166250 = 9534873188458 := by decide
theorem cert_e738780166250 : check e738780166250 [] .sourceHead = true := by decide
def e738780166682 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738780166682 : Closed e738780166682 ∧ code e738780166682 = 9534873188890 := by decide
theorem cert_e738780166682 : check e738780166682 [] .sourceHead = true := by decide
def e738780178538 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738780178538 : Closed e738780178538 ∧ code e738780178538 = 9534873200746 := by decide
theorem cert_e738780178538 : check e738780178538 [] .sourceHead = true := by decide
def e738780178970 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738780178970 : Closed e738780178970 ∧ code e738780178970 = 9534873201178 := by decide
theorem cert_e738780178970 : check e738780178970 [] .sourceHead = true := by decide
def e738780227690 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738780227690 : Closed e738780227690 ∧ code e738780227690 = 9534873249898 := by decide
theorem cert_e738780227690 : check e738780227690 [] .sourceHead = true := by decide
def e738780228122 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738780228122 : Closed e738780228122 ∧ code e738780228122 = 9534873250330 := by decide
theorem cert_e738780228122 : check e738780228122 [] .sourceHead = true := by decide
def e738780338282 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738780338282 : Closed e738780338282 ∧ code e738780338282 = 9534873360490 := by decide
theorem cert_e738780338282 : check e738780338282 [] .sourceHead = true := by decide
def e738780338714 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738780338714 : Closed e738780338714 ∧ code e738780338714 = 9534873360922 := by decide
theorem cert_e738780338714 : check e738780338714 [] .sourceHead = true := by decide
def e738780342378 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738780342378 : Closed e738780342378 ∧ code e738780342378 = 9534873364586 := by decide
theorem cert_e738780342378 : check e738780342378 [] .sourceHead = true := by decide
def e738780342810 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738780342810 : Closed e738780342810 ∧ code e738780342810 = 9534873365018 := by decide
theorem cert_e738780342810 : check e738780342810 [] .sourceHead = true := by decide
def e738780358762 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738780358762 : Closed e738780358762 ∧ code e738780358762 = 9534873380970 := by decide
theorem cert_e738780358762 : check e738780358762 [] .sourceHead = true := by decide
def e738780359194 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738780359194 : Closed e738780359194 ∧ code e738780359194 = 9534873381402 := by decide
theorem cert_e738780359194 : check e738780359194 [] .sourceHead = true := by decide
def e738781411434 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738781411434 : Closed e738781411434 ∧ code e738781411434 = 9534874433642 := by decide
theorem cert_e738781411434 : check e738781411434 [] .sourceHead = true := by decide
def e738781411866 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738781411866 : Closed e738781411866 ∧ code e738781411866 = 9534874434074 := by decide
theorem cert_e738781411866 : check e738781411866 [] .sourceHead = true := by decide
def e738781419626 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738781419626 : Closed e738781419626 ∧ code e738781419626 = 9534874441834 := by decide
theorem cert_e738781419626 : check e738781419626 [] .sourceHead = true := by decide
def e738781420058 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738781420058 : Closed e738781420058 ∧ code e738781420058 = 9534874442266 := by decide
theorem cert_e738781420058 : check e738781420058 [] .sourceHead = true := by decide
def e738781476970 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738781476970 : Closed e738781476970 ∧ code e738781476970 = 9534874499178 := by decide
theorem cert_e738781476970 : check e738781476970 [] .sourceHead = true := by decide
def e738781477402 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738781477402 : Closed e738781477402 ∧ code e738781477402 = 9534874499610 := by decide
theorem cert_e738781477402 : check e738781477402 [] .sourceHead = true := by decide
def e738781489258 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738781489258 : Closed e738781489258 ∧ code e738781489258 = 9534874511466 := by decide
theorem cert_e738781489258 : check e738781489258 [] .sourceHead = true := by decide
def e738781489690 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738781489690 : Closed e738781489690 ∧ code e738781489690 = 9534874511898 := by decide
theorem cert_e738781489690 : check e738781489690 [] .sourceHead = true := by decide
def e738781517930 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738781517930 : Closed e738781517930 ∧ code e738781517930 = 9534874540138 := by decide
theorem cert_e738781517930 : check e738781517930 [] .sourceHead = true := by decide
def e738781518362 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738781518362 : Closed e738781518362 ∧ code e738781518362 = 9534874540570 := by decide
theorem cert_e738781518362 : check e738781518362 [] .sourceHead = true := by decide
def e738781522026 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738781522026 : Closed e738781522026 ∧ code e738781522026 = 9534874544234 := by decide
theorem cert_e738781522026 : check e738781522026 [] .sourceHead = true := by decide
def e738781522458 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738781522458 : Closed e738781522458 ∧ code e738781522458 = 9534874544666 := by decide
theorem cert_e738781522458 : check e738781522458 [] .sourceHead = true := by decide
def e738781804650 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738781804650 : Closed e738781804650 ∧ code e738781804650 = 9534874826858 := by decide
theorem cert_e738781804650 : check e738781804650 [] .sourceHead = true := by decide
def e738781805082 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738781805082 : Closed e738781805082 ∧ code e738781805082 = 9534874827290 := by decide
theorem cert_e738781805082 : check e738781805082 [] .sourceHead = true := by decide
def e738781812842 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738781812842 : Closed e738781812842 ∧ code e738781812842 = 9534874835050 := by decide
theorem cert_e738781812842 : check e738781812842 [] .sourceHead = true := by decide
def e738781813274 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738781813274 : Closed e738781813274 ∧ code e738781813274 = 9534874835482 := by decide
theorem cert_e738781813274 : check e738781813274 [] .sourceHead = true := by decide
def e738782197866 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738782197866 : Closed e738782197866 ∧ code e738782197866 = 9534875220074 := by decide
theorem cert_e738782197866 : check e738782197866 [] .sourceHead = true := by decide
def e738782198298 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738782198298 : Closed e738782198298 ∧ code e738782198298 = 9534875220506 := by decide
theorem cert_e738782198298 : check e738782198298 [] .sourceHead = true := by decide
def e738782210154 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738782210154 : Closed e738782210154 ∧ code e738782210154 = 9534875232362 := by decide
theorem cert_e738782210154 : check e738782210154 [] .sourceHead = true := by decide
def e738782210586 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738782210586 : Closed e738782210586 ∧ code e738782210586 = 9534875232794 := by decide
theorem cert_e738782210586 : check e738782210586 [] .sourceHead = true := by decide
def e738782402666 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738782402666 : Closed e738782402666 ∧ code e738782402666 = 9534875424874 := by decide
theorem cert_e738782402666 : check e738782402666 [] .sourceHead = true := by decide
def e738782403098 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738782403098 : Closed e738782403098 ∧ code e738782403098 = 9534875425306 := by decide
theorem cert_e738782403098 : check e738782403098 [] .sourceHead = true := by decide
def e738782406762 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738782406762 : Closed e738782406762 ∧ code e738782406762 = 9534875428970 := by decide
theorem cert_e738782406762 : check e738782406762 [] .sourceHead = true := by decide
def e738782407194 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738782407194 : Closed e738782407194 ∧ code e738782407194 = 9534875429402 := by decide
theorem cert_e738782407194 : check e738782407194 [] .sourceHead = true := by decide
def e738783049834 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783049834 : Closed e738783049834 ∧ code e738783049834 = 9534876072042 := by decide
theorem cert_e738783049834 : check e738783049834 [] .sourceHead = true := by decide
def e738783050266 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783050266 : Closed e738783050266 ∧ code e738783050266 = 9534876072474 := by decide
theorem cert_e738783050266 : check e738783050266 [] .sourceHead = true := by decide
def e738783062122 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783062122 : Closed e738783062122 ∧ code e738783062122 = 9534876084330 := by decide
theorem cert_e738783062122 : check e738783062122 [] .sourceHead = true := by decide
def e738783062554 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783062554 : Closed e738783062554 ∧ code e738783062554 = 9534876084762 := by decide
theorem cert_e738783062554 : check e738783062554 [] .sourceHead = true := by decide
def e738783111274 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783111274 : Closed e738783111274 ∧ code e738783111274 = 9534876133482 := by decide
theorem cert_e738783111274 : check e738783111274 [] .sourceHead = true := by decide
def e738783111706 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783111706 : Closed e738783111706 ∧ code e738783111706 = 9534876133914 := by decide
theorem cert_e738783111706 : check e738783111706 [] .sourceHead = true := by decide
def e738783246442 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783246442 : Closed e738783246442 ∧ code e738783246442 = 9534876268650 := by decide
theorem cert_e738783246442 : check e738783246442 [] .sourceHead = true := by decide
def e738783246874 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783246874 : Closed e738783246874 ∧ code e738783246874 = 9534876269082 := by decide
theorem cert_e738783246874 : check e738783246874 [] .sourceHead = true := by decide
def e738783258730 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783258730 : Closed e738783258730 ∧ code e738783258730 = 9534876280938 := by decide
theorem cert_e738783258730 : check e738783258730 [] .sourceHead = true := by decide
def e738783259162 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783259162 : Closed e738783259162 ∧ code e738783259162 = 9534876281370 := by decide
theorem cert_e738783259162 : check e738783259162 [] .sourceHead = true := by decide
def e738783553642 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783553642 : Closed e738783553642 ∧ code e738783553642 = 9534876575850 := by decide
theorem cert_e738783553642 : check e738783553642 [] .sourceHead = true := by decide
def e738783554074 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783554074 : Closed e738783554074 ∧ code e738783554074 = 9534876576282 := by decide
theorem cert_e738783554074 : check e738783554074 [] .sourceHead = true := by decide
def e738783877226 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783877226 : Closed e738783877226 ∧ code e738783877226 = 9534876899434 := by decide
theorem cert_e738783877226 : check e738783877226 [] .sourceHead = true := by decide
def e738783877658 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783877658 : Closed e738783877658 ∧ code e738783877658 = 9534876899866 := by decide
theorem cert_e738783877658 : check e738783877658 [] .sourceHead = true := by decide
def e738783881322 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783881322 : Closed e738783881322 ∧ code e738783881322 = 9534876903530 := by decide
theorem cert_e738783881322 : check e738783881322 [] .sourceHead = true := by decide
def e738783881754 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783881754 : Closed e738783881754 ∧ code e738783881754 = 9534876903962 := by decide
theorem cert_e738783881754 : check e738783881754 [] .sourceHead = true := by decide
def e738783897706 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783897706 : Closed e738783897706 ∧ code e738783897706 = 9534876919914 := by decide
theorem cert_e738783897706 : check e738783897706 [] .sourceHead = true := by decide
def e738783898138 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783898138 : Closed e738783898138 ∧ code e738783898138 = 9534876920346 := by decide
theorem cert_e738783898138 : check e738783898138 [] .sourceHead = true := by decide
def e738783975530 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783975530 : Closed e738783975530 ∧ code e738783975530 = 9534876997738 := by decide
theorem cert_e738783975530 : check e738783975530 [] .sourceHead = true := by decide
def e738783975962 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783975962 : Closed e738783975962 ∧ code e738783975962 = 9534876998170 := by decide
theorem cert_e738783975962 : check e738783975962 [] .sourceHead = true := by decide
def e738783979626 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738783979626 : Closed e738783979626 ∧ code e738783979626 = 9534877001834 := by decide
theorem cert_e738783979626 : check e738783979626 [] .sourceHead = true := by decide
def e738783980058 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738783980058 : Closed e738783980058 ∧ code e738783980058 = 9534877002266 := by decide
theorem cert_e738783980058 : check e738783980058 [] .sourceHead = true := by decide
def e738784077930 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738784077930 : Closed e738784077930 ∧ code e738784077930 = 9534877100138 := by decide
theorem cert_e738784077930 : check e738784077930 [] .sourceHead = true := by decide
def e738784078362 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738784078362 : Closed e738784078362 ∧ code e738784078362 = 9534877100570 := by decide
theorem cert_e738784078362 : check e738784078362 [] .sourceHead = true := by decide
def e738787702890 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738787702890 : Closed e738787702890 ∧ code e738787702890 = 9534880725098 := by decide
theorem cert_e738787702890 : check e738787702890 [] .sourceHead = true := by decide
def e738787703322 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738787703322 : Closed e738787703322 ∧ code e738787703322 = 9534880725530 := by decide
theorem cert_e738787703322 : check e738787703322 [] .sourceHead = true := by decide
def e738787711082 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738787711082 : Closed e738787711082 ∧ code e738787711082 = 9534880733290 := by decide
theorem cert_e738787711082 : check e738787711082 [] .sourceHead = true := by decide
def e738787711514 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738787711514 : Closed e738787711514 ∧ code e738787711514 = 9534880733722 := by decide
theorem cert_e738787711514 : check e738787711514 [] .sourceHead = true := by decide
def e738787768426 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738787768426 : Closed e738787768426 ∧ code e738787768426 = 9534880790634 := by decide
theorem cert_e738787768426 : check e738787768426 [] .sourceHead = true := by decide
def e738787768858 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738787768858 : Closed e738787768858 ∧ code e738787768858 = 9534880791066 := by decide
theorem cert_e738787768858 : check e738787768858 [] .sourceHead = true := by decide
def e738787780714 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738787780714 : Closed e738787780714 ∧ code e738787780714 = 9534880802922 := by decide
theorem cert_e738787780714 : check e738787780714 [] .sourceHead = true := by decide
def e738787781146 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738787781146 : Closed e738787781146 ∧ code e738787781146 = 9534880803354 := by decide
theorem cert_e738787781146 : check e738787781146 [] .sourceHead = true := by decide
def e738787809386 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738787809386 : Closed e738787809386 ∧ code e738787809386 = 9534880831594 := by decide
theorem cert_e738787809386 : check e738787809386 [] .sourceHead = true := by decide
def e738787809818 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738787809818 : Closed e738787809818 ∧ code e738787809818 = 9534880832026 := by decide
theorem cert_e738787809818 : check e738787809818 [] .sourceHead = true := by decide
def e738787813482 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738787813482 : Closed e738787813482 ∧ code e738787813482 = 9534880835690 := by decide
theorem cert_e738787813482 : check e738787813482 [] .sourceHead = true := by decide
def e738787813914 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738787813914 : Closed e738787813914 ∧ code e738787813914 = 9534880836122 := by decide
theorem cert_e738787813914 : check e738787813914 [] .sourceHead = true := by decide
def e738788096106 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738788096106 : Closed e738788096106 ∧ code e738788096106 = 9534881118314 := by decide
theorem cert_e738788096106 : check e738788096106 [] .sourceHead = true := by decide
def e738788096538 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738788096538 : Closed e738788096538 ∧ code e738788096538 = 9534881118746 := by decide
theorem cert_e738788096538 : check e738788096538 [] .sourceHead = true := by decide
def e738788104298 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738788104298 : Closed e738788104298 ∧ code e738788104298 = 9534881126506 := by decide
theorem cert_e738788104298 : check e738788104298 [] .sourceHead = true := by decide
def e738788104730 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738788104730 : Closed e738788104730 ∧ code e738788104730 = 9534881126938 := by decide
theorem cert_e738788104730 : check e738788104730 [] .sourceHead = true := by decide
def e738788489322 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738788489322 : Closed e738788489322 ∧ code e738788489322 = 9534881511530 := by decide
theorem cert_e738788489322 : check e738788489322 [] .sourceHead = true := by decide
def e738788489754 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738788489754 : Closed e738788489754 ∧ code e738788489754 = 9534881511962 := by decide
theorem cert_e738788489754 : check e738788489754 [] .sourceHead = true := by decide
def e738788501610 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738788501610 : Closed e738788501610 ∧ code e738788501610 = 9534881523818 := by decide
theorem cert_e738788501610 : check e738788501610 [] .sourceHead = true := by decide
def e738788502042 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738788502042 : Closed e738788502042 ∧ code e738788502042 = 9534881524250 := by decide
theorem cert_e738788502042 : check e738788502042 [] .sourceHead = true := by decide
def e738788694122 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738788694122 : Closed e738788694122 ∧ code e738788694122 = 9534881716330 := by decide
theorem cert_e738788694122 : check e738788694122 [] .sourceHead = true := by decide
def e738788694554 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738788694554 : Closed e738788694554 ∧ code e738788694554 = 9534881716762 := by decide
theorem cert_e738788694554 : check e738788694554 [] .sourceHead = true := by decide
def e738788698218 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738788698218 : Closed e738788698218 ∧ code e738788698218 = 9534881720426 := by decide
theorem cert_e738788698218 : check e738788698218 [] .sourceHead = true := by decide
def e738788698650 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738788698650 : Closed e738788698650 ∧ code e738788698650 = 9534881720858 := by decide
theorem cert_e738788698650 : check e738788698650 [] .sourceHead = true := by decide
def e738794584170 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738794584170 : Closed e738794584170 ∧ code e738794584170 = 9534887606378 := by decide
theorem cert_e738794584170 : check e738794584170 [] .sourceHead = true := by decide
def e738794584602 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738794584602 : Closed e738794584602 ∧ code e738794584602 = 9534887606810 := by decide
theorem cert_e738794584602 : check e738794584602 [] .sourceHead = true := by decide
def e738794596458 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738794596458 : Closed e738794596458 ∧ code e738794596458 = 9534887618666 := by decide
theorem cert_e738794596458 : check e738794596458 [] .sourceHead = true := by decide
def e738794596890 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738794596890 : Closed e738794596890 ∧ code e738794596890 = 9534887619098 := by decide
theorem cert_e738794596890 : check e738794596890 [] .sourceHead = true := by decide
def e738794645610 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738794645610 : Closed e738794645610 ∧ code e738794645610 = 9534887667818 := by decide
theorem cert_e738794645610 : check e738794645610 [] .sourceHead = true := by decide
def e738794646042 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738794646042 : Closed e738794646042 ∧ code e738794646042 = 9534887668250 := by decide
theorem cert_e738794646042 : check e738794646042 [] .sourceHead = true := by decide
def e738794780778 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738794780778 : Closed e738794780778 ∧ code e738794780778 = 9534887802986 := by decide
theorem cert_e738794780778 : check e738794780778 [] .sourceHead = true := by decide
def e738794781210 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738794781210 : Closed e738794781210 ∧ code e738794781210 = 9534887803418 := by decide
theorem cert_e738794781210 : check e738794781210 [] .sourceHead = true := by decide
def e738794793066 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738794793066 : Closed e738794793066 ∧ code e738794793066 = 9534887815274 := by decide
theorem cert_e738794793066 : check e738794793066 [] .sourceHead = true := by decide
def e738794793498 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738794793498 : Closed e738794793498 ∧ code e738794793498 = 9534887815706 := by decide
theorem cert_e738794793498 : check e738794793498 [] .sourceHead = true := by decide
def e738795087978 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738795087978 : Closed e738795087978 ∧ code e738795087978 = 9534888110186 := by decide
theorem cert_e738795087978 : check e738795087978 [] .sourceHead = true := by decide
def e738795088410 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738795088410 : Closed e738795088410 ∧ code e738795088410 = 9534888110618 := by decide
theorem cert_e738795088410 : check e738795088410 [] .sourceHead = true := by decide
def e738798033002 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738798033002 : Closed e738798033002 ∧ code e738798033002 = 9534891055210 := by decide
theorem cert_e738798033002 : check e738798033002 [] .sourceHead = true := by decide
def e738798033434 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738798033434 : Closed e738798033434 ∧ code e738798033434 = 9534891055642 := by decide
theorem cert_e738798033434 : check e738798033434 [] .sourceHead = true := by decide
def e738798037098 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738798037098 : Closed e738798037098 ∧ code e738798037098 = 9534891059306 := by decide
theorem cert_e738798037098 : check e738798037098 [] .sourceHead = true := by decide
def e738798037530 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738798037530 : Closed e738798037530 ∧ code e738798037530 = 9534891059738 := by decide
theorem cert_e738798037530 : check e738798037530 [] .sourceHead = true := by decide
def e738798053482 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738798053482 : Closed e738798053482 ∧ code e738798053482 = 9534891075690 := by decide
theorem cert_e738798053482 : check e738798053482 [] .sourceHead = true := by decide
def e738798053914 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738798053914 : Closed e738798053914 ∧ code e738798053914 = 9534891076122 := by decide
theorem cert_e738798053914 : check e738798053914 [] .sourceHead = true := by decide
def e738798131306 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738798131306 : Closed e738798131306 ∧ code e738798131306 = 9534891153514 := by decide
theorem cert_e738798131306 : check e738798131306 [] .sourceHead = true := by decide
def e738798131738 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738798131738 : Closed e738798131738 ∧ code e738798131738 = 9534891153946 := by decide
theorem cert_e738798131738 : check e738798131738 [] .sourceHead = true := by decide
def e738798135402 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738798135402 : Closed e738798135402 ∧ code e738798135402 = 9534891157610 := by decide
theorem cert_e738798135402 : check e738798135402 [] .sourceHead = true := by decide
def e738798135834 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738798135834 : Closed e738798135834 ∧ code e738798135834 = 9534891158042 := by decide
theorem cert_e738798135834 : check e738798135834 [] .sourceHead = true := by decide
def e738798233706 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738798233706 : Closed e738798233706 ∧ code e738798233706 = 9534891255914 := by decide
theorem cert_e738798233706 : check e738798233706 [] .sourceHead = true := by decide
def e738798234138 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738798234138 : Closed e738798234138 ∧ code e738798234138 = 9534891256346 := by decide
theorem cert_e738798234138 : check e738798234138 [] .sourceHead = true := by decide
def e738938697834 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738938697834 : Closed e738938697834 ∧ code e738938697834 = 9535031720042 := by decide
theorem cert_e738938697834 : check e738938697834 [] .sourceHead = true := by decide
def e738938698266 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738938698266 : Closed e738938698266 ∧ code e738938698266 = 9535031720474 := by decide
theorem cert_e738938698266 : check e738938698266 [] .sourceHead = true := by decide
def e738938706026 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738938706026 : Closed e738938706026 ∧ code e738938706026 = 9535031728234 := by decide
theorem cert_e738938706026 : check e738938706026 [] .sourceHead = true := by decide
def e738938706458 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738938706458 : Closed e738938706458 ∧ code e738938706458 = 9535031728666 := by decide
theorem cert_e738938706458 : check e738938706458 [] .sourceHead = true := by decide
def e738938763370 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738938763370 : Closed e738938763370 ∧ code e738938763370 = 9535031785578 := by decide
theorem cert_e738938763370 : check e738938763370 [] .sourceHead = true := by decide
def e738938763802 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738938763802 : Closed e738938763802 ∧ code e738938763802 = 9535031786010 := by decide
theorem cert_e738938763802 : check e738938763802 [] .sourceHead = true := by decide
def e738938775658 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738938775658 : Closed e738938775658 ∧ code e738938775658 = 9535031797866 := by decide
theorem cert_e738938775658 : check e738938775658 [] .sourceHead = true := by decide
def e738938776090 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738938776090 : Closed e738938776090 ∧ code e738938776090 = 9535031798298 := by decide
theorem cert_e738938776090 : check e738938776090 [] .sourceHead = true := by decide
def e738938804330 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738938804330 : Closed e738938804330 ∧ code e738938804330 = 9535031826538 := by decide
theorem cert_e738938804330 : check e738938804330 [] .sourceHead = true := by decide
def e738938804762 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738938804762 : Closed e738938804762 ∧ code e738938804762 = 9535031826970 := by decide
theorem cert_e738938804762 : check e738938804762 [] .sourceHead = true := by decide
def e738938808426 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738938808426 : Closed e738938808426 ∧ code e738938808426 = 9535031830634 := by decide
theorem cert_e738938808426 : check e738938808426 [] .sourceHead = true := by decide
def e738938808858 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738938808858 : Closed e738938808858 ∧ code e738938808858 = 9535031831066 := by decide
theorem cert_e738938808858 : check e738938808858 [] .sourceHead = true := by decide
def e738939091050 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738939091050 : Closed e738939091050 ∧ code e738939091050 = 9535032113258 := by decide
theorem cert_e738939091050 : check e738939091050 [] .sourceHead = true := by decide
def e738939091482 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738939091482 : Closed e738939091482 ∧ code e738939091482 = 9535032113690 := by decide
theorem cert_e738939091482 : check e738939091482 [] .sourceHead = true := by decide
def e738939099242 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738939099242 : Closed e738939099242 ∧ code e738939099242 = 9535032121450 := by decide
theorem cert_e738939099242 : check e738939099242 [] .sourceHead = true := by decide
def e738939099674 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738939099674 : Closed e738939099674 ∧ code e738939099674 = 9535032121882 := by decide
theorem cert_e738939099674 : check e738939099674 [] .sourceHead = true := by decide
def e738939484266 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738939484266 : Closed e738939484266 ∧ code e738939484266 = 9535032506474 := by decide
theorem cert_e738939484266 : check e738939484266 [] .sourceHead = true := by decide
def e738939484698 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738939484698 : Closed e738939484698 ∧ code e738939484698 = 9535032506906 := by decide
theorem cert_e738939484698 : check e738939484698 [] .sourceHead = true := by decide
def e738939496554 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738939496554 : Closed e738939496554 ∧ code e738939496554 = 9535032518762 := by decide
theorem cert_e738939496554 : check e738939496554 [] .sourceHead = true := by decide
def e738939496986 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738939496986 : Closed e738939496986 ∧ code e738939496986 = 9535032519194 := by decide
theorem cert_e738939496986 : check e738939496986 [] .sourceHead = true := by decide
def e738939689066 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738939689066 : Closed e738939689066 ∧ code e738939689066 = 9535032711274 := by decide
theorem cert_e738939689066 : check e738939689066 [] .sourceHead = true := by decide
def e738939689498 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738939689498 : Closed e738939689498 ∧ code e738939689498 = 9535032711706 := by decide
theorem cert_e738939689498 : check e738939689498 [] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e725056797610
#print axioms Blc.Floor43.cert_e725056798122
