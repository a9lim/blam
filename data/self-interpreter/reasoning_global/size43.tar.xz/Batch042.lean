import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e611631783478 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e611631783478 : Closed e611631783478 ∧ code e611631783478 = 9407724805686 := by decide
theorem cert_e611631783478 : check e611631783478 [[.under]] .sourceHead = true := by decide
def e611631783482 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e611631783482 : Closed e611631783482 ∧ code e611631783482 = 9407724805690 := by decide
theorem cert_e611631783482 : check e611631783482 [[.under]] .sourceHead = true := by decide
def e611631783566 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e611631783566 : Closed e611631783566 ∧ code e611631783566 = 9407724805774 := by decide
theorem cert_e611631783566 : check e611631783566 [[.under]] .sourceHead = true := by decide
def e611631783622 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e611631783622 : Closed e611631783622 ∧ code e611631783622 = 9407724805830 := by decide
theorem cert_e611631783622 : check e611631783622 [[.under]] .sourceHead = true := by decide
def e611631785758 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e611631785758 : Closed e611631785758 ∧ code e611631785758 = 9407724807966 := by decide
theorem cert_e611631785758 : check e611631785758 [[.under]] .sourceHead = true := by decide
def e611631785870 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e611631785870 : Closed e611631785870 ∧ code e611631785870 = 9407724808078 := by decide
theorem cert_e611631785870 : check e611631785870 [[.under]] .sourceHead = true := by decide
def e611631788830 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e611631788830 : Closed e611631788830 ∧ code e611631788830 = 9407724811038 := by decide
theorem cert_e611631788830 : check e611631788830 [[.under]] .sourceHead = true := by decide
def e611631788998 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e611631788998 : Closed e611631788998 ∧ code e611631788998 = 9407724811206 := by decide
theorem cert_e611631788998 : check e611631788998 [[.under]] .sourceHead = true := by decide
def e611631790478 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e611631790478 : Closed e611631790478 ∧ code e611631790478 = 9407724812686 := by decide
theorem cert_e611631790478 : check e611631790478 [[.under]] .sourceHead = true := by decide
def e611631790534 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e611631790534 : Closed e611631790534 ∧ code e611631790534 = 9407724812742 := by decide
theorem cert_e611631790534 : check e611631790534 [[.under]] .sourceHead = true := by decide
def e611636483806 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e611636483806 : Closed e611636483806 ∧ code e611636483806 = 9407729506014 := by decide
theorem cert_e611636483806 : check e611636483806 [[.under]] .sourceHead = true := by decide
def e611636483830 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e611636483830 : Closed e611636483830 ∧ code e611636483830 = 9407729506038 := by decide
theorem cert_e611636483830 : check e611636483830 [[.under]] .sourceHead = true := by decide
def e611636483934 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e611636483934 : Closed e611636483934 ∧ code e611636483934 = 9407729506142 := by decide
theorem cert_e611636483934 : check e611636483934 [[.under]] .sourceHead = true := by decide
def e611636483962 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e611636483962 : Closed e611636483962 ∧ code e611636483962 = 9407729506170 := by decide
theorem cert_e611636483962 : check e611636483962 [[.under]] .sourceHead = true := by decide
def e611636484054 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e611636484054 : Closed e611636484054 ∧ code e611636484054 = 9407729506262 := by decide
theorem cert_e611636484054 : check e611636484054 [[.under]] .sourceHead = true := by decide
def e611636484058 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e611636484058 : Closed e611636484058 ∧ code e611636484058 = 9407729506266 := by decide
theorem cert_e611636484058 : check e611636484058 [[.under]] .sourceHead = true := by decide
def e611636484574 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e611636484574 : Closed e611636484574 ∧ code e611636484574 = 9407729506782 := by decide
theorem cert_e611636484574 : check e611636484574 [[.under]] .sourceHead = true := by decide
def e611636484598 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e611636484598 : Closed e611636484598 ∧ code e611636484598 = 9407729506806 := by decide
theorem cert_e611636484598 : check e611636484598 [[.under]] .sourceHead = true := by decide
def e611636485342 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e611636485342 : Closed e611636485342 ∧ code e611636485342 = 9407729507550 := by decide
theorem cert_e611636485342 : check e611636485342 [[.under]] .sourceHead = true := by decide
def e611636485370 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e611636485370 : Closed e611636485370 ∧ code e611636485370 = 9407729507578 := by decide
theorem cert_e611636485370 : check e611636485370 [[.under]] .sourceHead = true := by decide
def e611636485942 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e611636485942 : Closed e611636485942 ∧ code e611636485942 = 9407729508150 := by decide
theorem cert_e611636485942 : check e611636485942 [[.under]] .sourceHead = true := by decide
def e611636485946 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e611636485946 : Closed e611636485946 ∧ code e611636485946 = 9407729508154 := by decide
theorem cert_e611636485946 : check e611636485946 [[.under]] .sourceHead = true := by decide
def e611636500718 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e611636500718 : Closed e611636500718 ∧ code e611636500718 = 9407729522926 := by decide
theorem cert_e611636500718 : check e611636500718 [[.under]] .sourceHead = true := by decide
def e611636500726 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e611636500726 : Closed e611636500726 ∧ code e611636500726 = 9407729522934 := by decide
theorem cert_e611636500726 : check e611636500726 [[.under]] .sourceHead = true := by decide
def e611636501278 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e611636501278 : Closed e611636501278 ∧ code e611636501278 = 9407729523486 := by decide
theorem cert_e611636501278 : check e611636501278 [[.under]] .sourceHead = true := by decide
def e611636501390 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e611636501390 : Closed e611636501390 ∧ code e611636501390 = 9407729523598 := by decide
theorem cert_e611636501390 : check e611636501390 [[.under]] .sourceHead = true := by decide
def e611636501614 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e611636501614 : Closed e611636501614 ∧ code e611636501614 = 9407729523822 := by decide
theorem cert_e611636501614 : check e611636501614 [[.under]] .sourceHead = true := by decide
def e611636501626 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e611636501626 : Closed e611636501626 ∧ code e611636501626 = 9407729523834 := by decide
theorem cert_e611636501626 : check e611636501626 [[.under]] .sourceHead = true := by decide
def e611636501790 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e611636501790 : Closed e611636501790 ∧ code e611636501790 = 9407729523998 := by decide
theorem cert_e611636501790 : check e611636501790 [[.under]] .sourceHead = true := by decide
def e611636501958 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e611636501958 : Closed e611636501958 ∧ code e611636501958 = 9407729524166 := by decide
theorem cert_e611636501958 : check e611636501958 [[.under]] .sourceHead = true := by decide
def e611636502070 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e611636502070 : Closed e611636502070 ∧ code e611636502070 = 9407729524278 := by decide
theorem cert_e611636502070 : check e611636502070 [[.under]] .sourceHead = true := by decide
def e611636502074 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e611636502074 : Closed e611636502074 ∧ code e611636502074 = 9407729524282 := by decide
theorem cert_e611636502074 : check e611636502074 [[.under]] .sourceHead = true := by decide
def e611636502158 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e611636502158 : Closed e611636502158 ∧ code e611636502158 = 9407729524366 := by decide
theorem cert_e611636502158 : check e611636502158 [[.under]] .sourceHead = true := by decide
def e611636502214 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e611636502214 : Closed e611636502214 ∧ code e611636502214 = 9407729524422 := by decide
theorem cert_e611636502214 : check e611636502214 [[.under]] .sourceHead = true := by decide
def e611636504350 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e611636504350 : Closed e611636504350 ∧ code e611636504350 = 9407729526558 := by decide
theorem cert_e611636504350 : check e611636504350 [[.under]] .sourceHead = true := by decide
def e611636504462 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e611636504462 : Closed e611636504462 ∧ code e611636504462 = 9407729526670 := by decide
theorem cert_e611636504462 : check e611636504462 [[.under]] .sourceHead = true := by decide
def e611636507422 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e611636507422 : Closed e611636507422 ∧ code e611636507422 = 9407729529630 := by decide
theorem cert_e611636507422 : check e611636507422 [[.under]] .sourceHead = true := by decide
def e611636507590 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e611636507590 : Closed e611636507590 ∧ code e611636507590 = 9407729529798 := by decide
theorem cert_e611636507590 : check e611636507590 [[.under]] .sourceHead = true := by decide
def e611636509070 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e611636509070 : Closed e611636509070 ∧ code e611636509070 = 9407729531278 := by decide
theorem cert_e611636509070 : check e611636509070 [[.under]] .sourceHead = true := by decide
def e611636509126 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e611636509126 : Closed e611636509126 ∧ code e611636509126 = 9407729531334 := by decide
theorem cert_e611636509126 : check e611636509126 [[.under]] .sourceHead = true := by decide
def e690976834330 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690976834330 : Closed e690976834330 ∧ code e690976834330 = 9487069856538 := by decide
theorem cert_e690976834330 : check e690976834330 [[.under,.left]] .width = true := by decide
def e690976899866 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690976899866 : Closed e690976899866 ∧ code e690976899866 = 9487069922074 := by decide
theorem cert_e690976899866 : check e690976899866 [[.under,.left]] .width = true := by decide
def e690977358618 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690977358618 : Closed e690977358618 ∧ code e690977358618 = 9487070380826 := by decide
theorem cert_e690977358618 : check e690977358618 [[.under,.left]] .width = true := by decide
def e690977456922 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690977456922 : Closed e690977456922 ∧ code e690977456922 = 9487070479130 := by decide
theorem cert_e690977456922 : check e690977456922 [[.under,.left]] .width = true := by decide
def e690977686298 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690977686298 : Closed e690977686298 ∧ code e690977686298 = 9487070708506 := by decide
theorem cert_e690977686298 : check e690977686298 [[.under,.left]] .width = true := by decide
def e690977719066 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690977719066 : Closed e690977719066 ∧ code e690977719066 = 9487070741274 := by decide
theorem cert_e690977719066 : check e690977719066 [[.under,.left]] .width = true := by decide
def e690979980058 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690979980058 : Closed e690979980058 ∧ code e690979980058 = 9487073002266 := by decide
theorem cert_e690979980058 : check e690979980058 [[.under,.left]] .width = true := by decide
def e690980045594 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690980045594 : Closed e690980045594 ∧ code e690980045594 = 9487073067802 := by decide
theorem cert_e690980045594 : check e690980045594 [[.under,.left]] .width = true := by decide
def e690983125786 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690983125786 : Closed e690983125786 ∧ code e690983125786 = 9487076147994 := by decide
theorem cert_e690983125786 : check e690983125786 [[.under,.left]] .width = true := by decide
def e690983224090 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690983224090 : Closed e690983224090 ∧ code e690983224090 = 9487076246298 := by decide
theorem cert_e690983224090 : check e690983224090 [[.under,.left]] .width = true := by decide
def e690984764186 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690984764186 : Closed e690984764186 ∧ code e690984764186 = 9487077786394 := by decide
theorem cert_e690984764186 : check e690984764186 [[.under,.left]] .width = true := by decide
def e690984796954 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)))
theorem wire_e690984796954 : Closed e690984796954 ∧ code e690984796954 = 9487077819162 := by decide
theorem cert_e690984796954 : check e690984796954 [[.under,.left]] .width = true := by decide
def e691154367930 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e691154367930 : Closed e691154367930 ∧ code e691154367930 = 9487247390138 := by decide
theorem cert_e691154367930 : check e691154367930 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154367962 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e691154367962 : Closed e691154367962 ∧ code e691154367962 = 9487247390170 := by decide
theorem cert_e691154367962 : check e691154367962 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154368186 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e691154368186 : Closed e691154368186 ∧ code e691154368186 = 9487247390394 := by decide
theorem cert_e691154368186 : check e691154368186 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154368234 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e691154368234 : Closed e691154368234 ∧ code e691154368234 = 9487247390442 := by decide
theorem cert_e691154368234 : check e691154368234 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154368346 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e691154368346 : Closed e691154368346 ∧ code e691154368346 = 9487247390554 := by decide
theorem cert_e691154368346 : check e691154368346 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154368362 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e691154368362 : Closed e691154368362 ∧ code e691154368362 = 9487247390570 := by decide
theorem cert_e691154368362 : check e691154368362 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154369210 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e691154369210 : Closed e691154369210 ∧ code e691154369210 = 9487247391418 := by decide
theorem cert_e691154369210 : check e691154369210 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154369258 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e691154369258 : Closed e691154369258 ∧ code e691154369258 = 9487247391466 := by decide
theorem cert_e691154369258 : check e691154369258 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154369450 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e691154369450 : Closed e691154369450 ∧ code e691154369450 = 9487247391658 := by decide
theorem cert_e691154369450 : check e691154369450 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154369882 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e691154369882 : Closed e691154369882 ∧ code e691154369882 = 9487247392090 := by decide
theorem cert_e691154369882 : check e691154369882 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154369898 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e691154369898 : Closed e691154369898 ∧ code e691154369898 = 9487247392106 := by decide
theorem cert_e691154369898 : check e691154369898 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154369962 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e691154369962 : Closed e691154369962 ∧ code e691154369962 = 9487247392170 := by decide
theorem cert_e691154369962 : check e691154369962 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154374074 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e691154374074 : Closed e691154374074 ∧ code e691154374074 = 9487247396282 := by decide
theorem cert_e691154374074 : check e691154374074 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154374106 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e691154374106 : Closed e691154374106 ∧ code e691154374106 = 9487247396314 := by decide
theorem cert_e691154374106 : check e691154374106 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154374330 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e691154374330 : Closed e691154374330 ∧ code e691154374330 = 9487247396538 := by decide
theorem cert_e691154374330 : check e691154374330 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154374378 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e691154374378 : Closed e691154374378 ∧ code e691154374378 = 9487247396586 := by decide
theorem cert_e691154374378 : check e691154374378 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154374490 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e691154374490 : Closed e691154374490 ∧ code e691154374490 = 9487247396698 := by decide
theorem cert_e691154374490 : check e691154374490 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154374506 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e691154374506 : Closed e691154374506 ∧ code e691154374506 = 9487247396714 := by decide
theorem cert_e691154374506 : check e691154374506 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154375610 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e691154375610 : Closed e691154375610 ∧ code e691154375610 = 9487247397818 := by decide
theorem cert_e691154375610 : check e691154375610 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154375642 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e691154375642 : Closed e691154375642 ∧ code e691154375642 = 9487247397850 := by decide
theorem cert_e691154375642 : check e691154375642 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154377146 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e691154377146 : Closed e691154377146 ∧ code e691154377146 = 9487247399354 := by decide
theorem cert_e691154377146 : check e691154377146 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154377194 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e691154377194 : Closed e691154377194 ∧ code e691154377194 = 9487247399402 := by decide
theorem cert_e691154377194 : check e691154377194 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154377946 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e691154377946 : Closed e691154377946 ∧ code e691154377946 = 9487247400154 := by decide
theorem cert_e691154377946 : check e691154377946 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154377962 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e691154377962 : Closed e691154377962 ∧ code e691154377962 = 9487247400170 := by decide
theorem cert_e691154377962 : check e691154377962 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154380474 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e691154380474 : Closed e691154380474 ∧ code e691154380474 = 9487247402682 := by decide
theorem cert_e691154380474 : check e691154380474 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154380522 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e691154380522 : Closed e691154380522 ∧ code e691154380522 = 9487247402730 := by decide
theorem cert_e691154380522 : check e691154380522 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154380714 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e691154380714 : Closed e691154380714 ∧ code e691154380714 = 9487247402922 := by decide
theorem cert_e691154380714 : check e691154380714 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154381242 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e691154381242 : Closed e691154381242 ∧ code e691154381242 = 9487247403450 := by decide
theorem cert_e691154381242 : check e691154381242 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154381290 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e691154381290 : Closed e691154381290 ∧ code e691154381290 = 9487247403498 := by decide
theorem cert_e691154381290 : check e691154381290 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154382442 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e691154382442 : Closed e691154382442 ∧ code e691154382442 = 9487247404650 := by decide
theorem cert_e691154382442 : check e691154382442 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154383706 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e691154383706 : Closed e691154383706 ∧ code e691154383706 = 9487247405914 := by decide
theorem cert_e691154383706 : check e691154383706 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154383722 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e691154383722 : Closed e691154383722 ∧ code e691154383722 = 9487247405930 := by decide
theorem cert_e691154383722 : check e691154383722 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154383786 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e691154383786 : Closed e691154383786 ∧ code e691154383786 = 9487247405994 := by decide
theorem cert_e691154383786 : check e691154383786 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154384090 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e691154384090 : Closed e691154384090 ∧ code e691154384090 = 9487247406298 := by decide
theorem cert_e691154384090 : check e691154384090 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154384106 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e691154384106 : Closed e691154384106 ∧ code e691154384106 = 9487247406314 := by decide
theorem cert_e691154384106 : check e691154384106 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154384490 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e691154384490 : Closed e691154384490 ∧ code e691154384490 = 9487247406698 := by decide
theorem cert_e691154384490 : check e691154384490 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154398650 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e691154398650 : Closed e691154398650 ∧ code e691154398650 = 9487247420858 := by decide
theorem cert_e691154398650 : check e691154398650 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154398682 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e691154398682 : Closed e691154398682 ∧ code e691154398682 = 9487247420890 := by decide
theorem cert_e691154398682 : check e691154398682 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154398906 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e691154398906 : Closed e691154398906 ∧ code e691154398906 = 9487247421114 := by decide
theorem cert_e691154398906 : check e691154398906 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154398954 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e691154398954 : Closed e691154398954 ∧ code e691154398954 = 9487247421162 := by decide
theorem cert_e691154398954 : check e691154398954 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154399066 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e691154399066 : Closed e691154399066 ∧ code e691154399066 = 9487247421274 := by decide
theorem cert_e691154399066 : check e691154399066 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154399082 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e691154399082 : Closed e691154399082 ∧ code e691154399082 = 9487247421290 := by decide
theorem cert_e691154399082 : check e691154399082 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154400186 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e691154400186 : Closed e691154400186 ∧ code e691154400186 = 9487247422394 := by decide
theorem cert_e691154400186 : check e691154400186 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154400218 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e691154400218 : Closed e691154400218 ∧ code e691154400218 = 9487247422426 := by decide
theorem cert_e691154400218 : check e691154400218 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154401722 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e691154401722 : Closed e691154401722 ∧ code e691154401722 = 9487247423930 := by decide
theorem cert_e691154401722 : check e691154401722 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154401770 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e691154401770 : Closed e691154401770 ∧ code e691154401770 = 9487247423978 := by decide
theorem cert_e691154401770 : check e691154401770 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154402522 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e691154402522 : Closed e691154402522 ∧ code e691154402522 = 9487247424730 := by decide
theorem cert_e691154402522 : check e691154402522 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154402538 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e691154402538 : Closed e691154402538 ∧ code e691154402538 = 9487247424746 := by decide
theorem cert_e691154402538 : check e691154402538 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154425530 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e691154425530 : Closed e691154425530 ∧ code e691154425530 = 9487247447738 := by decide
theorem cert_e691154425530 : check e691154425530 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154425578 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e691154425578 : Closed e691154425578 ∧ code e691154425578 = 9487247447786 := by decide
theorem cert_e691154425578 : check e691154425578 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154425770 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e691154425770 : Closed e691154425770 ∧ code e691154425770 = 9487247447978 := by decide
theorem cert_e691154425770 : check e691154425770 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154426298 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e691154426298 : Closed e691154426298 ∧ code e691154426298 = 9487247448506 := by decide
theorem cert_e691154426298 : check e691154426298 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154426346 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e691154426346 : Closed e691154426346 ∧ code e691154426346 = 9487247448554 := by decide
theorem cert_e691154426346 : check e691154426346 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154427498 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e691154427498 : Closed e691154427498 ∧ code e691154427498 = 9487247449706 := by decide
theorem cert_e691154427498 : check e691154427498 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154439002 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e691154439002 : Closed e691154439002 ∧ code e691154439002 = 9487247461210 := by decide
theorem cert_e691154439002 : check e691154439002 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154439018 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e691154439018 : Closed e691154439018 ∧ code e691154439018 = 9487247461226 := by decide
theorem cert_e691154439018 : check e691154439018 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154439082 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e691154439082 : Closed e691154439082 ∧ code e691154439082 = 9487247461290 := by decide
theorem cert_e691154439082 : check e691154439082 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154439386 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e691154439386 : Closed e691154439386 ∧ code e691154439386 = 9487247461594 := by decide
theorem cert_e691154439386 : check e691154439386 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154439402 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e691154439402 : Closed e691154439402 ∧ code e691154439402 = 9487247461610 := by decide
theorem cert_e691154439402 : check e691154439402 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154439786 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e691154439786 : Closed e691154439786 ∧ code e691154439786 = 9487247461994 := by decide
theorem cert_e691154439786 : check e691154439786 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154988474 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e691154988474 : Closed e691154988474 ∧ code e691154988474 = 9487248010682 := by decide
theorem cert_e691154988474 : check e691154988474 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154988506 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e691154988506 : Closed e691154988506 ∧ code e691154988506 = 9487248010714 := by decide
theorem cert_e691154988506 : check e691154988506 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154988730 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e691154988730 : Closed e691154988730 ∧ code e691154988730 = 9487248010938 := by decide
theorem cert_e691154988730 : check e691154988730 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154988778 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e691154988778 : Closed e691154988778 ∧ code e691154988778 = 9487248010986 := by decide
theorem cert_e691154988778 : check e691154988778 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154988890 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e691154988890 : Closed e691154988890 ∧ code e691154988890 = 9487248011098 := by decide
theorem cert_e691154988890 : check e691154988890 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154988906 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e691154988906 : Closed e691154988906 ∧ code e691154988906 = 9487248011114 := by decide
theorem cert_e691154988906 : check e691154988906 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154990010 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e691154990010 : Closed e691154990010 ∧ code e691154990010 = 9487248012218 := by decide
theorem cert_e691154990010 : check e691154990010 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154990042 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e691154990042 : Closed e691154990042 ∧ code e691154990042 = 9487248012250 := by decide
theorem cert_e691154990042 : check e691154990042 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154991546 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e691154991546 : Closed e691154991546 ∧ code e691154991546 = 9487248013754 := by decide
theorem cert_e691154991546 : check e691154991546 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154991594 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e691154991594 : Closed e691154991594 ∧ code e691154991594 = 9487248013802 := by decide
theorem cert_e691154991594 : check e691154991594 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154992346 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e691154992346 : Closed e691154992346 ∧ code e691154992346 = 9487248014554 := by decide
theorem cert_e691154992346 : check e691154992346 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691154992362 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e691154992362 : Closed e691154992362 ∧ code e691154992362 = 9487248014570 := by decide
theorem cert_e691154992362 : check e691154992362 [[.under,.left],[.under],[.under]] .smaller = true := by decide
def e691157347770 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e691157347770 : Closed e691157347770 ∧ code e691157347770 = 9487250369978 := by decide
theorem cert_e691157347770 : check e691157347770 [[.left],[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e691157347802 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e691157347802 : Closed e691157347802 ∧ code e691157347802 = 9487250370010 := by decide
theorem cert_e691157347802 : check e691157347802 [[.left],[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e691157348026 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e691157348026 : Closed e691157348026 ∧ code e691157348026 = 9487250370234 := by decide
theorem cert_e691157348026 : check e691157348026 [[.left],[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e691157348074 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e691157348074 : Closed e691157348074 ∧ code e691157348074 = 9487250370282 := by decide
private def t_e691157348074 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem cert_e691157348074 : ¬ IsSelfInterpreter e691157348074 :=
  wSource (t := t_e691157348074) (replay_sound (ps := []) (t := e691157348074) (by decide)) (by decide)
def e691157348186 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e691157348186 : Closed e691157348186 ∧ code e691157348186 = 9487250370394 := by decide
theorem cert_e691157348186 : check e691157348186 [[.under,.left],[.under],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e691157348202 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e691157348202 : Closed e691157348202 ∧ code e691157348202 = 9487250370410 := by decide
private def t_e691157348202 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem cert_e691157348202 : ¬ IsSelfInterpreter e691157348202 :=
  wSource (t := t_e691157348202) (replay_sound (ps := []) (t := e691157348202) (by decide)) (by decide)
def e691157349306 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e691157349306 : Closed e691157349306 ∧ code e691157349306 = 9487250371514 := by decide
theorem cert_e691157349306 : check e691157349306 [[.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[]] .identityHead = true := by decide
def e691157349338 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e691157349338 : Closed e691157349338 ∧ code e691157349338 = 9487250371546 := by decide
theorem cert_e691157349338 : check e691157349338 [[.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e691157350842 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e691157350842 : Closed e691157350842 ∧ code e691157350842 = 9487250373050 := by decide
theorem cert_e691157350842 : check e691157350842 [[.under,.left],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e691157350890 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e691157350890 : Closed e691157350890 ∧ code e691157350890 = 9487250373098 := by decide
theorem cert_e691157350890 : check e691157350890 [[.under,.left],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e691157351642 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e691157351642 : Closed e691157351642 ∧ code e691157351642 = 9487250373850 := by decide
def e691157351658 : Term := (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e691157351658 : Closed e691157351658 ∧ code e691157351658 = 9487250373866 := by decide
theorem cert_e691157351658 : check e691157351658 [[.under,.left],[.under],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e699017914474 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699017914474 : Closed e699017914474 ∧ code e699017914474 = 9495110936682 := by decide
theorem cert_e699017914474 : check e699017914474 [[.under,.left]] .width = true := by decide
def e699017947242 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699017947242 : Closed e699017947242 ∧ code e699017947242 = 9495110969450 := by decide
theorem cert_e699017947242 : check e699017947242 [[.under,.left]] .width = true := by decide
def e699018176618 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699018176618 : Closed e699018176618 ∧ code e699018176618 = 9495111198826 := by decide
theorem cert_e699018176618 : check e699018176618 [[.under,.left]] .width = true := by decide
def e699018225770 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699018225770 : Closed e699018225770 ∧ code e699018225770 = 9495111247978 := by decide
private def t_e699018225770 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699018225770 : ¬ IsSelfInterpreter e699018225770 :=
  wSource (t := t_e699018225770) (replay_sound (ps := []) (t := e699018225770) (by decide)) (by decide)
def e699018340458 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699018340458 : Closed e699018340458 ∧ code e699018340458 = 9495111362666 := by decide
theorem cert_e699018340458 : check e699018340458 [[.under,.left]] .width = true := by decide
def e699018356842 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699018356842 : Closed e699018356842 ∧ code e699018356842 = 9495111379050 := by decide
private def t_e699018356842 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699018356842 : ¬ IsSelfInterpreter e699018356842 :=
  wSource (t := t_e699018356842) (replay_sound (ps := []) (t := e699018356842) (by decide)) (by decide)
def e699019487338 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699019487338 : Closed e699019487338 ∧ code e699019487338 = 9495112509546 := by decide
theorem cert_e699019487338 : check e699019487338 [[.under,.left]] .width = true := by decide
def e699019520106 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699019520106 : Closed e699019520106 ∧ code e699019520106 = 9495112542314 := by decide
theorem cert_e699019520106 : check e699019520106 [[.under,.left]] .width = true := by decide
def e699021060202 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699021060202 : Closed e699021060202 ∧ code e699021060202 = 9495114082410 := by decide
theorem cert_e699021060202 : check e699021060202 [[.under,.left]] .width = true := by decide
def e699021109354 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699021109354 : Closed e699021109354 ∧ code e699021109354 = 9495114131562 := by decide
theorem cert_e699021109354 : check e699021109354 [[.under,.left]] .width = true := by decide
def e699021879402 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699021879402 : Closed e699021879402 ∧ code e699021879402 = 9495114901610 := by decide
theorem cert_e699021879402 : check e699021879402 [[.under,.left]] .width = true := by decide
def e699021895786 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699021895786 : Closed e699021895786 ∧ code e699021895786 = 9495114917994 := by decide
theorem cert_e699021895786 : check e699021895786 [[.under,.left]] .width = true := by decide
def e699277359210 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699277359210 : Closed e699277359210 ∧ code e699277359210 = 9495370381418 := by decide
private def t_e699277359210 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699277359210 : ¬ IsSelfInterpreter e699277359210 :=
  wSource (t := t_e699277359210) (replay_sound (ps := []) (t := e699277359210) (by decide)) (by decide)
def e699277367402 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699277367402 : Closed e699277367402 ∧ code e699277367402 = 9495370389610 := by decide
private def t_e699277367402 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699277367402 : ¬ IsSelfInterpreter e699277367402 :=
  wSource (t := t_e699277367402) (replay_sound (ps := []) (t := e699277367402) (by decide)) (by decide)
def e699277424746 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699277424746 : Closed e699277424746 ∧ code e699277424746 = 9495370446954 := by decide
private def t_e699277424746 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699277424746 : ¬ IsSelfInterpreter e699277424746 :=
  wSource (t := t_e699277424746) (replay_sound (ps := []) (t := e699277424746) (by decide)) (by decide)
def e699277437034 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699277437034 : Closed e699277437034 ∧ code e699277437034 = 9495370459242 := by decide
private def t_e699277437034 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699277437034 : ¬ IsSelfInterpreter e699277437034 :=
  wSource (t := t_e699277437034) (replay_sound (ps := []) (t := e699277437034) (by decide)) (by decide)
def e699277465706 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699277465706 : Closed e699277465706 ∧ code e699277465706 = 9495370487914 := by decide
private def t_e699277465706 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699277465706 : ¬ IsSelfInterpreter e699277465706 :=
  wSource (t := t_e699277465706) (replay_sound (ps := []) (t := e699277465706) (by decide)) (by decide)
def e699277469802 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699277469802 : Closed e699277469802 ∧ code e699277469802 = 9495370492010 := by decide
private def t_e699277469802 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699277469802 : ¬ IsSelfInterpreter e699277469802 :=
  wSource (t := t_e699277469802) (replay_sound (ps := []) (t := e699277469802) (by decide)) (by decide)
def e699277752426 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699277752426 : Closed e699277752426 ∧ code e699277752426 = 9495370774634 := by decide
private def t_e699277752426 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699277752426 : ¬ IsSelfInterpreter e699277752426 :=
  wSource (t := t_e699277752426) (replay_sound (ps := []) (t := e699277752426) (by decide)) (by decide)
def e699277760618 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699277760618 : Closed e699277760618 ∧ code e699277760618 = 9495370782826 := by decide
private def t_e699277760618 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699277760618 : ¬ IsSelfInterpreter e699277760618 :=
  wSource (t := t_e699277760618) (replay_sound (ps := []) (t := e699277760618) (by decide)) (by decide)
def e699278145642 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699278145642 : Closed e699278145642 ∧ code e699278145642 = 9495371167850 := by decide
private def t_e699278145642 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699278145642 : ¬ IsSelfInterpreter e699278145642 :=
  wSource (t := t_e699278145642) (replay_sound (ps := []) (t := e699278145642) (by decide)) (by decide)
def e699278157930 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699278157930 : Closed e699278157930 ∧ code e699278157930 = 9495371180138 := by decide
private def t_e699278157930 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699278157930 : ¬ IsSelfInterpreter e699278157930 :=
  wSource (t := t_e699278157930) (replay_sound (ps := []) (t := e699278157930) (by decide)) (by decide)
def e699278350442 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699278350442 : Closed e699278350442 ∧ code e699278350442 = 9495371372650 := by decide
private def t_e699278350442 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699278350442 : ¬ IsSelfInterpreter e699278350442 :=
  wSource (t := t_e699278350442) (replay_sound (ps := []) (t := e699278350442) (by decide)) (by decide)
def e699278354538 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e699278354538 : Closed e699278354538 ∧ code e699278354538 = 9495371376746 := by decide
private def t_e699278354538 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem cert_e699278354538 : ¬ IsSelfInterpreter e699278354538 :=
  wSource (t := t_e699278354538) (replay_sound (ps := []) (t := e699278354538) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e691157348074
#print axioms Blc.Floor43.cert_e691157348202
#print axioms Blc.Floor43.cert_e699018225770
#print axioms Blc.Floor43.cert_e699018356842
#print axioms Blc.Floor43.cert_e699277359210
#print axioms Blc.Floor43.cert_e699277367402
#print axioms Blc.Floor43.cert_e699277424746
#print axioms Blc.Floor43.cert_e699277437034
#print axioms Blc.Floor43.cert_e699277465706
#print axioms Blc.Floor43.cert_e699277469802
#print axioms Blc.Floor43.cert_e699277752426
#print axioms Blc.Floor43.cert_e699277760618
#print axioms Blc.Floor43.cert_e699278145642
#print axioms Blc.Floor43.cert_e699278157930
#print axioms Blc.Floor43.cert_e699278350442
#print axioms Blc.Floor43.cert_e699278354538
