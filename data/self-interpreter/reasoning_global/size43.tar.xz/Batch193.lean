import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2388337405786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2388337405786 : Closed e2388337405786 ∧ code e2388337405786 = 11184430427994 := by decide
theorem cert_e2388337405786 : check e2388337405786 [[],[.left],[]] .smaller = true := by decide
def e2388337405802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2388337405802 : Closed e2388337405802 ∧ code e2388337405802 = 11184430428010 := by decide
theorem cert_e2388337405802 : check e2388337405802 [[],[.left],[]] .smaller = true := by decide
def e2388337406830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2388337406830 : Closed e2388337406830 ∧ code e2388337406830 = 11184430429038 := by decide
theorem cert_e2388337406830 : check e2388337406830 [[],[.left],[]] .smaller = true := by decide
def e2388337406838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2388337406838 : Closed e2388337406838 ∧ code e2388337406838 = 11184430429046 := by decide
theorem cert_e2388337406838 : check e2388337406838 [[],[.left],[]] .smaller = true := by decide
def e2388337406894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2388337406894 : Closed e2388337406894 ∧ code e2388337406894 = 11184430429102 := by decide
theorem cert_e2388337406894 : check e2388337406894 [[],[.left],[]] .smaller = true := by decide
def e2388337406906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2388337406906 : Closed e2388337406906 ∧ code e2388337406906 = 11184430429114 := by decide
theorem cert_e2388337406906 : check e2388337406906 [[],[.left],[]] .smaller = true := by decide
def e2388337406934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2388337406934 : Closed e2388337406934 ∧ code e2388337406934 = 11184430429142 := by decide
theorem cert_e2388337406934 : check e2388337406934 [[],[.left],[]] .smaller = true := by decide
def e2388337406938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2388337406938 : Closed e2388337406938 ∧ code e2388337406938 = 11184430429146 := by decide
theorem cert_e2388337406938 : check e2388337406938 [[],[.left],[]] .smaller = true := by decide
def e2388337407214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2388337407214 : Closed e2388337407214 ∧ code e2388337407214 = 11184430429422 := by decide
theorem cert_e2388337407214 : check e2388337407214 [[],[.left],[]] .smaller = true := by decide
def e2388337407222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2388337407222 : Closed e2388337407222 ∧ code e2388337407222 = 11184430429430 := by decide
theorem cert_e2388337407222 : check e2388337407222 [[],[.left],[]] .smaller = true := by decide
def e2388337407598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2388337407598 : Closed e2388337407598 ∧ code e2388337407598 = 11184430429806 := by decide
theorem cert_e2388337407598 : check e2388337407598 [[],[.left],[]] .smaller = true := by decide
def e2388337407610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2388337407610 : Closed e2388337407610 ∧ code e2388337407610 = 11184430429818 := by decide
theorem cert_e2388337407610 : check e2388337407610 [[],[.left],[]] .smaller = true := by decide
def e2388337407798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2388337407798 : Closed e2388337407798 ∧ code e2388337407798 = 11184430430006 := by decide
theorem cert_e2388337407798 : check e2388337407798 [[],[.left],[]] .smaller = true := by decide
def e2388337407802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2388337407802 : Closed e2388337407802 ∧ code e2388337407802 = 11184430430010 := by decide
theorem cert_e2388337407802 : check e2388337407802 [[],[.left],[]] .smaller = true := by decide
def e2388337408430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2388337408430 : Closed e2388337408430 ∧ code e2388337408430 = 11184430430638 := by decide
theorem cert_e2388337408430 : check e2388337408430 [[],[.left],[]] .smaller = true := by decide
def e2388337408442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2388337408442 : Closed e2388337408442 ∧ code e2388337408442 = 11184430430650 := by decide
theorem cert_e2388337408442 : check e2388337408442 [[],[.left],[]] .smaller = true := by decide
def e2388337408490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2388337408490 : Closed e2388337408490 ∧ code e2388337408490 = 11184430430698 := by decide
theorem cert_e2388337408490 : check e2388337408490 [[],[.left],[]] .smaller = true := by decide
def e2388337408622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2388337408622 : Closed e2388337408622 ∧ code e2388337408622 = 11184430430830 := by decide
theorem cert_e2388337408622 : check e2388337408622 [[],[.left],[]] .smaller = true := by decide
def e2388337408634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2388337408634 : Closed e2388337408634 ∧ code e2388337408634 = 11184430430842 := by decide
theorem cert_e2388337408634 : check e2388337408634 [[],[.left],[]] .smaller = true := by decide
def e2388337408922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2388337408922 : Closed e2388337408922 ∧ code e2388337408922 = 11184430431130 := by decide
theorem cert_e2388337408922 : check e2388337408922 [[],[.left],[]] .smaller = true := by decide
def e2388337409238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2388337409238 : Closed e2388337409238 ∧ code e2388337409238 = 11184430431446 := by decide
theorem cert_e2388337409238 : check e2388337409238 [[],[.left],[]] .smaller = true := by decide
def e2388337409242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2388337409242 : Closed e2388337409242 ∧ code e2388337409242 = 11184430431450 := by decide
theorem cert_e2388337409242 : check e2388337409242 [[],[.left],[]] .smaller = true := by decide
def e2388337409258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2388337409258 : Closed e2388337409258 ∧ code e2388337409258 = 11184430431466 := by decide
theorem cert_e2388337409258 : check e2388337409258 [[],[.left],[]] .smaller = true := by decide
def e2388337409334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2388337409334 : Closed e2388337409334 ∧ code e2388337409334 = 11184430431542 := by decide
theorem cert_e2388337409334 : check e2388337409334 [[],[.left],[]] .smaller = true := by decide
def e2388337409338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2388337409338 : Closed e2388337409338 ∧ code e2388337409338 = 11184430431546 := by decide
theorem cert_e2388337409338 : check e2388337409338 [[],[.left],[]] .smaller = true := by decide
def e2388337409434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2388337409434 : Closed e2388337409434 ∧ code e2388337409434 = 11184430431642 := by decide
theorem cert_e2388337409434 : check e2388337409434 [[],[.left],[]] .smaller = true := by decide
def e2388337412974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2388337412974 : Closed e2388337412974 ∧ code e2388337412974 = 11184430435182 := by decide
theorem cert_e2388337412974 : check e2388337412974 [[],[.left],[]] .smaller = true := by decide
def e2388337412982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2388337412982 : Closed e2388337412982 ∧ code e2388337412982 = 11184430435190 := by decide
theorem cert_e2388337412982 : check e2388337412982 [[],[.left],[]] .smaller = true := by decide
def e2388337413038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2388337413038 : Closed e2388337413038 ∧ code e2388337413038 = 11184430435246 := by decide
theorem cert_e2388337413038 : check e2388337413038 [[],[.left],[]] .smaller = true := by decide
def e2388337413050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2388337413050 : Closed e2388337413050 ∧ code e2388337413050 = 11184430435258 := by decide
theorem cert_e2388337413050 : check e2388337413050 [[],[.left],[]] .smaller = true := by decide
def e2388337413078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2388337413078 : Closed e2388337413078 ∧ code e2388337413078 = 11184430435286 := by decide
theorem cert_e2388337413078 : check e2388337413078 [[],[.left],[]] .smaller = true := by decide
def e2388337413082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2388337413082 : Closed e2388337413082 ∧ code e2388337413082 = 11184430435290 := by decide
theorem cert_e2388337413082 : check e2388337413082 [[],[.left],[]] .smaller = true := by decide
def e2388337413358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2388337413358 : Closed e2388337413358 ∧ code e2388337413358 = 11184430435566 := by decide
theorem cert_e2388337413358 : check e2388337413358 [[],[.left],[]] .smaller = true := by decide
def e2388337413366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2388337413366 : Closed e2388337413366 ∧ code e2388337413366 = 11184430435574 := by decide
theorem cert_e2388337413366 : check e2388337413366 [[],[.left],[]] .smaller = true := by decide
def e2388337413742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2388337413742 : Closed e2388337413742 ∧ code e2388337413742 = 11184430435950 := by decide
theorem cert_e2388337413742 : check e2388337413742 [[],[.left],[]] .smaller = true := by decide
def e2388337413754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2388337413754 : Closed e2388337413754 ∧ code e2388337413754 = 11184430435962 := by decide
theorem cert_e2388337413754 : check e2388337413754 [[],[.left],[]] .smaller = true := by decide
def e2388337413942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2388337413942 : Closed e2388337413942 ∧ code e2388337413942 = 11184430436150 := by decide
theorem cert_e2388337413942 : check e2388337413942 [[],[.left],[]] .smaller = true := by decide
def e2388337413946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2388337413946 : Closed e2388337413946 ∧ code e2388337413946 = 11184430436154 := by decide
theorem cert_e2388337413946 : check e2388337413946 [[],[.left],[]] .smaller = true := by decide
def e2388337419694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2388337419694 : Closed e2388337419694 ∧ code e2388337419694 = 11184430441902 := by decide
theorem cert_e2388337419694 : check e2388337419694 [[],[.left],[]] .smaller = true := by decide
def e2388337419706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2388337419706 : Closed e2388337419706 ∧ code e2388337419706 = 11184430441914 := by decide
theorem cert_e2388337419706 : check e2388337419706 [[],[.left],[]] .smaller = true := by decide
def e2388337419754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2388337419754 : Closed e2388337419754 ∧ code e2388337419754 = 11184430441962 := by decide
theorem cert_e2388337419754 : check e2388337419754 [[],[.left],[]] .smaller = true := by decide
def e2388337419886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2388337419886 : Closed e2388337419886 ∧ code e2388337419886 = 11184430442094 := by decide
theorem cert_e2388337419886 : check e2388337419886 [[],[.left],[]] .smaller = true := by decide
def e2388337419898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2388337419898 : Closed e2388337419898 ∧ code e2388337419898 = 11184430442106 := by decide
theorem cert_e2388337419898 : check e2388337419898 [[],[.left],[]] .smaller = true := by decide
def e2388337420186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2388337420186 : Closed e2388337420186 ∧ code e2388337420186 = 11184430442394 := by decide
theorem cert_e2388337420186 : check e2388337420186 [[],[.left],[]] .smaller = true := by decide
def e2388337423062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2388337423062 : Closed e2388337423062 ∧ code e2388337423062 = 11184430445270 := by decide
theorem cert_e2388337423062 : check e2388337423062 [[],[.left],[]] .smaller = true := by decide
def e2388337423066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2388337423066 : Closed e2388337423066 ∧ code e2388337423066 = 11184430445274 := by decide
theorem cert_e2388337423066 : check e2388337423066 [[],[.left],[]] .smaller = true := by decide
def e2388337423082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2388337423082 : Closed e2388337423082 ∧ code e2388337423082 = 11184430445290 := by decide
theorem cert_e2388337423082 : check e2388337423082 [[],[.left],[]] .smaller = true := by decide
def e2388337423158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2388337423158 : Closed e2388337423158 ∧ code e2388337423158 = 11184430445366 := by decide
theorem cert_e2388337423158 : check e2388337423158 [[],[.left],[]] .smaller = true := by decide
def e2388337423162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2388337423162 : Closed e2388337423162 ∧ code e2388337423162 = 11184430445370 := by decide
theorem cert_e2388337423162 : check e2388337423162 [[],[.left],[]] .smaller = true := by decide
def e2388337423258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2388337423258 : Closed e2388337423258 ∧ code e2388337423258 = 11184430445466 := by decide
theorem cert_e2388337423258 : check e2388337423258 [[],[.left],[]] .smaller = true := by decide
def e2388337538798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2388337538798 : Closed e2388337538798 ∧ code e2388337538798 = 11184430561006 := by decide
theorem cert_e2388337538798 : check e2388337538798 [[],[.left]] .chain = true := by decide
def e2388337538926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2388337538926 : Closed e2388337538926 ∧ code e2388337538926 = 11184430561134 := by decide
theorem cert_e2388337538926 : check e2388337538926 [[],[.left]] .chain = true := by decide
def e2388337538934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2388337538934 : Closed e2388337538934 ∧ code e2388337538934 = 11184430561142 := by decide
theorem cert_e2388337538934 : check e2388337538934 [[],[.left]] .chain = true := by decide
def e2388337539822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2388337539822 : Closed e2388337539822 ∧ code e2388337539822 = 11184430562030 := by decide
theorem cert_e2388337539822 : check e2388337539822 [[],[.left]] .chain = true := by decide
def e2388337540014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2388337540014 : Closed e2388337540014 ∧ code e2388337540014 = 11184430562222 := by decide
theorem cert_e2388337540014 : check e2388337540014 [[],[.left]] .chain = true := by decide
def e2388337540026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2388337540026 : Closed e2388337540026 ∧ code e2388337540026 = 11184430562234 := by decide
theorem cert_e2388337540026 : check e2388337540026 [[],[.left]] .chain = true := by decide
def e2388337540462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2388337540462 : Closed e2388337540462 ∧ code e2388337540462 = 11184430562670 := by decide
theorem cert_e2388337540462 : check e2388337540462 [[],[.left]] .chain = true := by decide
def e2388337540470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2388337540470 : Closed e2388337540470 ∧ code e2388337540470 = 11184430562678 := by decide
theorem cert_e2388337540470 : check e2388337540470 [[],[.left]] .chain = true := by decide
def e2388337540526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2388337540526 : Closed e2388337540526 ∧ code e2388337540526 = 11184430562734 := by decide
theorem cert_e2388337540526 : check e2388337540526 [[],[.left]] .chain = true := by decide
def e2388337540538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2388337540538 : Closed e2388337540538 ∧ code e2388337540538 = 11184430562746 := by decide
theorem cert_e2388337540538 : check e2388337540538 [[],[.left]] .chain = true := by decide
def e2388337540566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2388337540566 : Closed e2388337540566 ∧ code e2388337540566 = 11184430562774 := by decide
theorem cert_e2388337540566 : check e2388337540566 [[],[.left]] .chain = true := by decide
def e2388337540570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2388337540570 : Closed e2388337540570 ∧ code e2388337540570 = 11184430562778 := by decide
theorem cert_e2388337540570 : check e2388337540570 [[],[.left]] .chain = true := by decide
def e2388337544942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2388337544942 : Closed e2388337544942 ∧ code e2388337544942 = 11184430567150 := by decide
theorem cert_e2388337544942 : check e2388337544942 [[],[.left]] .chain = true := by decide
def e2388337545070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2388337545070 : Closed e2388337545070 ∧ code e2388337545070 = 11184430567278 := by decide
theorem cert_e2388337545070 : check e2388337545070 [[],[.left]] .chain = true := by decide
def e2388337545078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2388337545078 : Closed e2388337545078 ∧ code e2388337545078 = 11184430567286 := by decide
theorem cert_e2388337545078 : check e2388337545078 [[],[.left]] .chain = true := by decide
def e2388337547758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2388337547758 : Closed e2388337547758 ∧ code e2388337547758 = 11184430569966 := by decide
theorem cert_e2388337547758 : check e2388337547758 [[],[.left]] .chain = true := by decide
def e2388337548526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2388337548526 : Closed e2388337548526 ∧ code e2388337548526 = 11184430570734 := by decide
theorem cert_e2388337548526 : check e2388337548526 [[],[.left]] .chain = true := by decide
def e2388337548534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2388337548534 : Closed e2388337548534 ∧ code e2388337548534 = 11184430570742 := by decide
theorem cert_e2388337548534 : check e2388337548534 [[],[.left]] .chain = true := by decide
def e2388337551086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2388337551086 : Closed e2388337551086 ∧ code e2388337551086 = 11184430573294 := by decide
theorem cert_e2388337551086 : check e2388337551086 [[],[.left]] .chain = true := by decide
def e2388337551278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2388337551278 : Closed e2388337551278 ∧ code e2388337551278 = 11184430573486 := by decide
theorem cert_e2388337551278 : check e2388337551278 [[],[.left]] .chain = true := by decide
def e2388337551290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2388337551290 : Closed e2388337551290 ∧ code e2388337551290 = 11184430573498 := by decide
theorem cert_e2388337551290 : check e2388337551290 [[],[.left]] .chain = true := by decide
def e2388337551854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2388337551854 : Closed e2388337551854 ∧ code e2388337551854 = 11184430574062 := by decide
theorem cert_e2388337551854 : check e2388337551854 [[],[.left]] .chain = true := by decide
def e2388337553006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2388337553006 : Closed e2388337553006 ∧ code e2388337553006 = 11184430575214 := by decide
theorem cert_e2388337553006 : check e2388337553006 [[],[.left]] .chain = true := by decide
def e2388337553018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2388337553018 : Closed e2388337553018 ∧ code e2388337553018 = 11184430575226 := by decide
theorem cert_e2388337553018 : check e2388337553018 [[],[.left]] .chain = true := by decide
def e2388337554286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2388337554286 : Closed e2388337554286 ∧ code e2388337554286 = 11184430576494 := by decide
theorem cert_e2388337554286 : check e2388337554286 [[],[.left]] .chain = true := by decide
def e2388337554294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2388337554294 : Closed e2388337554294 ∧ code e2388337554294 = 11184430576502 := by decide
theorem cert_e2388337554294 : check e2388337554294 [[],[.left]] .chain = true := by decide
def e2388337554350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2388337554350 : Closed e2388337554350 ∧ code e2388337554350 = 11184430576558 := by decide
theorem cert_e2388337554350 : check e2388337554350 [[],[.left]] .chain = true := by decide
def e2388337554362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2388337554362 : Closed e2388337554362 ∧ code e2388337554362 = 11184430576570 := by decide
theorem cert_e2388337554362 : check e2388337554362 [[],[.left]] .chain = true := by decide
def e2388337554390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2388337554390 : Closed e2388337554390 ∧ code e2388337554390 = 11184430576598 := by decide
theorem cert_e2388337554390 : check e2388337554390 [[],[.left]] .chain = true := by decide
def e2388337554394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2388337554394 : Closed e2388337554394 ∧ code e2388337554394 = 11184430576602 := by decide
theorem cert_e2388337554394 : check e2388337554394 [[],[.left]] .chain = true := by decide
def e2388337554670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2388337554670 : Closed e2388337554670 ∧ code e2388337554670 = 11184430576878 := by decide
theorem cert_e2388337554670 : check e2388337554670 [[],[.left]] .chain = true := by decide
def e2388337554678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2388337554678 : Closed e2388337554678 ∧ code e2388337554678 = 11184430576886 := by decide
theorem cert_e2388337554678 : check e2388337554678 [[],[.left]] .chain = true := by decide
def e2388337555054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2388337555054 : Closed e2388337555054 ∧ code e2388337555054 = 11184430577262 := by decide
theorem cert_e2388337555054 : check e2388337555054 [[],[.left]] .chain = true := by decide
def e2388337555066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2388337555066 : Closed e2388337555066 ∧ code e2388337555066 = 11184430577274 := by decide
theorem cert_e2388337555066 : check e2388337555066 [[],[.left]] .chain = true := by decide
def e2388337555254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2388337555254 : Closed e2388337555254 ∧ code e2388337555254 = 11184430577462 := by decide
theorem cert_e2388337555254 : check e2388337555254 [[],[.left]] .chain = true := by decide
def e2388337555258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2388337555258 : Closed e2388337555258 ∧ code e2388337555258 = 11184430577466 := by decide
theorem cert_e2388337555258 : check e2388337555258 [[],[.left]] .chain = true := by decide
def e2388337560430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2388337560430 : Closed e2388337560430 ∧ code e2388337560430 = 11184430582638 := by decide
theorem cert_e2388337560430 : check e2388337560430 [[],[.left],[]] .smaller = true := by decide
def e2388337560438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2388337560438 : Closed e2388337560438 ∧ code e2388337560438 = 11184430582646 := by decide
theorem cert_e2388337560438 : check e2388337560438 [[],[.left],[]] .smaller = true := by decide
def e2388337560494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2388337560494 : Closed e2388337560494 ∧ code e2388337560494 = 11184430582702 := by decide
theorem cert_e2388337560494 : check e2388337560494 [[],[.left],[]] .smaller = true := by decide
def e2388337560506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2388337560506 : Closed e2388337560506 ∧ code e2388337560506 = 11184430582714 := by decide
theorem cert_e2388337560506 : check e2388337560506 [[],[.left],[]] .smaller = true := by decide
def e2388337560534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2388337560534 : Closed e2388337560534 ∧ code e2388337560534 = 11184430582742 := by decide
theorem cert_e2388337560534 : check e2388337560534 [[],[.left],[]] .smaller = true := by decide
def e2388337560538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2388337560538 : Closed e2388337560538 ∧ code e2388337560538 = 11184430582746 := by decide
theorem cert_e2388337560538 : check e2388337560538 [[],[.left],[]] .smaller = true := by decide
def e2388337560814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2388337560814 : Closed e2388337560814 ∧ code e2388337560814 = 11184430583022 := by decide
theorem cert_e2388337560814 : check e2388337560814 [[],[.left],[]] .smaller = true := by decide
def e2388337560822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2388337560822 : Closed e2388337560822 ∧ code e2388337560822 = 11184430583030 := by decide
theorem cert_e2388337560822 : check e2388337560822 [[],[.left],[]] .smaller = true := by decide
def e2388337561198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2388337561198 : Closed e2388337561198 ∧ code e2388337561198 = 11184430583406 := by decide
theorem cert_e2388337561198 : check e2388337561198 [[],[.left],[]] .smaller = true := by decide
def e2388337561210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2388337561210 : Closed e2388337561210 ∧ code e2388337561210 = 11184430583418 := by decide
theorem cert_e2388337561210 : check e2388337561210 [[],[.left],[]] .smaller = true := by decide
def e2388337561398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2388337561398 : Closed e2388337561398 ∧ code e2388337561398 = 11184430583606 := by decide
theorem cert_e2388337561398 : check e2388337561398 [[],[.left],[]] .smaller = true := by decide
def e2388337561402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2388337561402 : Closed e2388337561402 ∧ code e2388337561402 = 11184430583610 := by decide
theorem cert_e2388337561402 : check e2388337561402 [[],[.left],[]] .smaller = true := by decide
def e2388337569518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2388337569518 : Closed e2388337569518 ∧ code e2388337569518 = 11184430591726 := by decide
theorem cert_e2388337569518 : check e2388337569518 [[],[.left]] .chain = true := by decide
def e2388337569646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2388337569646 : Closed e2388337569646 ∧ code e2388337569646 = 11184430591854 := by decide
theorem cert_e2388337569646 : check e2388337569646 [[],[.left]] .chain = true := by decide
def e2388337569654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2388337569654 : Closed e2388337569654 ∧ code e2388337569654 = 11184430591862 := by decide
theorem cert_e2388337569654 : check e2388337569654 [[],[.left]] .chain = true := by decide
def e2388337572334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2388337572334 : Closed e2388337572334 ∧ code e2388337572334 = 11184430594542 := by decide
theorem cert_e2388337572334 : check e2388337572334 [[],[.left]] .chain = true := by decide
def e2388337573102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2388337573102 : Closed e2388337573102 ∧ code e2388337573102 = 11184430595310 := by decide
theorem cert_e2388337573102 : check e2388337573102 [[],[.left]] .chain = true := by decide
def e2388337573110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2388337573110 : Closed e2388337573110 ∧ code e2388337573110 = 11184430595318 := by decide
theorem cert_e2388337573110 : check e2388337573110 [[],[.left]] .chain = true := by decide
def e2388337596142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2388337596142 : Closed e2388337596142 ∧ code e2388337596142 = 11184430618350 := by decide
theorem cert_e2388337596142 : check e2388337596142 [[],[.left]] .chain = true := by decide
def e2388337596334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2388337596334 : Closed e2388337596334 ∧ code e2388337596334 = 11184430618542 := by decide
theorem cert_e2388337596334 : check e2388337596334 [[],[.left]] .chain = true := by decide
def e2388337596346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2388337596346 : Closed e2388337596346 ∧ code e2388337596346 = 11184430618554 := by decide
theorem cert_e2388337596346 : check e2388337596346 [[],[.left]] .chain = true := by decide
def e2388337596910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2388337596910 : Closed e2388337596910 ∧ code e2388337596910 = 11184430619118 := by decide
theorem cert_e2388337596910 : check e2388337596910 [[],[.left]] .chain = true := by decide
def e2388337598062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2388337598062 : Closed e2388337598062 ∧ code e2388337598062 = 11184430620270 := by decide
theorem cert_e2388337598062 : check e2388337598062 [[],[.left]] .chain = true := by decide
def e2388337598074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2388337598074 : Closed e2388337598074 ∧ code e2388337598074 = 11184430620282 := by decide
theorem cert_e2388337598074 : check e2388337598074 [[],[.left]] .chain = true := by decide
def e2388337609582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388337609582 : Closed e2388337609582 ∧ code e2388337609582 = 11184430631790 := by decide
theorem cert_e2388337609582 : check e2388337609582 [[],[.left]] .chain = true := by decide
def e2388337609590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388337609590 : Closed e2388337609590 ∧ code e2388337609590 = 11184430631798 := by decide
theorem cert_e2388337609590 : check e2388337609590 [[],[.left]] .chain = true := by decide
def e2388337609646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388337609646 : Closed e2388337609646 ∧ code e2388337609646 = 11184430631854 := by decide
theorem cert_e2388337609646 : check e2388337609646 [[],[.left]] .chain = true := by decide
def e2388337609658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388337609658 : Closed e2388337609658 ∧ code e2388337609658 = 11184430631866 := by decide
theorem cert_e2388337609658 : check e2388337609658 [[],[.left]] .chain = true := by decide
def e2388337609686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388337609686 : Closed e2388337609686 ∧ code e2388337609686 = 11184430631894 := by decide
theorem cert_e2388337609686 : check e2388337609686 [[],[.left]] .chain = true := by decide
def e2388337609690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388337609690 : Closed e2388337609690 ∧ code e2388337609690 = 11184430631898 := by decide
theorem cert_e2388337609690 : check e2388337609690 [[],[.left]] .chain = true := by decide
def e2388337609966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388337609966 : Closed e2388337609966 ∧ code e2388337609966 = 11184430632174 := by decide
theorem cert_e2388337609966 : check e2388337609966 [[],[.left]] .chain = true := by decide
def e2388337609974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388337609974 : Closed e2388337609974 ∧ code e2388337609974 = 11184430632182 := by decide
theorem cert_e2388337609974 : check e2388337609974 [[],[.left]] .chain = true := by decide
def e2388337610350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388337610350 : Closed e2388337610350 ∧ code e2388337610350 = 11184430632558 := by decide
theorem cert_e2388337610350 : check e2388337610350 [[],[.left]] .chain = true := by decide
def e2388337610362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388337610362 : Closed e2388337610362 ∧ code e2388337610362 = 11184430632570 := by decide
theorem cert_e2388337610362 : check e2388337610362 [[],[.left]] .chain = true := by decide
def e2388337610550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388337610550 : Closed e2388337610550 ∧ code e2388337610550 = 11184430632758 := by decide
theorem cert_e2388337610550 : check e2388337610550 [[],[.left]] .chain = true := by decide
def e2388337610554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388337610554 : Closed e2388337610554 ∧ code e2388337610554 = 11184430632762 := by decide
theorem cert_e2388337610554 : check e2388337610554 [[],[.left]] .chain = true := by decide
def e2388338150254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2388338150254 : Closed e2388338150254 ∧ code e2388338150254 = 11184431172462 := by decide
theorem cert_e2388338150254 : check e2388338150254 [[],[.left],[],[]] .smaller = true := by decide
def e2388338150262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2388338150262 : Closed e2388338150262 ∧ code e2388338150262 = 11184431172470 := by decide
theorem cert_e2388338150262 : check e2388338150262 [[],[.left],[],[]] .smaller = true := by decide
def e2388338150318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2388338150318 : Closed e2388338150318 ∧ code e2388338150318 = 11184431172526 := by decide
theorem cert_e2388338150318 : check e2388338150318 [[],[.left],[],[]] .smaller = true := by decide
def e2388338150330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2388338150330 : Closed e2388338150330 ∧ code e2388338150330 = 11184431172538 := by decide
theorem cert_e2388338150330 : check e2388338150330 [[],[.left],[],[]] .smaller = true := by decide
def e2388338150358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2388338150358 : Closed e2388338150358 ∧ code e2388338150358 = 11184431172566 := by decide
theorem cert_e2388338150358 : check e2388338150358 [[],[.left],[],[]] .smaller = true := by decide
def e2388338150362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2388338150362 : Closed e2388338150362 ∧ code e2388338150362 = 11184431172570 := by decide
theorem cert_e2388338150362 : check e2388338150362 [[],[.left],[],[]] .smaller = true := by decide
def e2388338150638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2388338150638 : Closed e2388338150638 ∧ code e2388338150638 = 11184431172846 := by decide
theorem cert_e2388338150638 : check e2388338150638 [[],[.left],[],[]] .smaller = true := by decide
def e2388338150646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2388338150646 : Closed e2388338150646 ∧ code e2388338150646 = 11184431172854 := by decide
theorem cert_e2388338150646 : check e2388338150646 [[],[.left],[],[]] .smaller = true := by decide
def e2388338151022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2388338151022 : Closed e2388338151022 ∧ code e2388338151022 = 11184431173230 := by decide
theorem cert_e2388338151022 : check e2388338151022 [[],[.left],[],[]] .smaller = true := by decide
def e2388338151034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2388338151034 : Closed e2388338151034 ∧ code e2388338151034 = 11184431173242 := by decide
theorem cert_e2388338151034 : check e2388338151034 [[],[.left],[],[]] .smaller = true := by decide
def e2388338151222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2388338151222 : Closed e2388338151222 ∧ code e2388338151222 = 11184431173430 := by decide
theorem cert_e2388338151222 : check e2388338151222 [[],[.left],[],[]] .smaller = true := by decide
def e2388338151226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2388338151226 : Closed e2388338151226 ∧ code e2388338151226 = 11184431173434 := by decide
theorem cert_e2388338151226 : check e2388338151226 [[],[.left],[],[]] .smaller = true := by decide
def e2388438113134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2388438113134 : Closed e2388438113134 ∧ code e2388438113134 = 11184531135342 := by decide
theorem cert_e2388438113134 : check e2388438113134 [[],[.left],[]] .sourceHead = true := by decide
def e2388438113142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2388438113142 : Closed e2388438113142 ∧ code e2388438113142 = 11184531135350 := by decide
theorem cert_e2388438113142 : check e2388438113142 [[],[.left],[]] .sourceHead = true := by decide
def e2388438113206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2388438113206 : Closed e2388438113206 ∧ code e2388438113206 = 11184531135414 := by decide
theorem cert_e2388438113206 : check e2388438113206 [[],[.left],[]] .sourceHead = true := by decide
def e2388438113646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2388438113646 : Closed e2388438113646 ∧ code e2388438113646 = 11184531135854 := by decide
def e2388438113654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2388438113654 : Closed e2388438113654 ∧ code e2388438113654 = 11184531135862 := by decide
theorem cert_e2388438113654 : check e2388438113654 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2388438113710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2388438113710 : Closed e2388438113710 ∧ code e2388438113710 = 11184531135918 := by decide
theorem cert_e2388438113710 : check e2388438113710 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2388438113722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2388438113722 : Closed e2388438113722 ∧ code e2388438113722 = 11184531135930 := by decide
theorem cert_e2388438113722 : check e2388438113722 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2388438113750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2388438113750 : Closed e2388438113750 ∧ code e2388438113750 = 11184531135958 := by decide
theorem cert_e2388438113750 : check e2388438113750 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2388438113754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2388438113754 : Closed e2388438113754 ∧ code e2388438113754 = 11184531135962 := by decide
def e2388438113974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2388438113974 : Closed e2388438113974 ∧ code e2388438113974 = 11184531136182 := by decide
theorem cert_e2388438113974 : check e2388438113974 [[],[.left],[],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e2388438114006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2388438114006 : Closed e2388438114006 ∧ code e2388438114006 = 11184531136214 := by decide
theorem cert_e2388438114006 : check e2388438114006 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .three = true := by decide
def e2388438114010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2388438114010 : Closed e2388438114010 ∧ code e2388438114010 = 11184531136218 := by decide
theorem cert_e2388438114010 : check e2388438114010 [[],[.left],[],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e2388438116206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2388438116206 : Closed e2388438116206 ∧ code e2388438116206 = 11184531138414 := by decide
theorem cert_e2388438116206 : check e2388438116206 [[],[.left],[]] .sourceHead = true := by decide
def e2388438116214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2388438116214 : Closed e2388438116214 ∧ code e2388438116214 = 11184531138422 := by decide
theorem cert_e2388438116214 : check e2388438116214 [[],[.left],[]] .sourceHead = true := by decide
def e2388438116278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2388438116278 : Closed e2388438116278 ∧ code e2388438116278 = 11184531138486 := by decide
theorem cert_e2388438116278 : check e2388438116278 [[],[.left],[]] .sourceHead = true := by decide
def e2388438117614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2388438117614 : Closed e2388438117614 ∧ code e2388438117614 = 11184531139822 := by decide
theorem cert_e2388438117614 : check e2388438117614 [[],[.left],[]] .sourceHead = true := by decide
def e2388438117622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2388438117622 : Closed e2388438117622 ∧ code e2388438117622 = 11184531139830 := by decide
theorem cert_e2388438117622 : check e2388438117622 [[],[.left],[]] .sourceHead = true := by decide
def e2388438118006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2388438118006 : Closed e2388438118006 ∧ code e2388438118006 = 11184531140214 := by decide
theorem cert_e2388438118006 : check e2388438118006 [[],[.left],[]] .sourceHead = true := by decide
def e2388438119278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2388438119278 : Closed e2388438119278 ∧ code e2388438119278 = 11184531141486 := by decide
theorem cert_e2388438119278 : check e2388438119278 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2388438119286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2388438119286 : Closed e2388438119286 ∧ code e2388438119286 = 11184531141494 := by decide
theorem cert_e2388438119286 : check e2388438119286 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2388438119342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2388438119342 : Closed e2388438119342 ∧ code e2388438119342 = 11184531141550 := by decide
theorem cert_e2388438119342 : check e2388438119342 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2388438119354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2388438119354 : Closed e2388438119354 ∧ code e2388438119354 = 11184531141562 := by decide
theorem cert_e2388438119354 : check e2388438119354 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2388438119382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2388438119382 : Closed e2388438119382 ∧ code e2388438119382 = 11184531141590 := by decide
theorem cert_e2388438119382 : check e2388438119382 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2388438119386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2388438119386 : Closed e2388438119386 ∧ code e2388438119386 = 11184531141594 := by decide
theorem cert_e2388438119386 : check e2388438119386 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2388438119662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2388438119662 : Closed e2388438119662 ∧ code e2388438119662 = 11184531141870 := by decide
theorem cert_e2388438119662 : check e2388438119662 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2388438119670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2388438119670 : Closed e2388438119670 ∧ code e2388438119670 = 11184531141878 := by decide
theorem cert_e2388438119670 : check e2388438119670 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
end Blc.Floor43
