import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411624495674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411624495674 : Closed e2411624495674 ∧ code e2411624495674 = 11207717517882 := by decide
theorem cert_e2411624495674 : check e2411624495674 [[],[]] .smaller = true := by decide
def e2411624495758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411624495758 : Closed e2411624495758 ∧ code e2411624495758 = 11207717517966 := by decide
theorem cert_e2411624495758 : check e2411624495758 [[],[]] .smaller = true := by decide
def e2411624495806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 4))))))))
theorem wire_e2411624495806 : Closed e2411624495806 ∧ code e2411624495806 = 11207717518014 := by decide
theorem cert_e2411624495806 : check e2411624495806 [[],[]] .three = true := by decide
def e2411624495814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411624495814 : Closed e2411624495814 ∧ code e2411624495814 = 11207717518022 := by decide
theorem cert_e2411624495814 : check e2411624495814 [[],[]] .smaller = true := by decide
def e2411624495866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 4)) (.var 0))))))))
theorem wire_e2411624495866 : Closed e2411624495866 ∧ code e2411624495866 = 11207717518074 := by decide
theorem cert_e2411624495866 : check e2411624495866 [[],[]] .three = true := by decide
def e2411624495898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411624495898 : Closed e2411624495898 ∧ code e2411624495898 = 11207717518106 := by decide
theorem cert_e2411624495898 : check e2411624495898 [[],[]] .smaller = true := by decide
def e2411624495942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411624495942 : Closed e2411624495942 ∧ code e2411624495942 = 11207717518150 := by decide
theorem cert_e2411624495942 : check e2411624495942 [[],[]] .smaller = true := by decide
def e2411624496106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 4)) (.var 0)) (.var 0))))))))
theorem wire_e2411624496106 : Closed e2411624496106 ∧ code e2411624496106 = 11207717518314 := by decide
theorem cert_e2411624496106 : check e2411624496106 [[],[]] .three = true := by decide
def e2411624496814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2411624496814 : Closed e2411624496814 ∧ code e2411624496814 = 11207717519022 := by decide
theorem cert_e2411624496814 : check e2411624496814 [[],[]] .three = true := by decide
def e2411624496822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2411624496822 : Closed e2411624496822 ∧ code e2411624496822 = 11207717519030 := by decide
theorem cert_e2411624496822 : check e2411624496822 [[],[]] .three = true := by decide
def e2411624496826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2411624496826 : Closed e2411624496826 ∧ code e2411624496826 = 11207717519034 := by decide
theorem cert_e2411624496826 : check e2411624496826 [[],[]] .three = true := by decide
def e2411624496854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2411624496854 : Closed e2411624496854 ∧ code e2411624496854 = 11207717519062 := by decide
theorem cert_e2411624496854 : check e2411624496854 [[],[]] .three = true := by decide
def e2411624496858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2411624496858 : Closed e2411624496858 ∧ code e2411624496858 = 11207717519066 := by decide
theorem cert_e2411624496858 : check e2411624496858 [[],[]] .three = true := by decide
def e2411624496874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2411624496874 : Closed e2411624496874 ∧ code e2411624496874 = 11207717519082 := by decide
theorem cert_e2411624496874 : check e2411624496874 [[],[]] .three = true := by decide
def e2411624500462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411624500462 : Closed e2411624500462 ∧ code e2411624500462 = 11207717522670 := by decide
theorem cert_e2411624500462 : check e2411624500462 [[],[]] .smaller = true := by decide
def e2411624500470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411624500470 : Closed e2411624500470 ∧ code e2411624500470 = 11207717522678 := by decide
theorem cert_e2411624500470 : check e2411624500470 [[],[]] .smaller = true := by decide
def e2411624500846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411624500846 : Closed e2411624500846 ∧ code e2411624500846 = 11207717523054 := by decide
theorem cert_e2411624500846 : check e2411624500846 [[],[]] .smaller = true := by decide
def e2411624500858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411624500858 : Closed e2411624500858 ∧ code e2411624500858 = 11207717523066 := by decide
theorem cert_e2411624500858 : check e2411624500858 [[],[]] .smaller = true := by decide
def e2411624501046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411624501046 : Closed e2411624501046 ∧ code e2411624501046 = 11207717523254 := by decide
theorem cert_e2411624501046 : check e2411624501046 [[],[]] .smaller = true := by decide
def e2411624501050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411624501050 : Closed e2411624501050 ∧ code e2411624501050 = 11207717523258 := by decide
theorem cert_e2411624501050 : check e2411624501050 [[],[]] .smaller = true := by decide
def e2411624503534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2411624503534 : Closed e2411624503534 ∧ code e2411624503534 = 11207717525742 := by decide
theorem cert_e2411624503534 : check e2411624503534 [[],[]] .smaller = true := by decide
def e2411624503542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e2411624503542 : Closed e2411624503542 ∧ code e2411624503542 = 11207717525750 := by decide
theorem cert_e2411624503542 : check e2411624503542 [[],[]] .smaller = true := by decide
def e2411624504094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2411624504094 : Closed e2411624504094 ∧ code e2411624504094 = 11207717526302 := by decide
theorem cert_e2411624504094 : check e2411624504094 [[],[]] .smaller = true := by decide
def e2411624504206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e2411624504206 : Closed e2411624504206 ∧ code e2411624504206 = 11207717526414 := by decide
theorem cert_e2411624504206 : check e2411624504206 [[],[]] .smaller = true := by decide
def e2411624504254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 4))))))))
theorem wire_e2411624504254 : Closed e2411624504254 ∧ code e2411624504254 = 11207717526462 := by decide
theorem cert_e2411624504254 : check e2411624504254 [[],[]] .three = true := by decide
def e2411624504302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 2))))))))
theorem wire_e2411624504302 : Closed e2411624504302 ∧ code e2411624504302 = 11207717526510 := by decide
theorem cert_e2411624504302 : check e2411624504302 [[],[]] .three = true := by decide
def e2411624504430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e2411624504430 : Closed e2411624504430 ∧ code e2411624504430 = 11207717526638 := by decide
theorem cert_e2411624504430 : check e2411624504430 [[],[]] .smaller = true := by decide
def e2411624504442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2411624504442 : Closed e2411624504442 ∧ code e2411624504442 = 11207717526650 := by decide
theorem cert_e2411624504442 : check e2411624504442 [[],[]] .smaller = true := by decide
def e2411624504606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e2411624504606 : Closed e2411624504606 ∧ code e2411624504606 = 11207717526814 := by decide
theorem cert_e2411624504606 : check e2411624504606 [[],[]] .smaller = true := by decide
def e2411624504766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 4))))))))
theorem wire_e2411624504766 : Closed e2411624504766 ∧ code e2411624504766 = 11207717526974 := by decide
theorem cert_e2411624504766 : check e2411624504766 [[],[]] .three = true := by decide
def e2411624504774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2411624504774 : Closed e2411624504774 ∧ code e2411624504774 = 11207717526982 := by decide
theorem cert_e2411624504774 : check e2411624504774 [[],[]] .smaller = true := by decide
def e2411624504822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 1))))))))
theorem wire_e2411624504822 : Closed e2411624504822 ∧ code e2411624504822 = 11207717527030 := by decide
theorem cert_e2411624504822 : check e2411624504822 [[],[]] .three = true := by decide
def e2411624504886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2411624504886 : Closed e2411624504886 ∧ code e2411624504886 = 11207717527094 := by decide
theorem cert_e2411624504886 : check e2411624504886 [[],[]] .smaller = true := by decide
def e2411624504890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2411624504890 : Closed e2411624504890 ∧ code e2411624504890 = 11207717527098 := by decide
theorem cert_e2411624504890 : check e2411624504890 [[],[]] .smaller = true := by decide
def e2411624504974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2411624504974 : Closed e2411624504974 ∧ code e2411624504974 = 11207717527182 := by decide
theorem cert_e2411624504974 : check e2411624504974 [[],[]] .smaller = true := by decide
def e2411624505022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 4))))))))
theorem wire_e2411624505022 : Closed e2411624505022 ∧ code e2411624505022 = 11207717527230 := by decide
theorem cert_e2411624505022 : check e2411624505022 [[],[]] .three = true := by decide
def e2411624505030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2411624505030 : Closed e2411624505030 ∧ code e2411624505030 = 11207717527238 := by decide
theorem cert_e2411624505030 : check e2411624505030 [[],[]] .smaller = true := by decide
def e2411624505082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 4))) (.var 0))))))))
theorem wire_e2411624505082 : Closed e2411624505082 ∧ code e2411624505082 = 11207717527290 := by decide
theorem cert_e2411624505082 : check e2411624505082 [[],[]] .three = true := by decide
def e2411624505262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 2))))))))
theorem wire_e2411624505262 : Closed e2411624505262 ∧ code e2411624505262 = 11207717527470 := by decide
theorem cert_e2411624505262 : check e2411624505262 [[],[]] .three = true := by decide
def e2411624505270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 1))))))))
theorem wire_e2411624505270 : Closed e2411624505270 ∧ code e2411624505270 = 11207717527478 := by decide
theorem cert_e2411624505270 : check e2411624505270 [[],[]] .three = true := by decide
def e2411624505274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 2))) (.var 0))))))))
theorem wire_e2411624505274 : Closed e2411624505274 ∧ code e2411624505274 = 11207717527482 := by decide
theorem cert_e2411624505274 : check e2411624505274 [[],[]] .three = true := by decide
def e2411624507166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411624507166 : Closed e2411624507166 ∧ code e2411624507166 = 11207717529374 := by decide
theorem cert_e2411624507166 : check e2411624507166 [[],[]] .smaller = true := by decide
def e2411624507278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411624507278 : Closed e2411624507278 ∧ code e2411624507278 = 11207717529486 := by decide
theorem cert_e2411624507278 : check e2411624507278 [[],[]] .smaller = true := by decide
def e2411624507326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 4)))))))))
theorem wire_e2411624507326 : Closed e2411624507326 ∧ code e2411624507326 = 11207717529534 := by decide
theorem cert_e2411624507326 : check e2411624507326 [[],[]] .three = true := by decide
def e2411624507374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 2)))))))))
theorem wire_e2411624507374 : Closed e2411624507374 ∧ code e2411624507374 = 11207717529582 := by decide
theorem cert_e2411624507374 : check e2411624507374 [[],[]] .three = true := by decide
def e2411624510238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411624510238 : Closed e2411624510238 ∧ code e2411624510238 = 11207717532446 := by decide
theorem cert_e2411624510238 : check e2411624510238 [[],[]] .smaller = true := by decide
def e2411624510398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2411624510398 : Closed e2411624510398 ∧ code e2411624510398 = 11207717532606 := by decide
theorem cert_e2411624510398 : check e2411624510398 [[],[]] .three = true := by decide
def e2411624510406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411624510406 : Closed e2411624510406 ∧ code e2411624510406 = 11207717532614 := by decide
theorem cert_e2411624510406 : check e2411624510406 [[],[]] .smaller = true := by decide
def e2411624510454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2411624510454 : Closed e2411624510454 ∧ code e2411624510454 = 11207717532662 := by decide
theorem cert_e2411624510454 : check e2411624510454 [[],[]] .three = true := by decide
def e2411624511886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411624511886 : Closed e2411624511886 ∧ code e2411624511886 = 11207717534094 := by decide
theorem cert_e2411624511886 : check e2411624511886 [[],[]] .smaller = true := by decide
def e2411624511934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2411624511934 : Closed e2411624511934 ∧ code e2411624511934 = 11207717534142 := by decide
theorem cert_e2411624511934 : check e2411624511934 [[],[]] .three = true := by decide
def e2411624511942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411624511942 : Closed e2411624511942 ∧ code e2411624511942 = 11207717534150 := by decide
theorem cert_e2411624511942 : check e2411624511942 [[],[]] .smaller = true := by decide
def e2411624511994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2411624511994 : Closed e2411624511994 ∧ code e2411624511994 = 11207717534202 := by decide
theorem cert_e2411624511994 : check e2411624511994 [[],[]] .three = true := by decide
def e2411624513134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411624513134 : Closed e2411624513134 ∧ code e2411624513134 = 11207717535342 := by decide
theorem cert_e2411624513134 : check e2411624513134 [[],[]] .three = true := by decide
def e2411624513142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411624513142 : Closed e2411624513142 ∧ code e2411624513142 = 11207717535350 := by decide
theorem cert_e2411624513142 : check e2411624513142 [[],[]] .three = true := by decide
def e2411624513146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411624513146 : Closed e2411624513146 ∧ code e2411624513146 = 11207717535354 := by decide
theorem cert_e2411624513146 : check e2411624513146 [[],[]] .three = true := by decide
def e2411624515182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411624515182 : Closed e2411624515182 ∧ code e2411624515182 = 11207717537390 := by decide
theorem cert_e2411624515182 : check e2411624515182 [[],[]] .smaller = true := by decide
def e2411624515194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411624515194 : Closed e2411624515194 ∧ code e2411624515194 = 11207717537402 := by decide
theorem cert_e2411624515194 : check e2411624515194 [[],[]] .smaller = true := by decide
def e2411624515482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411624515482 : Closed e2411624515482 ∧ code e2411624515482 = 11207717537690 := by decide
theorem cert_e2411624515482 : check e2411624515482 [[],[]] .smaller = true := by decide
def e2411624516718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e2411624516718 : Closed e2411624516718 ∧ code e2411624516718 = 11207717538926 := by decide
theorem cert_e2411624516718 : check e2411624516718 [[],[]] .smaller = true := by decide
def e2411624516730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2411624516730 : Closed e2411624516730 ∧ code e2411624516730 = 11207717538938 := by decide
theorem cert_e2411624516730 : check e2411624516730 [[],[]] .smaller = true := by decide
def e2411624516894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e2411624516894 : Closed e2411624516894 ∧ code e2411624516894 = 11207717539102 := by decide
theorem cert_e2411624516894 : check e2411624516894 [[],[]] .smaller = true := by decide
def e2411624517054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 4))))))))
theorem wire_e2411624517054 : Closed e2411624517054 ∧ code e2411624517054 = 11207717539262 := by decide
theorem cert_e2411624517054 : check e2411624517054 [[],[]] .three = true := by decide
def e2411624517062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2411624517062 : Closed e2411624517062 ∧ code e2411624517062 = 11207717539270 := by decide
theorem cert_e2411624517062 : check e2411624517062 [[],[]] .smaller = true := by decide
def e2411624517110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 1))))))))
theorem wire_e2411624517110 : Closed e2411624517110 ∧ code e2411624517110 = 11207717539318 := by decide
theorem cert_e2411624517110 : check e2411624517110 [[],[]] .three = true := by decide
def e2411624517310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 4))))))))
theorem wire_e2411624517310 : Closed e2411624517310 ∧ code e2411624517310 = 11207717539518 := by decide
theorem cert_e2411624517310 : check e2411624517310 [[],[]] .three = true := by decide
def e2411624517370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 4))) (.var 0))))))))
theorem wire_e2411624517370 : Closed e2411624517370 ∧ code e2411624517370 = 11207717539578 := by decide
theorem cert_e2411624517370 : check e2411624517370 [[],[]] .three = true := by decide
def e2411624517402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2411624517402 : Closed e2411624517402 ∧ code e2411624517402 = 11207717539610 := by decide
theorem cert_e2411624517402 : check e2411624517402 [[],[]] .smaller = true := by decide
def e2411624517446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2411624517446 : Closed e2411624517446 ∧ code e2411624517446 = 11207717539654 := by decide
theorem cert_e2411624517446 : check e2411624517446 [[],[]] .smaller = true := by decide
def e2411624517590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 1))))))))
theorem wire_e2411624517590 : Closed e2411624517590 ∧ code e2411624517590 = 11207717539798 := by decide
theorem cert_e2411624517590 : check e2411624517590 [[],[]] .three = true := by decide
def e2411624517594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 1))) (.var 0))))))))
theorem wire_e2411624517594 : Closed e2411624517594 ∧ code e2411624517594 = 11207717539802 := by decide
theorem cert_e2411624517594 : check e2411624517594 [[],[]] .three = true := by decide
def e2411624518430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411624518430 : Closed e2411624518430 ∧ code e2411624518430 = 11207717540638 := by decide
theorem cert_e2411624518430 : check e2411624518430 [[],[]] .smaller = true := by decide
def e2411624518590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2411624518590 : Closed e2411624518590 ∧ code e2411624518590 = 11207717540798 := by decide
theorem cert_e2411624518590 : check e2411624518590 [[],[]] .three = true := by decide
def e2411624518598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411624518598 : Closed e2411624518598 ∧ code e2411624518598 = 11207717540806 := by decide
theorem cert_e2411624518598 : check e2411624518598 [[],[]] .smaller = true := by decide
def e2411624518646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2411624518646 : Closed e2411624518646 ∧ code e2411624518646 = 11207717540854 := by decide
theorem cert_e2411624518646 : check e2411624518646 [[],[]] .three = true := by decide
def e2411624520126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2411624520126 : Closed e2411624520126 ∧ code e2411624520126 = 11207717542334 := by decide
theorem cert_e2411624520126 : check e2411624520126 [[],[]] .three = true := by decide
def e2411624520186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2411624520186 : Closed e2411624520186 ∧ code e2411624520186 = 11207717542394 := by decide
theorem cert_e2411624520186 : check e2411624520186 [[],[]] .three = true := by decide
def e2411624520902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411624520902 : Closed e2411624520902 ∧ code e2411624520902 = 11207717543110 := by decide
theorem cert_e2411624520902 : check e2411624520902 [[],[]] .smaller = true := by decide
def e2411624521526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411624521526 : Closed e2411624521526 ∧ code e2411624521526 = 11207717543734 := by decide
theorem cert_e2411624521526 : check e2411624521526 [[],[]] .three = true := by decide
def e2411624521530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411624521530 : Closed e2411624521530 ∧ code e2411624521530 = 11207717543738 := by decide
theorem cert_e2411624521530 : check e2411624521530 [[],[]] .three = true := by decide
def e2411624522550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411624522550 : Closed e2411624522550 ∧ code e2411624522550 = 11207717544758 := by decide
theorem cert_e2411624522550 : check e2411624522550 [[],[]] .smaller = true := by decide
def e2411624522554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411624522554 : Closed e2411624522554 ∧ code e2411624522554 = 11207717544762 := by decide
theorem cert_e2411624522554 : check e2411624522554 [[],[]] .smaller = true := by decide
def e2411624522650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411624522650 : Closed e2411624522650 ∧ code e2411624522650 = 11207717544858 := by decide
theorem cert_e2411624522650 : check e2411624522650 [[],[]] .smaller = true := by decide
def e2411624523318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2411624523318 : Closed e2411624523318 ∧ code e2411624523318 = 11207717545526 := by decide
theorem cert_e2411624523318 : check e2411624523318 [[],[]] .smaller = true := by decide
def e2411624523322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2411624523322 : Closed e2411624523322 ∧ code e2411624523322 = 11207717545530 := by decide
theorem cert_e2411624523322 : check e2411624523322 [[],[]] .smaller = true := by decide
def e2411624523406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2411624523406 : Closed e2411624523406 ∧ code e2411624523406 = 11207717545614 := by decide
theorem cert_e2411624523406 : check e2411624523406 [[],[]] .smaller = true := by decide
def e2411624523454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 4))))))))
theorem wire_e2411624523454 : Closed e2411624523454 ∧ code e2411624523454 = 11207717545662 := by decide
theorem cert_e2411624523454 : check e2411624523454 [[],[]] .three = true := by decide
def e2411624523462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2411624523462 : Closed e2411624523462 ∧ code e2411624523462 = 11207717545670 := by decide
theorem cert_e2411624523462 : check e2411624523462 [[],[]] .smaller = true := by decide
def e2411624523514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 4))) (.var 0))))))))
theorem wire_e2411624523514 : Closed e2411624523514 ∧ code e2411624523514 = 11207717545722 := by decide
theorem cert_e2411624523514 : check e2411624523514 [[],[]] .three = true := by decide
def e2411624523546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2411624523546 : Closed e2411624523546 ∧ code e2411624523546 = 11207717545754 := by decide
theorem cert_e2411624523546 : check e2411624523546 [[],[]] .smaller = true := by decide
def e2411624523590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2411624523590 : Closed e2411624523590 ∧ code e2411624523590 = 11207717545798 := by decide
theorem cert_e2411624523590 : check e2411624523590 [[],[]] .smaller = true := by decide
def e2411624523754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 4) (.var 0))) (.var 0))))))))
theorem wire_e2411624523754 : Closed e2411624523754 ∧ code e2411624523754 = 11207717545962 := by decide
theorem cert_e2411624523754 : check e2411624523754 [[],[]] .three = true := by decide
def e2411624524174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411624524174 : Closed e2411624524174 ∧ code e2411624524174 = 11207717546382 := by decide
theorem cert_e2411624524174 : check e2411624524174 [[],[]] .smaller = true := by decide
def e2411624524222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2411624524222 : Closed e2411624524222 ∧ code e2411624524222 = 11207717546430 := by decide
theorem cert_e2411624524222 : check e2411624524222 [[],[]] .three = true := by decide
def e2411624524230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411624524230 : Closed e2411624524230 ∧ code e2411624524230 = 11207717546438 := by decide
theorem cert_e2411624524230 : check e2411624524230 [[],[]] .smaller = true := by decide
def e2411624524282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2411624524282 : Closed e2411624524282 ∧ code e2411624524282 = 11207717546490 := by decide
theorem cert_e2411624524282 : check e2411624524282 [[],[]] .three = true := by decide
def e2411624524998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411624524998 : Closed e2411624524998 ∧ code e2411624524998 = 11207717547206 := by decide
theorem cert_e2411624524998 : check e2411624524998 [[],[]] .smaller = true := by decide
def e2411624525722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411624525722 : Closed e2411624525722 ∧ code e2411624525722 = 11207717547930 := by decide
theorem cert_e2411624525722 : check e2411624525722 [[],[]] .three = true := by decide
def e2411624528302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2411624528302 : Closed e2411624528302 ∧ code e2411624528302 = 11207717550510 := by decide
theorem cert_e2411624528302 : check e2411624528302 [[],[]] .three = true := by decide
def e2411624528310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2411624528310 : Closed e2411624528310 ∧ code e2411624528310 = 11207717550518 := by decide
theorem cert_e2411624528310 : check e2411624528310 [[],[]] .three = true := by decide
def e2411624528314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2411624528314 : Closed e2411624528314 ∧ code e2411624528314 = 11207717550522 := by decide
theorem cert_e2411624528314 : check e2411624528314 [[],[]] .three = true := by decide
def e2411624528342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2411624528342 : Closed e2411624528342 ∧ code e2411624528342 = 11207717550550 := by decide
theorem cert_e2411624528342 : check e2411624528342 [[],[]] .three = true := by decide
def e2411624528346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2411624528346 : Closed e2411624528346 ∧ code e2411624528346 = 11207717550554 := by decide
theorem cert_e2411624528346 : check e2411624528346 [[],[]] .three = true := by decide
def e2411624528362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2411624528362 : Closed e2411624528362 ∧ code e2411624528362 = 11207717550570 := by decide
theorem cert_e2411624528362 : check e2411624528362 [[],[]] .three = true := by decide
def e2411624528494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411624528494 : Closed e2411624528494 ∧ code e2411624528494 = 11207717550702 := by decide
theorem cert_e2411624528494 : check e2411624528494 [[],[]] .three = true := by decide
def e2411624528502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411624528502 : Closed e2411624528502 ∧ code e2411624528502 = 11207717550710 := by decide
theorem cert_e2411624528502 : check e2411624528502 [[],[]] .three = true := by decide
def e2411624528506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411624528506 : Closed e2411624528506 ∧ code e2411624528506 = 11207717550714 := by decide
theorem cert_e2411624528506 : check e2411624528506 [[],[]] .three = true := by decide
def e2411624528694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411624528694 : Closed e2411624528694 ∧ code e2411624528694 = 11207717550902 := by decide
theorem cert_e2411624528694 : check e2411624528694 [[],[]] .three = true := by decide
def e2411624528698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411624528698 : Closed e2411624528698 ∧ code e2411624528698 = 11207717550906 := by decide
theorem cert_e2411624528698 : check e2411624528698 [[],[]] .three = true := by decide
def e2411624528794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411624528794 : Closed e2411624528794 ∧ code e2411624528794 = 11207717551002 := by decide
theorem cert_e2411624528794 : check e2411624528794 [[],[]] .three = true := by decide
def e2411624535774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2411624535774 : Closed e2411624535774 ∧ code e2411624535774 = 11207717557982 := by decide
theorem cert_e2411624535774 : check e2411624535774 [[],[]] .smaller = true := by decide
def e2411624535798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2411624535798 : Closed e2411624535798 ∧ code e2411624535798 = 11207717558006 := by decide
theorem cert_e2411624535798 : check e2411624535798 [[],[]] .smaller = true := by decide
def e2411624535902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2411624535902 : Closed e2411624535902 ∧ code e2411624535902 = 11207717558110 := by decide
theorem cert_e2411624535902 : check e2411624535902 [[],[]] .smaller = true := by decide
def e2411624535930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2411624535930 : Closed e2411624535930 ∧ code e2411624535930 = 11207717558138 := by decide
theorem cert_e2411624535930 : check e2411624535930 [[],[]] .smaller = true := by decide
def e2411624536022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2411624536022 : Closed e2411624536022 ∧ code e2411624536022 = 11207717558230 := by decide
theorem cert_e2411624536022 : check e2411624536022 [[],[]] .smaller = true := by decide
def e2411624536026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2411624536026 : Closed e2411624536026 ∧ code e2411624536026 = 11207717558234 := by decide
theorem cert_e2411624536026 : check e2411624536026 [[],[]] .smaller = true := by decide
def e2411624536542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2411624536542 : Closed e2411624536542 ∧ code e2411624536542 = 11207717558750 := by decide
theorem cert_e2411624536542 : check e2411624536542 [[],[]] .smaller = true := by decide
def e2411624536566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2411624536566 : Closed e2411624536566 ∧ code e2411624536566 = 11207717558774 := by decide
theorem cert_e2411624536566 : check e2411624536566 [[],[]] .smaller = true := by decide
def e2411624537310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2411624537310 : Closed e2411624537310 ∧ code e2411624537310 = 11207717559518 := by decide
theorem cert_e2411624537310 : check e2411624537310 [[],[]] .smaller = true := by decide
def e2411624537338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2411624537338 : Closed e2411624537338 ∧ code e2411624537338 = 11207717559546 := by decide
theorem cert_e2411624537338 : check e2411624537338 [[],[]] .smaller = true := by decide
def e2411624537910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2411624537910 : Closed e2411624537910 ∧ code e2411624537910 = 11207717560118 := by decide
theorem cert_e2411624537910 : check e2411624537910 [[],[]] .smaller = true := by decide
def e2411624537914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2411624537914 : Closed e2411624537914 ∧ code e2411624537914 = 11207717560122 := by decide
theorem cert_e2411624537914 : check e2411624537914 [[],[]] .smaller = true := by decide
def e2411624552686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2411624552686 : Closed e2411624552686 ∧ code e2411624552686 = 11207717574894 := by decide
theorem cert_e2411624552686 : check e2411624552686 [[],[]] .smaller = true := by decide
def e2411624552694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2411624552694 : Closed e2411624552694 ∧ code e2411624552694 = 11207717574902 := by decide
theorem cert_e2411624552694 : check e2411624552694 [[],[]] .smaller = true := by decide
def e2411624553246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2411624553246 : Closed e2411624553246 ∧ code e2411624553246 = 11207717575454 := by decide
theorem cert_e2411624553246 : check e2411624553246 [[],[]] .smaller = true := by decide
def e2411624553358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2411624553358 : Closed e2411624553358 ∧ code e2411624553358 = 11207717575566 := by decide
theorem cert_e2411624553358 : check e2411624553358 [[],[]] .smaller = true := by decide
def e2411624553406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e2411624553406 : Closed e2411624553406 ∧ code e2411624553406 = 11207717575614 := by decide
theorem cert_e2411624553406 : check e2411624553406 [[],[]] .three = true := by decide
def e2411624553454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e2411624553454 : Closed e2411624553454 ∧ code e2411624553454 = 11207717575662 := by decide
theorem cert_e2411624553454 : check e2411624553454 [[],[]] .three = true := by decide
def e2411624553582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2411624553582 : Closed e2411624553582 ∧ code e2411624553582 = 11207717575790 := by decide
theorem cert_e2411624553582 : check e2411624553582 [[],[]] .smaller = true := by decide
def e2411624553594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2411624553594 : Closed e2411624553594 ∧ code e2411624553594 = 11207717575802 := by decide
theorem cert_e2411624553594 : check e2411624553594 [[],[]] .smaller = true := by decide
def e2411624553758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2411624553758 : Closed e2411624553758 ∧ code e2411624553758 = 11207717575966 := by decide
theorem cert_e2411624553758 : check e2411624553758 [[],[]] .smaller = true := by decide
def e2411624553918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 4)))))))))
theorem wire_e2411624553918 : Closed e2411624553918 ∧ code e2411624553918 = 11207717576126 := by decide
theorem cert_e2411624553918 : check e2411624553918 [[],[]] .three = true := by decide
def e2411624553926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2411624553926 : Closed e2411624553926 ∧ code e2411624553926 = 11207717576134 := by decide
theorem cert_e2411624553926 : check e2411624553926 [[],[]] .smaller = true := by decide
def e2411624553974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 1)))))))))
theorem wire_e2411624553974 : Closed e2411624553974 ∧ code e2411624553974 = 11207717576182 := by decide
theorem cert_e2411624553974 : check e2411624553974 [[],[]] .three = true := by decide
def e2411624554038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2411624554038 : Closed e2411624554038 ∧ code e2411624554038 = 11207717576246 := by decide
theorem cert_e2411624554038 : check e2411624554038 [[],[]] .smaller = true := by decide
def e2411624554042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2411624554042 : Closed e2411624554042 ∧ code e2411624554042 = 11207717576250 := by decide
theorem cert_e2411624554042 : check e2411624554042 [[],[]] .smaller = true := by decide
def e2411624554126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2411624554126 : Closed e2411624554126 ∧ code e2411624554126 = 11207717576334 := by decide
theorem cert_e2411624554126 : check e2411624554126 [[],[]] .smaller = true := by decide
def e2411624554174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e2411624554174 : Closed e2411624554174 ∧ code e2411624554174 = 11207717576382 := by decide
theorem cert_e2411624554174 : check e2411624554174 [[],[]] .three = true := by decide
def e2411624554182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2411624554182 : Closed e2411624554182 ∧ code e2411624554182 = 11207717576390 := by decide
theorem cert_e2411624554182 : check e2411624554182 [[],[]] .smaller = true := by decide
def e2411624554234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e2411624554234 : Closed e2411624554234 ∧ code e2411624554234 = 11207717576442 := by decide
theorem cert_e2411624554234 : check e2411624554234 [[],[]] .three = true := by decide
def e2411624554414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e2411624554414 : Closed e2411624554414 ∧ code e2411624554414 = 11207717576622 := by decide
theorem cert_e2411624554414 : check e2411624554414 [[],[]] .three = true := by decide
def e2411624554422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 1)))))))))
theorem wire_e2411624554422 : Closed e2411624554422 ∧ code e2411624554422 = 11207717576630 := by decide
theorem cert_e2411624554422 : check e2411624554422 [[],[]] .three = true := by decide
def e2411624554426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e2411624554426 : Closed e2411624554426 ∧ code e2411624554426 = 11207717576634 := by decide
theorem cert_e2411624554426 : check e2411624554426 [[],[]] .three = true := by decide
def e2411624556318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2411624556318 : Closed e2411624556318 ∧ code e2411624556318 = 11207717578526 := by decide
theorem cert_e2411624556318 : check e2411624556318 [[],[]] .smaller = true := by decide
def e2411624556430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2411624556430 : Closed e2411624556430 ∧ code e2411624556430 = 11207717578638 := by decide
theorem cert_e2411624556430 : check e2411624556430 [[],[]] .smaller = true := by decide
def e2411624556478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e2411624556478 : Closed e2411624556478 ∧ code e2411624556478 = 11207717578686 := by decide
theorem cert_e2411624556478 : check e2411624556478 [[],[]] .three = true := by decide
def e2411624556526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e2411624556526 : Closed e2411624556526 ∧ code e2411624556526 = 11207717578734 := by decide
theorem cert_e2411624556526 : check e2411624556526 [[],[]] .three = true := by decide
def e2411624559390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2411624559390 : Closed e2411624559390 ∧ code e2411624559390 = 11207717581598 := by decide
theorem cert_e2411624559390 : check e2411624559390 [[],[]] .smaller = true := by decide
def e2411624559550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 4))))))))))
theorem wire_e2411624559550 : Closed e2411624559550 ∧ code e2411624559550 = 11207717581758 := by decide
theorem cert_e2411624559550 : check e2411624559550 [[],[]] .three = true := by decide
def e2411624559558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2411624559558 : Closed e2411624559558 ∧ code e2411624559558 = 11207717581766 := by decide
theorem cert_e2411624559558 : check e2411624559558 [[],[]] .smaller = true := by decide
def e2411624559606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 1))))))))))
theorem wire_e2411624559606 : Closed e2411624559606 ∧ code e2411624559606 = 11207717581814 := by decide
theorem cert_e2411624559606 : check e2411624559606 [[],[]] .three = true := by decide
def e2411624561038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2411624561038 : Closed e2411624561038 ∧ code e2411624561038 = 11207717583246 := by decide
theorem cert_e2411624561038 : check e2411624561038 [[],[]] .smaller = true := by decide
def e2411624561086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e2411624561086 : Closed e2411624561086 ∧ code e2411624561086 = 11207717583294 := by decide
theorem cert_e2411624561086 : check e2411624561086 [[],[]] .three = true := by decide
def e2411624561094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2411624561094 : Closed e2411624561094 ∧ code e2411624561094 = 11207717583302 := by decide
theorem cert_e2411624561094 : check e2411624561094 [[],[]] .smaller = true := by decide
def e2411624561146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e2411624561146 : Closed e2411624561146 ∧ code e2411624561146 = 11207717583354 := by decide
theorem cert_e2411624561146 : check e2411624561146 [[],[]] .three = true := by decide
def e2411624562286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411624562286 : Closed e2411624562286 ∧ code e2411624562286 = 11207717584494 := by decide
theorem cert_e2411624562286 : check e2411624562286 [[],[]] .three = true := by decide
def e2411624562294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411624562294 : Closed e2411624562294 ∧ code e2411624562294 = 11207717584502 := by decide
theorem cert_e2411624562294 : check e2411624562294 [[],[]] .three = true := by decide
def e2411624562298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411624562298 : Closed e2411624562298 ∧ code e2411624562298 = 11207717584506 := by decide
theorem cert_e2411624562298 : check e2411624562298 [[],[]] .three = true := by decide
def e2411624598382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2411624598382 : Closed e2411624598382 ∧ code e2411624598382 = 11207717620590 := by decide
theorem cert_e2411624598382 : check e2411624598382 [[],[]] .smaller = true := by decide
def e2411624598390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2411624598390 : Closed e2411624598390 ∧ code e2411624598390 = 11207717620598 := by decide
theorem cert_e2411624598390 : check e2411624598390 [[],[]] .smaller = true := by decide
end Blc.Floor43
