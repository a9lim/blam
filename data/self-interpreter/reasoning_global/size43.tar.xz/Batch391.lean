import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372750702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422372750702 : Closed e2422372750702 ∧ code e2422372750702 = 11218465772910 := by decide
theorem cert_e2422372750702 : check e2422372750702 [[],[]] .smaller = true := by decide
def e2422372750710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422372750710 : Closed e2422372750710 ∧ code e2422372750710 = 11218465772918 := by decide
theorem cert_e2422372750710 : check e2422372750710 [[],[]] .smaller = true := by decide
def e2422372750766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422372750766 : Closed e2422372750766 ∧ code e2422372750766 = 11218465772974 := by decide
theorem cert_e2422372750766 : check e2422372750766 [[],[]] .smaller = true := by decide
def e2422372750778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422372750778 : Closed e2422372750778 ∧ code e2422372750778 = 11218465772986 := by decide
theorem cert_e2422372750778 : check e2422372750778 [[],[]] .smaller = true := by decide
def e2422372750806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422372750806 : Closed e2422372750806 ∧ code e2422372750806 = 11218465773014 := by decide
theorem cert_e2422372750806 : check e2422372750806 [[],[]] .smaller = true := by decide
def e2422372750810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422372750810 : Closed e2422372750810 ∧ code e2422372750810 = 11218465773018 := by decide
theorem cert_e2422372750810 : check e2422372750810 [[],[]] .smaller = true := by decide
def e2422372751022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372751022 : Closed e2422372751022 ∧ code e2422372751022 = 11218465773230 := by decide
theorem cert_e2422372751022 : check e2422372751022 [[],[]] .smaller = true := by decide
def e2422372751034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372751034 : Closed e2422372751034 ∧ code e2422372751034 = 11218465773242 := by decide
theorem cert_e2422372751034 : check e2422372751034 [[],[]] .smaller = true := by decide
def e2422372751082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372751082 : Closed e2422372751082 ∧ code e2422372751082 = 11218465773290 := by decide
theorem cert_e2422372751082 : check e2422372751082 [[],[]] .smaller = true := by decide
def e2422372751190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372751190 : Closed e2422372751190 ∧ code e2422372751190 = 11218465773398 := by decide
theorem cert_e2422372751190 : check e2422372751190 [[],[]] .smaller = true := by decide
def e2422372751194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372751194 : Closed e2422372751194 ∧ code e2422372751194 = 11218465773402 := by decide
theorem cert_e2422372751194 : check e2422372751194 [[],[]] .smaller = true := by decide
def e2422372751210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372751210 : Closed e2422372751210 ∧ code e2422372751210 = 11218465773418 := by decide
theorem cert_e2422372751210 : check e2422372751210 [[],[]] .smaller = true := by decide
def e2422372752046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372752046 : Closed e2422372752046 ∧ code e2422372752046 = 11218465774254 := by decide
theorem cert_e2422372752046 : check e2422372752046 [[],[]] .smaller = true := by decide
def e2422372752058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372752058 : Closed e2422372752058 ∧ code e2422372752058 = 11218465774266 := by decide
theorem cert_e2422372752058 : check e2422372752058 [[],[]] .smaller = true := by decide
def e2422372752106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372752106 : Closed e2422372752106 ∧ code e2422372752106 = 11218465774314 := by decide
theorem cert_e2422372752106 : check e2422372752106 [[],[]] .smaller = true := by decide
def e2422372752298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372752298 : Closed e2422372752298 ∧ code e2422372752298 = 11218465774506 := by decide
theorem cert_e2422372752298 : check e2422372752298 [[],[]] .smaller = true := by decide
def e2422372752726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372752726 : Closed e2422372752726 ∧ code e2422372752726 = 11218465774934 := by decide
theorem cert_e2422372752726 : check e2422372752726 [[],[]] .smaller = true := by decide
def e2422372752730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372752730 : Closed e2422372752730 ∧ code e2422372752730 = 11218465774938 := by decide
theorem cert_e2422372752730 : check e2422372752730 [[],[]] .smaller = true := by decide
def e2422372752746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372752746 : Closed e2422372752746 ∧ code e2422372752746 = 11218465774954 := by decide
theorem cert_e2422372752746 : check e2422372752746 [[],[]] .smaller = true := by decide
def e2422372752810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372752810 : Closed e2422372752810 ∧ code e2422372752810 = 11218465775018 := by decide
theorem cert_e2422372752810 : check e2422372752810 [[],[]] .smaller = true := by decide
def e2422372756142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372756142 : Closed e2422372756142 ∧ code e2422372756142 = 11218465778350 := by decide
theorem cert_e2422372756142 : check e2422372756142 [[],[]] .smaller = true := by decide
def e2422372756154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372756154 : Closed e2422372756154 ∧ code e2422372756154 = 11218465778362 := by decide
theorem cert_e2422372756154 : check e2422372756154 [[],[]] .smaller = true := by decide
def e2422372756202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372756202 : Closed e2422372756202 ∧ code e2422372756202 = 11218465778410 := by decide
theorem cert_e2422372756202 : check e2422372756202 [[],[]] .smaller = true := by decide
def e2422372756394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372756394 : Closed e2422372756394 ∧ code e2422372756394 = 11218465778602 := by decide
theorem cert_e2422372756394 : check e2422372756394 [[],[]] .smaller = true := by decide
def e2422372757162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372757162 : Closed e2422372757162 ∧ code e2422372757162 = 11218465779370 := by decide
theorem cert_e2422372757162 : check e2422372757162 [[],[]] .smaller = true := by decide
def e2422372758870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372758870 : Closed e2422372758870 ∧ code e2422372758870 = 11218465781078 := by decide
theorem cert_e2422372758870 : check e2422372758870 [[],[]] .smaller = true := by decide
def e2422372758874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372758874 : Closed e2422372758874 ∧ code e2422372758874 = 11218465781082 := by decide
theorem cert_e2422372758874 : check e2422372758874 [[],[]] .smaller = true := by decide
def e2422372758890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372758890 : Closed e2422372758890 ∧ code e2422372758890 = 11218465781098 := by decide
theorem cert_e2422372758890 : check e2422372758890 [[],[]] .smaller = true := by decide
def e2422372758954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372758954 : Closed e2422372758954 ∧ code e2422372758954 = 11218465781162 := by decide
theorem cert_e2422372758954 : check e2422372758954 [[],[]] .smaller = true := by decide
def e2422372759210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372759210 : Closed e2422372759210 ∧ code e2422372759210 = 11218465781418 := by decide
theorem cert_e2422372759210 : check e2422372759210 [[],[]] .smaller = true := by decide
def e2422372762990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422372762990 : Closed e2422372762990 ∧ code e2422372762990 = 11218465785198 := by decide
theorem cert_e2422372762990 : check e2422372762990 [[],[]] .smaller = true := by decide
def e2422372762998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422372762998 : Closed e2422372762998 ∧ code e2422372762998 = 11218465785206 := by decide
theorem cert_e2422372762998 : check e2422372762998 [[],[]] .smaller = true := by decide
def e2422372763054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422372763054 : Closed e2422372763054 ∧ code e2422372763054 = 11218465785262 := by decide
theorem cert_e2422372763054 : check e2422372763054 [[],[]] .smaller = true := by decide
def e2422372763066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422372763066 : Closed e2422372763066 ∧ code e2422372763066 = 11218465785274 := by decide
theorem cert_e2422372763066 : check e2422372763066 [[],[]] .smaller = true := by decide
def e2422372763094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422372763094 : Closed e2422372763094 ∧ code e2422372763094 = 11218465785302 := by decide
theorem cert_e2422372763094 : check e2422372763094 [[],[]] .smaller = true := by decide
def e2422372763098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422372763098 : Closed e2422372763098 ∧ code e2422372763098 = 11218465785306 := by decide
theorem cert_e2422372763098 : check e2422372763098 [[],[]] .smaller = true := by decide
def e2422372767198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2422372767198 : Closed e2422372767198 ∧ code e2422372767198 = 11218465789406 := by decide
theorem cert_e2422372767198 : check e2422372767198 [[],[]] .three = true := by decide
def e2422372767214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2422372767214 : Closed e2422372767214 ∧ code e2422372767214 = 11218465789422 := by decide
theorem cert_e2422372767214 : check e2422372767214 [[],[]] .three = true := by decide
def e2422372767454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2422372767454 : Closed e2422372767454 ∧ code e2422372767454 = 11218465789662 := by decide
theorem cert_e2422372767454 : check e2422372767454 [[],[]] .three = true := by decide
def e2422372767470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2422372767470 : Closed e2422372767470 ∧ code e2422372767470 = 11218465789678 := by decide
theorem cert_e2422372767470 : check e2422372767470 [[],[]] .smaller = true := by decide
def e2422372767478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2422372767478 : Closed e2422372767478 ∧ code e2422372767478 = 11218465789686 := by decide
theorem cert_e2422372767478 : check e2422372767478 [[],[]] .three = true := by decide
def e2422372767582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2422372767582 : Closed e2422372767582 ∧ code e2422372767582 = 11218465789790 := by decide
theorem cert_e2422372767582 : check e2422372767582 [[],[]] .three = true := by decide
def e2422372767598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2422372767598 : Closed e2422372767598 ∧ code e2422372767598 = 11218465789806 := by decide
theorem cert_e2422372767598 : check e2422372767598 [[],[]] .smaller = true := by decide
def e2422372767606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2422372767606 : Closed e2422372767606 ∧ code e2422372767606 = 11218465789814 := by decide
theorem cert_e2422372767606 : check e2422372767606 [[],[]] .smaller = true := by decide
def e2422372767610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2422372767610 : Closed e2422372767610 ∧ code e2422372767610 = 11218465789818 := by decide
theorem cert_e2422372767610 : check e2422372767610 [[],[]] .three = true := by decide
def e2422372767662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2422372767662 : Closed e2422372767662 ∧ code e2422372767662 = 11218465789870 := by decide
theorem cert_e2422372767662 : check e2422372767662 [[],[]] .three = true := by decide
def e2422372767670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2422372767670 : Closed e2422372767670 ∧ code e2422372767670 = 11218465789878 := by decide
theorem cert_e2422372767670 : check e2422372767670 [[],[]] .three = true := by decide
def e2422372767674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2422372767674 : Closed e2422372767674 ∧ code e2422372767674 = 11218465789882 := by decide
theorem cert_e2422372767674 : check e2422372767674 [[],[]] .three = true := by decide
def e2422372768478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2422372768478 : Closed e2422372768478 ∧ code e2422372768478 = 11218465790686 := by decide
theorem cert_e2422372768478 : check e2422372768478 [[],[]] .three = true := by decide
def e2422372768502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2422372768502 : Closed e2422372768502 ∧ code e2422372768502 = 11218465790710 := by decide
theorem cert_e2422372768502 : check e2422372768502 [[],[]] .three = true := by decide
def e2422372768606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2422372768606 : Closed e2422372768606 ∧ code e2422372768606 = 11218465790814 := by decide
theorem cert_e2422372768606 : check e2422372768606 [[],[]] .three = true := by decide
def e2422372768622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2422372768622 : Closed e2422372768622 ∧ code e2422372768622 = 11218465790830 := by decide
theorem cert_e2422372768622 : check e2422372768622 [[],[]] .smaller = true := by decide
def e2422372768630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2422372768630 : Closed e2422372768630 ∧ code e2422372768630 = 11218465790838 := by decide
theorem cert_e2422372768630 : check e2422372768630 [[],[]] .smaller = true := by decide
def e2422372768634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2422372768634 : Closed e2422372768634 ∧ code e2422372768634 = 11218465790842 := by decide
theorem cert_e2422372768634 : check e2422372768634 [[],[]] .three = true := by decide
def e2422372768694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2422372768694 : Closed e2422372768694 ∧ code e2422372768694 = 11218465790902 := by decide
theorem cert_e2422372768694 : check e2422372768694 [[],[]] .smaller = true := by decide
def e2422372768726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2422372768726 : Closed e2422372768726 ∧ code e2422372768726 = 11218465790934 := by decide
theorem cert_e2422372768726 : check e2422372768726 [[],[]] .three = true := by decide
def e2422372768730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2422372768730 : Closed e2422372768730 ∧ code e2422372768730 = 11218465790938 := by decide
theorem cert_e2422372768730 : check e2422372768730 [[],[]] .three = true := by decide
def e2422372769118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2422372769118 : Closed e2422372769118 ∧ code e2422372769118 = 11218465791326 := by decide
theorem cert_e2422372769118 : check e2422372769118 [[],[]] .three = true := by decide
def e2422372769134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422372769134 : Closed e2422372769134 ∧ code e2422372769134 = 11218465791342 := by decide
theorem cert_e2422372769134 : check e2422372769134 [[],[]] .smaller = true := by decide
def e2422372769142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422372769142 : Closed e2422372769142 ∧ code e2422372769142 = 11218465791350 := by decide
theorem cert_e2422372769142 : check e2422372769142 [[],[]] .smaller = true := by decide
def e2422372769146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2422372769146 : Closed e2422372769146 ∧ code e2422372769146 = 11218465791354 := by decide
theorem cert_e2422372769146 : check e2422372769146 [[],[]] .three = true := by decide
def e2422372769198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422372769198 : Closed e2422372769198 ∧ code e2422372769198 = 11218465791406 := by decide
theorem cert_e2422372769198 : check e2422372769198 [[],[]] .smaller = true := by decide
def e2422372769210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422372769210 : Closed e2422372769210 ∧ code e2422372769210 = 11218465791418 := by decide
theorem cert_e2422372769210 : check e2422372769210 [[],[]] .smaller = true := by decide
def e2422372769238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422372769238 : Closed e2422372769238 ∧ code e2422372769238 = 11218465791446 := by decide
theorem cert_e2422372769238 : check e2422372769238 [[],[]] .smaller = true := by decide
def e2422372769242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422372769242 : Closed e2422372769242 ∧ code e2422372769242 = 11218465791450 := by decide
theorem cert_e2422372769242 : check e2422372769242 [[],[]] .smaller = true := by decide
def e2422372769258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2422372769258 : Closed e2422372769258 ∧ code e2422372769258 = 11218465791466 := by decide
theorem cert_e2422372769258 : check e2422372769258 [[],[]] .three = true := by decide
def e2422372769462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2422372769462 : Closed e2422372769462 ∧ code e2422372769462 = 11218465791670 := by decide
theorem cert_e2422372769462 : check e2422372769462 [[],[]] .smaller = true := by decide
def e2422372769494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2422372769494 : Closed e2422372769494 ∧ code e2422372769494 = 11218465791702 := by decide
theorem cert_e2422372769494 : check e2422372769494 [[],[]] .smaller = true := by decide
def e2422372769498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2422372769498 : Closed e2422372769498 ∧ code e2422372769498 = 11218465791706 := by decide
theorem cert_e2422372769498 : check e2422372769498 [[],[]] .smaller = true := by decide
def e2422372769622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372769622 : Closed e2422372769622 ∧ code e2422372769622 = 11218465791830 := by decide
theorem cert_e2422372769622 : check e2422372769622 [[],[]] .three = true := by decide
def e2422372769626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372769626 : Closed e2422372769626 ∧ code e2422372769626 = 11218465791834 := by decide
theorem cert_e2422372769626 : check e2422372769626 [[],[]] .three = true := by decide
def e2422372769642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372769642 : Closed e2422372769642 ∧ code e2422372769642 = 11218465791850 := by decide
theorem cert_e2422372769642 : check e2422372769642 [[],[]] .three = true := by decide
def e2422372775278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422372775278 : Closed e2422372775278 ∧ code e2422372775278 = 11218465797486 := by decide
theorem cert_e2422372775278 : check e2422372775278 [[],[]] .smaller = true := by decide
def e2422372775286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422372775286 : Closed e2422372775286 ∧ code e2422372775286 = 11218465797494 := by decide
theorem cert_e2422372775286 : check e2422372775286 [[],[]] .smaller = true := by decide
def e2422372775342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422372775342 : Closed e2422372775342 ∧ code e2422372775342 = 11218465797550 := by decide
theorem cert_e2422372775342 : check e2422372775342 [[],[]] .smaller = true := by decide
def e2422372775354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422372775354 : Closed e2422372775354 ∧ code e2422372775354 = 11218465797562 := by decide
theorem cert_e2422372775354 : check e2422372775354 [[],[]] .smaller = true := by decide
def e2422372775382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422372775382 : Closed e2422372775382 ∧ code e2422372775382 = 11218465797590 := by decide
theorem cert_e2422372775382 : check e2422372775382 [[],[]] .smaller = true := by decide
def e2422372775386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422372775386 : Closed e2422372775386 ∧ code e2422372775386 = 11218465797594 := by decide
theorem cert_e2422372775386 : check e2422372775386 [[],[]] .smaller = true := by decide
def e2422372775598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372775598 : Closed e2422372775598 ∧ code e2422372775598 = 11218465797806 := by decide
theorem cert_e2422372775598 : check e2422372775598 [[],[]] .smaller = true := by decide
def e2422372775610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372775610 : Closed e2422372775610 ∧ code e2422372775610 = 11218465797818 := by decide
theorem cert_e2422372775610 : check e2422372775610 [[],[]] .smaller = true := by decide
def e2422372775658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372775658 : Closed e2422372775658 ∧ code e2422372775658 = 11218465797866 := by decide
theorem cert_e2422372775658 : check e2422372775658 [[],[]] .smaller = true := by decide
def e2422372775766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372775766 : Closed e2422372775766 ∧ code e2422372775766 = 11218465797974 := by decide
theorem cert_e2422372775766 : check e2422372775766 [[],[]] .smaller = true := by decide
def e2422372775770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372775770 : Closed e2422372775770 ∧ code e2422372775770 = 11218465797978 := by decide
theorem cert_e2422372775770 : check e2422372775770 [[],[]] .smaller = true := by decide
def e2422372775786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372775786 : Closed e2422372775786 ∧ code e2422372775786 = 11218465797994 := by decide
theorem cert_e2422372775786 : check e2422372775786 [[],[]] .smaller = true := by decide
def e2422372776622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372776622 : Closed e2422372776622 ∧ code e2422372776622 = 11218465798830 := by decide
theorem cert_e2422372776622 : check e2422372776622 [[],[]] .smaller = true := by decide
def e2422372776634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372776634 : Closed e2422372776634 ∧ code e2422372776634 = 11218465798842 := by decide
theorem cert_e2422372776634 : check e2422372776634 [[],[]] .smaller = true := by decide
def e2422372776682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372776682 : Closed e2422372776682 ∧ code e2422372776682 = 11218465798890 := by decide
theorem cert_e2422372776682 : check e2422372776682 [[],[]] .smaller = true := by decide
def e2422372776874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372776874 : Closed e2422372776874 ∧ code e2422372776874 = 11218465799082 := by decide
theorem cert_e2422372776874 : check e2422372776874 [[],[]] .smaller = true := by decide
def e2422372777302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372777302 : Closed e2422372777302 ∧ code e2422372777302 = 11218465799510 := by decide
theorem cert_e2422372777302 : check e2422372777302 [[],[]] .smaller = true := by decide
def e2422372777306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372777306 : Closed e2422372777306 ∧ code e2422372777306 = 11218465799514 := by decide
theorem cert_e2422372777306 : check e2422372777306 [[],[]] .smaller = true := by decide
def e2422372777322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372777322 : Closed e2422372777322 ∧ code e2422372777322 = 11218465799530 := by decide
theorem cert_e2422372777322 : check e2422372777322 [[],[]] .smaller = true := by decide
def e2422372777386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372777386 : Closed e2422372777386 ∧ code e2422372777386 = 11218465799594 := by decide
theorem cert_e2422372777386 : check e2422372777386 [[],[]] .smaller = true := by decide
def e2422372778350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372778350 : Closed e2422372778350 ∧ code e2422372778350 = 11218465800558 := by decide
theorem cert_e2422372778350 : check e2422372778350 [[],[]] .smaller = true := by decide
def e2422372778358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372778358 : Closed e2422372778358 ∧ code e2422372778358 = 11218465800566 := by decide
theorem cert_e2422372778358 : check e2422372778358 [[],[]] .smaller = true := by decide
def e2422372779486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e2422372779486 : Closed e2422372779486 ∧ code e2422372779486 = 11218465801694 := by decide
theorem cert_e2422372779486 : check e2422372779486 [[],[]] .three = true := by decide
def e2422372779502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e2422372779502 : Closed e2422372779502 ∧ code e2422372779502 = 11218465801710 := by decide
theorem cert_e2422372779502 : check e2422372779502 [[],[]] .three = true := by decide
def e2422372779742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e2422372779742 : Closed e2422372779742 ∧ code e2422372779742 = 11218465801950 := by decide
theorem cert_e2422372779742 : check e2422372779742 [[],[]] .three = true := by decide
def e2422372779766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e2422372779766 : Closed e2422372779766 ∧ code e2422372779766 = 11218465801974 := by decide
theorem cert_e2422372779766 : check e2422372779766 [[],[]] .three = true := by decide
def e2422372779870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e2422372779870 : Closed e2422372779870 ∧ code e2422372779870 = 11218465802078 := by decide
theorem cert_e2422372779870 : check e2422372779870 [[],[]] .three = true := by decide
def e2422372779886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e2422372779886 : Closed e2422372779886 ∧ code e2422372779886 = 11218465802094 := by decide
theorem cert_e2422372779886 : check e2422372779886 [[],[]] .smaller = true := by decide
def e2422372779894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e2422372779894 : Closed e2422372779894 ∧ code e2422372779894 = 11218465802102 := by decide
theorem cert_e2422372779894 : check e2422372779894 [[],[]] .smaller = true := by decide
def e2422372779898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e2422372779898 : Closed e2422372779898 ∧ code e2422372779898 = 11218465802106 := by decide
theorem cert_e2422372779898 : check e2422372779898 [[],[]] .three = true := by decide
def e2422372779958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e2422372779958 : Closed e2422372779958 ∧ code e2422372779958 = 11218465802166 := by decide
theorem cert_e2422372779958 : check e2422372779958 [[],[]] .smaller = true := by decide
def e2422372779990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 0)) (.var 1)))))))
theorem wire_e2422372779990 : Closed e2422372779990 ∧ code e2422372779990 = 11218465802198 := by decide
theorem cert_e2422372779990 : check e2422372779990 [[],[]] .three = true := by decide
def e2422372779994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 1)) (.var 0)))))))
theorem wire_e2422372779994 : Closed e2422372779994 ∧ code e2422372779994 = 11218465802202 := by decide
theorem cert_e2422372779994 : check e2422372779994 [[],[]] .three = true := by decide
def e2422372781422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2422372781422 : Closed e2422372781422 ∧ code e2422372781422 = 11218465803630 := by decide
theorem cert_e2422372781422 : check e2422372781422 [[],[]] .smaller = true := by decide
def e2422372781430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2422372781430 : Closed e2422372781430 ∧ code e2422372781430 = 11218465803638 := by decide
theorem cert_e2422372781430 : check e2422372781430 [[],[]] .smaller = true := by decide
def e2422372781486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2422372781486 : Closed e2422372781486 ∧ code e2422372781486 = 11218465803694 := by decide
theorem cert_e2422372781486 : check e2422372781486 [[],[]] .smaller = true := by decide
def e2422372781498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2422372781498 : Closed e2422372781498 ∧ code e2422372781498 = 11218465803706 := by decide
theorem cert_e2422372781498 : check e2422372781498 [[],[]] .smaller = true := by decide
def e2422372781526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2422372781526 : Closed e2422372781526 ∧ code e2422372781526 = 11218465803734 := by decide
theorem cert_e2422372781526 : check e2422372781526 [[],[]] .smaller = true := by decide
def e2422372781530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2422372781530 : Closed e2422372781530 ∧ code e2422372781530 = 11218465803738 := by decide
theorem cert_e2422372781530 : check e2422372781530 [[],[]] .smaller = true := by decide
def e2422372781742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372781742 : Closed e2422372781742 ∧ code e2422372781742 = 11218465803950 := by decide
theorem cert_e2422372781742 : check e2422372781742 [[],[]] .smaller = true := by decide
def e2422372781754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372781754 : Closed e2422372781754 ∧ code e2422372781754 = 11218465803962 := by decide
theorem cert_e2422372781754 : check e2422372781754 [[],[]] .smaller = true := by decide
def e2422372781802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372781802 : Closed e2422372781802 ∧ code e2422372781802 = 11218465804010 := by decide
theorem cert_e2422372781802 : check e2422372781802 [[],[]] .smaller = true := by decide
def e2422372781910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422372781910 : Closed e2422372781910 ∧ code e2422372781910 = 11218465804118 := by decide
theorem cert_e2422372781910 : check e2422372781910 [[],[]] .smaller = true := by decide
def e2422372781914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422372781914 : Closed e2422372781914 ∧ code e2422372781914 = 11218465804122 := by decide
theorem cert_e2422372781914 : check e2422372781914 [[],[]] .smaller = true := by decide
def e2422372781930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2422372781930 : Closed e2422372781930 ∧ code e2422372781930 = 11218465804138 := by decide
theorem cert_e2422372781930 : check e2422372781930 [[],[]] .smaller = true := by decide
def e2422372782558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2422372782558 : Closed e2422372782558 ∧ code e2422372782558 = 11218465804766 := by decide
theorem cert_e2422372782558 : check e2422372782558 [[],[]] .three = true := by decide
def e2422372782582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2422372782582 : Closed e2422372782582 ∧ code e2422372782582 = 11218465804790 := by decide
theorem cert_e2422372782582 : check e2422372782582 [[],[]] .three = true := by decide
def e2422372782958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422372782958 : Closed e2422372782958 ∧ code e2422372782958 = 11218465805166 := by decide
theorem cert_e2422372782958 : check e2422372782958 [[],[]] .smaller = true := by decide
def e2422372782966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422372782966 : Closed e2422372782966 ∧ code e2422372782966 = 11218465805174 := by decide
theorem cert_e2422372782966 : check e2422372782966 [[],[]] .smaller = true := by decide
def e2422372783022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422372783022 : Closed e2422372783022 ∧ code e2422372783022 = 11218465805230 := by decide
theorem cert_e2422372783022 : check e2422372783022 [[],[]] .smaller = true := by decide
def e2422372783034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422372783034 : Closed e2422372783034 ∧ code e2422372783034 = 11218465805242 := by decide
theorem cert_e2422372783034 : check e2422372783034 [[],[]] .smaller = true := by decide
def e2422372783062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422372783062 : Closed e2422372783062 ∧ code e2422372783062 = 11218465805270 := by decide
theorem cert_e2422372783062 : check e2422372783062 [[],[]] .smaller = true := by decide
def e2422372783066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422372783066 : Closed e2422372783066 ∧ code e2422372783066 = 11218465805274 := by decide
theorem cert_e2422372783066 : check e2422372783066 [[],[]] .smaller = true := by decide
def e2422372783342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372783342 : Closed e2422372783342 ∧ code e2422372783342 = 11218465805550 := by decide
theorem cert_e2422372783342 : check e2422372783342 [[],[]] .smaller = true := by decide
def e2422372783350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372783350 : Closed e2422372783350 ∧ code e2422372783350 = 11218465805558 := by decide
theorem cert_e2422372783350 : check e2422372783350 [[],[]] .smaller = true := by decide
def e2422372783678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2422372783678 : Closed e2422372783678 ∧ code e2422372783678 = 11218465805886 := by decide
theorem cert_e2422372783678 : check e2422372783678 [[],[]] .three = true := by decide
def e2422372783726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372783726 : Closed e2422372783726 ∧ code e2422372783726 = 11218465805934 := by decide
theorem cert_e2422372783726 : check e2422372783726 [[],[]] .smaller = true := by decide
def e2422372783738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372783738 : Closed e2422372783738 ∧ code e2422372783738 = 11218465805946 := by decide
theorem cert_e2422372783738 : check e2422372783738 [[],[]] .smaller = true := by decide
def e2422372783926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372783926 : Closed e2422372783926 ∧ code e2422372783926 = 11218465806134 := by decide
theorem cert_e2422372783926 : check e2422372783926 [[],[]] .smaller = true := by decide
def e2422372783930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372783930 : Closed e2422372783930 ∧ code e2422372783930 = 11218465806138 := by decide
theorem cert_e2422372783930 : check e2422372783930 [[],[]] .smaller = true := by decide
def e2422372784014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2422372784014 : Closed e2422372784014 ∧ code e2422372784014 = 11218465806222 := by decide
theorem cert_e2422372784014 : check e2422372784014 [[],[]] .three = true := by decide
def e2422372784174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372784174 : Closed e2422372784174 ∧ code e2422372784174 = 11218465806382 := by decide
theorem cert_e2422372784174 : check e2422372784174 [[],[]] .smaller = true := by decide
def e2422372784350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422372784350 : Closed e2422372784350 ∧ code e2422372784350 = 11218465806558 := by decide
theorem cert_e2422372784350 : check e2422372784350 [[],[]] .three = true := by decide
def e2422372784366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422372784366 : Closed e2422372784366 ∧ code e2422372784366 = 11218465806574 := by decide
theorem cert_e2422372784366 : check e2422372784366 [[],[]] .smaller = true := by decide
def e2422372784374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422372784374 : Closed e2422372784374 ∧ code e2422372784374 = 11218465806582 := by decide
theorem cert_e2422372784374 : check e2422372784374 [[],[]] .smaller = true := by decide
def e2422372784378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422372784378 : Closed e2422372784378 ∧ code e2422372784378 = 11218465806586 := by decide
theorem cert_e2422372784378 : check e2422372784378 [[],[]] .three = true := by decide
def e2422372784558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422372784558 : Closed e2422372784558 ∧ code e2422372784558 = 11218465806766 := by decide
theorem cert_e2422372784558 : check e2422372784558 [[],[]] .smaller = true := by decide
def e2422372784570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422372784570 : Closed e2422372784570 ∧ code e2422372784570 = 11218465806778 := by decide
theorem cert_e2422372784570 : check e2422372784570 [[],[]] .smaller = true := by decide
def e2422372784618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422372784618 : Closed e2422372784618 ∧ code e2422372784618 = 11218465806826 := by decide
theorem cert_e2422372784618 : check e2422372784618 [[],[]] .smaller = true := by decide
def e2422372784702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422372784702 : Closed e2422372784702 ∧ code e2422372784702 = 11218465806910 := by decide
theorem cert_e2422372784702 : check e2422372784702 [[],[]] .three = true := by decide
def e2422372784750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372784750 : Closed e2422372784750 ∧ code e2422372784750 = 11218465806958 := by decide
theorem cert_e2422372784750 : check e2422372784750 [[],[]] .smaller = true := by decide
def e2422372784762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372784762 : Closed e2422372784762 ∧ code e2422372784762 = 11218465806970 := by decide
theorem cert_e2422372784762 : check e2422372784762 [[],[]] .smaller = true := by decide
def e2422372784926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422372784926 : Closed e2422372784926 ∧ code e2422372784926 = 11218465807134 := by decide
theorem cert_e2422372784926 : check e2422372784926 [[],[]] .smaller = true := by decide
def e2422372785026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372785026 : Closed e2422372785026 ∧ code e2422372785026 = 11218465807234 := by decide
theorem cert_e2422372785026 : check e2422372785026 [[],[]] .smaller = true := by decide
def e2422372785038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422372785038 : Closed e2422372785038 ∧ code e2422372785038 = 11218465807246 := by decide
theorem cert_e2422372785038 : check e2422372785038 [[],[]] .smaller = true := by decide
def e2422372785050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372785050 : Closed e2422372785050 ∧ code e2422372785050 = 11218465807258 := by decide
theorem cert_e2422372785050 : check e2422372785050 [[],[]] .smaller = true := by decide
def e2422372785094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422372785094 : Closed e2422372785094 ∧ code e2422372785094 = 11218465807302 := by decide
theorem cert_e2422372785094 : check e2422372785094 [[],[]] .three = true := by decide
def e2422372785118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.var 3)))))))
theorem wire_e2422372785118 : Closed e2422372785118 ∧ code e2422372785118 = 11218465807326 := by decide
theorem cert_e2422372785118 : check e2422372785118 [[],[]] .three = true := by decide
def e2422372785174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422372785174 : Closed e2422372785174 ∧ code e2422372785174 = 11218465807382 := by decide
theorem cert_e2422372785174 : check e2422372785174 [[],[]] .smaller = true := by decide
def e2422372785246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372785246 : Closed e2422372785246 ∧ code e2422372785246 = 11218465807454 := by decide
theorem cert_e2422372785246 : check e2422372785246 [[],[]] .three = true := by decide
def e2422372785270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2422372785270 : Closed e2422372785270 ∧ code e2422372785270 = 11218465807478 := by decide
theorem cert_e2422372785270 : check e2422372785270 [[],[]] .smaller = true := by decide
def e2422372785366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422372785366 : Closed e2422372785366 ∧ code e2422372785366 = 11218465807574 := by decide
theorem cert_e2422372785366 : check e2422372785366 [[],[]] .smaller = true := by decide
def e2422372785370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422372785370 : Closed e2422372785370 ∧ code e2422372785370 = 11218465807578 := by decide
theorem cert_e2422372785370 : check e2422372785370 [[],[]] .smaller = true := by decide
def e2422372785386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422372785386 : Closed e2422372785386 ∧ code e2422372785386 = 11218465807594 := by decide
theorem cert_e2422372785386 : check e2422372785386 [[],[]] .smaller = true := by decide
def e2422372785462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372785462 : Closed e2422372785462 ∧ code e2422372785462 = 11218465807670 := by decide
theorem cert_e2422372785462 : check e2422372785462 [[],[]] .smaller = true := by decide
def e2422372785466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372785466 : Closed e2422372785466 ∧ code e2422372785466 = 11218465807674 := by decide
theorem cert_e2422372785466 : check e2422372785466 [[],[]] .smaller = true := by decide
def e2422372785538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372785538 : Closed e2422372785538 ∧ code e2422372785538 = 11218465807746 := by decide
theorem cert_e2422372785538 : check e2422372785538 [[],[]] .smaller = true := by decide
def e2422372785550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2422372785550 : Closed e2422372785550 ∧ code e2422372785550 = 11218465807758 := by decide
theorem cert_e2422372785550 : check e2422372785550 [[],[]] .smaller = true := by decide
end Blc.Floor43
