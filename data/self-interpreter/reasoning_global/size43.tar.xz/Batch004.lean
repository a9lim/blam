import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598476946746 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598476946746 : Closed e598476946746 ∧ code e598476946746 = 9394569968954 := by decide
theorem cert_e598476946746 : check e598476946746 [[.under],[.under,.left]] .chain = true := by decide
def e598476946842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e598476946842 : Closed e598476946842 ∧ code e598476946842 = 9394569969050 := by decide
theorem cert_e598476946842 : check e598476946842 [[.under],[.under,.left]] .chain = true := by decide
def e598476953310 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e598476953310 : Closed e598476953310 ∧ code e598476953310 = 9394569975518 := by decide
theorem cert_e598476953310 : check e598476953310 [[.under],[.under,.left]] .chain = true := by decide
def e598476953334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e598476953334 : Closed e598476953334 ∧ code e598476953334 = 9394569975542 := by decide
theorem cert_e598476953334 : check e598476953334 [[.under],[.under,.left]] .chain = true := by decide
def e598476953438 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e598476953438 : Closed e598476953438 ∧ code e598476953438 = 9394569975646 := by decide
theorem cert_e598476953438 : check e598476953438 [[.under],[.under,.left]] .chain = true := by decide
def e598476953454 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e598476953454 : Closed e598476953454 ∧ code e598476953454 = 9394569975662 := by decide
theorem cert_e598476953454 : check e598476953454 [[.under],[.under,.left]] .smaller = true := by decide
def e598476953462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e598476953462 : Closed e598476953462 ∧ code e598476953462 = 9394569975670 := by decide
theorem cert_e598476953462 : check e598476953462 [[.under],[.under,.left]] .smaller = true := by decide
def e598476953466 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e598476953466 : Closed e598476953466 ∧ code e598476953466 = 9394569975674 := by decide
theorem cert_e598476953466 : check e598476953466 [[.under],[.under,.left]] .chain = true := by decide
def e598476953526 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e598476953526 : Closed e598476953526 ∧ code e598476953526 = 9394569975734 := by decide
theorem cert_e598476953526 : check e598476953526 [[.under],[.under,.left]] .smaller = true := by decide
def e598476953558 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e598476953558 : Closed e598476953558 ∧ code e598476953558 = 9394569975766 := by decide
theorem cert_e598476953558 : check e598476953558 [[.under],[.under,.left]] .chain = true := by decide
def e598476953562 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e598476953562 : Closed e598476953562 ∧ code e598476953562 = 9394569975770 := by decide
theorem cert_e598476953562 : check e598476953562 [[.under],[.under,.left]] .chain = true := by decide
def e598476954078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e598476954078 : Closed e598476954078 ∧ code e598476954078 = 9394569976286 := by decide
theorem cert_e598476954078 : check e598476954078 [[.under],[.under,.left]] .chain = true := by decide
def e598476954102 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e598476954102 : Closed e598476954102 ∧ code e598476954102 = 9394569976310 := by decide
theorem cert_e598476954102 : check e598476954102 [[.under],[.under,.left]] .chain = true := by decide
def e598476954846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e598476954846 : Closed e598476954846 ∧ code e598476954846 = 9394569977054 := by decide
theorem cert_e598476954846 : check e598476954846 [[.under],[.under,.left]] .chain = true := by decide
def e598476954862 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e598476954862 : Closed e598476954862 ∧ code e598476954862 = 9394569977070 := by decide
theorem cert_e598476954862 : check e598476954862 [[.under],[.under,.left]] .smaller = true := by decide
def e598476954870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e598476954870 : Closed e598476954870 ∧ code e598476954870 = 9394569977078 := by decide
theorem cert_e598476954870 : check e598476954870 [[.under],[.under,.left]] .smaller = true := by decide
def e598476954874 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e598476954874 : Closed e598476954874 ∧ code e598476954874 = 9394569977082 := by decide
theorem cert_e598476954874 : check e598476954874 [[.under],[.under,.left]] .chain = true := by decide
def e598476955254 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e598476955254 : Closed e598476955254 ∧ code e598476955254 = 9394569977462 := by decide
theorem cert_e598476955254 : check e598476955254 [[.under],[.under,.left]] .smaller = true := by decide
def e598476955446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e598476955446 : Closed e598476955446 ∧ code e598476955446 = 9394569977654 := by decide
theorem cert_e598476955446 : check e598476955446 [[.under],[.under,.left]] .chain = true := by decide
def e598476955450 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e598476955450 : Closed e598476955450 ∧ code e598476955450 = 9394569977658 := by decide
theorem cert_e598476955450 : check e598476955450 [[.under],[.under,.left]] .chain = true := by decide
def e598476966750 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e598476966750 : Closed e598476966750 ∧ code e598476966750 = 9394569988958 := by decide
theorem cert_e598476966750 : check e598476966750 [[.under],[.under,.left]] .chain = true := by decide
def e598476966766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598476966766 : Closed e598476966766 ∧ code e598476966766 = 9394569988974 := by decide
theorem cert_e598476966766 : check e598476966766 [[.under],[.under,.left]] .smaller = true := by decide
def e598476966774 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598476966774 : Closed e598476966774 ∧ code e598476966774 = 9394569988982 := by decide
theorem cert_e598476966774 : check e598476966774 [[.under],[.under,.left]] .smaller = true := by decide
def e598476966778 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e598476966778 : Closed e598476966778 ∧ code e598476966778 = 9394569988986 := by decide
theorem cert_e598476966778 : check e598476966778 [[.under],[.under,.left]] .chain = true := by decide
def e598476966830 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598476966830 : Closed e598476966830 ∧ code e598476966830 = 9394569989038 := by decide
theorem cert_e598476966830 : check e598476966830 [[.under],[.under,.left]] .smaller = true := by decide
def e598476966842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598476966842 : Closed e598476966842 ∧ code e598476966842 = 9394569989050 := by decide
theorem cert_e598476966842 : check e598476966842 [[.under],[.under,.left]] .smaller = true := by decide
def e598476966870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598476966870 : Closed e598476966870 ∧ code e598476966870 = 9394569989078 := by decide
theorem cert_e598476966870 : check e598476966870 [[.under],[.under,.left]] .smaller = true := by decide
def e598476966874 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598476966874 : Closed e598476966874 ∧ code e598476966874 = 9394569989082 := by decide
theorem cert_e598476966874 : check e598476966874 [[.under],[.under,.left]] .smaller = true := by decide
def e598476966890 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e598476966890 : Closed e598476966890 ∧ code e598476966890 = 9394569989098 := by decide
theorem cert_e598476966890 : check e598476966890 [[.under],[.under,.left]] .chain = true := by decide
def e598476967134 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e598476967134 : Closed e598476967134 ∧ code e598476967134 = 9394569989342 := by decide
theorem cert_e598476967134 : check e598476967134 [[.under],[.under,.left]] .chain = true := by decide
def e598476967150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598476967150 : Closed e598476967150 ∧ code e598476967150 = 9394569989358 := by decide
theorem cert_e598476967150 : check e598476967150 [[.under],[.under,.left]] .smaller = true := by decide
def e598476967158 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598476967158 : Closed e598476967158 ∧ code e598476967158 = 9394569989366 := by decide
theorem cert_e598476967158 : check e598476967158 [[.under],[.under,.left]] .smaller = true := by decide
def e598476967162 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e598476967162 : Closed e598476967162 ∧ code e598476967162 = 9394569989370 := by decide
theorem cert_e598476967162 : check e598476967162 [[.under],[.under,.left]] .chain = true := by decide
def e598476967534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598476967534 : Closed e598476967534 ∧ code e598476967534 = 9394569989742 := by decide
theorem cert_e598476967534 : check e598476967534 [[.under],[.under,.left]] .smaller = true := by decide
def e598476967546 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598476967546 : Closed e598476967546 ∧ code e598476967546 = 9394569989754 := by decide
theorem cert_e598476967546 : check e598476967546 [[.under],[.under,.left]] .smaller = true := by decide
def e598476967734 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598476967734 : Closed e598476967734 ∧ code e598476967734 = 9394569989942 := by decide
theorem cert_e598476967734 : check e598476967734 [[.under],[.under,.left]] .smaller = true := by decide
def e598476967738 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598476967738 : Closed e598476967738 ∧ code e598476967738 = 9394569989946 := by decide
theorem cert_e598476967738 : check e598476967738 [[.under],[.under,.left]] .smaller = true := by decide
def e598476967834 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e598476967834 : Closed e598476967834 ∧ code e598476967834 = 9394569990042 := by decide
theorem cert_e598476967834 : check e598476967834 [[.under],[.under,.left]] .chain = true := by decide
def e598476973494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e598476973494 : Closed e598476973494 ∧ code e598476973494 = 9394569995702 := by decide
theorem cert_e598476973494 : check e598476973494 [[.under],[.under,.left]] .smaller = true := by decide
def e598476973526 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e598476973526 : Closed e598476973526 ∧ code e598476973526 = 9394569995734 := by decide
theorem cert_e598476973526 : check e598476973526 [[.under],[.under,.left]] .smaller = true := by decide
def e598476973530 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e598476973530 : Closed e598476973530 ∧ code e598476973530 = 9394569995738 := by decide
theorem cert_e598476973530 : check e598476973530 [[.under],[.under,.left]] .smaller = true := by decide
def e598476973686 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e598476973686 : Closed e598476973686 ∧ code e598476973686 = 9394569995894 := by decide
theorem cert_e598476973686 : check e598476973686 [[.under],[.under,.left]] .smaller = true := by decide
def e598476973878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e598476973878 : Closed e598476973878 ∧ code e598476973878 = 9394569996086 := by decide
theorem cert_e598476973878 : check e598476973878 [[.under],[.under,.left]] .smaller = true := by decide
def e598476973882 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e598476973882 : Closed e598476973882 ∧ code e598476973882 = 9394569996090 := by decide
theorem cert_e598476973882 : check e598476973882 [[.under],[.under,.left]] .smaller = true := by decide
def e598476976854 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e598476976854 : Closed e598476976854 ∧ code e598476976854 = 9394569999062 := by decide
theorem cert_e598476976854 : check e598476976854 [[.under],[.under,.left]] .chain = true := by decide
def e598476976858 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e598476976858 : Closed e598476976858 ∧ code e598476976858 = 9394569999066 := by decide
theorem cert_e598476976858 : check e598476976858 [[.under],[.under,.left]] .chain = true := by decide
def e598476976874 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e598476976874 : Closed e598476976874 ∧ code e598476976874 = 9394569999082 := by decide
theorem cert_e598476976874 : check e598476976874 [[.under],[.under,.left]] .chain = true := by decide
def e598476976950 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e598476976950 : Closed e598476976950 ∧ code e598476976950 = 9394569999158 := by decide
theorem cert_e598476976950 : check e598476976950 [[.under],[.under,.left]] .chain = true := by decide
def e598476976954 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e598476976954 : Closed e598476976954 ∧ code e598476976954 = 9394569999162 := by decide
theorem cert_e598476976954 : check e598476976954 [[.under],[.under,.left]] .chain = true := by decide
def e598476977050 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e598476977050 : Closed e598476977050 ∧ code e598476977050 = 9394569999258 := by decide
theorem cert_e598476977050 : check e598476977050 [[.under],[.under,.left]] .chain = true := by decide
def e598477202286 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e598477202286 : Closed e598477202286 ∧ code e598477202286 = 9394570224494 := by decide
theorem cert_e598477202286 : check e598477202286 [[.under],[.under,.left]] .chain = true := by decide
def e598477202294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e598477202294 : Closed e598477202294 ∧ code e598477202294 = 9394570224502 := by decide
theorem cert_e598477202294 : check e598477202294 [[.under],[.under,.left]] .chain = true := by decide
def e598477202350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e598477202350 : Closed e598477202350 ∧ code e598477202350 = 9394570224558 := by decide
theorem cert_e598477202350 : check e598477202350 [[.under],[.under,.left]] .chain = true := by decide
def e598477202362 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e598477202362 : Closed e598477202362 ∧ code e598477202362 = 9394570224570 := by decide
theorem cert_e598477202362 : check e598477202362 [[.under],[.under,.left]] .chain = true := by decide
def e598477202390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e598477202390 : Closed e598477202390 ∧ code e598477202390 = 9394570224598 := by decide
theorem cert_e598477202390 : check e598477202390 [[.under],[.under,.left]] .chain = true := by decide
def e598477202394 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e598477202394 : Closed e598477202394 ∧ code e598477202394 = 9394570224602 := by decide
theorem cert_e598477202394 : check e598477202394 [[.under],[.under,.left]] .chain = true := by decide
def e598477203694 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e598477203694 : Closed e598477203694 ∧ code e598477203694 = 9394570225902 := by decide
theorem cert_e598477203694 : check e598477203694 [[.under],[.under,.left]] .chain = true := by decide
def e598477203702 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e598477203702 : Closed e598477203702 ∧ code e598477203702 = 9394570225910 := by decide
theorem cert_e598477203702 : check e598477203702 [[.under],[.under,.left]] .chain = true := by decide
def e598477204254 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e598477204254 : Closed e598477204254 ∧ code e598477204254 = 9394570226462 := by decide
theorem cert_e598477204254 : check e598477204254 [[.under],[.under,.left]] .chain = true := by decide
def e598477204366 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e598477204366 : Closed e598477204366 ∧ code e598477204366 = 9394570226574 := by decide
theorem cert_e598477204366 : check e598477204366 [[.under],[.under,.left]] .chain = true := by decide
def e598477204590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e598477204590 : Closed e598477204590 ∧ code e598477204590 = 9394570226798 := by decide
theorem cert_e598477204590 : check e598477204590 [[.under],[.under,.left]] .chain = true := by decide
def e598477204602 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e598477204602 : Closed e598477204602 ∧ code e598477204602 = 9394570226810 := by decide
theorem cert_e598477204602 : check e598477204602 [[.under],[.under,.left]] .chain = true := by decide
def e598477204766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e598477204766 : Closed e598477204766 ∧ code e598477204766 = 9394570226974 := by decide
theorem cert_e598477204766 : check e598477204766 [[.under],[.under,.left]] .chain = true := by decide
def e598477204934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e598477204934 : Closed e598477204934 ∧ code e598477204934 = 9394570227142 := by decide
theorem cert_e598477204934 : check e598477204934 [[.under],[.under,.left]] .chain = true := by decide
def e598477205046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e598477205046 : Closed e598477205046 ∧ code e598477205046 = 9394570227254 := by decide
theorem cert_e598477205046 : check e598477205046 [[.under],[.under,.left]] .chain = true := by decide
def e598477205050 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e598477205050 : Closed e598477205050 ∧ code e598477205050 = 9394570227258 := by decide
theorem cert_e598477205050 : check e598477205050 [[.under],[.under,.left]] .chain = true := by decide
def e598477205134 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e598477205134 : Closed e598477205134 ∧ code e598477205134 = 9394570227342 := by decide
theorem cert_e598477205134 : check e598477205134 [[.under],[.under,.left]] .chain = true := by decide
def e598477205190 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e598477205190 : Closed e598477205190 ∧ code e598477205190 = 9394570227398 := by decide
theorem cert_e598477205190 : check e598477205190 [[.under],[.under,.left]] .chain = true := by decide
def e598477205934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e598477205934 : Closed e598477205934 ∧ code e598477205934 = 9394570228142 := by decide
theorem cert_e598477205934 : check e598477205934 [[.under],[.under,.left]] .chain = true := by decide
def e598477205946 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e598477205946 : Closed e598477205946 ∧ code e598477205946 = 9394570228154 := by decide
theorem cert_e598477205946 : check e598477205946 [[.under],[.under,.left]] .chain = true := by decide
def e598477205994 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e598477205994 : Closed e598477205994 ∧ code e598477205994 = 9394570228202 := by decide
theorem cert_e598477205994 : check e598477205994 [[.under],[.under,.left]] .chain = true := by decide
def e598477206638 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e598477206638 : Closed e598477206638 ∧ code e598477206638 = 9394570228846 := by decide
theorem cert_e598477206638 : check e598477206638 [[.under],[.under,.left]] .chain = true := by decide
def e598477206650 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e598477206650 : Closed e598477206650 ∧ code e598477206650 = 9394570228858 := by decide
theorem cert_e598477206650 : check e598477206650 [[.under],[.under,.left]] .chain = true := by decide
def e598477206814 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e598477206814 : Closed e598477206814 ∧ code e598477206814 = 9394570229022 := by decide
theorem cert_e598477206814 : check e598477206814 [[.under],[.under,.left]] .chain = true := by decide
def e598477206982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e598477206982 : Closed e598477206982 ∧ code e598477206982 = 9394570229190 := by decide
theorem cert_e598477206982 : check e598477206982 [[.under],[.under,.left]] .chain = true := by decide
def e598477207322 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e598477207322 : Closed e598477207322 ∧ code e598477207322 = 9394570229530 := by decide
theorem cert_e598477207322 : check e598477207322 [[.under],[.under,.left]] .chain = true := by decide
def e598477207366 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e598477207366 : Closed e598477207366 ∧ code e598477207366 = 9394570229574 := by decide
theorem cert_e598477207366 : check e598477207366 [[.under],[.under,.left]] .chain = true := by decide
def e598477207766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e598477207766 : Closed e598477207766 ∧ code e598477207766 = 9394570229974 := by decide
theorem cert_e598477207766 : check e598477207766 [[.under],[.under,.left]] .chain = true := by decide
def e598477207770 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e598477207770 : Closed e598477207770 ∧ code e598477207770 = 9394570229978 := by decide
theorem cert_e598477207770 : check e598477207770 [[.under],[.under,.left]] .chain = true := by decide
def e598477207786 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e598477207786 : Closed e598477207786 ∧ code e598477207786 = 9394570229994 := by decide
theorem cert_e598477207786 : check e598477207786 [[.under],[.under,.left]] .chain = true := by decide
def e598477208118 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e598477208118 : Closed e598477208118 ∧ code e598477208118 = 9394570230326 := by decide
theorem cert_e598477208118 : check e598477208118 [[.under],[.under,.left]] .chain = true := by decide
def e598477208122 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e598477208122 : Closed e598477208122 ∧ code e598477208122 = 9394570230330 := by decide
theorem cert_e598477208122 : check e598477208122 [[.under],[.under,.left]] .chain = true := by decide
def e598477208206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e598477208206 : Closed e598477208206 ∧ code e598477208206 = 9394570230414 := by decide
theorem cert_e598477208206 : check e598477208206 [[.under],[.under,.left]] .chain = true := by decide
def e598477208262 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e598477208262 : Closed e598477208262 ∧ code e598477208262 = 9394570230470 := by decide
theorem cert_e598477208262 : check e598477208262 [[.under],[.under,.left]] .chain = true := by decide
def e598477208346 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e598477208346 : Closed e598477208346 ∧ code e598477208346 = 9394570230554 := by decide
theorem cert_e598477208346 : check e598477208346 [[.under],[.under,.left]] .chain = true := by decide
def e598477208390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e598477208390 : Closed e598477208390 ∧ code e598477208390 = 9394570230598 := by decide
theorem cert_e598477208390 : check e598477208390 [[.under],[.under,.left]] .chain = true := by decide
def e598477212910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e598477212910 : Closed e598477212910 ∧ code e598477212910 = 9394570235118 := by decide
theorem cert_e598477212910 : check e598477212910 [[.under],[.under,.left]] .chain = true := by decide
def e598477212918 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e598477212918 : Closed e598477212918 ∧ code e598477212918 = 9394570235126 := by decide
theorem cert_e598477212918 : check e598477212918 [[.under],[.under,.left]] .chain = true := by decide
def e598477213294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e598477213294 : Closed e598477213294 ∧ code e598477213294 = 9394570235502 := by decide
theorem cert_e598477213294 : check e598477213294 [[.under],[.under,.left]] .chain = true := by decide
def e598477213306 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e598477213306 : Closed e598477213306 ∧ code e598477213306 = 9394570235514 := by decide
theorem cert_e598477213306 : check e598477213306 [[.under],[.under,.left]] .chain = true := by decide
def e598477213494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e598477213494 : Closed e598477213494 ∧ code e598477213494 = 9394570235702 := by decide
theorem cert_e598477213494 : check e598477213494 [[.under],[.under,.left]] .chain = true := by decide
def e598477213498 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e598477213498 : Closed e598477213498 ∧ code e598477213498 = 9394570235706 := by decide
theorem cert_e598477213498 : check e598477213498 [[.under],[.under,.left]] .chain = true := by decide
def e598477215982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e598477215982 : Closed e598477215982 ∧ code e598477215982 = 9394570238190 := by decide
theorem cert_e598477215982 : check e598477215982 [[.under],[.under,.left]] .chain = true := by decide
def e598477215990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e598477215990 : Closed e598477215990 ∧ code e598477215990 = 9394570238198 := by decide
theorem cert_e598477215990 : check e598477215990 [[.under],[.under,.left]] .chain = true := by decide
def e598477216542 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e598477216542 : Closed e598477216542 ∧ code e598477216542 = 9394570238750 := by decide
theorem cert_e598477216542 : check e598477216542 [[.under],[.under,.left]] .chain = true := by decide
def e598477216654 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e598477216654 : Closed e598477216654 ∧ code e598477216654 = 9394570238862 := by decide
theorem cert_e598477216654 : check e598477216654 [[.under],[.under,.left]] .chain = true := by decide
def e598477216878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e598477216878 : Closed e598477216878 ∧ code e598477216878 = 9394570239086 := by decide
theorem cert_e598477216878 : check e598477216878 [[.under],[.under,.left]] .chain = true := by decide
def e598477216890 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e598477216890 : Closed e598477216890 ∧ code e598477216890 = 9394570239098 := by decide
theorem cert_e598477216890 : check e598477216890 [[.under],[.under,.left]] .chain = true := by decide
def e598477217054 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e598477217054 : Closed e598477217054 ∧ code e598477217054 = 9394570239262 := by decide
theorem cert_e598477217054 : check e598477217054 [[.under],[.under,.left]] .chain = true := by decide
def e598477217222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e598477217222 : Closed e598477217222 ∧ code e598477217222 = 9394570239430 := by decide
theorem cert_e598477217222 : check e598477217222 [[.under],[.under,.left]] .chain = true := by decide
def e598477217334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e598477217334 : Closed e598477217334 ∧ code e598477217334 = 9394570239542 := by decide
theorem cert_e598477217334 : check e598477217334 [[.under],[.under,.left]] .chain = true := by decide
def e598477217338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e598477217338 : Closed e598477217338 ∧ code e598477217338 = 9394570239546 := by decide
theorem cert_e598477217338 : check e598477217338 [[.under],[.under,.left]] .chain = true := by decide
def e598477217422 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e598477217422 : Closed e598477217422 ∧ code e598477217422 = 9394570239630 := by decide
theorem cert_e598477217422 : check e598477217422 [[.under],[.under,.left]] .chain = true := by decide
def e598477217478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e598477217478 : Closed e598477217478 ∧ code e598477217478 = 9394570239686 := by decide
theorem cert_e598477217478 : check e598477217478 [[.under],[.under,.left]] .chain = true := by decide
def e598477219614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e598477219614 : Closed e598477219614 ∧ code e598477219614 = 9394570241822 := by decide
theorem cert_e598477219614 : check e598477219614 [[.under],[.under,.left]] .chain = true := by decide
def e598477219726 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e598477219726 : Closed e598477219726 ∧ code e598477219726 = 9394570241934 := by decide
theorem cert_e598477219726 : check e598477219726 [[.under],[.under,.left]] .chain = true := by decide
def e598477222686 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e598477222686 : Closed e598477222686 ∧ code e598477222686 = 9394570244894 := by decide
theorem cert_e598477222686 : check e598477222686 [[.under],[.under,.left]] .chain = true := by decide
def e598477222854 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e598477222854 : Closed e598477222854 ∧ code e598477222854 = 9394570245062 := by decide
theorem cert_e598477222854 : check e598477222854 [[.under],[.under,.left]] .chain = true := by decide
def e598477224334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e598477224334 : Closed e598477224334 ∧ code e598477224334 = 9394570246542 := by decide
theorem cert_e598477224334 : check e598477224334 [[.under],[.under,.left]] .chain = true := by decide
def e598477224390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e598477224390 : Closed e598477224390 ∧ code e598477224390 = 9394570246598 := by decide
theorem cert_e598477224390 : check e598477224390 [[.under],[.under,.left]] .chain = true := by decide
def e598477227630 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e598477227630 : Closed e598477227630 ∧ code e598477227630 = 9394570249838 := by decide
theorem cert_e598477227630 : check e598477227630 [[.under],[.under,.left]] .chain = true := by decide
def e598477227642 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e598477227642 : Closed e598477227642 ∧ code e598477227642 = 9394570249850 := by decide
theorem cert_e598477227642 : check e598477227642 [[.under],[.under,.left]] .chain = true := by decide
def e598477227930 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e598477227930 : Closed e598477227930 ∧ code e598477227930 = 9394570250138 := by decide
theorem cert_e598477227930 : check e598477227930 [[.under],[.under,.left]] .chain = true := by decide
def e598477229166 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e598477229166 : Closed e598477229166 ∧ code e598477229166 = 9394570251374 := by decide
theorem cert_e598477229166 : check e598477229166 [[.under],[.under,.left]] .chain = true := by decide
def e598477229178 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e598477229178 : Closed e598477229178 ∧ code e598477229178 = 9394570251386 := by decide
theorem cert_e598477229178 : check e598477229178 [[.under],[.under,.left]] .chain = true := by decide
def e598477229342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e598477229342 : Closed e598477229342 ∧ code e598477229342 = 9394570251550 := by decide
theorem cert_e598477229342 : check e598477229342 [[.under],[.under,.left]] .chain = true := by decide
def e598477229510 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e598477229510 : Closed e598477229510 ∧ code e598477229510 = 9394570251718 := by decide
theorem cert_e598477229510 : check e598477229510 [[.under],[.under,.left]] .chain = true := by decide
def e598477229850 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e598477229850 : Closed e598477229850 ∧ code e598477229850 = 9394570252058 := by decide
theorem cert_e598477229850 : check e598477229850 [[.under],[.under,.left]] .chain = true := by decide
def e598477229894 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e598477229894 : Closed e598477229894 ∧ code e598477229894 = 9394570252102 := by decide
theorem cert_e598477229894 : check e598477229894 [[.under],[.under,.left]] .chain = true := by decide
def e598477230878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e598477230878 : Closed e598477230878 ∧ code e598477230878 = 9394570253086 := by decide
theorem cert_e598477230878 : check e598477230878 [[.under],[.under,.left]] .chain = true := by decide
def e598477231046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e598477231046 : Closed e598477231046 ∧ code e598477231046 = 9394570253254 := by decide
theorem cert_e598477231046 : check e598477231046 [[.under],[.under,.left]] .chain = true := by decide
def e598477233350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e598477233350 : Closed e598477233350 ∧ code e598477233350 = 9394570255558 := by decide
theorem cert_e598477233350 : check e598477233350 [[.under],[.under,.left]] .chain = true := by decide
def e598477234998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e598477234998 : Closed e598477234998 ∧ code e598477234998 = 9394570257206 := by decide
theorem cert_e598477234998 : check e598477234998 [[.under],[.under,.left]] .chain = true := by decide
def e598477235002 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e598477235002 : Closed e598477235002 ∧ code e598477235002 = 9394570257210 := by decide
theorem cert_e598477235002 : check e598477235002 [[.under],[.under,.left]] .chain = true := by decide
def e598477235098 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e598477235098 : Closed e598477235098 ∧ code e598477235098 = 9394570257306 := by decide
theorem cert_e598477235098 : check e598477235098 [[.under],[.under,.left]] .chain = true := by decide
def e598477235766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e598477235766 : Closed e598477235766 ∧ code e598477235766 = 9394570257974 := by decide
theorem cert_e598477235766 : check e598477235766 [[.under],[.under,.left]] .chain = true := by decide
def e598477235770 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e598477235770 : Closed e598477235770 ∧ code e598477235770 = 9394570257978 := by decide
theorem cert_e598477235770 : check e598477235770 [[.under],[.under,.left]] .chain = true := by decide
def e598477235854 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e598477235854 : Closed e598477235854 ∧ code e598477235854 = 9394570258062 := by decide
theorem cert_e598477235854 : check e598477235854 [[.under],[.under,.left]] .chain = true := by decide
def e598477235910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e598477235910 : Closed e598477235910 ∧ code e598477235910 = 9394570258118 := by decide
theorem cert_e598477235910 : check e598477235910 [[.under],[.under,.left]] .chain = true := by decide
def e598477235994 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e598477235994 : Closed e598477235994 ∧ code e598477235994 = 9394570258202 := by decide
theorem cert_e598477235994 : check e598477235994 [[.under],[.under,.left]] .chain = true := by decide
def e598477236038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e598477236038 : Closed e598477236038 ∧ code e598477236038 = 9394570258246 := by decide
theorem cert_e598477236038 : check e598477236038 [[.under],[.under,.left]] .chain = true := by decide
def e598477236622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e598477236622 : Closed e598477236622 ∧ code e598477236622 = 9394570258830 := by decide
theorem cert_e598477236622 : check e598477236622 [[.under],[.under,.left]] .chain = true := by decide
def e598477236678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e598477236678 : Closed e598477236678 ∧ code e598477236678 = 9394570258886 := by decide
theorem cert_e598477236678 : check e598477236678 [[.under],[.under,.left]] .chain = true := by decide
def e598477237446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e598477237446 : Closed e598477237446 ∧ code e598477237446 = 9394570259654 := by decide
theorem cert_e598477237446 : check e598477237446 [[.under],[.under,.left]] .chain = true := by decide
def e598477248222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e598477248222 : Closed e598477248222 ∧ code e598477248222 = 9394570270430 := by decide
theorem cert_e598477248222 : check e598477248222 [[.under],[.under,.left]] .chain = true := by decide
def e598477248246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e598477248246 : Closed e598477248246 ∧ code e598477248246 = 9394570270454 := by decide
theorem cert_e598477248246 : check e598477248246 [[.under],[.under,.left]] .chain = true := by decide
def e598477248350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e598477248350 : Closed e598477248350 ∧ code e598477248350 = 9394570270558 := by decide
theorem cert_e598477248350 : check e598477248350 [[.under],[.under,.left]] .chain = true := by decide
def e598477248378 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e598477248378 : Closed e598477248378 ∧ code e598477248378 = 9394570270586 := by decide
theorem cert_e598477248378 : check e598477248378 [[.under],[.under,.left]] .chain = true := by decide
def e598477248470 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e598477248470 : Closed e598477248470 ∧ code e598477248470 = 9394570270678 := by decide
theorem cert_e598477248470 : check e598477248470 [[.under],[.under,.left]] .chain = true := by decide
def e598477248474 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e598477248474 : Closed e598477248474 ∧ code e598477248474 = 9394570270682 := by decide
theorem cert_e598477248474 : check e598477248474 [[.under],[.under,.left]] .chain = true := by decide
def e598477248990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e598477248990 : Closed e598477248990 ∧ code e598477248990 = 9394570271198 := by decide
theorem cert_e598477248990 : check e598477248990 [[.under],[.under,.left]] .chain = true := by decide
def e598477249014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e598477249014 : Closed e598477249014 ∧ code e598477249014 = 9394570271222 := by decide
theorem cert_e598477249014 : check e598477249014 [[.under],[.under,.left]] .chain = true := by decide
def e598477249758 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e598477249758 : Closed e598477249758 ∧ code e598477249758 = 9394570271966 := by decide
theorem cert_e598477249758 : check e598477249758 [[.under],[.under,.left]] .chain = true := by decide
def e598477249786 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e598477249786 : Closed e598477249786 ∧ code e598477249786 = 9394570271994 := by decide
theorem cert_e598477249786 : check e598477249786 [[.under],[.under,.left]] .chain = true := by decide
def e598477250358 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e598477250358 : Closed e598477250358 ∧ code e598477250358 = 9394570272566 := by decide
theorem cert_e598477250358 : check e598477250358 [[.under],[.under,.left]] .chain = true := by decide
def e598477250362 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e598477250362 : Closed e598477250362 ∧ code e598477250362 = 9394570272570 := by decide
theorem cert_e598477250362 : check e598477250362 [[.under],[.under,.left]] .chain = true := by decide
def e598477265134 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e598477265134 : Closed e598477265134 ∧ code e598477265134 = 9394570287342 := by decide
theorem cert_e598477265134 : check e598477265134 [[.under],[.under,.left]] .chain = true := by decide
def e598477265142 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e598477265142 : Closed e598477265142 ∧ code e598477265142 = 9394570287350 := by decide
theorem cert_e598477265142 : check e598477265142 [[.under],[.under,.left]] .chain = true := by decide
def e598477265694 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e598477265694 : Closed e598477265694 ∧ code e598477265694 = 9394570287902 := by decide
theorem cert_e598477265694 : check e598477265694 [[.under],[.under,.left]] .chain = true := by decide
def e598477265806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e598477265806 : Closed e598477265806 ∧ code e598477265806 = 9394570288014 := by decide
theorem cert_e598477265806 : check e598477265806 [[.under],[.under,.left]] .chain = true := by decide
def e598477266030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e598477266030 : Closed e598477266030 ∧ code e598477266030 = 9394570288238 := by decide
theorem cert_e598477266030 : check e598477266030 [[.under],[.under,.left]] .chain = true := by decide
def e598477266042 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e598477266042 : Closed e598477266042 ∧ code e598477266042 = 9394570288250 := by decide
theorem cert_e598477266042 : check e598477266042 [[.under],[.under,.left]] .chain = true := by decide
def e598477266206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e598477266206 : Closed e598477266206 ∧ code e598477266206 = 9394570288414 := by decide
theorem cert_e598477266206 : check e598477266206 [[.under],[.under,.left]] .chain = true := by decide
def e598477266374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e598477266374 : Closed e598477266374 ∧ code e598477266374 = 9394570288582 := by decide
theorem cert_e598477266374 : check e598477266374 [[.under],[.under,.left]] .chain = true := by decide
def e598477266486 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e598477266486 : Closed e598477266486 ∧ code e598477266486 = 9394570288694 := by decide
theorem cert_e598477266486 : check e598477266486 [[.under],[.under,.left]] .chain = true := by decide
def e598477266490 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e598477266490 : Closed e598477266490 ∧ code e598477266490 = 9394570288698 := by decide
theorem cert_e598477266490 : check e598477266490 [[.under],[.under,.left]] .chain = true := by decide
def e598477266574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e598477266574 : Closed e598477266574 ∧ code e598477266574 = 9394570288782 := by decide
theorem cert_e598477266574 : check e598477266574 [[.under],[.under,.left]] .chain = true := by decide
def e598477266630 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e598477266630 : Closed e598477266630 ∧ code e598477266630 = 9394570288838 := by decide
theorem cert_e598477266630 : check e598477266630 [[.under],[.under,.left]] .chain = true := by decide
def e598477268766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e598477268766 : Closed e598477268766 ∧ code e598477268766 = 9394570290974 := by decide
theorem cert_e598477268766 : check e598477268766 [[.under],[.under,.left]] .chain = true := by decide
def e598477268878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e598477268878 : Closed e598477268878 ∧ code e598477268878 = 9394570291086 := by decide
theorem cert_e598477268878 : check e598477268878 [[.under],[.under,.left]] .chain = true := by decide
end Blc.Floor43
