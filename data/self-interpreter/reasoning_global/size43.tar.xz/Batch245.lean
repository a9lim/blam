import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393420916634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393420916634 : Closed e2393420916634 ∧ code e2393420916634 = 11189513938842 := by decide
theorem cert_e2393420916634 : check e2393420916634 [[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under]] .chain = true := by decide
def e2393420916678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2393420916678 : Closed e2393420916678 ∧ code e2393420916678 = 11189513938886 := by decide
theorem cert_e2393420916678 : check e2393420916678 [[],[.left],[.left],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e2393420919510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2393420919510 : Closed e2393420919510 ∧ code e2393420919510 = 11189513941718 := by decide
theorem cert_e2393420919510 : check e2393420919510 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2393420919514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2393420919514 : Closed e2393420919514 ∧ code e2393420919514 = 11189513941722 := by decide
theorem cert_e2393420919514 : check e2393420919514 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2393420919530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2393420919530 : Closed e2393420919530 ∧ code e2393420919530 = 11189513941738 := by decide
theorem cert_e2393420919530 : check e2393420919530 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2393420919606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393420919606 : Closed e2393420919606 ∧ code e2393420919606 = 11189513941814 := by decide
theorem cert_e2393420919606 : check e2393420919606 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2393420919610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393420919610 : Closed e2393420919610 ∧ code e2393420919610 = 11189513941818 := by decide
theorem cert_e2393420919610 : check e2393420919610 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2393420919706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393420919706 : Closed e2393420919706 ∧ code e2393420919706 = 11189513941914 := by decide
theorem cert_e2393420919706 : check e2393420919706 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2393420921230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2393420921230 : Closed e2393420921230 ∧ code e2393420921230 = 11189513943438 := by decide
theorem cert_e2393420921230 : check e2393420921230 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2393420921286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2393420921286 : Closed e2393420921286 ∧ code e2393420921286 = 11189513943494 := by decide
theorem cert_e2393420921286 : check e2393420921286 [[],[.left],[.left],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e2393421033838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2393421033838 : Closed e2393421033838 ∧ code e2393421033838 = 11189514056046 := by decide
theorem cert_e2393421033838 : check e2393421033838 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393421033846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2393421033846 : Closed e2393421033846 ∧ code e2393421033846 = 11189514056054 := by decide
theorem cert_e2393421033846 : check e2393421033846 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393421035054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393421035054 : Closed e2393421035054 ∧ code e2393421035054 = 11189514057262 := by decide
theorem cert_e2393421035054 : check e2393421035054 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393421035234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393421035234 : Closed e2393421035234 ∧ code e2393421035234 = 11189514057442 := by decide
def e2393421035246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2393421035246 : Closed e2393421035246 ∧ code e2393421035246 = 11189514057454 := by decide
def e2393421035286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393421035286 : Closed e2393421035286 ∧ code e2393421035286 = 11189514057494 := by decide
theorem cert_e2393421035286 : check e2393421035286 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] .chain = true := by decide
def e2393421035362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393421035362 : Closed e2393421035362 ∧ code e2393421035362 = 11189514057570 := by decide
def e2393421035374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2393421035374 : Closed e2393421035374 ∧ code e2393421035374 = 11189514057582 := by decide
def e2393421035382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2393421035382 : Closed e2393421035382 ∧ code e2393421035382 = 11189514057590 := by decide
def e2393421035694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2393421035694 : Closed e2393421035694 ∧ code e2393421035694 = 11189514057902 := by decide
def e2393421035706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2393421035706 : Closed e2393421035706 ∧ code e2393421035706 = 11189514057914 := by decide
theorem cert_e2393421035706 : check e2393421035706 [[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393421036078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393421036078 : Closed e2393421036078 ∧ code e2393421036078 = 11189514058286 := by decide
theorem cert_e2393421036078 : check e2393421036078 [[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393421036258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393421036258 : Closed e2393421036258 ∧ code e2393421036258 = 11189514058466 := by decide
def e2393421036270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2393421036270 : Closed e2393421036270 ∧ code e2393421036270 = 11189514058478 := by decide
def e2393421036426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393421036426 : Closed e2393421036426 ∧ code e2393421036426 = 11189514058634 := by decide
private def t_e2393421036426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem cert_e2393421036426 : ¬ IsSelfInterpreter e2393421036426 :=
  wSource (t := t_e2393421036426) (replay_sound (ps := []) (t := e2393421036426) (by decide)) (by decide)
def e2393421036450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393421036450 : Closed e2393421036450 ∧ code e2393421036450 = 11189514058658 := by decide
private def t_e2393421036450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem cert_e2393421036450 : ¬ IsSelfInterpreter e2393421036450 :=
  wSource (t := t_e2393421036450) (replay_sound (ps := []) (t := e2393421036450) (by decide)) (by decide)
def e2393421036462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2393421036462 : Closed e2393421036462 ∧ code e2393421036462 = 11189514058670 := by decide
private def t_e2393421036462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem cert_e2393421036462 : ¬ IsSelfInterpreter e2393421036462 :=
  wSource (t := t_e2393421036462) (replay_sound (ps := []) (t := e2393421036462) (by decide)) (by decide)
def e2393421036474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2393421036474 : Closed e2393421036474 ∧ code e2393421036474 = 11189514058682 := by decide
private def t_e2393421036474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem cert_e2393421036474 : ¬ IsSelfInterpreter e2393421036474 :=
  wSource (t := t_e2393421036474) (replay_sound (ps := []) (t := e2393421036474) (by decide)) (by decide)
def e2393421036630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2393421036630 : Closed e2393421036630 ∧ code e2393421036630 = 11189514058838 := by decide
theorem cert_e2393421036630 : check e2393421036630 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2393421036634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2393421036634 : Closed e2393421036634 ∧ code e2393421036634 = 11189514058842 := by decide
theorem cert_e2393421036634 : check e2393421036634 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2393421036822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393421036822 : Closed e2393421036822 ∧ code e2393421036822 = 11189514059030 := by decide
theorem cert_e2393421036822 : check e2393421036822 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .chain = true := by decide
def e2393421036898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393421036898 : Closed e2393421036898 ∧ code e2393421036898 = 11189514059106 := by decide
def e2393421036910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2393421036910 : Closed e2393421036910 ∧ code e2393421036910 = 11189514059118 := by decide
def e2393421036918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2393421036918 : Closed e2393421036918 ∧ code e2393421036918 = 11189514059126 := by decide
def e2393421036938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393421036938 : Closed e2393421036938 ∧ code e2393421036938 = 11189514059146 := by decide
private def t_e2393421036938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem cert_e2393421036938 : ¬ IsSelfInterpreter e2393421036938 :=
  wSource (t := t_e2393421036938) (replay_sound (ps := []) (t := e2393421036938) (by decide)) (by decide)
def e2393421036962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393421036962 : Closed e2393421036962 ∧ code e2393421036962 = 11189514059170 := by decide
private def t_e2393421036962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem cert_e2393421036962 : ¬ IsSelfInterpreter e2393421036962 :=
  wSource (t := t_e2393421036962) (replay_sound (ps := []) (t := e2393421036962) (by decide)) (by decide)
def e2393421036974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2393421036974 : Closed e2393421036974 ∧ code e2393421036974 = 11189514059182 := by decide
private def t_e2393421036974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem cert_e2393421036974 : ¬ IsSelfInterpreter e2393421036974 :=
  wSource (t := t_e2393421036974) (replay_sound (ps := []) (t := e2393421036974) (by decide)) (by decide)
def e2393421036986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2393421036986 : Closed e2393421036986 ∧ code e2393421036986 = 11189514059194 := by decide
private def t_e2393421036986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem cert_e2393421036986 : ¬ IsSelfInterpreter e2393421036986 :=
  wSource (t := t_e2393421036986) (replay_sound (ps := []) (t := e2393421036986) (by decide)) (by decide)
def e2393421037014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2393421037014 : Closed e2393421037014 ∧ code e2393421037014 = 11189514059222 := by decide
private def t_e2393421037014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e2393421037014 : ¬ IsSelfInterpreter e2393421037014 :=
  wSource (t := t_e2393421037014) (replay_sound (ps := []) (t := e2393421037014) (by decide)) (by decide)
def e2393421037018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2393421037018 : Closed e2393421037018 ∧ code e2393421037018 = 11189514059226 := by decide
private def t_e2393421037018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e2393421037018 : ¬ IsSelfInterpreter e2393421037018 :=
  wSource (t := t_e2393421037018) (replay_sound (ps := []) (t := e2393421037018) (by decide)) (by decide)
def e2393421038062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2393421038062 : Closed e2393421038062 ∧ code e2393421038062 = 11189514060270 := by decide
theorem cert_e2393421038062 : check e2393421038062 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .chain = true := by decide
def e2393421038070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2393421038070 : Closed e2393421038070 ∧ code e2393421038070 = 11189514060278 := by decide
theorem cert_e2393421038070 : check e2393421038070 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .smaller = true := by decide
def e2393421038830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2393421038830 : Closed e2393421038830 ∧ code e2393421038830 = 11189514061038 := by decide
theorem cert_e2393421038830 : check e2393421038830 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2393421038838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2393421038838 : Closed e2393421038838 ∧ code e2393421038838 = 11189514061046 := by decide
theorem cert_e2393421038838 : check e2393421038838 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2393421039390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2393421039390 : Closed e2393421039390 ∧ code e2393421039390 = 11189514061598 := by decide
theorem cert_e2393421039390 : check e2393421039390 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2393421039502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2393421039502 : Closed e2393421039502 ∧ code e2393421039502 = 11189514061710 := by decide
theorem cert_e2393421039502 : check e2393421039502 [[],[.left],[.left],[.left],[],[.left],[.left],[],[]] .chain = true := by decide
def e2393421041198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2393421041198 : Closed e2393421041198 ∧ code e2393421041198 = 11189514063406 := by decide
theorem cert_e2393421041198 : check e2393421041198 [[],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left]] .chain = true := by decide
def e2393421041378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2393421041378 : Closed e2393421041378 ∧ code e2393421041378 = 11189514063586 := by decide
def e2393421041390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2393421041390 : Closed e2393421041390 ∧ code e2393421041390 = 11189514063598 := by decide
def e2393421041430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2393421041430 : Closed e2393421041430 ∧ code e2393421041430 = 11189514063638 := by decide
theorem cert_e2393421041430 : check e2393421041430 [[],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2393421041506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2393421041506 : Closed e2393421041506 ∧ code e2393421041506 = 11189514063714 := by decide
def e2393421041518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2393421041518 : Closed e2393421041518 ∧ code e2393421041518 = 11189514063726 := by decide
def e2393421041526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2393421041526 : Closed e2393421041526 ∧ code e2393421041526 = 11189514063734 := by decide
def e2393421043774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2393421043774 : Closed e2393421043774 ∧ code e2393421043774 = 11189514065982 := by decide
theorem cert_e2393421043774 : check e2393421043774 [[],[.left],[.left],[.left],[],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e2393421044194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393421044194 : Closed e2393421044194 ∧ code e2393421044194 = 11189514066402 := by decide
theorem cert_e2393421044194 : check e2393421044194 [[],[.left],[.left],[.left],[],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left]] .chain = true := by decide
def e2393421044206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2393421044206 : Closed e2393421044206 ∧ code e2393421044206 = 11189514066414 := by decide
def e2393421044766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2393421044766 : Closed e2393421044766 ∧ code e2393421044766 = 11189514066974 := by decide
theorem cert_e2393421044766 : check e2393421044766 [[],[.left],[.left],[.left],[],[.left],[.left],[.left],[],[.left],[]] .chain = true := by decide
def e2393421044962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393421044962 : Closed e2393421044962 ∧ code e2393421044962 = 11189514067170 := by decide
theorem cert_e2393421044962 : check e2393421044962 [[],[.left],[.left],[.left],[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left]] .chain = true := by decide
def e2393421044974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393421044974 : Closed e2393421044974 ∧ code e2393421044974 = 11189514067182 := by decide
def e2393421044982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393421044982 : Closed e2393421044982 ∧ code e2393421044982 = 11189514067190 := by decide
def e2393421045998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2393421045998 : Closed e2393421045998 ∧ code e2393421045998 = 11189514068206 := by decide
theorem cert_e2393421045998 : check e2393421045998 [[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2393421046010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2393421046010 : Closed e2393421046010 ∧ code e2393421046010 = 11189514068218 := by decide
theorem cert_e2393421046010 : check e2393421046010 [[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2393421046382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2393421046382 : Closed e2393421046382 ∧ code e2393421046382 = 11189514068590 := by decide
theorem cert_e2393421046382 : check e2393421046382 [[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2393421046394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2393421046394 : Closed e2393421046394 ∧ code e2393421046394 = 11189514068602 := by decide
theorem cert_e2393421046394 : check e2393421046394 [[],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2393421046558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2393421046558 : Closed e2393421046558 ∧ code e2393421046558 = 11189514068766 := by decide
theorem cert_e2393421046558 : check e2393421046558 [[],[.left],[.left],[.left],[],[.left],[],[.left],[],[]] .chain = true := by decide
def e2393421046726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2393421046726 : Closed e2393421046726 ∧ code e2393421046726 = 11189514068934 := by decide
theorem cert_e2393421046726 : check e2393421046726 [[],[.left],[.left],[.left],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2393421047342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2393421047342 : Closed e2393421047342 ∧ code e2393421047342 = 11189514069550 := by decide
theorem cert_e2393421047342 : check e2393421047342 [[],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393421047522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2393421047522 : Closed e2393421047522 ∧ code e2393421047522 = 11189514069730 := by decide
def e2393421047534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2393421047534 : Closed e2393421047534 ∧ code e2393421047534 = 11189514069742 := by decide
def e2393421047690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393421047690 : Closed e2393421047690 ∧ code e2393421047690 = 11189514069898 := by decide
theorem cert_e2393421047690 : check e2393421047690 [[],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left,.left]] .chain = true := by decide
def e2393421047714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393421047714 : Closed e2393421047714 ∧ code e2393421047714 = 11189514069922 := by decide
theorem cert_e2393421047714 : check e2393421047714 [[],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .chain = true := by decide
def e2393421047726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2393421047726 : Closed e2393421047726 ∧ code e2393421047726 = 11189514069934 := by decide
def e2393421047738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2393421047738 : Closed e2393421047738 ∧ code e2393421047738 = 11189514069946 := by decide
private def t_e2393421047738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem cert_e2393421047738 : ¬ IsSelfInterpreter e2393421047738 :=
  wSource (t := t_e2393421047738) (replay_sound (ps := []) (t := e2393421047738) (by decide)) (by decide)
def e2393421047870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2393421047870 : Closed e2393421047870 ∧ code e2393421047870 = 11189514070078 := by decide
theorem cert_e2393421047870 : check e2393421047870 [[],[.left],[.left],[.left],[],[.left],[],[.left],[.left],[]] .smaller = true := by decide
def e2393421048290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393421048290 : Closed e2393421048290 ∧ code e2393421048290 = 11189514070498 := by decide
theorem cert_e2393421048290 : check e2393421048290 [[],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left]] .chain = true := by decide
def e2393421048302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2393421048302 : Closed e2393421048302 ∧ code e2393421048302 = 11189514070510 := by decide
def e2393421049358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393421049358 : Closed e2393421049358 ∧ code e2393421049358 = 11189514071566 := by decide
private def t_e2393421049358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem cert_e2393421049358 : ¬ IsSelfInterpreter e2393421049358 :=
  wSource (t := t_e2393421049358) (replay_sound (ps := []) (t := e2393421049358) (by decide)) (by decide)
def e2393421049442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393421049442 : Closed e2393421049442 ∧ code e2393421049442 = 11189514071650 := by decide
private def t_e2393421049442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem cert_e2393421049442 : ¬ IsSelfInterpreter e2393421049442 :=
  wSource (t := t_e2393421049442) (replay_sound (ps := []) (t := e2393421049442) (by decide)) (by decide)
def e2393421049454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393421049454 : Closed e2393421049454 ∧ code e2393421049454 = 11189514071662 := by decide
private def t_e2393421049454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem cert_e2393421049454 : ¬ IsSelfInterpreter e2393421049454 :=
  wSource (t := t_e2393421049454) (replay_sound (ps := []) (t := e2393421049454) (by decide)) (by decide)
def e2393421049466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393421049466 : Closed e2393421049466 ∧ code e2393421049466 = 11189514071674 := by decide
private def t_e2393421049466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem cert_e2393421049466 : ¬ IsSelfInterpreter e2393421049466 :=
  wSource (t := t_e2393421049466) (replay_sound (ps := []) (t := e2393421049466) (by decide)) (by decide)
def e2393421049974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2393421049974 : Closed e2393421049974 ∧ code e2393421049974 = 11189514072182 := by decide
theorem cert_e2393421049974 : check e2393421049974 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .smaller = true := by decide
def e2393421049978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2393421049978 : Closed e2393421049978 ∧ code e2393421049978 = 11189514072186 := by decide
theorem cert_e2393421049978 : check e2393421049978 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .chain = true := by decide
def e2393421050166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393421050166 : Closed e2393421050166 ∧ code e2393421050166 = 11189514072374 := by decide
theorem cert_e2393421050166 : check e2393421050166 [[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393421050170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393421050170 : Closed e2393421050170 ∧ code e2393421050170 = 11189514072378 := by decide
theorem cert_e2393421050170 : check e2393421050170 [[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2393421050254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2393421050254 : Closed e2393421050254 ∧ code e2393421050254 = 11189514072462 := by decide
theorem cert_e2393421050254 : check e2393421050254 [[],[.left],[.left],[.left],[],[.left],[.left],[],[]] .chain = true := by decide
def e2393421050310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2393421050310 : Closed e2393421050310 ∧ code e2393421050310 = 11189514072518 := by decide
theorem cert_e2393421050310 : check e2393421050310 [[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left]] .chain = true := by decide
def e2393421050646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2393421050646 : Closed e2393421050646 ∧ code e2393421050646 = 11189514072854 := by decide
theorem cert_e2393421050646 : check e2393421050646 [[],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e2393421050722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2393421050722 : Closed e2393421050722 ∧ code e2393421050722 = 11189514072930 := by decide
def e2393421050734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2393421050734 : Closed e2393421050734 ∧ code e2393421050734 = 11189514072942 := by decide
def e2393421050742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2393421050742 : Closed e2393421050742 ∧ code e2393421050742 = 11189514072950 := by decide
def e2393421050762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393421050762 : Closed e2393421050762 ∧ code e2393421050762 = 11189514072970 := by decide
theorem cert_e2393421050762 : check e2393421050762 [[],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2393421050786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393421050786 : Closed e2393421050786 ∧ code e2393421050786 = 11189514072994 := by decide
def e2393421050798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2393421050798 : Closed e2393421050798 ∧ code e2393421050798 = 11189514073006 := by decide
def e2393421050810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2393421050810 : Closed e2393421050810 ∧ code e2393421050810 = 11189514073018 := by decide
private def t_e2393421050810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem cert_e2393421050810 : ¬ IsSelfInterpreter e2393421050810 :=
  wSource (t := t_e2393421050810) (replay_sound (ps := []) (t := e2393421050810) (by decide)) (by decide)
def e2393421050838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2393421050838 : Closed e2393421050838 ∧ code e2393421050838 = 11189514073046 := by decide
def e2393421050842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2393421050842 : Closed e2393421050842 ∧ code e2393421050842 = 11189514073050 := by decide
private def t_e2393421050842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem cert_e2393421050842 : ¬ IsSelfInterpreter e2393421050842 :=
  wSource (t := t_e2393421050842) (replay_sound (ps := []) (t := e2393421050842) (by decide)) (by decide)
def e2393421050910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2393421050910 : Closed e2393421050910 ∧ code e2393421050910 = 11189514073118 := by decide
theorem cert_e2393421050910 : check e2393421050910 [[],[.left],[.left],[.left],[],[.left],[.left],[.left],[],[.left],[.left],[]] .chain = true := by decide
def e2393421051106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393421051106 : Closed e2393421051106 ∧ code e2393421051106 = 11189514073314 := by decide
theorem cert_e2393421051106 : check e2393421051106 [[],[.left],[.left],[.left],[],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e2393421051118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393421051118 : Closed e2393421051118 ∧ code e2393421051118 = 11189514073326 := by decide
def e2393421051126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393421051126 : Closed e2393421051126 ∧ code e2393421051126 = 11189514073334 := by decide
def e2393421051406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393421051406 : Closed e2393421051406 ∧ code e2393421051406 = 11189514073614 := by decide
private def t_e2393421051406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem cert_e2393421051406 : ¬ IsSelfInterpreter e2393421051406 :=
  wSource (t := t_e2393421051406) (replay_sound (ps := []) (t := e2393421051406) (by decide)) (by decide)
def e2393421051490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393421051490 : Closed e2393421051490 ∧ code e2393421051490 = 11189514073698 := by decide
private def t_e2393421051490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem cert_e2393421051490 : ¬ IsSelfInterpreter e2393421051490 :=
  wSource (t := t_e2393421051490) (replay_sound (ps := []) (t := e2393421051490) (by decide)) (by decide)
def e2393421051502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393421051502 : Closed e2393421051502 ∧ code e2393421051502 = 11189514073710 := by decide
private def t_e2393421051502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem cert_e2393421051502 : ¬ IsSelfInterpreter e2393421051502 :=
  wSource (t := t_e2393421051502) (replay_sound (ps := []) (t := e2393421051502) (by decide)) (by decide)
def e2393421051514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393421051514 : Closed e2393421051514 ∧ code e2393421051514 = 11189514073722 := by decide
private def t_e2393421051514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem cert_e2393421051514 : ¬ IsSelfInterpreter e2393421051514 :=
  wSource (t := t_e2393421051514) (replay_sound (ps := []) (t := e2393421051514) (by decide)) (by decide)
def e2393421051702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393421051702 : Closed e2393421051702 ∧ code e2393421051702 = 11189514073910 := by decide
private def t_e2393421051702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e2393421051702 : ¬ IsSelfInterpreter e2393421051702 :=
  wSource (t := t_e2393421051702) (replay_sound (ps := []) (t := e2393421051702) (by decide)) (by decide)
def e2393421051706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393421051706 : Closed e2393421051706 ∧ code e2393421051706 = 11189514073914 := by decide
private def t_e2393421051706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e2393421051706 : ¬ IsSelfInterpreter e2393421051706 :=
  wSource (t := t_e2393421051706) (replay_sound (ps := []) (t := e2393421051706) (by decide)) (by decide)
def e2393421056878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393421056878 : Closed e2393421056878 ∧ code e2393421056878 = 11189514079086 := by decide
theorem cert_e2393421056878 : check e2393421056878 [[],[.left],[.left],[.left],[],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2393421056886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393421056886 : Closed e2393421056886 ∧ code e2393421056886 = 11189514079094 := by decide
def e2393421056942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393421056942 : Closed e2393421056942 ∧ code e2393421056942 = 11189514079150 := by decide
theorem cert_e2393421056942 : check e2393421056942 [[],[.left],[.left],[.left],[],[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2393421056954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393421056954 : Closed e2393421056954 ∧ code e2393421056954 = 11189514079162 := by decide
theorem cert_e2393421056954 : check e2393421056954 [[],[.left],[.left],[.left],[],[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2393421056982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393421056982 : Closed e2393421056982 ∧ code e2393421056982 = 11189514079190 := by decide
def e2393421056986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393421056986 : Closed e2393421056986 ∧ code e2393421056986 = 11189514079194 := by decide
theorem cert_e2393421056986 : check e2393421056986 [[],[.left],[.left],[.left],[],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2393421057262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393421057262 : Closed e2393421057262 ∧ code e2393421057262 = 11189514079470 := by decide
theorem cert_e2393421057262 : check e2393421057262 [[],[.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2393421057270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393421057270 : Closed e2393421057270 ∧ code e2393421057270 = 11189514079478 := by decide
theorem cert_e2393421057270 : check e2393421057270 [[],[.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2393421057646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393421057646 : Closed e2393421057646 ∧ code e2393421057646 = 11189514079854 := by decide
theorem cert_e2393421057646 : check e2393421057646 [[],[.left],[.left],[.left],[],[],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2393421057658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393421057658 : Closed e2393421057658 ∧ code e2393421057658 = 11189514079866 := by decide
theorem cert_e2393421057658 : check e2393421057658 [[],[.left],[.left],[.left],[],[],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2393421057846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393421057846 : Closed e2393421057846 ∧ code e2393421057846 = 11189514080054 := by decide
theorem cert_e2393421057846 : check e2393421057846 [[],[.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2393421057850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393421057850 : Closed e2393421057850 ∧ code e2393421057850 = 11189514080058 := by decide
theorem cert_e2393421057850 : check e2393421057850 [[],[.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2393421065774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2393421065774 : Closed e2393421065774 ∧ code e2393421065774 = 11189514087982 := by decide
theorem cert_e2393421065774 : check e2393421065774 [[],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2393421065954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2393421065954 : Closed e2393421065954 ∧ code e2393421065954 = 11189514088162 := by decide
def e2393421065966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2393421065966 : Closed e2393421065966 ∧ code e2393421065966 = 11189514088174 := by decide
def e2393421066006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2393421066006 : Closed e2393421066006 ∧ code e2393421066006 = 11189514088214 := by decide
theorem cert_e2393421066006 : check e2393421066006 [[],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2393421066082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2393421066082 : Closed e2393421066082 ∧ code e2393421066082 = 11189514088290 := by decide
def e2393421066094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2393421066094 : Closed e2393421066094 ∧ code e2393421066094 = 11189514088302 := by decide
def e2393421066102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2393421066102 : Closed e2393421066102 ∧ code e2393421066102 = 11189514088310 := by decide
def e2393421068350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2393421068350 : Closed e2393421068350 ∧ code e2393421068350 = 11189514090558 := by decide
theorem cert_e2393421068350 : check e2393421068350 [[],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2393421068770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2393421068770 : Closed e2393421068770 ∧ code e2393421068770 = 11189514090978 := by decide
theorem cert_e2393421068770 : check e2393421068770 [[],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2393421068782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393421068782 : Closed e2393421068782 ∧ code e2393421068782 = 11189514090990 := by decide
def e2393421069342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2393421069342 : Closed e2393421069342 ∧ code e2393421069342 = 11189514091550 := by decide
theorem cert_e2393421069342 : check e2393421069342 [[],[.left],[.left],[.left],[],[],[.left],[.left],[]] .chain = true := by decide
def e2393421069538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2393421069538 : Closed e2393421069538 ∧ code e2393421069538 = 11189514091746 := by decide
theorem cert_e2393421069538 : check e2393421069538 [[],[.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2393421069550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393421069550 : Closed e2393421069550 ∧ code e2393421069550 = 11189514091758 := by decide
def e2393421069558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393421069558 : Closed e2393421069558 ∧ code e2393421069558 = 11189514091766 := by decide
def e2393421092398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2393421092398 : Closed e2393421092398 ∧ code e2393421092398 = 11189514114606 := by decide
theorem cert_e2393421092398 : check e2393421092398 [[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393421092578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2393421092578 : Closed e2393421092578 ∧ code e2393421092578 = 11189514114786 := by decide
theorem cert_e2393421092578 : check e2393421092578 [[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393421092590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2393421092590 : Closed e2393421092590 ∧ code e2393421092590 = 11189514114798 := by decide
def e2393421092746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393421092746 : Closed e2393421092746 ∧ code e2393421092746 = 11189514114954 := by decide
theorem cert_e2393421092746 : check e2393421092746 [[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2393421092770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393421092770 : Closed e2393421092770 ∧ code e2393421092770 = 11189514114978 := by decide
theorem cert_e2393421092770 : check e2393421092770 [[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2393421092782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2393421092782 : Closed e2393421092782 ∧ code e2393421092782 = 11189514114990 := by decide
def e2393421092794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2393421092794 : Closed e2393421092794 ∧ code e2393421092794 = 11189514115002 := by decide
private def t_e2393421092794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem cert_e2393421092794 : ¬ IsSelfInterpreter e2393421092794 :=
  wSource (t := t_e2393421092794) (replay_sound (ps := []) (t := e2393421092794) (by decide)) (by decide)
def e2393421092926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2393421092926 : Closed e2393421092926 ∧ code e2393421092926 = 11189514115134 := by decide
theorem cert_e2393421092926 : check e2393421092926 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2393421093346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2393421093346 : Closed e2393421093346 ∧ code e2393421093346 = 11189514115554 := by decide
theorem cert_e2393421093346 : check e2393421093346 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393421093358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393421093358 : Closed e2393421093358 ∧ code e2393421093358 = 11189514115566 := by decide
def e2393421094414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2393421094414 : Closed e2393421094414 ∧ code e2393421094414 = 11189514116622 := by decide
theorem cert_e2393421094414 : check e2393421094414 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2393421094498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393421094498 : Closed e2393421094498 ∧ code e2393421094498 = 11189514116706 := by decide
theorem cert_e2393421094498 : check e2393421094498 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393421094510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393421094510 : Closed e2393421094510 ∧ code e2393421094510 = 11189514116718 := by decide
def e2393421094522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393421094522 : Closed e2393421094522 ∧ code e2393421094522 = 11189514116730 := by decide
def e2393421105942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2393421105942 : Closed e2393421105942 ∧ code e2393421105942 = 11189514128150 := by decide
theorem cert_e2393421105942 : check e2393421105942 [[],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left]] .chain = true := by decide
def e2393421106018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2393421106018 : Closed e2393421106018 ∧ code e2393421106018 = 11189514128226 := by decide
def e2393421106030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393421106030 : Closed e2393421106030 ∧ code e2393421106030 = 11189514128238 := by decide
def e2393421106038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393421106038 : Closed e2393421106038 ∧ code e2393421106038 = 11189514128246 := by decide
def e2393421106058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393421106058 : Closed e2393421106058 ∧ code e2393421106058 = 11189514128266 := by decide
def e2393421106082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393421106082 : Closed e2393421106082 ∧ code e2393421106082 = 11189514128290 := by decide
theorem cert_e2393421106082 : check e2393421106082 [[],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left,.left,.left]] .chain = true := by decide
def e2393421106094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393421106094 : Closed e2393421106094 ∧ code e2393421106094 = 11189514128302 := by decide
def e2393421106106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393421106106 : Closed e2393421106106 ∧ code e2393421106106 = 11189514128314 := by decide
private def t_e2393421106106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e2393421106106 : ¬ IsSelfInterpreter e2393421106106 :=
  wSource (t := t_e2393421106106) (replay_sound (ps := []) (t := e2393421106106) (by decide)) (by decide)
def e2393421106134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393421106134 : Closed e2393421106134 ∧ code e2393421106134 = 11189514128342 := by decide
def e2393421106138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393421106138 : Closed e2393421106138 ∧ code e2393421106138 = 11189514128346 := by decide
private def t_e2393421106138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e2393421106138 : ¬ IsSelfInterpreter e2393421106138 :=
  wSource (t := t_e2393421106138) (replay_sound (ps := []) (t := e2393421106138) (by decide)) (by decide)
def e2393421106206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2393421106206 : Closed e2393421106206 ∧ code e2393421106206 = 11189514128414 := by decide
theorem cert_e2393421106206 : check e2393421106206 [[],[.left],[.left],[.left],[],[],[.left],[.left],[]] .chain = true := by decide
def e2393421106402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2393421106402 : Closed e2393421106402 ∧ code e2393421106402 = 11189514128610 := by decide
def e2393421106414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393421106414 : Closed e2393421106414 ∧ code e2393421106414 = 11189514128622 := by decide
def e2393421106422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393421106422 : Closed e2393421106422 ∧ code e2393421106422 = 11189514128630 := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393421036426
#print axioms Blc.Floor43.cert_e2393421036450
#print axioms Blc.Floor43.cert_e2393421036462
#print axioms Blc.Floor43.cert_e2393421036474
#print axioms Blc.Floor43.cert_e2393421036938
#print axioms Blc.Floor43.cert_e2393421036962
#print axioms Blc.Floor43.cert_e2393421036974
#print axioms Blc.Floor43.cert_e2393421036986
#print axioms Blc.Floor43.cert_e2393421037014
#print axioms Blc.Floor43.cert_e2393421037018
#print axioms Blc.Floor43.cert_e2393421047738
#print axioms Blc.Floor43.cert_e2393421049358
#print axioms Blc.Floor43.cert_e2393421049442
#print axioms Blc.Floor43.cert_e2393421049454
#print axioms Blc.Floor43.cert_e2393421049466
#print axioms Blc.Floor43.cert_e2393421050810
#print axioms Blc.Floor43.cert_e2393421050842
#print axioms Blc.Floor43.cert_e2393421051406
#print axioms Blc.Floor43.cert_e2393421051490
#print axioms Blc.Floor43.cert_e2393421051502
#print axioms Blc.Floor43.cert_e2393421051514
#print axioms Blc.Floor43.cert_e2393421051702
#print axioms Blc.Floor43.cert_e2393421051706
#print axioms Blc.Floor43.cert_e2393421092794
#print axioms Blc.Floor43.cert_e2393421106106
#print axioms Blc.Floor43.cert_e2393421106138
