import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392699793038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2392699793038 : Closed e2392699793038 ∧ code e2392699793038 = 11188792815246 := by decide
theorem cert_e2392699793038 : check e2392699793038 [[],[.left],[]] .sourceHead = true := by decide
def e2392699793094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2392699793094 : Closed e2392699793094 ∧ code e2392699793094 = 11188792815302 := by decide
theorem cert_e2392699793094 : check e2392699793094 [[],[.left],[]] .sourceHead = true := by decide
def e2392699793838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2392699793838 : Closed e2392699793838 ∧ code e2392699793838 = 11188792816046 := by decide
theorem cert_e2392699793838 : check e2392699793838 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e2392699793850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2392699793850 : Closed e2392699793850 ∧ code e2392699793850 = 11188792816058 := by decide
theorem cert_e2392699793850 : check e2392699793850 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2392699793898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2392699793898 : Closed e2392699793898 ∧ code e2392699793898 = 11188792816106 := by decide
theorem cert_e2392699793898 : check e2392699793898 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392699794542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2392699794542 : Closed e2392699794542 ∧ code e2392699794542 = 11188792816750 := by decide
theorem cert_e2392699794542 : check e2392699794542 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e2392699794554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2392699794554 : Closed e2392699794554 ∧ code e2392699794554 = 11188792816762 := by decide
theorem cert_e2392699794554 : check e2392699794554 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2392699794718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2392699794718 : Closed e2392699794718 ∧ code e2392699794718 = 11188792816926 := by decide
theorem cert_e2392699794718 : check e2392699794718 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e2392699794886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2392699794886 : Closed e2392699794886 ∧ code e2392699794886 = 11188792817094 := by decide
theorem cert_e2392699794886 : check e2392699794886 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2392699795226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2392699795226 : Closed e2392699795226 ∧ code e2392699795226 = 11188792817434 := by decide
theorem cert_e2392699795226 : check e2392699795226 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392699795270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2392699795270 : Closed e2392699795270 ∧ code e2392699795270 = 11188792817478 := by decide
theorem cert_e2392699795270 : check e2392699795270 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392699795670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2392699795670 : Closed e2392699795670 ∧ code e2392699795670 = 11188792817878 := by decide
theorem cert_e2392699795670 : check e2392699795670 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .smaller = true := by decide
def e2392699795674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2392699795674 : Closed e2392699795674 ∧ code e2392699795674 = 11188792817882 := by decide
theorem cert_e2392699795674 : check e2392699795674 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2392699795690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2392699795690 : Closed e2392699795690 ∧ code e2392699795690 = 11188792817898 := by decide
theorem cert_e2392699795690 : check e2392699795690 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2392699796022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2392699796022 : Closed e2392699796022 ∧ code e2392699796022 = 11188792818230 := by decide
theorem cert_e2392699796022 : check e2392699796022 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392699796026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2392699796026 : Closed e2392699796026 ∧ code e2392699796026 = 11188792818234 := by decide
theorem cert_e2392699796026 : check e2392699796026 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2392699796110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2392699796110 : Closed e2392699796110 ∧ code e2392699796110 = 11188792818318 := by decide
theorem cert_e2392699796110 : check e2392699796110 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392699796166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2392699796166 : Closed e2392699796166 ∧ code e2392699796166 = 11188792818374 := by decide
theorem cert_e2392699796166 : check e2392699796166 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2392699796250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2392699796250 : Closed e2392699796250 ∧ code e2392699796250 = 11188792818458 := by decide
theorem cert_e2392699796250 : check e2392699796250 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2392699796294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2392699796294 : Closed e2392699796294 ∧ code e2392699796294 = 11188792818502 := by decide
theorem cert_e2392699796294 : check e2392699796294 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2392699800814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2392699800814 : Closed e2392699800814 ∧ code e2392699800814 = 11188792823022 := by decide
theorem cert_e2392699800814 : check e2392699800814 [[],[.left],[]] .sourceHead = true := by decide
def e2392699800822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2392699800822 : Closed e2392699800822 ∧ code e2392699800822 = 11188792823030 := by decide
theorem cert_e2392699800822 : check e2392699800822 [[],[.left],[]] .sourceHead = true := by decide
def e2392699801198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2392699801198 : Closed e2392699801198 ∧ code e2392699801198 = 11188792823406 := by decide
theorem cert_e2392699801198 : check e2392699801198 [[],[.left],[]] .sourceHead = true := by decide
def e2392699801210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2392699801210 : Closed e2392699801210 ∧ code e2392699801210 = 11188792823418 := by decide
theorem cert_e2392699801210 : check e2392699801210 [[],[.left],[]] .sourceHead = true := by decide
def e2392699801398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2392699801398 : Closed e2392699801398 ∧ code e2392699801398 = 11188792823606 := by decide
theorem cert_e2392699801398 : check e2392699801398 [[],[.left],[]] .sourceHead = true := by decide
def e2392699801402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2392699801402 : Closed e2392699801402 ∧ code e2392699801402 = 11188792823610 := by decide
theorem cert_e2392699801402 : check e2392699801402 [[],[.left],[]] .sourceHead = true := by decide
def e2392699803886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2392699803886 : Closed e2392699803886 ∧ code e2392699803886 = 11188792826094 := by decide
theorem cert_e2392699803886 : check e2392699803886 [[],[.left],[]] .sourceHead = true := by decide
def e2392699803894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2392699803894 : Closed e2392699803894 ∧ code e2392699803894 = 11188792826102 := by decide
theorem cert_e2392699803894 : check e2392699803894 [[],[.left],[]] .sourceHead = true := by decide
def e2392699804446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2392699804446 : Closed e2392699804446 ∧ code e2392699804446 = 11188792826654 := by decide
theorem cert_e2392699804446 : check e2392699804446 [[],[.left],[]] .sourceHead = true := by decide
def e2392699804558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2392699804558 : Closed e2392699804558 ∧ code e2392699804558 = 11188792826766 := by decide
theorem cert_e2392699804558 : check e2392699804558 [[],[.left],[]] .sourceHead = true := by decide
def e2392699804782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2392699804782 : Closed e2392699804782 ∧ code e2392699804782 = 11188792826990 := by decide
theorem cert_e2392699804782 : check e2392699804782 [[],[.left],[]] .sourceHead = true := by decide
def e2392699804794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2392699804794 : Closed e2392699804794 ∧ code e2392699804794 = 11188792827002 := by decide
theorem cert_e2392699804794 : check e2392699804794 [[],[.left],[]] .sourceHead = true := by decide
def e2392699804958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2392699804958 : Closed e2392699804958 ∧ code e2392699804958 = 11188792827166 := by decide
theorem cert_e2392699804958 : check e2392699804958 [[],[.left],[]] .sourceHead = true := by decide
def e2392699805126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2392699805126 : Closed e2392699805126 ∧ code e2392699805126 = 11188792827334 := by decide
theorem cert_e2392699805126 : check e2392699805126 [[],[.left],[]] .sourceHead = true := by decide
def e2392699805238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2392699805238 : Closed e2392699805238 ∧ code e2392699805238 = 11188792827446 := by decide
theorem cert_e2392699805238 : check e2392699805238 [[],[.left],[]] .sourceHead = true := by decide
def e2392699805242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2392699805242 : Closed e2392699805242 ∧ code e2392699805242 = 11188792827450 := by decide
theorem cert_e2392699805242 : check e2392699805242 [[],[.left],[]] .sourceHead = true := by decide
def e2392699805326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2392699805326 : Closed e2392699805326 ∧ code e2392699805326 = 11188792827534 := by decide
theorem cert_e2392699805326 : check e2392699805326 [[],[.left],[]] .sourceHead = true := by decide
def e2392699805382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2392699805382 : Closed e2392699805382 ∧ code e2392699805382 = 11188792827590 := by decide
theorem cert_e2392699805382 : check e2392699805382 [[],[.left],[]] .sourceHead = true := by decide
def e2392699807518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2392699807518 : Closed e2392699807518 ∧ code e2392699807518 = 11188792829726 := by decide
theorem cert_e2392699807518 : check e2392699807518 [[],[.left],[]] .sourceHead = true := by decide
def e2392699807630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2392699807630 : Closed e2392699807630 ∧ code e2392699807630 = 11188792829838 := by decide
theorem cert_e2392699807630 : check e2392699807630 [[],[.left],[]] .sourceHead = true := by decide
def e2392699810590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2392699810590 : Closed e2392699810590 ∧ code e2392699810590 = 11188792832798 := by decide
theorem cert_e2392699810590 : check e2392699810590 [[],[.left],[]] .sourceHead = true := by decide
def e2392699810758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2392699810758 : Closed e2392699810758 ∧ code e2392699810758 = 11188792832966 := by decide
theorem cert_e2392699810758 : check e2392699810758 [[],[.left],[]] .sourceHead = true := by decide
def e2392699812238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2392699812238 : Closed e2392699812238 ∧ code e2392699812238 = 11188792834446 := by decide
theorem cert_e2392699812238 : check e2392699812238 [[],[.left],[]] .sourceHead = true := by decide
def e2392699812294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2392699812294 : Closed e2392699812294 ∧ code e2392699812294 = 11188792834502 := by decide
theorem cert_e2392699812294 : check e2392699812294 [[],[.left],[]] .sourceHead = true := by decide
def e2392699815534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2392699815534 : Closed e2392699815534 ∧ code e2392699815534 = 11188792837742 := by decide
theorem cert_e2392699815534 : check e2392699815534 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2392699815546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2392699815546 : Closed e2392699815546 ∧ code e2392699815546 = 11188792837754 := by decide
theorem cert_e2392699815546 : check e2392699815546 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2392699815834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2392699815834 : Closed e2392699815834 ∧ code e2392699815834 = 11188792838042 := by decide
theorem cert_e2392699815834 : check e2392699815834 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392699817070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2392699817070 : Closed e2392699817070 ∧ code e2392699817070 = 11188792839278 := by decide
theorem cert_e2392699817070 : check e2392699817070 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2392699817082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2392699817082 : Closed e2392699817082 ∧ code e2392699817082 = 11188792839290 := by decide
theorem cert_e2392699817082 : check e2392699817082 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392699817246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2392699817246 : Closed e2392699817246 ∧ code e2392699817246 = 11188792839454 := by decide
theorem cert_e2392699817246 : check e2392699817246 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2392699817414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2392699817414 : Closed e2392699817414 ∧ code e2392699817414 = 11188792839622 := by decide
theorem cert_e2392699817414 : check e2392699817414 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392699817754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2392699817754 : Closed e2392699817754 ∧ code e2392699817754 = 11188792839962 := by decide
theorem cert_e2392699817754 : check e2392699817754 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392699817798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2392699817798 : Closed e2392699817798 ∧ code e2392699817798 = 11188792840006 := by decide
theorem cert_e2392699817798 : check e2392699817798 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392699818782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2392699818782 : Closed e2392699818782 ∧ code e2392699818782 = 11188792840990 := by decide
theorem cert_e2392699818782 : check e2392699818782 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2392699818950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2392699818950 : Closed e2392699818950 ∧ code e2392699818950 = 11188792841158 := by decide
theorem cert_e2392699818950 : check e2392699818950 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2392699821254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2392699821254 : Closed e2392699821254 ∧ code e2392699821254 = 11188792843462 := by decide
theorem cert_e2392699821254 : check e2392699821254 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392699822902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2392699822902 : Closed e2392699822902 ∧ code e2392699822902 = 11188792845110 := by decide
theorem cert_e2392699822902 : check e2392699822902 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392699822906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2392699822906 : Closed e2392699822906 ∧ code e2392699822906 = 11188792845114 := by decide
theorem cert_e2392699822906 : check e2392699822906 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392699823002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2392699823002 : Closed e2392699823002 ∧ code e2392699823002 = 11188792845210 := by decide
theorem cert_e2392699823002 : check e2392699823002 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392699823670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2392699823670 : Closed e2392699823670 ∧ code e2392699823670 = 11188792845878 := by decide
theorem cert_e2392699823670 : check e2392699823670 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392699823674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2392699823674 : Closed e2392699823674 ∧ code e2392699823674 = 11188792845882 := by decide
theorem cert_e2392699823674 : check e2392699823674 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392699823758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2392699823758 : Closed e2392699823758 ∧ code e2392699823758 = 11188792845966 := by decide
theorem cert_e2392699823758 : check e2392699823758 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392699823814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2392699823814 : Closed e2392699823814 ∧ code e2392699823814 = 11188792846022 := by decide
theorem cert_e2392699823814 : check e2392699823814 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392699823898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2392699823898 : Closed e2392699823898 ∧ code e2392699823898 = 11188792846106 := by decide
theorem cert_e2392699823898 : check e2392699823898 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392699823942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2392699823942 : Closed e2392699823942 ∧ code e2392699823942 = 11188792846150 := by decide
theorem cert_e2392699823942 : check e2392699823942 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392699824526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2392699824526 : Closed e2392699824526 ∧ code e2392699824526 = 11188792846734 := by decide
theorem cert_e2392699824526 : check e2392699824526 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392699824582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2392699824582 : Closed e2392699824582 ∧ code e2392699824582 = 11188792846790 := by decide
theorem cert_e2392699824582 : check e2392699824582 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392699825350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2392699825350 : Closed e2392699825350 ∧ code e2392699825350 = 11188792847558 := by decide
theorem cert_e2392699825350 : check e2392699825350 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392699836126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2392699836126 : Closed e2392699836126 ∧ code e2392699836126 = 11188792858334 := by decide
theorem cert_e2392699836126 : check e2392699836126 [[],[.left],[]] .chain = true := by decide
def e2392699836150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2392699836150 : Closed e2392699836150 ∧ code e2392699836150 = 11188792858358 := by decide
theorem cert_e2392699836150 : check e2392699836150 [[],[.left],[]] .chain = true := by decide
def e2392699836254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2392699836254 : Closed e2392699836254 ∧ code e2392699836254 = 11188792858462 := by decide
theorem cert_e2392699836254 : check e2392699836254 [[],[.left],[]] .chain = true := by decide
def e2392699836282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2392699836282 : Closed e2392699836282 ∧ code e2392699836282 = 11188792858490 := by decide
theorem cert_e2392699836282 : check e2392699836282 [[],[.left],[]] .chain = true := by decide
def e2392699836374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2392699836374 : Closed e2392699836374 ∧ code e2392699836374 = 11188792858582 := by decide
theorem cert_e2392699836374 : check e2392699836374 [[],[.left],[]] .chain = true := by decide
def e2392699836378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2392699836378 : Closed e2392699836378 ∧ code e2392699836378 = 11188792858586 := by decide
theorem cert_e2392699836378 : check e2392699836378 [[],[.left],[]] .chain = true := by decide
def e2392699836894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2392699836894 : Closed e2392699836894 ∧ code e2392699836894 = 11188792859102 := by decide
theorem cert_e2392699836894 : check e2392699836894 [[],[.left],[]] .chain = true := by decide
def e2392699836918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2392699836918 : Closed e2392699836918 ∧ code e2392699836918 = 11188792859126 := by decide
theorem cert_e2392699836918 : check e2392699836918 [[],[.left],[]] .chain = true := by decide
def e2392699837662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392699837662 : Closed e2392699837662 ∧ code e2392699837662 = 11188792859870 := by decide
theorem cert_e2392699837662 : check e2392699837662 [[],[.left],[]] .chain = true := by decide
def e2392699837690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392699837690 : Closed e2392699837690 ∧ code e2392699837690 = 11188792859898 := by decide
theorem cert_e2392699837690 : check e2392699837690 [[],[.left],[]] .chain = true := by decide
def e2392699838262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392699838262 : Closed e2392699838262 ∧ code e2392699838262 = 11188792860470 := by decide
theorem cert_e2392699838262 : check e2392699838262 [[],[.left],[]] .chain = true := by decide
def e2392699838266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392699838266 : Closed e2392699838266 ∧ code e2392699838266 = 11188792860474 := by decide
theorem cert_e2392699838266 : check e2392699838266 [[],[.left],[]] .chain = true := by decide
def e2392699853038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2392699853038 : Closed e2392699853038 ∧ code e2392699853038 = 11188792875246 := by decide
theorem cert_e2392699853038 : check e2392699853038 [[],[.left],[]] .sourceHead = true := by decide
def e2392699853046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2392699853046 : Closed e2392699853046 ∧ code e2392699853046 = 11188792875254 := by decide
theorem cert_e2392699853046 : check e2392699853046 [[],[.left],[]] .sourceHead = true := by decide
def e2392699853598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2392699853598 : Closed e2392699853598 ∧ code e2392699853598 = 11188792875806 := by decide
theorem cert_e2392699853598 : check e2392699853598 [[],[.left],[]] .sourceHead = true := by decide
def e2392699853710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2392699853710 : Closed e2392699853710 ∧ code e2392699853710 = 11188792875918 := by decide
theorem cert_e2392699853710 : check e2392699853710 [[],[.left],[]] .sourceHead = true := by decide
def e2392699853934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2392699853934 : Closed e2392699853934 ∧ code e2392699853934 = 11188792876142 := by decide
theorem cert_e2392699853934 : check e2392699853934 [[],[.left],[]] .sourceHead = true := by decide
def e2392699853946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2392699853946 : Closed e2392699853946 ∧ code e2392699853946 = 11188792876154 := by decide
theorem cert_e2392699853946 : check e2392699853946 [[],[.left],[]] .sourceHead = true := by decide
def e2392699854110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2392699854110 : Closed e2392699854110 ∧ code e2392699854110 = 11188792876318 := by decide
theorem cert_e2392699854110 : check e2392699854110 [[],[.left],[]] .sourceHead = true := by decide
def e2392699854278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2392699854278 : Closed e2392699854278 ∧ code e2392699854278 = 11188792876486 := by decide
theorem cert_e2392699854278 : check e2392699854278 [[],[.left],[]] .sourceHead = true := by decide
def e2392699854390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2392699854390 : Closed e2392699854390 ∧ code e2392699854390 = 11188792876598 := by decide
theorem cert_e2392699854390 : check e2392699854390 [[],[.left],[]] .sourceHead = true := by decide
def e2392699854394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2392699854394 : Closed e2392699854394 ∧ code e2392699854394 = 11188792876602 := by decide
theorem cert_e2392699854394 : check e2392699854394 [[],[.left],[]] .sourceHead = true := by decide
def e2392699854478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2392699854478 : Closed e2392699854478 ∧ code e2392699854478 = 11188792876686 := by decide
theorem cert_e2392699854478 : check e2392699854478 [[],[.left],[]] .sourceHead = true := by decide
def e2392699854534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2392699854534 : Closed e2392699854534 ∧ code e2392699854534 = 11188792876742 := by decide
theorem cert_e2392699854534 : check e2392699854534 [[],[.left],[]] .sourceHead = true := by decide
def e2392699856670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2392699856670 : Closed e2392699856670 ∧ code e2392699856670 = 11188792878878 := by decide
theorem cert_e2392699856670 : check e2392699856670 [[],[.left],[]] .sourceHead = true := by decide
def e2392699856782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2392699856782 : Closed e2392699856782 ∧ code e2392699856782 = 11188792878990 := by decide
theorem cert_e2392699856782 : check e2392699856782 [[],[.left],[]] .sourceHead = true := by decide
def e2392699859742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2392699859742 : Closed e2392699859742 ∧ code e2392699859742 = 11188792881950 := by decide
theorem cert_e2392699859742 : check e2392699859742 [[],[.left],[]] .sourceHead = true := by decide
def e2392699859910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2392699859910 : Closed e2392699859910 ∧ code e2392699859910 = 11188792882118 := by decide
theorem cert_e2392699859910 : check e2392699859910 [[],[.left],[]] .sourceHead = true := by decide
def e2392699861390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2392699861390 : Closed e2392699861390 ∧ code e2392699861390 = 11188792883598 := by decide
theorem cert_e2392699861390 : check e2392699861390 [[],[.left],[]] .sourceHead = true := by decide
def e2392699861446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2392699861446 : Closed e2392699861446 ∧ code e2392699861446 = 11188792883654 := by decide
theorem cert_e2392699861446 : check e2392699861446 [[],[.left],[]] .sourceHead = true := by decide
def e2392699898734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392699898734 : Closed e2392699898734 ∧ code e2392699898734 = 11188792920942 := by decide
theorem cert_e2392699898734 : check e2392699898734 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699898742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392699898742 : Closed e2392699898742 ∧ code e2392699898742 = 11188792920950 := by decide
theorem cert_e2392699898742 : check e2392699898742 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699898798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392699898798 : Closed e2392699898798 ∧ code e2392699898798 = 11188792921006 := by decide
theorem cert_e2392699898798 : check e2392699898798 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699898810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392699898810 : Closed e2392699898810 ∧ code e2392699898810 = 11188792921018 := by decide
theorem cert_e2392699898810 : check e2392699898810 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699898838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392699898838 : Closed e2392699898838 ∧ code e2392699898838 = 11188792921046 := by decide
theorem cert_e2392699898838 : check e2392699898838 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699898842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392699898842 : Closed e2392699898842 ∧ code e2392699898842 = 11188792921050 := by decide
theorem cert_e2392699898842 : check e2392699898842 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699899118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392699899118 : Closed e2392699899118 ∧ code e2392699899118 = 11188792921326 := by decide
theorem cert_e2392699899118 : check e2392699899118 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699899126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392699899126 : Closed e2392699899126 ∧ code e2392699899126 = 11188792921334 := by decide
theorem cert_e2392699899126 : check e2392699899126 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699899502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392699899502 : Closed e2392699899502 ∧ code e2392699899502 = 11188792921710 := by decide
theorem cert_e2392699899502 : check e2392699899502 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699899514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392699899514 : Closed e2392699899514 ∧ code e2392699899514 = 11188792921722 := by decide
theorem cert_e2392699899514 : check e2392699899514 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699899702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392699899702 : Closed e2392699899702 ∧ code e2392699899702 = 11188792921910 := by decide
theorem cert_e2392699899702 : check e2392699899702 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699899706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392699899706 : Closed e2392699899706 ∧ code e2392699899706 = 11188792921914 := by decide
theorem cert_e2392699899706 : check e2392699899706 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699907182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2392699907182 : Closed e2392699907182 ∧ code e2392699907182 = 11188792929390 := by decide
theorem cert_e2392699907182 : check e2392699907182 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699907194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2392699907194 : Closed e2392699907194 ∧ code e2392699907194 = 11188792929402 := by decide
theorem cert_e2392699907194 : check e2392699907194 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699907358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2392699907358 : Closed e2392699907358 ∧ code e2392699907358 = 11188792929566 := by decide
theorem cert_e2392699907358 : check e2392699907358 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699907526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2392699907526 : Closed e2392699907526 ∧ code e2392699907526 = 11188792929734 := by decide
theorem cert_e2392699907526 : check e2392699907526 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699907866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2392699907866 : Closed e2392699907866 ∧ code e2392699907866 = 11188792930074 := by decide
theorem cert_e2392699907866 : check e2392699907866 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699907910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2392699907910 : Closed e2392699907910 ∧ code e2392699907910 = 11188792930118 := by decide
theorem cert_e2392699907910 : check e2392699907910 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699908894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2392699908894 : Closed e2392699908894 ∧ code e2392699908894 = 11188792931102 := by decide
theorem cert_e2392699908894 : check e2392699908894 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699909062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2392699909062 : Closed e2392699909062 ∧ code e2392699909062 = 11188792931270 := by decide
theorem cert_e2392699909062 : check e2392699909062 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699911366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2392699911366 : Closed e2392699911366 ∧ code e2392699911366 = 11188792933574 := by decide
theorem cert_e2392699911366 : check e2392699911366 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392699934262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2392699934262 : Closed e2392699934262 ∧ code e2392699934262 = 11188792956470 := by decide
theorem cert_e2392699934262 : check e2392699934262 [[],[.left],[],[.under]] .three = true := by decide
def e2392699934266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2392699934266 : Closed e2392699934266 ∧ code e2392699934266 = 11188792956474 := by decide
theorem cert_e2392699934266 : check e2392699934266 [[],[.left],[],[.under]] .three = true := by decide
def e2392699934350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2392699934350 : Closed e2392699934350 ∧ code e2392699934350 = 11188792956558 := by decide
theorem cert_e2392699934350 : check e2392699934350 [[],[.left],[],[.under]] .three = true := by decide
def e2392699934406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2392699934406 : Closed e2392699934406 ∧ code e2392699934406 = 11188792956614 := by decide
theorem cert_e2392699934406 : check e2392699934406 [[],[.left],[],[.under]] .three = true := by decide
def e2392699934490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2392699934490 : Closed e2392699934490 ∧ code e2392699934490 = 11188792956698 := by decide
theorem cert_e2392699934490 : check e2392699934490 [[],[.left],[],[.under]] .three = true := by decide
def e2392699934534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2392699934534 : Closed e2392699934534 ∧ code e2392699934534 = 11188792956742 := by decide
theorem cert_e2392699934534 : check e2392699934534 [[],[.left],[],[.under]] .three = true := by decide
def e2392699935118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2392699935118 : Closed e2392699935118 ∧ code e2392699935118 = 11188792957326 := by decide
theorem cert_e2392699935118 : check e2392699935118 [[],[.left],[],[.under]] .three = true := by decide
def e2392699935174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2392699935174 : Closed e2392699935174 ∧ code e2392699935174 = 11188792957382 := by decide
theorem cert_e2392699935174 : check e2392699935174 [[],[.left],[],[.under]] .three = true := by decide
def e2392699935942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2392699935942 : Closed e2392699935942 ∧ code e2392699935942 = 11188792958150 := by decide
theorem cert_e2392699935942 : check e2392699935942 [[],[.left],[],[.under]] .three = true := by decide
def e2392701032686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2392701032686 : Closed e2392701032686 ∧ code e2392701032686 = 11188794054894 := by decide
theorem cert_e2392701032686 : check e2392701032686 [[],[.left],[],[]] .smaller = true := by decide
def e2392701032694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2392701032694 : Closed e2392701032694 ∧ code e2392701032694 = 11188794054902 := by decide
theorem cert_e2392701032694 : check e2392701032694 [[],[.left],[],[]] .smaller = true := by decide
def e2392701033246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2392701033246 : Closed e2392701033246 ∧ code e2392701033246 = 11188794055454 := by decide
theorem cert_e2392701033246 : check e2392701033246 [[],[.left],[],[]] .smaller = true := by decide
def e2392701033358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2392701033358 : Closed e2392701033358 ∧ code e2392701033358 = 11188794055566 := by decide
theorem cert_e2392701033358 : check e2392701033358 [[],[.left],[],[]] .smaller = true := by decide
def e2392701033582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2392701033582 : Closed e2392701033582 ∧ code e2392701033582 = 11188794055790 := by decide
theorem cert_e2392701033582 : check e2392701033582 [[],[.left],[],[]] .smaller = true := by decide
def e2392701033594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2392701033594 : Closed e2392701033594 ∧ code e2392701033594 = 11188794055802 := by decide
theorem cert_e2392701033594 : check e2392701033594 [[],[.left],[],[]] .smaller = true := by decide
def e2392701033758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2392701033758 : Closed e2392701033758 ∧ code e2392701033758 = 11188794055966 := by decide
theorem cert_e2392701033758 : check e2392701033758 [[],[.left],[],[]] .smaller = true := by decide
def e2392701033926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2392701033926 : Closed e2392701033926 ∧ code e2392701033926 = 11188794056134 := by decide
theorem cert_e2392701033926 : check e2392701033926 [[],[.left],[],[]] .smaller = true := by decide
def e2392701034038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2392701034038 : Closed e2392701034038 ∧ code e2392701034038 = 11188794056246 := by decide
theorem cert_e2392701034038 : check e2392701034038 [[],[.left],[],[]] .smaller = true := by decide
def e2392701034042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2392701034042 : Closed e2392701034042 ∧ code e2392701034042 = 11188794056250 := by decide
theorem cert_e2392701034042 : check e2392701034042 [[],[.left],[],[]] .smaller = true := by decide
def e2392701034126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2392701034126 : Closed e2392701034126 ∧ code e2392701034126 = 11188794056334 := by decide
theorem cert_e2392701034126 : check e2392701034126 [[],[.left],[],[]] .smaller = true := by decide
def e2392701034182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2392701034182 : Closed e2392701034182 ∧ code e2392701034182 = 11188794056390 := by decide
theorem cert_e2392701034182 : check e2392701034182 [[],[.left],[],[]] .smaller = true := by decide
def e2392701036318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2392701036318 : Closed e2392701036318 ∧ code e2392701036318 = 11188794058526 := by decide
theorem cert_e2392701036318 : check e2392701036318 [[],[.left],[],[]] .smaller = true := by decide
def e2392701036430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2392701036430 : Closed e2392701036430 ∧ code e2392701036430 = 11188794058638 := by decide
theorem cert_e2392701036430 : check e2392701036430 [[],[.left],[],[]] .smaller = true := by decide
def e2392701039390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2392701039390 : Closed e2392701039390 ∧ code e2392701039390 = 11188794061598 := by decide
theorem cert_e2392701039390 : check e2392701039390 [[],[.left],[],[]] .smaller = true := by decide
def e2392701039558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2392701039558 : Closed e2392701039558 ∧ code e2392701039558 = 11188794061766 := by decide
theorem cert_e2392701039558 : check e2392701039558 [[],[.left],[],[]] .smaller = true := by decide
def e2392701041038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2392701041038 : Closed e2392701041038 ∧ code e2392701041038 = 11188794063246 := by decide
theorem cert_e2392701041038 : check e2392701041038 [[],[.left],[],[]] .smaller = true := by decide
def e2392701041094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2392701041094 : Closed e2392701041094 ∧ code e2392701041094 = 11188794063302 := by decide
theorem cert_e2392701041094 : check e2392701041094 [[],[.left],[],[]] .smaller = true := by decide
def e2392705734366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2392705734366 : Closed e2392705734366 ∧ code e2392705734366 = 11188798756574 := by decide
theorem cert_e2392705734366 : check e2392705734366 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2392705734390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2392705734390 : Closed e2392705734390 ∧ code e2392705734390 = 11188798756598 := by decide
theorem cert_e2392705734390 : check e2392705734390 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2392705734494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2392705734494 : Closed e2392705734494 ∧ code e2392705734494 = 11188798756702 := by decide
theorem cert_e2392705734494 : check e2392705734494 [[],[.left],[.left],[.left],[],[.under,.left],[.under],[.under],[.under]] .smaller = true := by decide
def e2392705734522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2392705734522 : Closed e2392705734522 ∧ code e2392705734522 = 11188798756730 := by decide
theorem cert_e2392705734522 : check e2392705734522 [[],[.left],[.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392705734614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2392705734614 : Closed e2392705734614 ∧ code e2392705734614 = 11188798756822 := by decide
theorem cert_e2392705734614 : check e2392705734614 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2392705734618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2392705734618 : Closed e2392705734618 ∧ code e2392705734618 = 11188798756826 := by decide
theorem cert_e2392705734618 : check e2392705734618 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2392705735134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2392705735134 : Closed e2392705735134 ∧ code e2392705735134 = 11188798757342 := by decide
theorem cert_e2392705735134 : check e2392705735134 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2392705735158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2392705735158 : Closed e2392705735158 ∧ code e2392705735158 = 11188798757366 := by decide
theorem cert_e2392705735158 : check e2392705735158 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2392705735902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392705735902 : Closed e2392705735902 ∧ code e2392705735902 = 11188798758110 := by decide
theorem cert_e2392705735902 : check e2392705735902 [[],[.left],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2392705735930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392705735930 : Closed e2392705735930 ∧ code e2392705735930 = 11188798758138 := by decide
theorem cert_e2392705735930 : check e2392705735930 [[],[.left],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2392705736502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392705736502 : Closed e2392705736502 ∧ code e2392705736502 = 11188798758710 := by decide
theorem cert_e2392705736502 : check e2392705736502 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2392705736506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392705736506 : Closed e2392705736506 ∧ code e2392705736506 = 11188798758714 := by decide
theorem cert_e2392705736506 : check e2392705736506 [[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under],[.under]] .three = true := by decide
def e2392705751278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2392705751278 : Closed e2392705751278 ∧ code e2392705751278 = 11188798773486 := by decide
theorem cert_e2392705751278 : check e2392705751278 [[],[.left],[.left],[.left],[],[.left],[],[],[]] .sourceHead = true := by decide
def e2392705751286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2392705751286 : Closed e2392705751286 ∧ code e2392705751286 = 11188798773494 := by decide
theorem cert_e2392705751286 : check e2392705751286 [[],[.left],[.left],[.left],[],[.left],[],[]] .sourceHead = true := by decide
end Blc.Floor43
