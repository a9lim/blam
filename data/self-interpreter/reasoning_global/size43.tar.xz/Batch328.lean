import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418117684762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117684762 : Closed e2418117684762 ∧ code e2418117684762 = 11214210706970 := by decide
def e2418117687834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117687834 : Closed e2418117687834 ∧ code e2418117687834 = 11214210710042 := by decide
def e2418117695002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117695002 : Closed e2418117695002 ∧ code e2418117695002 = 11214210717210 := by decide
def e2418117696026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117696026 : Closed e2418117696026 ∧ code e2418117696026 = 11214210718234 := by decide
def e2418117766682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117766682 : Closed e2418117766682 ∧ code e2418117766682 = 11214210788890 := by decide
def e2418117768730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117768730 : Closed e2418117768730 ∧ code e2418117768730 = 11214210790938 := by decide
def e2418117864986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117864986 : Closed e2418117864986 ∧ code e2418117864986 = 11214210887194 := by decide
def e2418117868058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117868058 : Closed e2418117868058 ∧ code e2418117868058 = 11214210890266 := by decide
def e2418117916186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117916186 : Closed e2418117916186 ∧ code e2418117916186 = 11214210938394 := by decide
theorem cert_e2418117916186 : check e2418117916186 [[],[],[.left],[.left],[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2418117917210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418117917210 : Closed e2418117917210 ∧ code e2418117917210 = 11214210939418 := by decide
theorem cert_e2418117917210 : check e2418117917210 [[],[],[.left],[.left],[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2418117933082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418117933082 : Closed e2418117933082 ∧ code e2418117933082 = 11214210955290 := by decide
theorem cert_e2418117933082 : check e2418117933082 [[]] .width = true := by decide
def e2418117949466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418117949466 : Closed e2418117949466 ∧ code e2418117949466 = 11214210971674 := by decide
theorem cert_e2418117949466 : check e2418117949466 [[]] .width = true := by decide
def e2418119915546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418119915546 : Closed e2418119915546 ∧ code e2418119915546 = 11214212937754 := by decide
theorem cert_e2418119915546 : check e2418119915546 [[]] .width = true := by decide
def e2418119923738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418119923738 : Closed e2418119923738 ∧ code e2418119923738 = 11214212945946 := by decide
theorem cert_e2418119923738 : check e2418119923738 [[]] .width = true := by decide
def e2418119945754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418119945754 : Closed e2418119945754 ∧ code e2418119945754 = 11214212967962 := by decide
theorem cert_e2418119945754 : check e2418119945754 [[]] .width = true := by decide
def e2418119981082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418119981082 : Closed e2418119981082 ∧ code e2418119981082 = 11214213003290 := by decide
theorem cert_e2418119981082 : check e2418119981082 [[]] .width = true := by decide
def e2418119991834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418119991834 : Closed e2418119991834 ∧ code e2418119991834 = 11214213014042 := by decide
theorem cert_e2418119991834 : check e2418119991834 [[]] .width = true := by decide
def e2418119993370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418119993370 : Closed e2418119993370 ∧ code e2418119993370 = 11214213015578 := by decide
theorem cert_e2418119993370 : check e2418119993370 [[]] .width = true := by decide
def e2418119994906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418119994906 : Closed e2418119994906 ∧ code e2418119994906 = 11214213017114 := by decide
theorem cert_e2418119994906 : check e2418119994906 [[]] .width = true := by decide
def e2418120005146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120005146 : Closed e2418120005146 ∧ code e2418120005146 = 11214213027354 := by decide
theorem cert_e2418120005146 : check e2418120005146 [[]] .width = true := by decide
def e2418120022042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418120022042 : Closed e2418120022042 ∧ code e2418120022042 = 11214213044250 := by decide
theorem cert_e2418120022042 : check e2418120022042 [[]] .width = true := by decide
def e2418120024602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120024602 : Closed e2418120024602 ∧ code e2418120024602 = 11214213046810 := by decide
theorem cert_e2418120024602 : check e2418120024602 [[]] .width = true := by decide
def e2418120026138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418120026138 : Closed e2418120026138 ∧ code e2418120026138 = 11214213048346 := by decide
theorem cert_e2418120026138 : check e2418120026138 [[]] .width = true := by decide
def e2418120027674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120027674 : Closed e2418120027674 ∧ code e2418120027674 = 11214213049882 := by decide
theorem cert_e2418120027674 : check e2418120027674 [[]] .width = true := by decide
def e2418120029722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120029722 : Closed e2418120029722 ∧ code e2418120029722 = 11214213051930 := by decide
theorem cert_e2418120029722 : check e2418120029722 [[]] .width = true := by decide
def e2418120308762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418120308762 : Closed e2418120308762 ∧ code e2418120308762 = 11214213330970 := by decide
theorem cert_e2418120308762 : check e2418120308762 [[]] .width = true := by decide
def e2418120316954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418120316954 : Closed e2418120316954 ∧ code e2418120316954 = 11214213339162 := by decide
theorem cert_e2418120316954 : check e2418120316954 [[]] .width = true := by decide
def e2418120605210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120605210 : Closed e2418120605210 ∧ code e2418120605210 = 11214213627418 := by decide
theorem cert_e2418120605210 : check e2418120605210 [[]] .width = true := by decide
def e2418120650950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418120650950 : Closed e2418120650950 ∧ code e2418120650950 = 11214213673158 := by decide
theorem cert_e2418120650950 : check e2418120650950 [[]] .width = true := by decide
def e2418120701978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418120701978 : Closed e2418120701978 ∧ code e2418120701978 = 11214213724186 := by decide
theorem cert_e2418120701978 : check e2418120701978 [[]] .width = true := by decide
def e2418120712730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120712730 : Closed e2418120712730 ∧ code e2418120712730 = 11214213734938 := by decide
theorem cert_e2418120712730 : check e2418120712730 [[]] .width = true := by decide
def e2418120714266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418120714266 : Closed e2418120714266 ∧ code e2418120714266 = 11214213736474 := by decide
theorem cert_e2418120714266 : check e2418120714266 [[]] .width = true := by decide
def e2418120715802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120715802 : Closed e2418120715802 ∧ code e2418120715802 = 11214213738010 := by decide
theorem cert_e2418120715802 : check e2418120715802 [[]] .width = true := by decide
def e2418120818714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418120818714 : Closed e2418120818714 ∧ code e2418120818714 = 11214213840922 := by decide
theorem cert_e2418120818714 : check e2418120818714 [[]] .width = true := by decide
def e2418120818806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418120818806 : Closed e2418120818806 ∧ code e2418120818806 = 11214213841014 := by decide
theorem cert_e2418120818806 : check e2418120818806 [[]] .width = true := by decide
def e2418120819050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418120819050 : Closed e2418120819050 ∧ code e2418120819050 = 11214213841258 := by decide
theorem cert_e2418120819050 : check e2418120819050 [[]] .width = true := by decide
def e2418120819098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418120819098 : Closed e2418120819098 ∧ code e2418120819098 = 11214213841306 := by decide
theorem cert_e2418120819098 : check e2418120819098 [[]] .width = true := by decide
def e2418120820106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418120820106 : Closed e2418120820106 ∧ code e2418120820106 = 11214213842314 := by decide
theorem cert_e2418120820106 : check e2418120820106 [[]] .width = true := by decide
def e2418120820130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418120820130 : Closed e2418120820130 ∧ code e2418120820130 = 11214213842338 := by decide
theorem cert_e2418120820130 : check e2418120820130 [[]] .width = true := by decide
def e2418120820238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418120820238 : Closed e2418120820238 ∧ code e2418120820238 = 11214213842446 := by decide
theorem cert_e2418120820238 : check e2418120820238 [[]] .width = true := by decide
def e2418120820250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418120820250 : Closed e2418120820250 ∧ code e2418120820250 = 11214213842458 := by decide
theorem cert_e2418120820250 : check e2418120820250 [[]] .width = true := by decide
def e2418120820322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418120820322 : Closed e2418120820322 ∧ code e2418120820322 = 11214213842530 := by decide
theorem cert_e2418120820322 : check e2418120820322 [[]] .width = true := by decide
def e2418120859162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120859162 : Closed e2418120859162 ∧ code e2418120859162 = 11214213881370 := by decide
theorem cert_e2418120859162 : check e2418120859162 [[]] .width = true := by decide
def e2418120880326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418120880326 : Closed e2418120880326 ∧ code e2418120880326 = 11214213902534 := by decide
theorem cert_e2418120880326 : check e2418120880326 [[]] .width = true := by decide
def e2418120906778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418120906778 : Closed e2418120906778 ∧ code e2418120906778 = 11214213928986 := by decide
theorem cert_e2418120906778 : check e2418120906778 [[]] .width = true := by decide
def e2418120909338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120909338 : Closed e2418120909338 ∧ code e2418120909338 = 11214213931546 := by decide
theorem cert_e2418120909338 : check e2418120909338 [[]] .width = true := by decide
def e2418120910874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418120910874 : Closed e2418120910874 ∧ code e2418120910874 = 11214213933082 := by decide
theorem cert_e2418120910874 : check e2418120910874 [[]] .width = true := by decide
def e2418120912410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120912410 : Closed e2418120912410 ∧ code e2418120912410 = 11214213934618 := by decide
theorem cert_e2418120912410 : check e2418120912410 [[]] .width = true := by decide
def e2418120914458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418120914458 : Closed e2418120914458 ∧ code e2418120914458 = 11214213936666 := by decide
theorem cert_e2418120914458 : check e2418120914458 [[]] .width = true := by decide
def e2418120949786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418120949786 : Closed e2418120949786 ∧ code e2418120949786 = 11214213971994 := by decide
theorem cert_e2418120949786 : check e2418120949786 [[]] .width = true := by decide
def e2418120949878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418120949878 : Closed e2418120949878 ∧ code e2418120949878 = 11214213972086 := by decide
theorem cert_e2418120949878 : check e2418120949878 [[]] .width = true := by decide
def e2418120950122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418120950122 : Closed e2418120950122 ∧ code e2418120950122 = 11214213972330 := by decide
theorem cert_e2418120950122 : check e2418120950122 [[]] .width = true := by decide
def e2418120950170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418120950170 : Closed e2418120950170 ∧ code e2418120950170 = 11214213972378 := by decide
theorem cert_e2418120950170 : check e2418120950170 [[]] .width = true := by decide
def e2418120951178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418120951178 : Closed e2418120951178 ∧ code e2418120951178 = 11214213973386 := by decide
theorem cert_e2418120951178 : check e2418120951178 [[]] .width = true := by decide
def e2418120951202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418120951202 : Closed e2418120951202 ∧ code e2418120951202 = 11214213973410 := by decide
theorem cert_e2418120951202 : check e2418120951202 [[]] .width = true := by decide
def e2418120951310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418120951310 : Closed e2418120951310 ∧ code e2418120951310 = 11214213973518 := by decide
theorem cert_e2418120951310 : check e2418120951310 [[]] .width = true := by decide
def e2418120951322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418120951322 : Closed e2418120951322 ∧ code e2418120951322 = 11214213973530 := by decide
theorem cert_e2418120951322 : check e2418120951322 [[]] .width = true := by decide
def e2418120951394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418120951394 : Closed e2418120951394 ∧ code e2418120951394 = 11214213973602 := by decide
theorem cert_e2418120951394 : check e2418120951394 [[]] .width = true := by decide
def e2418125797402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418125797402 : Closed e2418125797402 ∧ code e2418125797402 = 11214218819610 := by decide
theorem cert_e2418125797402 : check e2418125797402 [[]] .width = true := by decide
def e2418125821978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418125821978 : Closed e2418125821978 ∧ code e2418125821978 = 11214218844186 := by decide
theorem cert_e2418125821978 : check e2418125821978 [[]] .width = true := by decide
def e2418126761498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418126761498 : Closed e2418126761498 ∧ code e2418126761498 = 11214219783706 := by decide
theorem cert_e2418126761498 : check e2418126761498 [[]] .width = true := by decide
def e2418126796826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418126796826 : Closed e2418126796826 ∧ code e2418126796826 = 11214219819034 := by decide
theorem cert_e2418126796826 : check e2418126796826 [[]] .width = true := by decide
def e2418126807578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418126807578 : Closed e2418126807578 ∧ code e2418126807578 = 11214219829786 := by decide
theorem cert_e2418126807578 : check e2418126807578 [[]] .width = true := by decide
def e2418126809114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418126809114 : Closed e2418126809114 ∧ code e2418126809114 = 11214219831322 := by decide
theorem cert_e2418126809114 : check e2418126809114 [[]] .width = true := by decide
def e2418126810650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418126810650 : Closed e2418126810650 ∧ code e2418126810650 = 11214219832858 := by decide
theorem cert_e2418126810650 : check e2418126810650 [[]] .width = true := by decide
def e2418126850586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418126850586 : Closed e2418126850586 ∧ code e2418126850586 = 11214219872794 := by decide
theorem cert_e2418126850586 : check e2418126850586 [[]] .width = true := by decide
def e2418126856730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418126856730 : Closed e2418126856730 ∧ code e2418126856730 = 11214219878938 := by decide
theorem cert_e2418126856730 : check e2418126856730 [[]] .width = true := by decide
def e2418126858266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418126858266 : Closed e2418126858266 ∧ code e2418126858266 = 11214219880474 := by decide
theorem cert_e2418126858266 : check e2418126858266 [[]] .width = true := by decide
def e2418126859802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418126859802 : Closed e2418126859802 ∧ code e2418126859802 = 11214219882010 := by decide
theorem cert_e2418126859802 : check e2418126859802 [[]] .width = true := by decide
def e2418126862874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418126862874 : Closed e2418126862874 ∧ code e2418126862874 = 11214219885082 := by decide
private def t_e2418126862874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418126862874 : ¬ IsSelfInterpreter e2418126862874 :=
  wSource (t := t_e2418126862874) (replay_sound (ps := []) (t := e2418126862874) (by decide)) (by decide)
def e2418126896666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418126896666 : Closed e2418126896666 ∧ code e2418126896666 = 11214219918874 := by decide
theorem cert_e2418126896666 : check e2418126896666 [[]] .width = true := by decide
def e2418126942406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418126942406 : Closed e2418126942406 ∧ code e2418126942406 = 11214219964614 := by decide
theorem cert_e2418126942406 : check e2418126942406 [[]] .width = true := by decide
def e2418126993434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418126993434 : Closed e2418126993434 ∧ code e2418126993434 = 11214220015642 := by decide
theorem cert_e2418126993434 : check e2418126993434 [[]] .width = true := by decide
def e2418127004186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418127004186 : Closed e2418127004186 ∧ code e2418127004186 = 11214220026394 := by decide
theorem cert_e2418127004186 : check e2418127004186 [[]] .width = true := by decide
def e2418127005722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418127005722 : Closed e2418127005722 ∧ code e2418127005722 = 11214220027930 := by decide
theorem cert_e2418127005722 : check e2418127005722 [[]] .width = true := by decide
def e2418127007258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418127007258 : Closed e2418127007258 ∧ code e2418127007258 = 11214220029466 := by decide
theorem cert_e2418127007258 : check e2418127007258 [[]] .width = true := by decide
def e2418127110170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418127110170 : Closed e2418127110170 ∧ code e2418127110170 = 11214220132378 := by decide
theorem cert_e2418127110170 : check e2418127110170 [[]] .width = true := by decide
def e2418127110262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418127110262 : Closed e2418127110262 ∧ code e2418127110262 = 11214220132470 := by decide
theorem cert_e2418127110262 : check e2418127110262 [[]] .width = true := by decide
def e2418127110506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418127110506 : Closed e2418127110506 ∧ code e2418127110506 = 11214220132714 := by decide
theorem cert_e2418127110506 : check e2418127110506 [[]] .width = true := by decide
def e2418127110554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418127110554 : Closed e2418127110554 ∧ code e2418127110554 = 11214220132762 := by decide
theorem cert_e2418127110554 : check e2418127110554 [[]] .width = true := by decide
def e2418127111562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418127111562 : Closed e2418127111562 ∧ code e2418127111562 = 11214220133770 := by decide
theorem cert_e2418127111562 : check e2418127111562 [[]] .width = true := by decide
def e2418127111586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418127111586 : Closed e2418127111586 ∧ code e2418127111586 = 11214220133794 := by decide
theorem cert_e2418127111586 : check e2418127111586 [[]] .width = true := by decide
def e2418127111694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418127111694 : Closed e2418127111694 ∧ code e2418127111694 = 11214220133902 := by decide
theorem cert_e2418127111694 : check e2418127111694 [[]] .width = true := by decide
def e2418127111706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418127111706 : Closed e2418127111706 ∧ code e2418127111706 = 11214220133914 := by decide
theorem cert_e2418127111706 : check e2418127111706 [[]] .width = true := by decide
def e2418127111778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418127111778 : Closed e2418127111778 ∧ code e2418127111778 = 11214220133986 := by decide
theorem cert_e2418127111778 : check e2418127111778 [[]] .width = true := by decide
def e2418127277594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418127277594 : Closed e2418127277594 ∧ code e2418127277594 = 11214220299802 := by decide
theorem cert_e2418127277594 : check e2418127277594 [[]] .width = true := by decide
def e2418127286470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418127286470 : Closed e2418127286470 ∧ code e2418127286470 = 11214220308678 := by decide
theorem cert_e2418127286470 : check e2418127286470 [[]] .width = true := by decide
def e2418127299098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418127299098 : Closed e2418127299098 ∧ code e2418127299098 = 11214220321306 := by decide
theorem cert_e2418127299098 : check e2418127299098 [[]] .width = true := by decide
def e2418127300634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418127300634 : Closed e2418127300634 ∧ code e2418127300634 = 11214220322842 := by decide
theorem cert_e2418127300634 : check e2418127300634 [[]] .width = true := by decide
def e2418127302170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418127302170 : Closed e2418127302170 ∧ code e2418127302170 = 11214220324378 := by decide
theorem cert_e2418127302170 : check e2418127302170 [[]] .width = true := by decide
def e2418127305242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418127305242 : Closed e2418127305242 ∧ code e2418127305242 = 11214220327450 := by decide
theorem cert_e2418127305242 : check e2418127305242 [[]] .width = true := by decide
def e2418127306778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418127306778 : Closed e2418127306778 ∧ code e2418127306778 = 11214220328986 := by decide
theorem cert_e2418127306778 : check e2418127306778 [[]] .width = true := by decide
def e2418127306870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418127306870 : Closed e2418127306870 ∧ code e2418127306870 = 11214220329078 := by decide
theorem cert_e2418127306870 : check e2418127306870 [[]] .width = true := by decide
def e2418127307114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418127307114 : Closed e2418127307114 ∧ code e2418127307114 = 11214220329322 := by decide
theorem cert_e2418127307114 : check e2418127307114 [[]] .width = true := by decide
def e2418127307162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418127307162 : Closed e2418127307162 ∧ code e2418127307162 = 11214220329370 := by decide
theorem cert_e2418127307162 : check e2418127307162 [[]] .width = true := by decide
def e2418127308170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418127308170 : Closed e2418127308170 ∧ code e2418127308170 = 11214220330378 := by decide
theorem cert_e2418127308170 : check e2418127308170 [[]] .width = true := by decide
def e2418127308194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418127308194 : Closed e2418127308194 ∧ code e2418127308194 = 11214220330402 := by decide
theorem cert_e2418127308194 : check e2418127308194 [[]] .width = true := by decide
def e2418127308302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418127308302 : Closed e2418127308302 ∧ code e2418127308302 = 11214220330510 := by decide
theorem cert_e2418127308302 : check e2418127308302 [[]] .width = true := by decide
def e2418127308314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418127308314 : Closed e2418127308314 ∧ code e2418127308314 = 11214220330522 := by decide
theorem cert_e2418127308314 : check e2418127308314 [[]] .width = true := by decide
def e2418127308386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418127308386 : Closed e2418127308386 ∧ code e2418127308386 = 11214220330594 := by decide
theorem cert_e2418127308386 : check e2418127308386 [[]] .width = true := by decide
def e2418129745946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418129745946 : Closed e2418129745946 ∧ code e2418129745946 = 11214222768154 := by decide
theorem cert_e2418129745946 : check e2418129745946 [[]] .width = true := by decide
def e2418129754138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418129754138 : Closed e2418129754138 ∧ code e2418129754138 = 11214222776346 := by decide
theorem cert_e2418129754138 : check e2418129754138 [[]] .width = true := by decide
def e2418130228762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130228762 : Closed e2418130228762 ∧ code e2418130228762 = 11214223250970 := by decide
theorem cert_e2418130228762 : check e2418130228762 [[]] .width = true := by decide
def e2418130245658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418130245658 : Closed e2418130245658 ∧ code e2418130245658 = 11214223267866 := by decide
theorem cert_e2418130245658 : check e2418130245658 [[]] .width = true := by decide
def e2418130248218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130248218 : Closed e2418130248218 ∧ code e2418130248218 = 11214223270426 := by decide
theorem cert_e2418130248218 : check e2418130248218 [[]] .width = true := by decide
def e2418130249754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418130249754 : Closed e2418130249754 ∧ code e2418130249754 = 11214223271962 := by decide
theorem cert_e2418130249754 : check e2418130249754 [[]] .width = true := by decide
def e2418130251290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130251290 : Closed e2418130251290 ∧ code e2418130251290 = 11214223273498 := by decide
theorem cert_e2418130251290 : check e2418130251290 [[]] .width = true := by decide
def e2418130253338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130253338 : Closed e2418130253338 ∧ code e2418130253338 = 11214223275546 := by decide
theorem cert_e2418130253338 : check e2418130253338 [[]] .width = true := by decide
def e2418130258458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130258458 : Closed e2418130258458 ∧ code e2418130258458 = 11214223280666 := by decide
theorem cert_e2418130258458 : check e2418130258458 [[]] .width = true := by decide
def e2418130264602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130264602 : Closed e2418130264602 ∧ code e2418130264602 = 11214223286810 := by decide
theorem cert_e2418130264602 : check e2418130264602 [[]] .width = true := by decide
def e2418130266138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418130266138 : Closed e2418130266138 ∧ code e2418130266138 = 11214223288346 := by decide
theorem cert_e2418130266138 : check e2418130266138 [[]] .width = true := by decide
def e2418130267674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130267674 : Closed e2418130267674 ∧ code e2418130267674 = 11214223289882 := by decide
theorem cert_e2418130267674 : check e2418130267674 [[]] .width = true := by decide
def e2418130270746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130270746 : Closed e2418130270746 ∧ code e2418130270746 = 11214223292954 := by decide
private def t_e2418130270746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418130270746 : ¬ IsSelfInterpreter e2418130270746 :=
  wSource (t := t_e2418130270746) (replay_sound (ps := []) (t := e2418130270746) (by decide)) (by decide)
def e2418130277914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130277914 : Closed e2418130277914 ∧ code e2418130277914 = 11214223300122 := by decide
theorem cert_e2418130277914 : check e2418130277914 [[]] .width = true := by decide
def e2418130278938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130278938 : Closed e2418130278938 ∧ code e2418130278938 = 11214223301146 := by decide
private def t_e2418130278938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418130278938 : ¬ IsSelfInterpreter e2418130278938 :=
  wSource (t := t_e2418130278938) (replay_sound (ps := []) (t := e2418130278938) (by decide)) (by decide)
def e2418130296346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130296346 : Closed e2418130296346 ∧ code e2418130296346 = 11214223318554 := by decide
theorem cert_e2418130296346 : check e2418130296346 [[]] .width = true := by decide
def e2418130317510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418130317510 : Closed e2418130317510 ∧ code e2418130317510 = 11214223339718 := by decide
theorem cert_e2418130317510 : check e2418130317510 [[]] .width = true := by decide
def e2418130343962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418130343962 : Closed e2418130343962 ∧ code e2418130343962 = 11214223366170 := by decide
theorem cert_e2418130343962 : check e2418130343962 [[]] .width = true := by decide
def e2418130346522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130346522 : Closed e2418130346522 ∧ code e2418130346522 = 11214223368730 := by decide
theorem cert_e2418130346522 : check e2418130346522 [[]] .width = true := by decide
def e2418130348058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418130348058 : Closed e2418130348058 ∧ code e2418130348058 = 11214223370266 := by decide
theorem cert_e2418130348058 : check e2418130348058 [[]] .width = true := by decide
def e2418130349594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130349594 : Closed e2418130349594 ∧ code e2418130349594 = 11214223371802 := by decide
theorem cert_e2418130349594 : check e2418130349594 [[]] .width = true := by decide
def e2418130351642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130351642 : Closed e2418130351642 ∧ code e2418130351642 = 11214223373850 := by decide
theorem cert_e2418130351642 : check e2418130351642 [[]] .width = true := by decide
def e2418130386970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418130386970 : Closed e2418130386970 ∧ code e2418130386970 = 11214223409178 := by decide
theorem cert_e2418130386970 : check e2418130386970 [[]] .width = true := by decide
def e2418130387062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418130387062 : Closed e2418130387062 ∧ code e2418130387062 = 11214223409270 := by decide
theorem cert_e2418130387062 : check e2418130387062 [[]] .width = true := by decide
def e2418130387306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418130387306 : Closed e2418130387306 ∧ code e2418130387306 = 11214223409514 := by decide
theorem cert_e2418130387306 : check e2418130387306 [[]] .width = true := by decide
def e2418130387354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418130387354 : Closed e2418130387354 ∧ code e2418130387354 = 11214223409562 := by decide
theorem cert_e2418130387354 : check e2418130387354 [[]] .width = true := by decide
def e2418130388362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418130388362 : Closed e2418130388362 ∧ code e2418130388362 = 11214223410570 := by decide
theorem cert_e2418130388362 : check e2418130388362 [[]] .width = true := by decide
def e2418130388386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418130388386 : Closed e2418130388386 ∧ code e2418130388386 = 11214223410594 := by decide
theorem cert_e2418130388386 : check e2418130388386 [[]] .width = true := by decide
def e2418130388494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418130388494 : Closed e2418130388494 ∧ code e2418130388494 = 11214223410702 := by decide
theorem cert_e2418130388494 : check e2418130388494 [[]] .width = true := by decide
def e2418130388506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418130388506 : Closed e2418130388506 ∧ code e2418130388506 = 11214223410714 := by decide
theorem cert_e2418130388506 : check e2418130388506 [[]] .width = true := by decide
def e2418130388578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418130388578 : Closed e2418130388578 ∧ code e2418130388578 = 11214223410786 := by decide
theorem cert_e2418130388578 : check e2418130388578 [[]] .width = true := by decide
def e2418130423322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130423322 : Closed e2418130423322 ∧ code e2418130423322 = 11214223445530 := by decide
theorem cert_e2418130423322 : check e2418130423322 [[]] .width = true := by decide
def e2418130432198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418130432198 : Closed e2418130432198 ∧ code e2418130432198 = 11214223454406 := by decide
theorem cert_e2418130432198 : check e2418130432198 [[]] .width = true := by decide
def e2418130444826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130444826 : Closed e2418130444826 ∧ code e2418130444826 = 11214223467034 := by decide
theorem cert_e2418130444826 : check e2418130444826 [[]] .width = true := by decide
def e2418130446362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418130446362 : Closed e2418130446362 ∧ code e2418130446362 = 11214223468570 := by decide
theorem cert_e2418130446362 : check e2418130446362 [[]] .width = true := by decide
def e2418130447898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130447898 : Closed e2418130447898 ∧ code e2418130447898 = 11214223470106 := by decide
theorem cert_e2418130447898 : check e2418130447898 [[]] .width = true := by decide
def e2418130450970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130450970 : Closed e2418130450970 ∧ code e2418130450970 = 11214223473178 := by decide
theorem cert_e2418130450970 : check e2418130450970 [[]] .width = true := by decide
def e2418130452506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2418130452506 : Closed e2418130452506 ∧ code e2418130452506 = 11214223474714 := by decide
theorem cert_e2418130452506 : check e2418130452506 [[]] .width = true := by decide
def e2418130452598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2418130452598 : Closed e2418130452598 ∧ code e2418130452598 = 11214223474806 := by decide
theorem cert_e2418130452598 : check e2418130452598 [[]] .width = true := by decide
def e2418130452842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2418130452842 : Closed e2418130452842 ∧ code e2418130452842 = 11214223475050 := by decide
theorem cert_e2418130452842 : check e2418130452842 [[]] .width = true := by decide
def e2418130452890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2418130452890 : Closed e2418130452890 ∧ code e2418130452890 = 11214223475098 := by decide
theorem cert_e2418130452890 : check e2418130452890 [[]] .width = true := by decide
def e2418130453898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2418130453898 : Closed e2418130453898 ∧ code e2418130453898 = 11214223476106 := by decide
theorem cert_e2418130453898 : check e2418130453898 [[]] .width = true := by decide
def e2418130453922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2418130453922 : Closed e2418130453922 ∧ code e2418130453922 = 11214223476130 := by decide
theorem cert_e2418130453922 : check e2418130453922 [[]] .width = true := by decide
def e2418130454030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2418130454030 : Closed e2418130454030 ∧ code e2418130454030 = 11214223476238 := by decide
theorem cert_e2418130454030 : check e2418130454030 [[]] .width = true := by decide
def e2418130454042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418130454042 : Closed e2418130454042 ∧ code e2418130454042 = 11214223476250 := by decide
theorem cert_e2418130454042 : check e2418130454042 [[]] .width = true := by decide
def e2418130454114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2418130454114 : Closed e2418130454114 ∧ code e2418130454114 = 11214223476322 := by decide
theorem cert_e2418130454114 : check e2418130454114 [[]] .width = true := by decide
def e2418130499098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130499098 : Closed e2418130499098 ∧ code e2418130499098 = 11214223521306 := by decide
theorem cert_e2418130499098 : check e2418130499098 [[]] .width = true := by decide
def e2418130500122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418130500122 : Closed e2418130500122 ∧ code e2418130500122 = 11214223522330 := by decide
theorem cert_e2418130500122 : check e2418130500122 [[]] .width = true := by decide
def e2418133740910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2418133740910 : Closed e2418133740910 ∧ code e2418133740910 = 11214226763118 := by decide
theorem cert_e2418133740910 : check e2418133740910 [[],[]] .smaller = true := by decide
def e2418133740918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2418133740918 : Closed e2418133740918 ∧ code e2418133740918 = 11214226763126 := by decide
theorem cert_e2418133740918 : check e2418133740918 [[],[]] .smaller = true := by decide
def e2418133740974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2418133740974 : Closed e2418133740974 ∧ code e2418133740974 = 11214226763182 := by decide
theorem cert_e2418133740974 : check e2418133740974 [[],[]] .smaller = true := by decide
def e2418133740986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2418133740986 : Closed e2418133740986 ∧ code e2418133740986 = 11214226763194 := by decide
theorem cert_e2418133740986 : check e2418133740986 [[],[]] .smaller = true := by decide
def e2418133741014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2418133741014 : Closed e2418133741014 ∧ code e2418133741014 = 11214226763222 := by decide
theorem cert_e2418133741014 : check e2418133741014 [[],[]] .smaller = true := by decide
def e2418133741018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2418133741018 : Closed e2418133741018 ∧ code e2418133741018 = 11214226763226 := by decide
theorem cert_e2418133741018 : check e2418133741018 [[],[]] .smaller = true := by decide
def e2418133741230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2418133741230 : Closed e2418133741230 ∧ code e2418133741230 = 11214226763438 := by decide
theorem cert_e2418133741230 : check e2418133741230 [[],[]] .smaller = true := by decide
def e2418133741242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2418133741242 : Closed e2418133741242 ∧ code e2418133741242 = 11214226763450 := by decide
theorem cert_e2418133741242 : check e2418133741242 [[],[]] .smaller = true := by decide
def e2418133741290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2418133741290 : Closed e2418133741290 ∧ code e2418133741290 = 11214226763498 := by decide
theorem cert_e2418133741290 : check e2418133741290 [[],[]] .smaller = true := by decide
def e2418133741398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2418133741398 : Closed e2418133741398 ∧ code e2418133741398 = 11214226763606 := by decide
theorem cert_e2418133741398 : check e2418133741398 [[],[]] .smaller = true := by decide
def e2418133741402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2418133741402 : Closed e2418133741402 ∧ code e2418133741402 = 11214226763610 := by decide
theorem cert_e2418133741402 : check e2418133741402 [[],[]] .smaller = true := by decide
def e2418133741418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2418133741418 : Closed e2418133741418 ∧ code e2418133741418 = 11214226763626 := by decide
theorem cert_e2418133741418 : check e2418133741418 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2418126862874
#print axioms Blc.Floor43.cert_e2418130270746
#print axioms Blc.Floor43.cert_e2418130278938
