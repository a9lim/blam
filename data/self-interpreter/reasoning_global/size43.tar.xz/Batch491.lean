import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422408108278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422408108278 : Closed e2422408108278 ∧ code e2422408108278 = 11218501130486 := by decide
theorem cert_e2422408108278 : check e2422408108278 [[],[]] .chain = true := by decide
def e2422408108830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422408108830 : Closed e2422408108830 ∧ code e2422408108830 = 11218501131038 := by decide
theorem cert_e2422408108830 : check e2422408108830 [[],[]] .chain = true := by decide
def e2422408108942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422408108942 : Closed e2422408108942 ∧ code e2422408108942 = 11218501131150 := by decide
theorem cert_e2422408108942 : check e2422408108942 [[],[]] .chain = true := by decide
def e2422408109166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422408109166 : Closed e2422408109166 ∧ code e2422408109166 = 11218501131374 := by decide
theorem cert_e2422408109166 : check e2422408109166 [[],[]] .chain = true := by decide
def e2422408109178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422408109178 : Closed e2422408109178 ∧ code e2422408109178 = 11218501131386 := by decide
theorem cert_e2422408109178 : check e2422408109178 [[],[]] .chain = true := by decide
def e2422408109342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422408109342 : Closed e2422408109342 ∧ code e2422408109342 = 11218501131550 := by decide
theorem cert_e2422408109342 : check e2422408109342 [[],[]] .chain = true := by decide
def e2422408109510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422408109510 : Closed e2422408109510 ∧ code e2422408109510 = 11218501131718 := by decide
theorem cert_e2422408109510 : check e2422408109510 [[],[]] .chain = true := by decide
def e2422408109622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422408109622 : Closed e2422408109622 ∧ code e2422408109622 = 11218501131830 := by decide
theorem cert_e2422408109622 : check e2422408109622 [[],[]] .chain = true := by decide
def e2422408109626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422408109626 : Closed e2422408109626 ∧ code e2422408109626 = 11218501131834 := by decide
theorem cert_e2422408109626 : check e2422408109626 [[],[]] .chain = true := by decide
def e2422408109710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422408109710 : Closed e2422408109710 ∧ code e2422408109710 = 11218501131918 := by decide
theorem cert_e2422408109710 : check e2422408109710 [[],[]] .chain = true := by decide
def e2422408109766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422408109766 : Closed e2422408109766 ∧ code e2422408109766 = 11218501131974 := by decide
theorem cert_e2422408109766 : check e2422408109766 [[],[]] .chain = true := by decide
def e2422408111902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422408111902 : Closed e2422408111902 ∧ code e2422408111902 = 11218501134110 := by decide
theorem cert_e2422408111902 : check e2422408111902 [[],[]] .chain = true := by decide
def e2422408112014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422408112014 : Closed e2422408112014 ∧ code e2422408112014 = 11218501134222 := by decide
theorem cert_e2422408112014 : check e2422408112014 [[],[]] .chain = true := by decide
def e2422408114398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422408114398 : Closed e2422408114398 ∧ code e2422408114398 = 11218501136606 := by decide
theorem cert_e2422408114398 : check e2422408114398 [[],[]] .chain = true := by decide
def e2422408114426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422408114426 : Closed e2422408114426 ∧ code e2422408114426 = 11218501136634 := by decide
theorem cert_e2422408114426 : check e2422408114426 [[],[]] .chain = true := by decide
def e2422408114974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422408114974 : Closed e2422408114974 ∧ code e2422408114974 = 11218501137182 := by decide
theorem cert_e2422408114974 : check e2422408114974 [[],[]] .chain = true := by decide
def e2422408115142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422408115142 : Closed e2422408115142 ∧ code e2422408115142 = 11218501137350 := by decide
theorem cert_e2422408115142 : check e2422408115142 [[],[]] .chain = true := by decide
def e2422408116334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408116334 : Closed e2422408116334 ∧ code e2422408116334 = 11218501138542 := by decide
theorem cert_e2422408116334 : check e2422408116334 [[],[]] .chain = true := by decide
def e2422408116346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408116346 : Closed e2422408116346 ∧ code e2422408116346 = 11218501138554 := by decide
theorem cert_e2422408116346 : check e2422408116346 [[],[]] .chain = true := by decide
def e2422408116622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422408116622 : Closed e2422408116622 ∧ code e2422408116622 = 11218501138830 := by decide
theorem cert_e2422408116622 : check e2422408116622 [[],[]] .chain = true := by decide
def e2422408116678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422408116678 : Closed e2422408116678 ∧ code e2422408116678 = 11218501138886 := by decide
theorem cert_e2422408116678 : check e2422408116678 [[],[]] .chain = true := by decide
def e2422408153950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2422408153950 : Closed e2422408153950 ∧ code e2422408153950 = 11218501176158 := by decide
theorem cert_e2422408153950 : check e2422408153950 [[],[]] .chain = true := by decide
def e2422408153966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422408153966 : Closed e2422408153966 ∧ code e2422408153966 = 11218501176174 := by decide
theorem cert_e2422408153966 : check e2422408153966 [[],[]] .smaller = true := by decide
def e2422408153974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422408153974 : Closed e2422408153974 ∧ code e2422408153974 = 11218501176182 := by decide
theorem cert_e2422408153974 : check e2422408153974 [[],[]] .smaller = true := by decide
def e2422408153978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2422408153978 : Closed e2422408153978 ∧ code e2422408153978 = 11218501176186 := by decide
theorem cert_e2422408153978 : check e2422408153978 [[],[]] .chain = true := by decide
def e2422408154030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422408154030 : Closed e2422408154030 ∧ code e2422408154030 = 11218501176238 := by decide
theorem cert_e2422408154030 : check e2422408154030 [[],[]] .smaller = true := by decide
def e2422408154042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422408154042 : Closed e2422408154042 ∧ code e2422408154042 = 11218501176250 := by decide
theorem cert_e2422408154042 : check e2422408154042 [[],[]] .smaller = true := by decide
def e2422408154070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422408154070 : Closed e2422408154070 ∧ code e2422408154070 = 11218501176278 := by decide
theorem cert_e2422408154070 : check e2422408154070 [[],[]] .smaller = true := by decide
def e2422408154074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422408154074 : Closed e2422408154074 ∧ code e2422408154074 = 11218501176282 := by decide
theorem cert_e2422408154074 : check e2422408154074 [[],[]] .smaller = true := by decide
def e2422408154090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2422408154090 : Closed e2422408154090 ∧ code e2422408154090 = 11218501176298 := by decide
theorem cert_e2422408154090 : check e2422408154090 [[],[]] .chain = true := by decide
def e2422408154334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422408154334 : Closed e2422408154334 ∧ code e2422408154334 = 11218501176542 := by decide
theorem cert_e2422408154334 : check e2422408154334 [[],[]] .chain = true := by decide
def e2422408154350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422408154350 : Closed e2422408154350 ∧ code e2422408154350 = 11218501176558 := by decide
theorem cert_e2422408154350 : check e2422408154350 [[],[]] .smaller = true := by decide
def e2422408154358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422408154358 : Closed e2422408154358 ∧ code e2422408154358 = 11218501176566 := by decide
theorem cert_e2422408154358 : check e2422408154358 [[],[]] .smaller = true := by decide
def e2422408154362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422408154362 : Closed e2422408154362 ∧ code e2422408154362 = 11218501176570 := by decide
theorem cert_e2422408154362 : check e2422408154362 [[],[]] .chain = true := by decide
def e2422408154686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2422408154686 : Closed e2422408154686 ∧ code e2422408154686 = 11218501176894 := by decide
theorem cert_e2422408154686 : check e2422408154686 [[],[]] .chain = true := by decide
def e2422408154734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408154734 : Closed e2422408154734 ∧ code e2422408154734 = 11218501176942 := by decide
theorem cert_e2422408154734 : check e2422408154734 [[],[]] .smaller = true := by decide
def e2422408154746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408154746 : Closed e2422408154746 ∧ code e2422408154746 = 11218501176954 := by decide
theorem cert_e2422408154746 : check e2422408154746 [[],[]] .smaller = true := by decide
def e2422408154934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422408154934 : Closed e2422408154934 ∧ code e2422408154934 = 11218501177142 := by decide
theorem cert_e2422408154934 : check e2422408154934 [[],[]] .smaller = true := by decide
def e2422408154938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422408154938 : Closed e2422408154938 ∧ code e2422408154938 = 11218501177146 := by decide
theorem cert_e2422408154938 : check e2422408154938 [[],[]] .smaller = true := by decide
def e2422408155022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2422408155022 : Closed e2422408155022 ∧ code e2422408155022 = 11218501177230 := by decide
theorem cert_e2422408155022 : check e2422408155022 [[],[]] .chain = true := by decide
def e2422408155034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408155034 : Closed e2422408155034 ∧ code e2422408155034 = 11218501177242 := by decide
theorem cert_e2422408155034 : check e2422408155034 [[],[]] .chain = true := by decide
def e2422408162414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422408162414 : Closed e2422408162414 ∧ code e2422408162414 = 11218501184622 := by decide
theorem cert_e2422408162414 : check e2422408162414 [[],[]] .chain = true := by decide
def e2422408162426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422408162426 : Closed e2422408162426 ∧ code e2422408162426 = 11218501184634 := by decide
theorem cert_e2422408162426 : check e2422408162426 [[],[]] .chain = true := by decide
def e2422408162590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422408162590 : Closed e2422408162590 ∧ code e2422408162590 = 11218501184798 := by decide
theorem cert_e2422408162590 : check e2422408162590 [[],[]] .chain = true := by decide
def e2422408162758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422408162758 : Closed e2422408162758 ∧ code e2422408162758 = 11218501184966 := by decide
theorem cert_e2422408162758 : check e2422408162758 [[],[]] .chain = true := by decide
def e2422408162862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422408162862 : Closed e2422408162862 ∧ code e2422408162862 = 11218501185070 := by decide
theorem cert_e2422408162862 : check e2422408162862 [[],[]] .chain = true := by decide
def e2422408163042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422408163042 : Closed e2422408163042 ∧ code e2422408163042 = 11218501185250 := by decide
theorem cert_e2422408163042 : check e2422408163042 [[],[]] .chain = true := by decide
def e2422408163054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2422408163054 : Closed e2422408163054 ∧ code e2422408163054 = 11218501185262 := by decide
theorem cert_e2422408163054 : checkPay e2422408163054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2422408163094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422408163094 : Closed e2422408163094 ∧ code e2422408163094 = 11218501185302 := by decide
theorem cert_e2422408163094 : check e2422408163094 [[],[]] .chain = true := by decide
def e2422408163098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422408163098 : Closed e2422408163098 ∧ code e2422408163098 = 11218501185306 := by decide
theorem cert_e2422408163098 : check e2422408163098 [[],[]] .chain = true := by decide
def e2422408163142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422408163142 : Closed e2422408163142 ∧ code e2422408163142 = 11218501185350 := by decide
theorem cert_e2422408163142 : check e2422408163142 [[],[]] .chain = true := by decide
def e2422408163170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422408163170 : Closed e2422408163170 ∧ code e2422408163170 = 11218501185378 := by decide
theorem cert_e2422408163170 : check e2422408163170 [[],[]] .chain = true := by decide
def e2422408163182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2422408163182 : Closed e2422408163182 ∧ code e2422408163182 = 11218501185390 := by decide
theorem cert_e2422408163182 : checkPay e2422408163182 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2422408163190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2422408163190 : Closed e2422408163190 ∧ code e2422408163190 = 11218501185398 := by decide
theorem cert_e2422408163190 : checkPay e2422408163190 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2422408163550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422408163550 : Closed e2422408163550 ∧ code e2422408163550 = 11218501185758 := by decide
theorem cert_e2422408163550 : check e2422408163550 [[],[]] .chain = true := by decide
def e2422408163578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422408163578 : Closed e2422408163578 ∧ code e2422408163578 = 11218501185786 := by decide
theorem cert_e2422408163578 : check e2422408163578 [[],[]] .chain = true := by decide
def e2422408164126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422408164126 : Closed e2422408164126 ∧ code e2422408164126 = 11218501186334 := by decide
theorem cert_e2422408164126 : check e2422408164126 [[],[]] .chain = true := by decide
def e2422408164294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422408164294 : Closed e2422408164294 ∧ code e2422408164294 = 11218501186502 := by decide
theorem cert_e2422408164294 : check e2422408164294 [[],[]] .chain = true := by decide
def e2422408165438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e2422408165438 : Closed e2422408165438 ∧ code e2422408165438 = 11218501187646 := by decide
theorem cert_e2422408165438 : check e2422408165438 [[],[]] .chain = true := by decide
def e2422408165858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422408165858 : Closed e2422408165858 ∧ code e2422408165858 = 11218501188066 := by decide
theorem cert_e2422408165858 : check e2422408165858 [[],[]] .chain = true := by decide
def e2422408165870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2422408165870 : Closed e2422408165870 ∧ code e2422408165870 = 11218501188078 := by decide
theorem cert_e2422408165870 : checkPay e2422408165870 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2422408166430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e2422408166430 : Closed e2422408166430 ∧ code e2422408166430 = 11218501188638 := by decide
theorem cert_e2422408166430 : check e2422408166430 [[],[]] .chain = true := by decide
def e2422408166454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422408166454 : Closed e2422408166454 ∧ code e2422408166454 = 11218501188662 := by decide
theorem cert_e2422408166454 : check e2422408166454 [[],[]] .chain = true := by decide
def e2422408166458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422408166458 : Closed e2422408166458 ∧ code e2422408166458 = 11218501188666 := by decide
theorem cert_e2422408166458 : check e2422408166458 [[],[]] .chain = true := by decide
def e2422408166598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422408166598 : Closed e2422408166598 ∧ code e2422408166598 = 11218501188806 := by decide
theorem cert_e2422408166598 : check e2422408166598 [[],[]] .chain = true := by decide
def e2422408166626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422408166626 : Closed e2422408166626 ∧ code e2422408166626 = 11218501188834 := by decide
theorem cert_e2422408166626 : check e2422408166626 [[],[]] .chain = true := by decide
def e2422408166638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408166638 : Closed e2422408166638 ∧ code e2422408166638 = 11218501188846 := by decide
theorem cert_e2422408166638 : checkPay e2422408166638 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2422408166646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408166646 : Closed e2422408166646 ∧ code e2422408166646 = 11218501188854 := by decide
theorem cert_e2422408166646 : checkPay e2422408166646 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] 0 [] = true := by decide
def e2422408185262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422408185262 : Closed e2422408185262 ∧ code e2422408185262 = 11218501207470 := by decide
theorem cert_e2422408185262 : check e2422408185262 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408185274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422408185274 : Closed e2422408185274 ∧ code e2422408185274 = 11218501207482 := by decide
theorem cert_e2422408185274 : check e2422408185274 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408185322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422408185322 : Closed e2422408185322 ∧ code e2422408185322 = 11218501207530 := by decide
theorem cert_e2422408185322 : check e2422408185322 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408185454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408185454 : Closed e2422408185454 ∧ code e2422408185454 = 11218501207662 := by decide
theorem cert_e2422408185454 : check e2422408185454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408185466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408185466 : Closed e2422408185466 ∧ code e2422408185466 = 11218501207674 := by decide
theorem cert_e2422408185466 : check e2422408185466 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408185630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422408185630 : Closed e2422408185630 ∧ code e2422408185630 = 11218501207838 := by decide
theorem cert_e2422408185630 : check e2422408185630 [[],[]] .chain = true := by decide
def e2422408185742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422408185742 : Closed e2422408185742 ∧ code e2422408185742 = 11218501207950 := by decide
theorem cert_e2422408185742 : check e2422408185742 [[],[]] .chain = true := by decide
def e2422408185754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408185754 : Closed e2422408185754 ∧ code e2422408185754 = 11218501207962 := by decide
theorem cert_e2422408185754 : check e2422408185754 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408189494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422408189494 : Closed e2422408189494 ∧ code e2422408189494 = 11218501211702 := by decide
theorem cert_e2422408189494 : check e2422408189494 [[],[]] .chain = true := by decide
def e2422408189498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422408189498 : Closed e2422408189498 ∧ code e2422408189498 = 11218501211706 := by decide
theorem cert_e2422408189498 : check e2422408189498 [[],[]] .chain = true := by decide
def e2422408189582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422408189582 : Closed e2422408189582 ∧ code e2422408189582 = 11218501211790 := by decide
theorem cert_e2422408189582 : check e2422408189582 [[],[]] .chain = true := by decide
def e2422408189638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422408189638 : Closed e2422408189638 ∧ code e2422408189638 = 11218501211846 := by decide
theorem cert_e2422408189638 : check e2422408189638 [[],[]] .chain = true := by decide
def e2422408189718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422408189718 : Closed e2422408189718 ∧ code e2422408189718 = 11218501211926 := by decide
theorem cert_e2422408189718 : check e2422408189718 [[],[]] .chain = true := by decide
def e2422408189722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422408189722 : Closed e2422408189722 ∧ code e2422408189722 = 11218501211930 := by decide
theorem cert_e2422408189722 : check e2422408189722 [[],[]] .chain = true := by decide
def e2422408189766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422408189766 : Closed e2422408189766 ∧ code e2422408189766 = 11218501211974 := by decide
theorem cert_e2422408189766 : check e2422408189766 [[],[]] .chain = true := by decide
def e2422408189794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422408189794 : Closed e2422408189794 ∧ code e2422408189794 = 11218501212002 := by decide
theorem cert_e2422408189794 : check e2422408189794 [[],[]] .chain = true := by decide
def e2422408189806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2422408189806 : Closed e2422408189806 ∧ code e2422408189806 = 11218501212014 := by decide
theorem cert_e2422408189806 : check e2422408189806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408189814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2422408189814 : Closed e2422408189814 ∧ code e2422408189814 = 11218501212022 := by decide
theorem cert_e2422408189814 : check e2422408189814 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408189878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2422408189878 : Closed e2422408189878 ∧ code e2422408189878 = 11218501212086 := by decide
theorem cert_e2422408189878 : check e2422408189878 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408190062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408190062 : Closed e2422408190062 ∧ code e2422408190062 = 11218501212270 := by decide
theorem cert_e2422408190062 : check e2422408190062 [[],[]] .chain = true := by decide
def e2422408190074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408190074 : Closed e2422408190074 ∧ code e2422408190074 = 11218501212282 := by decide
theorem cert_e2422408190074 : check e2422408190074 [[],[]] .chain = true := by decide
def e2422408190350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422408190350 : Closed e2422408190350 ∧ code e2422408190350 = 11218501212558 := by decide
theorem cert_e2422408190350 : check e2422408190350 [[],[]] .chain = true := by decide
def e2422408190406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422408190406 : Closed e2422408190406 ∧ code e2422408190406 = 11218501212614 := by decide
theorem cert_e2422408190406 : check e2422408190406 [[],[]] .chain = true := by decide
def e2422408191006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.lam (.var 3)))))))))
theorem wire_e2422408191006 : Closed e2422408191006 ∧ code e2422408191006 = 11218501213214 := by decide
theorem cert_e2422408191006 : check e2422408191006 [[],[]] .chain = true := by decide
def e2422408191030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422408191030 : Closed e2422408191030 ∧ code e2422408191030 = 11218501213238 := by decide
theorem cert_e2422408191030 : check e2422408191030 [[],[]] .chain = true := by decide
def e2422408191034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422408191034 : Closed e2422408191034 ∧ code e2422408191034 = 11218501213242 := by decide
theorem cert_e2422408191034 : check e2422408191034 [[],[]] .chain = true := by decide
def e2422408191174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422408191174 : Closed e2422408191174 ∧ code e2422408191174 = 11218501213382 := by decide
theorem cert_e2422408191174 : check e2422408191174 [[],[]] .chain = true := by decide
def e2422408191202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422408191202 : Closed e2422408191202 ∧ code e2422408191202 = 11218501213410 := by decide
theorem cert_e2422408191202 : check e2422408191202 [[],[]] .chain = true := by decide
def e2422408191214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408191214 : Closed e2422408191214 ∧ code e2422408191214 = 11218501213422 := by decide
theorem cert_e2422408191214 : check e2422408191214 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408191222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408191222 : Closed e2422408191222 ∧ code e2422408191222 = 11218501213430 := by decide
theorem cert_e2422408191222 : check e2422408191222 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408191606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2422408191606 : Closed e2422408191606 ∧ code e2422408191606 = 11218501213814 := by decide
theorem cert_e2422408191606 : check e2422408191606 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408270710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422408270710 : Closed e2422408270710 ∧ code e2422408270710 = 11218501292918 := by decide
theorem cert_e2422408270710 : check e2422408270710 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408270778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422408270778 : Closed e2422408270778 ∧ code e2422408270778 = 11218501292986 := by decide
theorem cert_e2422408270778 : check e2422408270778 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408270806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422408270806 : Closed e2422408270806 ∧ code e2422408270806 = 11218501293014 := by decide
theorem cert_e2422408270806 : check e2422408270806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408270810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422408270810 : Closed e2422408270810 ∧ code e2422408270810 = 11218501293018 := by decide
theorem cert_e2422408270810 : check e2422408270810 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408398190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422408398190 : Closed e2422408398190 ∧ code e2422408398190 = 11218501420398 := by decide
theorem cert_e2422408398190 : check e2422408398190 [[],[]] .chain = true := by decide
def e2422408398198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422408398198 : Closed e2422408398198 ∧ code e2422408398198 = 11218501420406 := by decide
theorem cert_e2422408398198 : check e2422408398198 [[],[]] .chain = true := by decide
def e2422408398254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422408398254 : Closed e2422408398254 ∧ code e2422408398254 = 11218501420462 := by decide
theorem cert_e2422408398254 : check e2422408398254 [[],[]] .chain = true := by decide
def e2422408398266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422408398266 : Closed e2422408398266 ∧ code e2422408398266 = 11218501420474 := by decide
theorem cert_e2422408398266 : check e2422408398266 [[],[]] .chain = true := by decide
def e2422408398294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422408398294 : Closed e2422408398294 ∧ code e2422408398294 = 11218501420502 := by decide
theorem cert_e2422408398294 : check e2422408398294 [[],[]] .chain = true := by decide
def e2422408398298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422408398298 : Closed e2422408398298 ∧ code e2422408398298 = 11218501420506 := by decide
theorem cert_e2422408398298 : check e2422408398298 [[],[]] .chain = true := by decide
def e2422408401262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2422408401262 : Closed e2422408401262 ∧ code e2422408401262 = 11218501423470 := by decide
theorem cert_e2422408401262 : check e2422408401262 [[],[]] .chain = true := by decide
def e2422408401270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2422408401270 : Closed e2422408401270 ∧ code e2422408401270 = 11218501423478 := by decide
theorem cert_e2422408401270 : check e2422408401270 [[],[]] .chain = true := by decide
def e2422408402478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422408402478 : Closed e2422408402478 ∧ code e2422408402478 = 11218501424686 := by decide
theorem cert_e2422408402478 : check e2422408402478 [[],[]] .chain = true := by decide
def e2422408402658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422408402658 : Closed e2422408402658 ∧ code e2422408402658 = 11218501424866 := by decide
theorem cert_e2422408402658 : check e2422408402658 [[],[]] .chain = true := by decide
def e2422408402670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e2422408402670 : Closed e2422408402670 ∧ code e2422408402670 = 11218501424878 := by decide
theorem cert_e2422408402670 : check e2422408402670 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408402710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422408402710 : Closed e2422408402710 ∧ code e2422408402710 = 11218501424918 := by decide
theorem cert_e2422408402710 : check e2422408402710 [[],[]] .chain = true := by decide
def e2422408402786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422408402786 : Closed e2422408402786 ∧ code e2422408402786 = 11218501424994 := by decide
theorem cert_e2422408402786 : check e2422408402786 [[],[]] .chain = true := by decide
def e2422408402798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e2422408402798 : Closed e2422408402798 ∧ code e2422408402798 = 11218501425006 := by decide
theorem cert_e2422408402798 : check e2422408402798 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408402806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e2422408402806 : Closed e2422408402806 ∧ code e2422408402806 = 11218501425014 := by decide
theorem cert_e2422408402806 : check e2422408402806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408403118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2422408403118 : Closed e2422408403118 ∧ code e2422408403118 = 11218501425326 := by decide
theorem cert_e2422408403118 : check e2422408403118 [[],[]] .chain = true := by decide
def e2422408403130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2422408403130 : Closed e2422408403130 ∧ code e2422408403130 = 11218501425338 := by decide
theorem cert_e2422408403130 : check e2422408403130 [[],[]] .chain = true := by decide
def e2422408403502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422408403502 : Closed e2422408403502 ∧ code e2422408403502 = 11218501425710 := by decide
theorem cert_e2422408403502 : check e2422408403502 [[],[]] .chain = true := by decide
def e2422408403682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422408403682 : Closed e2422408403682 ∧ code e2422408403682 = 11218501425890 := by decide
theorem cert_e2422408403682 : check e2422408403682 [[],[]] .chain = true := by decide
def e2422408403694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2422408403694 : Closed e2422408403694 ∧ code e2422408403694 = 11218501425902 := by decide
theorem cert_e2422408403694 : check e2422408403694 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408403822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2422408403822 : Closed e2422408403822 ∧ code e2422408403822 = 11218501426030 := by decide
theorem cert_e2422408403822 : check e2422408403822 [[],[]] .chain = true := by decide
def e2422408403830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2422408403830 : Closed e2422408403830 ∧ code e2422408403830 = 11218501426038 := by decide
theorem cert_e2422408403830 : check e2422408403830 [[],[]] .chain = true := by decide
def e2422408403850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408403850 : Closed e2422408403850 ∧ code e2422408403850 = 11218501426058 := by decide
theorem cert_e2422408403850 : check e2422408403850 [[],[]] .chain = true := by decide
def e2422408403874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408403874 : Closed e2422408403874 ∧ code e2422408403874 = 11218501426082 := by decide
theorem cert_e2422408403874 : check e2422408403874 [[],[]] .chain = true := by decide
def e2422408403886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2422408403886 : Closed e2422408403886 ∧ code e2422408403886 = 11218501426094 := by decide
theorem cert_e2422408403886 : check e2422408403886 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408403894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2422408403894 : Closed e2422408403894 ∧ code e2422408403894 = 11218501426102 := by decide
theorem cert_e2422408403894 : check e2422408403894 [[],[]] .chain = true := by decide
def e2422408403898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2422408403898 : Closed e2422408403898 ∧ code e2422408403898 = 11218501426106 := by decide
theorem cert_e2422408403898 : check e2422408403898 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408404054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2422408404054 : Closed e2422408404054 ∧ code e2422408404054 = 11218501426262 := by decide
theorem cert_e2422408404054 : check e2422408404054 [[],[]] .chain = true := by decide
def e2422408404058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2422408404058 : Closed e2422408404058 ∧ code e2422408404058 = 11218501426266 := by decide
theorem cert_e2422408404058 : check e2422408404058 [[],[]] .chain = true := by decide
def e2422408404246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422408404246 : Closed e2422408404246 ∧ code e2422408404246 = 11218501426454 := by decide
theorem cert_e2422408404246 : check e2422408404246 [[],[]] .chain = true := by decide
def e2422408404322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422408404322 : Closed e2422408404322 ∧ code e2422408404322 = 11218501426530 := by decide
theorem cert_e2422408404322 : check e2422408404322 [[],[]] .chain = true := by decide
def e2422408404334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422408404334 : Closed e2422408404334 ∧ code e2422408404334 = 11218501426542 := by decide
theorem cert_e2422408404334 : check e2422408404334 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408404342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422408404342 : Closed e2422408404342 ∧ code e2422408404342 = 11218501426550 := by decide
theorem cert_e2422408404342 : check e2422408404342 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408404362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408404362 : Closed e2422408404362 ∧ code e2422408404362 = 11218501426570 := by decide
theorem cert_e2422408404362 : check e2422408404362 [[],[]] .chain = true := by decide
def e2422408404386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408404386 : Closed e2422408404386 ∧ code e2422408404386 = 11218501426594 := by decide
theorem cert_e2422408404386 : check e2422408404386 [[],[]] .chain = true := by decide
def e2422408404398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422408404398 : Closed e2422408404398 ∧ code e2422408404398 = 11218501426606 := by decide
theorem cert_e2422408404398 : check e2422408404398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408404406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2422408404406 : Closed e2422408404406 ∧ code e2422408404406 = 11218501426614 := by decide
theorem cert_e2422408404406 : check e2422408404406 [[],[]] .chain = true := by decide
def e2422408404410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422408404410 : Closed e2422408404410 ∧ code e2422408404410 = 11218501426618 := by decide
theorem cert_e2422408404410 : check e2422408404410 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408404438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422408404438 : Closed e2422408404438 ∧ code e2422408404438 = 11218501426646 := by decide
def e2422408404442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422408404442 : Closed e2422408404442 ∧ code e2422408404442 = 11218501426650 := by decide
theorem cert_e2422408404442 : check e2422408404442 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408405678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422408405678 : Closed e2422408405678 ∧ code e2422408405678 = 11218501427886 := by decide
theorem cert_e2422408405678 : check e2422408405678 [[],[]] .chain = true := by decide
def e2422408405690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422408405690 : Closed e2422408405690 ∧ code e2422408405690 = 11218501427898 := by decide
theorem cert_e2422408405690 : check e2422408405690 [[],[]] .chain = true := by decide
def e2422408405738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422408405738 : Closed e2422408405738 ∧ code e2422408405738 = 11218501427946 := by decide
theorem cert_e2422408405738 : check e2422408405738 [[],[]] .chain = true := by decide
def e2422408407214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2422408407214 : Closed e2422408407214 ∧ code e2422408407214 = 11218501429422 := by decide
theorem cert_e2422408407214 : check e2422408407214 [[],[]] .chain = true := by decide
def e2422408407226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2422408407226 : Closed e2422408407226 ∧ code e2422408407226 = 11218501429434 := by decide
theorem cert_e2422408407226 : check e2422408407226 [[],[]] .chain = true := by decide
def e2422408407598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422408407598 : Closed e2422408407598 ∧ code e2422408407598 = 11218501429806 := by decide
theorem cert_e2422408407598 : check e2422408407598 [[],[]] .chain = true := by decide
def e2422408407778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422408407778 : Closed e2422408407778 ∧ code e2422408407778 = 11218501429986 := by decide
theorem cert_e2422408407778 : check e2422408407778 [[],[]] .chain = true := by decide
def e2422408407790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2422408407790 : Closed e2422408407790 ∧ code e2422408407790 = 11218501429998 := by decide
theorem cert_e2422408407790 : check e2422408407790 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408407918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2422408407918 : Closed e2422408407918 ∧ code e2422408407918 = 11218501430126 := by decide
theorem cert_e2422408407918 : check e2422408407918 [[],[]] .chain = true := by decide
def e2422408407926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2422408407926 : Closed e2422408407926 ∧ code e2422408407926 = 11218501430134 := by decide
theorem cert_e2422408407926 : check e2422408407926 [[],[]] .chain = true := by decide
def e2422408407946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408407946 : Closed e2422408407946 ∧ code e2422408407946 = 11218501430154 := by decide
theorem cert_e2422408407946 : check e2422408407946 [[],[]] .chain = true := by decide
def e2422408407970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408407970 : Closed e2422408407970 ∧ code e2422408407970 = 11218501430178 := by decide
theorem cert_e2422408407970 : check e2422408407970 [[],[]] .chain = true := by decide
def e2422408407982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2422408407982 : Closed e2422408407982 ∧ code e2422408407982 = 11218501430190 := by decide
theorem cert_e2422408407982 : check e2422408407982 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408407990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2422408407990 : Closed e2422408407990 ∧ code e2422408407990 = 11218501430198 := by decide
theorem cert_e2422408407990 : check e2422408407990 [[],[]] .chain = true := by decide
def e2422408407994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2422408407994 : Closed e2422408407994 ∧ code e2422408407994 = 11218501430202 := by decide
theorem cert_e2422408407994 : check e2422408407994 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408408430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422408408430 : Closed e2422408408430 ∧ code e2422408408430 = 11218501430638 := by decide
theorem cert_e2422408408430 : check e2422408408430 [[],[]] .chain = true := by decide
def e2422408408438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422408408438 : Closed e2422408408438 ∧ code e2422408408438 = 11218501430646 := by decide
theorem cert_e2422408408438 : check e2422408408438 [[],[]] .chain = true := by decide
end Blc.Floor43
