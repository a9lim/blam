import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605603733358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e605603733358 : Closed e605603733358 ∧ code e605603733358 = 9401696755566 := by decide
theorem cert_e605603733358 : check e605603733358 [[.under],[.under]] .three = true := by decide
def e605603733366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e605603733366 : Closed e605603733366 ∧ code e605603733366 = 9401696755574 := by decide
theorem cert_e605603733366 : check e605603733366 [[.under],[.under]] .three = true := by decide
def e605603738590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605603738590 : Closed e605603738590 ∧ code e605603738590 = 9401696760798 := by decide
theorem cert_e605603738590 : check e605603738590 [[.under],[.under]] .three = true := by decide
def e605603738606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605603738606 : Closed e605603738606 ∧ code e605603738606 = 9401696760814 := by decide
theorem cert_e605603738606 : check e605603738606 [[.under],[.under]] .three = true := by decide
def e605603740126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605603740126 : Closed e605603740126 ∧ code e605603740126 = 9401696762334 := by decide
theorem cert_e605603740126 : check e605603740126 [[.under],[.under]] .three = true := by decide
def e605603740150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605603740150 : Closed e605603740150 ∧ code e605603740150 = 9401696762358 := by decide
theorem cert_e605603740150 : check e605603740150 [[.under],[.under]] .three = true := by decide
def e605603740910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605603740910 : Closed e605603740910 ∧ code e605603740910 = 9401696763118 := by decide
theorem cert_e605603740910 : check e605603740910 [[.under],[.under]] .three = true := by decide
def e605603740918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605603740918 : Closed e605603740918 ∧ code e605603740918 = 9401696763126 := by decide
theorem cert_e605603740918 : check e605603740918 [[.under],[.under]] .three = true := by decide
def e605603745502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e605603745502 : Closed e605603745502 ∧ code e605603745502 = 9401696767710 := by decide
theorem cert_e605603745502 : check e605603745502 [[.under],[.under]] .three = true := by decide
def e605603745526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e605603745526 : Closed e605603745526 ∧ code e605603745526 = 9401696767734 := by decide
theorem cert_e605603745526 : check e605603745526 [[.under],[.under]] .three = true := by decide
def e605603745718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e605603745718 : Closed e605603745718 ∧ code e605603745718 = 9401696767926 := by decide
theorem cert_e605603745718 : check e605603745718 [[.under],[.under]] .three = true := by decide
def e605603748318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605603748318 : Closed e605603748318 ∧ code e605603748318 = 9401696770526 := by decide
theorem cert_e605603748318 : check e605603748318 [[.under],[.under]] .three = true := by decide
def e605603748342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605603748342 : Closed e605603748342 ∧ code e605603748342 = 9401696770550 := by decide
theorem cert_e605603748342 : check e605603748342 [[.under],[.under]] .three = true := by decide
def e605603749494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605603749494 : Closed e605603749494 ∧ code e605603749494 = 9401696771702 := by decide
theorem cert_e605603749494 : check e605603749494 [[.under],[.under]] .three = true := by decide
def e605603751790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e605603751790 : Closed e605603751790 ∧ code e605603751790 = 9401696773998 := by decide
theorem cert_e605603751790 : check e605603751790 [[.under],[.under]] .three = true := by decide
def e605603751798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e605603751798 : Closed e605603751798 ∧ code e605603751798 = 9401696774006 := by decide
theorem cert_e605603751798 : check e605603751798 [[.under],[.under]] .three = true := by decide
def e605603751862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e605603751862 : Closed e605603751862 ∧ code e605603751862 = 9401696774070 := by decide
theorem cert_e605603751862 : check e605603751862 [[.under],[.under]] .three = true := by decide
def e605603753198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605603753198 : Closed e605603753198 ∧ code e605603753198 = 9401696775406 := by decide
theorem cert_e605603753198 : check e605603753198 [[.under],[.under]] .three = true := by decide
def e605603753206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605603753206 : Closed e605603753206 ∧ code e605603753206 = 9401696775414 := by decide
theorem cert_e605603753206 : check e605603753206 [[.under],[.under]] .three = true := by decide
def e605603753590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e605603753590 : Closed e605603753590 ∧ code e605603753590 = 9401696775798 := by decide
theorem cert_e605603753590 : check e605603753590 [[.under],[.under]] .three = true := by decide
def e605603913182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e605603913182 : Closed e605603913182 ∧ code e605603913182 = 9401696935390 := by decide
theorem cert_e605603913182 : check e605603913182 [[.under],[.under]] .three = true := by decide
def e605603913198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e605603913198 : Closed e605603913198 ∧ code e605603913198 = 9401696935406 := by decide
theorem cert_e605603913198 : check e605603913198 [[.under],[.under]] .three = true := by decide
def e605603913438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e605603913438 : Closed e605603913438 ∧ code e605603913438 = 9401696935646 := by decide
theorem cert_e605603913438 : check e605603913438 [[.under],[.under]] .three = true := by decide
def e605603913462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e605603913462 : Closed e605603913462 ∧ code e605603913462 = 9401696935670 := by decide
theorem cert_e605603913462 : check e605603913462 [[.under],[.under]] .three = true := by decide
def e605603913582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e605603913582 : Closed e605603913582 ∧ code e605603913582 = 9401696935790 := by decide
theorem cert_e605603913582 : check e605603913582 [[.under],[.under]] .three = true := by decide
def e605603913590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e605603913590 : Closed e605603913590 ∧ code e605603913590 = 9401696935798 := by decide
theorem cert_e605603913590 : check e605603913590 [[.under],[.under]] .three = true := by decide
def e605603918814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e605603918814 : Closed e605603918814 ∧ code e605603918814 = 9401696941022 := by decide
theorem cert_e605603918814 : check e605603918814 [[.under],[.under]] .three = true := by decide
def e605603918830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e605603918830 : Closed e605603918830 ∧ code e605603918830 = 9401696941038 := by decide
theorem cert_e605603918830 : check e605603918830 [[.under],[.under]] .three = true := by decide
def e605603920350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e605603920350 : Closed e605603920350 ∧ code e605603920350 = 9401696942558 := by decide
theorem cert_e605603920350 : check e605603920350 [[.under],[.under]] .three = true := by decide
def e605603920374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e605603920374 : Closed e605603920374 ∧ code e605603920374 = 9401696942582 := by decide
theorem cert_e605603920374 : check e605603920374 [[.under],[.under]] .three = true := by decide
def e605603921134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e605603921134 : Closed e605603921134 ∧ code e605603921134 = 9401696943342 := by decide
theorem cert_e605603921134 : check e605603921134 [[.under],[.under]] .three = true := by decide
def e605603921142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e605603921142 : Closed e605603921142 ∧ code e605603921142 = 9401696943350 := by decide
theorem cert_e605603921142 : check e605603921142 [[.under],[.under]] .three = true := by decide
def e605603966686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e605603966686 : Closed e605603966686 ∧ code e605603966686 = 9401696988894 := by decide
theorem cert_e605603966686 : check e605603966686 [[.under],[.under]] .three = true := by decide
def e605603966710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e605603966710 : Closed e605603966710 ∧ code e605603966710 = 9401696988918 := by decide
theorem cert_e605603966710 : check e605603966710 [[.under],[.under]] .three = true := by decide
def e605603966902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e605603966902 : Closed e605603966902 ∧ code e605603966902 = 9401696989110 := by decide
theorem cert_e605603966902 : check e605603966902 [[.under],[.under]] .three = true := by decide
def e605603969502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e605603969502 : Closed e605603969502 ∧ code e605603969502 = 9401696991710 := by decide
theorem cert_e605603969502 : check e605603969502 [[.under],[.under]] .three = true := by decide
def e605603969526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e605603969526 : Closed e605603969526 ∧ code e605603969526 = 9401696991734 := by decide
theorem cert_e605603969526 : check e605603969526 [[.under],[.under]] .three = true := by decide
def e605603970678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e605603970678 : Closed e605603970678 ∧ code e605603970678 = 9401696992886 := by decide
theorem cert_e605603970678 : check e605603970678 [[.under],[.under]] .three = true := by decide
def e605603993454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e605603993454 : Closed e605603993454 ∧ code e605603993454 = 9401697015662 := by decide
theorem cert_e605603993454 : check e605603993454 [[.under],[.under]] .three = true := by decide
def e605603993462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e605603993462 : Closed e605603993462 ∧ code e605603993462 = 9401697015670 := by decide
theorem cert_e605603993462 : check e605603993462 [[.under],[.under]] .three = true := by decide
def e605603993526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e605603993526 : Closed e605603993526 ∧ code e605603993526 = 9401697015734 := by decide
theorem cert_e605603993526 : check e605603993526 [[.under],[.under]] .three = true := by decide
def e605603994862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e605603994862 : Closed e605603994862 ∧ code e605603994862 = 9401697017070 := by decide
theorem cert_e605603994862 : check e605603994862 [[.under],[.under]] .three = true := by decide
def e605603994870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e605603994870 : Closed e605603994870 ∧ code e605603994870 = 9401697017078 := by decide
theorem cert_e605603994870 : check e605603994870 [[.under],[.under]] .three = true := by decide
def e605603995254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e605603995254 : Closed e605603995254 ∧ code e605603995254 = 9401697017462 := by decide
theorem cert_e605603995254 : check e605603995254 [[.under],[.under]] .three = true := by decide
def e605605424606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e605605424606 : Closed e605605424606 ∧ code e605605424606 = 9401698446814 := by decide
theorem cert_e605605424606 : check e605605424606 [[.under],[.under]] .three = true := by decide
def e605605424622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e605605424622 : Closed e605605424622 ∧ code e605605424622 = 9401698446830 := by decide
theorem cert_e605605424622 : check e605605424622 [[.under],[.under]] .three = true := by decide
def e605605424862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e605605424862 : Closed e605605424862 ∧ code e605605424862 = 9401698447070 := by decide
theorem cert_e605605424862 : check e605605424862 [[.under],[.under]] .three = true := by decide
def e605605424886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e605605424886 : Closed e605605424886 ∧ code e605605424886 = 9401698447094 := by decide
theorem cert_e605605424886 : check e605605424886 [[.under],[.under]] .three = true := by decide
def e605605425006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e605605425006 : Closed e605605425006 ∧ code e605605425006 = 9401698447214 := by decide
theorem cert_e605605425006 : check e605605425006 [[.under],[.under]] .three = true := by decide
def e605605425014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e605605425014 : Closed e605605425014 ∧ code e605605425014 = 9401698447222 := by decide
theorem cert_e605605425014 : check e605605425014 [[.under],[.under]] .three = true := by decide
def e605605426654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e605605426654 : Closed e605605426654 ∧ code e605605426654 = 9401698448862 := by decide
theorem cert_e605605426654 : check e605605426654 [[.under],[.under]] .three = true := by decide
def e605605426670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e605605426670 : Closed e605605426670 ∧ code e605605426670 = 9401698448878 := by decide
theorem cert_e605605426670 : check e605605426670 [[.under],[.under]] .three = true := by decide
def e605605427038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e605605427038 : Closed e605605427038 ∧ code e605605427038 = 9401698449246 := by decide
theorem cert_e605605427038 : check e605605427038 [[.under],[.under]] .three = true := by decide
def e605605427066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e605605427066 : Closed e605605427066 ∧ code e605605427066 = 9401698449274 := by decide
theorem cert_e605605427066 : check e605605427066 [[.under],[.under]] .three = true := by decide
def e605605427118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e605605427118 : Closed e605605427118 ∧ code e605605427118 = 9401698449326 := by decide
theorem cert_e605605427118 : check e605605427118 [[.under],[.under]] .three = true := by decide
def e605605427130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e605605427130 : Closed e605605427130 ∧ code e605605427130 = 9401698449338 := by decide
theorem cert_e605605427130 : check e605605427130 [[.under],[.under]] .three = true := by decide
def e605605427934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605605427934 : Closed e605605427934 ∧ code e605605427934 = 9401698450142 := by decide
theorem cert_e605605427934 : check e605605427934 [[.under],[.under]] .three = true := by decide
def e605605427958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605605427958 : Closed e605605427958 ∧ code e605605427958 = 9401698450166 := by decide
theorem cert_e605605427958 : check e605605427958 [[.under],[.under]] .three = true := by decide
def e605605428062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605605428062 : Closed e605605428062 ∧ code e605605428062 = 9401698450270 := by decide
theorem cert_e605605428062 : check e605605428062 [[.under],[.under]] .three = true := by decide
def e605605428090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605605428090 : Closed e605605428090 ∧ code e605605428090 = 9401698450298 := by decide
theorem cert_e605605428090 : check e605605428090 [[.under],[.under]] .three = true := by decide
def e605605428182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605605428182 : Closed e605605428182 ∧ code e605605428182 = 9401698450390 := by decide
theorem cert_e605605428182 : check e605605428182 [[.under],[.under]] .three = true := by decide
def e605605428186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605605428186 : Closed e605605428186 ∧ code e605605428186 = 9401698450394 := by decide
theorem cert_e605605428186 : check e605605428186 [[.under],[.under]] .three = true := by decide
def e605605428590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605605428590 : Closed e605605428590 ∧ code e605605428590 = 9401698450798 := by decide
theorem cert_e605605428590 : check e605605428590 [[.under],[.under]] .three = true := by decide
def e605605428598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605605428598 : Closed e605605428598 ∧ code e605605428598 = 9401698450806 := by decide
theorem cert_e605605428598 : check e605605428598 [[.under],[.under]] .three = true := by decide
def e605605428654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605605428654 : Closed e605605428654 ∧ code e605605428654 = 9401698450862 := by decide
theorem cert_e605605428654 : check e605605428654 [[.under],[.under]] .three = true := by decide
def e605605428666 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605605428666 : Closed e605605428666 ∧ code e605605428666 = 9401698450874 := by decide
theorem cert_e605605428666 : check e605605428666 [[.under],[.under]] .three = true := by decide
def e605605428694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605605428694 : Closed e605605428694 ∧ code e605605428694 = 9401698450902 := by decide
theorem cert_e605605428694 : check e605605428694 [[.under],[.under]] .three = true := by decide
def e605605428698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605605428698 : Closed e605605428698 ∧ code e605605428698 = 9401698450906 := by decide
theorem cert_e605605428698 : check e605605428698 [[.under],[.under]] .three = true := by decide
def e605605436894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e605605436894 : Closed e605605436894 ∧ code e605605436894 = 9401698459102 := by decide
theorem cert_e605605436894 : check e605605436894 [[.under],[.under]] .three = true := by decide
def e605605436910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e605605436910 : Closed e605605436910 ∧ code e605605436910 = 9401698459118 := by decide
theorem cert_e605605436910 : check e605605436910 [[.under],[.under]] .three = true := by decide
def e605605437150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e605605437150 : Closed e605605437150 ∧ code e605605437150 = 9401698459358 := by decide
theorem cert_e605605437150 : check e605605437150 [[.under],[.under]] .three = true := by decide
def e605605437174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e605605437174 : Closed e605605437174 ∧ code e605605437174 = 9401698459382 := by decide
theorem cert_e605605437174 : check e605605437174 [[.under],[.under]] .three = true := by decide
def e605605437294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e605605437294 : Closed e605605437294 ∧ code e605605437294 = 9401698459502 := by decide
theorem cert_e605605437294 : check e605605437294 [[.under],[.under]] .three = true := by decide
def e605605437302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e605605437302 : Closed e605605437302 ∧ code e605605437302 = 9401698459510 := by decide
theorem cert_e605605437302 : check e605605437302 [[.under],[.under]] .three = true := by decide
def e605605442526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605605442526 : Closed e605605442526 ∧ code e605605442526 = 9401698464734 := by decide
theorem cert_e605605442526 : check e605605442526 [[.under],[.under]] .three = true := by decide
def e605605442542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605605442542 : Closed e605605442542 ∧ code e605605442542 = 9401698464750 := by decide
theorem cert_e605605442542 : check e605605442542 [[.under],[.under]] .three = true := by decide
def e605605444062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605605444062 : Closed e605605444062 ∧ code e605605444062 = 9401698466270 := by decide
theorem cert_e605605444062 : check e605605444062 [[.under],[.under]] .three = true := by decide
def e605605444086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605605444086 : Closed e605605444086 ∧ code e605605444086 = 9401698466294 := by decide
theorem cert_e605605444086 : check e605605444086 [[.under],[.under]] .three = true := by decide
def e605605444846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605605444846 : Closed e605605444846 ∧ code e605605444846 = 9401698467054 := by decide
theorem cert_e605605444846 : check e605605444846 [[.under],[.under]] .three = true := by decide
def e605605444854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605605444854 : Closed e605605444854 ∧ code e605605444854 = 9401698467062 := by decide
theorem cert_e605605444854 : check e605605444854 [[.under],[.under]] .three = true := by decide
def e605605449182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e605605449182 : Closed e605605449182 ∧ code e605605449182 = 9401698471390 := by decide
theorem cert_e605605449182 : check e605605449182 [[.under],[.under]] .three = true := by decide
def e605605449198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e605605449198 : Closed e605605449198 ∧ code e605605449198 = 9401698471406 := by decide
theorem cert_e605605449198 : check e605605449198 [[.under],[.under]] .three = true := by decide
def e605605449566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e605605449566 : Closed e605605449566 ∧ code e605605449566 = 9401698471774 := by decide
theorem cert_e605605449566 : check e605605449566 [[.under],[.under]] .three = true := by decide
def e605605449594 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e605605449594 : Closed e605605449594 ∧ code e605605449594 = 9401698471802 := by decide
theorem cert_e605605449594 : check e605605449594 [[.under],[.under]] .three = true := by decide
def e605605449646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e605605449646 : Closed e605605449646 ∧ code e605605449646 = 9401698471854 := by decide
theorem cert_e605605449646 : check e605605449646 [[.under],[.under]] .three = true := by decide
def e605605449658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e605605449658 : Closed e605605449658 ∧ code e605605449658 = 9401698471866 := by decide
theorem cert_e605605449658 : check e605605449658 [[.under],[.under]] .three = true := by decide
def e605605450718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605605450718 : Closed e605605450718 ∧ code e605605450718 = 9401698472926 := by decide
theorem cert_e605605450718 : check e605605450718 [[.under],[.under]] .three = true := by decide
def e605605450734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605605450734 : Closed e605605450734 ∧ code e605605450734 = 9401698472942 := by decide
theorem cert_e605605450734 : check e605605450734 [[.under],[.under]] .three = true := by decide
def e605605453022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605605453022 : Closed e605605453022 ∧ code e605605453022 = 9401698475230 := by decide
theorem cert_e605605453022 : check e605605453022 [[.under],[.under]] .three = true := by decide
def e605605453050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605605453050 : Closed e605605453050 ∧ code e605605453050 = 9401698475258 := by decide
theorem cert_e605605453050 : check e605605453050 [[.under],[.under]] .three = true := by decide
def e605605453422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605605453422 : Closed e605605453422 ∧ code e605605453422 = 9401698475630 := by decide
theorem cert_e605605453422 : check e605605453422 [[.under],[.under]] .three = true := by decide
def e605605453434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605605453434 : Closed e605605453434 ∧ code e605605453434 = 9401698475642 := by decide
theorem cert_e605605453434 : check e605605453434 [[.under],[.under]] .three = true := by decide
def e605605455582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605605455582 : Closed e605605455582 ∧ code e605605455582 = 9401698477790 := by decide
theorem cert_e605605455582 : check e605605455582 [[.under],[.under]] .three = true := by decide
def e605605455606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605605455606 : Closed e605605455606 ∧ code e605605455606 = 9401698477814 := by decide
theorem cert_e605605455606 : check e605605455606 [[.under],[.under]] .three = true := by decide
def e605605455710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605605455710 : Closed e605605455710 ∧ code e605605455710 = 9401698477918 := by decide
theorem cert_e605605455710 : check e605605455710 [[.under],[.under]] .three = true := by decide
def e605605455738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605605455738 : Closed e605605455738 ∧ code e605605455738 = 9401698477946 := by decide
theorem cert_e605605455738 : check e605605455738 [[.under],[.under]] .three = true := by decide
def e605605455830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605605455830 : Closed e605605455830 ∧ code e605605455830 = 9401698478038 := by decide
theorem cert_e605605455830 : check e605605455830 [[.under],[.under]] .three = true := by decide
def e605605455834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605605455834 : Closed e605605455834 ∧ code e605605455834 = 9401698478042 := by decide
theorem cert_e605605455834 : check e605605455834 [[.under],[.under]] .three = true := by decide
def e605605456350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605605456350 : Closed e605605456350 ∧ code e605605456350 = 9401698478558 := by decide
theorem cert_e605605456350 : check e605605456350 [[.under],[.under]] .three = true := by decide
def e605605456374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605605456374 : Closed e605605456374 ∧ code e605605456374 = 9401698478582 := by decide
theorem cert_e605605456374 : check e605605456374 [[.under],[.under]] .three = true := by decide
def e605605457118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605605457118 : Closed e605605457118 ∧ code e605605457118 = 9401698479326 := by decide
theorem cert_e605605457118 : check e605605457118 [[.under],[.under]] .three = true := by decide
def e605605457146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605605457146 : Closed e605605457146 ∧ code e605605457146 = 9401698479354 := by decide
theorem cert_e605605457146 : check e605605457146 [[.under],[.under]] .three = true := by decide
def e605605457718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605605457718 : Closed e605605457718 ∧ code e605605457718 = 9401698479926 := by decide
theorem cert_e605605457718 : check e605605457718 [[.under],[.under]] .three = true := by decide
def e605605457722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605605457722 : Closed e605605457722 ∧ code e605605457722 = 9401698479930 := by decide
theorem cert_e605605457722 : check e605605457722 [[.under],[.under]] .three = true := by decide
def e605605458798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605605458798 : Closed e605605458798 ∧ code e605605458798 = 9401698481006 := by decide
theorem cert_e605605458798 : check e605605458798 [[.under],[.under]] .three = true := by decide
def e605605458806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605605458806 : Closed e605605458806 ∧ code e605605458806 = 9401698481014 := by decide
theorem cert_e605605458806 : check e605605458806 [[.under],[.under]] .three = true := by decide
def e605605458862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605605458862 : Closed e605605458862 ∧ code e605605458862 = 9401698481070 := by decide
theorem cert_e605605458862 : check e605605458862 [[.under],[.under]] .three = true := by decide
def e605605458874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605605458874 : Closed e605605458874 ∧ code e605605458874 = 9401698481082 := by decide
theorem cert_e605605458874 : check e605605458874 [[.under],[.under]] .three = true := by decide
def e605605458902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605605458902 : Closed e605605458902 ∧ code e605605458902 = 9401698481110 := by decide
theorem cert_e605605458902 : check e605605458902 [[.under],[.under]] .three = true := by decide
def e605605458906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605605458906 : Closed e605605458906 ∧ code e605605458906 = 9401698481114 := by decide
theorem cert_e605605458906 : check e605605458906 [[.under],[.under]] .three = true := by decide
def e605605459182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605605459182 : Closed e605605459182 ∧ code e605605459182 = 9401698481390 := by decide
theorem cert_e605605459182 : check e605605459182 [[.under],[.under]] .three = true := by decide
def e605605459190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605605459190 : Closed e605605459190 ∧ code e605605459190 = 9401698481398 := by decide
theorem cert_e605605459190 : check e605605459190 [[.under],[.under]] .three = true := by decide
def e605605459566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605605459566 : Closed e605605459566 ∧ code e605605459566 = 9401698481774 := by decide
theorem cert_e605605459566 : check e605605459566 [[.under],[.under]] .three = true := by decide
def e605605459578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605605459578 : Closed e605605459578 ∧ code e605605459578 = 9401698481786 := by decide
theorem cert_e605605459578 : check e605605459578 [[.under],[.under]] .three = true := by decide
def e605605459766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605605459766 : Closed e605605459766 ∧ code e605605459766 = 9401698481974 := by decide
theorem cert_e605605459766 : check e605605459766 [[.under],[.under]] .three = true := by decide
def e605605459770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605605459770 : Closed e605605459770 ∧ code e605605459770 = 9401698481978 := by decide
theorem cert_e605605459770 : check e605605459770 [[.under],[.under]] .three = true := by decide
def e605605486046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e605605486046 : Closed e605605486046 ∧ code e605605486046 = 9401698508254 := by decide
theorem cert_e605605486046 : check e605605486046 [[.under],[.under]] .three = true := by decide
def e605605486062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e605605486062 : Closed e605605486062 ∧ code e605605486062 = 9401698508270 := by decide
theorem cert_e605605486062 : check e605605486062 [[.under],[.under]] .three = true := by decide
def e605605486302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e605605486302 : Closed e605605486302 ∧ code e605605486302 = 9401698508510 := by decide
theorem cert_e605605486302 : check e605605486302 [[.under],[.under]] .three = true := by decide
def e605605486326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e605605486326 : Closed e605605486326 ∧ code e605605486326 = 9401698508534 := by decide
theorem cert_e605605486326 : check e605605486326 [[.under],[.under]] .three = true := by decide
def e605605486446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e605605486446 : Closed e605605486446 ∧ code e605605486446 = 9401698508654 := by decide
theorem cert_e605605486446 : check e605605486446 [[.under],[.under]] .three = true := by decide
def e605605486454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e605605486454 : Closed e605605486454 ∧ code e605605486454 = 9401698508662 := by decide
theorem cert_e605605486454 : check e605605486454 [[.under],[.under]] .three = true := by decide
def e605605491678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e605605491678 : Closed e605605491678 ∧ code e605605491678 = 9401698513886 := by decide
theorem cert_e605605491678 : check e605605491678 [[.under],[.under]] .three = true := by decide
def e605605491694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e605605491694 : Closed e605605491694 ∧ code e605605491694 = 9401698513902 := by decide
theorem cert_e605605491694 : check e605605491694 [[.under],[.under]] .three = true := by decide
def e605605493214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e605605493214 : Closed e605605493214 ∧ code e605605493214 = 9401698515422 := by decide
theorem cert_e605605493214 : check e605605493214 [[.under],[.under]] .three = true := by decide
def e605605493238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e605605493238 : Closed e605605493238 ∧ code e605605493238 = 9401698515446 := by decide
theorem cert_e605605493238 : check e605605493238 [[.under],[.under]] .three = true := by decide
def e605605493998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e605605493998 : Closed e605605493998 ∧ code e605605493998 = 9401698516206 := by decide
theorem cert_e605605493998 : check e605605493998 [[.under],[.under]] .three = true := by decide
def e605605494006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e605605494006 : Closed e605605494006 ∧ code e605605494006 = 9401698516214 := by decide
theorem cert_e605605494006 : check e605605494006 [[.under],[.under]] .three = true := by decide
def e605605539294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605605539294 : Closed e605605539294 ∧ code e605605539294 = 9401698561502 := by decide
theorem cert_e605605539294 : check e605605539294 [[.under],[.under]] .three = true := by decide
def e605605539310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605605539310 : Closed e605605539310 ∧ code e605605539310 = 9401698561518 := by decide
theorem cert_e605605539310 : check e605605539310 [[.under],[.under]] .three = true := by decide
def e605605539678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605605539678 : Closed e605605539678 ∧ code e605605539678 = 9401698561886 := by decide
theorem cert_e605605539678 : check e605605539678 [[.under],[.under]] .three = true := by decide
def e605605539706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605605539706 : Closed e605605539706 ∧ code e605605539706 = 9401698561914 := by decide
theorem cert_e605605539706 : check e605605539706 [[.under],[.under]] .three = true := by decide
def e605605539758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605605539758 : Closed e605605539758 ∧ code e605605539758 = 9401698561966 := by decide
theorem cert_e605605539758 : check e605605539758 [[.under],[.under]] .three = true := by decide
def e605605539770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605605539770 : Closed e605605539770 ∧ code e605605539770 = 9401698561978 := by decide
theorem cert_e605605539770 : check e605605539770 [[.under],[.under]] .three = true := by decide
def e605605540830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605605540830 : Closed e605605540830 ∧ code e605605540830 = 9401698563038 := by decide
theorem cert_e605605540830 : check e605605540830 [[.under],[.under]] .three = true := by decide
def e605605540846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605605540846 : Closed e605605540846 ∧ code e605605540846 = 9401698563054 := by decide
theorem cert_e605605540846 : check e605605540846 [[.under],[.under]] .three = true := by decide
def e605605543134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605605543134 : Closed e605605543134 ∧ code e605605543134 = 9401698565342 := by decide
theorem cert_e605605543134 : check e605605543134 [[.under],[.under]] .three = true := by decide
def e605605543162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605605543162 : Closed e605605543162 ∧ code e605605543162 = 9401698565370 := by decide
theorem cert_e605605543162 : check e605605543162 [[.under],[.under]] .three = true := by decide
def e605605543534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605605543534 : Closed e605605543534 ∧ code e605605543534 = 9401698565742 := by decide
theorem cert_e605605543534 : check e605605543534 [[.under],[.under]] .three = true := by decide
def e605605543546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605605543546 : Closed e605605543546 ∧ code e605605543546 = 9401698565754 := by decide
theorem cert_e605605543546 : check e605605543546 [[.under],[.under]] .three = true := by decide
def e605605566174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605605566174 : Closed e605605566174 ∧ code e605605566174 = 9401698588382 := by decide
theorem cert_e605605566174 : check e605605566174 [[.under],[.under]] .three = true := by decide
def e605605566198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605605566198 : Closed e605605566198 ∧ code e605605566198 = 9401698588406 := by decide
theorem cert_e605605566198 : check e605605566198 [[.under],[.under]] .three = true := by decide
def e605605566302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605605566302 : Closed e605605566302 ∧ code e605605566302 = 9401698588510 := by decide
theorem cert_e605605566302 : check e605605566302 [[.under],[.under]] .three = true := by decide
def e605605566330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605605566330 : Closed e605605566330 ∧ code e605605566330 = 9401698588538 := by decide
theorem cert_e605605566330 : check e605605566330 [[.under],[.under]] .three = true := by decide
def e605605566422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605605566422 : Closed e605605566422 ∧ code e605605566422 = 9401698588630 := by decide
theorem cert_e605605566422 : check e605605566422 [[.under],[.under]] .three = true := by decide
def e605605566426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605605566426 : Closed e605605566426 ∧ code e605605566426 = 9401698588634 := by decide
theorem cert_e605605566426 : check e605605566426 [[.under],[.under]] .three = true := by decide
def e605605566942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605605566942 : Closed e605605566942 ∧ code e605605566942 = 9401698589150 := by decide
theorem cert_e605605566942 : check e605605566942 [[.under],[.under]] .three = true := by decide
def e605605566966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605605566966 : Closed e605605566966 ∧ code e605605566966 = 9401698589174 := by decide
theorem cert_e605605566966 : check e605605566966 [[.under],[.under]] .three = true := by decide
def e605605567710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605605567710 : Closed e605605567710 ∧ code e605605567710 = 9401698589918 := by decide
theorem cert_e605605567710 : check e605605567710 [[.under],[.under]] .three = true := by decide
def e605605567738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605605567738 : Closed e605605567738 ∧ code e605605567738 = 9401698589946 := by decide
theorem cert_e605605567738 : check e605605567738 [[.under],[.under]] .three = true := by decide
def e605605568310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605605568310 : Closed e605605568310 ∧ code e605605568310 = 9401698590518 := by decide
theorem cert_e605605568310 : check e605605568310 [[.under],[.under]] .three = true := by decide
def e605605568314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605605568314 : Closed e605605568314 ∧ code e605605568314 = 9401698590522 := by decide
theorem cert_e605605568314 : check e605605568314 [[.under],[.under]] .three = true := by decide
def e605605579630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605605579630 : Closed e605605579630 ∧ code e605605579630 = 9401698601838 := by decide
theorem cert_e605605579630 : check e605605579630 [[.under],[.under]] .three = true := by decide
def e605605579638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605605579638 : Closed e605605579638 ∧ code e605605579638 = 9401698601846 := by decide
theorem cert_e605605579638 : check e605605579638 [[.under],[.under]] .three = true := by decide
def e605605579694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605605579694 : Closed e605605579694 ∧ code e605605579694 = 9401698601902 := by decide
theorem cert_e605605579694 : check e605605579694 [[.under],[.under]] .three = true := by decide
def e605605579706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605605579706 : Closed e605605579706 ∧ code e605605579706 = 9401698601914 := by decide
theorem cert_e605605579706 : check e605605579706 [[.under],[.under]] .three = true := by decide
def e605605579734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605605579734 : Closed e605605579734 ∧ code e605605579734 = 9401698601942 := by decide
theorem cert_e605605579734 : check e605605579734 [[.under],[.under]] .three = true := by decide
def e605605579738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605605579738 : Closed e605605579738 ∧ code e605605579738 = 9401698601946 := by decide
theorem cert_e605605579738 : check e605605579738 [[.under],[.under]] .three = true := by decide
def e605605580014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605605580014 : Closed e605605580014 ∧ code e605605580014 = 9401698602222 := by decide
theorem cert_e605605580014 : check e605605580014 [[.under],[.under]] .three = true := by decide
def e605605580022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605605580022 : Closed e605605580022 ∧ code e605605580022 = 9401698602230 := by decide
theorem cert_e605605580022 : check e605605580022 [[.under],[.under]] .three = true := by decide
end Blc.Floor43
