import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373887674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e2422373887674 : Closed e2422373887674 ∧ code e2422373887674 = 11218466909882 := by decide
theorem cert_e2422373887674 : check e2422373887674 [[],[]] .smaller = true := by decide
def e2422373887702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373887702 : Closed e2422373887702 ∧ code e2422373887702 = 11218466909910 := by decide
theorem cert_e2422373887702 : check e2422373887702 [[],[]] .smaller = true := by decide
def e2422373887722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373887722 : Closed e2422373887722 ∧ code e2422373887722 = 11218466909930 := by decide
theorem cert_e2422373887722 : check e2422373887722 [[],[]] .smaller = true := by decide
def e2422373887834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373887834 : Closed e2422373887834 ∧ code e2422373887834 = 11218466910042 := by decide
theorem cert_e2422373887834 : check e2422373887834 [[],[]] .smaller = true := by decide
def e2422373887850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373887850 : Closed e2422373887850 ∧ code e2422373887850 = 11218466910058 := by decide
theorem cert_e2422373887850 : check e2422373887850 [[],[]] .smaller = true := by decide
def e2422373888950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.var 1)))))))
theorem wire_e2422373888950 : Closed e2422373888950 ∧ code e2422373888950 = 11218466911158 := by decide
theorem cert_e2422373888950 : check e2422373888950 [[],[]] .smaller = true := by decide
def e2422373888954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))))
theorem wire_e2422373888954 : Closed e2422373888954 ∧ code e2422373888954 = 11218466911162 := by decide
theorem cert_e2422373888954 : check e2422373888954 [[],[]] .smaller = true := by decide
def e2422373888986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))))
theorem wire_e2422373888986 : Closed e2422373888986 ∧ code e2422373888986 = 11218466911194 := by decide
theorem cert_e2422373888986 : check e2422373888986 [[],[]] .smaller = true := by decide
def e2422373889246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373889246 : Closed e2422373889246 ∧ code e2422373889246 = 11218466911454 := by decide
theorem cert_e2422373889246 : check e2422373889246 [[],[]] .three = true := by decide
def e2422373889274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373889274 : Closed e2422373889274 ∧ code e2422373889274 = 11218466911482 := by decide
theorem cert_e2422373889274 : check e2422373889274 [[],[]] .three = true := by decide
def e2422373889654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373889654 : Closed e2422373889654 ∧ code e2422373889654 = 11218466911862 := by decide
theorem cert_e2422373889654 : check e2422373889654 [[],[]] .smaller = true := by decide
def e2422373889846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373889846 : Closed e2422373889846 ∧ code e2422373889846 = 11218466912054 := by decide
theorem cert_e2422373889846 : check e2422373889846 [[],[]] .smaller = true := by decide
def e2422373889850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373889850 : Closed e2422373889850 ∧ code e2422373889850 = 11218466912058 := by decide
theorem cert_e2422373889850 : check e2422373889850 [[],[]] .smaller = true := by decide
def e2422373890294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 1)))))))
theorem wire_e2422373890294 : Closed e2422373890294 ∧ code e2422373890294 = 11218466912502 := by decide
theorem cert_e2422373890294 : check e2422373890294 [[],[]] .smaller = true := by decide
def e2422373890486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e2422373890486 : Closed e2422373890486 ∧ code e2422373890486 = 11218466912694 := by decide
theorem cert_e2422373890486 : check e2422373890486 [[],[]] .smaller = true := by decide
def e2422373890490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422373890490 : Closed e2422373890490 ∧ code e2422373890490 = 11218466912698 := by decide
theorem cert_e2422373890490 : check e2422373890490 [[],[]] .smaller = true := by decide
def e2422373890518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e2422373890518 : Closed e2422373890518 ∧ code e2422373890518 = 11218466912726 := by decide
theorem cert_e2422373890518 : check e2422373890518 [[],[]] .smaller = true := by decide
def e2422373890538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422373890538 : Closed e2422373890538 ∧ code e2422373890538 = 11218466912746 := by decide
theorem cert_e2422373890538 : check e2422373890538 [[],[]] .smaller = true := by decide
def e2422373890678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373890678 : Closed e2422373890678 ∧ code e2422373890678 = 11218466912886 := by decide
theorem cert_e2422373890678 : check e2422373890678 [[],[]] .smaller = true := by decide
def e2422373890870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373890870 : Closed e2422373890870 ∧ code e2422373890870 = 11218466913078 := by decide
theorem cert_e2422373890870 : check e2422373890870 [[],[]] .smaller = true := by decide
def e2422373890874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373890874 : Closed e2422373890874 ∧ code e2422373890874 = 11218466913082 := by decide
theorem cert_e2422373890874 : check e2422373890874 [[],[]] .smaller = true := by decide
def e2422373890958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 2))))))))
theorem wire_e2422373890958 : Closed e2422373890958 ∧ code e2422373890958 = 11218466913166 := by decide
theorem cert_e2422373890958 : check e2422373890958 [[],[]] .smaller = true := by decide
def e2422373890970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373890970 : Closed e2422373890970 ∧ code e2422373890970 = 11218466913178 := by decide
theorem cert_e2422373890970 : check e2422373890970 [[],[]] .smaller = true := by decide
def e2422373891038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 3)))))))
theorem wire_e2422373891038 : Closed e2422373891038 ∧ code e2422373891038 = 11218466913246 := by decide
theorem cert_e2422373891038 : check e2422373891038 [[],[]] .three = true := by decide
def e2422373891054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 4)))) (.var 2)))))))
theorem wire_e2422373891054 : Closed e2422373891054 ∧ code e2422373891054 = 11218466913262 := by decide
theorem cert_e2422373891054 : check e2422373891054 [[],[]] .three = true := by decide
def e2422373891190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422373891190 : Closed e2422373891190 ∧ code e2422373891190 = 11218466913398 := by decide
theorem cert_e2422373891190 : check e2422373891190 [[],[]] .smaller = true := by decide
def e2422373891194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422373891194 : Closed e2422373891194 ∧ code e2422373891194 = 11218466913402 := by decide
theorem cert_e2422373891194 : check e2422373891194 [[],[]] .smaller = true := by decide
def e2422373891290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e2422373891290 : Closed e2422373891290 ∧ code e2422373891290 = 11218466913498 := by decide
theorem cert_e2422373891290 : check e2422373891290 [[],[]] .smaller = true := by decide
def e2422373891306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e2422373891306 : Closed e2422373891306 ∧ code e2422373891306 = 11218466913514 := by decide
theorem cert_e2422373891306 : check e2422373891306 [[],[]] .smaller = true := by decide
def e2422373891382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373891382 : Closed e2422373891382 ∧ code e2422373891382 = 11218466913590 := by decide
theorem cert_e2422373891382 : check e2422373891382 [[],[]] .smaller = true := by decide
def e2422373891386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373891386 : Closed e2422373891386 ∧ code e2422373891386 = 11218466913594 := by decide
theorem cert_e2422373891386 : check e2422373891386 [[],[]] .smaller = true := by decide
def e2422373891470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422373891470 : Closed e2422373891470 ∧ code e2422373891470 = 11218466913678 := by decide
theorem cert_e2422373891470 : check e2422373891470 [[],[]] .smaller = true := by decide
def e2422373891482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373891482 : Closed e2422373891482 ∧ code e2422373891482 = 11218466913690 := by decide
theorem cert_e2422373891482 : check e2422373891482 [[],[]] .smaller = true := by decide
def e2422373891526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422373891526 : Closed e2422373891526 ∧ code e2422373891526 = 11218466913734 := by decide
theorem cert_e2422373891526 : check e2422373891526 [[],[]] .smaller = true := by decide
def e2422373891550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 3)))))))
theorem wire_e2422373891550 : Closed e2422373891550 ∧ code e2422373891550 = 11218466913758 := by decide
theorem cert_e2422373891550 : check e2422373891550 [[],[]] .three = true := by decide
def e2422373891574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 4)))) (.var 1)))))))
theorem wire_e2422373891574 : Closed e2422373891574 ∧ code e2422373891574 = 11218466913782 := by decide
theorem cert_e2422373891574 : check e2422373891574 [[],[]] .three = true := by decide
def e2422373891806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 3)))))))
theorem wire_e2422373891806 : Closed e2422373891806 ∧ code e2422373891806 = 11218466914014 := by decide
theorem cert_e2422373891806 : check e2422373891806 [[],[]] .three = true := by decide
def e2422373891834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 4)))) (.var 0)))))))
theorem wire_e2422373891834 : Closed e2422373891834 ∧ code e2422373891834 = 11218466914042 := by decide
theorem cert_e2422373891834 : check e2422373891834 [[],[]] .three = true := by decide
def e2422373891950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 4) (.var 1)))) (.var 2)))))))
theorem wire_e2422373891950 : Closed e2422373891950 ∧ code e2422373891950 = 11218466914158 := by decide
theorem cert_e2422373891950 : check e2422373891950 [[],[]] .three = true := by decide
def e2422373891958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 4) (.var 2)))) (.var 1)))))))
theorem wire_e2422373891958 : Closed e2422373891958 ∧ code e2422373891958 = 11218466914166 := by decide
theorem cert_e2422373891958 : check e2422373891958 [[],[]] .three = true := by decide
def e2422373891962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 4) (.var 3)))) (.var 0)))))))
theorem wire_e2422373891962 : Closed e2422373891962 ∧ code e2422373891962 = 11218466914170 := by decide
theorem cert_e2422373891962 : check e2422373891962 [[],[]] .three = true := by decide
def e2422373895006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2422373895006 : Closed e2422373895006 ∧ code e2422373895006 = 11218466917214 := by decide
theorem cert_e2422373895006 : check e2422373895006 [[],[]] .three = true := by decide
def e2422373895022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422373895022 : Closed e2422373895022 ∧ code e2422373895022 = 11218466917230 := by decide
theorem cert_e2422373895022 : check e2422373895022 [[],[]] .smaller = true := by decide
def e2422373895030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422373895030 : Closed e2422373895030 ∧ code e2422373895030 = 11218466917238 := by decide
theorem cert_e2422373895030 : check e2422373895030 [[],[]] .smaller = true := by decide
def e2422373895034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2422373895034 : Closed e2422373895034 ∧ code e2422373895034 = 11218466917242 := by decide
theorem cert_e2422373895034 : check e2422373895034 [[],[]] .three = true := by decide
def e2422373895086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422373895086 : Closed e2422373895086 ∧ code e2422373895086 = 11218466917294 := by decide
theorem cert_e2422373895086 : check e2422373895086 [[],[]] .smaller = true := by decide
def e2422373895098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422373895098 : Closed e2422373895098 ∧ code e2422373895098 = 11218466917306 := by decide
theorem cert_e2422373895098 : check e2422373895098 [[],[]] .smaller = true := by decide
def e2422373895126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422373895126 : Closed e2422373895126 ∧ code e2422373895126 = 11218466917334 := by decide
theorem cert_e2422373895126 : check e2422373895126 [[],[]] .smaller = true := by decide
def e2422373895130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422373895130 : Closed e2422373895130 ∧ code e2422373895130 = 11218466917338 := by decide
theorem cert_e2422373895130 : check e2422373895130 [[],[]] .smaller = true := by decide
def e2422373895146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2422373895146 : Closed e2422373895146 ∧ code e2422373895146 = 11218466917354 := by decide
theorem cert_e2422373895146 : check e2422373895146 [[],[]] .three = true := by decide
def e2422373895390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373895390 : Closed e2422373895390 ∧ code e2422373895390 = 11218466917598 := by decide
theorem cert_e2422373895390 : check e2422373895390 [[],[]] .three = true := by decide
def e2422373895406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373895406 : Closed e2422373895406 ∧ code e2422373895406 = 11218466917614 := by decide
theorem cert_e2422373895406 : check e2422373895406 [[],[]] .smaller = true := by decide
def e2422373895414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373895414 : Closed e2422373895414 ∧ code e2422373895414 = 11218466917622 := by decide
theorem cert_e2422373895414 : check e2422373895414 [[],[]] .smaller = true := by decide
def e2422373895418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373895418 : Closed e2422373895418 ∧ code e2422373895418 = 11218466917626 := by decide
theorem cert_e2422373895418 : check e2422373895418 [[],[]] .three = true := by decide
def e2422373895790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373895790 : Closed e2422373895790 ∧ code e2422373895790 = 11218466917998 := by decide
theorem cert_e2422373895790 : check e2422373895790 [[],[]] .smaller = true := by decide
def e2422373895802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373895802 : Closed e2422373895802 ∧ code e2422373895802 = 11218466918010 := by decide
theorem cert_e2422373895802 : check e2422373895802 [[],[]] .smaller = true := by decide
def e2422373895990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373895990 : Closed e2422373895990 ∧ code e2422373895990 = 11218466918198 := by decide
theorem cert_e2422373895990 : check e2422373895990 [[],[]] .smaller = true := by decide
def e2422373895994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373895994 : Closed e2422373895994 ∧ code e2422373895994 = 11218466918202 := by decide
theorem cert_e2422373895994 : check e2422373895994 [[],[]] .smaller = true := by decide
def e2422373896090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373896090 : Closed e2422373896090 ∧ code e2422373896090 = 11218466918298 := by decide
theorem cert_e2422373896090 : check e2422373896090 [[],[]] .three = true := by decide
def e2422373900782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373900782 : Closed e2422373900782 ∧ code e2422373900782 = 11218466922990 := by decide
theorem cert_e2422373900782 : check e2422373900782 [[],[]] .smaller = true := by decide
def e2422373901750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2422373901750 : Closed e2422373901750 ∧ code e2422373901750 = 11218466923958 := by decide
theorem cert_e2422373901750 : check e2422373901750 [[],[]] .smaller = true := by decide
def e2422373901782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2422373901782 : Closed e2422373901782 ∧ code e2422373901782 = 11218466923990 := by decide
theorem cert_e2422373901782 : check e2422373901782 [[],[]] .smaller = true := by decide
def e2422373901786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2422373901786 : Closed e2422373901786 ∧ code e2422373901786 = 11218466923994 := by decide
theorem cert_e2422373901786 : check e2422373901786 [[],[]] .smaller = true := by decide
def e2422373901886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422373901886 : Closed e2422373901886 ∧ code e2422373901886 = 11218466924094 := by decide
theorem cert_e2422373901886 : check e2422373901886 [[],[]] .three = true := by decide
def e2422373901942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373901942 : Closed e2422373901942 ∧ code e2422373901942 = 11218466924150 := by decide
theorem cert_e2422373901942 : check e2422373901942 [[],[]] .smaller = true := by decide
def e2422373902110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422373902110 : Closed e2422373902110 ∧ code e2422373902110 = 11218466924318 := by decide
theorem cert_e2422373902110 : check e2422373902110 [[],[]] .smaller = true := by decide
def e2422373902134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373902134 : Closed e2422373902134 ∧ code e2422373902134 = 11218466924342 := by decide
theorem cert_e2422373902134 : check e2422373902134 [[],[]] .smaller = true := by decide
def e2422373902138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373902138 : Closed e2422373902138 ∧ code e2422373902138 = 11218466924346 := by decide
theorem cert_e2422373902138 : check e2422373902138 [[],[]] .smaller = true := by decide
def e2422373902222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422373902222 : Closed e2422373902222 ∧ code e2422373902222 = 11218466924430 := by decide
theorem cert_e2422373902222 : check e2422373902222 [[],[]] .smaller = true := by decide
def e2422373902278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422373902278 : Closed e2422373902278 ∧ code e2422373902278 = 11218466924486 := by decide
theorem cert_e2422373902278 : check e2422373902278 [[],[]] .three = true := by decide
def e2422373902302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 3) (.var 3))))))))
theorem wire_e2422373902302 : Closed e2422373902302 ∧ code e2422373902302 = 11218466924510 := by decide
theorem cert_e2422373902302 : check e2422373902302 [[],[]] .three = true := by decide
def e2422373904622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373904622 : Closed e2422373904622 ∧ code e2422373904622 = 11218466926830 := by decide
theorem cert_e2422373904622 : check e2422373904622 [[],[]] .smaller = true := by decide
def e2422373904630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373904630 : Closed e2422373904630 ∧ code e2422373904630 = 11218466926838 := by decide
theorem cert_e2422373904630 : check e2422373904630 [[],[]] .smaller = true := by decide
def e2422373905110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422373905110 : Closed e2422373905110 ∧ code e2422373905110 = 11218466927318 := by decide
theorem cert_e2422373905110 : check e2422373905110 [[],[]] .smaller = true := by decide
def e2422373905114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422373905114 : Closed e2422373905114 ∧ code e2422373905114 = 11218466927322 := by decide
theorem cert_e2422373905114 : check e2422373905114 [[],[]] .smaller = true := by decide
def e2422373905130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422373905130 : Closed e2422373905130 ∧ code e2422373905130 = 11218466927338 := by decide
theorem cert_e2422373905130 : check e2422373905130 [[],[]] .smaller = true := by decide
def e2422373905182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422373905182 : Closed e2422373905182 ∧ code e2422373905182 = 11218466927390 := by decide
theorem cert_e2422373905182 : check e2422373905182 [[],[]] .smaller = true := by decide
def e2422373905206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373905206 : Closed e2422373905206 ∧ code e2422373905206 = 11218466927414 := by decide
theorem cert_e2422373905206 : check e2422373905206 [[],[]] .smaller = true := by decide
def e2422373905210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373905210 : Closed e2422373905210 ∧ code e2422373905210 = 11218466927418 := by decide
theorem cert_e2422373905210 : check e2422373905210 [[],[]] .smaller = true := by decide
def e2422373905306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373905306 : Closed e2422373905306 ∧ code e2422373905306 = 11218466927514 := by decide
theorem cert_e2422373905306 : check e2422373905306 [[],[]] .smaller = true := by decide
def e2422373905350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422373905350 : Closed e2422373905350 ∧ code e2422373905350 = 11218466927558 := by decide
theorem cert_e2422373905350 : check e2422373905350 [[],[]] .smaller = true := by decide
def e2422373905374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373905374 : Closed e2422373905374 ∧ code e2422373905374 = 11218466927582 := by decide
theorem cert_e2422373905374 : check e2422373905374 [[],[]] .three = true := by decide
def e2422373905390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373905390 : Closed e2422373905390 ∧ code e2422373905390 = 11218466927598 := by decide
theorem cert_e2422373905390 : check e2422373905390 [[],[]] .three = true := by decide
def e2422373906830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373906830 : Closed e2422373906830 ∧ code e2422373906830 = 11218466929038 := by decide
theorem cert_e2422373906830 : check e2422373906830 [[],[]] .smaller = true := by decide
def e2422373906886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373906886 : Closed e2422373906886 ∧ code e2422373906886 = 11218466929094 := by decide
theorem cert_e2422373906886 : check e2422373906886 [[],[]] .smaller = true := by decide
def e2422373906910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373906910 : Closed e2422373906910 ∧ code e2422373906910 = 11218466929118 := by decide
theorem cert_e2422373906910 : check e2422373906910 [[],[]] .three = true := by decide
def e2422373906934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373906934 : Closed e2422373906934 ∧ code e2422373906934 = 11218466929142 := by decide
theorem cert_e2422373906934 : check e2422373906934 [[],[]] .three = true := by decide
def e2422373907654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373907654 : Closed e2422373907654 ∧ code e2422373907654 = 11218466929862 := by decide
theorem cert_e2422373907654 : check e2422373907654 [[],[]] .three = true := by decide
def e2422373907678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373907678 : Closed e2422373907678 ∧ code e2422373907678 = 11218466929886 := by decide
theorem cert_e2422373907678 : check e2422373907678 [[],[]] .three = true := by decide
def e2422373907694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373907694 : Closed e2422373907694 ∧ code e2422373907694 = 11218466929902 := by decide
theorem cert_e2422373907694 : check e2422373907694 [[],[]] .three = true := by decide
def e2422373907702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373907702 : Closed e2422373907702 ∧ code e2422373907702 = 11218466929910 := by decide
theorem cert_e2422373907702 : check e2422373907702 [[],[]] .three = true := by decide
def e2422373907706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373907706 : Closed e2422373907706 ∧ code e2422373907706 = 11218466929914 := by decide
theorem cert_e2422373907706 : check e2422373907706 [[],[]] .three = true := by decide
def e2422373920086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2422373920086 : Closed e2422373920086 ∧ code e2422373920086 = 11218466942294 := by decide
theorem cert_e2422373920086 : check e2422373920086 [[],[]] .smaller = true := by decide
def e2422373920090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2422373920090 : Closed e2422373920090 ∧ code e2422373920090 = 11218466942298 := by decide
theorem cert_e2422373920090 : check e2422373920090 [[],[]] .smaller = true := by decide
def e2422373920106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2422373920106 : Closed e2422373920106 ∧ code e2422373920106 = 11218466942314 := by decide
theorem cert_e2422373920106 : check e2422373920106 [[],[]] .smaller = true := by decide
def e2422373920170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422373920170 : Closed e2422373920170 ∧ code e2422373920170 = 11218466942378 := by decide
theorem cert_e2422373920170 : check e2422373920170 [[],[]] .smaller = true := by decide
def e2422373920426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422373920426 : Closed e2422373920426 ∧ code e2422373920426 = 11218466942634 := by decide
theorem cert_e2422373920426 : check e2422373920426 [[],[]] .smaller = true := by decide
def e2422373920854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.var 1)))))))
theorem wire_e2422373920854 : Closed e2422373920854 ∧ code e2422373920854 = 11218466943062 := by decide
theorem cert_e2422373920854 : check e2422373920854 [[],[]] .smaller = true := by decide
def e2422373920858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))) (.var 0)))))))
theorem wire_e2422373920858 : Closed e2422373920858 ∧ code e2422373920858 = 11218466943066 := by decide
theorem cert_e2422373920858 : check e2422373920858 [[],[]] .smaller = true := by decide
def e2422373921118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 3)))))))
theorem wire_e2422373921118 : Closed e2422373921118 ∧ code e2422373921118 = 11218466943326 := by decide
theorem cert_e2422373921118 : check e2422373921118 [[],[]] .three = true := by decide
def e2422373921134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2)))))))
theorem wire_e2422373921134 : Closed e2422373921134 ∧ code e2422373921134 = 11218466943342 := by decide
theorem cert_e2422373921134 : check e2422373921134 [[],[]] .smaller = true := by decide
def e2422373921142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1)))))))
theorem wire_e2422373921142 : Closed e2422373921142 ∧ code e2422373921142 = 11218466943350 := by decide
theorem cert_e2422373921142 : check e2422373921142 [[],[]] .smaller = true := by decide
def e2422373921146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))) (.var 0)))))))
theorem wire_e2422373921146 : Closed e2422373921146 ∧ code e2422373921146 = 11218466943354 := by decide
theorem cert_e2422373921146 : check e2422373921146 [[],[]] .three = true := by decide
def e2422373921206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 1)))))))
theorem wire_e2422373921206 : Closed e2422373921206 ∧ code e2422373921206 = 11218466943414 := by decide
theorem cert_e2422373921206 : check e2422373921206 [[],[]] .smaller = true := by decide
def e2422373921238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 1)))))))
theorem wire_e2422373921238 : Closed e2422373921238 ∧ code e2422373921238 = 11218466943446 := by decide
theorem cert_e2422373921238 : check e2422373921238 [[],[]] .smaller = true := by decide
def e2422373921242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))) (.var 0)))))))
theorem wire_e2422373921242 : Closed e2422373921242 ∧ code e2422373921242 = 11218466943450 := by decide
theorem cert_e2422373921242 : check e2422373921242 [[],[]] .smaller = true := by decide
def e2422373921622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e2422373921622 : Closed e2422373921622 ∧ code e2422373921622 = 11218466943830 := by decide
theorem cert_e2422373921622 : check e2422373921622 [[],[]] .smaller = true := by decide
def e2422373921626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e2422373921626 : Closed e2422373921626 ∧ code e2422373921626 = 11218466943834 := by decide
theorem cert_e2422373921626 : check e2422373921626 [[],[]] .smaller = true := by decide
def e2422373921642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.var 0)))))))
theorem wire_e2422373921642 : Closed e2422373921642 ∧ code e2422373921642 = 11218466943850 := by decide
theorem cert_e2422373921642 : check e2422373921642 [[],[]] .smaller = true := by decide
def e2422373921706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e2422373921706 : Closed e2422373921706 ∧ code e2422373921706 = 11218466943914 := by decide
theorem cert_e2422373921706 : check e2422373921706 [[],[]] .smaller = true := by decide
def e2422373921814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373921814 : Closed e2422373921814 ∧ code e2422373921814 = 11218466944022 := by decide
theorem cert_e2422373921814 : check e2422373921814 [[],[]] .smaller = true := by decide
def e2422373921886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422373921886 : Closed e2422373921886 ∧ code e2422373921886 = 11218466944094 := by decide
theorem cert_e2422373921886 : check e2422373921886 [[],[]] .three = true := by decide
def e2422373921910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2422373921910 : Closed e2422373921910 ∧ code e2422373921910 = 11218466944118 := by decide
theorem cert_e2422373921910 : check e2422373921910 [[],[]] .smaller = true := by decide
def e2422373922006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2422373922006 : Closed e2422373922006 ∧ code e2422373922006 = 11218466944214 := by decide
theorem cert_e2422373922006 : check e2422373922006 [[],[]] .smaller = true := by decide
def e2422373922010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2422373922010 : Closed e2422373922010 ∧ code e2422373922010 = 11218466944218 := by decide
theorem cert_e2422373922010 : check e2422373922010 [[],[]] .smaller = true := by decide
def e2422373922026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2422373922026 : Closed e2422373922026 ∧ code e2422373922026 = 11218466944234 := by decide
theorem cert_e2422373922026 : check e2422373922026 [[],[]] .smaller = true := by decide
def e2422373922102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373922102 : Closed e2422373922102 ∧ code e2422373922102 = 11218466944310 := by decide
theorem cert_e2422373922102 : check e2422373922102 [[],[]] .smaller = true := by decide
def e2422373922106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373922106 : Closed e2422373922106 ∧ code e2422373922106 = 11218466944314 := by decide
theorem cert_e2422373922106 : check e2422373922106 [[],[]] .smaller = true := by decide
def e2422373922178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373922178 : Closed e2422373922178 ∧ code e2422373922178 = 11218466944386 := by decide
theorem cert_e2422373922178 : check e2422373922178 [[],[]] .smaller = true := by decide
def e2422373922190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2422373922190 : Closed e2422373922190 ∧ code e2422373922190 = 11218466944398 := by decide
theorem cert_e2422373922190 : check e2422373922190 [[],[]] .smaller = true := by decide
def e2422373922202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373922202 : Closed e2422373922202 ∧ code e2422373922202 = 11218466944410 := by decide
theorem cert_e2422373922202 : check e2422373922202 [[],[]] .smaller = true := by decide
def e2422373922270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 3)))))))
theorem wire_e2422373922270 : Closed e2422373922270 ∧ code e2422373922270 = 11218466944478 := by decide
theorem cert_e2422373922270 : check e2422373922270 [[],[]] .three = true := by decide
def e2422373922274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422373922274 : Closed e2422373922274 ∧ code e2422373922274 = 11218466944482 := by decide
theorem cert_e2422373922274 : check e2422373922274 [[],[]] .three = true := by decide
def e2422373922286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 2)))))))
theorem wire_e2422373922286 : Closed e2422373922286 ∧ code e2422373922286 = 11218466944494 := by decide
theorem cert_e2422373922286 : check e2422373922286 [[],[]] .three = true := by decide
def e2422373922314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373922314 : Closed e2422373922314 ∧ code e2422373922314 = 11218466944522 := by decide
theorem cert_e2422373922314 : check e2422373922314 [[],[]] .smaller = true := by decide
def e2422373922350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373922350 : Closed e2422373922350 ∧ code e2422373922350 = 11218466944558 := by decide
theorem cert_e2422373922350 : check e2422373922350 [[],[]] .smaller = true := by decide
def e2422373922358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373922358 : Closed e2422373922358 ∧ code e2422373922358 = 11218466944566 := by decide
theorem cert_e2422373922358 : check e2422373922358 [[],[]] .smaller = true := by decide
def e2422373922362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373922362 : Closed e2422373922362 ∧ code e2422373922362 = 11218466944570 := by decide
theorem cert_e2422373922362 : check e2422373922362 [[],[]] .smaller = true := by decide
def e2422373922410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373922410 : Closed e2422373922410 ∧ code e2422373922410 = 11218466944618 := by decide
theorem cert_e2422373922410 : check e2422373922410 [[],[]] .smaller = true := by decide
def e2422373922434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373922434 : Closed e2422373922434 ∧ code e2422373922434 = 11218466944642 := by decide
theorem cert_e2422373922434 : check e2422373922434 [[],[]] .smaller = true := by decide
def e2422373922446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373922446 : Closed e2422373922446 ∧ code e2422373922446 = 11218466944654 := by decide
theorem cert_e2422373922446 : check e2422373922446 [[],[]] .smaller = true := by decide
def e2422373922458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373922458 : Closed e2422373922458 ∧ code e2422373922458 = 11218466944666 := by decide
theorem cert_e2422373922458 : check e2422373922458 [[],[]] .smaller = true := by decide
def e2422373922502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373922502 : Closed e2422373922502 ∧ code e2422373922502 = 11218466944710 := by decide
theorem cert_e2422373922502 : check e2422373922502 [[],[]] .smaller = true := by decide
def e2422373922526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 3)))))))
theorem wire_e2422373922526 : Closed e2422373922526 ∧ code e2422373922526 = 11218466944734 := by decide
theorem cert_e2422373922526 : check e2422373922526 [[],[]] .three = true := by decide
def e2422373922530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373922530 : Closed e2422373922530 ∧ code e2422373922530 = 11218466944738 := by decide
theorem cert_e2422373922530 : check e2422373922530 [[],[]] .smaller = true := by decide
def e2422373922542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2)))))))
theorem wire_e2422373922542 : Closed e2422373922542 ∧ code e2422373922542 = 11218466944750 := by decide
theorem cert_e2422373922542 : check e2422373922542 [[],[]] .smaller = true := by decide
def e2422373922550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 1)))))))
theorem wire_e2422373922550 : Closed e2422373922550 ∧ code e2422373922550 = 11218466944758 := by decide
theorem cert_e2422373922550 : check e2422373922550 [[],[]] .three = true := by decide
def e2422373922582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373922582 : Closed e2422373922582 ∧ code e2422373922582 = 11218466944790 := by decide
theorem cert_e2422373922582 : check e2422373922582 [[],[]] .smaller = true := by decide
def e2422373922654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 3)))))))
theorem wire_e2422373922654 : Closed e2422373922654 ∧ code e2422373922654 = 11218466944862 := by decide
theorem cert_e2422373922654 : check e2422373922654 [[],[]] .three = true := by decide
def e2422373922658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373922658 : Closed e2422373922658 ∧ code e2422373922658 = 11218466944866 := by decide
theorem cert_e2422373922658 : check e2422373922658 [[],[]] .smaller = true := by decide
def e2422373922670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2)))))))
theorem wire_e2422373922670 : Closed e2422373922670 ∧ code e2422373922670 = 11218466944878 := by decide
theorem cert_e2422373922670 : check e2422373922670 [[],[]] .smaller = true := by decide
def e2422373922678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1)))))))
theorem wire_e2422373922678 : Closed e2422373922678 ∧ code e2422373922678 = 11218466944886 := by decide
theorem cert_e2422373922678 : check e2422373922678 [[],[]] .smaller = true := by decide
def e2422373922682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 0)))))))
theorem wire_e2422373922682 : Closed e2422373922682 ∧ code e2422373922682 = 11218466944890 := by decide
theorem cert_e2422373922682 : check e2422373922682 [[],[]] .three = true := by decide
def e2422373922698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373922698 : Closed e2422373922698 ∧ code e2422373922698 = 11218466944906 := by decide
theorem cert_e2422373922698 : check e2422373922698 [[],[]] .three = true := by decide
def e2422373922722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373922722 : Closed e2422373922722 ∧ code e2422373922722 = 11218466944930 := by decide
theorem cert_e2422373922722 : check e2422373922722 [[],[]] .three = true := by decide
def e2422373922734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 2)))))))
theorem wire_e2422373922734 : Closed e2422373922734 ∧ code e2422373922734 = 11218466944942 := by decide
theorem cert_e2422373922734 : check e2422373922734 [[],[]] .three = true := by decide
def e2422373922742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 1)))))))
theorem wire_e2422373922742 : Closed e2422373922742 ∧ code e2422373922742 = 11218466944950 := by decide
theorem cert_e2422373922742 : check e2422373922742 [[],[]] .three = true := by decide
def e2422373922746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 0)))))))
theorem wire_e2422373922746 : Closed e2422373922746 ∧ code e2422373922746 = 11218466944954 := by decide
theorem cert_e2422373922746 : check e2422373922746 [[],[]] .three = true := by decide
def e2422373922858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))) (.var 0)))))))
theorem wire_e2422373922858 : Closed e2422373922858 ∧ code e2422373922858 = 11218466945066 := by decide
theorem cert_e2422373922858 : check e2422373922858 [[],[]] .smaller = true := by decide
def e2422373922990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e2422373922990 : Closed e2422373922990 ∧ code e2422373922990 = 11218466945198 := by decide
theorem cert_e2422373922990 : check e2422373922990 [[],[]] .smaller = true := by decide
def e2422373923002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e2422373923002 : Closed e2422373923002 ∧ code e2422373923002 = 11218466945210 := by decide
theorem cert_e2422373923002 : check e2422373923002 [[],[]] .smaller = true := by decide
def e2422373923030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 1)))))))
theorem wire_e2422373923030 : Closed e2422373923030 ∧ code e2422373923030 = 11218466945238 := by decide
theorem cert_e2422373923030 : check e2422373923030 [[],[]] .smaller = true := by decide
def e2422373923034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))) (.var 0)))))))
theorem wire_e2422373923034 : Closed e2422373923034 ∧ code e2422373923034 = 11218466945242 := by decide
theorem cert_e2422373923034 : check e2422373923034 [[],[]] .smaller = true := by decide
def e2422373923050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))) (.var 0)))))))
theorem wire_e2422373923050 : Closed e2422373923050 ∧ code e2422373923050 = 11218466945258 := by decide
theorem cert_e2422373923050 : check e2422373923050 [[],[]] .smaller = true := by decide
def e2422373923242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e2422373923242 : Closed e2422373923242 ∧ code e2422373923242 = 11218466945450 := by decide
theorem cert_e2422373923242 : check e2422373923242 [[],[]] .smaller = true := by decide
def e2422373923338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373923338 : Closed e2422373923338 ∧ code e2422373923338 = 11218466945546 := by decide
theorem cert_e2422373923338 : check e2422373923338 [[],[]] .smaller = true := by decide
def e2422373923374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373923374 : Closed e2422373923374 ∧ code e2422373923374 = 11218466945582 := by decide
theorem cert_e2422373923374 : check e2422373923374 [[],[]] .smaller = true := by decide
def e2422373923382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373923382 : Closed e2422373923382 ∧ code e2422373923382 = 11218466945590 := by decide
theorem cert_e2422373923382 : check e2422373923382 [[],[]] .smaller = true := by decide
def e2422373923386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373923386 : Closed e2422373923386 ∧ code e2422373923386 = 11218466945594 := by decide
theorem cert_e2422373923386 : check e2422373923386 [[],[]] .smaller = true := by decide
def e2422373923434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373923434 : Closed e2422373923434 ∧ code e2422373923434 = 11218466945642 := by decide
theorem cert_e2422373923434 : check e2422373923434 [[],[]] .smaller = true := by decide
end Blc.Floor43
