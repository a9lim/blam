import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e738939693162 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e738939693162 : Closed e738939693162 ∧ code e738939693162 = 9535032715370 := by decide
theorem cert_e738939693162 : check e738939693162 [] .sourceHead = true := by decide
def e738939693594 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e738939693594 : Closed e738939693594 ∧ code e738939693594 = 9535032715802 := by decide
theorem cert_e738939693594 : check e738939693594 [] .sourceHead = true := by decide
def e739542677610 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739542677610 : Closed e739542677610 ∧ code e739542677610 = 9535635699818 := by decide
theorem cert_e739542677610 : check e739542677610 [] .sourceHead = true := by decide
def e739542678042 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739542678042 : Closed e739542678042 ∧ code e739542678042 = 9535635700250 := by decide
theorem cert_e739542678042 : check e739542678042 [] .sourceHead = true := by decide
def e739542685802 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739542685802 : Closed e739542685802 ∧ code e739542685802 = 9535635708010 := by decide
theorem cert_e739542685802 : check e739542685802 [] .sourceHead = true := by decide
def e739542686234 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739542686234 : Closed e739542686234 ∧ code e739542686234 = 9535635708442 := by decide
theorem cert_e739542686234 : check e739542686234 [] .sourceHead = true := by decide
def e739542743146 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739542743146 : Closed e739542743146 ∧ code e739542743146 = 9535635765354 := by decide
theorem cert_e739542743146 : check e739542743146 [] .sourceHead = true := by decide
def e739542743578 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739542743578 : Closed e739542743578 ∧ code e739542743578 = 9535635765786 := by decide
theorem cert_e739542743578 : check e739542743578 [] .sourceHead = true := by decide
def e739542755434 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739542755434 : Closed e739542755434 ∧ code e739542755434 = 9535635777642 := by decide
theorem cert_e739542755434 : check e739542755434 [] .sourceHead = true := by decide
def e739542755866 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739542755866 : Closed e739542755866 ∧ code e739542755866 = 9535635778074 := by decide
theorem cert_e739542755866 : check e739542755866 [] .sourceHead = true := by decide
def e739542784106 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739542784106 : Closed e739542784106 ∧ code e739542784106 = 9535635806314 := by decide
theorem cert_e739542784106 : check e739542784106 [] .sourceHead = true := by decide
def e739542784538 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739542784538 : Closed e739542784538 ∧ code e739542784538 = 9535635806746 := by decide
theorem cert_e739542784538 : check e739542784538 [] .sourceHead = true := by decide
def e739542788202 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739542788202 : Closed e739542788202 ∧ code e739542788202 = 9535635810410 := by decide
theorem cert_e739542788202 : check e739542788202 [] .sourceHead = true := by decide
def e739542788634 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739542788634 : Closed e739542788634 ∧ code e739542788634 = 9535635810842 := by decide
theorem cert_e739542788634 : check e739542788634 [] .sourceHead = true := by decide
def e739543070826 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739543070826 : Closed e739543070826 ∧ code e739543070826 = 9535636093034 := by decide
theorem cert_e739543070826 : check e739543070826 [] .sourceHead = true := by decide
def e739543071258 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739543071258 : Closed e739543071258 ∧ code e739543071258 = 9535636093466 := by decide
theorem cert_e739543071258 : check e739543071258 [] .sourceHead = true := by decide
def e739543079018 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739543079018 : Closed e739543079018 ∧ code e739543079018 = 9535636101226 := by decide
theorem cert_e739543079018 : check e739543079018 [] .sourceHead = true := by decide
def e739543079450 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739543079450 : Closed e739543079450 ∧ code e739543079450 = 9535636101658 := by decide
theorem cert_e739543079450 : check e739543079450 [] .sourceHead = true := by decide
def e739543464042 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739543464042 : Closed e739543464042 ∧ code e739543464042 = 9535636486250 := by decide
theorem cert_e739543464042 : check e739543464042 [] .sourceHead = true := by decide
def e739543464474 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739543464474 : Closed e739543464474 ∧ code e739543464474 = 9535636486682 := by decide
theorem cert_e739543464474 : check e739543464474 [] .sourceHead = true := by decide
def e739543476330 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739543476330 : Closed e739543476330 ∧ code e739543476330 = 9535636498538 := by decide
theorem cert_e739543476330 : check e739543476330 [] .sourceHead = true := by decide
def e739543476762 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739543476762 : Closed e739543476762 ∧ code e739543476762 = 9535636498970 := by decide
theorem cert_e739543476762 : check e739543476762 [] .sourceHead = true := by decide
def e739543668842 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739543668842 : Closed e739543668842 ∧ code e739543668842 = 9535636691050 := by decide
theorem cert_e739543668842 : check e739543668842 [] .sourceHead = true := by decide
def e739543669274 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739543669274 : Closed e739543669274 ∧ code e739543669274 = 9535636691482 := by decide
theorem cert_e739543669274 : check e739543669274 [] .sourceHead = true := by decide
def e739543672938 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem wire_e739543672938 : Closed e739543672938 ∧ code e739543672938 = 9535636695146 := by decide
theorem cert_e739543672938 : check e739543672938 [] .sourceHead = true := by decide
def e739543673370 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e739543673370 : Closed e739543673370 ∧ code e739543673370 = 9535636695578 := by decide
theorem cert_e739543673370 : check e739543673370 [] .sourceHead = true := by decide
def e739606967738 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e739606967738 : Closed e739606967738 ∧ code e739606967738 = 9535699989946 := by decide
theorem cert_e739606967738 : check e739606967738 [] .sourceHead = true := by decide
def e739606967770 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e739606967770 : Closed e739606967770 ∧ code e739606967770 = 9535699989978 := by decide
theorem cert_e739606967770 : check e739606967770 [] .sourceHead = true := by decide
def e739606967994 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e739606967994 : Closed e739606967994 ∧ code e739606967994 = 9535699990202 := by decide
theorem cert_e739606967994 : check e739606967994 [] .sourceHead = true := by decide
def e739606968042 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e739606968042 : Closed e739606968042 ∧ code e739606968042 = 9535699990250 := by decide
theorem cert_e739606968042 : check e739606968042 [] .sourceHead = true := by decide
def e739606968154 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e739606968154 : Closed e739606968154 ∧ code e739606968154 = 9535699990362 := by decide
theorem cert_e739606968154 : check e739606968154 [] .sourceHead = true := by decide
def e739606968170 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e739606968170 : Closed e739606968170 ∧ code e739606968170 = 9535699990378 := by decide
theorem cert_e739606968170 : check e739606968170 [] .sourceHead = true := by decide
def e739606969018 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e739606969018 : Closed e739606969018 ∧ code e739606969018 = 9535699991226 := by decide
theorem cert_e739606969018 : check e739606969018 [] .sourceHead = true := by decide
def e739606969066 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e739606969066 : Closed e739606969066 ∧ code e739606969066 = 9535699991274 := by decide
theorem cert_e739606969066 : check e739606969066 [] .sourceHead = true := by decide
def e739606969258 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e739606969258 : Closed e739606969258 ∧ code e739606969258 = 9535699991466 := by decide
theorem cert_e739606969258 : check e739606969258 [] .sourceHead = true := by decide
def e739606969690 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e739606969690 : Closed e739606969690 ∧ code e739606969690 = 9535699991898 := by decide
theorem cert_e739606969690 : check e739606969690 [] .sourceHead = true := by decide
def e739606969706 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e739606969706 : Closed e739606969706 ∧ code e739606969706 = 9535699991914 := by decide
theorem cert_e739606969706 : check e739606969706 [] .sourceHead = true := by decide
def e739606969770 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e739606969770 : Closed e739606969770 ∧ code e739606969770 = 9535699991978 := by decide
theorem cert_e739606969770 : check e739606969770 [] .sourceHead = true := by decide
def e739606973882 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e739606973882 : Closed e739606973882 ∧ code e739606973882 = 9535699996090 := by decide
theorem cert_e739606973882 : check e739606973882 [] .sourceHead = true := by decide
def e739606973914 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e739606973914 : Closed e739606973914 ∧ code e739606973914 = 9535699996122 := by decide
theorem cert_e739606973914 : check e739606973914 [] .sourceHead = true := by decide
def e739606974138 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e739606974138 : Closed e739606974138 ∧ code e739606974138 = 9535699996346 := by decide
theorem cert_e739606974138 : check e739606974138 [] .sourceHead = true := by decide
def e739606974186 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e739606974186 : Closed e739606974186 ∧ code e739606974186 = 9535699996394 := by decide
theorem cert_e739606974186 : check e739606974186 [] .sourceHead = true := by decide
def e739606974298 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e739606974298 : Closed e739606974298 ∧ code e739606974298 = 9535699996506 := by decide
theorem cert_e739606974298 : check e739606974298 [] .sourceHead = true := by decide
def e739606974314 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e739606974314 : Closed e739606974314 ∧ code e739606974314 = 9535699996522 := by decide
theorem cert_e739606974314 : check e739606974314 [] .sourceHead = true := by decide
def e739606975418 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e739606975418 : Closed e739606975418 ∧ code e739606975418 = 9535699997626 := by decide
theorem cert_e739606975418 : check e739606975418 [] .sourceHead = true := by decide
def e739606975450 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e739606975450 : Closed e739606975450 ∧ code e739606975450 = 9535699997658 := by decide
theorem cert_e739606975450 : check e739606975450 [] .sourceHead = true := by decide
def e739606976954 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e739606976954 : Closed e739606976954 ∧ code e739606976954 = 9535699999162 := by decide
theorem cert_e739606976954 : check e739606976954 [] .sourceHead = true := by decide
def e739606977002 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e739606977002 : Closed e739606977002 ∧ code e739606977002 = 9535699999210 := by decide
theorem cert_e739606977002 : check e739606977002 [] .sourceHead = true := by decide
def e739606977754 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e739606977754 : Closed e739606977754 ∧ code e739606977754 = 9535699999962 := by decide
theorem cert_e739606977754 : check e739606977754 [] .sourceHead = true := by decide
def e739606977770 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e739606977770 : Closed e739606977770 ∧ code e739606977770 = 9535699999978 := by decide
theorem cert_e739606977770 : check e739606977770 [] .sourceHead = true := by decide
def e739606980282 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e739606980282 : Closed e739606980282 ∧ code e739606980282 = 9535700002490 := by decide
theorem cert_e739606980282 : check e739606980282 [] .sourceHead = true := by decide
def e739606980330 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e739606980330 : Closed e739606980330 ∧ code e739606980330 = 9535700002538 := by decide
theorem cert_e739606980330 : check e739606980330 [] .sourceHead = true := by decide
def e739606980522 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e739606980522 : Closed e739606980522 ∧ code e739606980522 = 9535700002730 := by decide
theorem cert_e739606980522 : check e739606980522 [] .sourceHead = true := by decide
def e739606981050 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e739606981050 : Closed e739606981050 ∧ code e739606981050 = 9535700003258 := by decide
theorem cert_e739606981050 : check e739606981050 [] .sourceHead = true := by decide
def e739606981098 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e739606981098 : Closed e739606981098 ∧ code e739606981098 = 9535700003306 := by decide
theorem cert_e739606981098 : check e739606981098 [] .sourceHead = true := by decide
def e739606982250 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e739606982250 : Closed e739606982250 ∧ code e739606982250 = 9535700004458 := by decide
theorem cert_e739606982250 : check e739606982250 [] .sourceHead = true := by decide
def e739606983514 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e739606983514 : Closed e739606983514 ∧ code e739606983514 = 9535700005722 := by decide
theorem cert_e739606983514 : check e739606983514 [] .sourceHead = true := by decide
def e739606983530 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e739606983530 : Closed e739606983530 ∧ code e739606983530 = 9535700005738 := by decide
theorem cert_e739606983530 : check e739606983530 [] .sourceHead = true := by decide
def e739606983594 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e739606983594 : Closed e739606983594 ∧ code e739606983594 = 9535700005802 := by decide
theorem cert_e739606983594 : check e739606983594 [] .sourceHead = true := by decide
def e739606983898 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e739606983898 : Closed e739606983898 ∧ code e739606983898 = 9535700006106 := by decide
theorem cert_e739606983898 : check e739606983898 [] .sourceHead = true := by decide
def e739606983914 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e739606983914 : Closed e739606983914 ∧ code e739606983914 = 9535700006122 := by decide
theorem cert_e739606983914 : check e739606983914 [] .sourceHead = true := by decide
def e739606984298 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e739606984298 : Closed e739606984298 ∧ code e739606984298 = 9535700006506 := by decide
theorem cert_e739606984298 : check e739606984298 [] .sourceHead = true := by decide
def e739606998458 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e739606998458 : Closed e739606998458 ∧ code e739606998458 = 9535700020666 := by decide
theorem cert_e739606998458 : check e739606998458 [] .sourceHead = true := by decide
def e739606998490 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e739606998490 : Closed e739606998490 ∧ code e739606998490 = 9535700020698 := by decide
theorem cert_e739606998490 : check e739606998490 [] .sourceHead = true := by decide
def e739606998714 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e739606998714 : Closed e739606998714 ∧ code e739606998714 = 9535700020922 := by decide
theorem cert_e739606998714 : check e739606998714 [] .sourceHead = true := by decide
def e739606998762 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e739606998762 : Closed e739606998762 ∧ code e739606998762 = 9535700020970 := by decide
theorem cert_e739606998762 : check e739606998762 [] .sourceHead = true := by decide
def e739606998874 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e739606998874 : Closed e739606998874 ∧ code e739606998874 = 9535700021082 := by decide
theorem cert_e739606998874 : check e739606998874 [] .sourceHead = true := by decide
def e739606998890 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e739606998890 : Closed e739606998890 ∧ code e739606998890 = 9535700021098 := by decide
theorem cert_e739606998890 : check e739606998890 [] .sourceHead = true := by decide
def e739606999994 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e739606999994 : Closed e739606999994 ∧ code e739606999994 = 9535700022202 := by decide
theorem cert_e739606999994 : check e739606999994 [] .sourceHead = true := by decide
def e739607000026 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e739607000026 : Closed e739607000026 ∧ code e739607000026 = 9535700022234 := by decide
theorem cert_e739607000026 : check e739607000026 [] .sourceHead = true := by decide
def e739607001530 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e739607001530 : Closed e739607001530 ∧ code e739607001530 = 9535700023738 := by decide
theorem cert_e739607001530 : check e739607001530 [] .sourceHead = true := by decide
def e739607001578 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e739607001578 : Closed e739607001578 ∧ code e739607001578 = 9535700023786 := by decide
theorem cert_e739607001578 : check e739607001578 [] .sourceHead = true := by decide
def e739607002330 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e739607002330 : Closed e739607002330 ∧ code e739607002330 = 9535700024538 := by decide
theorem cert_e739607002330 : check e739607002330 [] .sourceHead = true := by decide
def e739607002346 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e739607002346 : Closed e739607002346 ∧ code e739607002346 = 9535700024554 := by decide
theorem cert_e739607002346 : check e739607002346 [] .sourceHead = true := by decide
def e739607025338 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e739607025338 : Closed e739607025338 ∧ code e739607025338 = 9535700047546 := by decide
theorem cert_e739607025338 : check e739607025338 [] .sourceHead = true := by decide
def e739607025386 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e739607025386 : Closed e739607025386 ∧ code e739607025386 = 9535700047594 := by decide
theorem cert_e739607025386 : check e739607025386 [] .sourceHead = true := by decide
def e739607025578 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e739607025578 : Closed e739607025578 ∧ code e739607025578 = 9535700047786 := by decide
theorem cert_e739607025578 : check e739607025578 [] .sourceHead = true := by decide
def e739607026106 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e739607026106 : Closed e739607026106 ∧ code e739607026106 = 9535700048314 := by decide
theorem cert_e739607026106 : check e739607026106 [] .sourceHead = true := by decide
def e739607026154 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e739607026154 : Closed e739607026154 ∧ code e739607026154 = 9535700048362 := by decide
theorem cert_e739607026154 : check e739607026154 [] .sourceHead = true := by decide
def e739607027306 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e739607027306 : Closed e739607027306 ∧ code e739607027306 = 9535700049514 := by decide
theorem cert_e739607027306 : check e739607027306 [] .sourceHead = true := by decide
def e739607038810 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e739607038810 : Closed e739607038810 ∧ code e739607038810 = 9535700061018 := by decide
theorem cert_e739607038810 : check e739607038810 [] .sourceHead = true := by decide
def e739607038826 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e739607038826 : Closed e739607038826 ∧ code e739607038826 = 9535700061034 := by decide
theorem cert_e739607038826 : check e739607038826 [] .sourceHead = true := by decide
def e739607038890 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e739607038890 : Closed e739607038890 ∧ code e739607038890 = 9535700061098 := by decide
theorem cert_e739607038890 : check e739607038890 [] .sourceHead = true := by decide
def e739607039194 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e739607039194 : Closed e739607039194 ∧ code e739607039194 = 9535700061402 := by decide
theorem cert_e739607039194 : check e739607039194 [] .sourceHead = true := by decide
def e739607039210 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e739607039210 : Closed e739607039210 ∧ code e739607039210 = 9535700061418 := by decide
theorem cert_e739607039210 : check e739607039210 [] .sourceHead = true := by decide
def e739607039594 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e739607039594 : Closed e739607039594 ∧ code e739607039594 = 9535700061802 := by decide
theorem cert_e739607039594 : check e739607039594 [] .sourceHead = true := by decide
def e739607588282 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e739607588282 : Closed e739607588282 ∧ code e739607588282 = 9535700610490 := by decide
theorem cert_e739607588282 : check e739607588282 [] .sourceHead = true := by decide
def e739607588314 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e739607588314 : Closed e739607588314 ∧ code e739607588314 = 9535700610522 := by decide
theorem cert_e739607588314 : check e739607588314 [] .sourceHead = true := by decide
def e739607588538 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e739607588538 : Closed e739607588538 ∧ code e739607588538 = 9535700610746 := by decide
theorem cert_e739607588538 : check e739607588538 [] .sourceHead = true := by decide
def e739607588586 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e739607588586 : Closed e739607588586 ∧ code e739607588586 = 9535700610794 := by decide
theorem cert_e739607588586 : check e739607588586 [] .sourceHead = true := by decide
def e739607588698 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e739607588698 : Closed e739607588698 ∧ code e739607588698 = 9535700610906 := by decide
theorem cert_e739607588698 : check e739607588698 [] .sourceHead = true := by decide
def e739607588714 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e739607588714 : Closed e739607588714 ∧ code e739607588714 = 9535700610922 := by decide
theorem cert_e739607588714 : check e739607588714 [] .sourceHead = true := by decide
def e739607589818 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e739607589818 : Closed e739607589818 ∧ code e739607589818 = 9535700612026 := by decide
theorem cert_e739607589818 : check e739607589818 [] .sourceHead = true := by decide
def e739607589850 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e739607589850 : Closed e739607589850 ∧ code e739607589850 = 9535700612058 := by decide
theorem cert_e739607589850 : check e739607589850 [] .sourceHead = true := by decide
def e739607591354 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e739607591354 : Closed e739607591354 ∧ code e739607591354 = 9535700613562 := by decide
theorem cert_e739607591354 : check e739607591354 [] .sourceHead = true := by decide
def e739607591402 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e739607591402 : Closed e739607591402 ∧ code e739607591402 = 9535700613610 := by decide
theorem cert_e739607591402 : check e739607591402 [] .sourceHead = true := by decide
def e739607592154 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e739607592154 : Closed e739607592154 ∧ code e739607592154 = 9535700614362 := by decide
theorem cert_e739607592154 : check e739607592154 [] .sourceHead = true := by decide
def e739607592170 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e739607592170 : Closed e739607592170 ∧ code e739607592170 = 9535700614378 := by decide
theorem cert_e739607592170 : check e739607592170 [] .sourceHead = true := by decide
def e739609947578 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e739609947578 : Closed e739609947578 ∧ code e739609947578 = 9535702969786 := by decide
theorem cert_e739609947578 : check e739609947578 [] .sourceHead = true := by decide
def e739609947610 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e739609947610 : Closed e739609947610 ∧ code e739609947610 = 9535702969818 := by decide
theorem cert_e739609947610 : check e739609947610 [] .sourceHead = true := by decide
def e739609947834 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e739609947834 : Closed e739609947834 ∧ code e739609947834 = 9535702970042 := by decide
theorem cert_e739609947834 : check e739609947834 [] .sourceHead = true := by decide
def e739609947882 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e739609947882 : Closed e739609947882 ∧ code e739609947882 = 9535702970090 := by decide
theorem cert_e739609947882 : check e739609947882 [] .sourceHead = true := by decide
def e739609947994 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e739609947994 : Closed e739609947994 ∧ code e739609947994 = 9535702970202 := by decide
theorem cert_e739609947994 : check e739609947994 [] .sourceHead = true := by decide
def e739609948010 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e739609948010 : Closed e739609948010 ∧ code e739609948010 = 9535702970218 := by decide
theorem cert_e739609948010 : check e739609948010 [] .sourceHead = true := by decide
def e739609949114 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e739609949114 : Closed e739609949114 ∧ code e739609949114 = 9535702971322 := by decide
theorem cert_e739609949114 : check e739609949114 [] .sourceHead = true := by decide
def e739609949146 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e739609949146 : Closed e739609949146 ∧ code e739609949146 = 9535702971354 := by decide
theorem cert_e739609949146 : check e739609949146 [] .sourceHead = true := by decide
def e739609950650 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e739609950650 : Closed e739609950650 ∧ code e739609950650 = 9535702972858 := by decide
theorem cert_e739609950650 : check e739609950650 [] .sourceHead = true := by decide
def e739609950698 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e739609950698 : Closed e739609950698 ∧ code e739609950698 = 9535702972906 := by decide
theorem cert_e739609950698 : check e739609950698 [] .sourceHead = true := by decide
def e739609951450 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e739609951450 : Closed e739609951450 ∧ code e739609951450 = 9535702973658 := by decide
theorem cert_e739609951450 : check e739609951450 [] .sourceHead = true := by decide
def e739609951466 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e739609951466 : Closed e739609951466 ∧ code e739609951466 = 9535702973674 := by decide
theorem cert_e739609951466 : check e739609951466 [] .sourceHead = true := by decide
def e739623611758 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e739623611758 : Closed e739623611758 ∧ code e739623611758 = 9535716633966 := by decide
theorem cert_e739623611758 : check e739623611758 [] .sourceHead = true := by decide
def e739623611766 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e739623611766 : Closed e739623611766 ∧ code e739623611766 = 9535716633974 := by decide
theorem cert_e739623611766 : check e739623611766 [] .sourceHead = true := by decide
def e739623611822 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e739623611822 : Closed e739623611822 ∧ code e739623611822 = 9535716634030 := by decide
theorem cert_e739623611822 : check e739623611822 [] .sourceHead = true := by decide
def e739623611834 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e739623611834 : Closed e739623611834 ∧ code e739623611834 = 9535716634042 := by decide
theorem cert_e739623611834 : check e739623611834 [] .sourceHead = true := by decide
def e739623611862 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e739623611862 : Closed e739623611862 ∧ code e739623611862 = 9535716634070 := by decide
theorem cert_e739623611862 : check e739623611862 [] .sourceHead = true := by decide
def e739623611866 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e739623611866 : Closed e739623611866 ∧ code e739623611866 = 9535716634074 := by decide
theorem cert_e739623611866 : check e739623611866 [] .sourceHead = true := by decide
def e739623612078 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e739623612078 : Closed e739623612078 ∧ code e739623612078 = 9535716634286 := by decide
theorem cert_e739623612078 : check e739623612078 [] .sourceHead = true := by decide
def e739623612090 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e739623612090 : Closed e739623612090 ∧ code e739623612090 = 9535716634298 := by decide
theorem cert_e739623612090 : check e739623612090 [] .sourceHead = true := by decide
def e739623612138 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e739623612138 : Closed e739623612138 ∧ code e739623612138 = 9535716634346 := by decide
theorem cert_e739623612138 : check e739623612138 [] .sourceHead = true := by decide
def e739623612246 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e739623612246 : Closed e739623612246 ∧ code e739623612246 = 9535716634454 := by decide
theorem cert_e739623612246 : check e739623612246 [] .sourceHead = true := by decide
def e739623612250 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e739623612250 : Closed e739623612250 ∧ code e739623612250 = 9535716634458 := by decide
theorem cert_e739623612250 : check e739623612250 [] .sourceHead = true := by decide
def e739623612266 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e739623612266 : Closed e739623612266 ∧ code e739623612266 = 9535716634474 := by decide
theorem cert_e739623612266 : check e739623612266 [] .sourceHead = true := by decide
def e739623613294 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e739623613294 : Closed e739623613294 ∧ code e739623613294 = 9535716635502 := by decide
theorem cert_e739623613294 : check e739623613294 [] .sourceHead = true := by decide
def e739623613302 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e739623613302 : Closed e739623613302 ∧ code e739623613302 = 9535716635510 := by decide
theorem cert_e739623613302 : check e739623613302 [] .sourceHead = true := by decide
def e739623613358 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e739623613358 : Closed e739623613358 ∧ code e739623613358 = 9535716635566 := by decide
theorem cert_e739623613358 : check e739623613358 [] .sourceHead = true := by decide
def e739623613370 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e739623613370 : Closed e739623613370 ∧ code e739623613370 = 9535716635578 := by decide
theorem cert_e739623613370 : check e739623613370 [] .sourceHead = true := by decide
def e739623613398 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e739623613398 : Closed e739623613398 ∧ code e739623613398 = 9535716635606 := by decide
theorem cert_e739623613398 : check e739623613398 [] .sourceHead = true := by decide
def e739623613402 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e739623613402 : Closed e739623613402 ∧ code e739623613402 = 9535716635610 := by decide
theorem cert_e739623613402 : check e739623613402 [] .sourceHead = true := by decide
def e739623613678 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e739623613678 : Closed e739623613678 ∧ code e739623613678 = 9535716635886 := by decide
theorem cert_e739623613678 : check e739623613678 [] .sourceHead = true := by decide
def e739623613686 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e739623613686 : Closed e739623613686 ∧ code e739623613686 = 9535716635894 := by decide
theorem cert_e739623613686 : check e739623613686 [] .sourceHead = true := by decide
def e739623614062 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e739623614062 : Closed e739623614062 ∧ code e739623614062 = 9535716636270 := by decide
theorem cert_e739623614062 : check e739623614062 [] .sourceHead = true := by decide
def e739623614074 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e739623614074 : Closed e739623614074 ∧ code e739623614074 = 9535716636282 := by decide
theorem cert_e739623614074 : check e739623614074 [] .sourceHead = true := by decide
def e739623614262 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e739623614262 : Closed e739623614262 ∧ code e739623614262 = 9535716636470 := by decide
theorem cert_e739623614262 : check e739623614262 [] .sourceHead = true := by decide
def e739623614266 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e739623614266 : Closed e739623614266 ∧ code e739623614266 = 9535716636474 := by decide
theorem cert_e739623614266 : check e739623614266 [] .sourceHead = true := by decide
def e739623614894 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e739623614894 : Closed e739623614894 ∧ code e739623614894 = 9535716637102 := by decide
theorem cert_e739623614894 : check e739623614894 [] .sourceHead = true := by decide
def e739623614906 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e739623614906 : Closed e739623614906 ∧ code e739623614906 = 9535716637114 := by decide
theorem cert_e739623614906 : check e739623614906 [] .sourceHead = true := by decide
def e739623614954 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e739623614954 : Closed e739623614954 ∧ code e739623614954 = 9535716637162 := by decide
theorem cert_e739623614954 : check e739623614954 [] .sourceHead = true := by decide
def e739623615086 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e739623615086 : Closed e739623615086 ∧ code e739623615086 = 9535716637294 := by decide
theorem cert_e739623615086 : check e739623615086 [] .sourceHead = true := by decide
def e739623615098 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e739623615098 : Closed e739623615098 ∧ code e739623615098 = 9535716637306 := by decide
theorem cert_e739623615098 : check e739623615098 [] .sourceHead = true := by decide
def e739623615386 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e739623615386 : Closed e739623615386 ∧ code e739623615386 = 9535716637594 := by decide
theorem cert_e739623615386 : check e739623615386 [] .sourceHead = true := by decide
def e739623615702 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e739623615702 : Closed e739623615702 ∧ code e739623615702 = 9535716637910 := by decide
theorem cert_e739623615702 : check e739623615702 [] .sourceHead = true := by decide
def e739623615706 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e739623615706 : Closed e739623615706 ∧ code e739623615706 = 9535716637914 := by decide
theorem cert_e739623615706 : check e739623615706 [] .sourceHead = true := by decide
def e739623615722 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e739623615722 : Closed e739623615722 ∧ code e739623615722 = 9535716637930 := by decide
theorem cert_e739623615722 : check e739623615722 [] .sourceHead = true := by decide
def e739623615798 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e739623615798 : Closed e739623615798 ∧ code e739623615798 = 9535716638006 := by decide
theorem cert_e739623615798 : check e739623615798 [] .sourceHead = true := by decide
def e739623615802 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e739623615802 : Closed e739623615802 ∧ code e739623615802 = 9535716638010 := by decide
theorem cert_e739623615802 : check e739623615802 [] .sourceHead = true := by decide
def e739623615898 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e739623615898 : Closed e739623615898 ∧ code e739623615898 = 9535716638106 := by decide
theorem cert_e739623615898 : check e739623615898 [] .sourceHead = true := by decide
def e739623619438 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e739623619438 : Closed e739623619438 ∧ code e739623619438 = 9535716641646 := by decide
theorem cert_e739623619438 : check e739623619438 [] .sourceHead = true := by decide
def e739623619446 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e739623619446 : Closed e739623619446 ∧ code e739623619446 = 9535716641654 := by decide
theorem cert_e739623619446 : check e739623619446 [] .sourceHead = true := by decide
def e739623619502 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e739623619502 : Closed e739623619502 ∧ code e739623619502 = 9535716641710 := by decide
theorem cert_e739623619502 : check e739623619502 [] .sourceHead = true := by decide
def e739623619514 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e739623619514 : Closed e739623619514 ∧ code e739623619514 = 9535716641722 := by decide
theorem cert_e739623619514 : check e739623619514 [] .sourceHead = true := by decide
def e739623619542 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e739623619542 : Closed e739623619542 ∧ code e739623619542 = 9535716641750 := by decide
theorem cert_e739623619542 : check e739623619542 [] .sourceHead = true := by decide
def e739623619546 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e739623619546 : Closed e739623619546 ∧ code e739623619546 = 9535716641754 := by decide
theorem cert_e739623619546 : check e739623619546 [] .sourceHead = true := by decide
def e739623619822 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e739623619822 : Closed e739623619822 ∧ code e739623619822 = 9535716642030 := by decide
theorem cert_e739623619822 : check e739623619822 [] .sourceHead = true := by decide
def e739623619830 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e739623619830 : Closed e739623619830 ∧ code e739623619830 = 9535716642038 := by decide
theorem cert_e739623619830 : check e739623619830 [] .sourceHead = true := by decide
def e739623620206 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e739623620206 : Closed e739623620206 ∧ code e739623620206 = 9535716642414 := by decide
theorem cert_e739623620206 : check e739623620206 [] .sourceHead = true := by decide
def e739623620218 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e739623620218 : Closed e739623620218 ∧ code e739623620218 = 9535716642426 := by decide
theorem cert_e739623620218 : check e739623620218 [] .sourceHead = true := by decide
def e739623620406 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e739623620406 : Closed e739623620406 ∧ code e739623620406 = 9535716642614 := by decide
theorem cert_e739623620406 : check e739623620406 [] .sourceHead = true := by decide
def e739623620410 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e739623620410 : Closed e739623620410 ∧ code e739623620410 = 9535716642618 := by decide
theorem cert_e739623620410 : check e739623620410 [] .sourceHead = true := by decide
def e739623626158 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e739623626158 : Closed e739623626158 ∧ code e739623626158 = 9535716648366 := by decide
theorem cert_e739623626158 : check e739623626158 [] .sourceHead = true := by decide
def e739623626170 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e739623626170 : Closed e739623626170 ∧ code e739623626170 = 9535716648378 := by decide
theorem cert_e739623626170 : check e739623626170 [] .sourceHead = true := by decide
end Blc.Floor43
