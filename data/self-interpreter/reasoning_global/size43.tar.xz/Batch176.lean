import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262377213786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2262377213786 : Closed e2262377213786 ∧ code e2262377213786 = 11058470235994 := by decide
theorem cert_e2262377213786 : check e2262377213786 [[],[.under]] .smaller = true := by decide
def e2262377213802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2262377213802 : Closed e2262377213802 ∧ code e2262377213802 = 11058470236010 := by decide
theorem cert_e2262377213802 : check e2262377213802 [[],[.under]] .smaller = true := by decide
def e2262377214430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2262377214430 : Closed e2262377214430 ∧ code e2262377214430 = 11058470236638 := by decide
theorem cert_e2262377214430 : check e2262377214430 [[],[.under]] .three = true := by decide
def e2262377214454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2262377214454 : Closed e2262377214454 ∧ code e2262377214454 = 11058470236662 := by decide
theorem cert_e2262377214454 : check e2262377214454 [[],[.under]] .three = true := by decide
def e2262377214830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2262377214830 : Closed e2262377214830 ∧ code e2262377214830 = 11058470237038 := by decide
theorem cert_e2262377214830 : check e2262377214830 [[],[.under]] .smaller = true := by decide
def e2262377214838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2262377214838 : Closed e2262377214838 ∧ code e2262377214838 = 11058470237046 := by decide
theorem cert_e2262377214838 : check e2262377214838 [[],[.under]] .smaller = true := by decide
def e2262377214894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2262377214894 : Closed e2262377214894 ∧ code e2262377214894 = 11058470237102 := by decide
theorem cert_e2262377214894 : check e2262377214894 [[],[.under]] .smaller = true := by decide
def e2262377214906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2262377214906 : Closed e2262377214906 ∧ code e2262377214906 = 11058470237114 := by decide
theorem cert_e2262377214906 : check e2262377214906 [[],[.under]] .smaller = true := by decide
def e2262377214934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2262377214934 : Closed e2262377214934 ∧ code e2262377214934 = 11058470237142 := by decide
theorem cert_e2262377214934 : check e2262377214934 [[],[.under]] .smaller = true := by decide
def e2262377214938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2262377214938 : Closed e2262377214938 ∧ code e2262377214938 = 11058470237146 := by decide
theorem cert_e2262377214938 : check e2262377214938 [[],[.under]] .smaller = true := by decide
def e2262377215214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262377215214 : Closed e2262377215214 ∧ code e2262377215214 = 11058470237422 := by decide
theorem cert_e2262377215214 : check e2262377215214 [[],[.under]] .smaller = true := by decide
def e2262377215222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262377215222 : Closed e2262377215222 ∧ code e2262377215222 = 11058470237430 := by decide
theorem cert_e2262377215222 : check e2262377215222 [[],[.under]] .smaller = true := by decide
def e2262377215550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2262377215550 : Closed e2262377215550 ∧ code e2262377215550 = 11058470237758 := by decide
theorem cert_e2262377215550 : check e2262377215550 [[],[.under]] .three = true := by decide
def e2262377215598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262377215598 : Closed e2262377215598 ∧ code e2262377215598 = 11058470237806 := by decide
theorem cert_e2262377215598 : check e2262377215598 [[],[.under]] .smaller = true := by decide
def e2262377215610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262377215610 : Closed e2262377215610 ∧ code e2262377215610 = 11058470237818 := by decide
theorem cert_e2262377215610 : check e2262377215610 [[],[.under]] .smaller = true := by decide
def e2262377215798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262377215798 : Closed e2262377215798 ∧ code e2262377215798 = 11058470238006 := by decide
theorem cert_e2262377215798 : check e2262377215798 [[],[.under]] .smaller = true := by decide
def e2262377215802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262377215802 : Closed e2262377215802 ∧ code e2262377215802 = 11058470238010 := by decide
theorem cert_e2262377215802 : check e2262377215802 [[],[.under]] .smaller = true := by decide
def e2262377215886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2262377215886 : Closed e2262377215886 ∧ code e2262377215886 = 11058470238094 := by decide
theorem cert_e2262377215886 : check e2262377215886 [[],[.under]] .three = true := by decide
def e2262377216222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2262377216222 : Closed e2262377216222 ∧ code e2262377216222 = 11058470238430 := by decide
theorem cert_e2262377216222 : check e2262377216222 [[],[.under]] .three = true := by decide
def e2262377216250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2262377216250 : Closed e2262377216250 ∧ code e2262377216250 = 11058470238458 := by decide
theorem cert_e2262377216250 : check e2262377216250 [[],[.under]] .three = true := by decide
def e2262377216430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2262377216430 : Closed e2262377216430 ∧ code e2262377216430 = 11058470238638 := by decide
theorem cert_e2262377216430 : check e2262377216430 [[],[.under]] .smaller = true := by decide
def e2262377216442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2262377216442 : Closed e2262377216442 ∧ code e2262377216442 = 11058470238650 := by decide
theorem cert_e2262377216442 : check e2262377216442 [[],[.under]] .smaller = true := by decide
def e2262377216490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2262377216490 : Closed e2262377216490 ∧ code e2262377216490 = 11058470238698 := by decide
theorem cert_e2262377216490 : check e2262377216490 [[],[.under]] .smaller = true := by decide
def e2262377216574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2262377216574 : Closed e2262377216574 ∧ code e2262377216574 = 11058470238782 := by decide
theorem cert_e2262377216574 : check e2262377216574 [[],[.under]] .three = true := by decide
def e2262377216622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262377216622 : Closed e2262377216622 ∧ code e2262377216622 = 11058470238830 := by decide
theorem cert_e2262377216622 : check e2262377216622 [[],[.under]] .smaller = true := by decide
def e2262377216634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262377216634 : Closed e2262377216634 ∧ code e2262377216634 = 11058470238842 := by decide
theorem cert_e2262377216634 : check e2262377216634 [[],[.under]] .smaller = true := by decide
def e2262377216922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377216922 : Closed e2262377216922 ∧ code e2262377216922 = 11058470239130 := by decide
theorem cert_e2262377216922 : check e2262377216922 [[],[.under]] .smaller = true := by decide
def e2262377216966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2262377216966 : Closed e2262377216966 ∧ code e2262377216966 = 11058470239174 := by decide
theorem cert_e2262377216966 : check e2262377216966 [[],[.under]] .three = true := by decide
def e2262377217238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2262377217238 : Closed e2262377217238 ∧ code e2262377217238 = 11058470239446 := by decide
theorem cert_e2262377217238 : check e2262377217238 [[],[.under]] .smaller = true := by decide
def e2262377217242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2262377217242 : Closed e2262377217242 ∧ code e2262377217242 = 11058470239450 := by decide
theorem cert_e2262377217242 : check e2262377217242 [[],[.under]] .smaller = true := by decide
def e2262377217258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2262377217258 : Closed e2262377217258 ∧ code e2262377217258 = 11058470239466 := by decide
theorem cert_e2262377217258 : check e2262377217258 [[],[.under]] .smaller = true := by decide
def e2262377217334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262377217334 : Closed e2262377217334 ∧ code e2262377217334 = 11058470239542 := by decide
theorem cert_e2262377217334 : check e2262377217334 [[],[.under]] .smaller = true := by decide
def e2262377217338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262377217338 : Closed e2262377217338 ∧ code e2262377217338 = 11058470239546 := by decide
theorem cert_e2262377217338 : check e2262377217338 [[],[.under]] .smaller = true := by decide
def e2262377217434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377217434 : Closed e2262377217434 ∧ code e2262377217434 = 11058470239642 := by decide
theorem cert_e2262377217434 : check e2262377217434 [[],[.under]] .smaller = true := by decide
def e2262377217502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e2262377217502 : Closed e2262377217502 ∧ code e2262377217502 = 11058470239710 := by decide
theorem cert_e2262377217502 : check e2262377217502 [[],[.under]] .three = true := by decide
def e2262377217518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e2262377217518 : Closed e2262377217518 ∧ code e2262377217518 = 11058470239726 := by decide
theorem cert_e2262377217518 : check e2262377217518 [[],[.under]] .three = true := by decide
def e2262377217590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2262377217590 : Closed e2262377217590 ∧ code e2262377217590 = 11058470239798 := by decide
theorem cert_e2262377217590 : check e2262377217590 [[],[.under]] .three = true := by decide
def e2262377217594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2262377217594 : Closed e2262377217594 ∧ code e2262377217594 = 11058470239802 := by decide
theorem cert_e2262377217594 : check e2262377217594 [[],[.under]] .three = true := by decide
def e2262377217678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2262377217678 : Closed e2262377217678 ∧ code e2262377217678 = 11058470239886 := by decide
theorem cert_e2262377217678 : check e2262377217678 [[],[.under]] .three = true := by decide
def e2262377217734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2262377217734 : Closed e2262377217734 ∧ code e2262377217734 = 11058470239942 := by decide
theorem cert_e2262377217734 : check e2262377217734 [[],[.under]] .three = true := by decide
def e2262377217774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e2262377217774 : Closed e2262377217774 ∧ code e2262377217774 = 11058470239982 := by decide
theorem cert_e2262377217774 : check e2262377217774 [[],[.under]] .three = true := by decide
def e2262377219038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2262377219038 : Closed e2262377219038 ∧ code e2262377219038 = 11058470241246 := by decide
theorem cert_e2262377219038 : check e2262377219038 [[],[.under]] .smaller = true := by decide
def e2262377219054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2262377219054 : Closed e2262377219054 ∧ code e2262377219054 = 11058470241262 := by decide
theorem cert_e2262377219054 : check e2262377219054 [[],[.under]] .smaller = true := by decide
def e2262377220974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262377220974 : Closed e2262377220974 ∧ code e2262377220974 = 11058470243182 := by decide
theorem cert_e2262377220974 : check e2262377220974 [[],[.under]] .smaller = true := by decide
def e2262377220982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262377220982 : Closed e2262377220982 ∧ code e2262377220982 = 11058470243190 := by decide
theorem cert_e2262377220982 : check e2262377220982 [[],[.under]] .smaller = true := by decide
def e2262377221038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262377221038 : Closed e2262377221038 ∧ code e2262377221038 = 11058470243246 := by decide
theorem cert_e2262377221038 : check e2262377221038 [[],[.under]] .smaller = true := by decide
def e2262377221050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262377221050 : Closed e2262377221050 ∧ code e2262377221050 = 11058470243258 := by decide
theorem cert_e2262377221050 : check e2262377221050 [[],[.under]] .smaller = true := by decide
def e2262377221078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262377221078 : Closed e2262377221078 ∧ code e2262377221078 = 11058470243286 := by decide
theorem cert_e2262377221078 : check e2262377221078 [[],[.under]] .smaller = true := by decide
def e2262377221082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262377221082 : Closed e2262377221082 ∧ code e2262377221082 = 11058470243290 := by decide
theorem cert_e2262377221082 : check e2262377221082 [[],[.under]] .smaller = true := by decide
def e2262377221358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262377221358 : Closed e2262377221358 ∧ code e2262377221358 = 11058470243566 := by decide
theorem cert_e2262377221358 : check e2262377221358 [[],[.under]] .smaller = true := by decide
def e2262377221366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262377221366 : Closed e2262377221366 ∧ code e2262377221366 = 11058470243574 := by decide
theorem cert_e2262377221366 : check e2262377221366 [[],[.under]] .smaller = true := by decide
def e2262377221694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2262377221694 : Closed e2262377221694 ∧ code e2262377221694 = 11058470243902 := by decide
theorem cert_e2262377221694 : check e2262377221694 [[],[.under]] .three = true := by decide
def e2262377221742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262377221742 : Closed e2262377221742 ∧ code e2262377221742 = 11058470243950 := by decide
theorem cert_e2262377221742 : check e2262377221742 [[],[.under]] .smaller = true := by decide
def e2262377221754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262377221754 : Closed e2262377221754 ∧ code e2262377221754 = 11058470243962 := by decide
theorem cert_e2262377221754 : check e2262377221754 [[],[.under]] .smaller = true := by decide
def e2262377221942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262377221942 : Closed e2262377221942 ∧ code e2262377221942 = 11058470244150 := by decide
theorem cert_e2262377221942 : check e2262377221942 [[],[.under]] .smaller = true := by decide
def e2262377221946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262377221946 : Closed e2262377221946 ∧ code e2262377221946 = 11058470244154 := by decide
theorem cert_e2262377221946 : check e2262377221946 [[],[.under]] .smaller = true := by decide
def e2262377222030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2262377222030 : Closed e2262377222030 ∧ code e2262377222030 = 11058470244238 := by decide
theorem cert_e2262377222030 : check e2262377222030 [[],[.under]] .three = true := by decide
def e2262377226718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2262377226718 : Closed e2262377226718 ∧ code e2262377226718 = 11058470248926 := by decide
theorem cert_e2262377226718 : check e2262377226718 [[],[.under]] .smaller = true := by decide
def e2262377226742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2262377226742 : Closed e2262377226742 ∧ code e2262377226742 = 11058470248950 := by decide
theorem cert_e2262377226742 : check e2262377226742 [[],[.under]] .smaller = true := by decide
def e2262377227694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2262377227694 : Closed e2262377227694 ∧ code e2262377227694 = 11058470249902 := by decide
theorem cert_e2262377227694 : check e2262377227694 [[],[.under]] .smaller = true := by decide
def e2262377227706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2262377227706 : Closed e2262377227706 ∧ code e2262377227706 = 11058470249914 := by decide
theorem cert_e2262377227706 : check e2262377227706 [[],[.under]] .smaller = true := by decide
def e2262377227754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2262377227754 : Closed e2262377227754 ∧ code e2262377227754 = 11058470249962 := by decide
theorem cert_e2262377227754 : check e2262377227754 [[],[.under]] .smaller = true := by decide
def e2262377227838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2262377227838 : Closed e2262377227838 ∧ code e2262377227838 = 11058470250046 := by decide
theorem cert_e2262377227838 : check e2262377227838 [[],[.under]] .three = true := by decide
def e2262377227886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262377227886 : Closed e2262377227886 ∧ code e2262377227886 = 11058470250094 := by decide
theorem cert_e2262377227886 : check e2262377227886 [[],[.under]] .smaller = true := by decide
def e2262377227898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262377227898 : Closed e2262377227898 ∧ code e2262377227898 = 11058470250106 := by decide
theorem cert_e2262377227898 : check e2262377227898 [[],[.under]] .smaller = true := by decide
def e2262377228186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262377228186 : Closed e2262377228186 ∧ code e2262377228186 = 11058470250394 := by decide
theorem cert_e2262377228186 : check e2262377228186 [[],[.under]] .smaller = true := by decide
def e2262377228230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2262377228230 : Closed e2262377228230 ∧ code e2262377228230 = 11058470250438 := by decide
theorem cert_e2262377228230 : check e2262377228230 [[],[.under]] .three = true := by decide
def e2262377230574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2262377230574 : Closed e2262377230574 ∧ code e2262377230574 = 11058470252782 := by decide
theorem cert_e2262377230574 : check e2262377230574 [[],[.under]] .smaller = true := by decide
def e2262377230582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2262377230582 : Closed e2262377230582 ∧ code e2262377230582 = 11058470252790 := by decide
theorem cert_e2262377230582 : check e2262377230582 [[],[.under]] .smaller = true := by decide
def e2262377231062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2262377231062 : Closed e2262377231062 ∧ code e2262377231062 = 11058470253270 := by decide
theorem cert_e2262377231062 : check e2262377231062 [[],[.under]] .smaller = true := by decide
def e2262377231066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2262377231066 : Closed e2262377231066 ∧ code e2262377231066 = 11058470253274 := by decide
theorem cert_e2262377231066 : check e2262377231066 [[],[.under]] .smaller = true := by decide
def e2262377231082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2262377231082 : Closed e2262377231082 ∧ code e2262377231082 = 11058470253290 := by decide
theorem cert_e2262377231082 : check e2262377231082 [[],[.under]] .smaller = true := by decide
def e2262377231158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262377231158 : Closed e2262377231158 ∧ code e2262377231158 = 11058470253366 := by decide
theorem cert_e2262377231158 : check e2262377231158 [[],[.under]] .smaller = true := by decide
def e2262377231162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262377231162 : Closed e2262377231162 ∧ code e2262377231162 = 11058470253370 := by decide
theorem cert_e2262377231162 : check e2262377231162 [[],[.under]] .smaller = true := by decide
def e2262377231258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262377231258 : Closed e2262377231258 ∧ code e2262377231258 = 11058470253466 := by decide
theorem cert_e2262377231258 : check e2262377231258 [[],[.under]] .smaller = true := by decide
def e2262377231326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e2262377231326 : Closed e2262377231326 ∧ code e2262377231326 = 11058470253534 := by decide
theorem cert_e2262377231326 : check e2262377231326 [[],[.under]] .three = true := by decide
def e2262377231342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e2262377231342 : Closed e2262377231342 ∧ code e2262377231342 = 11058470253550 := by decide
theorem cert_e2262377231342 : check e2262377231342 [[],[.under]] .three = true := by decide
def e2262377232782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2262377232782 : Closed e2262377232782 ∧ code e2262377232782 = 11058470254990 := by decide
theorem cert_e2262377232782 : check e2262377232782 [[],[.under]] .three = true := by decide
def e2262377232838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2262377232838 : Closed e2262377232838 ∧ code e2262377232838 = 11058470255046 := by decide
theorem cert_e2262377232838 : check e2262377232838 [[],[.under]] .three = true := by decide
def e2262377232878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262377232878 : Closed e2262377232878 ∧ code e2262377232878 = 11058470255086 := by decide
theorem cert_e2262377232878 : check e2262377232878 [[],[.under]] .three = true := by decide
def e2262377313518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377313518 : Closed e2262377313518 ∧ code e2262377313518 = 11058470335726 := by decide
theorem cert_e2262377313518 : check e2262377313518 [[],[.under]] .three = true := by decide
def e2262377313526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377313526 : Closed e2262377313526 ∧ code e2262377313526 = 11058470335734 := by decide
theorem cert_e2262377313526 : check e2262377313526 [[],[.under]] .three = true := by decide
def e2262377345390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2262377345390 : Closed e2262377345390 ∧ code e2262377345390 = 11058470367598 := by decide
theorem cert_e2262377345390 : check e2262377345390 [[],[.under]] .three = true := by decide
def e2262377345398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2262377345398 : Closed e2262377345398 ∧ code e2262377345398 = 11058470367606 := by decide
theorem cert_e2262377345398 : check e2262377345398 [[],[.under]] .three = true := by decide
def e2262377346606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262377346606 : Closed e2262377346606 ∧ code e2262377346606 = 11058470368814 := by decide
theorem cert_e2262377346606 : check e2262377346606 [[],[.under]] .three = true := by decide
def e2262377346786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262377346786 : Closed e2262377346786 ∧ code e2262377346786 = 11058470368994 := by decide
theorem cert_e2262377346786 : check e2262377346786 [[],[.under]] .three = true := by decide
def e2262377346798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2262377346798 : Closed e2262377346798 ∧ code e2262377346798 = 11058470369006 := by decide
theorem cert_e2262377346798 : check e2262377346798 [[],[.under]] .three = true := by decide
def e2262377346838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262377346838 : Closed e2262377346838 ∧ code e2262377346838 = 11058470369046 := by decide
theorem cert_e2262377346838 : check e2262377346838 [[],[.under]] .three = true := by decide
def e2262377346914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262377346914 : Closed e2262377346914 ∧ code e2262377346914 = 11058470369122 := by decide
theorem cert_e2262377346914 : check e2262377346914 [[],[.under]] .three = true := by decide
def e2262377346926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2262377346926 : Closed e2262377346926 ∧ code e2262377346926 = 11058470369134 := by decide
theorem cert_e2262377346926 : check e2262377346926 [[],[.under]] .three = true := by decide
def e2262377346934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2262377346934 : Closed e2262377346934 ∧ code e2262377346934 = 11058470369142 := by decide
theorem cert_e2262377346934 : check e2262377346934 [[],[.under]] .three = true := by decide
def e2262377347246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2262377347246 : Closed e2262377347246 ∧ code e2262377347246 = 11058470369454 := by decide
theorem cert_e2262377347246 : check e2262377347246 [[],[.under]] .three = true := by decide
def e2262377347258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2262377347258 : Closed e2262377347258 ∧ code e2262377347258 = 11058470369466 := by decide
theorem cert_e2262377347258 : check e2262377347258 [[],[.under]] .three = true := by decide
def e2262377347630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262377347630 : Closed e2262377347630 ∧ code e2262377347630 = 11058470369838 := by decide
theorem cert_e2262377347630 : check e2262377347630 [[],[.under]] .three = true := by decide
def e2262377347810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262377347810 : Closed e2262377347810 ∧ code e2262377347810 = 11058470370018 := by decide
theorem cert_e2262377347810 : check e2262377347810 [[],[.under]] .three = true := by decide
def e2262377347822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2262377347822 : Closed e2262377347822 ∧ code e2262377347822 = 11058470370030 := by decide
theorem cert_e2262377347822 : check e2262377347822 [[],[.under]] .three = true := by decide
def e2262377347950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2262377347950 : Closed e2262377347950 ∧ code e2262377347950 = 11058470370158 := by decide
theorem cert_e2262377347950 : check e2262377347950 [[],[.under]] .three = true := by decide
def e2262377347958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2262377347958 : Closed e2262377347958 ∧ code e2262377347958 = 11058470370166 := by decide
theorem cert_e2262377347958 : check e2262377347958 [[],[.under]] .three = true := by decide
def e2262377347978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377347978 : Closed e2262377347978 ∧ code e2262377347978 = 11058470370186 := by decide
theorem cert_e2262377347978 : check e2262377347978 [[],[.under]] .three = true := by decide
def e2262377348002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377348002 : Closed e2262377348002 ∧ code e2262377348002 = 11058470370210 := by decide
theorem cert_e2262377348002 : check e2262377348002 [[],[.under]] .three = true := by decide
def e2262377348014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2262377348014 : Closed e2262377348014 ∧ code e2262377348014 = 11058470370222 := by decide
theorem cert_e2262377348014 : check e2262377348014 [[],[.under]] .three = true := by decide
def e2262377348022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2262377348022 : Closed e2262377348022 ∧ code e2262377348022 = 11058470370230 := by decide
theorem cert_e2262377348022 : check e2262377348022 [[],[.under]] .three = true := by decide
def e2262377348026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2262377348026 : Closed e2262377348026 ∧ code e2262377348026 = 11058470370234 := by decide
theorem cert_e2262377348026 : check e2262377348026 [[],[.under]] .three = true := by decide
def e2262377348182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2262377348182 : Closed e2262377348182 ∧ code e2262377348182 = 11058470370390 := by decide
theorem cert_e2262377348182 : check e2262377348182 [[],[.under]] .three = true := by decide
def e2262377348186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2262377348186 : Closed e2262377348186 ∧ code e2262377348186 = 11058470370394 := by decide
theorem cert_e2262377348186 : check e2262377348186 [[],[.under]] .three = true := by decide
def e2262377348374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262377348374 : Closed e2262377348374 ∧ code e2262377348374 = 11058470370582 := by decide
theorem cert_e2262377348374 : check e2262377348374 [[],[.under]] .three = true := by decide
def e2262377348450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262377348450 : Closed e2262377348450 ∧ code e2262377348450 = 11058470370658 := by decide
theorem cert_e2262377348450 : check e2262377348450 [[],[.under]] .three = true := by decide
def e2262377348462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2262377348462 : Closed e2262377348462 ∧ code e2262377348462 = 11058470370670 := by decide
theorem cert_e2262377348462 : check e2262377348462 [[],[.under]] .three = true := by decide
def e2262377348470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2262377348470 : Closed e2262377348470 ∧ code e2262377348470 = 11058470370678 := by decide
theorem cert_e2262377348470 : check e2262377348470 [[],[.under]] .three = true := by decide
def e2262377348490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377348490 : Closed e2262377348490 ∧ code e2262377348490 = 11058470370698 := by decide
theorem cert_e2262377348490 : check e2262377348490 [[],[.under]] .three = true := by decide
def e2262377348514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377348514 : Closed e2262377348514 ∧ code e2262377348514 = 11058470370722 := by decide
theorem cert_e2262377348514 : check e2262377348514 [[],[.under]] .three = true := by decide
def e2262377348526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2262377348526 : Closed e2262377348526 ∧ code e2262377348526 = 11058470370734 := by decide
theorem cert_e2262377348526 : check e2262377348526 [[],[.under]] .three = true := by decide
def e2262377348534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e2262377348534 : Closed e2262377348534 ∧ code e2262377348534 = 11058470370742 := by decide
theorem cert_e2262377348534 : check e2262377348534 [[],[.under]] .three = true := by decide
def e2262377348538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2262377348538 : Closed e2262377348538 ∧ code e2262377348538 = 11058470370746 := by decide
theorem cert_e2262377348538 : check e2262377348538 [[],[.under]] .three = true := by decide
def e2262377348566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2262377348566 : Closed e2262377348566 ∧ code e2262377348566 = 11058470370774 := by decide
theorem cert_e2262377348566 : check e2262377348566 [[],[.under]] .three = true := by decide
def e2262377348570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2262377348570 : Closed e2262377348570 ∧ code e2262377348570 = 11058470370778 := by decide
theorem cert_e2262377348570 : check e2262377348570 [[],[.under]] .three = true := by decide
def e2262377349614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2262377349614 : Closed e2262377349614 ∧ code e2262377349614 = 11058470371822 := by decide
theorem cert_e2262377349614 : check e2262377349614 [[],[.under]] .three = true := by decide
def e2262377349622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2262377349622 : Closed e2262377349622 ∧ code e2262377349622 = 11058470371830 := by decide
theorem cert_e2262377349622 : check e2262377349622 [[],[.under]] .three = true := by decide
def e2262377350382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377350382 : Closed e2262377350382 ∧ code e2262377350382 = 11058470372590 := by decide
theorem cert_e2262377350382 : check e2262377350382 [[],[.under]] .three = true := by decide
def e2262377350390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377350390 : Closed e2262377350390 ∧ code e2262377350390 = 11058470372598 := by decide
theorem cert_e2262377350390 : check e2262377350390 [[],[.under]] .three = true := by decide
def e2262377350942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2262377350942 : Closed e2262377350942 ∧ code e2262377350942 = 11058470373150 := by decide
theorem cert_e2262377350942 : check e2262377350942 [[],[.under]] .three = true := by decide
def e2262377351054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2262377351054 : Closed e2262377351054 ∧ code e2262377351054 = 11058470373262 := by decide
theorem cert_e2262377351054 : check e2262377351054 [[],[.under]] .three = true := by decide
def e2262377352750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2262377352750 : Closed e2262377352750 ∧ code e2262377352750 = 11058470374958 := by decide
theorem cert_e2262377352750 : check e2262377352750 [[],[.under]] .three = true := by decide
def e2262377352930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2262377352930 : Closed e2262377352930 ∧ code e2262377352930 = 11058470375138 := by decide
theorem cert_e2262377352930 : check e2262377352930 [[],[.under]] .three = true := by decide
def e2262377352942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2262377352942 : Closed e2262377352942 ∧ code e2262377352942 = 11058470375150 := by decide
theorem cert_e2262377352942 : check e2262377352942 [[],[.under]] .three = true := by decide
def e2262377352982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2262377352982 : Closed e2262377352982 ∧ code e2262377352982 = 11058470375190 := by decide
theorem cert_e2262377352982 : check e2262377352982 [[],[.under]] .three = true := by decide
def e2262377353058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2262377353058 : Closed e2262377353058 ∧ code e2262377353058 = 11058470375266 := by decide
theorem cert_e2262377353058 : check e2262377353058 [[],[.under]] .three = true := by decide
def e2262377353070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2262377353070 : Closed e2262377353070 ∧ code e2262377353070 = 11058470375278 := by decide
theorem cert_e2262377353070 : check e2262377353070 [[],[.under]] .three = true := by decide
def e2262377353078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2262377353078 : Closed e2262377353078 ∧ code e2262377353078 = 11058470375286 := by decide
theorem cert_e2262377353078 : check e2262377353078 [[],[.under]] .three = true := by decide
def e2262377355326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2262377355326 : Closed e2262377355326 ∧ code e2262377355326 = 11058470377534 := by decide
theorem cert_e2262377355326 : check e2262377355326 [[],[.under]] .three = true := by decide
def e2262377355746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262377355746 : Closed e2262377355746 ∧ code e2262377355746 = 11058470377954 := by decide
theorem cert_e2262377355746 : check e2262377355746 [[],[.under]] .three = true := by decide
def e2262377355758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2262377355758 : Closed e2262377355758 ∧ code e2262377355758 = 11058470377966 := by decide
theorem cert_e2262377355758 : check e2262377355758 [[],[.under]] .three = true := by decide
def e2262377356318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2262377356318 : Closed e2262377356318 ∧ code e2262377356318 = 11058470378526 := by decide
theorem cert_e2262377356318 : check e2262377356318 [[],[.under]] .three = true := by decide
def e2262377356514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262377356514 : Closed e2262377356514 ∧ code e2262377356514 = 11058470378722 := by decide
theorem cert_e2262377356514 : check e2262377356514 [[],[.under]] .three = true := by decide
def e2262377356526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377356526 : Closed e2262377356526 ∧ code e2262377356526 = 11058470378734 := by decide
theorem cert_e2262377356526 : check e2262377356526 [[],[.under]] .three = true := by decide
def e2262377356534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377356534 : Closed e2262377356534 ∧ code e2262377356534 = 11058470378742 := by decide
theorem cert_e2262377356534 : check e2262377356534 [[],[.under]] .three = true := by decide
def e2262377357550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2262377357550 : Closed e2262377357550 ∧ code e2262377357550 = 11058470379758 := by decide
theorem cert_e2262377357550 : check e2262377357550 [[],[.under]] .three = true := by decide
def e2262377357562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2262377357562 : Closed e2262377357562 ∧ code e2262377357562 = 11058470379770 := by decide
theorem cert_e2262377357562 : check e2262377357562 [[],[.under]] .three = true := by decide
def e2262377357742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2262377357742 : Closed e2262377357742 ∧ code e2262377357742 = 11058470379950 := by decide
theorem cert_e2262377357742 : check e2262377357742 [[],[.under]] .three = true := by decide
def e2262377357934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377357934 : Closed e2262377357934 ∧ code e2262377357934 = 11058470380142 := by decide
theorem cert_e2262377357934 : check e2262377357934 [[],[.under]] .three = true := by decide
def e2262377357946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377357946 : Closed e2262377357946 ∧ code e2262377357946 = 11058470380154 := by decide
theorem cert_e2262377357946 : check e2262377357946 [[],[.under]] .three = true := by decide
def e2262377358110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2262377358110 : Closed e2262377358110 ∧ code e2262377358110 = 11058470380318 := by decide
theorem cert_e2262377358110 : check e2262377358110 [[],[.under]] .three = true := by decide
def e2262377358278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2262377358278 : Closed e2262377358278 ∧ code e2262377358278 = 11058470380486 := by decide
theorem cert_e2262377358278 : check e2262377358278 [[],[.under]] .three = true := by decide
def e2262377358894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2262377358894 : Closed e2262377358894 ∧ code e2262377358894 = 11058470381102 := by decide
theorem cert_e2262377358894 : check e2262377358894 [[],[.under]] .three = true := by decide
def e2262377359074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2262377359074 : Closed e2262377359074 ∧ code e2262377359074 = 11058470381282 := by decide
theorem cert_e2262377359074 : check e2262377359074 [[],[.under]] .three = true := by decide
def e2262377359086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2262377359086 : Closed e2262377359086 ∧ code e2262377359086 = 11058470381294 := by decide
theorem cert_e2262377359086 : check e2262377359086 [[],[.under]] .three = true := by decide
def e2262377359214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2262377359214 : Closed e2262377359214 ∧ code e2262377359214 = 11058470381422 := by decide
theorem cert_e2262377359214 : check e2262377359214 [[],[.under]] .three = true := by decide
def e2262377359222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2262377359222 : Closed e2262377359222 ∧ code e2262377359222 = 11058470381430 := by decide
theorem cert_e2262377359222 : check e2262377359222 [[],[.under]] .three = true := by decide
def e2262377359242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262377359242 : Closed e2262377359242 ∧ code e2262377359242 = 11058470381450 := by decide
theorem cert_e2262377359242 : check e2262377359242 [[],[.under]] .three = true := by decide
def e2262377359266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262377359266 : Closed e2262377359266 ∧ code e2262377359266 = 11058470381474 := by decide
theorem cert_e2262377359266 : check e2262377359266 [[],[.under]] .three = true := by decide
def e2262377359278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2262377359278 : Closed e2262377359278 ∧ code e2262377359278 = 11058470381486 := by decide
theorem cert_e2262377359278 : check e2262377359278 [[],[.under]] .three = true := by decide
def e2262377359286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2262377359286 : Closed e2262377359286 ∧ code e2262377359286 = 11058470381494 := by decide
theorem cert_e2262377359286 : check e2262377359286 [[],[.under]] .three = true := by decide
def e2262377359290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2262377359290 : Closed e2262377359290 ∧ code e2262377359290 = 11058470381498 := by decide
theorem cert_e2262377359290 : check e2262377359290 [[],[.under]] .three = true := by decide
def e2262377359422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2262377359422 : Closed e2262377359422 ∧ code e2262377359422 = 11058470381630 := by decide
theorem cert_e2262377359422 : check e2262377359422 [[],[.under]] .three = true := by decide
def e2262377359842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262377359842 : Closed e2262377359842 ∧ code e2262377359842 = 11058470382050 := by decide
theorem cert_e2262377359842 : check e2262377359842 [[],[.under]] .three = true := by decide
def e2262377359854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2262377359854 : Closed e2262377359854 ∧ code e2262377359854 = 11058470382062 := by decide
theorem cert_e2262377359854 : check e2262377359854 [[],[.under]] .three = true := by decide
def e2262377360622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377360622 : Closed e2262377360622 ∧ code e2262377360622 = 11058470382830 := by decide
theorem cert_e2262377360622 : check e2262377360622 [[],[.under]] .three = true := by decide
def e2262377360630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377360630 : Closed e2262377360630 ∧ code e2262377360630 = 11058470382838 := by decide
theorem cert_e2262377360630 : check e2262377360630 [[],[.under]] .three = true := by decide
def e2262377360910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377360910 : Closed e2262377360910 ∧ code e2262377360910 = 11058470383118 := by decide
theorem cert_e2262377360910 : check e2262377360910 [[],[.under]] .three = true := by decide
def e2262377360922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377360922 : Closed e2262377360922 ∧ code e2262377360922 = 11058470383130 := by decide
theorem cert_e2262377360922 : check e2262377360922 [[],[.under]] .three = true := by decide
end Blc.Floor43
