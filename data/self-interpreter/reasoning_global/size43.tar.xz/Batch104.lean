import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e862315453686 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e862315453686 : Closed e862315453686 ∧ code e862315453686 = 9658408475894 := by decide
theorem cert_e862315453686 : check e862315453686 [] .sourceHead = true := by decide
def e862315454070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e862315454070 : Closed e862315454070 ∧ code e862315454070 = 9658408476278 := by decide
theorem cert_e862315454070 : check e862315454070 [] .sourceHead = true := by decide
def e862315465582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862315465582 : Closed e862315465582 ∧ code e862315465582 = 9658408487790 := by decide
theorem cert_e862315465582 : check e862315465582 [] .sourceHead = true := by decide
def e862315465590 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862315465590 : Closed e862315465590 ∧ code e862315465590 = 9658408487798 := by decide
theorem cert_e862315465590 : check e862315465590 [] .sourceHead = true := by decide
def e862315465646 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862315465646 : Closed e862315465646 ∧ code e862315465646 = 9658408487854 := by decide
theorem cert_e862315465646 : check e862315465646 [] .sourceHead = true := by decide
def e862315465658 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862315465658 : Closed e862315465658 ∧ code e862315465658 = 9658408487866 := by decide
theorem cert_e862315465658 : check e862315465658 [] .sourceHead = true := by decide
def e862315465686 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862315465686 : Closed e862315465686 ∧ code e862315465686 = 9658408487894 := by decide
theorem cert_e862315465686 : check e862315465686 [] .sourceHead = true := by decide
def e862315465690 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862315465690 : Closed e862315465690 ∧ code e862315465690 = 9658408487898 := by decide
theorem cert_e862315465690 : check e862315465690 [] .sourceHead = true := by decide
def e862315465966 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862315465966 : Closed e862315465966 ∧ code e862315465966 = 9658408488174 := by decide
theorem cert_e862315465966 : check e862315465966 [] .sourceHead = true := by decide
def e862315465974 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862315465974 : Closed e862315465974 ∧ code e862315465974 = 9658408488182 := by decide
theorem cert_e862315465974 : check e862315465974 [] .sourceHead = true := by decide
def e862315466350 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862315466350 : Closed e862315466350 ∧ code e862315466350 = 9658408488558 := by decide
theorem cert_e862315466350 : check e862315466350 [] .sourceHead = true := by decide
def e862315466362 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862315466362 : Closed e862315466362 ∧ code e862315466362 = 9658408488570 := by decide
theorem cert_e862315466362 : check e862315466362 [] .sourceHead = true := by decide
def e862315466550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862315466550 : Closed e862315466550 ∧ code e862315466550 = 9658408488758 := by decide
theorem cert_e862315466550 : check e862315466550 [] .sourceHead = true := by decide
def e862315466554 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862315466554 : Closed e862315466554 ∧ code e862315466554 = 9658408488762 := by decide
theorem cert_e862315466554 : check e862315466554 [] .sourceHead = true := by decide
def e862315472310 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e862315472310 : Closed e862315472310 ∧ code e862315472310 = 9658408494518 := by decide
theorem cert_e862315472310 : check e862315472310 [] .sourceHead = true := by decide
def e862315472342 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e862315472342 : Closed e862315472342 ∧ code e862315472342 = 9658408494550 := by decide
theorem cert_e862315472342 : check e862315472342 [] .sourceHead = true := by decide
def e862315472346 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e862315472346 : Closed e862315472346 ∧ code e862315472346 = 9658408494554 := by decide
theorem cert_e862315472346 : check e862315472346 [] .sourceHead = true := by decide
def e862315472502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e862315472502 : Closed e862315472502 ∧ code e862315472502 = 9658408494710 := by decide
theorem cert_e862315472502 : check e862315472502 [] .sourceHead = true := by decide
def e862315472694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e862315472694 : Closed e862315472694 ∧ code e862315472694 = 9658408494902 := by decide
theorem cert_e862315472694 : check e862315472694 [] .sourceHead = true := by decide
def e862315472698 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e862315472698 : Closed e862315472698 ∧ code e862315472698 = 9658408494906 := by decide
theorem cert_e862315472698 : check e862315472698 [] .sourceHead = true := by decide
def e862315809646 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862315809646 : Closed e862315809646 ∧ code e862315809646 = 9658408831854 := by decide
theorem cert_e862315809646 : check e862315809646 [] .sourceHead = true := by decide
def e862315809654 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862315809654 : Closed e862315809654 ∧ code e862315809654 = 9658408831862 := by decide
theorem cert_e862315809654 : check e862315809654 [] .sourceHead = true := by decide
def e862315809710 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862315809710 : Closed e862315809710 ∧ code e862315809710 = 9658408831918 := by decide
theorem cert_e862315809710 : check e862315809710 [] .sourceHead = true := by decide
def e862315809722 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862315809722 : Closed e862315809722 ∧ code e862315809722 = 9658408831930 := by decide
theorem cert_e862315809722 : check e862315809722 [] .sourceHead = true := by decide
def e862315809750 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862315809750 : Closed e862315809750 ∧ code e862315809750 = 9658408831958 := by decide
theorem cert_e862315809750 : check e862315809750 [] .sourceHead = true := by decide
def e862315809754 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862315809754 : Closed e862315809754 ∧ code e862315809754 = 9658408831962 := by decide
theorem cert_e862315809754 : check e862315809754 [] .sourceHead = true := by decide
def e862315810030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862315810030 : Closed e862315810030 ∧ code e862315810030 = 9658408832238 := by decide
theorem cert_e862315810030 : check e862315810030 [] .sourceHead = true := by decide
def e862315810038 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862315810038 : Closed e862315810038 ∧ code e862315810038 = 9658408832246 := by decide
theorem cert_e862315810038 : check e862315810038 [] .sourceHead = true := by decide
def e862315810414 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862315810414 : Closed e862315810414 ∧ code e862315810414 = 9658408832622 := by decide
theorem cert_e862315810414 : check e862315810414 [] .sourceHead = true := by decide
def e862315810426 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862315810426 : Closed e862315810426 ∧ code e862315810426 = 9658408832634 := by decide
theorem cert_e862315810426 : check e862315810426 [] .sourceHead = true := by decide
def e862315810614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862315810614 : Closed e862315810614 ∧ code e862315810614 = 9658408832822 := by decide
theorem cert_e862315810614 : check e862315810614 [] .sourceHead = true := by decide
def e862315810618 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862315810618 : Closed e862315810618 ∧ code e862315810618 = 9658408832826 := by decide
theorem cert_e862315810618 : check e862315810618 [] .sourceHead = true := by decide
def e862416760346 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416760346 : Closed e862416760346 ∧ code e862416760346 = 9658509782554 := by decide
theorem cert_e862416760346 : check e862416760346 [] .sourceHead = true := by decide
def e862416762394 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416762394 : Closed e862416762394 ∧ code e862416762394 = 9658509784602 := by decide
theorem cert_e862416762394 : check e862416762394 [] .sourceHead = true := by decide
def e862416776730 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416776730 : Closed e862416776730 ∧ code e862416776730 = 9658509798938 := by decide
theorem cert_e862416776730 : check e862416776730 [] .sourceHead = true := by decide
def e862416779802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416779802 : Closed e862416779802 ∧ code e862416779802 = 9658509802010 := by decide
theorem cert_e862416779802 : check e862416779802 [] .sourceHead = true := by decide
def e862416786970 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416786970 : Closed e862416786970 ∧ code e862416786970 = 9658509809178 := by decide
theorem cert_e862416786970 : check e862416786970 [] .sourceHead = true := by decide
def e862416787994 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416787994 : Closed e862416787994 ∧ code e862416787994 = 9658509810202 := by decide
theorem cert_e862416787994 : check e862416787994 [] .sourceHead = true := by decide
def e862416858650 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416858650 : Closed e862416858650 ∧ code e862416858650 = 9658509880858 := by decide
theorem cert_e862416858650 : check e862416858650 [] .sourceHead = true := by decide
def e862416860698 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416860698 : Closed e862416860698 ∧ code e862416860698 = 9658509882906 := by decide
theorem cert_e862416860698 : check e862416860698 [] .sourceHead = true := by decide
def e862416956954 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416956954 : Closed e862416956954 ∧ code e862416956954 = 9658509979162 := by decide
theorem cert_e862416956954 : check e862416956954 [] .sourceHead = true := by decide
def e862416960026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862416960026 : Closed e862416960026 ∧ code e862416960026 = 9658509982234 := by decide
theorem cert_e862416960026 : check e862416960026 [] .sourceHead = true := by decide
def e862417008154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862417008154 : Closed e862417008154 ∧ code e862417008154 = 9658510030362 := by decide
theorem cert_e862417008154 : check e862417008154 [] .sourceHead = true := by decide
def e862417009178 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862417009178 : Closed e862417009178 ∧ code e862417009178 = 9658510031386 := by decide
theorem cert_e862417009178 : check e862417009178 [] .sourceHead = true := by decide
def e862432832878 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e862432832878 : Closed e862432832878 ∧ code e862432832878 = 9658525855086 := by decide
theorem cert_e862432832878 : check e862432832878 [] .sourceHead = true := by decide
def e862432832886 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e862432832886 : Closed e862432832886 ∧ code e862432832886 = 9658525855094 := by decide
theorem cert_e862432832886 : check e862432832886 [] .sourceHead = true := by decide
def e862432832942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e862432832942 : Closed e862432832942 ∧ code e862432832942 = 9658525855150 := by decide
theorem cert_e862432832942 : check e862432832942 [] .sourceHead = true := by decide
def e862432832954 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e862432832954 : Closed e862432832954 ∧ code e862432832954 = 9658525855162 := by decide
theorem cert_e862432832954 : check e862432832954 [] .sourceHead = true := by decide
def e862432832982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e862432832982 : Closed e862432832982 ∧ code e862432832982 = 9658525855190 := by decide
theorem cert_e862432832982 : check e862432832982 [] .sourceHead = true := by decide
def e862432832986 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e862432832986 : Closed e862432832986 ∧ code e862432832986 = 9658525855194 := by decide
theorem cert_e862432832986 : check e862432832986 [] .sourceHead = true := by decide
def e862432833198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e862432833198 : Closed e862432833198 ∧ code e862432833198 = 9658525855406 := by decide
theorem cert_e862432833198 : check e862432833198 [] .sourceHead = true := by decide
def e862432833210 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e862432833210 : Closed e862432833210 ∧ code e862432833210 = 9658525855418 := by decide
theorem cert_e862432833210 : check e862432833210 [] .sourceHead = true := by decide
def e862432833258 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e862432833258 : Closed e862432833258 ∧ code e862432833258 = 9658525855466 := by decide
theorem cert_e862432833258 : check e862432833258 [] .sourceHead = true := by decide
def e862432833366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e862432833366 : Closed e862432833366 ∧ code e862432833366 = 9658525855574 := by decide
theorem cert_e862432833366 : check e862432833366 [] .sourceHead = true := by decide
def e862432833370 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e862432833370 : Closed e862432833370 ∧ code e862432833370 = 9658525855578 := by decide
theorem cert_e862432833370 : check e862432833370 [] .sourceHead = true := by decide
def e862432833386 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e862432833386 : Closed e862432833386 ∧ code e862432833386 = 9658525855594 := by decide
theorem cert_e862432833386 : check e862432833386 [] .sourceHead = true := by decide
def e862432834414 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e862432834414 : Closed e862432834414 ∧ code e862432834414 = 9658525856622 := by decide
theorem cert_e862432834414 : check e862432834414 [] .sourceHead = true := by decide
def e862432834422 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e862432834422 : Closed e862432834422 ∧ code e862432834422 = 9658525856630 := by decide
theorem cert_e862432834422 : check e862432834422 [] .sourceHead = true := by decide
def e862432834478 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e862432834478 : Closed e862432834478 ∧ code e862432834478 = 9658525856686 := by decide
theorem cert_e862432834478 : check e862432834478 [] .sourceHead = true := by decide
def e862432834490 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e862432834490 : Closed e862432834490 ∧ code e862432834490 = 9658525856698 := by decide
theorem cert_e862432834490 : check e862432834490 [] .sourceHead = true := by decide
def e862432834518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e862432834518 : Closed e862432834518 ∧ code e862432834518 = 9658525856726 := by decide
theorem cert_e862432834518 : check e862432834518 [] .sourceHead = true := by decide
def e862432834522 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e862432834522 : Closed e862432834522 ∧ code e862432834522 = 9658525856730 := by decide
theorem cert_e862432834522 : check e862432834522 [] .sourceHead = true := by decide
def e862432834798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e862432834798 : Closed e862432834798 ∧ code e862432834798 = 9658525857006 := by decide
theorem cert_e862432834798 : check e862432834798 [] .sourceHead = true := by decide
def e862432834806 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e862432834806 : Closed e862432834806 ∧ code e862432834806 = 9658525857014 := by decide
theorem cert_e862432834806 : check e862432834806 [] .sourceHead = true := by decide
def e862432835182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e862432835182 : Closed e862432835182 ∧ code e862432835182 = 9658525857390 := by decide
theorem cert_e862432835182 : check e862432835182 [] .sourceHead = true := by decide
def e862432835194 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e862432835194 : Closed e862432835194 ∧ code e862432835194 = 9658525857402 := by decide
theorem cert_e862432835194 : check e862432835194 [] .sourceHead = true := by decide
def e862432835382 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e862432835382 : Closed e862432835382 ∧ code e862432835382 = 9658525857590 := by decide
theorem cert_e862432835382 : check e862432835382 [] .sourceHead = true := by decide
def e862432835386 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e862432835386 : Closed e862432835386 ∧ code e862432835386 = 9658525857594 := by decide
theorem cert_e862432835386 : check e862432835386 [] .sourceHead = true := by decide
def e862432836014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e862432836014 : Closed e862432836014 ∧ code e862432836014 = 9658525858222 := by decide
theorem cert_e862432836014 : check e862432836014 [] .sourceHead = true := by decide
def e862432836026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e862432836026 : Closed e862432836026 ∧ code e862432836026 = 9658525858234 := by decide
theorem cert_e862432836026 : check e862432836026 [] .sourceHead = true := by decide
def e862432836074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e862432836074 : Closed e862432836074 ∧ code e862432836074 = 9658525858282 := by decide
theorem cert_e862432836074 : check e862432836074 [] .sourceHead = true := by decide
def e862432836206 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e862432836206 : Closed e862432836206 ∧ code e862432836206 = 9658525858414 := by decide
theorem cert_e862432836206 : check e862432836206 [] .sourceHead = true := by decide
def e862432836218 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e862432836218 : Closed e862432836218 ∧ code e862432836218 = 9658525858426 := by decide
theorem cert_e862432836218 : check e862432836218 [] .sourceHead = true := by decide
def e862432836506 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862432836506 : Closed e862432836506 ∧ code e862432836506 = 9658525858714 := by decide
theorem cert_e862432836506 : check e862432836506 [] .sourceHead = true := by decide
def e862432836822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e862432836822 : Closed e862432836822 ∧ code e862432836822 = 9658525859030 := by decide
theorem cert_e862432836822 : check e862432836822 [] .sourceHead = true := by decide
def e862432836826 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e862432836826 : Closed e862432836826 ∧ code e862432836826 = 9658525859034 := by decide
theorem cert_e862432836826 : check e862432836826 [] .sourceHead = true := by decide
def e862432836842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e862432836842 : Closed e862432836842 ∧ code e862432836842 = 9658525859050 := by decide
theorem cert_e862432836842 : check e862432836842 [] .sourceHead = true := by decide
def e862432836918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e862432836918 : Closed e862432836918 ∧ code e862432836918 = 9658525859126 := by decide
theorem cert_e862432836918 : check e862432836918 [] .sourceHead = true := by decide
def e862432836922 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e862432836922 : Closed e862432836922 ∧ code e862432836922 = 9658525859130 := by decide
theorem cert_e862432836922 : check e862432836922 [] .sourceHead = true := by decide
def e862432837018 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e862432837018 : Closed e862432837018 ∧ code e862432837018 = 9658525859226 := by decide
theorem cert_e862432837018 : check e862432837018 [] .sourceHead = true := by decide
def e862432840558 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862432840558 : Closed e862432840558 ∧ code e862432840558 = 9658525862766 := by decide
theorem cert_e862432840558 : check e862432840558 [] .sourceHead = true := by decide
def e862432840566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862432840566 : Closed e862432840566 ∧ code e862432840566 = 9658525862774 := by decide
theorem cert_e862432840566 : check e862432840566 [] .sourceHead = true := by decide
def e862432840622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862432840622 : Closed e862432840622 ∧ code e862432840622 = 9658525862830 := by decide
theorem cert_e862432840622 : check e862432840622 [] .sourceHead = true := by decide
def e862432840634 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862432840634 : Closed e862432840634 ∧ code e862432840634 = 9658525862842 := by decide
theorem cert_e862432840634 : check e862432840634 [] .sourceHead = true := by decide
def e862432840662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862432840662 : Closed e862432840662 ∧ code e862432840662 = 9658525862870 := by decide
theorem cert_e862432840662 : check e862432840662 [] .sourceHead = true := by decide
def e862432840666 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862432840666 : Closed e862432840666 ∧ code e862432840666 = 9658525862874 := by decide
theorem cert_e862432840666 : check e862432840666 [] .sourceHead = true := by decide
def e862432840942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862432840942 : Closed e862432840942 ∧ code e862432840942 = 9658525863150 := by decide
theorem cert_e862432840942 : check e862432840942 [] .sourceHead = true := by decide
def e862432840950 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862432840950 : Closed e862432840950 ∧ code e862432840950 = 9658525863158 := by decide
theorem cert_e862432840950 : check e862432840950 [] .sourceHead = true := by decide
def e862432841326 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862432841326 : Closed e862432841326 ∧ code e862432841326 = 9658525863534 := by decide
theorem cert_e862432841326 : check e862432841326 [] .sourceHead = true := by decide
def e862432841338 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862432841338 : Closed e862432841338 ∧ code e862432841338 = 9658525863546 := by decide
theorem cert_e862432841338 : check e862432841338 [] .sourceHead = true := by decide
def e862432841526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862432841526 : Closed e862432841526 ∧ code e862432841526 = 9658525863734 := by decide
theorem cert_e862432841526 : check e862432841526 [] .sourceHead = true := by decide
def e862432841530 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862432841530 : Closed e862432841530 ∧ code e862432841530 = 9658525863738 := by decide
theorem cert_e862432841530 : check e862432841530 [] .sourceHead = true := by decide
def e862432847278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e862432847278 : Closed e862432847278 ∧ code e862432847278 = 9658525869486 := by decide
theorem cert_e862432847278 : check e862432847278 [] .sourceHead = true := by decide
def e862432847290 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e862432847290 : Closed e862432847290 ∧ code e862432847290 = 9658525869498 := by decide
theorem cert_e862432847290 : check e862432847290 [] .sourceHead = true := by decide
def e862432847338 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e862432847338 : Closed e862432847338 ∧ code e862432847338 = 9658525869546 := by decide
theorem cert_e862432847338 : check e862432847338 [] .sourceHead = true := by decide
def e862432847470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e862432847470 : Closed e862432847470 ∧ code e862432847470 = 9658525869678 := by decide
theorem cert_e862432847470 : check e862432847470 [] .sourceHead = true := by decide
def e862432847482 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e862432847482 : Closed e862432847482 ∧ code e862432847482 = 9658525869690 := by decide
theorem cert_e862432847482 : check e862432847482 [] .sourceHead = true := by decide
def e862432847770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e862432847770 : Closed e862432847770 ∧ code e862432847770 = 9658525869978 := by decide
theorem cert_e862432847770 : check e862432847770 [] .sourceHead = true := by decide
def e862432850646 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e862432850646 : Closed e862432850646 ∧ code e862432850646 = 9658525872854 := by decide
theorem cert_e862432850646 : check e862432850646 [] .sourceHead = true := by decide
def e862432850650 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e862432850650 : Closed e862432850650 ∧ code e862432850650 = 9658525872858 := by decide
theorem cert_e862432850650 : check e862432850650 [] .sourceHead = true := by decide
def e862432850666 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e862432850666 : Closed e862432850666 ∧ code e862432850666 = 9658525872874 := by decide
theorem cert_e862432850666 : check e862432850666 [] .sourceHead = true := by decide
def e862432850742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e862432850742 : Closed e862432850742 ∧ code e862432850742 = 9658525872950 := by decide
theorem cert_e862432850742 : check e862432850742 [] .sourceHead = true := by decide
def e862432850746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e862432850746 : Closed e862432850746 ∧ code e862432850746 = 9658525872954 := by decide
theorem cert_e862432850746 : check e862432850746 [] .sourceHead = true := by decide
def e862432850842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e862432850842 : Closed e862432850842 ∧ code e862432850842 = 9658525873050 := by decide
theorem cert_e862432850842 : check e862432850842 [] .sourceHead = true := by decide
def e862432988014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862432988014 : Closed e862432988014 ∧ code e862432988014 = 9658526010222 := by decide
theorem cert_e862432988014 : check e862432988014 [] .sourceHead = true := by decide
def e862432988022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862432988022 : Closed e862432988022 ∧ code e862432988022 = 9658526010230 := by decide
theorem cert_e862432988022 : check e862432988022 [] .sourceHead = true := by decide
def e862432988078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862432988078 : Closed e862432988078 ∧ code e862432988078 = 9658526010286 := by decide
theorem cert_e862432988078 : check e862432988078 [] .sourceHead = true := by decide
def e862432988090 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862432988090 : Closed e862432988090 ∧ code e862432988090 = 9658526010298 := by decide
theorem cert_e862432988090 : check e862432988090 [] .sourceHead = true := by decide
def e862432988118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862432988118 : Closed e862432988118 ∧ code e862432988118 = 9658526010326 := by decide
theorem cert_e862432988118 : check e862432988118 [] .sourceHead = true := by decide
def e862432988122 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862432988122 : Closed e862432988122 ∧ code e862432988122 = 9658526010330 := by decide
theorem cert_e862432988122 : check e862432988122 [] .sourceHead = true := by decide
def e862432988398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862432988398 : Closed e862432988398 ∧ code e862432988398 = 9658526010606 := by decide
theorem cert_e862432988398 : check e862432988398 [] .sourceHead = true := by decide
def e862432988406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862432988406 : Closed e862432988406 ∧ code e862432988406 = 9658526010614 := by decide
theorem cert_e862432988406 : check e862432988406 [] .sourceHead = true := by decide
def e862432988782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862432988782 : Closed e862432988782 ∧ code e862432988782 = 9658526010990 := by decide
theorem cert_e862432988782 : check e862432988782 [] .sourceHead = true := by decide
def e862432988794 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862432988794 : Closed e862432988794 ∧ code e862432988794 = 9658526011002 := by decide
theorem cert_e862432988794 : check e862432988794 [] .sourceHead = true := by decide
def e862432988982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862432988982 : Closed e862432988982 ∧ code e862432988982 = 9658526011190 := by decide
theorem cert_e862432988982 : check e862432988982 [] .sourceHead = true := by decide
def e862432988986 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862432988986 : Closed e862432988986 ∧ code e862432988986 = 9658526011194 := by decide
theorem cert_e862432988986 : check e862432988986 [] .sourceHead = true := by decide
def e862433577838 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862433577838 : Closed e862433577838 ∧ code e862433577838 = 9658526600046 := by decide
theorem cert_e862433577838 : check e862433577838 [] .sourceHead = true := by decide
def e862433577846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862433577846 : Closed e862433577846 ∧ code e862433577846 = 9658526600054 := by decide
theorem cert_e862433577846 : check e862433577846 [] .sourceHead = true := by decide
def e862433577902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862433577902 : Closed e862433577902 ∧ code e862433577902 = 9658526600110 := by decide
theorem cert_e862433577902 : check e862433577902 [] .sourceHead = true := by decide
def e862433577914 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862433577914 : Closed e862433577914 ∧ code e862433577914 = 9658526600122 := by decide
theorem cert_e862433577914 : check e862433577914 [] .sourceHead = true := by decide
def e862433577942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862433577942 : Closed e862433577942 ∧ code e862433577942 = 9658526600150 := by decide
theorem cert_e862433577942 : check e862433577942 [] .sourceHead = true := by decide
def e862433577946 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862433577946 : Closed e862433577946 ∧ code e862433577946 = 9658526600154 := by decide
theorem cert_e862433577946 : check e862433577946 [] .sourceHead = true := by decide
def e862433578222 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862433578222 : Closed e862433578222 ∧ code e862433578222 = 9658526600430 := by decide
theorem cert_e862433578222 : check e862433578222 [] .sourceHead = true := by decide
def e862433578230 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862433578230 : Closed e862433578230 ∧ code e862433578230 = 9658526600438 := by decide
theorem cert_e862433578230 : check e862433578230 [] .sourceHead = true := by decide
def e862433578606 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862433578606 : Closed e862433578606 ∧ code e862433578606 = 9658526600814 := by decide
theorem cert_e862433578606 : check e862433578606 [] .sourceHead = true := by decide
def e862433578618 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862433578618 : Closed e862433578618 ∧ code e862433578618 = 9658526600826 := by decide
theorem cert_e862433578618 : check e862433578618 [] .sourceHead = true := by decide
def e862433578806 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862433578806 : Closed e862433578806 ∧ code e862433578806 = 9658526601014 := by decide
theorem cert_e862433578806 : check e862433578806 [] .sourceHead = true := by decide
def e862433578810 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862433578810 : Closed e862433578810 ∧ code e862433578810 = 9658526601018 := by decide
theorem cert_e862433578810 : check e862433578810 [] .sourceHead = true := by decide
def e862483164526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e862483164526 : Closed e862483164526 ∧ code e862483164526 = 9658576186734 := by decide
theorem cert_e862483164526 : check e862483164526 [] .sourceHead = true := by decide
def e862483164534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e862483164534 : Closed e862483164534 ∧ code e862483164534 = 9658576186742 := by decide
theorem cert_e862483164534 : check e862483164534 [] .sourceHead = true := by decide
def e862483164590 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e862483164590 : Closed e862483164590 ∧ code e862483164590 = 9658576186798 := by decide
theorem cert_e862483164590 : check e862483164590 [] .sourceHead = true := by decide
def e862483164602 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e862483164602 : Closed e862483164602 ∧ code e862483164602 = 9658576186810 := by decide
theorem cert_e862483164602 : check e862483164602 [] .sourceHead = true := by decide
def e862483164630 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e862483164630 : Closed e862483164630 ∧ code e862483164630 = 9658576186838 := by decide
theorem cert_e862483164630 : check e862483164630 [] .sourceHead = true := by decide
def e862483164634 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e862483164634 : Closed e862483164634 ∧ code e862483164634 = 9658576186842 := by decide
theorem cert_e862483164634 : check e862483164634 [] .sourceHead = true := by decide
def e862483164846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e862483164846 : Closed e862483164846 ∧ code e862483164846 = 9658576187054 := by decide
theorem cert_e862483164846 : check e862483164846 [] .sourceHead = true := by decide
def e862483164858 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e862483164858 : Closed e862483164858 ∧ code e862483164858 = 9658576187066 := by decide
theorem cert_e862483164858 : check e862483164858 [] .sourceHead = true := by decide
def e862483164906 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e862483164906 : Closed e862483164906 ∧ code e862483164906 = 9658576187114 := by decide
theorem cert_e862483164906 : check e862483164906 [] .sourceHead = true := by decide
def e862483165014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e862483165014 : Closed e862483165014 ∧ code e862483165014 = 9658576187222 := by decide
theorem cert_e862483165014 : check e862483165014 [] .sourceHead = true := by decide
def e862483165018 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e862483165018 : Closed e862483165018 ∧ code e862483165018 = 9658576187226 := by decide
theorem cert_e862483165018 : check e862483165018 [] .sourceHead = true := by decide
def e862483165034 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e862483165034 : Closed e862483165034 ∧ code e862483165034 = 9658576187242 := by decide
theorem cert_e862483165034 : check e862483165034 [] .sourceHead = true := by decide
def e862483166062 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e862483166062 : Closed e862483166062 ∧ code e862483166062 = 9658576188270 := by decide
theorem cert_e862483166062 : check e862483166062 [] .sourceHead = true := by decide
def e862483166070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e862483166070 : Closed e862483166070 ∧ code e862483166070 = 9658576188278 := by decide
theorem cert_e862483166070 : check e862483166070 [] .sourceHead = true := by decide
def e862483166126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e862483166126 : Closed e862483166126 ∧ code e862483166126 = 9658576188334 := by decide
theorem cert_e862483166126 : check e862483166126 [] .sourceHead = true := by decide
def e862483166138 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e862483166138 : Closed e862483166138 ∧ code e862483166138 = 9658576188346 := by decide
theorem cert_e862483166138 : check e862483166138 [] .sourceHead = true := by decide
def e862483166166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e862483166166 : Closed e862483166166 ∧ code e862483166166 = 9658576188374 := by decide
theorem cert_e862483166166 : check e862483166166 [] .sourceHead = true := by decide
def e862483166170 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e862483166170 : Closed e862483166170 ∧ code e862483166170 = 9658576188378 := by decide
theorem cert_e862483166170 : check e862483166170 [] .sourceHead = true := by decide
def e862483166446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862483166446 : Closed e862483166446 ∧ code e862483166446 = 9658576188654 := by decide
theorem cert_e862483166446 : check e862483166446 [] .sourceHead = true := by decide
def e862483166454 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862483166454 : Closed e862483166454 ∧ code e862483166454 = 9658576188662 := by decide
theorem cert_e862483166454 : check e862483166454 [] .sourceHead = true := by decide
def e862483166830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862483166830 : Closed e862483166830 ∧ code e862483166830 = 9658576189038 := by decide
theorem cert_e862483166830 : check e862483166830 [] .sourceHead = true := by decide
def e862483166842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862483166842 : Closed e862483166842 ∧ code e862483166842 = 9658576189050 := by decide
theorem cert_e862483166842 : check e862483166842 [] .sourceHead = true := by decide
def e862483167030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862483167030 : Closed e862483167030 ∧ code e862483167030 = 9658576189238 := by decide
theorem cert_e862483167030 : check e862483167030 [] .sourceHead = true := by decide
def e862483167034 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862483167034 : Closed e862483167034 ∧ code e862483167034 = 9658576189242 := by decide
theorem cert_e862483167034 : check e862483167034 [] .sourceHead = true := by decide
def e862483167662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e862483167662 : Closed e862483167662 ∧ code e862483167662 = 9658576189870 := by decide
theorem cert_e862483167662 : check e862483167662 [] .sourceHead = true := by decide
def e862483167674 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e862483167674 : Closed e862483167674 ∧ code e862483167674 = 9658576189882 := by decide
theorem cert_e862483167674 : check e862483167674 [] .sourceHead = true := by decide
def e862483167722 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e862483167722 : Closed e862483167722 ∧ code e862483167722 = 9658576189930 := by decide
theorem cert_e862483167722 : check e862483167722 [] .sourceHead = true := by decide
def e862483167854 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862483167854 : Closed e862483167854 ∧ code e862483167854 = 9658576190062 := by decide
theorem cert_e862483167854 : check e862483167854 [] .sourceHead = true := by decide
def e862483167866 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862483167866 : Closed e862483167866 ∧ code e862483167866 = 9658576190074 := by decide
theorem cert_e862483167866 : check e862483167866 [] .sourceHead = true := by decide
def e862483168154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862483168154 : Closed e862483168154 ∧ code e862483168154 = 9658576190362 := by decide
theorem cert_e862483168154 : check e862483168154 [] .sourceHead = true := by decide
def e862483168470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e862483168470 : Closed e862483168470 ∧ code e862483168470 = 9658576190678 := by decide
theorem cert_e862483168470 : check e862483168470 [] .sourceHead = true := by decide
def e862483168474 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e862483168474 : Closed e862483168474 ∧ code e862483168474 = 9658576190682 := by decide
theorem cert_e862483168474 : check e862483168474 [] .sourceHead = true := by decide
end Blc.Floor43
