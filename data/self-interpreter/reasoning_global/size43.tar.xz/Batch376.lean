import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364454106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))))
theorem wire_e2422364454106 : Closed e2422364454106 ∧ code e2422364454106 = 11218457476314 := by decide
theorem cert_e2422364454106 : check e2422364454106 [[],[]] .smaller = true := by decide
def e2422364454122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))))
theorem wire_e2422364454122 : Closed e2422364454122 ∧ code e2422364454122 = 11218457476330 := by decide
theorem cert_e2422364454122 : check e2422364454122 [[],[]] .smaller = true := by decide
def e2422364454334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 4))))))))
theorem wire_e2422364454334 : Closed e2422364454334 ∧ code e2422364454334 = 11218457476542 := by decide
theorem cert_e2422364454334 : check e2422364454334 [[],[]] .three = true := by decide
def e2422364454366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 3))))))))
theorem wire_e2422364454366 : Closed e2422364454366 ∧ code e2422364454366 = 11218457476574 := by decide
theorem cert_e2422364454366 : check e2422364454366 [[],[]] .smaller = true := by decide
def e2422364454382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 2))))))))
theorem wire_e2422364454382 : Closed e2422364454382 ∧ code e2422364454382 = 11218457476590 := by decide
theorem cert_e2422364454382 : check e2422364454382 [[],[]] .smaller = true := by decide
def e2422364454390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 4)))) (.var 1))))))))
theorem wire_e2422364454390 : Closed e2422364454390 ∧ code e2422364454390 = 11218457476598 := by decide
theorem cert_e2422364454390 : check e2422364454390 [[],[]] .smaller = true := by decide
def e2422364454394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 5)))) (.var 0))))))))
theorem wire_e2422364454394 : Closed e2422364454394 ∧ code e2422364454394 = 11218457476602 := by decide
theorem cert_e2422364454394 : check e2422364454394 [[],[]] .three = true := by decide
def e2422364454622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 3))))))))
theorem wire_e2422364454622 : Closed e2422364454622 ∧ code e2422364454622 = 11218457476830 := by decide
theorem cert_e2422364454622 : check e2422364454622 [[],[]] .smaller = true := by decide
def e2422364454638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 2))))))))
theorem wire_e2422364454638 : Closed e2422364454638 ∧ code e2422364454638 = 11218457476846 := by decide
theorem cert_e2422364454638 : check e2422364454638 [[],[]] .smaller = true := by decide
def e2422364454646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 1))))))))
theorem wire_e2422364454646 : Closed e2422364454646 ∧ code e2422364454646 = 11218457476854 := by decide
theorem cert_e2422364454646 : check e2422364454646 [[],[]] .smaller = true := by decide
def e2422364454650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 4)))) (.var 0))))))))
theorem wire_e2422364454650 : Closed e2422364454650 ∧ code e2422364454650 = 11218457476858 := by decide
theorem cert_e2422364454650 : check e2422364454650 [[],[]] .smaller = true := by decide
def e2422364454766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 1)))) (.var 2))))))))
theorem wire_e2422364454766 : Closed e2422364454766 ∧ code e2422364454766 = 11218457476974 := by decide
theorem cert_e2422364454766 : check e2422364454766 [[],[]] .smaller = true := by decide
def e2422364454774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 2)))) (.var 1))))))))
theorem wire_e2422364454774 : Closed e2422364454774 ∧ code e2422364454774 = 11218457476982 := by decide
theorem cert_e2422364454774 : check e2422364454774 [[],[]] .smaller = true := by decide
def e2422364454778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 4) (.var 3)))) (.var 0))))))))
theorem wire_e2422364454778 : Closed e2422364454778 ∧ code e2422364454778 = 11218457476986 := by decide
theorem cert_e2422364454778 : check e2422364454778 [[],[]] .smaller = true := by decide
def e2422364454838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 5) (.var 1)))) (.var 1))))))))
theorem wire_e2422364454838 : Closed e2422364454838 ∧ code e2422364454838 = 11218457477046 := by decide
theorem cert_e2422364454838 : check e2422364454838 [[],[]] .three = true := by decide
def e2422364454842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 5) (.var 2)))) (.var 0))))))))
theorem wire_e2422364454842 : Closed e2422364454842 ∧ code e2422364454842 = 11218457477050 := by decide
theorem cert_e2422364454842 : check e2422364454842 [[],[]] .three = true := by decide
def e2422364457838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422364457838 : Closed e2422364457838 ∧ code e2422364457838 = 11218457480046 := by decide
theorem cert_e2422364457838 : check e2422364457838 [[],[]] .smaller = true := by decide
def e2422364457846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422364457846 : Closed e2422364457846 ∧ code e2422364457846 = 11218457480054 := by decide
theorem cert_e2422364457846 : check e2422364457846 [[],[]] .smaller = true := by decide
def e2422364457902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422364457902 : Closed e2422364457902 ∧ code e2422364457902 = 11218457480110 := by decide
theorem cert_e2422364457902 : check e2422364457902 [[],[]] .smaller = true := by decide
def e2422364457914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422364457914 : Closed e2422364457914 ∧ code e2422364457914 = 11218457480122 := by decide
theorem cert_e2422364457914 : check e2422364457914 [[],[]] .smaller = true := by decide
def e2422364457942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422364457942 : Closed e2422364457942 ∧ code e2422364457942 = 11218457480150 := by decide
theorem cert_e2422364457942 : check e2422364457942 [[],[]] .smaller = true := by decide
def e2422364457946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422364457946 : Closed e2422364457946 ∧ code e2422364457946 = 11218457480154 := by decide
theorem cert_e2422364457946 : check e2422364457946 [[],[]] .smaller = true := by decide
def e2422364458222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364458222 : Closed e2422364458222 ∧ code e2422364458222 = 11218457480430 := by decide
theorem cert_e2422364458222 : check e2422364458222 [[],[]] .smaller = true := by decide
def e2422364458230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364458230 : Closed e2422364458230 ∧ code e2422364458230 = 11218457480438 := by decide
theorem cert_e2422364458230 : check e2422364458230 [[],[]] .smaller = true := by decide
def e2422364458606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364458606 : Closed e2422364458606 ∧ code e2422364458606 = 11218457480814 := by decide
theorem cert_e2422364458606 : check e2422364458606 [[],[]] .smaller = true := by decide
def e2422364458618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364458618 : Closed e2422364458618 ∧ code e2422364458618 = 11218457480826 := by decide
theorem cert_e2422364458618 : check e2422364458618 [[],[]] .smaller = true := by decide
def e2422364458806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364458806 : Closed e2422364458806 ∧ code e2422364458806 = 11218457481014 := by decide
theorem cert_e2422364458806 : check e2422364458806 [[],[]] .smaller = true := by decide
def e2422364458810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364458810 : Closed e2422364458810 ∧ code e2422364458810 = 11218457481018 := by decide
theorem cert_e2422364458810 : check e2422364458810 [[],[]] .smaller = true := by decide
def e2422364464926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422364464926 : Closed e2422364464926 ∧ code e2422364464926 = 11218457487134 := by decide
theorem cert_e2422364464926 : check e2422364464926 [[],[]] .smaller = true := by decide
def e2422364465038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422364465038 : Closed e2422364465038 ∧ code e2422364465038 = 11218457487246 := by decide
theorem cert_e2422364465038 : check e2422364465038 [[],[]] .smaller = true := by decide
def e2422364465086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 4)))))))))
theorem wire_e2422364465086 : Closed e2422364465086 ∧ code e2422364465086 = 11218457487294 := by decide
theorem cert_e2422364465086 : check e2422364465086 [[],[]] .three = true := by decide
def e2422364465134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 4) (.var 2)))))))))
theorem wire_e2422364465134 : Closed e2422364465134 ∧ code e2422364465134 = 11218457487342 := by decide
theorem cert_e2422364465134 : check e2422364465134 [[],[]] .three = true := by decide
def e2422364467998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422364467998 : Closed e2422364467998 ∧ code e2422364467998 = 11218457490206 := by decide
theorem cert_e2422364467998 : check e2422364467998 [[],[]] .smaller = true := by decide
def e2422364468158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 4)))))))))
theorem wire_e2422364468158 : Closed e2422364468158 ∧ code e2422364468158 = 11218457490366 := by decide
theorem cert_e2422364468158 : check e2422364468158 [[],[]] .three = true := by decide
def e2422364468166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422364468166 : Closed e2422364468166 ∧ code e2422364468166 = 11218457490374 := by decide
theorem cert_e2422364468166 : check e2422364468166 [[],[]] .smaller = true := by decide
def e2422364468214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 4) (.var 1)))))))))
theorem wire_e2422364468214 : Closed e2422364468214 ∧ code e2422364468214 = 11218457490422 := by decide
theorem cert_e2422364468214 : check e2422364468214 [[],[]] .three = true := by decide
def e2422364469646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422364469646 : Closed e2422364469646 ∧ code e2422364469646 = 11218457491854 := by decide
theorem cert_e2422364469646 : check e2422364469646 [[],[]] .smaller = true := by decide
def e2422364469694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364469694 : Closed e2422364469694 ∧ code e2422364469694 = 11218457491902 := by decide
theorem cert_e2422364469694 : check e2422364469694 [[],[]] .three = true := by decide
def e2422364469702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422364469702 : Closed e2422364469702 ∧ code e2422364469702 = 11218457491910 := by decide
theorem cert_e2422364469702 : check e2422364469702 [[],[]] .smaller = true := by decide
def e2422364469754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364469754 : Closed e2422364469754 ∧ code e2422364469754 = 11218457491962 := by decide
theorem cert_e2422364469754 : check e2422364469754 [[],[]] .three = true := by decide
def e2422364470894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364470894 : Closed e2422364470894 ∧ code e2422364470894 = 11218457493102 := by decide
theorem cert_e2422364470894 : check e2422364470894 [[],[]] .three = true := by decide
def e2422364470902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364470902 : Closed e2422364470902 ∧ code e2422364470902 = 11218457493110 := by decide
theorem cert_e2422364470902 : check e2422364470902 [[],[]] .three = true := by decide
def e2422364470906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 5))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364470906 : Closed e2422364470906 ∧ code e2422364470906 = 11218457493114 := by decide
theorem cert_e2422364470906 : check e2422364470906 [[],[]] .three = true := by decide
def e2422364483950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2))))))))
theorem wire_e2422364483950 : Closed e2422364483950 ∧ code e2422364483950 = 11218457506158 := by decide
theorem cert_e2422364483950 : check e2422364483950 [[],[]] .smaller = true := by decide
def e2422364483958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1))))))))
theorem wire_e2422364483958 : Closed e2422364483958 ∧ code e2422364483958 = 11218457506166 := by decide
theorem cert_e2422364483958 : check e2422364483958 [[],[]] .smaller = true := by decide
def e2422364485054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 4))))))))
theorem wire_e2422364485054 : Closed e2422364485054 ∧ code e2422364485054 = 11218457507262 := by decide
theorem cert_e2422364485054 : check e2422364485054 [[],[]] .three = true := by decide
def e2422364485086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 3))))))))
theorem wire_e2422364485086 : Closed e2422364485086 ∧ code e2422364485086 = 11218457507294 := by decide
theorem cert_e2422364485086 : check e2422364485086 [[],[]] .smaller = true := by decide
def e2422364485102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 2))))))))
theorem wire_e2422364485102 : Closed e2422364485102 ∧ code e2422364485102 = 11218457507310 := by decide
theorem cert_e2422364485102 : check e2422364485102 [[],[]] .smaller = true := by decide
def e2422364485110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 4))) (.var 1))))))))
theorem wire_e2422364485110 : Closed e2422364485110 ∧ code e2422364485110 = 11218457507318 := by decide
theorem cert_e2422364485110 : check e2422364485110 [[],[]] .three = true := by decide
def e2422364485166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422364485166 : Closed e2422364485166 ∧ code e2422364485166 = 11218457507374 := by decide
theorem cert_e2422364485166 : check e2422364485166 [[],[]] .smaller = true := by decide
def e2422364485310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 4))))))))
theorem wire_e2422364485310 : Closed e2422364485310 ∧ code e2422364485310 = 11218457507518 := by decide
theorem cert_e2422364485310 : check e2422364485310 [[],[]] .three = true := by decide
def e2422364485342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 3))))))))
theorem wire_e2422364485342 : Closed e2422364485342 ∧ code e2422364485342 = 11218457507550 := by decide
theorem cert_e2422364485342 : check e2422364485342 [[],[]] .smaller = true := by decide
def e2422364485346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422364485346 : Closed e2422364485346 ∧ code e2422364485346 = 11218457507554 := by decide
theorem cert_e2422364485346 : check e2422364485346 [[],[]] .smaller = true := by decide
def e2422364485358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))))))
theorem wire_e2422364485358 : Closed e2422364485358 ∧ code e2422364485358 = 11218457507566 := by decide
theorem cert_e2422364485358 : check e2422364485358 [[],[]] .smaller = true := by decide
def e2422364485366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 1))))))))
theorem wire_e2422364485366 : Closed e2422364485366 ∧ code e2422364485366 = 11218457507574 := by decide
theorem cert_e2422364485366 : check e2422364485366 [[],[]] .smaller = true := by decide
def e2422364485370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 4))) (.var 0))))))))
theorem wire_e2422364485370 : Closed e2422364485370 ∧ code e2422364485370 = 11218457507578 := by decide
theorem cert_e2422364485370 : check e2422364485370 [[],[]] .three = true := by decide
def e2422364485398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422364485398 : Closed e2422364485398 ∧ code e2422364485398 = 11218457507606 := by decide
theorem cert_e2422364485398 : check e2422364485398 [[],[]] .smaller = true := by decide
def e2422364485470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 3))))))))
theorem wire_e2422364485470 : Closed e2422364485470 ∧ code e2422364485470 = 11218457507678 := by decide
theorem cert_e2422364485470 : check e2422364485470 [[],[]] .smaller = true := by decide
def e2422364485474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422364485474 : Closed e2422364485474 ∧ code e2422364485474 = 11218457507682 := by decide
theorem cert_e2422364485474 : check e2422364485474 [[],[]] .smaller = true := by decide
def e2422364485486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))))))
theorem wire_e2422364485486 : Closed e2422364485486 ∧ code e2422364485486 = 11218457507694 := by decide
theorem cert_e2422364485486 : check e2422364485486 [[],[]] .smaller = true := by decide
def e2422364485494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))))))
theorem wire_e2422364485494 : Closed e2422364485494 ∧ code e2422364485494 = 11218457507702 := by decide
theorem cert_e2422364485494 : check e2422364485494 [[],[]] .smaller = true := by decide
def e2422364485498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 0))))))))
theorem wire_e2422364485498 : Closed e2422364485498 ∧ code e2422364485498 = 11218457507706 := by decide
theorem cert_e2422364485498 : check e2422364485498 [[],[]] .smaller = true := by decide
def e2422364485550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 2))))))))
theorem wire_e2422364485550 : Closed e2422364485550 ∧ code e2422364485550 = 11218457507758 := by decide
theorem cert_e2422364485550 : check e2422364485550 [[],[]] .smaller = true := by decide
def e2422364485558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 1))))))))
theorem wire_e2422364485558 : Closed e2422364485558 ∧ code e2422364485558 = 11218457507766 := by decide
theorem cert_e2422364485558 : check e2422364485558 [[],[]] .smaller = true := by decide
def e2422364485562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 0))))))))
theorem wire_e2422364485562 : Closed e2422364485562 ∧ code e2422364485562 = 11218457507770 := by decide
theorem cert_e2422364485562 : check e2422364485562 [[],[]] .smaller = true := by decide
def e2422364485590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 0))) (.var 1))))))))
theorem wire_e2422364485590 : Closed e2422364485590 ∧ code e2422364485590 = 11218457507798 := by decide
theorem cert_e2422364485590 : check e2422364485590 [[],[]] .three = true := by decide
def e2422364485594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 1))) (.var 0))))))))
theorem wire_e2422364485594 : Closed e2422364485594 ∧ code e2422364485594 = 11218457507802 := by decide
theorem cert_e2422364485594 : check e2422364485594 [[],[]] .three = true := by decide
def e2422364485806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2))))))))
theorem wire_e2422364485806 : Closed e2422364485806 ∧ code e2422364485806 = 11218457508014 := by decide
theorem cert_e2422364485806 : check e2422364485806 [[],[]] .smaller = true := by decide
def e2422364485818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0))))))))
theorem wire_e2422364485818 : Closed e2422364485818 ∧ code e2422364485818 = 11218457508026 := by decide
theorem cert_e2422364485818 : check e2422364485818 [[],[]] .smaller = true := by decide
def e2422364486190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422364486190 : Closed e2422364486190 ∧ code e2422364486190 = 11218457508398 := by decide
theorem cert_e2422364486190 : check e2422364486190 [[],[]] .smaller = true := by decide
def e2422364486334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 4))))))))
theorem wire_e2422364486334 : Closed e2422364486334 ∧ code e2422364486334 = 11218457508542 := by decide
theorem cert_e2422364486334 : check e2422364486334 [[],[]] .three = true := by decide
def e2422364486366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 3))))))))
theorem wire_e2422364486366 : Closed e2422364486366 ∧ code e2422364486366 = 11218457508574 := by decide
theorem cert_e2422364486366 : check e2422364486366 [[],[]] .smaller = true := by decide
def e2422364486370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422364486370 : Closed e2422364486370 ∧ code e2422364486370 = 11218457508578 := by decide
theorem cert_e2422364486370 : check e2422364486370 [[],[]] .smaller = true := by decide
def e2422364486382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))))))
theorem wire_e2422364486382 : Closed e2422364486382 ∧ code e2422364486382 = 11218457508590 := by decide
theorem cert_e2422364486382 : check e2422364486382 [[],[]] .smaller = true := by decide
def e2422364486390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 1))))))))
theorem wire_e2422364486390 : Closed e2422364486390 ∧ code e2422364486390 = 11218457508598 := by decide
theorem cert_e2422364486390 : check e2422364486390 [[],[]] .smaller = true := by decide
def e2422364486394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 4))) (.var 0))))))))
theorem wire_e2422364486394 : Closed e2422364486394 ∧ code e2422364486394 = 11218457508602 := by decide
theorem cert_e2422364486394 : check e2422364486394 [[],[]] .three = true := by decide
def e2422364486494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 3))))))))
theorem wire_e2422364486494 : Closed e2422364486494 ∧ code e2422364486494 = 11218457508702 := by decide
theorem cert_e2422364486494 : check e2422364486494 [[],[]] .smaller = true := by decide
def e2422364486510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 2))))))))
theorem wire_e2422364486510 : Closed e2422364486510 ∧ code e2422364486510 = 11218457508718 := by decide
theorem cert_e2422364486510 : check e2422364486510 [[],[]] .smaller = true := by decide
def e2422364486518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 1))))))))
theorem wire_e2422364486518 : Closed e2422364486518 ∧ code e2422364486518 = 11218457508726 := by decide
theorem cert_e2422364486518 : check e2422364486518 [[],[]] .smaller = true := by decide
def e2422364486522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))) (.var 0))))))))
theorem wire_e2422364486522 : Closed e2422364486522 ∧ code e2422364486522 = 11218457508730 := by decide
theorem cert_e2422364486522 : check e2422364486522 [[],[]] .smaller = true := by decide
def e2422364486538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364486538 : Closed e2422364486538 ∧ code e2422364486538 = 11218457508746 := by decide
theorem cert_e2422364486538 : check e2422364486538 [[],[]] .smaller = true := by decide
def e2422364486562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364486562 : Closed e2422364486562 ∧ code e2422364486562 = 11218457508770 := by decide
theorem cert_e2422364486562 : check e2422364486562 [[],[]] .smaller = true := by decide
def e2422364486574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))))))
theorem wire_e2422364486574 : Closed e2422364486574 ∧ code e2422364486574 = 11218457508782 := by decide
theorem cert_e2422364486574 : check e2422364486574 [[],[]] .smaller = true := by decide
def e2422364486582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 1))))))))
theorem wire_e2422364486582 : Closed e2422364486582 ∧ code e2422364486582 = 11218457508790 := by decide
theorem cert_e2422364486582 : check e2422364486582 [[],[]] .smaller = true := by decide
def e2422364486586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))))))
theorem wire_e2422364486586 : Closed e2422364486586 ∧ code e2422364486586 = 11218457508794 := by decide
theorem cert_e2422364486586 : check e2422364486586 [[],[]] .smaller = true := by decide
def e2422364486614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 1))))))))
theorem wire_e2422364486614 : Closed e2422364486614 ∧ code e2422364486614 = 11218457508822 := by decide
theorem cert_e2422364486614 : check e2422364486614 [[],[]] .smaller = true := by decide
def e2422364486618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))) (.var 0))))))))
theorem wire_e2422364486618 : Closed e2422364486618 ∧ code e2422364486618 = 11218457508826 := by decide
theorem cert_e2422364486618 : check e2422364486618 [[],[]] .smaller = true := by decide
def e2422364486634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 0))) (.var 0))))))))
theorem wire_e2422364486634 : Closed e2422364486634 ∧ code e2422364486634 = 11218457508842 := by decide
theorem cert_e2422364486634 : check e2422364486634 [[],[]] .three = true := by decide
def e2422364486742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1))))))))
theorem wire_e2422364486742 : Closed e2422364486742 ∧ code e2422364486742 = 11218457508950 := by decide
theorem cert_e2422364486742 : check e2422364486742 [[],[]] .smaller = true := by decide
def e2422364486746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0))))))))
theorem wire_e2422364486746 : Closed e2422364486746 ∧ code e2422364486746 = 11218457508954 := by decide
theorem cert_e2422364486746 : check e2422364486746 [[],[]] .smaller = true := by decide
def e2422364486934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422364486934 : Closed e2422364486934 ∧ code e2422364486934 = 11218457509142 := by decide
theorem cert_e2422364486934 : check e2422364486934 [[],[]] .smaller = true := by decide
def e2422364487006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 3))))))))
theorem wire_e2422364487006 : Closed e2422364487006 ∧ code e2422364487006 = 11218457509214 := by decide
theorem cert_e2422364487006 : check e2422364487006 [[],[]] .smaller = true := by decide
def e2422364487010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422364487010 : Closed e2422364487010 ∧ code e2422364487010 = 11218457509218 := by decide
theorem cert_e2422364487010 : check e2422364487010 [[],[]] .smaller = true := by decide
def e2422364487022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e2422364487022 : Closed e2422364487022 ∧ code e2422364487022 = 11218457509230 := by decide
theorem cert_e2422364487022 : check e2422364487022 [[],[]] .smaller = true := by decide
def e2422364487030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e2422364487030 : Closed e2422364487030 ∧ code e2422364487030 = 11218457509238 := by decide
theorem cert_e2422364487030 : check e2422364487030 [[],[]] .smaller = true := by decide
def e2422364487034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 0))))))))
theorem wire_e2422364487034 : Closed e2422364487034 ∧ code e2422364487034 = 11218457509242 := by decide
theorem cert_e2422364487034 : check e2422364487034 [[],[]] .smaller = true := by decide
def e2422364487050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364487050 : Closed e2422364487050 ∧ code e2422364487050 = 11218457509258 := by decide
theorem cert_e2422364487050 : check e2422364487050 [[],[]] .smaller = true := by decide
def e2422364487074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364487074 : Closed e2422364487074 ∧ code e2422364487074 = 11218457509282 := by decide
theorem cert_e2422364487074 : check e2422364487074 [[],[]] .smaller = true := by decide
def e2422364487086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e2422364487086 : Closed e2422364487086 ∧ code e2422364487086 = 11218457509294 := by decide
theorem cert_e2422364487086 : check e2422364487086 [[],[]] .smaller = true := by decide
def e2422364487094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 1))))))))
theorem wire_e2422364487094 : Closed e2422364487094 ∧ code e2422364487094 = 11218457509302 := by decide
theorem cert_e2422364487094 : check e2422364487094 [[],[]] .smaller = true := by decide
def e2422364487098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e2422364487098 : Closed e2422364487098 ∧ code e2422364487098 = 11218457509306 := by decide
theorem cert_e2422364487098 : check e2422364487098 [[],[]] .smaller = true := by decide
def e2422364487126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e2422364487126 : Closed e2422364487126 ∧ code e2422364487126 = 11218457509334 := by decide
theorem cert_e2422364487126 : check e2422364487126 [[],[]] .smaller = true := by decide
def e2422364487130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e2422364487130 : Closed e2422364487130 ∧ code e2422364487130 = 11218457509338 := by decide
theorem cert_e2422364487130 : check e2422364487130 [[],[]] .smaller = true := by decide
def e2422364487146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 0))))))))
theorem wire_e2422364487146 : Closed e2422364487146 ∧ code e2422364487146 = 11218457509354 := by decide
theorem cert_e2422364487146 : check e2422364487146 [[],[]] .smaller = true := by decide
def e2422364487342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e2422364487342 : Closed e2422364487342 ∧ code e2422364487342 = 11218457509550 := by decide
theorem cert_e2422364487342 : check e2422364487342 [[],[]] .smaller = true := by decide
def e2422364487350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 1))))))))
theorem wire_e2422364487350 : Closed e2422364487350 ∧ code e2422364487350 = 11218457509558 := by decide
theorem cert_e2422364487350 : check e2422364487350 [[],[]] .smaller = true := by decide
def e2422364487354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e2422364487354 : Closed e2422364487354 ∧ code e2422364487354 = 11218457509562 := by decide
theorem cert_e2422364487354 : check e2422364487354 [[],[]] .smaller = true := by decide
def e2422364487382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 1))))))))
theorem wire_e2422364487382 : Closed e2422364487382 ∧ code e2422364487382 = 11218457509590 := by decide
theorem cert_e2422364487382 : check e2422364487382 [[],[]] .smaller = true := by decide
def e2422364487386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))) (.var 0))))))))
theorem wire_e2422364487386 : Closed e2422364487386 ∧ code e2422364487386 = 11218457509594 := by decide
theorem cert_e2422364487386 : check e2422364487386 [[],[]] .smaller = true := by decide
def e2422364487402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e2422364487402 : Closed e2422364487402 ∧ code e2422364487402 = 11218457509610 := by decide
theorem cert_e2422364487402 : check e2422364487402 [[],[]] .smaller = true := by decide
def e2422364487510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e2422364487510 : Closed e2422364487510 ∧ code e2422364487510 = 11218457509718 := by decide
theorem cert_e2422364487510 : check e2422364487510 [[],[]] .three = true := by decide
def e2422364487514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e2422364487514 : Closed e2422364487514 ∧ code e2422364487514 = 11218457509722 := by decide
theorem cert_e2422364487514 : check e2422364487514 [[],[]] .three = true := by decide
def e2422364487530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e2422364487530 : Closed e2422364487530 ∧ code e2422364487530 = 11218457509738 := by decide
theorem cert_e2422364487530 : check e2422364487530 [[],[]] .three = true := by decide
def e2422364488174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2))))))))
theorem wire_e2422364488174 : Closed e2422364488174 ∧ code e2422364488174 = 11218457510382 := by decide
theorem cert_e2422364488174 : check e2422364488174 [[],[]] .smaller = true := by decide
def e2422364488182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1))))))))
theorem wire_e2422364488182 : Closed e2422364488182 ∧ code e2422364488182 = 11218457510390 := by decide
theorem cert_e2422364488182 : check e2422364488182 [[],[]] .smaller = true := by decide
def e2422364488942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364488942 : Closed e2422364488942 ∧ code e2422364488942 = 11218457511150 := by decide
theorem cert_e2422364488942 : check e2422364488942 [[],[]] .smaller = true := by decide
def e2422364488950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364488950 : Closed e2422364488950 ∧ code e2422364488950 = 11218457511158 := by decide
theorem cert_e2422364488950 : check e2422364488950 [[],[]] .smaller = true := by decide
def e2422364489502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3)))))))))
theorem wire_e2422364489502 : Closed e2422364489502 ∧ code e2422364489502 = 11218457511710 := by decide
theorem cert_e2422364489502 : check e2422364489502 [[],[]] .smaller = true := by decide
def e2422364489614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2)))))))))
theorem wire_e2422364489614 : Closed e2422364489614 ∧ code e2422364489614 = 11218457511822 := by decide
theorem cert_e2422364489614 : check e2422364489614 [[],[]] .smaller = true := by decide
def e2422364489662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 4))))))))
theorem wire_e2422364489662 : Closed e2422364489662 ∧ code e2422364489662 = 11218457511870 := by decide
theorem cert_e2422364489662 : check e2422364489662 [[],[]] .three = true := by decide
def e2422364489710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 5)))) (.var 2))))))))
theorem wire_e2422364489710 : Closed e2422364489710 ∧ code e2422364489710 = 11218457511918 := by decide
theorem cert_e2422364489710 : check e2422364489710 [[],[]] .three = true := by decide
def e2422364491198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 4))))))))
theorem wire_e2422364491198 : Closed e2422364491198 ∧ code e2422364491198 = 11218457513406 := by decide
theorem cert_e2422364491198 : check e2422364491198 [[],[]] .three = true := by decide
def e2422364491230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 3))))))))
theorem wire_e2422364491230 : Closed e2422364491230 ∧ code e2422364491230 = 11218457513438 := by decide
theorem cert_e2422364491230 : check e2422364491230 [[],[]] .smaller = true := by decide
def e2422364491246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 2))))))))
theorem wire_e2422364491246 : Closed e2422364491246 ∧ code e2422364491246 = 11218457513454 := by decide
theorem cert_e2422364491246 : check e2422364491246 [[],[]] .smaller = true := by decide
def e2422364491254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 4)))) (.var 1))))))))
theorem wire_e2422364491254 : Closed e2422364491254 ∧ code e2422364491254 = 11218457513462 := by decide
theorem cert_e2422364491254 : check e2422364491254 [[],[]] .three = true := by decide
def e2422364491310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))))
theorem wire_e2422364491310 : Closed e2422364491310 ∧ code e2422364491310 = 11218457513518 := by decide
theorem cert_e2422364491310 : check e2422364491310 [[],[]] .smaller = true := by decide
def e2422364491454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 4))))))))
theorem wire_e2422364491454 : Closed e2422364491454 ∧ code e2422364491454 = 11218457513662 := by decide
theorem cert_e2422364491454 : check e2422364491454 [[],[]] .three = true := by decide
def e2422364491486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 3))))))))
theorem wire_e2422364491486 : Closed e2422364491486 ∧ code e2422364491486 = 11218457513694 := by decide
theorem cert_e2422364491486 : check e2422364491486 [[],[]] .smaller = true := by decide
def e2422364491490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))))
theorem wire_e2422364491490 : Closed e2422364491490 ∧ code e2422364491490 = 11218457513698 := by decide
theorem cert_e2422364491490 : check e2422364491490 [[],[]] .smaller = true := by decide
def e2422364491502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))))))
theorem wire_e2422364491502 : Closed e2422364491502 ∧ code e2422364491502 = 11218457513710 := by decide
theorem cert_e2422364491502 : check e2422364491502 [[],[]] .smaller = true := by decide
def e2422364491510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 1))))))))
theorem wire_e2422364491510 : Closed e2422364491510 ∧ code e2422364491510 = 11218457513718 := by decide
theorem cert_e2422364491510 : check e2422364491510 [[],[]] .smaller = true := by decide
def e2422364491514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 4)))) (.var 0))))))))
theorem wire_e2422364491514 : Closed e2422364491514 ∧ code e2422364491514 = 11218457513722 := by decide
theorem cert_e2422364491514 : check e2422364491514 [[],[]] .three = true := by decide
def e2422364491542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))))
theorem wire_e2422364491542 : Closed e2422364491542 ∧ code e2422364491542 = 11218457513750 := by decide
theorem cert_e2422364491542 : check e2422364491542 [[],[]] .smaller = true := by decide
def e2422364491614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 3))))))))
theorem wire_e2422364491614 : Closed e2422364491614 ∧ code e2422364491614 = 11218457513822 := by decide
theorem cert_e2422364491614 : check e2422364491614 [[],[]] .smaller = true := by decide
def e2422364491618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))))
theorem wire_e2422364491618 : Closed e2422364491618 ∧ code e2422364491618 = 11218457513826 := by decide
theorem cert_e2422364491618 : check e2422364491618 [[],[]] .smaller = true := by decide
def e2422364491630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))))))
theorem wire_e2422364491630 : Closed e2422364491630 ∧ code e2422364491630 = 11218457513838 := by decide
theorem cert_e2422364491630 : check e2422364491630 [[],[]] .smaller = true := by decide
def e2422364491638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))))))
theorem wire_e2422364491638 : Closed e2422364491638 ∧ code e2422364491638 = 11218457513846 := by decide
theorem cert_e2422364491638 : check e2422364491638 [[],[]] .smaller = true := by decide
def e2422364491642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 0))))))))
theorem wire_e2422364491642 : Closed e2422364491642 ∧ code e2422364491642 = 11218457513850 := by decide
theorem cert_e2422364491642 : check e2422364491642 [[],[]] .smaller = true := by decide
def e2422364491694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 2))))))))
theorem wire_e2422364491694 : Closed e2422364491694 ∧ code e2422364491694 = 11218457513902 := by decide
theorem cert_e2422364491694 : check e2422364491694 [[],[]] .smaller = true := by decide
def e2422364491702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 1))))))))
theorem wire_e2422364491702 : Closed e2422364491702 ∧ code e2422364491702 = 11218457513910 := by decide
theorem cert_e2422364491702 : check e2422364491702 [[],[]] .smaller = true := by decide
def e2422364491706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 0))))))))
theorem wire_e2422364491706 : Closed e2422364491706 ∧ code e2422364491706 = 11218457513914 := by decide
theorem cert_e2422364491706 : check e2422364491706 [[],[]] .smaller = true := by decide
def e2422364491734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 0)))) (.var 1))))))))
theorem wire_e2422364491734 : Closed e2422364491734 ∧ code e2422364491734 = 11218457513942 := by decide
theorem cert_e2422364491734 : check e2422364491734 [[],[]] .three = true := by decide
def e2422364491738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 1)))) (.var 0))))))))
theorem wire_e2422364491738 : Closed e2422364491738 ∧ code e2422364491738 = 11218457513946 := by decide
theorem cert_e2422364491738 : check e2422364491738 [[],[]] .three = true := by decide
def e2422364492734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 4)))))))))
theorem wire_e2422364492734 : Closed e2422364492734 ∧ code e2422364492734 = 11218457514942 := by decide
theorem cert_e2422364492734 : check e2422364492734 [[],[]] .three = true := by decide
def e2422364492766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422364492766 : Closed e2422364492766 ∧ code e2422364492766 = 11218457514974 := by decide
theorem cert_e2422364492766 : check e2422364492766 [[],[]] .smaller = true := by decide
def e2422364492782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422364492782 : Closed e2422364492782 ∧ code e2422364492782 = 11218457514990 := by decide
theorem cert_e2422364492782 : check e2422364492782 [[],[]] .smaller = true := by decide
def e2422364492790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 4) (.var 1)))))))))
theorem wire_e2422364492790 : Closed e2422364492790 ∧ code e2422364492790 = 11218457514998 := by decide
theorem cert_e2422364492790 : check e2422364492790 [[],[]] .three = true := by decide
def e2422364493886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4))))))))))
theorem wire_e2422364493886 : Closed e2422364493886 ∧ code e2422364493886 = 11218457516094 := by decide
theorem cert_e2422364493886 : check e2422364493886 [[],[]] .smaller = true := by decide
def e2422364494270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364494270 : Closed e2422364494270 ∧ code e2422364494270 = 11218457516478 := by decide
theorem cert_e2422364494270 : check e2422364494270 [[],[]] .three = true := by decide
def e2422364494302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364494302 : Closed e2422364494302 ∧ code e2422364494302 = 11218457516510 := by decide
theorem cert_e2422364494302 : check e2422364494302 [[],[]] .smaller = true := by decide
def e2422364494306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422364494306 : Closed e2422364494306 ∧ code e2422364494306 = 11218457516514 := by decide
theorem cert_e2422364494306 : check e2422364494306 [[],[]] .smaller = true := by decide
def e2422364494318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422364494318 : Closed e2422364494318 ∧ code e2422364494318 = 11218457516526 := by decide
theorem cert_e2422364494318 : check e2422364494318 [[],[]] .smaller = true := by decide
def e2422364494326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364494326 : Closed e2422364494326 ∧ code e2422364494326 = 11218457516534 := by decide
theorem cert_e2422364494326 : check e2422364494326 [[],[]] .smaller = true := by decide
def e2422364494330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364494330 : Closed e2422364494330 ∧ code e2422364494330 = 11218457516538 := by decide
theorem cert_e2422364494330 : check e2422364494330 [[],[]] .three = true := by decide
def e2422364494878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3))))))))))
theorem wire_e2422364494878 : Closed e2422364494878 ∧ code e2422364494878 = 11218457517086 := by decide
theorem cert_e2422364494878 : check e2422364494878 [[],[]] .smaller = true := by decide
def e2422364494974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 5)))))))))
theorem wire_e2422364494974 : Closed e2422364494974 ∧ code e2422364494974 = 11218457517182 := by decide
theorem cert_e2422364494974 : check e2422364494974 [[],[]] .three = true := by decide
def e2422364495070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364495070 : Closed e2422364495070 ∧ code e2422364495070 = 11218457517278 := by decide
theorem cert_e2422364495070 : check e2422364495070 [[],[]] .smaller = true := by decide
def e2422364495074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422364495074 : Closed e2422364495074 ∧ code e2422364495074 = 11218457517282 := by decide
theorem cert_e2422364495074 : check e2422364495074 [[],[]] .smaller = true := by decide
def e2422364495086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364495086 : Closed e2422364495086 ∧ code e2422364495086 = 11218457517294 := by decide
theorem cert_e2422364495086 : check e2422364495086 [[],[]] .smaller = true := by decide
def e2422364495094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364495094 : Closed e2422364495094 ∧ code e2422364495094 = 11218457517302 := by decide
theorem cert_e2422364495094 : check e2422364495094 [[],[]] .smaller = true := by decide
end Blc.Floor43
