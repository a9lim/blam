import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373709662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 3)))))))
theorem wire_e2422373709662 : Closed e2422373709662 ∧ code e2422373709662 = 11218466731870 := by decide
theorem cert_e2422373709662 : check e2422373709662 [[],[]] .three = true := by decide
def e2422373709690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3))) (.var 0)))))))
theorem wire_e2422373709690 : Closed e2422373709690 ∧ code e2422373709690 = 11218466731898 := by decide
theorem cert_e2422373709690 : check e2422373709690 [[],[]] .three = true := by decide
def e2422373709706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373709706 : Closed e2422373709706 ∧ code e2422373709706 = 11218466731914 := by decide
theorem cert_e2422373709706 : check e2422373709706 [[],[]] .three = true := by decide
def e2422373709730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373709730 : Closed e2422373709730 ∧ code e2422373709730 = 11218466731938 := by decide
theorem cert_e2422373709730 : check e2422373709730 [[],[]] .three = true := by decide
def e2422373709742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 2)))))))
theorem wire_e2422373709742 : Closed e2422373709742 ∧ code e2422373709742 = 11218466731950 := by decide
theorem cert_e2422373709742 : check e2422373709742 [[],[]] .three = true := by decide
def e2422373709754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2))) (.var 0)))))))
theorem wire_e2422373709754 : Closed e2422373709754 ∧ code e2422373709754 = 11218466731962 := by decide
theorem cert_e2422373709754 : check e2422373709754 [[],[]] .three = true := by decide
def e2422373709866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))) (.var 0)))))))
theorem wire_e2422373709866 : Closed e2422373709866 ∧ code e2422373709866 = 11218466732074 := by decide
theorem cert_e2422373709866 : check e2422373709866 [[],[]] .smaller = true := by decide
def e2422373709998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e2422373709998 : Closed e2422373709998 ∧ code e2422373709998 = 11218466732206 := by decide
theorem cert_e2422373709998 : check e2422373709998 [[],[]] .smaller = true := by decide
def e2422373710010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e2422373710010 : Closed e2422373710010 ∧ code e2422373710010 = 11218466732218 := by decide
theorem cert_e2422373710010 : check e2422373710010 [[],[]] .smaller = true := by decide
def e2422373710038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 1)))))))
theorem wire_e2422373710038 : Closed e2422373710038 ∧ code e2422373710038 = 11218466732246 := by decide
theorem cert_e2422373710038 : check e2422373710038 [[],[]] .smaller = true := by decide
def e2422373710042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 0)))))))
theorem wire_e2422373710042 : Closed e2422373710042 ∧ code e2422373710042 = 11218466732250 := by decide
theorem cert_e2422373710042 : check e2422373710042 [[],[]] .smaller = true := by decide
def e2422373710058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 0)))))))
theorem wire_e2422373710058 : Closed e2422373710058 ∧ code e2422373710058 = 11218466732266 := by decide
theorem cert_e2422373710058 : check e2422373710058 [[],[]] .smaller = true := by decide
def e2422373710250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e2422373710250 : Closed e2422373710250 ∧ code e2422373710250 = 11218466732458 := by decide
theorem cert_e2422373710250 : check e2422373710250 [[],[]] .smaller = true := by decide
def e2422373710346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373710346 : Closed e2422373710346 ∧ code e2422373710346 = 11218466732554 := by decide
theorem cert_e2422373710346 : check e2422373710346 [[],[]] .smaller = true := by decide
def e2422373710382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373710382 : Closed e2422373710382 ∧ code e2422373710382 = 11218466732590 := by decide
theorem cert_e2422373710382 : check e2422373710382 [[],[]] .smaller = true := by decide
def e2422373710390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373710390 : Closed e2422373710390 ∧ code e2422373710390 = 11218466732598 := by decide
theorem cert_e2422373710390 : check e2422373710390 [[],[]] .smaller = true := by decide
def e2422373710394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373710394 : Closed e2422373710394 ∧ code e2422373710394 = 11218466732602 := by decide
theorem cert_e2422373710394 : check e2422373710394 [[],[]] .smaller = true := by decide
def e2422373710442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373710442 : Closed e2422373710442 ∧ code e2422373710442 = 11218466732650 := by decide
theorem cert_e2422373710442 : check e2422373710442 [[],[]] .smaller = true := by decide
def e2422373710466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373710466 : Closed e2422373710466 ∧ code e2422373710466 = 11218466732674 := by decide
theorem cert_e2422373710466 : check e2422373710466 [[],[]] .smaller = true := by decide
def e2422373710478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373710478 : Closed e2422373710478 ∧ code e2422373710478 = 11218466732686 := by decide
theorem cert_e2422373710478 : check e2422373710478 [[],[]] .smaller = true := by decide
def e2422373710490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373710490 : Closed e2422373710490 ∧ code e2422373710490 = 11218466732698 := by decide
theorem cert_e2422373710490 : check e2422373710490 [[],[]] .smaller = true := by decide
def e2422373710534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373710534 : Closed e2422373710534 ∧ code e2422373710534 = 11218466732742 := by decide
theorem cert_e2422373710534 : check e2422373710534 [[],[]] .smaller = true := by decide
def e2422373710558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e2422373710558 : Closed e2422373710558 ∧ code e2422373710558 = 11218466732766 := by decide
theorem cert_e2422373710558 : check e2422373710558 [[],[]] .three = true := by decide
def e2422373710562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373710562 : Closed e2422373710562 ∧ code e2422373710562 = 11218466732770 := by decide
theorem cert_e2422373710562 : check e2422373710562 [[],[]] .smaller = true := by decide
def e2422373710574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 2)))))))
theorem wire_e2422373710574 : Closed e2422373710574 ∧ code e2422373710574 = 11218466732782 := by decide
theorem cert_e2422373710574 : check e2422373710574 [[],[]] .smaller = true := by decide
def e2422373710582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e2422373710582 : Closed e2422373710582 ∧ code e2422373710582 = 11218466732790 := by decide
theorem cert_e2422373710582 : check e2422373710582 [[],[]] .three = true := by decide
def e2422373710618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373710618 : Closed e2422373710618 ∧ code e2422373710618 = 11218466732826 := by decide
theorem cert_e2422373710618 : check e2422373710618 [[],[]] .smaller = true := by decide
def e2422373710662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373710662 : Closed e2422373710662 ∧ code e2422373710662 = 11218466732870 := by decide
theorem cert_e2422373710662 : check e2422373710662 [[],[]] .smaller = true := by decide
def e2422373710686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e2422373710686 : Closed e2422373710686 ∧ code e2422373710686 = 11218466732894 := by decide
theorem cert_e2422373710686 : check e2422373710686 [[],[]] .three = true := by decide
def e2422373710714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e2422373710714 : Closed e2422373710714 ∧ code e2422373710714 = 11218466732922 := by decide
theorem cert_e2422373710714 : check e2422373710714 [[],[]] .three = true := by decide
def e2422373710730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373710730 : Closed e2422373710730 ∧ code e2422373710730 = 11218466732938 := by decide
theorem cert_e2422373710730 : check e2422373710730 [[],[]] .smaller = true := by decide
def e2422373710754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373710754 : Closed e2422373710754 ∧ code e2422373710754 = 11218466732962 := by decide
theorem cert_e2422373710754 : check e2422373710754 [[],[]] .smaller = true := by decide
def e2422373710766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 2)))))))
theorem wire_e2422373710766 : Closed e2422373710766 ∧ code e2422373710766 = 11218466732974 := by decide
theorem cert_e2422373710766 : check e2422373710766 [[],[]] .smaller = true := by decide
def e2422373710778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 2))) (.var 0)))))))
theorem wire_e2422373710778 : Closed e2422373710778 ∧ code e2422373710778 = 11218466732986 := by decide
theorem cert_e2422373710778 : check e2422373710778 [[],[]] .smaller = true := by decide
def e2422373710806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e2422373710806 : Closed e2422373710806 ∧ code e2422373710806 = 11218466733014 := by decide
theorem cert_e2422373710806 : check e2422373710806 [[],[]] .three = true := by decide
def e2422373710810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e2422373710810 : Closed e2422373710810 ∧ code e2422373710810 = 11218466733018 := by decide
theorem cert_e2422373710810 : check e2422373710810 [[],[]] .three = true := by decide
def e2422373710934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e2422373710934 : Closed e2422373710934 ∧ code e2422373710934 = 11218466733142 := by decide
theorem cert_e2422373710934 : check e2422373710934 [[],[]] .three = true := by decide
def e2422373710938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e2422373710938 : Closed e2422373710938 ∧ code e2422373710938 = 11218466733146 := by decide
theorem cert_e2422373710938 : check e2422373710938 [[],[]] .three = true := by decide
def e2422373710954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))) (.var 0)))))))
theorem wire_e2422373710954 : Closed e2422373710954 ∧ code e2422373710954 = 11218466733162 := by decide
theorem cert_e2422373710954 : check e2422373710954 [[],[]] .three = true := by decide
def e2422373711126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373711126 : Closed e2422373711126 ∧ code e2422373711126 = 11218466733334 := by decide
theorem cert_e2422373711126 : check e2422373711126 [[],[]] .three = true := by decide
def e2422373711130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373711130 : Closed e2422373711130 ∧ code e2422373711130 = 11218466733338 := by decide
theorem cert_e2422373711130 : check e2422373711130 [[],[]] .three = true := by decide
def e2422373711174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373711174 : Closed e2422373711174 ∧ code e2422373711174 = 11218466733382 := by decide
theorem cert_e2422373711174 : check e2422373711174 [[],[]] .three = true := by decide
def e2422373711198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e2422373711198 : Closed e2422373711198 ∧ code e2422373711198 = 11218466733406 := by decide
theorem cert_e2422373711198 : check e2422373711198 [[],[]] .three = true := by decide
def e2422373711202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373711202 : Closed e2422373711202 ∧ code e2422373711202 = 11218466733410 := by decide
theorem cert_e2422373711202 : check e2422373711202 [[],[]] .three = true := by decide
def e2422373711214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2422373711214 : Closed e2422373711214 ∧ code e2422373711214 = 11218466733422 := by decide
theorem cert_e2422373711214 : check e2422373711214 [[],[]] .three = true := by decide
def e2422373711222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2422373711222 : Closed e2422373711222 ∧ code e2422373711222 = 11218466733430 := by decide
theorem cert_e2422373711222 : check e2422373711222 [[],[]] .three = true := by decide
def e2422373711226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e2422373711226 : Closed e2422373711226 ∧ code e2422373711226 = 11218466733434 := by decide
theorem cert_e2422373711226 : check e2422373711226 [[],[]] .three = true := by decide
def e2422373711242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373711242 : Closed e2422373711242 ∧ code e2422373711242 = 11218466733450 := by decide
theorem cert_e2422373711242 : check e2422373711242 [[],[]] .three = true := by decide
def e2422373711266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373711266 : Closed e2422373711266 ∧ code e2422373711266 = 11218466733474 := by decide
theorem cert_e2422373711266 : check e2422373711266 [[],[]] .three = true := by decide
def e2422373711278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2422373711278 : Closed e2422373711278 ∧ code e2422373711278 = 11218466733486 := by decide
theorem cert_e2422373711278 : check e2422373711278 [[],[]] .three = true := by decide
def e2422373711290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2422373711290 : Closed e2422373711290 ∧ code e2422373711290 = 11218466733498 := by decide
theorem cert_e2422373711290 : check e2422373711290 [[],[]] .three = true := by decide
def e2422373711318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2422373711318 : Closed e2422373711318 ∧ code e2422373711318 = 11218466733526 := by decide
theorem cert_e2422373711318 : check e2422373711318 [[],[]] .three = true := by decide
def e2422373711322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2422373711322 : Closed e2422373711322 ∧ code e2422373711322 = 11218466733530 := by decide
theorem cert_e2422373711322 : check e2422373711322 [[],[]] .three = true := by decide
def e2422373711338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e2422373711338 : Closed e2422373711338 ∧ code e2422373711338 = 11218466733546 := by decide
theorem cert_e2422373711338 : check e2422373711338 [[],[]] .three = true := by decide
def e2422373712302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 2)))))))
theorem wire_e2422373712302 : Closed e2422373712302 ∧ code e2422373712302 = 11218466734510 := by decide
theorem cert_e2422373712302 : check e2422373712302 [[],[]] .smaller = true := by decide
def e2422373712494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373712494 : Closed e2422373712494 ∧ code e2422373712494 = 11218466734702 := by decide
theorem cert_e2422373712494 : check e2422373712494 [[],[]] .smaller = true := by decide
def e2422373712506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373712506 : Closed e2422373712506 ∧ code e2422373712506 = 11218466734714 := by decide
theorem cert_e2422373712506 : check e2422373712506 [[],[]] .smaller = true := by decide
def e2422373712862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 3)))))))
theorem wire_e2422373712862 : Closed e2422373712862 ∧ code e2422373712862 = 11218466735070 := by decide
theorem cert_e2422373712862 : check e2422373712862 [[],[]] .three = true := by decide
def e2422373712878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 2)))))))
theorem wire_e2422373712878 : Closed e2422373712878 ∧ code e2422373712878 = 11218466735086 := by decide
theorem cert_e2422373712878 : check e2422373712878 [[],[]] .smaller = true := by decide
def e2422373712886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 5))))) (.var 1)))))))
theorem wire_e2422373712886 : Closed e2422373712886 ∧ code e2422373712886 = 11218466735094 := by decide
theorem cert_e2422373712886 : check e2422373712886 [[],[]] .three = true := by decide
def e2422373713630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.var 3)))))))
theorem wire_e2422373713630 : Closed e2422373713630 ∧ code e2422373713630 = 11218466735838 := by decide
theorem cert_e2422373713630 : check e2422373713630 [[],[]] .three = true := by decide
def e2422373713646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 2)))))))
theorem wire_e2422373713646 : Closed e2422373713646 ∧ code e2422373713646 = 11218466735854 := by decide
theorem cert_e2422373713646 : check e2422373713646 [[],[]] .smaller = true := by decide
def e2422373713654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 1)))))))
theorem wire_e2422373713654 : Closed e2422373713654 ∧ code e2422373713654 = 11218466735862 := by decide
theorem cert_e2422373713654 : check e2422373713654 [[],[]] .smaller = true := by decide
def e2422373713658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 4))))) (.var 0)))))))
theorem wire_e2422373713658 : Closed e2422373713658 ∧ code e2422373713658 = 11218466735866 := by decide
theorem cert_e2422373713658 : check e2422373713658 [[],[]] .three = true := by decide
def e2422373713758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.var 3)))))))
theorem wire_e2422373713758 : Closed e2422373713758 ∧ code e2422373713758 = 11218466735966 := by decide
theorem cert_e2422373713758 : check e2422373713758 [[],[]] .three = true := by decide
def e2422373713774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 2)))))))
theorem wire_e2422373713774 : Closed e2422373713774 ∧ code e2422373713774 = 11218466735982 := by decide
theorem cert_e2422373713774 : check e2422373713774 [[],[]] .smaller = true := by decide
def e2422373713786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))) (.var 0)))))))
theorem wire_e2422373713786 : Closed e2422373713786 ∧ code e2422373713786 = 11218466735994 := by decide
theorem cert_e2422373713786 : check e2422373713786 [[],[]] .smaller = true := by decide
def e2422373713838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 2)))))))
theorem wire_e2422373713838 : Closed e2422373713838 ∧ code e2422373713838 = 11218466736046 := by decide
theorem cert_e2422373713838 : check e2422373713838 [[],[]] .smaller = true := by decide
def e2422373713878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 1)))))))
theorem wire_e2422373713878 : Closed e2422373713878 ∧ code e2422373713878 = 11218466736086 := by decide
theorem cert_e2422373713878 : check e2422373713878 [[],[]] .smaller = true := by decide
def e2422373713882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))) (.var 0)))))))
theorem wire_e2422373713882 : Closed e2422373713882 ∧ code e2422373713882 = 11218466736090 := by decide
theorem cert_e2422373713882 : check e2422373713882 [[],[]] .smaller = true := by decide
def e2422373713898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.var 0))))) (.var 0)))))))
theorem wire_e2422373713898 : Closed e2422373713898 ∧ code e2422373713898 = 11218466736106 := by decide
theorem cert_e2422373713898 : check e2422373713898 [[],[]] .three = true := by decide
def e2422373714398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373714398 : Closed e2422373714398 ∧ code e2422373714398 = 11218466736606 := by decide
theorem cert_e2422373714398 : check e2422373714398 [[],[]] .three = true := by decide
def e2422373714414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373714414 : Closed e2422373714414 ∧ code e2422373714414 = 11218466736622 := by decide
theorem cert_e2422373714414 : check e2422373714414 [[],[]] .smaller = true := by decide
def e2422373714422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373714422 : Closed e2422373714422 ∧ code e2422373714422 = 11218466736630 := by decide
theorem cert_e2422373714422 : check e2422373714422 [[],[]] .three = true := by decide
def e2422373715166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373715166 : Closed e2422373715166 ∧ code e2422373715166 = 11218466737374 := by decide
theorem cert_e2422373715166 : check e2422373715166 [[],[]] .three = true := by decide
def e2422373715182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373715182 : Closed e2422373715182 ∧ code e2422373715182 = 11218466737390 := by decide
theorem cert_e2422373715182 : check e2422373715182 [[],[]] .smaller = true := by decide
def e2422373715190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373715190 : Closed e2422373715190 ∧ code e2422373715190 = 11218466737398 := by decide
theorem cert_e2422373715190 : check e2422373715190 [[],[]] .smaller = true := by decide
def e2422373715194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373715194 : Closed e2422373715194 ∧ code e2422373715194 = 11218466737402 := by decide
theorem cert_e2422373715194 : check e2422373715194 [[],[]] .three = true := by decide
def e2422373715518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 4))))))))
theorem wire_e2422373715518 : Closed e2422373715518 ∧ code e2422373715518 = 11218466737726 := by decide
theorem cert_e2422373715518 : check e2422373715518 [[],[]] .three = true := by decide
def e2422373715566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373715566 : Closed e2422373715566 ∧ code e2422373715566 = 11218466737774 := by decide
theorem cert_e2422373715566 : check e2422373715566 [[],[]] .smaller = true := by decide
def e2422373715578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373715578 : Closed e2422373715578 ∧ code e2422373715578 = 11218466737786 := by decide
theorem cert_e2422373715578 : check e2422373715578 [[],[]] .smaller = true := by decide
def e2422373715742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 3))))))))
theorem wire_e2422373715742 : Closed e2422373715742 ∧ code e2422373715742 = 11218466737950 := by decide
theorem cert_e2422373715742 : check e2422373715742 [[],[]] .smaller = true := by decide
def e2422373715766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373715766 : Closed e2422373715766 ∧ code e2422373715766 = 11218466737974 := by decide
theorem cert_e2422373715766 : check e2422373715766 [[],[]] .smaller = true := by decide
def e2422373715770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373715770 : Closed e2422373715770 ∧ code e2422373715770 = 11218466737978 := by decide
theorem cert_e2422373715770 : check e2422373715770 [[],[]] .smaller = true := by decide
def e2422373715854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.lam (.var 2))))))))
theorem wire_e2422373715854 : Closed e2422373715854 ∧ code e2422373715854 = 11218466738062 := by decide
theorem cert_e2422373715854 : check e2422373715854 [[],[]] .three = true := by decide
def e2422373715866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373715866 : Closed e2422373715866 ∧ code e2422373715866 = 11218466738074 := by decide
theorem cert_e2422373715866 : check e2422373715866 [[],[]] .three = true := by decide
def e2422373717678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2)))))))
theorem wire_e2422373717678 : Closed e2422373717678 ∧ code e2422373717678 = 11218466739886 := by decide
theorem cert_e2422373717678 : check e2422373717678 [[],[]] .smaller = true := by decide
def e2422373717690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e2422373717690 : Closed e2422373717690 ∧ code e2422373717690 = 11218466739898 := by decide
theorem cert_e2422373717690 : check e2422373717690 [[],[]] .smaller = true := by decide
def e2422373717738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373717738 : Closed e2422373717738 ∧ code e2422373717738 = 11218466739946 := by decide
theorem cert_e2422373717738 : check e2422373717738 [[],[]] .smaller = true := by decide
def e2422373717930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373717930 : Closed e2422373717930 ∧ code e2422373717930 = 11218466740138 := by decide
theorem cert_e2422373717930 : check e2422373717930 [[],[]] .smaller = true := by decide
def e2422373718062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 2)))))))
theorem wire_e2422373718062 : Closed e2422373718062 ∧ code e2422373718062 = 11218466740270 := by decide
theorem cert_e2422373718062 : check e2422373718062 [[],[]] .smaller = true := by decide
def e2422373718238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.var 3)))))))
theorem wire_e2422373718238 : Closed e2422373718238 ∧ code e2422373718238 = 11218466740446 := by decide
theorem cert_e2422373718238 : check e2422373718238 [[],[]] .three = true := by decide
def e2422373718254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 2)))))))
theorem wire_e2422373718254 : Closed e2422373718254 ∧ code e2422373718254 = 11218466740462 := by decide
theorem cert_e2422373718254 : check e2422373718254 [[],[]] .smaller = true := by decide
def e2422373718262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 1)))))))
theorem wire_e2422373718262 : Closed e2422373718262 ∧ code e2422373718262 = 11218466740470 := by decide
theorem cert_e2422373718262 : check e2422373718262 [[],[]] .smaller = true := by decide
def e2422373718266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))) (.var 0)))))))
theorem wire_e2422373718266 : Closed e2422373718266 ∧ code e2422373718266 = 11218466740474 := by decide
theorem cert_e2422373718266 : check e2422373718266 [[],[]] .three = true := by decide
def e2422373718446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e2422373718446 : Closed e2422373718446 ∧ code e2422373718446 = 11218466740654 := by decide
theorem cert_e2422373718446 : check e2422373718446 [[],[]] .smaller = true := by decide
def e2422373718458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422373718458 : Closed e2422373718458 ∧ code e2422373718458 = 11218466740666 := by decide
theorem cert_e2422373718458 : check e2422373718458 [[],[]] .smaller = true := by decide
def e2422373718506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422373718506 : Closed e2422373718506 ∧ code e2422373718506 = 11218466740714 := by decide
theorem cert_e2422373718506 : check e2422373718506 [[],[]] .smaller = true := by decide
def e2422373718590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 4))))))))
theorem wire_e2422373718590 : Closed e2422373718590 ∧ code e2422373718590 = 11218466740798 := by decide
theorem cert_e2422373718590 : check e2422373718590 [[],[]] .three = true := by decide
def e2422373718638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373718638 : Closed e2422373718638 ∧ code e2422373718638 = 11218466740846 := by decide
theorem cert_e2422373718638 : check e2422373718638 [[],[]] .smaller = true := by decide
def e2422373718650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373718650 : Closed e2422373718650 ∧ code e2422373718650 = 11218466740858 := by decide
theorem cert_e2422373718650 : check e2422373718650 [[],[]] .smaller = true := by decide
def e2422373718814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 3))))))))
theorem wire_e2422373718814 : Closed e2422373718814 ∧ code e2422373718814 = 11218466741022 := by decide
theorem cert_e2422373718814 : check e2422373718814 [[],[]] .smaller = true := by decide
def e2422373718914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373718914 : Closed e2422373718914 ∧ code e2422373718914 = 11218466741122 := by decide
theorem cert_e2422373718914 : check e2422373718914 [[],[]] .smaller = true := by decide
def e2422373718926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 2))))))))
theorem wire_e2422373718926 : Closed e2422373718926 ∧ code e2422373718926 = 11218466741134 := by decide
theorem cert_e2422373718926 : check e2422373718926 [[],[]] .smaller = true := by decide
def e2422373718938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373718938 : Closed e2422373718938 ∧ code e2422373718938 = 11218466741146 := by decide
theorem cert_e2422373718938 : check e2422373718938 [[],[]] .smaller = true := by decide
def e2422373718982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.lam (.var 1))))))))
theorem wire_e2422373718982 : Closed e2422373718982 ∧ code e2422373718982 = 11218466741190 := by decide
theorem cert_e2422373718982 : check e2422373718982 [[],[]] .three = true := by decide
def e2422373719006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 3)))))))
theorem wire_e2422373719006 : Closed e2422373719006 ∧ code e2422373719006 = 11218466741214 := by decide
theorem cert_e2422373719006 : check e2422373719006 [[],[]] .three = true := by decide
def e2422373719134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 3)))))))
theorem wire_e2422373719134 : Closed e2422373719134 ∧ code e2422373719134 = 11218466741342 := by decide
theorem cert_e2422373719134 : check e2422373719134 [[],[]] .three = true := by decide
def e2422373719150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 2)))))))
theorem wire_e2422373719150 : Closed e2422373719150 ∧ code e2422373719150 = 11218466741358 := by decide
theorem cert_e2422373719150 : check e2422373719150 [[],[]] .smaller = true := by decide
def e2422373719162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422373719162 : Closed e2422373719162 ∧ code e2422373719162 = 11218466741370 := by decide
theorem cert_e2422373719162 : check e2422373719162 [[],[]] .smaller = true := by decide
def e2422373719326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 3))))))))
theorem wire_e2422373719326 : Closed e2422373719326 ∧ code e2422373719326 = 11218466741534 := by decide
theorem cert_e2422373719326 : check e2422373719326 [[],[]] .smaller = true := by decide
def e2422373719494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422373719494 : Closed e2422373719494 ∧ code e2422373719494 = 11218466741702 := by decide
theorem cert_e2422373719494 : check e2422373719494 [[],[]] .smaller = true := by decide
def e2422373719518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e2422373719518 : Closed e2422373719518 ∧ code e2422373719518 = 11218466741726 := by decide
theorem cert_e2422373719518 : check e2422373719518 [[],[]] .three = true := by decide
def e2422373719522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))) (.lam (.var 0))))))))
theorem wire_e2422373719522 : Closed e2422373719522 ∧ code e2422373719522 = 11218466741730 := by decide
theorem cert_e2422373719522 : check e2422373719522 [[],[]] .three = true := by decide
def e2422373719534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 2)))))))
theorem wire_e2422373719534 : Closed e2422373719534 ∧ code e2422373719534 = 11218466741742 := by decide
theorem cert_e2422373719534 : check e2422373719534 [[],[]] .three = true := by decide
def e2422373719562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 0)))))))
theorem wire_e2422373719562 : Closed e2422373719562 ∧ code e2422373719562 = 11218466741770 := by decide
theorem cert_e2422373719562 : check e2422373719562 [[],[]] .smaller = true := by decide
def e2422373719598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373719598 : Closed e2422373719598 ∧ code e2422373719598 = 11218466741806 := by decide
theorem cert_e2422373719598 : check e2422373719598 [[],[]] .smaller = true := by decide
def e2422373719606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e2422373719606 : Closed e2422373719606 ∧ code e2422373719606 = 11218466741814 := by decide
theorem cert_e2422373719606 : check e2422373719606 [[],[]] .smaller = true := by decide
def e2422373719610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373719610 : Closed e2422373719610 ∧ code e2422373719610 = 11218466741818 := by decide
theorem cert_e2422373719610 : check e2422373719610 [[],[]] .smaller = true := by decide
def e2422373719658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373719658 : Closed e2422373719658 ∧ code e2422373719658 = 11218466741866 := by decide
theorem cert_e2422373719658 : check e2422373719658 [[],[]] .smaller = true := by decide
def e2422373719682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373719682 : Closed e2422373719682 ∧ code e2422373719682 = 11218466741890 := by decide
theorem cert_e2422373719682 : check e2422373719682 [[],[]] .smaller = true := by decide
def e2422373719694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e2422373719694 : Closed e2422373719694 ∧ code e2422373719694 = 11218466741902 := by decide
theorem cert_e2422373719694 : check e2422373719694 [[],[]] .smaller = true := by decide
def e2422373719706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373719706 : Closed e2422373719706 ∧ code e2422373719706 = 11218466741914 := by decide
theorem cert_e2422373719706 : check e2422373719706 [[],[]] .smaller = true := by decide
def e2422373719750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373719750 : Closed e2422373719750 ∧ code e2422373719750 = 11218466741958 := by decide
theorem cert_e2422373719750 : check e2422373719750 [[],[]] .smaller = true := by decide
def e2422373719774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e2422373719774 : Closed e2422373719774 ∧ code e2422373719774 = 11218466741982 := by decide
theorem cert_e2422373719774 : check e2422373719774 [[],[]] .three = true := by decide
def e2422373719778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373719778 : Closed e2422373719778 ∧ code e2422373719778 = 11218466741986 := by decide
theorem cert_e2422373719778 : check e2422373719778 [[],[]] .smaller = true := by decide
def e2422373719790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 2)))))))
theorem wire_e2422373719790 : Closed e2422373719790 ∧ code e2422373719790 = 11218466741998 := by decide
theorem cert_e2422373719790 : check e2422373719790 [[],[]] .smaller = true := by decide
def e2422373719798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e2422373719798 : Closed e2422373719798 ∧ code e2422373719798 = 11218466742006 := by decide
theorem cert_e2422373719798 : check e2422373719798 [[],[]] .three = true := by decide
def e2422373719830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373719830 : Closed e2422373719830 ∧ code e2422373719830 = 11218466742038 := by decide
theorem cert_e2422373719830 : check e2422373719830 [[],[]] .three = true := by decide
def e2422373719834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e2422373719834 : Closed e2422373719834 ∧ code e2422373719834 = 11218466742042 := by decide
theorem cert_e2422373719834 : check e2422373719834 [[],[]] .three = true := by decide
def e2422373719878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e2422373719878 : Closed e2422373719878 ∧ code e2422373719878 = 11218466742086 := by decide
theorem cert_e2422373719878 : check e2422373719878 [[],[]] .three = true := by decide
def e2422373719902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 3)))))))
theorem wire_e2422373719902 : Closed e2422373719902 ∧ code e2422373719902 = 11218466742110 := by decide
theorem cert_e2422373719902 : check e2422373719902 [[],[]] .three = true := by decide
def e2422373719906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422373719906 : Closed e2422373719906 ∧ code e2422373719906 = 11218466742114 := by decide
theorem cert_e2422373719906 : check e2422373719906 [[],[]] .three = true := by decide
def e2422373719918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 2)))))))
theorem wire_e2422373719918 : Closed e2422373719918 ∧ code e2422373719918 = 11218466742126 := by decide
theorem cert_e2422373719918 : check e2422373719918 [[],[]] .three = true := by decide
def e2422373719926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e2422373719926 : Closed e2422373719926 ∧ code e2422373719926 = 11218466742134 := by decide
theorem cert_e2422373719926 : check e2422373719926 [[],[]] .three = true := by decide
def e2422373719930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 3)))) (.var 0)))))))
theorem wire_e2422373719930 : Closed e2422373719930 ∧ code e2422373719930 = 11218466742138 := by decide
theorem cert_e2422373719930 : check e2422373719930 [[],[]] .three = true := by decide
def e2422373720510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422373720510 : Closed e2422373720510 ∧ code e2422373720510 = 11218466742718 := by decide
theorem cert_e2422373720510 : check e2422373720510 [[],[]] .three = true := by decide
def e2422373720542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373720542 : Closed e2422373720542 ∧ code e2422373720542 = 11218466742750 := by decide
theorem cert_e2422373720542 : check e2422373720542 [[],[]] .smaller = true := by decide
def e2422373720566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373720566 : Closed e2422373720566 ∧ code e2422373720566 = 11218466742774 := by decide
theorem cert_e2422373720566 : check e2422373720566 [[],[]] .smaller = true := by decide
def e2422373720570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422373720570 : Closed e2422373720570 ∧ code e2422373720570 = 11218466742778 := by decide
theorem cert_e2422373720570 : check e2422373720570 [[],[]] .three = true := by decide
def e2422373721518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422373721518 : Closed e2422373721518 ∧ code e2422373721518 = 11218466743726 := by decide
theorem cert_e2422373721518 : check e2422373721518 [[],[]] .smaller = true := by decide
def e2422373721530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422373721530 : Closed e2422373721530 ∧ code e2422373721530 = 11218466743738 := by decide
theorem cert_e2422373721530 : check e2422373721530 [[],[]] .smaller = true := by decide
def e2422373721578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422373721578 : Closed e2422373721578 ∧ code e2422373721578 = 11218466743786 := by decide
theorem cert_e2422373721578 : check e2422373721578 [[],[]] .smaller = true := by decide
def e2422373721662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422373721662 : Closed e2422373721662 ∧ code e2422373721662 = 11218466743870 := by decide
theorem cert_e2422373721662 : check e2422373721662 [[],[]] .three = true := by decide
def e2422373721710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373721710 : Closed e2422373721710 ∧ code e2422373721710 = 11218466743918 := by decide
theorem cert_e2422373721710 : check e2422373721710 [[],[]] .smaller = true := by decide
def e2422373721722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373721722 : Closed e2422373721722 ∧ code e2422373721722 = 11218466743930 := by decide
theorem cert_e2422373721722 : check e2422373721722 [[],[]] .smaller = true := by decide
def e2422373721886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422373721886 : Closed e2422373721886 ∧ code e2422373721886 = 11218466744094 := by decide
theorem cert_e2422373721886 : check e2422373721886 [[],[]] .smaller = true := by decide
def e2422373721986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373721986 : Closed e2422373721986 ∧ code e2422373721986 = 11218466744194 := by decide
theorem cert_e2422373721986 : check e2422373721986 [[],[]] .smaller = true := by decide
def e2422373721998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422373721998 : Closed e2422373721998 ∧ code e2422373721998 = 11218466744206 := by decide
theorem cert_e2422373721998 : check e2422373721998 [[],[]] .smaller = true := by decide
def e2422373722010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373722010 : Closed e2422373722010 ∧ code e2422373722010 = 11218466744218 := by decide
theorem cert_e2422373722010 : check e2422373722010 [[],[]] .smaller = true := by decide
def e2422373722054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422373722054 : Closed e2422373722054 ∧ code e2422373722054 = 11218466744262 := by decide
theorem cert_e2422373722054 : check e2422373722054 [[],[]] .three = true := by decide
def e2422373722078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 3))))))))
theorem wire_e2422373722078 : Closed e2422373722078 ∧ code e2422373722078 = 11218466744286 := by decide
theorem cert_e2422373722078 : check e2422373722078 [[],[]] .three = true := by decide
def e2422373724286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.lam (.var 5)))))))))
theorem wire_e2422373724286 : Closed e2422373724286 ∧ code e2422373724286 = 11218466746494 := by decide
theorem cert_e2422373724286 : check e2422373724286 [[],[]] .three = true := by decide
def e2422373724382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373724382 : Closed e2422373724382 ∧ code e2422373724382 = 11218466746590 := by decide
theorem cert_e2422373724382 : check e2422373724382 [[],[]] .smaller = true := by decide
def e2422373724410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373724410 : Closed e2422373724410 ∧ code e2422373724410 = 11218466746618 := by decide
theorem cert_e2422373724410 : check e2422373724410 [[],[]] .smaller = true := by decide
def e2422373724958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422373724958 : Closed e2422373724958 ∧ code e2422373724958 = 11218466747166 := by decide
theorem cert_e2422373724958 : check e2422373724958 [[],[]] .smaller = true := by decide
def e2422373725126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422373725126 : Closed e2422373725126 ∧ code e2422373725126 = 11218466747334 := by decide
theorem cert_e2422373725126 : check e2422373725126 [[],[]] .smaller = true := by decide
def e2422373725150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373725150 : Closed e2422373725150 ∧ code e2422373725150 = 11218466747358 := by decide
theorem cert_e2422373725150 : check e2422373725150 [[],[]] .three = true := by decide
def e2422373725154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422373725154 : Closed e2422373725154 ∧ code e2422373725154 = 11218466747362 := by decide
theorem cert_e2422373725154 : check e2422373725154 [[],[]] .three = true := by decide
def e2422373725166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373725166 : Closed e2422373725166 ∧ code e2422373725166 = 11218466747374 := by decide
theorem cert_e2422373725166 : check e2422373725166 [[],[]] .three = true := by decide
end Blc.Floor43
