import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2406153197978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2406153197978 : Closed e2406153197978 ∧ code e2406153197978 = 11202246220186 := by decide
theorem cert_e2406153197978 : check e2406153197978 [[]] .width = true := by decide
def e2406153198022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2406153198022 : Closed e2406153198022 ∧ code e2406153198022 = 11202246220230 := by decide
theorem cert_e2406153198022 : check e2406153198022 [[]] .width = true := by decide
def e2406153198622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2406153198622 : Closed e2406153198622 ∧ code e2406153198622 = 11202246220830 := by decide
theorem cert_e2406153198622 : check e2406153198622 [[]] .width = true := by decide
def e2406153198790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2406153198790 : Closed e2406153198790 ∧ code e2406153198790 = 11202246220998 := by decide
theorem cert_e2406153198790 : check e2406153198790 [[]] .width = true := by decide
def e2406153198818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2406153198818 : Closed e2406153198818 ∧ code e2406153198818 = 11202246221026 := by decide
theorem cert_e2406153198818 : check e2406153198818 [[]] .width = true := by decide
def e2406153213482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2406153213482 : Closed e2406153213482 ∧ code e2406153213482 = 11202246235690 := by decide
theorem cert_e2406153213482 : check e2406153213482 [[]] .width = true := by decide
def e2406153213578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2406153213578 : Closed e2406153213578 ∧ code e2406153213578 = 11202246235786 := by decide
theorem cert_e2406153213578 : check e2406153213578 [[]] .width = true := by decide
def e2406153213602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406153213602 : Closed e2406153213602 ∧ code e2406153213602 = 11202246235810 := by decide
theorem cert_e2406153213602 : check e2406153213602 [[]] .width = true := by decide
def e2406153213962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2406153213962 : Closed e2406153213962 ∧ code e2406153213962 = 11202246236170 := by decide
theorem cert_e2406153213962 : check e2406153213962 [[]] .width = true := by decide
def e2406153214010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2406153214010 : Closed e2406153214010 ∧ code e2406153214010 = 11202246236218 := by decide
theorem cert_e2406153214010 : check e2406153214010 [[]] .width = true := by decide
def e2406153214058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2406153214058 : Closed e2406153214058 ∧ code e2406153214058 = 11202246236266 := by decide
theorem cert_e2406153214058 : check e2406153214058 [[]] .width = true := by decide
def e2406153214106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2406153214106 : Closed e2406153214106 ∧ code e2406153214106 = 11202246236314 := by decide
theorem cert_e2406153214106 : check e2406153214106 [[]] .width = true := by decide
def e2406153214150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2406153214150 : Closed e2406153214150 ∧ code e2406153214150 = 11202246236358 := by decide
theorem cert_e2406153214150 : check e2406153214150 [[]] .width = true := by decide
def e2406153214346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2406153214346 : Closed e2406153214346 ∧ code e2406153214346 = 11202246236554 := by decide
theorem cert_e2406153214346 : check e2406153214346 [[]] .width = true := by decide
def e2406153214370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2406153214370 : Closed e2406153214370 ∧ code e2406153214370 = 11202246236578 := by decide
theorem cert_e2406153214370 : check e2406153214370 [[]] .width = true := by decide
def e2406153214466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2406153214466 : Closed e2406153214466 ∧ code e2406153214466 = 11202246236674 := by decide
theorem cert_e2406153214466 : check e2406153214466 [[]] .width = true := by decide
def e2406153214478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2406153214478 : Closed e2406153214478 ∧ code e2406153214478 = 11202246236686 := by decide
theorem cert_e2406153214478 : check e2406153214478 [[]] .width = true := by decide
def e2406153214490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406153214490 : Closed e2406153214490 ∧ code e2406153214490 = 11202246236698 := by decide
theorem cert_e2406153214490 : check e2406153214490 [[]] .width = true := by decide
def e2406153214562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406153214562 : Closed e2406153214562 ∧ code e2406153214562 = 11202246236770 := by decide
theorem cert_e2406153214562 : check e2406153214562 [[]] .width = true := by decide
def e2406153216026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406153216026 : Closed e2406153216026 ∧ code e2406153216026 = 11202246238234 := by decide
theorem cert_e2406153216026 : check e2406153216026 [[]] .width = true := by decide
def e2406153216110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2406153216110 : Closed e2406153216110 ∧ code e2406153216110 = 11202246238318 := by decide
theorem cert_e2406153216110 : check e2406153216110 [[]] .width = true := by decide
def e2406153216118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406153216118 : Closed e2406153216118 ∧ code e2406153216118 = 11202246238326 := by decide
theorem cert_e2406153216118 : check e2406153216118 [[]] .width = true := by decide
def e2406153216122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2406153216122 : Closed e2406153216122 ∧ code e2406153216122 = 11202246238330 := by decide
theorem cert_e2406153216122 : check e2406153216122 [[]] .width = true := by decide
def e2406153216362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2406153216362 : Closed e2406153216362 ∧ code e2406153216362 = 11202246238570 := by decide
theorem cert_e2406153216362 : check e2406153216362 [[]] .width = true := by decide
def e2406153216398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2406153216398 : Closed e2406153216398 ∧ code e2406153216398 = 11202246238606 := by decide
theorem cert_e2406153216398 : check e2406153216398 [[]] .width = true := by decide
def e2406153216410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2406153216410 : Closed e2406153216410 ∧ code e2406153216410 = 11202246238618 := by decide
theorem cert_e2406153216410 : check e2406153216410 [[]] .width = true := by decide
def e2406153216454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2406153216454 : Closed e2406153216454 ∧ code e2406153216454 = 11202246238662 := by decide
theorem cert_e2406153216454 : check e2406153216454 [[]] .width = true := by decide
def e2406153217418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2406153217418 : Closed e2406153217418 ∧ code e2406153217418 = 11202246239626 := by decide
theorem cert_e2406153217418 : check e2406153217418 [[]] .width = true := by decide
def e2406153217442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2406153217442 : Closed e2406153217442 ∧ code e2406153217442 = 11202246239650 := by decide
theorem cert_e2406153217442 : check e2406153217442 [[]] .width = true := by decide
def e2406153217538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2406153217538 : Closed e2406153217538 ∧ code e2406153217538 = 11202246239746 := by decide
theorem cert_e2406153217538 : check e2406153217538 [[]] .width = true := by decide
def e2406153217550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2406153217550 : Closed e2406153217550 ∧ code e2406153217550 = 11202246239758 := by decide
theorem cert_e2406153217550 : check e2406153217550 [[]] .width = true := by decide
def e2406153217562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406153217562 : Closed e2406153217562 ∧ code e2406153217562 = 11202246239770 := by decide
theorem cert_e2406153217562 : check e2406153217562 [[]] .width = true := by decide
def e2406153217634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2406153217634 : Closed e2406153217634 ∧ code e2406153217634 = 11202246239842 := by decide
theorem cert_e2406153217634 : check e2406153217634 [[]] .width = true := by decide
def e2406153263618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2406153263618 : Closed e2406153263618 ∧ code e2406153263618 = 11202246285826 := by decide
theorem cert_e2406153263618 : check e2406153263618 [[]] .width = true := by decide
def e2406153263642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406153263642 : Closed e2406153263642 ∧ code e2406153263642 = 11202246285850 := by decide
theorem cert_e2406153263642 : check e2406153263642 [[]] .width = true := by decide
def e2406189332506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406189332506 : Closed e2406189332506 ∧ code e2406189332506 = 11202282354714 := by decide
theorem cert_e2406189332506 : check e2406189332506 [[]] .width = true := by decide
def e2406189348890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406189348890 : Closed e2406189348890 ∧ code e2406189348890 = 11202282371098 := by decide
theorem cert_e2406189348890 : check e2406189348890 [[]] .width = true := by decide
def e2406191314970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406191314970 : Closed e2406191314970 ∧ code e2406191314970 = 11202284337178 := by decide
theorem cert_e2406191314970 : check e2406191314970 [[],[]] .smaller = true := by decide
def e2406191323162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406191323162 : Closed e2406191323162 ∧ code e2406191323162 = 11202284345370 := by decide
theorem cert_e2406191323162 : check e2406191323162 [[],[]] .smaller = true := by decide
def e2406191324698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406191324698 : Closed e2406191324698 ∧ code e2406191324698 = 11202284346906 := by decide
private def t_e2406191324698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406191324698 : ¬ IsSelfInterpreter e2406191324698 :=
  wSource (t := t_e2406191324698) (replay_sound (ps := []) (t := e2406191324698) (by decide)) (by decide)
def e2406191328794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406191328794 : Closed e2406191328794 ∧ code e2406191328794 = 11202284351002 := by decide
private def t_e2406191328794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406191328794 : ¬ IsSelfInterpreter e2406191328794 :=
  wSource (t := t_e2406191328794) (replay_sound (ps := []) (t := e2406191328794) (by decide)) (by decide)
def e2406191380506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406191380506 : Closed e2406191380506 ∧ code e2406191380506 = 11202284402714 := by decide
theorem cert_e2406191380506 : check e2406191380506 [[],[]] .smaller = true := by decide
def e2406191392794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406191392794 : Closed e2406191392794 ∧ code e2406191392794 = 11202284415002 := by decide
theorem cert_e2406191392794 : check e2406191392794 [[],[]] .smaller = true := by decide
def e2406191421466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406191421466 : Closed e2406191421466 ∧ code e2406191421466 = 11202284443674 := by decide
theorem cert_e2406191421466 : check e2406191421466 [[],[]] .smaller = true := by decide
def e2406191423002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406191423002 : Closed e2406191423002 ∧ code e2406191423002 = 11202284445210 := by decide
private def t_e2406191423002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406191423002 : ¬ IsSelfInterpreter e2406191423002 :=
  wSource (t := t_e2406191423002) (replay_sound (ps := []) (t := e2406191423002) (by decide)) (by decide)
def e2406191425562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406191425562 : Closed e2406191425562 ∧ code e2406191425562 = 11202284447770 := by decide
theorem cert_e2406191425562 : check e2406191425562 [[],[]] .smaller = true := by decide
def e2406191430170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406191430170 : Closed e2406191430170 ∧ code e2406191430170 = 11202284452378 := by decide
private def t_e2406191430170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406191430170 : ¬ IsSelfInterpreter e2406191430170 :=
  wSource (t := t_e2406191430170) (replay_sound (ps := []) (t := e2406191430170) (by decide)) (by decide)
def e2406191443482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406191443482 : Closed e2406191443482 ∧ code e2406191443482 = 11202284465690 := by decide
private def t_e2406191443482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406191443482 : ¬ IsSelfInterpreter e2406191443482 :=
  wSource (t := t_e2406191443482) (replay_sound (ps := []) (t := e2406191443482) (by decide)) (by decide)
def e2406191446554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406191446554 : Closed e2406191446554 ∧ code e2406191446554 = 11202284468762 := by decide
private def t_e2406191446554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406191446554 : ¬ IsSelfInterpreter e2406191446554 :=
  wSource (t := t_e2406191446554) (replay_sound (ps := []) (t := e2406191446554) (by decide)) (by decide)
def e2406191708186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406191708186 : Closed e2406191708186 ∧ code e2406191708186 = 11202284730394 := by decide
theorem cert_e2406191708186 : check e2406191708186 [[],[]] .smaller = true := by decide
def e2406191716378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406191716378 : Closed e2406191716378 ∧ code e2406191716378 = 11202284738586 := by decide
theorem cert_e2406191716378 : check e2406191716378 [[],[]] .smaller = true := by decide
def e2406191717914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406191717914 : Closed e2406191717914 ∧ code e2406191717914 = 11202284740122 := by decide
private def t_e2406191717914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406191717914 : ¬ IsSelfInterpreter e2406191717914 :=
  wSource (t := t_e2406191717914) (replay_sound (ps := []) (t := e2406191717914) (by decide)) (by decide)
def e2406191722010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406191722010 : Closed e2406191722010 ∧ code e2406191722010 = 11202284744218 := by decide
private def t_e2406191722010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406191722010 : ¬ IsSelfInterpreter e2406191722010 :=
  wSource (t := t_e2406191722010) (replay_sound (ps := []) (t := e2406191722010) (by decide)) (by decide)
def e2406192050374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406192050374 : Closed e2406192050374 ∧ code e2406192050374 = 11202285072582 := by decide
theorem cert_e2406192050374 : check e2406192050374 [[]] .width = true := by decide
def e2406192101402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406192101402 : Closed e2406192101402 ∧ code e2406192101402 = 11202285123610 := by decide
theorem cert_e2406192101402 : check e2406192101402 [[],[]] .smaller = true := by decide
def e2406192113690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406192113690 : Closed e2406192113690 ∧ code e2406192113690 = 11202285135898 := by decide
theorem cert_e2406192113690 : check e2406192113690 [[],[]] .smaller = true := by decide
def e2406192218138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406192218138 : Closed e2406192218138 ∧ code e2406192218138 = 11202285240346 := by decide
theorem cert_e2406192218138 : check e2406192218138 [[]] .width = true := by decide
def e2406192218230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406192218230 : Closed e2406192218230 ∧ code e2406192218230 = 11202285240438 := by decide
theorem cert_e2406192218230 : check e2406192218230 [[]] .width = true := by decide
def e2406192218474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406192218474 : Closed e2406192218474 ∧ code e2406192218474 = 11202285240682 := by decide
theorem cert_e2406192218474 : check e2406192218474 [[]] .width = true := by decide
def e2406192218522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406192218522 : Closed e2406192218522 ∧ code e2406192218522 = 11202285240730 := by decide
theorem cert_e2406192218522 : check e2406192218522 [[]] .width = true := by decide
def e2406192219530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406192219530 : Closed e2406192219530 ∧ code e2406192219530 = 11202285241738 := by decide
theorem cert_e2406192219530 : check e2406192219530 [[]] .width = true := by decide
def e2406192219554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406192219554 : Closed e2406192219554 ∧ code e2406192219554 = 11202285241762 := by decide
theorem cert_e2406192219554 : check e2406192219554 [[]] .width = true := by decide
def e2406192219662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406192219662 : Closed e2406192219662 ∧ code e2406192219662 = 11202285241870 := by decide
theorem cert_e2406192219662 : check e2406192219662 [[]] .width = true := by decide
def e2406192219674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406192219674 : Closed e2406192219674 ∧ code e2406192219674 = 11202285241882 := by decide
theorem cert_e2406192219674 : check e2406192219674 [[]] .width = true := by decide
def e2406192219746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406192219746 : Closed e2406192219746 ∧ code e2406192219746 = 11202285241954 := by decide
theorem cert_e2406192219746 : check e2406192219746 [[]] .width = true := by decide
def e2406192279750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406192279750 : Closed e2406192279750 ∧ code e2406192279750 = 11202285301958 := by decide
theorem cert_e2406192279750 : check e2406192279750 [[]] .width = true := by decide
def e2406192306202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406192306202 : Closed e2406192306202 ∧ code e2406192306202 = 11202285328410 := by decide
theorem cert_e2406192306202 : check e2406192306202 [[],[]] .smaller = true := by decide
def e2406192307738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406192307738 : Closed e2406192307738 ∧ code e2406192307738 = 11202285329946 := by decide
private def t_e2406192307738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406192307738 : ¬ IsSelfInterpreter e2406192307738 :=
  wSource (t := t_e2406192307738) (replay_sound (ps := []) (t := e2406192307738) (by decide)) (by decide)
def e2406192310298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406192310298 : Closed e2406192310298 ∧ code e2406192310298 = 11202285332506 := by decide
theorem cert_e2406192310298 : check e2406192310298 [[],[]] .smaller = true := by decide
def e2406192314906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406192314906 : Closed e2406192314906 ∧ code e2406192314906 = 11202285337114 := by decide
private def t_e2406192314906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406192314906 : ¬ IsSelfInterpreter e2406192314906 :=
  wSource (t := t_e2406192314906) (replay_sound (ps := []) (t := e2406192314906) (by decide)) (by decide)
def e2406192349210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406192349210 : Closed e2406192349210 ∧ code e2406192349210 = 11202285371418 := by decide
theorem cert_e2406192349210 : check e2406192349210 [[]] .width = true := by decide
def e2406192349302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406192349302 : Closed e2406192349302 ∧ code e2406192349302 = 11202285371510 := by decide
theorem cert_e2406192349302 : check e2406192349302 [[]] .width = true := by decide
def e2406192349546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406192349546 : Closed e2406192349546 ∧ code e2406192349546 = 11202285371754 := by decide
theorem cert_e2406192349546 : check e2406192349546 [[]] .width = true := by decide
def e2406192349594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406192349594 : Closed e2406192349594 ∧ code e2406192349594 = 11202285371802 := by decide
theorem cert_e2406192349594 : check e2406192349594 [[]] .width = true := by decide
def e2406192350602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406192350602 : Closed e2406192350602 ∧ code e2406192350602 = 11202285372810 := by decide
theorem cert_e2406192350602 : check e2406192350602 [[]] .width = true := by decide
def e2406192350626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406192350626 : Closed e2406192350626 ∧ code e2406192350626 = 11202285372834 := by decide
theorem cert_e2406192350626 : check e2406192350626 [[]] .width = true := by decide
def e2406192350734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406192350734 : Closed e2406192350734 ∧ code e2406192350734 = 11202285372942 := by decide
theorem cert_e2406192350734 : check e2406192350734 [[]] .width = true := by decide
def e2406192350746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406192350746 : Closed e2406192350746 ∧ code e2406192350746 = 11202285372954 := by decide
theorem cert_e2406192350746 : check e2406192350746 [[]] .width = true := by decide
def e2406192350818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406192350818 : Closed e2406192350818 ∧ code e2406192350818 = 11202285373026 := by decide
theorem cert_e2406192350818 : check e2406192350818 [[]] .width = true := by decide
def e2406192410138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406192410138 : Closed e2406192410138 ∧ code e2406192410138 = 11202285432346 := by decide
private def t_e2406192410138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406192410138 : ¬ IsSelfInterpreter e2406192410138 :=
  wSource (t := t_e2406192410138) (replay_sound (ps := []) (t := e2406192410138) (by decide)) (by decide)
def e2406192413210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406192413210 : Closed e2406192413210 ∧ code e2406192413210 = 11202285435418 := by decide
private def t_e2406192413210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406192413210 : ¬ IsSelfInterpreter e2406192413210 :=
  wSource (t := t_e2406192413210) (replay_sound (ps := []) (t := e2406192413210) (by decide)) (by decide)
def e2406199679002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406199679002 : Closed e2406199679002 ∧ code e2406199679002 = 11202292701210 := by decide
theorem cert_e2406199679002 : check e2406199679002 [[]] .width = true := by decide
def e2406199683098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406199683098 : Closed e2406199683098 ∧ code e2406199683098 = 11202292705306 := by decide
theorem cert_e2406199683098 : check e2406199683098 [[]] .width = true := by decide
def e2406199684634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199684634 : Closed e2406199684634 ∧ code e2406199684634 = 11202292706842 := by decide
theorem cert_e2406199684634 : check e2406199684634 [[]] .width = true := by decide
def e2406199686682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199686682 : Closed e2406199686682 ∧ code e2406199686682 = 11202292708890 := by decide
theorem cert_e2406199686682 : check e2406199686682 [[]] .width = true := by decide
def e2406199699482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406199699482 : Closed e2406199699482 ∧ code e2406199699482 = 11202292721690 := by decide
theorem cert_e2406199699482 : check e2406199699482 [[]] .width = true := by decide
def e2406199701018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199701018 : Closed e2406199701018 ∧ code e2406199701018 = 11202292723226 := by decide
theorem cert_e2406199701018 : check e2406199701018 [[]] .width = true := by decide
def e2406199704090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199704090 : Closed e2406199704090 ∧ code e2406199704090 = 11202292726298 := by decide
theorem cert_e2406199704090 : check e2406199704090 [[]] .width = true := by decide
def e2406199711258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199711258 : Closed e2406199711258 ∧ code e2406199711258 = 11202292733466 := by decide
theorem cert_e2406199711258 : check e2406199711258 [[]] .width = true := by decide
def e2406199712282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199712282 : Closed e2406199712282 ∧ code e2406199712282 = 11202292734490 := by decide
theorem cert_e2406199712282 : check e2406199712282 [[]] .width = true := by decide
def e2406199765018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406199765018 : Closed e2406199765018 ∧ code e2406199765018 = 11202292787226 := by decide
theorem cert_e2406199765018 : check e2406199765018 [[]] .width = true := by decide
def e2406199766554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199766554 : Closed e2406199766554 ∧ code e2406199766554 = 11202292788762 := by decide
theorem cert_e2406199766554 : check e2406199766554 [[]] .width = true := by decide
def e2406199769626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199769626 : Closed e2406199769626 ∧ code e2406199769626 = 11202292791834 := by decide
theorem cert_e2406199769626 : check e2406199769626 [[]] .width = true := by decide
def e2406199781914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199781914 : Closed e2406199781914 ∧ code e2406199781914 = 11202292804122 := by decide
private def t_e2406199781914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406199781914 : ¬ IsSelfInterpreter e2406199781914 :=
  wSource (t := t_e2406199781914) (replay_sound (ps := []) (t := e2406199781914) (by decide)) (by decide)
def e2406199809562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199809562 : Closed e2406199809562 ∧ code e2406199809562 = 11202292831770 := by decide
theorem cert_e2406199809562 : check e2406199809562 [[]] .width = true := by decide
def e2406199810586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199810586 : Closed e2406199810586 ∧ code e2406199810586 = 11202292832794 := by decide
theorem cert_e2406199810586 : check e2406199810586 [[]] .width = true := by decide
def e2406199814682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406199814682 : Closed e2406199814682 ∧ code e2406199814682 = 11202292836890 := by decide
private def t_e2406199814682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406199814682 : ¬ IsSelfInterpreter e2406199814682 :=
  wSource (t := t_e2406199814682) (replay_sound (ps := []) (t := e2406199814682) (by decide)) (by decide)
def e2406199875610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406199875610 : Closed e2406199875610 ∧ code e2406199875610 = 11202292897818 := by decide
theorem cert_e2406199875610 : check e2406199875610 [[]] .width = true := by decide
def e2406199943194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406199943194 : Closed e2406199943194 ∧ code e2406199943194 = 11202292965402 := by decide
theorem cert_e2406199943194 : check e2406199943194 [[]] .width = true := by decide
def e2406199943286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406199943286 : Closed e2406199943286 ∧ code e2406199943286 = 11202292965494 := by decide
theorem cert_e2406199943286 : check e2406199943286 [[]] .width = true := by decide
def e2406199943530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406199943530 : Closed e2406199943530 ∧ code e2406199943530 = 11202292965738 := by decide
theorem cert_e2406199943530 : check e2406199943530 [[]] .width = true := by decide
def e2406199943578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406199943578 : Closed e2406199943578 ∧ code e2406199943578 = 11202292965786 := by decide
theorem cert_e2406199943578 : check e2406199943578 [[]] .width = true := by decide
def e2406199963846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406199963846 : Closed e2406199963846 ∧ code e2406199963846 = 11202292986054 := by decide
theorem cert_e2406199963846 : check e2406199963846 [[]] .width = true := by decide
def e2406199972038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406199972038 : Closed e2406199972038 ∧ code e2406199972038 = 11202292994246 := by decide
theorem cert_e2406199972038 : check e2406199972038 [[]] .width = true := by decide
def e2406199973914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406199973914 : Closed e2406199973914 ∧ code e2406199973914 = 11202292996122 := by decide
theorem cert_e2406199973914 : check e2406199973914 [[]] .width = true := by decide
def e2406200072218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200072218 : Closed e2406200072218 ∧ code e2406200072218 = 11202293094426 := by decide
theorem cert_e2406200072218 : check e2406200072218 [[]] .width = true := by decide
def e2406200076314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200076314 : Closed e2406200076314 ∧ code e2406200076314 = 11202293098522 := by decide
theorem cert_e2406200076314 : check e2406200076314 [[]] .width = true := by decide
def e2406200077850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200077850 : Closed e2406200077850 ∧ code e2406200077850 = 11202293100058 := by decide
theorem cert_e2406200077850 : check e2406200077850 [[]] .width = true := by decide
def e2406200079898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200079898 : Closed e2406200079898 ∧ code e2406200079898 = 11202293102106 := by decide
theorem cert_e2406200079898 : check e2406200079898 [[]] .width = true := by decide
def e2406200092698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200092698 : Closed e2406200092698 ∧ code e2406200092698 = 11202293114906 := by decide
theorem cert_e2406200092698 : check e2406200092698 [[]] .width = true := by decide
def e2406200094234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200094234 : Closed e2406200094234 ∧ code e2406200094234 = 11202293116442 := by decide
theorem cert_e2406200094234 : check e2406200094234 [[]] .width = true := by decide
def e2406200097306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200097306 : Closed e2406200097306 ∧ code e2406200097306 = 11202293119514 := by decide
theorem cert_e2406200097306 : check e2406200097306 [[]] .width = true := by decide
def e2406200104474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200104474 : Closed e2406200104474 ∧ code e2406200104474 = 11202293126682 := by decide
theorem cert_e2406200104474 : check e2406200104474 [[]] .width = true := by decide
def e2406200105498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200105498 : Closed e2406200105498 ∧ code e2406200105498 = 11202293127706 := by decide
theorem cert_e2406200105498 : check e2406200105498 [[]] .width = true := by decide
def e2406200144070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406200144070 : Closed e2406200144070 ∧ code e2406200144070 = 11202293166278 := by decide
theorem cert_e2406200144070 : check e2406200144070 [[]] .width = true := by decide
def e2406200170522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200170522 : Closed e2406200170522 ∧ code e2406200170522 = 11202293192730 := by decide
theorem cert_e2406200170522 : check e2406200170522 [[]] .width = true := by decide
def e2406200174618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200174618 : Closed e2406200174618 ∧ code e2406200174618 = 11202293196826 := by decide
theorem cert_e2406200174618 : check e2406200174618 [[]] .width = true := by decide
def e2406200176154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200176154 : Closed e2406200176154 ∧ code e2406200176154 = 11202293198362 := by decide
theorem cert_e2406200176154 : check e2406200176154 [[]] .width = true := by decide
def e2406200178202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200178202 : Closed e2406200178202 ∧ code e2406200178202 = 11202293200410 := by decide
theorem cert_e2406200178202 : check e2406200178202 [[]] .width = true := by decide
def e2406200213530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406200213530 : Closed e2406200213530 ∧ code e2406200213530 = 11202293235738 := by decide
theorem cert_e2406200213530 : check e2406200213530 [[]] .width = true := by decide
def e2406200213622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406200213622 : Closed e2406200213622 ∧ code e2406200213622 = 11202293235830 := by decide
theorem cert_e2406200213622 : check e2406200213622 [[]] .width = true := by decide
def e2406200213866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406200213866 : Closed e2406200213866 ∧ code e2406200213866 = 11202293236074 := by decide
theorem cert_e2406200213866 : check e2406200213866 [[]] .width = true := by decide
def e2406200213914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406200213914 : Closed e2406200213914 ∧ code e2406200213914 = 11202293236122 := by decide
theorem cert_e2406200213914 : check e2406200213914 [[]] .width = true := by decide
def e2406200214922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406200214922 : Closed e2406200214922 ∧ code e2406200214922 = 11202293237130 := by decide
theorem cert_e2406200214922 : check e2406200214922 [[]] .width = true := by decide
def e2406200214946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406200214946 : Closed e2406200214946 ∧ code e2406200214946 = 11202293237154 := by decide
theorem cert_e2406200214946 : check e2406200214946 [[]] .width = true := by decide
def e2406200215054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406200215054 : Closed e2406200215054 ∧ code e2406200215054 = 11202293237262 := by decide
theorem cert_e2406200215054 : check e2406200215054 [[]] .width = true := by decide
def e2406200215066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200215066 : Closed e2406200215066 ∧ code e2406200215066 = 11202293237274 := by decide
theorem cert_e2406200215066 : check e2406200215066 [[]] .width = true := by decide
def e2406200215138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406200215138 : Closed e2406200215138 ∧ code e2406200215138 = 11202293237346 := by decide
theorem cert_e2406200215138 : check e2406200215138 [[]] .width = true := by decide
def e2406200248346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200248346 : Closed e2406200248346 ∧ code e2406200248346 = 11202293270554 := by decide
theorem cert_e2406200248346 : check e2406200248346 [[]] .width = true := by decide
def e2406200254490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200254490 : Closed e2406200254490 ∧ code e2406200254490 = 11202293276698 := by decide
theorem cert_e2406200254490 : check e2406200254490 [[]] .width = true := by decide
def e2406200254582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406200254582 : Closed e2406200254582 ∧ code e2406200254582 = 11202293276790 := by decide
theorem cert_e2406200254582 : check e2406200254582 [[]] .width = true := by decide
def e2406200254826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406200254826 : Closed e2406200254826 ∧ code e2406200254826 = 11202293277034 := by decide
theorem cert_e2406200254826 : check e2406200254826 [[]] .width = true := by decide
def e2406200254874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406200254874 : Closed e2406200254874 ∧ code e2406200254874 = 11202293277082 := by decide
theorem cert_e2406200254874 : check e2406200254874 [[]] .width = true := by decide
def e2406200258758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406200258758 : Closed e2406200258758 ∧ code e2406200258758 = 11202293280966 := by decide
theorem cert_e2406200258758 : check e2406200258758 [[]] .width = true := by decide
def e2406200260634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200260634 : Closed e2406200260634 ∧ code e2406200260634 = 11202293282842 := by decide
theorem cert_e2406200260634 : check e2406200260634 [[]] .width = true := by decide
def e2406200272922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200272922 : Closed e2406200272922 ∧ code e2406200272922 = 11202293295130 := by decide
theorem cert_e2406200272922 : check e2406200272922 [[]] .width = true := by decide
def e2406200274458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200274458 : Closed e2406200274458 ∧ code e2406200274458 = 11202293296666 := by decide
theorem cert_e2406200274458 : check e2406200274458 [[]] .width = true := by decide
def e2406200277530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200277530 : Closed e2406200277530 ∧ code e2406200277530 = 11202293299738 := by decide
theorem cert_e2406200277530 : check e2406200277530 [[]] .width = true := by decide
def e2406200279066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406200279066 : Closed e2406200279066 ∧ code e2406200279066 = 11202293301274 := by decide
theorem cert_e2406200279066 : check e2406200279066 [[]] .width = true := by decide
def e2406200279158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406200279158 : Closed e2406200279158 ∧ code e2406200279158 = 11202293301366 := by decide
theorem cert_e2406200279158 : check e2406200279158 [[]] .width = true := by decide
def e2406200279402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406200279402 : Closed e2406200279402 ∧ code e2406200279402 = 11202293301610 := by decide
theorem cert_e2406200279402 : check e2406200279402 [[]] .width = true := by decide
def e2406200279450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406200279450 : Closed e2406200279450 ∧ code e2406200279450 = 11202293301658 := by decide
theorem cert_e2406200279450 : check e2406200279450 [[]] .width = true := by decide
def e2406200280458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406200280458 : Closed e2406200280458 ∧ code e2406200280458 = 11202293302666 := by decide
theorem cert_e2406200280458 : check e2406200280458 [[]] .width = true := by decide
def e2406200280482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406200280482 : Closed e2406200280482 ∧ code e2406200280482 = 11202293302690 := by decide
theorem cert_e2406200280482 : check e2406200280482 [[]] .width = true := by decide
def e2406200280590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406200280590 : Closed e2406200280590 ∧ code e2406200280590 = 11202293302798 := by decide
theorem cert_e2406200280590 : check e2406200280590 [[]] .width = true := by decide
def e2406200280602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200280602 : Closed e2406200280602 ∧ code e2406200280602 = 11202293302810 := by decide
theorem cert_e2406200280602 : check e2406200280602 [[]] .width = true := by decide
def e2406200280674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406200280674 : Closed e2406200280674 ∧ code e2406200280674 = 11202293302882 := by decide
theorem cert_e2406200280674 : check e2406200280674 [[]] .width = true := by decide
def e2406200295622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406200295622 : Closed e2406200295622 ∧ code e2406200295622 = 11202293317830 := by decide
theorem cert_e2406200295622 : check e2406200295622 [[]] .width = true := by decide
def e2406200303642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200303642 : Closed e2406200303642 ∧ code e2406200303642 = 11202293325850 := by decide
theorem cert_e2406200303642 : check e2406200303642 [[]] .width = true := by decide
def e2406200303734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406200303734 : Closed e2406200303734 ∧ code e2406200303734 = 11202293325942 := by decide
theorem cert_e2406200303734 : check e2406200303734 [[]] .width = true := by decide
def e2406200303978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406200303978 : Closed e2406200303978 ∧ code e2406200303978 = 11202293326186 := by decide
theorem cert_e2406200303978 : check e2406200303978 [[]] .width = true := by decide
def e2406200304026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406200304026 : Closed e2406200304026 ∧ code e2406200304026 = 11202293326234 := by decide
theorem cert_e2406200304026 : check e2406200304026 [[]] .width = true := by decide
def e2406200325658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200325658 : Closed e2406200325658 ∧ code e2406200325658 = 11202293347866 := by decide
theorem cert_e2406200325658 : check e2406200325658 [[]] .width = true := by decide
def e2406200326682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200326682 : Closed e2406200326682 ∧ code e2406200326682 = 11202293348890 := by decide
theorem cert_e2406200326682 : check e2406200326682 [[]] .width = true := by decide
def e2406200336410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200336410 : Closed e2406200336410 ∧ code e2406200336410 = 11202293358618 := by decide
theorem cert_e2406200336410 : check e2406200336410 [[]] .width = true := by decide
def e2406200336502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406200336502 : Closed e2406200336502 ∧ code e2406200336502 = 11202293358710 := by decide
theorem cert_e2406200336502 : check e2406200336502 [[]] .width = true := by decide
def e2406200336746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406200336746 : Closed e2406200336746 ∧ code e2406200336746 = 11202293358954 := by decide
theorem cert_e2406200336746 : check e2406200336746 [[]] .width = true := by decide
def e2406200336794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406200336794 : Closed e2406200336794 ∧ code e2406200336794 = 11202293359002 := by decide
theorem cert_e2406200336794 : check e2406200336794 [[]] .width = true := by decide
def e2406200387610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200387610 : Closed e2406200387610 ∧ code e2406200387610 = 11202293409818 := by decide
theorem cert_e2406200387610 : check e2406200387610 [[]] .width = true := by decide
def e2406200418330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200418330 : Closed e2406200418330 ∧ code e2406200418330 = 11202293440538 := by decide
theorem cert_e2406200418330 : check e2406200418330 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2406191324698
#print axioms Blc.Floor43.cert_e2406191328794
#print axioms Blc.Floor43.cert_e2406191423002
#print axioms Blc.Floor43.cert_e2406191430170
#print axioms Blc.Floor43.cert_e2406191443482
#print axioms Blc.Floor43.cert_e2406191446554
#print axioms Blc.Floor43.cert_e2406191717914
#print axioms Blc.Floor43.cert_e2406191722010
#print axioms Blc.Floor43.cert_e2406192307738
#print axioms Blc.Floor43.cert_e2406192314906
#print axioms Blc.Floor43.cert_e2406192410138
#print axioms Blc.Floor43.cert_e2406192413210
#print axioms Blc.Floor43.cert_e2406199781914
#print axioms Blc.Floor43.cert_e2406199814682
