import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2407060786414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2407060786414 : Closed e2407060786414 ∧ code e2407060786414 = 11203153808622 := by decide
theorem cert_e2407060786414 : check e2407060786414 [[],[]] .smaller = true := by decide
def e2407060786422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2407060786422 : Closed e2407060786422 ∧ code e2407060786422 = 11203153808630 := by decide
theorem cert_e2407060786422 : check e2407060786422 [[],[]] .smaller = true := by decide
def e2407060786798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2407060786798 : Closed e2407060786798 ∧ code e2407060786798 = 11203153809006 := by decide
theorem cert_e2407060786798 : check e2407060786798 [[],[]] .smaller = true := by decide
def e2407060786810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2407060786810 : Closed e2407060786810 ∧ code e2407060786810 = 11203153809018 := by decide
theorem cert_e2407060786810 : check e2407060786810 [[],[]] .smaller = true := by decide
def e2407060786998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2407060786998 : Closed e2407060786998 ∧ code e2407060786998 = 11203153809206 := by decide
theorem cert_e2407060786998 : check e2407060786998 [[],[]] .smaller = true := by decide
def e2407060787002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2407060787002 : Closed e2407060787002 ∧ code e2407060787002 = 11203153809210 := by decide
theorem cert_e2407060787002 : check e2407060787002 [[],[]] .smaller = true := by decide
def e2407060792750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2407060792750 : Closed e2407060792750 ∧ code e2407060792750 = 11203153814958 := by decide
theorem cert_e2407060792750 : check e2407060792750 [[],[]] .smaller = true := by decide
def e2407060792762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2407060792762 : Closed e2407060792762 ∧ code e2407060792762 = 11203153814970 := by decide
theorem cert_e2407060792762 : check e2407060792762 [[],[]] .smaller = true := by decide
def e2407060792810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2407060792810 : Closed e2407060792810 ∧ code e2407060792810 = 11203153815018 := by decide
theorem cert_e2407060792810 : check e2407060792810 [[],[]] .smaller = true := by decide
def e2407060792942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2407060792942 : Closed e2407060792942 ∧ code e2407060792942 = 11203153815150 := by decide
theorem cert_e2407060792942 : check e2407060792942 [[],[]] .smaller = true := by decide
def e2407060792954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2407060792954 : Closed e2407060792954 ∧ code e2407060792954 = 11203153815162 := by decide
theorem cert_e2407060792954 : check e2407060792954 [[],[]] .smaller = true := by decide
def e2407060793242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2407060793242 : Closed e2407060793242 ∧ code e2407060793242 = 11203153815450 := by decide
theorem cert_e2407060793242 : check e2407060793242 [[],[]] .smaller = true := by decide
def e2407060796118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2407060796118 : Closed e2407060796118 ∧ code e2407060796118 = 11203153818326 := by decide
theorem cert_e2407060796118 : check e2407060796118 [[],[]] .smaller = true := by decide
def e2407060796122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2407060796122 : Closed e2407060796122 ∧ code e2407060796122 = 11203153818330 := by decide
theorem cert_e2407060796122 : check e2407060796122 [[],[]] .smaller = true := by decide
def e2407060796138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2407060796138 : Closed e2407060796138 ∧ code e2407060796138 = 11203153818346 := by decide
theorem cert_e2407060796138 : check e2407060796138 [[],[]] .smaller = true := by decide
def e2407060796214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2407060796214 : Closed e2407060796214 ∧ code e2407060796214 = 11203153818422 := by decide
theorem cert_e2407060796214 : check e2407060796214 [[],[]] .smaller = true := by decide
def e2407060796218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2407060796218 : Closed e2407060796218 ∧ code e2407060796218 = 11203153818426 := by decide
theorem cert_e2407060796218 : check e2407060796218 [[],[]] .smaller = true := by decide
def e2407060796314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2407060796314 : Closed e2407060796314 ∧ code e2407060796314 = 11203153818522 := by decide
theorem cert_e2407060796314 : check e2407060796314 [[],[]] .smaller = true := by decide
def e2407060911582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2407060911582 : Closed e2407060911582 ∧ code e2407060911582 = 11203153933790 := by decide
theorem cert_e2407060911582 : check e2407060911582 [[],[]] .three = true := by decide
def e2407060911598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2407060911598 : Closed e2407060911598 ∧ code e2407060911598 = 11203153933806 := by decide
theorem cert_e2407060911598 : check e2407060911598 [[],[]] .three = true := by decide
def e2407060911838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2407060911838 : Closed e2407060911838 ∧ code e2407060911838 = 11203153934046 := by decide
theorem cert_e2407060911838 : check e2407060911838 [[],[]] .three = true := by decide
def e2407060911854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2407060911854 : Closed e2407060911854 ∧ code e2407060911854 = 11203153934062 := by decide
theorem cert_e2407060911854 : check e2407060911854 [[],[]] .smaller = true := by decide
def e2407060911862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2407060911862 : Closed e2407060911862 ∧ code e2407060911862 = 11203153934070 := by decide
theorem cert_e2407060911862 : check e2407060911862 [[],[]] .three = true := by decide
def e2407060911966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2407060911966 : Closed e2407060911966 ∧ code e2407060911966 = 11203153934174 := by decide
theorem cert_e2407060911966 : check e2407060911966 [[],[]] .three = true := by decide
def e2407060911982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2407060911982 : Closed e2407060911982 ∧ code e2407060911982 = 11203153934190 := by decide
theorem cert_e2407060911982 : check e2407060911982 [[],[]] .smaller = true := by decide
def e2407060911990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2407060911990 : Closed e2407060911990 ∧ code e2407060911990 = 11203153934198 := by decide
theorem cert_e2407060911990 : check e2407060911990 [[],[]] .smaller = true := by decide
def e2407060911994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2407060911994 : Closed e2407060911994 ∧ code e2407060911994 = 11203153934202 := by decide
theorem cert_e2407060911994 : check e2407060911994 [[],[]] .three = true := by decide
def e2407060912046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2407060912046 : Closed e2407060912046 ∧ code e2407060912046 = 11203153934254 := by decide
theorem cert_e2407060912046 : check e2407060912046 [[],[]] .three = true := by decide
def e2407060912054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2407060912054 : Closed e2407060912054 ∧ code e2407060912054 = 11203153934262 := by decide
theorem cert_e2407060912054 : check e2407060912054 [[],[]] .three = true := by decide
def e2407060912058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2407060912058 : Closed e2407060912058 ∧ code e2407060912058 = 11203153934266 := by decide
theorem cert_e2407060912058 : check e2407060912058 [[],[]] .three = true := by decide
def e2407060912862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2407060912862 : Closed e2407060912862 ∧ code e2407060912862 = 11203153935070 := by decide
theorem cert_e2407060912862 : check e2407060912862 [[],[]] .three = true := by decide
def e2407060912878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2407060912878 : Closed e2407060912878 ∧ code e2407060912878 = 11203153935086 := by decide
theorem cert_e2407060912878 : check e2407060912878 [[],[]] .smaller = true := by decide
def e2407060912886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2407060912886 : Closed e2407060912886 ∧ code e2407060912886 = 11203153935094 := by decide
theorem cert_e2407060912886 : check e2407060912886 [[],[]] .three = true := by decide
def e2407060912990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2407060912990 : Closed e2407060912990 ∧ code e2407060912990 = 11203153935198 := by decide
theorem cert_e2407060912990 : check e2407060912990 [[],[]] .three = true := by decide
def e2407060913018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2407060913018 : Closed e2407060913018 ∧ code e2407060913018 = 11203153935226 := by decide
theorem cert_e2407060913018 : check e2407060913018 [[],[]] .three = true := by decide
def e2407060913070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2407060913070 : Closed e2407060913070 ∧ code e2407060913070 = 11203153935278 := by decide
theorem cert_e2407060913070 : check e2407060913070 [[],[]] .smaller = true := by decide
def e2407060913082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2407060913082 : Closed e2407060913082 ∧ code e2407060913082 = 11203153935290 := by decide
theorem cert_e2407060913082 : check e2407060913082 [[],[]] .smaller = true := by decide
def e2407060913110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2407060913110 : Closed e2407060913110 ∧ code e2407060913110 = 11203153935318 := by decide
theorem cert_e2407060913110 : check e2407060913110 [[],[]] .three = true := by decide
def e2407060913114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2407060913114 : Closed e2407060913114 ∧ code e2407060913114 = 11203153935322 := by decide
theorem cert_e2407060913114 : check e2407060913114 [[],[]] .three = true := by decide
def e2407060913502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2407060913502 : Closed e2407060913502 ∧ code e2407060913502 = 11203153935710 := by decide
theorem cert_e2407060913502 : check e2407060913502 [[],[]] .three = true := by decide
def e2407060913518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2407060913518 : Closed e2407060913518 ∧ code e2407060913518 = 11203153935726 := by decide
theorem cert_e2407060913518 : check e2407060913518 [[],[]] .smaller = true := by decide
def e2407060913526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2407060913526 : Closed e2407060913526 ∧ code e2407060913526 = 11203153935734 := by decide
theorem cert_e2407060913526 : check e2407060913526 [[],[]] .smaller = true := by decide
def e2407060913530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2407060913530 : Closed e2407060913530 ∧ code e2407060913530 = 11203153935738 := by decide
theorem cert_e2407060913530 : check e2407060913530 [[],[]] .three = true := by decide
def e2407060913582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2407060913582 : Closed e2407060913582 ∧ code e2407060913582 = 11203153935790 := by decide
theorem cert_e2407060913582 : check e2407060913582 [[],[]] .smaller = true := by decide
def e2407060913594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2407060913594 : Closed e2407060913594 ∧ code e2407060913594 = 11203153935802 := by decide
theorem cert_e2407060913594 : check e2407060913594 [[],[]] .smaller = true := by decide
def e2407060913622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2407060913622 : Closed e2407060913622 ∧ code e2407060913622 = 11203153935830 := by decide
theorem cert_e2407060913622 : check e2407060913622 [[],[]] .smaller = true := by decide
def e2407060913626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2407060913626 : Closed e2407060913626 ∧ code e2407060913626 = 11203153935834 := by decide
theorem cert_e2407060913626 : check e2407060913626 [[],[]] .smaller = true := by decide
def e2407060913642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2407060913642 : Closed e2407060913642 ∧ code e2407060913642 = 11203153935850 := by decide
theorem cert_e2407060913642 : check e2407060913642 [[],[]] .three = true := by decide
def e2407060913838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2407060913838 : Closed e2407060913838 ∧ code e2407060913838 = 11203153936046 := by decide
theorem cert_e2407060913838 : check e2407060913838 [[],[]] .three = true := by decide
def e2407060913846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2407060913846 : Closed e2407060913846 ∧ code e2407060913846 = 11203153936054 := by decide
theorem cert_e2407060913846 : check e2407060913846 [[],[]] .three = true := by decide
def e2407060913850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2407060913850 : Closed e2407060913850 ∧ code e2407060913850 = 11203153936058 := by decide
theorem cert_e2407060913850 : check e2407060913850 [[],[]] .three = true := by decide
def e2407060913878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2407060913878 : Closed e2407060913878 ∧ code e2407060913878 = 11203153936086 := by decide
theorem cert_e2407060913878 : check e2407060913878 [[],[]] .three = true := by decide
def e2407060913882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2407060913882 : Closed e2407060913882 ∧ code e2407060913882 = 11203153936090 := by decide
theorem cert_e2407060913882 : check e2407060913882 [[],[]] .three = true := by decide
def e2407060913898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2407060913898 : Closed e2407060913898 ∧ code e2407060913898 = 11203153936106 := by decide
theorem cert_e2407060913898 : check e2407060913898 [[],[]] .three = true := by decide
def e2407060917726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2407060917726 : Closed e2407060917726 ∧ code e2407060917726 = 11203153939934 := by decide
theorem cert_e2407060917726 : check e2407060917726 [[],[]] .three = true := by decide
def e2407060917742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2407060917742 : Closed e2407060917742 ∧ code e2407060917742 = 11203153939950 := by decide
theorem cert_e2407060917742 : check e2407060917742 [[],[]] .three = true := by decide
def e2407060917982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2407060917982 : Closed e2407060917982 ∧ code e2407060917982 = 11203153940190 := by decide
theorem cert_e2407060917982 : check e2407060917982 [[],[]] .three = true := by decide
def e2407060917998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2407060917998 : Closed e2407060917998 ∧ code e2407060917998 = 11203153940206 := by decide
theorem cert_e2407060917998 : check e2407060917998 [[],[]] .smaller = true := by decide
def e2407060918006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2407060918006 : Closed e2407060918006 ∧ code e2407060918006 = 11203153940214 := by decide
theorem cert_e2407060918006 : check e2407060918006 [[],[]] .three = true := by decide
def e2407060918110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2407060918110 : Closed e2407060918110 ∧ code e2407060918110 = 11203153940318 := by decide
theorem cert_e2407060918110 : check e2407060918110 [[],[]] .three = true := by decide
def e2407060918126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2407060918126 : Closed e2407060918126 ∧ code e2407060918126 = 11203153940334 := by decide
theorem cert_e2407060918126 : check e2407060918126 [[],[]] .smaller = true := by decide
def e2407060918134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2407060918134 : Closed e2407060918134 ∧ code e2407060918134 = 11203153940342 := by decide
theorem cert_e2407060918134 : check e2407060918134 [[],[]] .smaller = true := by decide
def e2407060918138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2407060918138 : Closed e2407060918138 ∧ code e2407060918138 = 11203153940346 := by decide
theorem cert_e2407060918138 : check e2407060918138 [[],[]] .three = true := by decide
def e2407060918190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2407060918190 : Closed e2407060918190 ∧ code e2407060918190 = 11203153940398 := by decide
theorem cert_e2407060918190 : check e2407060918190 [[],[]] .three = true := by decide
def e2407060918198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2407060918198 : Closed e2407060918198 ∧ code e2407060918198 = 11203153940406 := by decide
theorem cert_e2407060918198 : check e2407060918198 [[],[]] .three = true := by decide
def e2407060918202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2407060918202 : Closed e2407060918202 ∧ code e2407060918202 = 11203153940410 := by decide
theorem cert_e2407060918202 : check e2407060918202 [[],[]] .three = true := by decide
def e2407060919262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2407060919262 : Closed e2407060919262 ∧ code e2407060919262 = 11203153941470 := by decide
theorem cert_e2407060919262 : check e2407060919262 [[],[]] .three = true := by decide
def e2407060919278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2407060919278 : Closed e2407060919278 ∧ code e2407060919278 = 11203153941486 := by decide
theorem cert_e2407060919278 : check e2407060919278 [[],[]] .three = true := by decide
def e2407060920798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2407060920798 : Closed e2407060920798 ∧ code e2407060920798 = 11203153943006 := by decide
theorem cert_e2407060920798 : check e2407060920798 [[],[]] .three = true := by decide
def e2407060920814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2407060920814 : Closed e2407060920814 ∧ code e2407060920814 = 11203153943022 := by decide
theorem cert_e2407060920814 : check e2407060920814 [[],[]] .smaller = true := by decide
def e2407060920822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2407060920822 : Closed e2407060920822 ∧ code e2407060920822 = 11203153943030 := by decide
theorem cert_e2407060920822 : check e2407060920822 [[],[]] .three = true := by decide
def e2407060921566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2407060921566 : Closed e2407060921566 ∧ code e2407060921566 = 11203153943774 := by decide
theorem cert_e2407060921566 : check e2407060921566 [[],[]] .three = true := by decide
def e2407060921582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2407060921582 : Closed e2407060921582 ∧ code e2407060921582 = 11203153943790 := by decide
theorem cert_e2407060921582 : check e2407060921582 [[],[]] .smaller = true := by decide
def e2407060921590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2407060921590 : Closed e2407060921590 ∧ code e2407060921590 = 11203153943798 := by decide
theorem cert_e2407060921590 : check e2407060921590 [[],[]] .smaller = true := by decide
def e2407060921594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2407060921594 : Closed e2407060921594 ∧ code e2407060921594 = 11203153943802 := by decide
theorem cert_e2407060921594 : check e2407060921594 [[],[]] .three = true := by decide
def e2407060921966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407060921966 : Closed e2407060921966 ∧ code e2407060921966 = 11203153944174 := by decide
theorem cert_e2407060921966 : check e2407060921966 [[],[]] .three = true := by decide
def e2407060921974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2407060921974 : Closed e2407060921974 ∧ code e2407060921974 = 11203153944182 := by decide
theorem cert_e2407060921974 : check e2407060921974 [[],[]] .three = true := by decide
def e2407060921978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407060921978 : Closed e2407060921978 ∧ code e2407060921978 = 11203153944186 := by decide
theorem cert_e2407060921978 : check e2407060921978 [[],[]] .three = true := by decide
def e2407060924126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2407060924126 : Closed e2407060924126 ∧ code e2407060924126 = 11203153946334 := by decide
theorem cert_e2407060924126 : check e2407060924126 [[],[]] .three = true := by decide
def e2407060924142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2407060924142 : Closed e2407060924142 ∧ code e2407060924142 = 11203153946350 := by decide
theorem cert_e2407060924142 : check e2407060924142 [[],[]] .smaller = true := by decide
def e2407060924150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2407060924150 : Closed e2407060924150 ∧ code e2407060924150 = 11203153946358 := by decide
theorem cert_e2407060924150 : check e2407060924150 [[],[]] .three = true := by decide
def e2407060924254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2407060924254 : Closed e2407060924254 ∧ code e2407060924254 = 11203153946462 := by decide
theorem cert_e2407060924254 : check e2407060924254 [[],[]] .three = true := by decide
def e2407060924282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2407060924282 : Closed e2407060924282 ∧ code e2407060924282 = 11203153946490 := by decide
theorem cert_e2407060924282 : check e2407060924282 [[],[]] .three = true := by decide
def e2407060924334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2407060924334 : Closed e2407060924334 ∧ code e2407060924334 = 11203153946542 := by decide
theorem cert_e2407060924334 : check e2407060924334 [[],[]] .smaller = true := by decide
def e2407060924346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2407060924346 : Closed e2407060924346 ∧ code e2407060924346 = 11203153946554 := by decide
theorem cert_e2407060924346 : check e2407060924346 [[],[]] .smaller = true := by decide
def e2407060924374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2407060924374 : Closed e2407060924374 ∧ code e2407060924374 = 11203153946582 := by decide
theorem cert_e2407060924374 : check e2407060924374 [[],[]] .three = true := by decide
def e2407060924378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2407060924378 : Closed e2407060924378 ∧ code e2407060924378 = 11203153946586 := by decide
theorem cert_e2407060924378 : check e2407060924378 [[],[]] .three = true := by decide
def e2407060924894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2407060924894 : Closed e2407060924894 ∧ code e2407060924894 = 11203153947102 := by decide
theorem cert_e2407060924894 : check e2407060924894 [[],[]] .three = true := by decide
def e2407060924910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2407060924910 : Closed e2407060924910 ∧ code e2407060924910 = 11203153947118 := by decide
theorem cert_e2407060924910 : check e2407060924910 [[],[]] .smaller = true := by decide
def e2407060924918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2407060924918 : Closed e2407060924918 ∧ code e2407060924918 = 11203153947126 := by decide
theorem cert_e2407060924918 : check e2407060924918 [[],[]] .three = true := by decide
def e2407060925662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2407060925662 : Closed e2407060925662 ∧ code e2407060925662 = 11203153947870 := by decide
theorem cert_e2407060925662 : check e2407060925662 [[],[]] .three = true := by decide
def e2407060925690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2407060925690 : Closed e2407060925690 ∧ code e2407060925690 = 11203153947898 := by decide
theorem cert_e2407060925690 : check e2407060925690 [[],[]] .three = true := by decide
def e2407060926062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407060926062 : Closed e2407060926062 ∧ code e2407060926062 = 11203153948270 := by decide
theorem cert_e2407060926062 : check e2407060926062 [[],[]] .smaller = true := by decide
def e2407060926074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407060926074 : Closed e2407060926074 ∧ code e2407060926074 = 11203153948282 := by decide
theorem cert_e2407060926074 : check e2407060926074 [[],[]] .smaller = true := by decide
def e2407060926262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407060926262 : Closed e2407060926262 ∧ code e2407060926262 = 11203153948470 := by decide
theorem cert_e2407060926262 : check e2407060926262 [[],[]] .three = true := by decide
def e2407060926266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407060926266 : Closed e2407060926266 ∧ code e2407060926266 = 11203153948474 := by decide
theorem cert_e2407060926266 : check e2407060926266 [[],[]] .three = true := by decide
def e2407060927326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2407060927326 : Closed e2407060927326 ∧ code e2407060927326 = 11203153949534 := by decide
theorem cert_e2407060927326 : check e2407060927326 [[],[]] .three = true := by decide
def e2407060927342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2407060927342 : Closed e2407060927342 ∧ code e2407060927342 = 11203153949550 := by decide
theorem cert_e2407060927342 : check e2407060927342 [[],[]] .smaller = true := by decide
def e2407060927350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2407060927350 : Closed e2407060927350 ∧ code e2407060927350 = 11203153949558 := by decide
theorem cert_e2407060927350 : check e2407060927350 [[],[]] .smaller = true := by decide
def e2407060927354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2407060927354 : Closed e2407060927354 ∧ code e2407060927354 = 11203153949562 := by decide
theorem cert_e2407060927354 : check e2407060927354 [[],[]] .three = true := by decide
def e2407060927406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2407060927406 : Closed e2407060927406 ∧ code e2407060927406 = 11203153949614 := by decide
theorem cert_e2407060927406 : check e2407060927406 [[],[]] .smaller = true := by decide
def e2407060927418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2407060927418 : Closed e2407060927418 ∧ code e2407060927418 = 11203153949626 := by decide
theorem cert_e2407060927418 : check e2407060927418 [[],[]] .smaller = true := by decide
def e2407060927446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2407060927446 : Closed e2407060927446 ∧ code e2407060927446 = 11203153949654 := by decide
theorem cert_e2407060927446 : check e2407060927446 [[],[]] .smaller = true := by decide
def e2407060927450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2407060927450 : Closed e2407060927450 ∧ code e2407060927450 = 11203153949658 := by decide
theorem cert_e2407060927450 : check e2407060927450 [[],[]] .smaller = true := by decide
def e2407060927466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2407060927466 : Closed e2407060927466 ∧ code e2407060927466 = 11203153949674 := by decide
theorem cert_e2407060927466 : check e2407060927466 [[],[]] .three = true := by decide
def e2407060927710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2407060927710 : Closed e2407060927710 ∧ code e2407060927710 = 11203153949918 := by decide
theorem cert_e2407060927710 : check e2407060927710 [[],[]] .three = true := by decide
def e2407060927726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2407060927726 : Closed e2407060927726 ∧ code e2407060927726 = 11203153949934 := by decide
theorem cert_e2407060927726 : check e2407060927726 [[],[]] .smaller = true := by decide
def e2407060927734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2407060927734 : Closed e2407060927734 ∧ code e2407060927734 = 11203153949942 := by decide
theorem cert_e2407060927734 : check e2407060927734 [[],[]] .smaller = true := by decide
def e2407060927738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2407060927738 : Closed e2407060927738 ∧ code e2407060927738 = 11203153949946 := by decide
theorem cert_e2407060927738 : check e2407060927738 [[],[]] .three = true := by decide
def e2407060928110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407060928110 : Closed e2407060928110 ∧ code e2407060928110 = 11203153950318 := by decide
theorem cert_e2407060928110 : check e2407060928110 [[],[]] .smaller = true := by decide
def e2407060928122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407060928122 : Closed e2407060928122 ∧ code e2407060928122 = 11203153950330 := by decide
theorem cert_e2407060928122 : check e2407060928122 [[],[]] .smaller = true := by decide
def e2407060928310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407060928310 : Closed e2407060928310 ∧ code e2407060928310 = 11203153950518 := by decide
theorem cert_e2407060928310 : check e2407060928310 [[],[]] .smaller = true := by decide
def e2407060928314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407060928314 : Closed e2407060928314 ∧ code e2407060928314 = 11203153950522 := by decide
theorem cert_e2407060928314 : check e2407060928314 [[],[]] .smaller = true := by decide
def e2407060928410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407060928410 : Closed e2407060928410 ∧ code e2407060928410 = 11203153950618 := by decide
theorem cert_e2407060928410 : check e2407060928410 [[],[]] .three = true := by decide
def e2407060928942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2407060928942 : Closed e2407060928942 ∧ code e2407060928942 = 11203153951150 := by decide
theorem cert_e2407060928942 : check e2407060928942 [[],[]] .three = true := by decide
def e2407060928950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2407060928950 : Closed e2407060928950 ∧ code e2407060928950 = 11203153951158 := by decide
theorem cert_e2407060928950 : check e2407060928950 [[],[]] .three = true := by decide
def e2407060928954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2407060928954 : Closed e2407060928954 ∧ code e2407060928954 = 11203153951162 := by decide
theorem cert_e2407060928954 : check e2407060928954 [[],[]] .three = true := by decide
def e2407060928982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2407060928982 : Closed e2407060928982 ∧ code e2407060928982 = 11203153951190 := by decide
theorem cert_e2407060928982 : check e2407060928982 [[],[]] .three = true := by decide
def e2407060928986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2407060928986 : Closed e2407060928986 ∧ code e2407060928986 = 11203153951194 := by decide
theorem cert_e2407060928986 : check e2407060928986 [[],[]] .three = true := by decide
def e2407060929002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2407060929002 : Closed e2407060929002 ∧ code e2407060929002 = 11203153951210 := by decide
theorem cert_e2407060929002 : check e2407060929002 [[],[]] .three = true := by decide
def e2407060929134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407060929134 : Closed e2407060929134 ∧ code e2407060929134 = 11203153951342 := by decide
theorem cert_e2407060929134 : check e2407060929134 [[],[]] .three = true := by decide
def e2407060929142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2407060929142 : Closed e2407060929142 ∧ code e2407060929142 = 11203153951350 := by decide
theorem cert_e2407060929142 : check e2407060929142 [[],[]] .three = true := by decide
def e2407060929146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407060929146 : Closed e2407060929146 ∧ code e2407060929146 = 11203153951354 := by decide
theorem cert_e2407060929146 : check e2407060929146 [[],[]] .three = true := by decide
def e2407060929334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407060929334 : Closed e2407060929334 ∧ code e2407060929334 = 11203153951542 := by decide
theorem cert_e2407060929334 : check e2407060929334 [[],[]] .three = true := by decide
def e2407060929338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407060929338 : Closed e2407060929338 ∧ code e2407060929338 = 11203153951546 := by decide
theorem cert_e2407060929338 : check e2407060929338 [[],[]] .three = true := by decide
def e2407060929434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407060929434 : Closed e2407060929434 ∧ code e2407060929434 = 11203153951642 := by decide
theorem cert_e2407060929434 : check e2407060929434 [[],[]] .three = true := by decide
def e2407060933486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2407060933486 : Closed e2407060933486 ∧ code e2407060933486 = 11203153955694 := by decide
theorem cert_e2407060933486 : check e2407060933486 [[],[]] .smaller = true := by decide
def e2407060933494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2407060933494 : Closed e2407060933494 ∧ code e2407060933494 = 11203153955702 := by decide
theorem cert_e2407060933494 : check e2407060933494 [[],[]] .smaller = true := by decide
def e2407060933550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2407060933550 : Closed e2407060933550 ∧ code e2407060933550 = 11203153955758 := by decide
theorem cert_e2407060933550 : check e2407060933550 [[],[]] .smaller = true := by decide
def e2407060933562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2407060933562 : Closed e2407060933562 ∧ code e2407060933562 = 11203153955770 := by decide
theorem cert_e2407060933562 : check e2407060933562 [[],[]] .smaller = true := by decide
def e2407060933590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2407060933590 : Closed e2407060933590 ∧ code e2407060933590 = 11203153955798 := by decide
theorem cert_e2407060933590 : check e2407060933590 [[],[]] .smaller = true := by decide
def e2407060933594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2407060933594 : Closed e2407060933594 ∧ code e2407060933594 = 11203153955802 := by decide
theorem cert_e2407060933594 : check e2407060933594 [[],[]] .smaller = true := by decide
def e2407060933870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2407060933870 : Closed e2407060933870 ∧ code e2407060933870 = 11203153956078 := by decide
theorem cert_e2407060933870 : check e2407060933870 [[],[]] .smaller = true := by decide
def e2407060933878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2407060933878 : Closed e2407060933878 ∧ code e2407060933878 = 11203153956086 := by decide
theorem cert_e2407060933878 : check e2407060933878 [[],[]] .smaller = true := by decide
def e2407060934254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2407060934254 : Closed e2407060934254 ∧ code e2407060934254 = 11203153956462 := by decide
theorem cert_e2407060934254 : check e2407060934254 [[],[]] .smaller = true := by decide
def e2407060934266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2407060934266 : Closed e2407060934266 ∧ code e2407060934266 = 11203153956474 := by decide
theorem cert_e2407060934266 : check e2407060934266 [[],[]] .smaller = true := by decide
def e2407060934454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2407060934454 : Closed e2407060934454 ∧ code e2407060934454 = 11203153956662 := by decide
theorem cert_e2407060934454 : check e2407060934454 [[],[]] .smaller = true := by decide
def e2407060934458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2407060934458 : Closed e2407060934458 ∧ code e2407060934458 = 11203153956666 := by decide
theorem cert_e2407060934458 : check e2407060934458 [[],[]] .smaller = true := by decide
def e2407060942302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2407060942302 : Closed e2407060942302 ∧ code e2407060942302 = 11203153964510 := by decide
theorem cert_e2407060942302 : check e2407060942302 [[],[]] .three = true := by decide
def e2407060942318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2407060942318 : Closed e2407060942318 ∧ code e2407060942318 = 11203153964526 := by decide
theorem cert_e2407060942318 : check e2407060942318 [[],[]] .three = true := by decide
def e2407060942558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2407060942558 : Closed e2407060942558 ∧ code e2407060942558 = 11203153964766 := by decide
theorem cert_e2407060942558 : check e2407060942558 [[],[]] .three = true := by decide
def e2407060942574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2407060942574 : Closed e2407060942574 ∧ code e2407060942574 = 11203153964782 := by decide
theorem cert_e2407060942574 : check e2407060942574 [[],[]] .smaller = true := by decide
def e2407060942582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2407060942582 : Closed e2407060942582 ∧ code e2407060942582 = 11203153964790 := by decide
theorem cert_e2407060942582 : check e2407060942582 [[],[]] .three = true := by decide
def e2407060942686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2407060942686 : Closed e2407060942686 ∧ code e2407060942686 = 11203153964894 := by decide
theorem cert_e2407060942686 : check e2407060942686 [[],[]] .three = true := by decide
def e2407060942702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2407060942702 : Closed e2407060942702 ∧ code e2407060942702 = 11203153964910 := by decide
theorem cert_e2407060942702 : check e2407060942702 [[],[]] .smaller = true := by decide
def e2407060942710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2407060942710 : Closed e2407060942710 ∧ code e2407060942710 = 11203153964918 := by decide
theorem cert_e2407060942710 : check e2407060942710 [[],[]] .smaller = true := by decide
def e2407060942714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2407060942714 : Closed e2407060942714 ∧ code e2407060942714 = 11203153964922 := by decide
theorem cert_e2407060942714 : check e2407060942714 [[],[]] .three = true := by decide
def e2407060942766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2407060942766 : Closed e2407060942766 ∧ code e2407060942766 = 11203153964974 := by decide
theorem cert_e2407060942766 : check e2407060942766 [[],[]] .three = true := by decide
def e2407060942774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2407060942774 : Closed e2407060942774 ∧ code e2407060942774 = 11203153964982 := by decide
theorem cert_e2407060942774 : check e2407060942774 [[],[]] .three = true := by decide
def e2407060942778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2407060942778 : Closed e2407060942778 ∧ code e2407060942778 = 11203153964986 := by decide
theorem cert_e2407060942778 : check e2407060942778 [[],[]] .three = true := by decide
def e2407060943838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2407060943838 : Closed e2407060943838 ∧ code e2407060943838 = 11203153966046 := by decide
theorem cert_e2407060943838 : check e2407060943838 [[],[]] .three = true := by decide
def e2407060943854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2407060943854 : Closed e2407060943854 ∧ code e2407060943854 = 11203153966062 := by decide
theorem cert_e2407060943854 : check e2407060943854 [[],[]] .three = true := by decide
def e2407060945374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2407060945374 : Closed e2407060945374 ∧ code e2407060945374 = 11203153967582 := by decide
theorem cert_e2407060945374 : check e2407060945374 [[],[]] .three = true := by decide
def e2407060945390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2407060945390 : Closed e2407060945390 ∧ code e2407060945390 = 11203153967598 := by decide
theorem cert_e2407060945390 : check e2407060945390 [[],[]] .smaller = true := by decide
def e2407060945398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2407060945398 : Closed e2407060945398 ∧ code e2407060945398 = 11203153967606 := by decide
theorem cert_e2407060945398 : check e2407060945398 [[],[]] .three = true := by decide
def e2407060946142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2407060946142 : Closed e2407060946142 ∧ code e2407060946142 = 11203153968350 := by decide
theorem cert_e2407060946142 : check e2407060946142 [[],[]] .three = true := by decide
def e2407060946158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2407060946158 : Closed e2407060946158 ∧ code e2407060946158 = 11203153968366 := by decide
theorem cert_e2407060946158 : check e2407060946158 [[],[]] .smaller = true := by decide
def e2407060946166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2407060946166 : Closed e2407060946166 ∧ code e2407060946166 = 11203153968374 := by decide
theorem cert_e2407060946166 : check e2407060946166 [[],[]] .smaller = true := by decide
def e2407060946170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2407060946170 : Closed e2407060946170 ∧ code e2407060946170 = 11203153968378 := by decide
theorem cert_e2407060946170 : check e2407060946170 [[],[]] .three = true := by decide
def e2407060946542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407060946542 : Closed e2407060946542 ∧ code e2407060946542 = 11203153968750 := by decide
theorem cert_e2407060946542 : check e2407060946542 [[],[]] .three = true := by decide
end Blc.Floor43
