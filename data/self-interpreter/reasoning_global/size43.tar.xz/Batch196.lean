import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389176316886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2389176316886 : Closed e2389176316886 ∧ code e2389176316886 = 11185269339094 := by decide
theorem cert_e2389176316886 : check e2389176316886 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389176316890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2389176316890 : Closed e2389176316890 ∧ code e2389176316890 = 11185269339098 := by decide
theorem cert_e2389176316890 : check e2389176316890 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389176317166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2389176317166 : Closed e2389176317166 ∧ code e2389176317166 = 11185269339374 := by decide
theorem cert_e2389176317166 : check e2389176317166 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389176317174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2389176317174 : Closed e2389176317174 ∧ code e2389176317174 = 11185269339382 := by decide
theorem cert_e2389176317174 : check e2389176317174 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389176317550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2389176317550 : Closed e2389176317550 ∧ code e2389176317550 = 11185269339758 := by decide
theorem cert_e2389176317550 : check e2389176317550 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389176317562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2389176317562 : Closed e2389176317562 ∧ code e2389176317562 = 11185269339770 := by decide
theorem cert_e2389176317562 : check e2389176317562 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389176317750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389176317750 : Closed e2389176317750 ∧ code e2389176317750 = 11185269339958 := by decide
theorem cert_e2389176317750 : check e2389176317750 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389176317754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389176317754 : Closed e2389176317754 ∧ code e2389176317754 = 11185269339962 := by decide
theorem cert_e2389176317754 : check e2389176317754 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389176318390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2389176318390 : Closed e2389176318390 ∧ code e2389176318390 = 11185269340598 := by decide
theorem cert_e2389176318390 : check e2389176318390 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389176318422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2389176318422 : Closed e2389176318422 ∧ code e2389176318422 = 11185269340630 := by decide
theorem cert_e2389176318422 : check e2389176318422 [[],[.left],[],[.under,.left],[.under,.left],[.under]] .three = true := by decide
def e2389176318426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2389176318426 : Closed e2389176318426 ∧ code e2389176318426 = 11185269340634 := by decide
theorem cert_e2389176318426 : check e2389176318426 [[],[.left],[],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2389176318582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2389176318582 : Closed e2389176318582 ∧ code e2389176318582 = 11185269340790 := by decide
theorem cert_e2389176318582 : check e2389176318582 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389176318774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389176318774 : Closed e2389176318774 ∧ code e2389176318774 = 11185269340982 := by decide
theorem cert_e2389176318774 : check e2389176318774 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2389176318778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389176318778 : Closed e2389176318778 ∧ code e2389176318778 = 11185269340986 := by decide
theorem cert_e2389176318778 : check e2389176318778 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2389176325998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2389176325998 : Closed e2389176325998 ∧ code e2389176325998 = 11185269348206 := by decide
theorem cert_e2389176325998 : check e2389176325998 [[],[.left],[]] .sourceHead = true := by decide
def e2389176326006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2389176326006 : Closed e2389176326006 ∧ code e2389176326006 = 11185269348214 := by decide
theorem cert_e2389176326006 : check e2389176326006 [[],[.left],[]] .sourceHead = true := by decide
def e2389176326070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2389176326070 : Closed e2389176326070 ∧ code e2389176326070 = 11185269348278 := by decide
theorem cert_e2389176326070 : check e2389176326070 [[],[.left],[]] .sourceHead = true := by decide
def e2389176327406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2389176327406 : Closed e2389176327406 ∧ code e2389176327406 = 11185269349614 := by decide
theorem cert_e2389176327406 : check e2389176327406 [[],[.left],[]] .sourceHead = true := by decide
def e2389176327414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2389176327414 : Closed e2389176327414 ∧ code e2389176327414 = 11185269349622 := by decide
theorem cert_e2389176327414 : check e2389176327414 [[],[.left],[]] .sourceHead = true := by decide
def e2389176327798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2389176327798 : Closed e2389176327798 ∧ code e2389176327798 = 11185269350006 := by decide
theorem cert_e2389176327798 : check e2389176327798 [[],[.left],[]] .sourceHead = true := by decide
def e2389176339310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389176339310 : Closed e2389176339310 ∧ code e2389176339310 = 11185269361518 := by decide
theorem cert_e2389176339310 : check e2389176339310 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176339318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389176339318 : Closed e2389176339318 ∧ code e2389176339318 = 11185269361526 := by decide
theorem cert_e2389176339318 : check e2389176339318 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176339374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389176339374 : Closed e2389176339374 ∧ code e2389176339374 = 11185269361582 := by decide
theorem cert_e2389176339374 : check e2389176339374 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176339386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389176339386 : Closed e2389176339386 ∧ code e2389176339386 = 11185269361594 := by decide
theorem cert_e2389176339386 : check e2389176339386 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176339414 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389176339414 : Closed e2389176339414 ∧ code e2389176339414 = 11185269361622 := by decide
theorem cert_e2389176339414 : check e2389176339414 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176339418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389176339418 : Closed e2389176339418 ∧ code e2389176339418 = 11185269361626 := by decide
theorem cert_e2389176339418 : check e2389176339418 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176339694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389176339694 : Closed e2389176339694 ∧ code e2389176339694 = 11185269361902 := by decide
theorem cert_e2389176339694 : check e2389176339694 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176339702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389176339702 : Closed e2389176339702 ∧ code e2389176339702 = 11185269361910 := by decide
theorem cert_e2389176339702 : check e2389176339702 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176340078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389176340078 : Closed e2389176340078 ∧ code e2389176340078 = 11185269362286 := by decide
theorem cert_e2389176340078 : check e2389176340078 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176340090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389176340090 : Closed e2389176340090 ∧ code e2389176340090 = 11185269362298 := by decide
theorem cert_e2389176340090 : check e2389176340090 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176340278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389176340278 : Closed e2389176340278 ∧ code e2389176340278 = 11185269362486 := by decide
theorem cert_e2389176340278 : check e2389176340278 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176340282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389176340282 : Closed e2389176340282 ∧ code e2389176340282 = 11185269362490 := by decide
theorem cert_e2389176340282 : check e2389176340282 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389176346038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2389176346038 : Closed e2389176346038 ∧ code e2389176346038 = 11185269368246 := by decide
theorem cert_e2389176346038 : check e2389176346038 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2389176346070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2389176346070 : Closed e2389176346070 ∧ code e2389176346070 = 11185269368278 := by decide
theorem cert_e2389176346070 : check e2389176346070 [[],[.left],[],[.under],[.under,.left],[.under]] .three = true := by decide
def e2389176346074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2389176346074 : Closed e2389176346074 ∧ code e2389176346074 = 11185269368282 := by decide
theorem cert_e2389176346074 : check e2389176346074 [[],[.left],[],[.under],[.under,.left]] .smaller = true := by decide
def e2389176346230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2389176346230 : Closed e2389176346230 ∧ code e2389176346230 = 11185269368438 := by decide
theorem cert_e2389176346230 : check e2389176346230 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2389176346422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2389176346422 : Closed e2389176346422 ∧ code e2389176346422 = 11185269368630 := by decide
theorem cert_e2389176346422 : check e2389176346422 [[],[.left],[],[.under],[.under]] .smaller = true := by decide
def e2389176346426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2389176346426 : Closed e2389176346426 ∧ code e2389176346426 = 11185269368634 := by decide
theorem cert_e2389176346426 : check e2389176346426 [[],[.left],[],[.under],[.under]] .smaller = true := by decide
def e2389176683374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389176683374 : Closed e2389176683374 ∧ code e2389176683374 = 11185269705582 := by decide
theorem cert_e2389176683374 : check e2389176683374 [[],[.left]] .chain = true := by decide
def e2389176683382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389176683382 : Closed e2389176683382 ∧ code e2389176683382 = 11185269705590 := by decide
theorem cert_e2389176683382 : check e2389176683382 [[],[.left]] .chain = true := by decide
def e2389176683438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389176683438 : Closed e2389176683438 ∧ code e2389176683438 = 11185269705646 := by decide
theorem cert_e2389176683438 : check e2389176683438 [[],[.left]] .chain = true := by decide
def e2389176683450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389176683450 : Closed e2389176683450 ∧ code e2389176683450 = 11185269705658 := by decide
theorem cert_e2389176683450 : check e2389176683450 [[],[.left]] .chain = true := by decide
def e2389176683478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389176683478 : Closed e2389176683478 ∧ code e2389176683478 = 11185269705686 := by decide
theorem cert_e2389176683478 : check e2389176683478 [[],[.left]] .chain = true := by decide
def e2389176683482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389176683482 : Closed e2389176683482 ∧ code e2389176683482 = 11185269705690 := by decide
theorem cert_e2389176683482 : check e2389176683482 [[],[.left]] .chain = true := by decide
def e2389176683758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389176683758 : Closed e2389176683758 ∧ code e2389176683758 = 11185269705966 := by decide
theorem cert_e2389176683758 : check e2389176683758 [[],[.left]] .chain = true := by decide
def e2389176683766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389176683766 : Closed e2389176683766 ∧ code e2389176683766 = 11185269705974 := by decide
theorem cert_e2389176683766 : check e2389176683766 [[],[.left]] .chain = true := by decide
def e2389176684142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389176684142 : Closed e2389176684142 ∧ code e2389176684142 = 11185269706350 := by decide
theorem cert_e2389176684142 : check e2389176684142 [[],[.left]] .chain = true := by decide
def e2389176684154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389176684154 : Closed e2389176684154 ∧ code e2389176684154 = 11185269706362 := by decide
theorem cert_e2389176684154 : check e2389176684154 [[],[.left]] .chain = true := by decide
def e2389176684342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389176684342 : Closed e2389176684342 ∧ code e2389176684342 = 11185269706550 := by decide
theorem cert_e2389176684342 : check e2389176684342 [[],[.left]] .chain = true := by decide
def e2389176684346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389176684346 : Closed e2389176684346 ∧ code e2389176684346 = 11185269706554 := by decide
theorem cert_e2389176684346 : check e2389176684346 [[],[.left]] .chain = true := by decide
def e2389277634074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277634074 : Closed e2389277634074 ∧ code e2389277634074 = 11185370656282 := by decide
theorem cert_e2389277634074 : check e2389277634074 [[]] .width = true := by decide
def e2389277636122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277636122 : Closed e2389277636122 ∧ code e2389277636122 = 11185370658330 := by decide
theorem cert_e2389277636122 : check e2389277636122 [[]] .width = true := by decide
def e2389277650458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277650458 : Closed e2389277650458 ∧ code e2389277650458 = 11185370672666 := by decide
theorem cert_e2389277650458 : check e2389277650458 [[]] .width = true := by decide
def e2389277653530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277653530 : Closed e2389277653530 ∧ code e2389277653530 = 11185370675738 := by decide
theorem cert_e2389277653530 : check e2389277653530 [[]] .width = true := by decide
def e2389277660698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277660698 : Closed e2389277660698 ∧ code e2389277660698 = 11185370682906 := by decide
theorem cert_e2389277660698 : check e2389277660698 [[]] .width = true := by decide
def e2389277661722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277661722 : Closed e2389277661722 ∧ code e2389277661722 = 11185370683930 := by decide
theorem cert_e2389277661722 : check e2389277661722 [[]] .width = true := by decide
def e2389277732378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277732378 : Closed e2389277732378 ∧ code e2389277732378 = 11185370754586 := by decide
theorem cert_e2389277732378 : check e2389277732378 [[]] .width = true := by decide
def e2389277734426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277734426 : Closed e2389277734426 ∧ code e2389277734426 = 11185370756634 := by decide
theorem cert_e2389277734426 : check e2389277734426 [[]] .width = true := by decide
def e2389277830682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277830682 : Closed e2389277830682 ∧ code e2389277830682 = 11185370852890 := by decide
theorem cert_e2389277830682 : check e2389277830682 [[]] .width = true := by decide
def e2389277833754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277833754 : Closed e2389277833754 ∧ code e2389277833754 = 11185370855962 := by decide
theorem cert_e2389277833754 : check e2389277833754 [[]] .width = true := by decide
def e2389277881882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277881882 : Closed e2389277881882 ∧ code e2389277881882 = 11185370904090 := by decide
theorem cert_e2389277881882 : check e2389277881882 [[]] .width = true := by decide
def e2389277882906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389277882906 : Closed e2389277882906 ∧ code e2389277882906 = 11185370905114 := by decide
theorem cert_e2389277882906 : check e2389277882906 [[]] .width = true := by decide
def e2389293706606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2389293706606 : Closed e2389293706606 ∧ code e2389293706606 = 11185386728814 := by decide
theorem cert_e2389293706606 : check e2389293706606 [[],[.left],[]] .sourceHead = true := by decide
def e2389293706614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2389293706614 : Closed e2389293706614 ∧ code e2389293706614 = 11185386728822 := by decide
theorem cert_e2389293706614 : check e2389293706614 [[],[.left],[]] .sourceHead = true := by decide
def e2389293706670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2389293706670 : Closed e2389293706670 ∧ code e2389293706670 = 11185386728878 := by decide
theorem cert_e2389293706670 : check e2389293706670 [[],[.left],[]] .sourceHead = true := by decide
def e2389293706682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2389293706682 : Closed e2389293706682 ∧ code e2389293706682 = 11185386728890 := by decide
theorem cert_e2389293706682 : check e2389293706682 [[],[.left],[]] .sourceHead = true := by decide
def e2389293706710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2389293706710 : Closed e2389293706710 ∧ code e2389293706710 = 11185386728918 := by decide
theorem cert_e2389293706710 : check e2389293706710 [[],[.left],[]] .sourceHead = true := by decide
def e2389293706714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2389293706714 : Closed e2389293706714 ∧ code e2389293706714 = 11185386728922 := by decide
theorem cert_e2389293706714 : check e2389293706714 [[],[.left],[]] .sourceHead = true := by decide
def e2389293706926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2389293706926 : Closed e2389293706926 ∧ code e2389293706926 = 11185386729134 := by decide
theorem cert_e2389293706926 : check e2389293706926 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2389293706938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2389293706938 : Closed e2389293706938 ∧ code e2389293706938 = 11185386729146 := by decide
theorem cert_e2389293706938 : check e2389293706938 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2389293706986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2389293706986 : Closed e2389293706986 ∧ code e2389293706986 = 11185386729194 := by decide
theorem cert_e2389293706986 : check e2389293706986 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2389293707094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2389293707094 : Closed e2389293707094 ∧ code e2389293707094 = 11185386729302 := by decide
theorem cert_e2389293707094 : check e2389293707094 [[],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2389293707098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2389293707098 : Closed e2389293707098 ∧ code e2389293707098 = 11185386729306 := by decide
theorem cert_e2389293707098 : check e2389293707098 [[],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2389293707114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2389293707114 : Closed e2389293707114 ∧ code e2389293707114 = 11185386729322 := by decide
theorem cert_e2389293707114 : check e2389293707114 [[],[.left],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2389293708142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2389293708142 : Closed e2389293708142 ∧ code e2389293708142 = 11185386730350 := by decide
theorem cert_e2389293708142 : check e2389293708142 [[],[.left],[]] .sourceHead = true := by decide
def e2389293708150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2389293708150 : Closed e2389293708150 ∧ code e2389293708150 = 11185386730358 := by decide
theorem cert_e2389293708150 : check e2389293708150 [[],[.left],[]] .sourceHead = true := by decide
def e2389293708206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2389293708206 : Closed e2389293708206 ∧ code e2389293708206 = 11185386730414 := by decide
theorem cert_e2389293708206 : check e2389293708206 [[],[.left],[]] .sourceHead = true := by decide
def e2389293708218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2389293708218 : Closed e2389293708218 ∧ code e2389293708218 = 11185386730426 := by decide
theorem cert_e2389293708218 : check e2389293708218 [[],[.left],[]] .sourceHead = true := by decide
def e2389293708246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2389293708246 : Closed e2389293708246 ∧ code e2389293708246 = 11185386730454 := by decide
theorem cert_e2389293708246 : check e2389293708246 [[],[.left],[]] .sourceHead = true := by decide
def e2389293708250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2389293708250 : Closed e2389293708250 ∧ code e2389293708250 = 11185386730458 := by decide
theorem cert_e2389293708250 : check e2389293708250 [[],[.left],[]] .sourceHead = true := by decide
def e2389293708526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2389293708526 : Closed e2389293708526 ∧ code e2389293708526 = 11185386730734 := by decide
theorem cert_e2389293708526 : check e2389293708526 [[],[.left],[]] .sourceHead = true := by decide
def e2389293708534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2389293708534 : Closed e2389293708534 ∧ code e2389293708534 = 11185386730742 := by decide
theorem cert_e2389293708534 : check e2389293708534 [[],[.left],[]] .sourceHead = true := by decide
def e2389293708910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2389293708910 : Closed e2389293708910 ∧ code e2389293708910 = 11185386731118 := by decide
theorem cert_e2389293708910 : check e2389293708910 [[],[.left],[]] .sourceHead = true := by decide
def e2389293708922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2389293708922 : Closed e2389293708922 ∧ code e2389293708922 = 11185386731130 := by decide
theorem cert_e2389293708922 : check e2389293708922 [[],[.left],[]] .sourceHead = true := by decide
def e2389293709110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389293709110 : Closed e2389293709110 ∧ code e2389293709110 = 11185386731318 := by decide
theorem cert_e2389293709110 : check e2389293709110 [[],[.left],[]] .sourceHead = true := by decide
def e2389293709114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389293709114 : Closed e2389293709114 ∧ code e2389293709114 = 11185386731322 := by decide
theorem cert_e2389293709114 : check e2389293709114 [[],[.left],[]] .sourceHead = true := by decide
def e2389293709742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2389293709742 : Closed e2389293709742 ∧ code e2389293709742 = 11185386731950 := by decide
theorem cert_e2389293709742 : check e2389293709742 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389293709754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2389293709754 : Closed e2389293709754 ∧ code e2389293709754 = 11185386731962 := by decide
theorem cert_e2389293709754 : check e2389293709754 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389293709802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2389293709802 : Closed e2389293709802 ∧ code e2389293709802 = 11185386732010 := by decide
theorem cert_e2389293709802 : check e2389293709802 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389293709934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2389293709934 : Closed e2389293709934 ∧ code e2389293709934 = 11185386732142 := by decide
theorem cert_e2389293709934 : check e2389293709934 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389293709946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2389293709946 : Closed e2389293709946 ∧ code e2389293709946 = 11185386732154 := by decide
theorem cert_e2389293709946 : check e2389293709946 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389293710234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389293710234 : Closed e2389293710234 ∧ code e2389293710234 = 11185386732442 := by decide
theorem cert_e2389293710234 : check e2389293710234 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389293710550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2389293710550 : Closed e2389293710550 ∧ code e2389293710550 = 11185386732758 := by decide
theorem cert_e2389293710550 : check e2389293710550 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389293710554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2389293710554 : Closed e2389293710554 ∧ code e2389293710554 = 11185386732762 := by decide
theorem cert_e2389293710554 : check e2389293710554 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389293710570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2389293710570 : Closed e2389293710570 ∧ code e2389293710570 = 11185386732778 := by decide
theorem cert_e2389293710570 : check e2389293710570 [[],[.left],[],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2389293710646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389293710646 : Closed e2389293710646 ∧ code e2389293710646 = 11185386732854 := by decide
theorem cert_e2389293710646 : check e2389293710646 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389293710650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389293710650 : Closed e2389293710650 ∧ code e2389293710650 = 11185386732858 := by decide
theorem cert_e2389293710650 : check e2389293710650 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389293710746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389293710746 : Closed e2389293710746 ∧ code e2389293710746 = 11185386732954 := by decide
theorem cert_e2389293710746 : check e2389293710746 [[],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2389293714286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389293714286 : Closed e2389293714286 ∧ code e2389293714286 = 11185386736494 := by decide
theorem cert_e2389293714286 : check e2389293714286 [[],[.left],[]] .sourceHead = true := by decide
def e2389293714294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389293714294 : Closed e2389293714294 ∧ code e2389293714294 = 11185386736502 := by decide
theorem cert_e2389293714294 : check e2389293714294 [[],[.left],[]] .sourceHead = true := by decide
def e2389293714350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389293714350 : Closed e2389293714350 ∧ code e2389293714350 = 11185386736558 := by decide
theorem cert_e2389293714350 : check e2389293714350 [[],[.left],[]] .sourceHead = true := by decide
def e2389293714362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389293714362 : Closed e2389293714362 ∧ code e2389293714362 = 11185386736570 := by decide
theorem cert_e2389293714362 : check e2389293714362 [[],[.left],[]] .sourceHead = true := by decide
def e2389293714390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389293714390 : Closed e2389293714390 ∧ code e2389293714390 = 11185386736598 := by decide
theorem cert_e2389293714390 : check e2389293714390 [[],[.left],[]] .sourceHead = true := by decide
def e2389293714394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389293714394 : Closed e2389293714394 ∧ code e2389293714394 = 11185386736602 := by decide
theorem cert_e2389293714394 : check e2389293714394 [[],[.left],[]] .sourceHead = true := by decide
def e2389293714670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389293714670 : Closed e2389293714670 ∧ code e2389293714670 = 11185386736878 := by decide
theorem cert_e2389293714670 : check e2389293714670 [[],[.left],[]] .sourceHead = true := by decide
def e2389293714678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389293714678 : Closed e2389293714678 ∧ code e2389293714678 = 11185386736886 := by decide
theorem cert_e2389293714678 : check e2389293714678 [[],[.left],[]] .sourceHead = true := by decide
def e2389293715054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389293715054 : Closed e2389293715054 ∧ code e2389293715054 = 11185386737262 := by decide
theorem cert_e2389293715054 : check e2389293715054 [[],[.left],[]] .sourceHead = true := by decide
def e2389293715066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389293715066 : Closed e2389293715066 ∧ code e2389293715066 = 11185386737274 := by decide
theorem cert_e2389293715066 : check e2389293715066 [[],[.left],[]] .sourceHead = true := by decide
def e2389293715254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389293715254 : Closed e2389293715254 ∧ code e2389293715254 = 11185386737462 := by decide
theorem cert_e2389293715254 : check e2389293715254 [[],[.left],[]] .sourceHead = true := by decide
def e2389293715258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389293715258 : Closed e2389293715258 ∧ code e2389293715258 = 11185386737466 := by decide
theorem cert_e2389293715258 : check e2389293715258 [[],[.left],[]] .sourceHead = true := by decide
def e2389293721006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2389293721006 : Closed e2389293721006 ∧ code e2389293721006 = 11185386743214 := by decide
theorem cert_e2389293721006 : check e2389293721006 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389293721018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2389293721018 : Closed e2389293721018 ∧ code e2389293721018 = 11185386743226 := by decide
theorem cert_e2389293721018 : check e2389293721018 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389293721066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2389293721066 : Closed e2389293721066 ∧ code e2389293721066 = 11185386743274 := by decide
theorem cert_e2389293721066 : check e2389293721066 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389293721198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2389293721198 : Closed e2389293721198 ∧ code e2389293721198 = 11185386743406 := by decide
theorem cert_e2389293721198 : check e2389293721198 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389293721210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2389293721210 : Closed e2389293721210 ∧ code e2389293721210 = 11185386743418 := by decide
theorem cert_e2389293721210 : check e2389293721210 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389293721498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2389293721498 : Closed e2389293721498 ∧ code e2389293721498 = 11185386743706 := by decide
theorem cert_e2389293721498 : check e2389293721498 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2389293724374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2389293724374 : Closed e2389293724374 ∧ code e2389293724374 = 11185386746582 := by decide
theorem cert_e2389293724374 : check e2389293724374 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2389293724378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2389293724378 : Closed e2389293724378 ∧ code e2389293724378 = 11185386746586 := by decide
theorem cert_e2389293724378 : check e2389293724378 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2389293724394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2389293724394 : Closed e2389293724394 ∧ code e2389293724394 = 11185386746602 := by decide
theorem cert_e2389293724394 : check e2389293724394 [[],[.left],[],[.under],[.under,.left,.left]] .chain = true := by decide
def e2389293724470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2389293724470 : Closed e2389293724470 ∧ code e2389293724470 = 11185386746678 := by decide
theorem cert_e2389293724470 : check e2389293724470 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2389293724474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2389293724474 : Closed e2389293724474 ∧ code e2389293724474 = 11185386746682 := by decide
theorem cert_e2389293724474 : check e2389293724474 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2389293724570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2389293724570 : Closed e2389293724570 ∧ code e2389293724570 = 11185386746778 := by decide
theorem cert_e2389293724570 : check e2389293724570 [[],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e2389293861742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389293861742 : Closed e2389293861742 ∧ code e2389293861742 = 11185386883950 := by decide
def e2389293861750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389293861750 : Closed e2389293861750 ∧ code e2389293861750 = 11185386883958 := by decide
def e2389293861806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389293861806 : Closed e2389293861806 ∧ code e2389293861806 = 11185386884014 := by decide
def e2389293861818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389293861818 : Closed e2389293861818 ∧ code e2389293861818 = 11185386884026 := by decide
theorem cert_e2389293861818 : check e2389293861818 [[],[.left],[],[.left],[],[],[.left,.left],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2389293861846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389293861846 : Closed e2389293861846 ∧ code e2389293861846 = 11185386884054 := by decide
def e2389293861850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389293861850 : Closed e2389293861850 ∧ code e2389293861850 = 11185386884058 := by decide
def e2389293862126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389293862126 : Closed e2389293862126 ∧ code e2389293862126 = 11185386884334 := by decide
theorem cert_e2389293862126 : check e2389293862126 [[],[.left],[],[.left],[],[],[],[.left,.left],[.left],[.left],[],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2389293862134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389293862134 : Closed e2389293862134 ∧ code e2389293862134 = 11185386884342 := by decide
def e2389293862510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389293862510 : Closed e2389293862510 ∧ code e2389293862510 = 11185386884718 := by decide
def e2389293862522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389293862522 : Closed e2389293862522 ∧ code e2389293862522 = 11185386884730 := by decide
def e2389293862710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389293862710 : Closed e2389293862710 ∧ code e2389293862710 = 11185386884918 := by decide
theorem cert_e2389293862710 : check e2389293862710 [[],[.left],[],[.left],[],[],[],[],[]] .sourceHead = true := by decide
def e2389293862714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389293862714 : Closed e2389293862714 ∧ code e2389293862714 = 11185386884922 := by decide
theorem cert_e2389293862714 : check e2389293862714 [[],[.left],[],[.left],[],[],[],[.left],[],[],[]] .sourceHead = true := by decide
def e2389294451566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389294451566 : Closed e2389294451566 ∧ code e2389294451566 = 11185387473774 := by decide
theorem cert_e2389294451566 : check e2389294451566 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2389294451574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389294451574 : Closed e2389294451574 ∧ code e2389294451574 = 11185387473782 := by decide
theorem cert_e2389294451574 : check e2389294451574 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2389294451630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389294451630 : Closed e2389294451630 ∧ code e2389294451630 = 11185387473838 := by decide
theorem cert_e2389294451630 : check e2389294451630 [[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2389294451642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389294451642 : Closed e2389294451642 ∧ code e2389294451642 = 11185387473850 := by decide
private def t_e2389294451642 : Term := (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 0))) (.var 0)))
theorem cert_e2389294451642 : ¬ IsSelfInterpreter e2389294451642 :=
  wSource (t := t_e2389294451642) (replay_sound (ps := [[],[.left],[.left],[]]) (t := e2389294451642) (by decide)) (by decide)
def e2389294451670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389294451670 : Closed e2389294451670 ∧ code e2389294451670 = 11185387473878 := by decide
theorem cert_e2389294451670 : check e2389294451670 [[],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2389294451674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389294451674 : Closed e2389294451674 ∧ code e2389294451674 = 11185387473882 := by decide
private def t_e2389294451674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem cert_e2389294451674 : ¬ IsSelfInterpreter e2389294451674 :=
  wSource (t := t_e2389294451674) (replay_sound (ps := [[],[.left],[.left],[],[.under,.left]]) (t := e2389294451674) (by decide)) (by decide)
def e2389294451950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389294451950 : Closed e2389294451950 ∧ code e2389294451950 = 11185387474158 := by decide
theorem cert_e2389294451950 : check e2389294451950 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2389294451958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389294451958 : Closed e2389294451958 ∧ code e2389294451958 = 11185387474166 := by decide
theorem cert_e2389294451958 : check e2389294451958 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2389294452334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389294452334 : Closed e2389294452334 ∧ code e2389294452334 = 11185387474542 := by decide
theorem cert_e2389294452334 : check e2389294452334 [[],[.left],[.left],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2389294452346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389294452346 : Closed e2389294452346 ∧ code e2389294452346 = 11185387474554 := by decide
theorem cert_e2389294452346 : check e2389294452346 [[],[.left],[.left],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2389294452534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389294452534 : Closed e2389294452534 ∧ code e2389294452534 = 11185387474742 := by decide
theorem cert_e2389294452534 : check e2389294452534 [[],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2389294452538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389294452538 : Closed e2389294452538 ∧ code e2389294452538 = 11185387474746 := by decide
theorem cert_e2389294452538 : check e2389294452538 [[],[.left],[.left],[],[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e2389344038254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2389344038254 : Closed e2389344038254 ∧ code e2389344038254 = 11185437060462 := by decide
theorem cert_e2389344038254 : check e2389344038254 [[],[.left],[]] .smaller = true := by decide
def e2389344038262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2389344038262 : Closed e2389344038262 ∧ code e2389344038262 = 11185437060470 := by decide
theorem cert_e2389344038262 : check e2389344038262 [[],[.left],[]] .smaller = true := by decide
def e2389344038318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2389344038318 : Closed e2389344038318 ∧ code e2389344038318 = 11185437060526 := by decide
theorem cert_e2389344038318 : check e2389344038318 [[],[.left],[]] .smaller = true := by decide
def e2389344038330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2389344038330 : Closed e2389344038330 ∧ code e2389344038330 = 11185437060538 := by decide
theorem cert_e2389344038330 : check e2389344038330 [[],[.left],[]] .smaller = true := by decide
def e2389344038358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2389344038358 : Closed e2389344038358 ∧ code e2389344038358 = 11185437060566 := by decide
theorem cert_e2389344038358 : check e2389344038358 [[],[.left],[]] .smaller = true := by decide
def e2389344038362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2389344038362 : Closed e2389344038362 ∧ code e2389344038362 = 11185437060570 := by decide
theorem cert_e2389344038362 : check e2389344038362 [[],[.left],[]] .smaller = true := by decide
def e2389344038574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2389344038574 : Closed e2389344038574 ∧ code e2389344038574 = 11185437060782 := by decide
theorem cert_e2389344038574 : check e2389344038574 [[],[.left],[]] .smaller = true := by decide
def e2389344038586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2389344038586 : Closed e2389344038586 ∧ code e2389344038586 = 11185437060794 := by decide
theorem cert_e2389344038586 : check e2389344038586 [[],[.left],[]] .smaller = true := by decide
def e2389344038634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2389344038634 : Closed e2389344038634 ∧ code e2389344038634 = 11185437060842 := by decide
theorem cert_e2389344038634 : check e2389344038634 [[],[.left],[]] .smaller = true := by decide
def e2389344038742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2389344038742 : Closed e2389344038742 ∧ code e2389344038742 = 11185437060950 := by decide
theorem cert_e2389344038742 : check e2389344038742 [[],[.left],[]] .smaller = true := by decide
def e2389344038746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2389344038746 : Closed e2389344038746 ∧ code e2389344038746 = 11185437060954 := by decide
theorem cert_e2389344038746 : check e2389344038746 [[],[.left],[]] .smaller = true := by decide
def e2389344038762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2389344038762 : Closed e2389344038762 ∧ code e2389344038762 = 11185437060970 := by decide
theorem cert_e2389344038762 : check e2389344038762 [[],[.left],[]] .smaller = true := by decide
def e2389344039790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2389344039790 : Closed e2389344039790 ∧ code e2389344039790 = 11185437061998 := by decide
theorem cert_e2389344039790 : check e2389344039790 [[],[.left],[]] .smaller = true := by decide
def e2389344039798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2389344039798 : Closed e2389344039798 ∧ code e2389344039798 = 11185437062006 := by decide
theorem cert_e2389344039798 : check e2389344039798 [[],[.left],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2389294451642
#print axioms Blc.Floor43.cert_e2389294451674
