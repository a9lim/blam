import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605775150198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.var 1)))))
theorem wire_e605775150198 : Closed e605775150198 ∧ code e605775150198 = 9401868172406 := by decide
theorem cert_e605775150198 : check e605775150198 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605775150478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 2))))))
theorem wire_e605775150478 : Closed e605775150478 ∧ code e605775150478 = 9401868172686 := by decide
theorem cert_e605775150478 : check e605775150478 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e605775173878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.var 1)))))
theorem wire_e605775173878 : Closed e605775173878 ∧ code e605775173878 = 9401868196086 := by decide
theorem cert_e605775173878 : check e605775173878 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e605775174542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 2))))))
theorem wire_e605775174542 : Closed e605775174542 ∧ code e605775174542 = 9401868196750 := by decide
theorem cert_e605775174542 : check e605775174542 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605775175222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.var 1)))))
theorem wire_e605775175222 : Closed e605775175222 ∧ code e605775175222 = 9401868197430 := by decide
theorem cert_e605775175222 : check e605775175222 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605775175310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 2))))))
theorem wire_e605775175310 : Closed e605775175310 ∧ code e605775175310 = 9401868197518 := by decide
theorem cert_e605775175310 : check e605775175310 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e605775187062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 1)))))
theorem wire_e605775187062 : Closed e605775187062 ∧ code e605775187062 = 9401868209270 := by decide
theorem cert_e605775187062 : check e605775187062 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e605775187342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 2))))))
theorem wire_e605775187342 : Closed e605775187342 ∧ code e605775187342 = 9401868209550 := by decide
theorem cert_e605775187342 : check e605775187342 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e605775187510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.var 1)))))
theorem wire_e605775187510 : Closed e605775187510 ∧ code e605775187510 = 9401868209718 := by decide
theorem cert_e605775187510 : check e605775187510 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left,.left]] .chain = true := by decide
def e605775187598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 2))))))
theorem wire_e605775187598 : Closed e605775187598 ∧ code e605775187598 = 9401868209806 := by decide
theorem cert_e605775187598 : check e605775187598 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left,.left]] .chain = true := by decide
def e605776776046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605776776046 : Closed e605776776046 ∧ code e605776776046 = 9401869798254 := by decide
theorem cert_e605776776046 : check e605776776046 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776776054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605776776054 : Closed e605776776054 ∧ code e605776776054 = 9401869798262 := by decide
theorem cert_e605776776054 : check e605776776054 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776776110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605776776110 : Closed e605776776110 ∧ code e605776776110 = 9401869798318 := by decide
theorem cert_e605776776110 : check e605776776110 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776776122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605776776122 : Closed e605776776122 ∧ code e605776776122 = 9401869798330 := by decide
theorem cert_e605776776122 : check e605776776122 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776776150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605776776150 : Closed e605776776150 ∧ code e605776776150 = 9401869798358 := by decide
theorem cert_e605776776150 : check e605776776150 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776776154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605776776154 : Closed e605776776154 ∧ code e605776776154 = 9401869798362 := by decide
theorem cert_e605776776154 : check e605776776154 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776776430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605776776430 : Closed e605776776430 ∧ code e605776776430 = 9401869798638 := by decide
theorem cert_e605776776430 : check e605776776430 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776776438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605776776438 : Closed e605776776438 ∧ code e605776776438 = 9401869798646 := by decide
theorem cert_e605776776438 : check e605776776438 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776776814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605776776814 : Closed e605776776814 ∧ code e605776776814 = 9401869799022 := by decide
theorem cert_e605776776814 : check e605776776814 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776776826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605776776826 : Closed e605776776826 ∧ code e605776776826 = 9401869799034 := by decide
theorem cert_e605776776826 : check e605776776826 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776777014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605776777014 : Closed e605776777014 ∧ code e605776777014 = 9401869799222 := by decide
theorem cert_e605776777014 : check e605776777014 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605776777018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605776777018 : Closed e605776777018 ∧ code e605776777018 = 9401869799226 := by decide
theorem cert_e605776777018 : check e605776777018 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781235422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605781235422 : Closed e605781235422 ∧ code e605781235422 = 9401874257630 := by decide
theorem cert_e605781235422 : check e605781235422 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781235446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605781235446 : Closed e605781235446 ∧ code e605781235446 = 9401874257654 := by decide
theorem cert_e605781235446 : check e605781235446 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781235550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605781235550 : Closed e605781235550 ∧ code e605781235550 = 9401874257758 := by decide
theorem cert_e605781235550 : check e605781235550 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781235578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605781235578 : Closed e605781235578 ∧ code e605781235578 = 9401874257786 := by decide
theorem cert_e605781235578 : check e605781235578 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781235670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605781235670 : Closed e605781235670 ∧ code e605781235670 = 9401874257878 := by decide
theorem cert_e605781235670 : check e605781235670 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781235674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605781235674 : Closed e605781235674 ∧ code e605781235674 = 9401874257882 := by decide
theorem cert_e605781235674 : check e605781235674 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781236190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605781236190 : Closed e605781236190 ∧ code e605781236190 = 9401874258398 := by decide
theorem cert_e605781236190 : check e605781236190 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781236214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605781236214 : Closed e605781236214 ∧ code e605781236214 = 9401874258422 := by decide
theorem cert_e605781236214 : check e605781236214 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781236958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605781236958 : Closed e605781236958 ∧ code e605781236958 = 9401874259166 := by decide
theorem cert_e605781236958 : check e605781236958 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781236986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605781236986 : Closed e605781236986 ∧ code e605781236986 = 9401874259194 := by decide
theorem cert_e605781236986 : check e605781236986 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781237558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605781237558 : Closed e605781237558 ∧ code e605781237558 = 9401874259766 := by decide
theorem cert_e605781237558 : check e605781237558 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781237562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605781237562 : Closed e605781237562 ∧ code e605781237562 = 9401874259770 := by decide
theorem cert_e605781237562 : check e605781237562 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781252334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605781252334 : Closed e605781252334 ∧ code e605781252334 = 9401874274542 := by decide
theorem cert_e605781252334 : check e605781252334 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781252342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605781252342 : Closed e605781252342 ∧ code e605781252342 = 9401874274550 := by decide
theorem cert_e605781252342 : check e605781252342 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781252894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605781252894 : Closed e605781252894 ∧ code e605781252894 = 9401874275102 := by decide
theorem cert_e605781252894 : check e605781252894 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781253006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605781253006 : Closed e605781253006 ∧ code e605781253006 = 9401874275214 := by decide
theorem cert_e605781253006 : check e605781253006 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781253230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605781253230 : Closed e605781253230 ∧ code e605781253230 = 9401874275438 := by decide
theorem cert_e605781253230 : check e605781253230 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781253242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605781253242 : Closed e605781253242 ∧ code e605781253242 = 9401874275450 := by decide
theorem cert_e605781253242 : check e605781253242 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781253406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605781253406 : Closed e605781253406 ∧ code e605781253406 = 9401874275614 := by decide
theorem cert_e605781253406 : check e605781253406 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781253574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605781253574 : Closed e605781253574 ∧ code e605781253574 = 9401874275782 := by decide
theorem cert_e605781253574 : check e605781253574 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781253686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605781253686 : Closed e605781253686 ∧ code e605781253686 = 9401874275894 := by decide
theorem cert_e605781253686 : check e605781253686 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781253690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605781253690 : Closed e605781253690 ∧ code e605781253690 = 9401874275898 := by decide
theorem cert_e605781253690 : check e605781253690 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781253774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605781253774 : Closed e605781253774 ∧ code e605781253774 = 9401874275982 := by decide
theorem cert_e605781253774 : check e605781253774 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781253830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605781253830 : Closed e605781253830 ∧ code e605781253830 = 9401874276038 := by decide
theorem cert_e605781253830 : check e605781253830 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781255966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605781255966 : Closed e605781255966 ∧ code e605781255966 = 9401874278174 := by decide
theorem cert_e605781255966 : check e605781255966 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781256078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605781256078 : Closed e605781256078 ∧ code e605781256078 = 9401874278286 := by decide
theorem cert_e605781256078 : check e605781256078 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781259038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605781259038 : Closed e605781259038 ∧ code e605781259038 = 9401874281246 := by decide
theorem cert_e605781259038 : check e605781259038 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781259206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605781259206 : Closed e605781259206 ∧ code e605781259206 = 9401874281414 := by decide
theorem cert_e605781259206 : check e605781259206 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781260686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605781260686 : Closed e605781260686 ∧ code e605781260686 = 9401874282894 := by decide
theorem cert_e605781260686 : check e605781260686 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605781260742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605781260742 : Closed e605781260742 ∧ code e605781260742 = 9401874282950 := by decide
theorem cert_e605781260742 : check e605781260742 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605783350138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 0)))))
theorem wire_e605783350138 : Closed e605783350138 ∧ code e605783350138 = 9401876372346 := by decide
theorem cert_e605783350138 : check e605783350138 [[.under],[.under]] .sourceHead = true := by decide
def e605783350234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.var 0)))))
theorem wire_e605783350234 : Closed e605783350234 ∧ code e605783350234 = 9401876372442 := by decide
theorem cert_e605783350234 : check e605783350234 [[.under],[.under]] .sourceHead = true := by decide
def e605783350650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.var 0)))))
theorem wire_e605783350650 : Closed e605783350650 ∧ code e605783350650 = 9401876372858 := by decide
theorem cert_e605783350650 : check e605783350650 [[.under],[.under]] .sourceHead = true := by decide
def e605783350762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.var 0)))))
theorem wire_e605783350762 : Closed e605783350762 ∧ code e605783350762 = 9401876372970 := by decide
theorem cert_e605783350762 : check e605783350762 [[.under],[.under]] .sourceHead = true := by decide
def e605783351130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.var 0)))))
theorem wire_e605783351130 : Closed e605783351130 ∧ code e605783351130 = 9401876373338 := by decide
theorem cert_e605783351130 : check e605783351130 [[.under],[.under]] .sourceHead = true := by decide
def e605783351146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.var 0)))))
theorem wire_e605783351146 : Closed e605783351146 ∧ code e605783351146 = 9401876373354 := by decide
theorem cert_e605783351146 : check e605783351146 [[.under],[.under]] .sourceHead = true := by decide
def e605783353210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.var 0)))))
theorem wire_e605783353210 : Closed e605783353210 ∧ code e605783353210 = 9401876375418 := by decide
theorem cert_e605783353210 : check e605783353210 [[.under],[.under]] .sourceHead = true := by decide
def e605783353306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.var 0)))))
theorem wire_e605783353306 : Closed e605783353306 ∧ code e605783353306 = 9401876375514 := by decide
theorem cert_e605783353306 : check e605783353306 [[.under],[.under]] .sourceHead = true := by decide
def e605783356282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.var 0)))))
theorem wire_e605783356282 : Closed e605783356282 ∧ code e605783356282 = 9401876378490 := by decide
theorem cert_e605783356282 : check e605783356282 [[.under],[.under]] .sourceHead = true := by decide
def e605783356394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.var 0)))))
theorem wire_e605783356394 : Closed e605783356394 ∧ code e605783356394 = 9401876378602 := by decide
theorem cert_e605783356394 : check e605783356394 [[.under],[.under]] .sourceHead = true := by decide
def e605783358682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.var 0)))))
theorem wire_e605783358682 : Closed e605783358682 ∧ code e605783358682 = 9401876380890 := by decide
theorem cert_e605783358682 : check e605783358682 [[.under],[.under]] .sourceHead = true := by decide
def e605783358698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.var 0)))))
theorem wire_e605783358698 : Closed e605783358698 ∧ code e605783358698 = 9401876380906 := by decide
theorem cert_e605783358698 : check e605783358698 [[.under],[.under]] .sourceHead = true := by decide
def e605783417786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.var 0)))))
theorem wire_e605783417786 : Closed e605783417786 ∧ code e605783417786 = 9401876439994 := by decide
theorem cert_e605783417786 : check e605783417786 [[.under],[.under]] .sourceHead = true := by decide
def e605783417818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.var 0)))))
theorem wire_e605783417818 : Closed e605783417818 ∧ code e605783417818 = 9401876440026 := by decide
theorem cert_e605783417818 : check e605783417818 [[.under],[.under]] .sourceHead = true := by decide
def e605783420026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e605783420026 : Closed e605783420026 ∧ code e605783420026 = 9401876442234 := by decide
theorem cert_e605783420026 : check e605783420026 [[.under],[.under]] .sourceHead = true := by decide
def e605783420358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 1))))))
theorem wire_e605783420358 : Closed e605783420358 ∧ code e605783420358 = 9401876442566 := by decide
theorem cert_e605783420358 : check e605783420358 [[.under],[.under]] .sourceHead = true := by decide
def e605783420474 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e605783420474 : Closed e605783420474 ∧ code e605783420474 = 9401876442682 := by decide
theorem cert_e605783420474 : check e605783420474 [[.under],[.under]] .sourceHead = true := by decide
def e605783420614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 1))))))
theorem wire_e605783420614 : Closed e605783420614 ∧ code e605783420614 = 9401876442822 := by decide
theorem cert_e605783420614 : check e605783420614 [[.under],[.under]] .sourceHead = true := by decide
def e605783421370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.var 0)))))
theorem wire_e605783421370 : Closed e605783421370 ∧ code e605783421370 = 9401876443578 := by decide
theorem cert_e605783421370 : check e605783421370 [[.under],[.under]] .sourceHead = true := by decide
def e605783421418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.var 0)))))
theorem wire_e605783421418 : Closed e605783421418 ∧ code e605783421418 = 9401876443626 := by decide
theorem cert_e605783421418 : check e605783421418 [[.under],[.under]] .sourceHead = true := by decide
def e605783422074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e605783422074 : Closed e605783422074 ∧ code e605783422074 = 9401876444282 := by decide
theorem cert_e605783422074 : check e605783422074 [[.under],[.under]] .sourceHead = true := by decide
def e605783422406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 1))))))
theorem wire_e605783422406 : Closed e605783422406 ∧ code e605783422406 = 9401876444614 := by decide
theorem cert_e605783422406 : check e605783422406 [[.under],[.under]] .sourceHead = true := by decide
def e605783422746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e605783422746 : Closed e605783422746 ∧ code e605783422746 = 9401876444954 := by decide
theorem cert_e605783422746 : check e605783422746 [[.under],[.under]] .sourceHead = true := by decide
def e605783422790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 1))))))
theorem wire_e605783422790 : Closed e605783422790 ∧ code e605783422790 = 9401876444998 := by decide
theorem cert_e605783422790 : check e605783422790 [[.under],[.under]] .sourceHead = true := by decide
def e605783423194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.var 0)))))
theorem wire_e605783423194 : Closed e605783423194 ∧ code e605783423194 = 9401876445402 := by decide
theorem cert_e605783423194 : check e605783423194 [[.under],[.under]] .sourceHead = true := by decide
def e605783423210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.var 0)))))
theorem wire_e605783423210 : Closed e605783423210 ∧ code e605783423210 = 9401876445418 := by decide
theorem cert_e605783423210 : check e605783423210 [[.under],[.under]] .sourceHead = true := by decide
def e605783423546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e605783423546 : Closed e605783423546 ∧ code e605783423546 = 9401876445754 := by decide
theorem cert_e605783423546 : check e605783423546 [[.under],[.under]] .sourceHead = true := by decide
def e605783423686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 1))))))
theorem wire_e605783423686 : Closed e605783423686 ∧ code e605783423686 = 9401876445894 := by decide
theorem cert_e605783423686 : check e605783423686 [[.under],[.under]] .sourceHead = true := by decide
def e605783423770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e605783423770 : Closed e605783423770 ∧ code e605783423770 = 9401876445978 := by decide
theorem cert_e605783423770 : check e605783423770 [[.under],[.under]] .sourceHead = true := by decide
def e605783423814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 1))))))
theorem wire_e605783423814 : Closed e605783423814 ∧ code e605783423814 = 9401876446022 := by decide
theorem cert_e605783423814 : check e605783423814 [[.under],[.under]] .sourceHead = true := by decide
def e605783432314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.var 0)))))
theorem wire_e605783432314 : Closed e605783432314 ∧ code e605783432314 = 9401876454522 := by decide
theorem cert_e605783432314 : check e605783432314 [[.under],[.under]] .sourceHead = true := by decide
def e605783432646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 1))))))
theorem wire_e605783432646 : Closed e605783432646 ∧ code e605783432646 = 9401876454854 := by decide
theorem cert_e605783432646 : check e605783432646 [[.under],[.under]] .sourceHead = true := by decide
def e605783432762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.var 0)))))
theorem wire_e605783432762 : Closed e605783432762 ∧ code e605783432762 = 9401876454970 := by decide
theorem cert_e605783432762 : check e605783432762 [[.under],[.under]] .sourceHead = true := by decide
def e605783432902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 1))))))
theorem wire_e605783432902 : Closed e605783432902 ∧ code e605783432902 = 9401876455110 := by decide
theorem cert_e605783432902 : check e605783432902 [[.under],[.under]] .sourceHead = true := by decide
def e605783444602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.var 0)))))
theorem wire_e605783444602 : Closed e605783444602 ∧ code e605783444602 = 9401876466810 := by decide
theorem cert_e605783444602 : check e605783444602 [[.under],[.under]] .sourceHead = true := by decide
def e605783444934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 1))))))
theorem wire_e605783444934 : Closed e605783444934 ∧ code e605783444934 = 9401876467142 := by decide
theorem cert_e605783444934 : check e605783444934 [[.under],[.under]] .sourceHead = true := by decide
def e605783445274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.var 0)))))
theorem wire_e605783445274 : Closed e605783445274 ∧ code e605783445274 = 9401876467482 := by decide
theorem cert_e605783445274 : check e605783445274 [[.under],[.under]] .sourceHead = true := by decide
def e605783445318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 1))))))
theorem wire_e605783445318 : Closed e605783445318 ∧ code e605783445318 = 9401876467526 := by decide
theorem cert_e605783445318 : check e605783445318 [[.under],[.under]] .sourceHead = true := by decide
def e605783451194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 0)))))
theorem wire_e605783451194 : Closed e605783451194 ∧ code e605783451194 = 9401876473402 := by decide
theorem cert_e605783451194 : check e605783451194 [[.under],[.under]] .sourceHead = true := by decide
def e605783451334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 1))))))
theorem wire_e605783451334 : Closed e605783451334 ∧ code e605783451334 = 9401876473542 := by decide
theorem cert_e605783451334 : check e605783451334 [[.under],[.under]] .sourceHead = true := by decide
def e605783451418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.var 0)))))
theorem wire_e605783451418 : Closed e605783451418 ∧ code e605783451418 = 9401876473626 := by decide
theorem cert_e605783451418 : check e605783451418 [[.under],[.under]] .sourceHead = true := by decide
def e605783451462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 1))))))
theorem wire_e605783451462 : Closed e605783451462 ∧ code e605783451462 = 9401876473670 := by decide
theorem cert_e605783451462 : check e605783451462 [[.under],[.under]] .sourceHead = true := by decide
def e605784116078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e605784116078 : Closed e605784116078 ∧ code e605784116078 = 9401877138286 := by decide
theorem cert_e605784116078 : check e605784116078 [[.under],[.under]] .sourceHead = true := by decide
def e605784116086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e605784116086 : Closed e605784116086 ∧ code e605784116086 = 9401877138294 := by decide
theorem cert_e605784116086 : check e605784116086 [[.under],[.under]] .sourceHead = true := by decide
def e605784116142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e605784116142 : Closed e605784116142 ∧ code e605784116142 = 9401877138350 := by decide
theorem cert_e605784116142 : check e605784116142 [[.under],[.under]] .sourceHead = true := by decide
def e605784116154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e605784116154 : Closed e605784116154 ∧ code e605784116154 = 9401877138362 := by decide
theorem cert_e605784116154 : check e605784116154 [[.under],[.under]] .sourceHead = true := by decide
def e605784116182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e605784116182 : Closed e605784116182 ∧ code e605784116182 = 9401877138390 := by decide
theorem cert_e605784116182 : check e605784116182 [[.under],[.under]] .sourceHead = true := by decide
def e605784116186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e605784116186 : Closed e605784116186 ∧ code e605784116186 = 9401877138394 := by decide
theorem cert_e605784116186 : check e605784116186 [[.under],[.under]] .sourceHead = true := by decide
def e605784116462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e605784116462 : Closed e605784116462 ∧ code e605784116462 = 9401877138670 := by decide
theorem cert_e605784116462 : check e605784116462 [[.under],[.under]] .sourceHead = true := by decide
def e605784116470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e605784116470 : Closed e605784116470 ∧ code e605784116470 = 9401877138678 := by decide
theorem cert_e605784116470 : check e605784116470 [[.under],[.under]] .sourceHead = true := by decide
def e605784116846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e605784116846 : Closed e605784116846 ∧ code e605784116846 = 9401877139054 := by decide
theorem cert_e605784116846 : check e605784116846 [[.under],[.under]] .sourceHead = true := by decide
def e605784116858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e605784116858 : Closed e605784116858 ∧ code e605784116858 = 9401877139066 := by decide
theorem cert_e605784116858 : check e605784116858 [[.under],[.under]] .sourceHead = true := by decide
def e605784117046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e605784117046 : Closed e605784117046 ∧ code e605784117046 = 9401877139254 := by decide
theorem cert_e605784117046 : check e605784117046 [[.under],[.under]] .sourceHead = true := by decide
def e605784117050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e605784117050 : Closed e605784117050 ∧ code e605784117050 = 9401877139258 := by decide
theorem cert_e605784117050 : check e605784117050 [[.under],[.under]] .sourceHead = true := by decide
def e605785429726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605785429726 : Closed e605785429726 ∧ code e605785429726 = 9401878451934 := by decide
theorem cert_e605785429726 : check e605785429726 [[.under],[.under]] .sourceHead = true := by decide
def e605785429750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605785429750 : Closed e605785429750 ∧ code e605785429750 = 9401878451958 := by decide
theorem cert_e605785429750 : check e605785429750 [[.under],[.under]] .sourceHead = true := by decide
def e605785429854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605785429854 : Closed e605785429854 ∧ code e605785429854 = 9401878452062 := by decide
theorem cert_e605785429854 : check e605785429854 [[.under],[.under]] .sourceHead = true := by decide
def e605785429882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605785429882 : Closed e605785429882 ∧ code e605785429882 = 9401878452090 := by decide
theorem cert_e605785429882 : check e605785429882 [[.under],[.under]] .sourceHead = true := by decide
def e605785429974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605785429974 : Closed e605785429974 ∧ code e605785429974 = 9401878452182 := by decide
theorem cert_e605785429974 : check e605785429974 [[.under],[.under]] .sourceHead = true := by decide
def e605785429978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605785429978 : Closed e605785429978 ∧ code e605785429978 = 9401878452186 := by decide
theorem cert_e605785429978 : check e605785429978 [[.under],[.under]] .sourceHead = true := by decide
def e605785430494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605785430494 : Closed e605785430494 ∧ code e605785430494 = 9401878452702 := by decide
theorem cert_e605785430494 : check e605785430494 [[.under],[.under]] .sourceHead = true := by decide
def e605785430518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605785430518 : Closed e605785430518 ∧ code e605785430518 = 9401878452726 := by decide
theorem cert_e605785430518 : check e605785430518 [[.under],[.under]] .sourceHead = true := by decide
def e605785431262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605785431262 : Closed e605785431262 ∧ code e605785431262 = 9401878453470 := by decide
theorem cert_e605785431262 : check e605785431262 [[.under],[.under]] .sourceHead = true := by decide
def e605785431290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605785431290 : Closed e605785431290 ∧ code e605785431290 = 9401878453498 := by decide
theorem cert_e605785431290 : check e605785431290 [[.under],[.under]] .sourceHead = true := by decide
def e605785431862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605785431862 : Closed e605785431862 ∧ code e605785431862 = 9401878454070 := by decide
theorem cert_e605785431862 : check e605785431862 [[.under],[.under]] .sourceHead = true := by decide
def e605785431866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605785431866 : Closed e605785431866 ∧ code e605785431866 = 9401878454074 := by decide
theorem cert_e605785431866 : check e605785431866 [[.under],[.under]] .sourceHead = true := by decide
def e605785446638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605785446638 : Closed e605785446638 ∧ code e605785446638 = 9401878468846 := by decide
theorem cert_e605785446638 : check e605785446638 [[.under],[.under]] .sourceHead = true := by decide
def e605785446646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605785446646 : Closed e605785446646 ∧ code e605785446646 = 9401878468854 := by decide
theorem cert_e605785446646 : check e605785446646 [[.under],[.under]] .sourceHead = true := by decide
def e605785447198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605785447198 : Closed e605785447198 ∧ code e605785447198 = 9401878469406 := by decide
theorem cert_e605785447198 : check e605785447198 [[.under],[.under]] .sourceHead = true := by decide
def e605785447310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605785447310 : Closed e605785447310 ∧ code e605785447310 = 9401878469518 := by decide
theorem cert_e605785447310 : check e605785447310 [[.under],[.under]] .sourceHead = true := by decide
def e605785447534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605785447534 : Closed e605785447534 ∧ code e605785447534 = 9401878469742 := by decide
theorem cert_e605785447534 : check e605785447534 [[.under],[.under]] .sourceHead = true := by decide
def e605785447546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605785447546 : Closed e605785447546 ∧ code e605785447546 = 9401878469754 := by decide
theorem cert_e605785447546 : check e605785447546 [[.under],[.under]] .sourceHead = true := by decide
def e605785447710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605785447710 : Closed e605785447710 ∧ code e605785447710 = 9401878469918 := by decide
theorem cert_e605785447710 : check e605785447710 [[.under],[.under]] .sourceHead = true := by decide
def e605785447878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605785447878 : Closed e605785447878 ∧ code e605785447878 = 9401878470086 := by decide
theorem cert_e605785447878 : check e605785447878 [[.under],[.under]] .sourceHead = true := by decide
def e605785447990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605785447990 : Closed e605785447990 ∧ code e605785447990 = 9401878470198 := by decide
theorem cert_e605785447990 : check e605785447990 [[.under],[.under]] .sourceHead = true := by decide
def e605785447994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605785447994 : Closed e605785447994 ∧ code e605785447994 = 9401878470202 := by decide
theorem cert_e605785447994 : check e605785447994 [[.under],[.under]] .sourceHead = true := by decide
def e605785448078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605785448078 : Closed e605785448078 ∧ code e605785448078 = 9401878470286 := by decide
theorem cert_e605785448078 : check e605785448078 [[.under],[.under]] .sourceHead = true := by decide
def e605785448134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605785448134 : Closed e605785448134 ∧ code e605785448134 = 9401878470342 := by decide
theorem cert_e605785448134 : check e605785448134 [[.under],[.under]] .sourceHead = true := by decide
def e605785450270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605785450270 : Closed e605785450270 ∧ code e605785450270 = 9401878472478 := by decide
theorem cert_e605785450270 : check e605785450270 [[.under],[.under]] .sourceHead = true := by decide
def e605785450382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605785450382 : Closed e605785450382 ∧ code e605785450382 = 9401878472590 := by decide
theorem cert_e605785450382 : check e605785450382 [[.under],[.under]] .sourceHead = true := by decide
def e605785453342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605785453342 : Closed e605785453342 ∧ code e605785453342 = 9401878475550 := by decide
theorem cert_e605785453342 : check e605785453342 [[.under],[.under]] .sourceHead = true := by decide
def e605785453510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605785453510 : Closed e605785453510 ∧ code e605785453510 = 9401878475718 := by decide
theorem cert_e605785453510 : check e605785453510 [[.under],[.under]] .sourceHead = true := by decide
def e605785454990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605785454990 : Closed e605785454990 ∧ code e605785454990 = 9401878477198 := by decide
theorem cert_e605785454990 : check e605785454990 [[.under],[.under]] .sourceHead = true := by decide
def e605785455046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605785455046 : Closed e605785455046 ∧ code e605785455046 = 9401878477254 := by decide
theorem cert_e605785455046 : check e605785455046 [[.under],[.under]] .sourceHead = true := by decide
def e605806401246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e605806401246 : Closed e605806401246 ∧ code e605806401246 = 9401899423454 := by decide
theorem cert_e605806401246 : check e605806401246 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806401270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e605806401270 : Closed e605806401270 ∧ code e605806401270 = 9401899423478 := by decide
theorem cert_e605806401270 : check e605806401270 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806401374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e605806401374 : Closed e605806401374 ∧ code e605806401374 = 9401899423582 := by decide
theorem cert_e605806401374 : check e605806401374 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806401402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e605806401402 : Closed e605806401402 ∧ code e605806401402 = 9401899423610 := by decide
theorem cert_e605806401402 : check e605806401402 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806401494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e605806401494 : Closed e605806401494 ∧ code e605806401494 = 9401899423702 := by decide
theorem cert_e605806401494 : check e605806401494 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806401498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e605806401498 : Closed e605806401498 ∧ code e605806401498 = 9401899423706 := by decide
theorem cert_e605806401498 : check e605806401498 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806402014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e605806402014 : Closed e605806402014 ∧ code e605806402014 = 9401899424222 := by decide
theorem cert_e605806402014 : check e605806402014 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806402038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e605806402038 : Closed e605806402038 ∧ code e605806402038 = 9401899424246 := by decide
theorem cert_e605806402038 : check e605806402038 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806402782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605806402782 : Closed e605806402782 ∧ code e605806402782 = 9401899424990 := by decide
theorem cert_e605806402782 : check e605806402782 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806402810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605806402810 : Closed e605806402810 ∧ code e605806402810 = 9401899425018 := by decide
theorem cert_e605806402810 : check e605806402810 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806403382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605806403382 : Closed e605806403382 ∧ code e605806403382 = 9401899425590 := by decide
theorem cert_e605806403382 : check e605806403382 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806403386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605806403386 : Closed e605806403386 ∧ code e605806403386 = 9401899425594 := by decide
theorem cert_e605806403386 : check e605806403386 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806418158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e605806418158 : Closed e605806418158 ∧ code e605806418158 = 9401899440366 := by decide
theorem cert_e605806418158 : check e605806418158 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806418166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e605806418166 : Closed e605806418166 ∧ code e605806418166 = 9401899440374 := by decide
theorem cert_e605806418166 : check e605806418166 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806418718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e605806418718 : Closed e605806418718 ∧ code e605806418718 = 9401899440926 := by decide
theorem cert_e605806418718 : check e605806418718 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806418830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e605806418830 : Closed e605806418830 ∧ code e605806418830 = 9401899441038 := by decide
theorem cert_e605806418830 : check e605806418830 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806419054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e605806419054 : Closed e605806419054 ∧ code e605806419054 = 9401899441262 := by decide
theorem cert_e605806419054 : check e605806419054 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806419066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e605806419066 : Closed e605806419066 ∧ code e605806419066 = 9401899441274 := by decide
theorem cert_e605806419066 : check e605806419066 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806419230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e605806419230 : Closed e605806419230 ∧ code e605806419230 = 9401899441438 := by decide
theorem cert_e605806419230 : check e605806419230 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806419398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e605806419398 : Closed e605806419398 ∧ code e605806419398 = 9401899441606 := by decide
theorem cert_e605806419398 : check e605806419398 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806419510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e605806419510 : Closed e605806419510 ∧ code e605806419510 = 9401899441718 := by decide
theorem cert_e605806419510 : check e605806419510 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806419514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e605806419514 : Closed e605806419514 ∧ code e605806419514 = 9401899441722 := by decide
theorem cert_e605806419514 : check e605806419514 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806419598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e605806419598 : Closed e605806419598 ∧ code e605806419598 = 9401899441806 := by decide
theorem cert_e605806419598 : check e605806419598 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806419654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e605806419654 : Closed e605806419654 ∧ code e605806419654 = 9401899441862 := by decide
theorem cert_e605806419654 : check e605806419654 [[.under],[.under],[.under]] .sourceHead = true := by decide
end Blc.Floor43
