import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e599820628766 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e599820628766 : Closed e599820628766 ∧ code e599820628766 = 9395913650974 := by decide
theorem cert_e599820628766 : check e599820628766 [[.under]] .sourceHead = true := by decide
def e599820628934 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e599820628934 : Closed e599820628934 ∧ code e599820628934 = 9395913651142 := by decide
theorem cert_e599820628934 : check e599820628934 [[.under]] .sourceHead = true := by decide
def e599820630414 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e599820630414 : Closed e599820630414 ∧ code e599820630414 = 9395913652622 := by decide
theorem cert_e599820630414 : check e599820630414 [[.under]] .sourceHead = true := by decide
def e599820630470 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e599820630470 : Closed e599820630470 ∧ code e599820630470 = 9395913652678 := by decide
theorem cert_e599820630470 : check e599820630470 [[.under]] .sourceHead = true := by decide
def e599825323742 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e599825323742 : Closed e599825323742 ∧ code e599825323742 = 9395918345950 := by decide
theorem cert_e599825323742 : check e599825323742 [[.under]] .sourceHead = true := by decide
def e599825323766 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e599825323766 : Closed e599825323766 ∧ code e599825323766 = 9395918345974 := by decide
theorem cert_e599825323766 : check e599825323766 [[.under]] .sourceHead = true := by decide
def e599825323870 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e599825323870 : Closed e599825323870 ∧ code e599825323870 = 9395918346078 := by decide
theorem cert_e599825323870 : check e599825323870 [[.under]] .sourceHead = true := by decide
def e599825323898 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e599825323898 : Closed e599825323898 ∧ code e599825323898 = 9395918346106 := by decide
theorem cert_e599825323898 : check e599825323898 [[.under]] .sourceHead = true := by decide
def e599825323990 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e599825323990 : Closed e599825323990 ∧ code e599825323990 = 9395918346198 := by decide
theorem cert_e599825323990 : check e599825323990 [[.under]] .sourceHead = true := by decide
def e599825323994 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e599825323994 : Closed e599825323994 ∧ code e599825323994 = 9395918346202 := by decide
theorem cert_e599825323994 : check e599825323994 [[.under]] .sourceHead = true := by decide
def e599825324510 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e599825324510 : Closed e599825324510 ∧ code e599825324510 = 9395918346718 := by decide
theorem cert_e599825324510 : check e599825324510 [[.under]] .sourceHead = true := by decide
def e599825324534 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e599825324534 : Closed e599825324534 ∧ code e599825324534 = 9395918346742 := by decide
theorem cert_e599825324534 : check e599825324534 [[.under]] .sourceHead = true := by decide
def e599825325278 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e599825325278 : Closed e599825325278 ∧ code e599825325278 = 9395918347486 := by decide
theorem cert_e599825325278 : check e599825325278 [[.under]] .sourceHead = true := by decide
def e599825325306 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e599825325306 : Closed e599825325306 ∧ code e599825325306 = 9395918347514 := by decide
theorem cert_e599825325306 : check e599825325306 [[.under]] .sourceHead = true := by decide
def e599825325878 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e599825325878 : Closed e599825325878 ∧ code e599825325878 = 9395918348086 := by decide
theorem cert_e599825325878 : check e599825325878 [[.under]] .sourceHead = true := by decide
def e599825325882 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e599825325882 : Closed e599825325882 ∧ code e599825325882 = 9395918348090 := by decide
theorem cert_e599825325882 : check e599825325882 [[.under]] .sourceHead = true := by decide
def e599825340654 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e599825340654 : Closed e599825340654 ∧ code e599825340654 = 9395918362862 := by decide
theorem cert_e599825340654 : check e599825340654 [[.under]] .sourceHead = true := by decide
def e599825340662 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e599825340662 : Closed e599825340662 ∧ code e599825340662 = 9395918362870 := by decide
theorem cert_e599825340662 : check e599825340662 [[.under]] .sourceHead = true := by decide
def e599825341214 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e599825341214 : Closed e599825341214 ∧ code e599825341214 = 9395918363422 := by decide
theorem cert_e599825341214 : check e599825341214 [[.under]] .sourceHead = true := by decide
def e599825341326 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e599825341326 : Closed e599825341326 ∧ code e599825341326 = 9395918363534 := by decide
theorem cert_e599825341326 : check e599825341326 [[.under]] .sourceHead = true := by decide
def e599825341550 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e599825341550 : Closed e599825341550 ∧ code e599825341550 = 9395918363758 := by decide
theorem cert_e599825341550 : check e599825341550 [[.under]] .sourceHead = true := by decide
def e599825341562 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e599825341562 : Closed e599825341562 ∧ code e599825341562 = 9395918363770 := by decide
theorem cert_e599825341562 : check e599825341562 [[.under]] .sourceHead = true := by decide
def e599825341726 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e599825341726 : Closed e599825341726 ∧ code e599825341726 = 9395918363934 := by decide
theorem cert_e599825341726 : check e599825341726 [[.under]] .sourceHead = true := by decide
def e599825341894 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e599825341894 : Closed e599825341894 ∧ code e599825341894 = 9395918364102 := by decide
theorem cert_e599825341894 : check e599825341894 [[.under]] .sourceHead = true := by decide
def e599825342006 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e599825342006 : Closed e599825342006 ∧ code e599825342006 = 9395918364214 := by decide
theorem cert_e599825342006 : check e599825342006 [[.under]] .sourceHead = true := by decide
def e599825342010 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e599825342010 : Closed e599825342010 ∧ code e599825342010 = 9395918364218 := by decide
theorem cert_e599825342010 : check e599825342010 [[.under]] .sourceHead = true := by decide
def e599825342094 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e599825342094 : Closed e599825342094 ∧ code e599825342094 = 9395918364302 := by decide
theorem cert_e599825342094 : check e599825342094 [[.under]] .sourceHead = true := by decide
def e599825342150 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e599825342150 : Closed e599825342150 ∧ code e599825342150 = 9395918364358 := by decide
theorem cert_e599825342150 : check e599825342150 [[.under]] .sourceHead = true := by decide
def e599825344286 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e599825344286 : Closed e599825344286 ∧ code e599825344286 = 9395918366494 := by decide
theorem cert_e599825344286 : check e599825344286 [[.under]] .sourceHead = true := by decide
def e599825344398 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e599825344398 : Closed e599825344398 ∧ code e599825344398 = 9395918366606 := by decide
theorem cert_e599825344398 : check e599825344398 [[.under]] .sourceHead = true := by decide
def e599825347358 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e599825347358 : Closed e599825347358 ∧ code e599825347358 = 9395918369566 := by decide
theorem cert_e599825347358 : check e599825347358 [[.under]] .sourceHead = true := by decide
def e599825347526 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e599825347526 : Closed e599825347526 ∧ code e599825347526 = 9395918369734 := by decide
theorem cert_e599825347526 : check e599825347526 [[.under]] .sourceHead = true := by decide
def e599825349006 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e599825349006 : Closed e599825349006 ∧ code e599825349006 = 9395918371214 := by decide
theorem cert_e599825349006 : check e599825349006 [[.under]] .sourceHead = true := by decide
def e599825349062 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e599825349062 : Closed e599825349062 ∧ code e599825349062 = 9395918371270 := by decide
theorem cert_e599825349062 : check e599825349062 [[.under]] .sourceHead = true := by decide
def e601343378134 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601343378134 : Closed e601343378134 ∧ code e601343378134 = 9397436400342 := by decide
theorem cert_e601343378134 : check e601343378134 [[.under]] .width = true := by decide
def e601343378138 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601343378138 : Closed e601343378138 ∧ code e601343378138 = 9397436400346 := by decide
theorem cert_e601343378138 : check e601343378138 [[.under]] .width = true := by decide
def e601343378154 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601343378154 : Closed e601343378154 ∧ code e601343378154 = 9397436400362 := by decide
theorem cert_e601343378154 : check e601343378154 [[.under]] .width = true := by decide
def e601343378230 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601343378230 : Closed e601343378230 ∧ code e601343378230 = 9397436400438 := by decide
theorem cert_e601343378230 : check e601343378230 [[.under]] .width = true := by decide
def e601343378234 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601343378234 : Closed e601343378234 ∧ code e601343378234 = 9397436400442 := by decide
theorem cert_e601343378234 : check e601343378234 [[.under]] .width = true := by decide
def e601343378330 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601343378330 : Closed e601343378330 ∧ code e601343378330 = 9397436400538 := by decide
theorem cert_e601343378330 : check e601343378330 [[.under]] .width = true := by decide
def e601343518234 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601343518234 : Closed e601343518234 ∧ code e601343518234 = 9397436540442 := by decide
theorem cert_e601343518234 : check e601343518234 [[.under]] .width = true := by decide
def e601343574742 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601343574742 : Closed e601343574742 ∧ code e601343574742 = 9397436596950 := by decide
theorem cert_e601343574742 : check e601343574742 [[.under]] .width = true := by decide
def e601343574746 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601343574746 : Closed e601343574746 ∧ code e601343574746 = 9397436596954 := by decide
theorem cert_e601343574746 : check e601343574746 [[.under]] .width = true := by decide
def e601343574762 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601343574762 : Closed e601343574762 ∧ code e601343574762 = 9397436596970 := by decide
theorem cert_e601343574762 : check e601343574762 [[.under]] .width = true := by decide
def e601343574838 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601343574838 : Closed e601343574838 ∧ code e601343574838 = 9397436597046 := by decide
theorem cert_e601343574838 : check e601343574838 [[.under]] .width = true := by decide
def e601343574842 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601343574842 : Closed e601343574842 ∧ code e601343574842 = 9397436597050 := by decide
theorem cert_e601343574842 : check e601343574842 [[.under]] .width = true := by decide
def e601343574938 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601343574938 : Closed e601343574938 ∧ code e601343574938 = 9397436597146 := by decide
theorem cert_e601343574938 : check e601343574938 [[.under]] .width = true := by decide
def e601343583770 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601343583770 : Closed e601343583770 ∧ code e601343583770 = 9397436605978 := by decide
theorem cert_e601343583770 : check e601343583770 [[.under]] .width = true := by decide
def e601344426710 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601344426710 : Closed e601344426710 ∧ code e601344426710 = 9397437448918 := by decide
theorem cert_e601344426710 : check e601344426710 [[.under]] .width = true := by decide
def e601344426714 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601344426714 : Closed e601344426714 ∧ code e601344426714 = 9397437448922 := by decide
theorem cert_e601344426714 : check e601344426714 [[.under]] .width = true := by decide
def e601344426730 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601344426730 : Closed e601344426730 ∧ code e601344426730 = 9397437448938 := by decide
theorem cert_e601344426730 : check e601344426730 [[.under]] .width = true := by decide
def e601344426806 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601344426806 : Closed e601344426806 ∧ code e601344426806 = 9397437449014 := by decide
theorem cert_e601344426806 : check e601344426806 [[.under]] .width = true := by decide
def e601344426810 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601344426810 : Closed e601344426810 ∧ code e601344426810 = 9397437449018 := by decide
theorem cert_e601344426810 : check e601344426810 [[.under]] .width = true := by decide
def e601344426906 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601344426906 : Closed e601344426906 ∧ code e601344426906 = 9397437449114 := by decide
theorem cert_e601344426906 : check e601344426906 [[.under]] .width = true := by decide
def e601344656086 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601344656086 : Closed e601344656086 ∧ code e601344656086 = 9397437678294 := by decide
theorem cert_e601344656086 : check e601344656086 [[.under]] .width = true := by decide
def e601344656090 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601344656090 : Closed e601344656090 ∧ code e601344656090 = 9397437678298 := by decide
theorem cert_e601344656090 : check e601344656090 [[.under]] .width = true := by decide
def e601344656106 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601344656106 : Closed e601344656106 ∧ code e601344656106 = 9397437678314 := by decide
theorem cert_e601344656106 : check e601344656106 [[.under]] .width = true := by decide
def e601344656182 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601344656182 : Closed e601344656182 ∧ code e601344656182 = 9397437678390 := by decide
theorem cert_e601344656182 : check e601344656182 [[.under]] .width = true := by decide
def e601344656186 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601344656186 : Closed e601344656186 ∧ code e601344656186 = 9397437678394 := by decide
theorem cert_e601344656186 : check e601344656186 [[.under]] .width = true := by decide
def e601344656282 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601344656282 : Closed e601344656282 ∧ code e601344656282 = 9397437678490 := by decide
theorem cert_e601344656282 : check e601344656282 [[.under]] .width = true := by decide
def e601345091098 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601345091098 : Closed e601345091098 ∧ code e601345091098 = 9397438113306 := by decide
theorem cert_e601345091098 : check e601345091098 [[.under]] .width = true := by decide
def e601345205786 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601345205786 : Closed e601345205786 ∧ code e601345205786 = 9397438227994 := by decide
theorem cert_e601345205786 : check e601345205786 [[.under]] .width = true := by decide
def e601345409750 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601345409750 : Closed e601345409750 ∧ code e601345409750 = 9397438431958 := by decide
theorem cert_e601345409750 : check e601345409750 [[.under]] .width = true := by decide
def e601345409754 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601345409754 : Closed e601345409754 ∧ code e601345409754 = 9397438431962 := by decide
theorem cert_e601345409754 : check e601345409754 [[.under]] .width = true := by decide
def e601345409770 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601345409770 : Closed e601345409770 ∧ code e601345409770 = 9397438431978 := by decide
theorem cert_e601345409770 : check e601345409770 [[.under]] .width = true := by decide
def e601345409846 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601345409846 : Closed e601345409846 ∧ code e601345409846 = 9397438432054 := by decide
theorem cert_e601345409846 : check e601345409846 [[.under]] .width = true := by decide
def e601345409850 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601345409850 : Closed e601345409850 ∧ code e601345409850 = 9397438432058 := by decide
theorem cert_e601345409850 : check e601345409850 [[.under]] .width = true := by decide
def e601345409946 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601345409946 : Closed e601345409946 ∧ code e601345409946 = 9397438432154 := by decide
theorem cert_e601345409946 : check e601345409946 [[.under]] .width = true := by decide
def e601345418778 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601345418778 : Closed e601345418778 ∧ code e601345418778 = 9397438440986 := by decide
theorem cert_e601345418778 : check e601345418778 [[.under]] .width = true := by decide
def e601345442518 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601345442518 : Closed e601345442518 ∧ code e601345442518 = 9397438464726 := by decide
theorem cert_e601345442518 : check e601345442518 [[.under]] .width = true := by decide
def e601345442522 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601345442522 : Closed e601345442522 ∧ code e601345442522 = 9397438464730 := by decide
theorem cert_e601345442522 : check e601345442522 [[.under]] .width = true := by decide
def e601345442538 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601345442538 : Closed e601345442538 ∧ code e601345442538 = 9397438464746 := by decide
theorem cert_e601345442538 : check e601345442538 [[.under]] .width = true := by decide
def e601345442614 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601345442614 : Closed e601345442614 ∧ code e601345442614 = 9397438464822 := by decide
theorem cert_e601345442614 : check e601345442614 [[.under]] .width = true := by decide
def e601345442618 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601345442618 : Closed e601345442618 ∧ code e601345442618 = 9397438464826 := by decide
theorem cert_e601345442618 : check e601345442618 [[.under]] .width = true := by decide
def e601345442714 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601345442714 : Closed e601345442714 ∧ code e601345442714 = 9397438464922 := by decide
theorem cert_e601345442714 : check e601345442714 [[.under]] .width = true := by decide
def e601345467930 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601345467930 : Closed e601345467930 ∧ code e601345467930 = 9397438490138 := by decide
theorem cert_e601345467930 : check e601345467930 [[.under]] .width = true := by decide
def e601349669590 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601349669590 : Closed e601349669590 ∧ code e601349669590 = 9397442691798 := by decide
theorem cert_e601349669590 : check e601349669590 [[.under]] .width = true := by decide
def e601349669594 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601349669594 : Closed e601349669594 ∧ code e601349669594 = 9397442691802 := by decide
theorem cert_e601349669594 : check e601349669594 [[.under]] .width = true := by decide
def e601349669610 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601349669610 : Closed e601349669610 ∧ code e601349669610 = 9397442691818 := by decide
theorem cert_e601349669610 : check e601349669610 [[.under]] .width = true := by decide
def e601349669686 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601349669686 : Closed e601349669686 ∧ code e601349669686 = 9397442691894 := by decide
theorem cert_e601349669686 : check e601349669686 [[.under]] .width = true := by decide
def e601349669690 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601349669690 : Closed e601349669690 ∧ code e601349669690 = 9397442691898 := by decide
theorem cert_e601349669690 : check e601349669690 [[.under]] .width = true := by decide
def e601349669786 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601349669786 : Closed e601349669786 ∧ code e601349669786 = 9397442691994 := by decide
theorem cert_e601349669786 : check e601349669786 [[.under]] .width = true := by decide
def e601349809690 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601349809690 : Closed e601349809690 ∧ code e601349809690 = 9397442831898 := by decide
theorem cert_e601349809690 : check e601349809690 [[.under]] .width = true := by decide
def e601349866198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601349866198 : Closed e601349866198 ∧ code e601349866198 = 9397442888406 := by decide
theorem cert_e601349866198 : check e601349866198 [[.under]] .width = true := by decide
def e601349866202 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601349866202 : Closed e601349866202 ∧ code e601349866202 = 9397442888410 := by decide
theorem cert_e601349866202 : check e601349866202 [[.under]] .width = true := by decide
def e601349866218 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601349866218 : Closed e601349866218 ∧ code e601349866218 = 9397442888426 := by decide
theorem cert_e601349866218 : check e601349866218 [[.under]] .width = true := by decide
def e601349866294 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601349866294 : Closed e601349866294 ∧ code e601349866294 = 9397442888502 := by decide
theorem cert_e601349866294 : check e601349866294 [[.under]] .width = true := by decide
def e601349866298 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601349866298 : Closed e601349866298 ∧ code e601349866298 = 9397442888506 := by decide
theorem cert_e601349866298 : check e601349866298 [[.under]] .width = true := by decide
def e601349866394 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601349866394 : Closed e601349866394 ∧ code e601349866394 = 9397442888602 := by decide
theorem cert_e601349866394 : check e601349866394 [[.under]] .width = true := by decide
def e601349875226 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601349875226 : Closed e601349875226 ∧ code e601349875226 = 9397442897434 := by decide
theorem cert_e601349875226 : check e601349875226 [[.under]] .width = true := by decide
def e601355961046 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601355961046 : Closed e601355961046 ∧ code e601355961046 = 9397448983254 := by decide
theorem cert_e601355961046 : check e601355961046 [[.under]] .width = true := by decide
def e601355961050 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601355961050 : Closed e601355961050 ∧ code e601355961050 = 9397448983258 := by decide
theorem cert_e601355961050 : check e601355961050 [[.under]] .width = true := by decide
def e601355961066 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601355961066 : Closed e601355961066 ∧ code e601355961066 = 9397448983274 := by decide
theorem cert_e601355961066 : check e601355961066 [[.under]] .width = true := by decide
def e601355961142 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601355961142 : Closed e601355961142 ∧ code e601355961142 = 9397448983350 := by decide
theorem cert_e601355961142 : check e601355961142 [[.under]] .width = true := by decide
def e601355961146 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601355961146 : Closed e601355961146 ∧ code e601355961146 = 9397448983354 := by decide
theorem cert_e601355961146 : check e601355961146 [[.under]] .width = true := by decide
def e601355961242 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601355961242 : Closed e601355961242 ∧ code e601355961242 = 9397448983450 := by decide
theorem cert_e601355961242 : check e601355961242 [[.under]] .width = true := by decide
def e601356190422 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601356190422 : Closed e601356190422 ∧ code e601356190422 = 9397449212630 := by decide
theorem cert_e601356190422 : check e601356190422 [[.under]] .width = true := by decide
def e601356190426 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601356190426 : Closed e601356190426 ∧ code e601356190426 = 9397449212634 := by decide
theorem cert_e601356190426 : check e601356190426 [[.under]] .width = true := by decide
def e601356190442 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601356190442 : Closed e601356190442 ∧ code e601356190442 = 9397449212650 := by decide
theorem cert_e601356190442 : check e601356190442 [[.under]] .width = true := by decide
def e601356190518 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601356190518 : Closed e601356190518 ∧ code e601356190518 = 9397449212726 := by decide
theorem cert_e601356190518 : check e601356190518 [[.under]] .width = true := by decide
def e601356190522 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601356190522 : Closed e601356190522 ∧ code e601356190522 = 9397449212730 := by decide
theorem cert_e601356190522 : check e601356190522 [[.under]] .width = true := by decide
def e601356190618 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601356190618 : Closed e601356190618 ∧ code e601356190618 = 9397449212826 := by decide
theorem cert_e601356190618 : check e601356190618 [[.under]] .width = true := by decide
def e601359246874 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601359246874 : Closed e601359246874 ∧ code e601359246874 = 9397452269082 := by decide
theorem cert_e601359246874 : check e601359246874 [[.under]] .width = true := by decide
def e601359361562 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601359361562 : Closed e601359361562 ∧ code e601359361562 = 9397452383770 := by decide
theorem cert_e601359361562 : check e601359361562 [[.under]] .width = true := by decide
def e601360876246 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601360876246 : Closed e601360876246 ∧ code e601360876246 = 9397453898454 := by decide
theorem cert_e601360876246 : check e601360876246 [[.under]] .width = true := by decide
def e601360876250 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601360876250 : Closed e601360876250 ∧ code e601360876250 = 9397453898458 := by decide
theorem cert_e601360876250 : check e601360876250 [[.under]] .width = true := by decide
def e601360876266 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601360876266 : Closed e601360876266 ∧ code e601360876266 = 9397453898474 := by decide
theorem cert_e601360876266 : check e601360876266 [[.under]] .width = true := by decide
def e601360876342 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601360876342 : Closed e601360876342 ∧ code e601360876342 = 9397453898550 := by decide
theorem cert_e601360876342 : check e601360876342 [[.under]] .width = true := by decide
def e601360876346 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601360876346 : Closed e601360876346 ∧ code e601360876346 = 9397453898554 := by decide
theorem cert_e601360876346 : check e601360876346 [[.under]] .width = true := by decide
def e601360876442 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601360876442 : Closed e601360876442 ∧ code e601360876442 = 9397453898650 := by decide
theorem cert_e601360876442 : check e601360876442 [[.under]] .width = true := by decide
def e601360885274 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601360885274 : Closed e601360885274 ∧ code e601360885274 = 9397453907482 := by decide
theorem cert_e601360885274 : check e601360885274 [[.under]] .width = true := by decide
def e601360909014 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601360909014 : Closed e601360909014 ∧ code e601360909014 = 9397453931222 := by decide
theorem cert_e601360909014 : check e601360909014 [[.under]] .width = true := by decide
def e601360909018 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601360909018 : Closed e601360909018 ∧ code e601360909018 = 9397453931226 := by decide
theorem cert_e601360909018 : check e601360909018 [[.under]] .width = true := by decide
def e601360909034 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601360909034 : Closed e601360909034 ∧ code e601360909034 = 9397453931242 := by decide
theorem cert_e601360909034 : check e601360909034 [[.under]] .width = true := by decide
def e601360909110 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601360909110 : Closed e601360909110 ∧ code e601360909110 = 9397453931318 := by decide
theorem cert_e601360909110 : check e601360909110 [[.under]] .width = true := by decide
def e601360909114 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601360909114 : Closed e601360909114 ∧ code e601360909114 = 9397453931322 := by decide
theorem cert_e601360909114 : check e601360909114 [[.under]] .width = true := by decide
def e601360909210 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601360909210 : Closed e601360909210 ∧ code e601360909210 = 9397453931418 := by decide
theorem cert_e601360909210 : check e601360909210 [[.under]] .width = true := by decide
def e601360934426 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601360934426 : Closed e601360934426 ∧ code e601360934426 = 9397453956634 := by decide
theorem cert_e601360934426 : check e601360934426 [[.under]] .width = true := by decide
def e601477277210 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477277210 : Closed e601477277210 ∧ code e601477277210 = 9397570299418 := by decide
theorem cert_e601477277210 : check e601477277210 [[.under]] .width = true := by decide
def e601477309978 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477309978 : Closed e601477309978 ∧ code e601477309978 = 9397570332186 := by decide
theorem cert_e601477309978 : check e601477309978 [[.under]] .width = true := by decide
def e601477539354 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477539354 : Closed e601477539354 ∧ code e601477539354 = 9397570561562 := by decide
theorem cert_e601477539354 : check e601477539354 [[.under]] .width = true := by decide
def e601477588506 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477588506 : Closed e601477588506 ∧ code e601477588506 = 9397570610714 := by decide
theorem cert_e601477588506 : check e601477588506 [[.under]] .width = true := by decide
def e601477703194 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477703194 : Closed e601477703194 ∧ code e601477703194 = 9397570725402 := by decide
theorem cert_e601477703194 : check e601477703194 [[.under]] .width = true := by decide
def e601477719578 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601477719578 : Closed e601477719578 ∧ code e601477719578 = 9397570741786 := by decide
theorem cert_e601477719578 : check e601477719578 [[.under]] .width = true := by decide
def e601478587930 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601478587930 : Closed e601478587930 ∧ code e601478587930 = 9397571610138 := by decide
theorem cert_e601478587930 : check e601478587930 [[.under]] .width = true := by decide
def e601478637082 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601478637082 : Closed e601478637082 ∧ code e601478637082 = 9397571659290 := by decide
theorem cert_e601478637082 : check e601478637082 [[.under]] .width = true := by decide
def e601478833690 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601478833690 : Closed e601478833690 ∧ code e601478833690 = 9397571855898 := by decide
theorem cert_e601478833690 : check e601478833690 [[.under]] .width = true := by decide
def e601479276058 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601479276058 : Closed e601479276058 ∧ code e601479276058 = 9397572298266 := by decide
theorem cert_e601479276058 : check e601479276058 [[.under]] .width = true := by decide
def e601479292442 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601479292442 : Closed e601479292442 ∧ code e601479292442 = 9397572314650 := by decide
theorem cert_e601479292442 : check e601479292442 [[.under]] .width = true := by decide
def e601479357978 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601479357978 : Closed e601479357978 ∧ code e601479357978 = 9397572380186 := by decide
theorem cert_e601479357978 : check e601479357978 [[.under]] .width = true := by decide
def e601481921238 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601481921238 : Closed e601481921238 ∧ code e601481921238 = 9397574943446 := by decide
theorem cert_e601481921238 : check e601481921238 [[.under]] .width = true := by decide
def e601481921242 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601481921242 : Closed e601481921242 ∧ code e601481921242 = 9397574943450 := by decide
theorem cert_e601481921242 : check e601481921242 [[.under]] .width = true := by decide
def e601481921258 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601481921258 : Closed e601481921258 ∧ code e601481921258 = 9397574943466 := by decide
theorem cert_e601481921258 : check e601481921258 [[.under]] .width = true := by decide
def e601481921334 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601481921334 : Closed e601481921334 ∧ code e601481921334 = 9397574943542 := by decide
theorem cert_e601481921334 : check e601481921334 [[.under]] .width = true := by decide
def e601481921338 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601481921338 : Closed e601481921338 ∧ code e601481921338 = 9397574943546 := by decide
theorem cert_e601481921338 : check e601481921338 [[.under]] .width = true := by decide
def e601481921434 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601481921434 : Closed e601481921434 ∧ code e601481921434 = 9397574943642 := by decide
theorem cert_e601481921434 : check e601481921434 [[.under]] .width = true := by decide
def e601481986774 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601481986774 : Closed e601481986774 ∧ code e601481986774 = 9397575008982 := by decide
theorem cert_e601481986774 : check e601481986774 [[.under]] .width = true := by decide
def e601481986778 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601481986778 : Closed e601481986778 ∧ code e601481986778 = 9397575008986 := by decide
theorem cert_e601481986778 : check e601481986778 [[.under]] .width = true := by decide
def e601481986794 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601481986794 : Closed e601481986794 ∧ code e601481986794 = 9397575009002 := by decide
theorem cert_e601481986794 : check e601481986794 [[.under]] .width = true := by decide
def e601481986870 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601481986870 : Closed e601481986870 ∧ code e601481986870 = 9397575009078 := by decide
theorem cert_e601481986870 : check e601481986870 [[.under]] .width = true := by decide
def e601481986874 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601481986874 : Closed e601481986874 ∧ code e601481986874 = 9397575009082 := by decide
theorem cert_e601481986874 : check e601481986874 [[.under]] .width = true := by decide
def e601481986970 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601481986970 : Closed e601481986970 ∧ code e601481986970 = 9397575009178 := by decide
theorem cert_e601481986970 : check e601481986970 [[.under]] .width = true := by decide
def e601483568666 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483568666 : Closed e601483568666 ∧ code e601483568666 = 9397576590874 := by decide
theorem cert_e601483568666 : check e601483568666 [[.under]] .width = true := by decide
def e601483601434 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483601434 : Closed e601483601434 ∧ code e601483601434 = 9397576623642 := by decide
theorem cert_e601483601434 : check e601483601434 [[.under]] .width = true := by decide
def e601483830810 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483830810 : Closed e601483830810 ∧ code e601483830810 = 9397576853018 := by decide
theorem cert_e601483830810 : check e601483830810 [[.under]] .width = true := by decide
def e601483879962 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483879962 : Closed e601483879962 ∧ code e601483879962 = 9397576902170 := by decide
theorem cert_e601483879962 : check e601483879962 [[.under]] .width = true := by decide
def e601483994650 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601483994650 : Closed e601483994650 ∧ code e601483994650 = 9397577016858 := by decide
theorem cert_e601483994650 : check e601483994650 [[.under]] .width = true := by decide
def e601484011034 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601484011034 : Closed e601484011034 ∧ code e601484011034 = 9397577033242 := by decide
theorem cert_e601484011034 : check e601484011034 [[.under]] .width = true := by decide
def e601485141530 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601485141530 : Closed e601485141530 ∧ code e601485141530 = 9397578163738 := by decide
theorem cert_e601485141530 : check e601485141530 [[.under]] .width = true := by decide
def e601485174298 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601485174298 : Closed e601485174298 ∧ code e601485174298 = 9397578196506 := by decide
theorem cert_e601485174298 : check e601485174298 [[.under]] .width = true := by decide
def e601486508758 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601486508758 : Closed e601486508758 ∧ code e601486508758 = 9397579530966 := by decide
theorem cert_e601486508758 : check e601486508758 [[.under]] .width = true := by decide
def e601486508762 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601486508762 : Closed e601486508762 ∧ code e601486508762 = 9397579530970 := by decide
theorem cert_e601486508762 : check e601486508762 [[.under]] .width = true := by decide
def e601486508778 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601486508778 : Closed e601486508778 ∧ code e601486508778 = 9397579530986 := by decide
theorem cert_e601486508778 : check e601486508778 [[.under]] .width = true := by decide
def e601486508854 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601486508854 : Closed e601486508854 ∧ code e601486508854 = 9397579531062 := by decide
theorem cert_e601486508854 : check e601486508854 [[.under]] .width = true := by decide
def e601486508858 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601486508858 : Closed e601486508858 ∧ code e601486508858 = 9397579531066 := by decide
theorem cert_e601486508858 : check e601486508858 [[.under]] .width = true := by decide
def e601486508954 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601486508954 : Closed e601486508954 ∧ code e601486508954 = 9397579531162 := by decide
theorem cert_e601486508954 : check e601486508954 [[.under]] .width = true := by decide
def e601486714394 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601486714394 : Closed e601486714394 ∧ code e601486714394 = 9397579736602 := by decide
theorem cert_e601486714394 : check e601486714394 [[.under]] .width = true := by decide
def e601486763546 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601486763546 : Closed e601486763546 ∧ code e601486763546 = 9397579785754 := by decide
theorem cert_e601486763546 : check e601486763546 [[.under]] .width = true := by decide
def e601487181230 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601487181230 : Closed e601487181230 ∧ code e601487181230 = 9397580203438 := by decide
theorem cert_e601487181230 : check e601487181230 [[.under]] .width = true := by decide
def e601487181242 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601487181242 : Closed e601487181242 ∧ code e601487181242 = 9397580203450 := by decide
theorem cert_e601487181242 : check e601487181242 [[.under]] .width = true := by decide
end Blc.Floor43
