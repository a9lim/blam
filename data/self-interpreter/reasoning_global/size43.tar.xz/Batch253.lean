import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405917394970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917394970 : Closed e2405917394970 ∧ code e2405917394970 = 11202010417178 := by decide
theorem cert_e2405917394970 : check e2405917394970 [[]] .width = true := by decide
def e2405917401114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917401114 : Closed e2405917401114 ∧ code e2405917401114 = 11202010423322 := by decide
theorem cert_e2405917401114 : check e2405917401114 [[]] .width = true := by decide
def e2405917401206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405917401206 : Closed e2405917401206 ∧ code e2405917401206 = 11202010423414 := by decide
private def t_e2405917401206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405917401206 : ¬ IsSelfInterpreter e2405917401206 :=
  wSource (t := t_e2405917401206) (replay_sound (ps := []) (t := e2405917401206) (by decide)) (by decide)
def e2405917401450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405917401450 : Closed e2405917401450 ∧ code e2405917401450 = 11202010423658 := by decide
private def t_e2405917401450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405917401450 : ¬ IsSelfInterpreter e2405917401450 :=
  wSource (t := t_e2405917401450) (replay_sound (ps := []) (t := e2405917401450) (by decide)) (by decide)
def e2405917401498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405917401498 : Closed e2405917401498 ∧ code e2405917401498 = 11202010423706 := by decide
private def t_e2405917401498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405917401498 : ¬ IsSelfInterpreter e2405917401498 :=
  wSource (t := t_e2405917401498) (replay_sound (ps := []) (t := e2405917401498) (by decide)) (by decide)
def e2405917405382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405917405382 : Closed e2405917405382 ∧ code e2405917405382 = 11202010427590 := by decide
theorem cert_e2405917405382 : check e2405917405382 [[]] .width = true := by decide
def e2405917407258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917407258 : Closed e2405917407258 ∧ code e2405917407258 = 11202010429466 := by decide
theorem cert_e2405917407258 : check e2405917407258 [[]] .width = true := by decide
def e2405917419546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917419546 : Closed e2405917419546 ∧ code e2405917419546 = 11202010441754 := by decide
theorem cert_e2405917419546 : check e2405917419546 [[]] .width = true := by decide
def e2405917421082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917421082 : Closed e2405917421082 ∧ code e2405917421082 = 11202010443290 := by decide
private def t_e2405917421082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917421082 : ¬ IsSelfInterpreter e2405917421082 :=
  wSource (t := t_e2405917421082) (replay_sound (ps := []) (t := e2405917421082) (by decide)) (by decide)
def e2405917424154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917424154 : Closed e2405917424154 ∧ code e2405917424154 = 11202010446362 := by decide
private def t_e2405917424154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917424154 : ¬ IsSelfInterpreter e2405917424154 :=
  wSource (t := t_e2405917424154) (replay_sound (ps := []) (t := e2405917424154) (by decide)) (by decide)
def e2405917425690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405917425690 : Closed e2405917425690 ∧ code e2405917425690 = 11202010447898 := by decide
theorem cert_e2405917425690 : check e2405917425690 [[]] .width = true := by decide
def e2405917425782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405917425782 : Closed e2405917425782 ∧ code e2405917425782 = 11202010447990 := by decide
theorem cert_e2405917425782 : check e2405917425782 [[]] .width = true := by decide
def e2405917426026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405917426026 : Closed e2405917426026 ∧ code e2405917426026 = 11202010448234 := by decide
theorem cert_e2405917426026 : check e2405917426026 [[]] .width = true := by decide
def e2405917426074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405917426074 : Closed e2405917426074 ∧ code e2405917426074 = 11202010448282 := by decide
theorem cert_e2405917426074 : check e2405917426074 [[]] .width = true := by decide
def e2405917427082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405917427082 : Closed e2405917427082 ∧ code e2405917427082 = 11202010449290 := by decide
theorem cert_e2405917427082 : check e2405917427082 [[]] .width = true := by decide
def e2405917427106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405917427106 : Closed e2405917427106 ∧ code e2405917427106 = 11202010449314 := by decide
private def t_e2405917427106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2405917427106 : ¬ IsSelfInterpreter e2405917427106 :=
  wSource (t := t_e2405917427106) (replay_sound (ps := []) (t := e2405917427106) (by decide)) (by decide)
def e2405917427214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405917427214 : Closed e2405917427214 ∧ code e2405917427214 = 11202010449422 := by decide
theorem cert_e2405917427214 : check e2405917427214 [[]] .width = true := by decide
def e2405917427226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917427226 : Closed e2405917427226 ∧ code e2405917427226 = 11202010449434 := by decide
private def t_e2405917427226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2405917427226 : ¬ IsSelfInterpreter e2405917427226 :=
  wSource (t := t_e2405917427226) (replay_sound (ps := []) (t := e2405917427226) (by decide)) (by decide)
def e2405917427298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405917427298 : Closed e2405917427298 ∧ code e2405917427298 = 11202010449506 := by decide
theorem cert_e2405917427298 : check e2405917427298 [[]] .width = true := by decide
def e2405917442246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405917442246 : Closed e2405917442246 ∧ code e2405917442246 = 11202010464454 := by decide
theorem cert_e2405917442246 : check e2405917442246 [[]] .width = true := by decide
def e2405917450266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917450266 : Closed e2405917450266 ∧ code e2405917450266 = 11202010472474 := by decide
theorem cert_e2405917450266 : check e2405917450266 [[]] .width = true := by decide
def e2405917450358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405917450358 : Closed e2405917450358 ∧ code e2405917450358 = 11202010472566 := by decide
private def t_e2405917450358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405917450358 : ¬ IsSelfInterpreter e2405917450358 :=
  wSource (t := t_e2405917450358) (replay_sound (ps := []) (t := e2405917450358) (by decide)) (by decide)
def e2405917450602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405917450602 : Closed e2405917450602 ∧ code e2405917450602 = 11202010472810 := by decide
private def t_e2405917450602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405917450602 : ¬ IsSelfInterpreter e2405917450602 :=
  wSource (t := t_e2405917450602) (replay_sound (ps := []) (t := e2405917450602) (by decide)) (by decide)
def e2405917450650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405917450650 : Closed e2405917450650 ∧ code e2405917450650 = 11202010472858 := by decide
private def t_e2405917450650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405917450650 : ¬ IsSelfInterpreter e2405917450650 :=
  wSource (t := t_e2405917450650) (replay_sound (ps := []) (t := e2405917450650) (by decide)) (by decide)
def e2405917464602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405917464602 : Closed e2405917464602 ∧ code e2405917464602 = 11202010486810 := by decide
theorem cert_e2405917464602 : check e2405917464602 [[]] .width = true := by decide
def e2405917475014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405917475014 : Closed e2405917475014 ∧ code e2405917475014 = 11202010497222 := by decide
theorem cert_e2405917475014 : check e2405917475014 [[]] .width = true := by decide
def e2405917497882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917497882 : Closed e2405917497882 ∧ code e2405917497882 = 11202010520090 := by decide
private def t_e2405917497882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917497882 : ¬ IsSelfInterpreter e2405917497882 :=
  wSource (t := t_e2405917497882) (replay_sound (ps := []) (t := e2405917497882) (by decide)) (by decide)
def e2405917499418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917499418 : Closed e2405917499418 ∧ code e2405917499418 = 11202010521626 := by decide
theorem cert_e2405917499418 : check e2405917499418 [[]] .width = true := by decide
def e2405917499510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405917499510 : Closed e2405917499510 ∧ code e2405917499510 = 11202010521718 := by decide
private def t_e2405917499510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405917499510 : ¬ IsSelfInterpreter e2405917499510 :=
  wSource (t := t_e2405917499510) (replay_sound (ps := []) (t := e2405917499510) (by decide)) (by decide)
def e2405917499754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405917499754 : Closed e2405917499754 ∧ code e2405917499754 = 11202010521962 := by decide
private def t_e2405917499754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405917499754 : ¬ IsSelfInterpreter e2405917499754 :=
  wSource (t := t_e2405917499754) (replay_sound (ps := []) (t := e2405917499754) (by decide)) (by decide)
def e2405917499802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405917499802 : Closed e2405917499802 ∧ code e2405917499802 = 11202010522010 := by decide
private def t_e2405917499802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405917499802 : ¬ IsSelfInterpreter e2405917499802 :=
  wSource (t := t_e2405917499802) (replay_sound (ps := []) (t := e2405917499802) (by decide)) (by decide)
def e2405917578778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917578778 : Closed e2405917578778 ∧ code e2405917578778 = 11202010600986 := by decide
private def t_e2405917578778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917578778 : ¬ IsSelfInterpreter e2405917578778 :=
  wSource (t := t_e2405917578778) (replay_sound (ps := []) (t := e2405917578778) (by decide)) (by decide)
def e2405917579802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917579802 : Closed e2405917579802 ∧ code e2405917579802 = 11202010602010 := by decide
private def t_e2405917579802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917579802 : ¬ IsSelfInterpreter e2405917579802 :=
  wSource (t := t_e2405917579802) (replay_sound (ps := []) (t := e2405917579802) (by decide)) (by decide)
def e2405917583898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917583898 : Closed e2405917583898 ∧ code e2405917583898 = 11202010606106 := by decide
private def t_e2405917583898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917583898 : ¬ IsSelfInterpreter e2405917583898 :=
  wSource (t := t_e2405917583898) (replay_sound (ps := []) (t := e2405917583898) (by decide)) (by decide)
def e2405917603354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917603354 : Closed e2405917603354 ∧ code e2405917603354 = 11202010625562 := by decide
private def t_e2405917603354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917603354 : ¬ IsSelfInterpreter e2405917603354 :=
  wSource (t := t_e2405917603354) (replay_sound (ps := []) (t := e2405917603354) (by decide)) (by decide)
def e2405917604378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917604378 : Closed e2405917604378 ∧ code e2405917604378 = 11202010626586 := by decide
private def t_e2405917604378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917604378 : ¬ IsSelfInterpreter e2405917604378 :=
  wSource (t := t_e2405917604378) (replay_sound (ps := []) (t := e2405917604378) (by decide)) (by decide)
def e2405917614106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917614106 : Closed e2405917614106 ∧ code e2405917614106 = 11202010636314 := by decide
theorem cert_e2405917614106 : check e2405917614106 [[]] .width = true := by decide
def e2405917614198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405917614198 : Closed e2405917614198 ∧ code e2405917614198 = 11202010636406 := by decide
private def t_e2405917614198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405917614198 : ¬ IsSelfInterpreter e2405917614198 :=
  wSource (t := t_e2405917614198) (replay_sound (ps := []) (t := e2405917614198) (by decide)) (by decide)
def e2405917614442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405917614442 : Closed e2405917614442 ∧ code e2405917614442 = 11202010636650 := by decide
private def t_e2405917614442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405917614442 : ¬ IsSelfInterpreter e2405917614442 :=
  wSource (t := t_e2405917614442) (replay_sound (ps := []) (t := e2405917614442) (by decide)) (by decide)
def e2405917614490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405917614490 : Closed e2405917614490 ∧ code e2405917614490 = 11202010636698 := by decide
private def t_e2405917614490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405917614490 : ¬ IsSelfInterpreter e2405917614490 :=
  wSource (t := t_e2405917614490) (replay_sound (ps := []) (t := e2405917614490) (by decide)) (by decide)
def e2405917628954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405917628954 : Closed e2405917628954 ∧ code e2405917628954 = 11202010651162 := by decide
private def t_e2405917628954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405917628954 : ¬ IsSelfInterpreter e2405917628954 :=
  wSource (t := t_e2405917628954) (replay_sound (ps := []) (t := e2405917628954) (by decide)) (by decide)
def e2405917630490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405917630490 : Closed e2405917630490 ∧ code e2405917630490 = 11202010652698 := by decide
theorem cert_e2405917630490 : check e2405917630490 [[]] .width = true := by decide
def e2405917630582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405917630582 : Closed e2405917630582 ∧ code e2405917630582 = 11202010652790 := by decide
private def t_e2405917630582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405917630582 : ¬ IsSelfInterpreter e2405917630582 :=
  wSource (t := t_e2405917630582) (replay_sound (ps := []) (t := e2405917630582) (by decide)) (by decide)
def e2405917630826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405917630826 : Closed e2405917630826 ∧ code e2405917630826 = 11202010653034 := by decide
private def t_e2405917630826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405917630826 : ¬ IsSelfInterpreter e2405917630826 :=
  wSource (t := t_e2405917630826) (replay_sound (ps := []) (t := e2405917630826) (by decide)) (by decide)
def e2405917630874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405917630874 : Closed e2405917630874 ∧ code e2405917630874 = 11202010653082 := by decide
private def t_e2405917630874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405917630874 : ¬ IsSelfInterpreter e2405917630874 :=
  wSource (t := t_e2405917630874) (replay_sound (ps := []) (t := e2405917630874) (by decide)) (by decide)
def e2405921175578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405921175578 : Closed e2405921175578 ∧ code e2405921175578 = 11202014197786 := by decide
theorem cert_e2405921175578 : check e2405921175578 [[]] .width = true := by decide
def e2405921183770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405921183770 : Closed e2405921183770 ∧ code e2405921183770 = 11202014205978 := by decide
theorem cert_e2405921183770 : check e2405921183770 [[]] .width = true := by decide
def e2405921906714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405921906714 : Closed e2405921906714 ∧ code e2405921906714 = 11202014928922 := by decide
theorem cert_e2405921906714 : check e2405921906714 [[]] .width = true := by decide
def e2405921906806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405921906806 : Closed e2405921906806 ∧ code e2405921906806 = 11202014929014 := by decide
theorem cert_e2405921906806 : check e2405921906806 [[]] .width = true := by decide
def e2405921907050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405921907050 : Closed e2405921907050 ∧ code e2405921907050 = 11202014929258 := by decide
theorem cert_e2405921907050 : check e2405921907050 [[]] .width = true := by decide
def e2405921907098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405921907098 : Closed e2405921907098 ∧ code e2405921907098 = 11202014929306 := by decide
theorem cert_e2405921907098 : check e2405921907098 [[]] .width = true := by decide
def e2405921939482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405921939482 : Closed e2405921939482 ∧ code e2405921939482 = 11202014961690 := by decide
theorem cert_e2405921939482 : check e2405921939482 [[]] .width = true := by decide
def e2405921939574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405921939574 : Closed e2405921939574 ∧ code e2405921939574 = 11202014961782 := by decide
theorem cert_e2405921939574 : check e2405921939574 [[]] .width = true := by decide
def e2405921939818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405921939818 : Closed e2405921939818 ∧ code e2405921939818 = 11202014962026 := by decide
theorem cert_e2405921939818 : check e2405921939818 [[]] .width = true := by decide
def e2405921939866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405921939866 : Closed e2405921939866 ∧ code e2405921939866 = 11202014962074 := by decide
theorem cert_e2405921939866 : check e2405921939866 [[]] .width = true := by decide
def e2405923516614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405923516614 : Closed e2405923516614 ∧ code e2405923516614 = 11202016538822 := by decide
theorem cert_e2405923516614 : check e2405923516614 [[]] .width = true := by decide
def e2405923532998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405923532998 : Closed e2405923532998 ∧ code e2405923532998 = 11202016555206 := by decide
theorem cert_e2405923532998 : check e2405923532998 [[]] .width = true := by decide
def e2405923797018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405923797018 : Closed e2405923797018 ∧ code e2405923797018 = 11202016819226 := by decide
theorem cert_e2405923797018 : check e2405923797018 [[]] .width = true := by decide
def e2405923909830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405923909830 : Closed e2405923909830 ∧ code e2405923909830 = 11202016932038 := by decide
theorem cert_e2405923909830 : check e2405923909830 [[]] .width = true := by decide
def e2405923928090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405923928090 : Closed e2405923928090 ∧ code e2405923928090 = 11202016950298 := by decide
theorem cert_e2405923928090 : check e2405923928090 [[]] .width = true := by decide
def e2405923941914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405923941914 : Closed e2405923941914 ∧ code e2405923941914 = 11202016964122 := by decide
theorem cert_e2405923941914 : check e2405923941914 [[]] .width = true := by decide
def e2405923991750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405923991750 : Closed e2405923991750 ∧ code e2405923991750 = 11202017013958 := by decide
theorem cert_e2405923991750 : check e2405923991750 [[]] .width = true := by decide
def e2405924007450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405924007450 : Closed e2405924007450 ∧ code e2405924007450 = 11202017029658 := by decide
theorem cert_e2405924007450 : check e2405924007450 [[]] .width = true := by decide
def e2405924009498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405924009498 : Closed e2405924009498 ∧ code e2405924009498 = 11202017031706 := by decide
theorem cert_e2405924009498 : check e2405924009498 [[]] .width = true := by decide
def e2405925052442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405925052442 : Closed e2405925052442 ∧ code e2405925052442 = 11202018074650 := by decide
theorem cert_e2405925052442 : check e2405925052442 [[]] .width = true := by decide
def e2405925052534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405925052534 : Closed e2405925052534 ∧ code e2405925052534 = 11202018074742 := by decide
theorem cert_e2405925052534 : check e2405925052534 [[]] .width = true := by decide
def e2405925052778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405925052778 : Closed e2405925052778 ∧ code e2405925052778 = 11202018074986 := by decide
theorem cert_e2405925052778 : check e2405925052778 [[]] .width = true := by decide
def e2405925052826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405925052826 : Closed e2405925052826 ∧ code e2405925052826 = 11202018075034 := by decide
theorem cert_e2405925052826 : check e2405925052826 [[]] .width = true := by decide
def e2405925085210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405925085210 : Closed e2405925085210 ∧ code e2405925085210 = 11202018107418 := by decide
theorem cert_e2405925085210 : check e2405925085210 [[]] .width = true := by decide
def e2405925085302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405925085302 : Closed e2405925085302 ∧ code e2405925085302 = 11202018107510 := by decide
theorem cert_e2405925085302 : check e2405925085302 [[]] .width = true := by decide
def e2405925085546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405925085546 : Closed e2405925085546 ∧ code e2405925085546 = 11202018107754 := by decide
theorem cert_e2405925085546 : check e2405925085546 [[]] .width = true := by decide
def e2405925085594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405925085594 : Closed e2405925085594 ∧ code e2405925085594 = 11202018107802 := by decide
theorem cert_e2405925085594 : check e2405925085594 [[]] .width = true := by decide
def e2405926662342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405926662342 : Closed e2405926662342 ∧ code e2405926662342 = 11202019684550 := by decide
theorem cert_e2405926662342 : check e2405926662342 [[]] .width = true := by decide
def e2405926678726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405926678726 : Closed e2405926678726 ∧ code e2405926678726 = 11202019700934 := by decide
theorem cert_e2405926678726 : check e2405926678726 [[]] .width = true := by decide
def e2405927346202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405927346202 : Closed e2405927346202 ∧ code e2405927346202 = 11202020368410 := by decide
theorem cert_e2405927346202 : check e2405927346202 [[]] .width = true := by decide
def e2405927346294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405927346294 : Closed e2405927346294 ∧ code e2405927346294 = 11202020368502 := by decide
theorem cert_e2405927346294 : check e2405927346294 [[]] .width = true := by decide
def e2405927346538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405927346538 : Closed e2405927346538 ∧ code e2405927346538 = 11202020368746 := by decide
theorem cert_e2405927346538 : check e2405927346538 [[]] .width = true := by decide
def e2405927346586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405927346586 : Closed e2405927346586 ∧ code e2405927346586 = 11202020368794 := by decide
theorem cert_e2405927346586 : check e2405927346586 [[]] .width = true := by decide
def e2405927448774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405927448774 : Closed e2405927448774 ∧ code e2405927448774 = 11202020470982 := by decide
theorem cert_e2405927448774 : check e2405927448774 [[]] .width = true := by decide
def e2405927467034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405927467034 : Closed e2405927467034 ∧ code e2405927467034 = 11202020489242 := by decide
theorem cert_e2405927467034 : check e2405927467034 [[]] .width = true := by decide
def e2405927473350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405927473350 : Closed e2405927473350 ∧ code e2405927473350 = 11202020495558 := by decide
theorem cert_e2405927473350 : check e2405927473350 [[]] .width = true := by decide
def e2405927475226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405927475226 : Closed e2405927475226 ∧ code e2405927475226 = 11202020497434 := by decide
theorem cert_e2405927475226 : check e2405927475226 [[]] .width = true := by decide
def e2405927682246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405927682246 : Closed e2405927682246 ∧ code e2405927682246 = 11202020704454 := by decide
theorem cert_e2405927682246 : check e2405927682246 [[]] .width = true := by decide
def e2405927682774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405927682774 : Closed e2405927682774 ∧ code e2405927682774 = 11202020704982 := by decide
theorem cert_e2405927682774 : check e2405927682774 [[]] .width = true := by decide
def e2405927682778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405927682778 : Closed e2405927682778 ∧ code e2405927682778 = 11202020704986 := by decide
theorem cert_e2405927682778 : check e2405927682778 [[]] .width = true := by decide
def e2405927682794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405927682794 : Closed e2405927682794 ∧ code e2405927682794 = 11202020705002 := by decide
theorem cert_e2405927682794 : check e2405927682794 [[]] .width = true := by decide
def e2405927682870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405927682870 : Closed e2405927682870 ∧ code e2405927682870 = 11202020705078 := by decide
theorem cert_e2405927682870 : check e2405927682870 [[]] .width = true := by decide
def e2405927682874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405927682874 : Closed e2405927682874 ∧ code e2405927682874 = 11202020705082 := by decide
theorem cert_e2405927682874 : check e2405927682874 [[]] .width = true := by decide
def e2405927682958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405927682958 : Closed e2405927682958 ∧ code e2405927682958 = 11202020705166 := by decide
theorem cert_e2405927682958 : check e2405927682958 [[]] .width = true := by decide
def e2405927682970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405927682970 : Closed e2405927682970 ∧ code e2405927682970 = 11202020705178 := by decide
theorem cert_e2405927682970 : check e2405927682970 [[]] .width = true := by decide
def e2405927684890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405927684890 : Closed e2405927684890 ∧ code e2405927684890 = 11202020707098 := by decide
theorem cert_e2405927684890 : check e2405927684890 [[]] .width = true := by decide
def e2405927684934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405927684934 : Closed e2405927684934 ∧ code e2405927684934 = 11202020707142 := by decide
theorem cert_e2405927684934 : check e2405927684934 [[]] .width = true := by decide
def e2405927685174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405927685174 : Closed e2405927685174 ∧ code e2405927685174 = 11202020707382 := by decide
theorem cert_e2405927685174 : check e2405927685174 [[]] .width = true := by decide
def e2405927685178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405927685178 : Closed e2405927685178 ∧ code e2405927685178 = 11202020707386 := by decide
theorem cert_e2405927685178 : check e2405927685178 [[]] .width = true := by decide
def e2405927685318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405927685318 : Closed e2405927685318 ∧ code e2405927685318 = 11202020707526 := by decide
theorem cert_e2405927685318 : check e2405927685318 [[]] .width = true := by decide
def e2405927804954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405927804954 : Closed e2405927804954 ∧ code e2405927804954 = 11202020827162 := by decide
theorem cert_e2405927804954 : check e2405927804954 [[]] .width = true := by decide
def e2405927805046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405927805046 : Closed e2405927805046 ∧ code e2405927805046 = 11202020827254 := by decide
theorem cert_e2405927805046 : check e2405927805046 [[]] .width = true := by decide
def e2405927805290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405927805290 : Closed e2405927805290 ∧ code e2405927805290 = 11202020827498 := by decide
theorem cert_e2405927805290 : check e2405927805290 [[]] .width = true := by decide
def e2405927805338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405927805338 : Closed e2405927805338 ∧ code e2405927805338 = 11202020827546 := by decide
theorem cert_e2405927805338 : check e2405927805338 [[]] .width = true := by decide
def e2405927858374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405927858374 : Closed e2405927858374 ∧ code e2405927858374 = 11202020880582 := by decide
theorem cert_e2405927858374 : check e2405927858374 [[]] .width = true := by decide
def e2405927866566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405927866566 : Closed e2405927866566 ∧ code e2405927866566 = 11202020888774 := by decide
theorem cert_e2405927866566 : check e2405927866566 [[]] .width = true := by decide
def e2405927944390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405927944390 : Closed e2405927944390 ∧ code e2405927944390 = 11202020966598 := by decide
theorem cert_e2405927944390 : check e2405927944390 [[]] .width = true := by decide
def e2405927944918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405927944918 : Closed e2405927944918 ∧ code e2405927944918 = 11202020967126 := by decide
theorem cert_e2405927944918 : check e2405927944918 [[]] .width = true := by decide
def e2405927944922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405927944922 : Closed e2405927944922 ∧ code e2405927944922 = 11202020967130 := by decide
theorem cert_e2405927944922 : check e2405927944922 [[]] .width = true := by decide
def e2405927944938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405927944938 : Closed e2405927944938 ∧ code e2405927944938 = 11202020967146 := by decide
theorem cert_e2405927944938 : check e2405927944938 [[]] .width = true := by decide
def e2405927945014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405927945014 : Closed e2405927945014 ∧ code e2405927945014 = 11202020967222 := by decide
theorem cert_e2405927945014 : check e2405927945014 [[]] .width = true := by decide
def e2405927945018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405927945018 : Closed e2405927945018 ∧ code e2405927945018 = 11202020967226 := by decide
theorem cert_e2405927945018 : check e2405927945018 [[]] .width = true := by decide
def e2405927945102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405927945102 : Closed e2405927945102 ∧ code e2405927945102 = 11202020967310 := by decide
theorem cert_e2405927945102 : check e2405927945102 [[]] .width = true := by decide
def e2405927945114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405927945114 : Closed e2405927945114 ∧ code e2405927945114 = 11202020967322 := by decide
theorem cert_e2405927945114 : check e2405927945114 [[]] .width = true := by decide
def e2405927947034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405927947034 : Closed e2405927947034 ∧ code e2405927947034 = 11202020969242 := by decide
theorem cert_e2405927947034 : check e2405927947034 [[]] .width = true := by decide
def e2405927947078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405927947078 : Closed e2405927947078 ∧ code e2405927947078 = 11202020969286 := by decide
theorem cert_e2405927947078 : check e2405927947078 [[]] .width = true := by decide
def e2405927947318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405927947318 : Closed e2405927947318 ∧ code e2405927947318 = 11202020969526 := by decide
theorem cert_e2405927947318 : check e2405927947318 [[]] .width = true := by decide
def e2405927947322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405927947322 : Closed e2405927947322 ∧ code e2405927947322 = 11202020969530 := by decide
theorem cert_e2405927947322 : check e2405927947322 [[]] .width = true := by decide
def e2405927947462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405927947462 : Closed e2405927947462 ∧ code e2405927947462 = 11202020969670 := by decide
theorem cert_e2405927947462 : check e2405927947462 [[]] .width = true := by decide
def e2405931792410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405931792410 : Closed e2405931792410 ∧ code e2405931792410 = 11202024814618 := by decide
theorem cert_e2405931792410 : check e2405931792410 [[]] .width = true := by decide
def e2405931800602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405931800602 : Closed e2405931800602 ∧ code e2405931800602 = 11202024822810 := by decide
theorem cert_e2405931800602 : check e2405931800602 [[]] .width = true := by decide
def e2405931857946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405931857946 : Closed e2405931857946 ∧ code e2405931857946 = 11202024880154 := by decide
theorem cert_e2405931857946 : check e2405931857946 [[]] .width = true := by decide
def e2405931870234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405931870234 : Closed e2405931870234 ∧ code e2405931870234 = 11202024892442 := by decide
theorem cert_e2405931870234 : check e2405931870234 [[]] .width = true := by decide
def e2405931871770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405931871770 : Closed e2405931871770 ∧ code e2405931871770 = 11202024893978 := by decide
theorem cert_e2405931871770 : check e2405931871770 [[]] .width = true := by decide
def e2405931898906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405931898906 : Closed e2405931898906 ∧ code e2405931898906 = 11202024921114 := by decide
theorem cert_e2405931898906 : check e2405931898906 [[]] .width = true := by decide
def e2405931903002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405931903002 : Closed e2405931903002 ∧ code e2405931903002 = 11202024925210 := by decide
theorem cert_e2405931903002 : check e2405931903002 [[]] .width = true := by decide
def e2405931904538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405931904538 : Closed e2405931904538 ∧ code e2405931904538 = 11202024926746 := by decide
theorem cert_e2405931904538 : check e2405931904538 [[]] .width = true := by decide
def e2405931906586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405931906586 : Closed e2405931906586 ∧ code e2405931906586 = 11202024928794 := by decide
theorem cert_e2405931906586 : check e2405931906586 [[]] .width = true := by decide
def e2405932120090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405932120090 : Closed e2405932120090 ∧ code e2405932120090 = 11202025142298 := by decide
theorem cert_e2405932120090 : check e2405932120090 [[]] .width = true := by decide
def e2405932132378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405932132378 : Closed e2405932132378 ∧ code e2405932132378 = 11202025154586 := by decide
theorem cert_e2405932132378 : check e2405932132378 [[]] .width = true := by decide
def e2405932133914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405932133914 : Closed e2405932133914 ∧ code e2405932133914 = 11202025156122 := by decide
theorem cert_e2405932133914 : check e2405932133914 [[]] .width = true := by decide
def e2405932181530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405932181530 : Closed e2405932181530 ∧ code e2405932181530 = 11202025203738 := by decide
theorem cert_e2405932181530 : check e2405932181530 [[]] .width = true := by decide
def e2405932183066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405932183066 : Closed e2405932183066 ∧ code e2405932183066 = 11202025205274 := by decide
theorem cert_e2405932183066 : check e2405932183066 [[]] .width = true := by decide
def e2405932186138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405932186138 : Closed e2405932186138 ∧ code e2405932186138 = 11202025208346 := by decide
theorem cert_e2405932186138 : check e2405932186138 [[]] .width = true := by decide
def e2405932292122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405932292122 : Closed e2405932292122 ∧ code e2405932292122 = 11202025314330 := by decide
theorem cert_e2405932292122 : check e2405932292122 [[]] .width = true := by decide
def e2405932296218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405932296218 : Closed e2405932296218 ∧ code e2405932296218 = 11202025318426 := by decide
theorem cert_e2405932296218 : check e2405932296218 [[]] .width = true := by decide
def e2405932297754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405932297754 : Closed e2405932297754 ∧ code e2405932297754 = 11202025319962 := by decide
theorem cert_e2405932297754 : check e2405932297754 [[]] .width = true := by decide
def e2405932299802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405932299802 : Closed e2405932299802 ∧ code e2405932299802 = 11202025322010 := by decide
theorem cert_e2405932299802 : check e2405932299802 [[]] .width = true := by decide
def e2405932312602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405932312602 : Closed e2405932312602 ∧ code e2405932312602 = 11202025334810 := by decide
theorem cert_e2405932312602 : check e2405932312602 [[]] .width = true := by decide
def e2405932314138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405932314138 : Closed e2405932314138 ∧ code e2405932314138 = 11202025336346 := by decide
theorem cert_e2405932314138 : check e2405932314138 [[]] .width = true := by decide
def e2405932317210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405932317210 : Closed e2405932317210 ∧ code e2405932317210 = 11202025339418 := by decide
theorem cert_e2405932317210 : check e2405932317210 [[]] .width = true := by decide
def e2405932324378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405932324378 : Closed e2405932324378 ∧ code e2405932324378 = 11202025346586 := by decide
theorem cert_e2405932324378 : check e2405932324378 [[]] .width = true := by decide
def e2405932325402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405932325402 : Closed e2405932325402 ∧ code e2405932325402 = 11202025347610 := by decide
theorem cert_e2405932325402 : check e2405932325402 [[]] .width = true := by decide
def e2405932953798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405932953798 : Closed e2405932953798 ∧ code e2405932953798 = 11202025976006 := by decide
theorem cert_e2405932953798 : check e2405932953798 [[]] .width = true := by decide
def e2405932970182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405932970182 : Closed e2405932970182 ∧ code e2405932970182 = 11202025992390 := by decide
theorem cert_e2405932970182 : check e2405932970182 [[]] .width = true := by decide
def e2405933365274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405933365274 : Closed e2405933365274 ∧ code e2405933365274 = 11202026387482 := by decide
theorem cert_e2405933365274 : check e2405933365274 [[]] .width = true := by decide
def e2405933373466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405933373466 : Closed e2405933373466 ∧ code e2405933373466 = 11202026395674 := by decide
theorem cert_e2405933373466 : check e2405933373466 [[]] .width = true := by decide
def e2405933430810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405933430810 : Closed e2405933430810 ∧ code e2405933430810 = 11202026453018 := by decide
theorem cert_e2405933430810 : check e2405933430810 [[]] .width = true := by decide
def e2405933443098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405933443098 : Closed e2405933443098 ∧ code e2405933443098 = 11202026465306 := by decide
theorem cert_e2405933443098 : check e2405933443098 [[]] .width = true := by decide
def e2405933444634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405933444634 : Closed e2405933444634 ∧ code e2405933444634 = 11202026466842 := by decide
theorem cert_e2405933444634 : check e2405933444634 [[]] .width = true := by decide
def e2405933471770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405933471770 : Closed e2405933471770 ∧ code e2405933471770 = 11202026493978 := by decide
theorem cert_e2405933471770 : check e2405933471770 [[]] .width = true := by decide
def e2405933475866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405933475866 : Closed e2405933475866 ∧ code e2405933475866 = 11202026498074 := by decide
theorem cert_e2405933475866 : check e2405933475866 [[]] .width = true := by decide
def e2405933477402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405933477402 : Closed e2405933477402 ∧ code e2405933477402 = 11202026499610 := by decide
theorem cert_e2405933477402 : check e2405933477402 [[]] .width = true := by decide
def e2405933479450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405933479450 : Closed e2405933479450 ∧ code e2405933479450 = 11202026501658 := by decide
theorem cert_e2405933479450 : check e2405933479450 [[]] .width = true := by decide
def e2405933758490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405933758490 : Closed e2405933758490 ∧ code e2405933758490 = 11202026780698 := by decide
theorem cert_e2405933758490 : check e2405933758490 [[]] .width = true := by decide
def e2405933766682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405933766682 : Closed e2405933766682 ∧ code e2405933766682 = 11202026788890 := by decide
theorem cert_e2405933766682 : check e2405933766682 [[]] .width = true := by decide
def e2405934100678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405934100678 : Closed e2405934100678 ∧ code e2405934100678 = 11202027122886 := by decide
theorem cert_e2405934100678 : check e2405934100678 [[]] .width = true := by decide
def e2405934151706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405934151706 : Closed e2405934151706 ∧ code e2405934151706 = 11202027173914 := by decide
theorem cert_e2405934151706 : check e2405934151706 [[]] .width = true := by decide
def e2405934163994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405934163994 : Closed e2405934163994 ∧ code e2405934163994 = 11202027186202 := by decide
theorem cert_e2405934163994 : check e2405934163994 [[]] .width = true := by decide
def e2405934165530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405934165530 : Closed e2405934165530 ∧ code e2405934165530 = 11202027187738 := by decide
theorem cert_e2405934165530 : check e2405934165530 [[]] .width = true := by decide
def e2405934268442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405934268442 : Closed e2405934268442 ∧ code e2405934268442 = 11202027290650 := by decide
theorem cert_e2405934268442 : check e2405934268442 [[]] .width = true := by decide
def e2405934268534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405934268534 : Closed e2405934268534 ∧ code e2405934268534 = 11202027290742 := by decide
theorem cert_e2405934268534 : check e2405934268534 [[]] .width = true := by decide
def e2405934268778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405934268778 : Closed e2405934268778 ∧ code e2405934268778 = 11202027290986 := by decide
theorem cert_e2405934268778 : check e2405934268778 [[]] .width = true := by decide
def e2405934268826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405934268826 : Closed e2405934268826 ∧ code e2405934268826 = 11202027291034 := by decide
theorem cert_e2405934268826 : check e2405934268826 [[]] .width = true := by decide
def e2405934269834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405934269834 : Closed e2405934269834 ∧ code e2405934269834 = 11202027292042 := by decide
theorem cert_e2405934269834 : check e2405934269834 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405917401206
#print axioms Blc.Floor43.cert_e2405917401450
#print axioms Blc.Floor43.cert_e2405917401498
#print axioms Blc.Floor43.cert_e2405917421082
#print axioms Blc.Floor43.cert_e2405917424154
#print axioms Blc.Floor43.cert_e2405917427106
#print axioms Blc.Floor43.cert_e2405917427226
#print axioms Blc.Floor43.cert_e2405917450358
#print axioms Blc.Floor43.cert_e2405917450602
#print axioms Blc.Floor43.cert_e2405917450650
#print axioms Blc.Floor43.cert_e2405917497882
#print axioms Blc.Floor43.cert_e2405917499510
#print axioms Blc.Floor43.cert_e2405917499754
#print axioms Blc.Floor43.cert_e2405917499802
#print axioms Blc.Floor43.cert_e2405917578778
#print axioms Blc.Floor43.cert_e2405917579802
#print axioms Blc.Floor43.cert_e2405917583898
#print axioms Blc.Floor43.cert_e2405917603354
#print axioms Blc.Floor43.cert_e2405917604378
#print axioms Blc.Floor43.cert_e2405917614198
#print axioms Blc.Floor43.cert_e2405917614442
#print axioms Blc.Floor43.cert_e2405917614490
#print axioms Blc.Floor43.cert_e2405917628954
#print axioms Blc.Floor43.cert_e2405917630582
#print axioms Blc.Floor43.cert_e2405917630826
#print axioms Blc.Floor43.cert_e2405917630874
