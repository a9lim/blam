import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2249235738138 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249235738138 : Closed e2249235738138 ∧ code e2249235738138 = 11045328760346 := by decide
private def t_e2249235738138 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249235738138 : ¬ IsSelfInterpreter e2249235738138 :=
  wSource (t := t_e2249235738138) (replay_sound (ps := []) (t := e2249235738138) (by decide)) (by decide)
def e2249235741210 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249235741210 : Closed e2249235741210 ∧ code e2249235741210 = 11045328763418 := by decide
private def t_e2249235741210 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249235741210 : ¬ IsSelfInterpreter e2249235741210 :=
  wSource (t := t_e2249235741210) (replay_sound (ps := []) (t := e2249235741210) (by decide)) (by decide)
def e2249235753498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249235753498 : Closed e2249235753498 ∧ code e2249235753498 = 11045328775706 := by decide
private def t_e2249235753498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249235753498 : ¬ IsSelfInterpreter e2249235753498 :=
  wSource (t := t_e2249235753498) (replay_sound (ps := []) (t := e2249235753498) (by decide)) (by decide)
def e2249235787290 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249235787290 : Closed e2249235787290 ∧ code e2249235787290 = 11045328809498 := by decide
private def t_e2249235787290 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249235787290 : ¬ IsSelfInterpreter e2249235787290 :=
  wSource (t := t_e2249235787290) (replay_sound (ps := []) (t := e2249235787290) (by decide)) (by decide)
def e2249235790362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249235790362 : Closed e2249235790362 ∧ code e2249235790362 = 11045328812570 := by decide
private def t_e2249235790362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249235790362 : ¬ IsSelfInterpreter e2249235790362 :=
  wSource (t := t_e2249235790362) (replay_sound (ps := []) (t := e2249235790362) (by decide)) (by decide)
def e2249235816474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249235816474 : Closed e2249235816474 ∧ code e2249235816474 = 11045328838682 := by decide
theorem cert_e2249235816474 : check e2249235816474 [[]] .width = true := by decide
def e2249235816566 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249235816566 : Closed e2249235816566 ∧ code e2249235816566 = 11045328838774 := by decide
private def t_e2249235816566 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249235816566 : ¬ IsSelfInterpreter e2249235816566 :=
  wSource (t := t_e2249235816566) (replay_sound (ps := []) (t := e2249235816566) (by decide)) (by decide)
def e2249235816810 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249235816810 : Closed e2249235816810 ∧ code e2249235816810 = 11045328839018 := by decide
private def t_e2249235816810 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249235816810 : ¬ IsSelfInterpreter e2249235816810 :=
  wSource (t := t_e2249235816810) (replay_sound (ps := []) (t := e2249235816810) (by decide)) (by decide)
def e2249235816858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249235816858 : Closed e2249235816858 ∧ code e2249235816858 = 11045328839066 := by decide
private def t_e2249235816858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249235816858 : ¬ IsSelfInterpreter e2249235816858 :=
  wSource (t := t_e2249235816858) (replay_sound (ps := []) (t := e2249235816858) (by decide)) (by decide)
def e2249235864090 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249235864090 : Closed e2249235864090 ∧ code e2249235864090 = 11045328886298 := by decide
private def t_e2249235864090 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249235864090 : ¬ IsSelfInterpreter e2249235864090 :=
  wSource (t := t_e2249235864090) (replay_sound (ps := []) (t := e2249235864090) (by decide)) (by decide)
def e2249235865626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249235865626 : Closed e2249235865626 ∧ code e2249235865626 = 11045328887834 := by decide
theorem cert_e2249235865626 : check e2249235865626 [[]] .width = true := by decide
def e2249235865718 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249235865718 : Closed e2249235865718 ∧ code e2249235865718 = 11045328887926 := by decide
private def t_e2249235865718 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249235865718 : ¬ IsSelfInterpreter e2249235865718 :=
  wSource (t := t_e2249235865718) (replay_sound (ps := []) (t := e2249235865718) (by decide)) (by decide)
def e2249235865962 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249235865962 : Closed e2249235865962 ∧ code e2249235865962 = 11045328888170 := by decide
private def t_e2249235865962 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249235865962 : ¬ IsSelfInterpreter e2249235865962 :=
  wSource (t := t_e2249235865962) (replay_sound (ps := []) (t := e2249235865962) (by decide)) (by decide)
def e2249235866010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249235866010 : Closed e2249235866010 ∧ code e2249235866010 = 11045328888218 := by decide
private def t_e2249235866010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249235866010 : ¬ IsSelfInterpreter e2249235866010 :=
  wSource (t := t_e2249235866010) (replay_sound (ps := []) (t := e2249235866010) (by decide)) (by decide)
def e2249236475418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249236475418 : Closed e2249236475418 ∧ code e2249236475418 = 11045329497626 := by decide
private def t_e2249236475418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249236475418 : ¬ IsSelfInterpreter e2249236475418 :=
  wSource (t := t_e2249236475418) (replay_sound (ps := []) (t := e2249236475418) (by decide)) (by decide)
def e2249236477466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249236477466 : Closed e2249236477466 ∧ code e2249236477466 = 11045329499674 := by decide
private def t_e2249236477466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249236477466 : ¬ IsSelfInterpreter e2249236477466 :=
  wSource (t := t_e2249236477466) (replay_sound (ps := []) (t := e2249236477466) (by decide)) (by decide)
def e2249236600346 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249236600346 : Closed e2249236600346 ∧ code e2249236600346 = 11045329622554 := by decide
private def t_e2249236600346 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249236600346 : ¬ IsSelfInterpreter e2249236600346 :=
  wSource (t := t_e2249236600346) (replay_sound (ps := []) (t := e2249236600346) (by decide)) (by decide)
def e2249236601370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249236601370 : Closed e2249236601370 ∧ code e2249236601370 = 11045329623578 := by decide
private def t_e2249236601370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249236601370 : ¬ IsSelfInterpreter e2249236601370 :=
  wSource (t := t_e2249236601370) (replay_sound (ps := []) (t := e2249236601370) (by decide)) (by decide)
def e2249236605466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249236605466 : Closed e2249236605466 ∧ code e2249236605466 = 11045329627674 := by decide
private def t_e2249236605466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249236605466 : ¬ IsSelfInterpreter e2249236605466 :=
  wSource (t := t_e2249236605466) (replay_sound (ps := []) (t := e2249236605466) (by decide)) (by decide)
def e2249236624922 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249236624922 : Closed e2249236624922 ∧ code e2249236624922 = 11045329647130 := by decide
private def t_e2249236624922 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249236624922 : ¬ IsSelfInterpreter e2249236624922 :=
  wSource (t := t_e2249236624922) (replay_sound (ps := []) (t := e2249236624922) (by decide)) (by decide)
def e2249236625946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249236625946 : Closed e2249236625946 ∧ code e2249236625946 = 11045329648154 := by decide
private def t_e2249236625946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249236625946 : ¬ IsSelfInterpreter e2249236625946 :=
  wSource (t := t_e2249236625946) (replay_sound (ps := []) (t := e2249236625946) (by decide)) (by decide)
def e2249236635674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249236635674 : Closed e2249236635674 ∧ code e2249236635674 = 11045329657882 := by decide
theorem cert_e2249236635674 : check e2249236635674 [[]] .width = true := by decide
def e2249236635766 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249236635766 : Closed e2249236635766 ∧ code e2249236635766 = 11045329657974 := by decide
private def t_e2249236635766 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249236635766 : ¬ IsSelfInterpreter e2249236635766 :=
  wSource (t := t_e2249236635766) (replay_sound (ps := []) (t := e2249236635766) (by decide)) (by decide)
def e2249236636010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249236636010 : Closed e2249236636010 ∧ code e2249236636010 = 11045329658218 := by decide
private def t_e2249236636010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249236636010 : ¬ IsSelfInterpreter e2249236636010 :=
  wSource (t := t_e2249236636010) (replay_sound (ps := []) (t := e2249236636010) (by decide)) (by decide)
def e2249236636058 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249236636058 : Closed e2249236636058 ∧ code e2249236636058 = 11045329658266 := by decide
private def t_e2249236636058 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249236636058 : ¬ IsSelfInterpreter e2249236636058 :=
  wSource (t := t_e2249236636058) (replay_sound (ps := []) (t := e2249236636058) (by decide)) (by decide)
def e2249236650522 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249236650522 : Closed e2249236650522 ∧ code e2249236650522 = 11045329672730 := by decide
private def t_e2249236650522 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249236650522 : ¬ IsSelfInterpreter e2249236650522 :=
  wSource (t := t_e2249236650522) (replay_sound (ps := []) (t := e2249236650522) (by decide)) (by decide)
def e2249236652058 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2249236652058 : Closed e2249236652058 ∧ code e2249236652058 = 11045329674266 := by decide
theorem cert_e2249236652058 : check e2249236652058 [[]] .width = true := by decide
def e2249236652150 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2249236652150 : Closed e2249236652150 ∧ code e2249236652150 = 11045329674358 := by decide
private def t_e2249236652150 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2249236652150 : ¬ IsSelfInterpreter e2249236652150 :=
  wSource (t := t_e2249236652150) (replay_sound (ps := []) (t := e2249236652150) (by decide)) (by decide)
def e2249236652394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2249236652394 : Closed e2249236652394 ∧ code e2249236652394 = 11045329674602 := by decide
private def t_e2249236652394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2249236652394 : ¬ IsSelfInterpreter e2249236652394 :=
  wSource (t := t_e2249236652394) (replay_sound (ps := []) (t := e2249236652394) (by decide)) (by decide)
def e2249236652442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2249236652442 : Closed e2249236652442 ∧ code e2249236652442 = 11045329674650 := by decide
private def t_e2249236652442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2249236652442 : ¬ IsSelfInterpreter e2249236652442 :=
  wSource (t := t_e2249236652442) (replay_sound (ps := []) (t := e2249236652442) (by decide)) (by decide)
def e2249237507438 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2249237507438 : Closed e2249237507438 ∧ code e2249237507438 = 11045330529646 := by decide
theorem cert_e2249237507438 : check e2249237507438 [[],[.under,.left]] .chain = true := by decide
def e2249237507446 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2249237507446 : Closed e2249237507446 ∧ code e2249237507446 = 11045330529654 := by decide
theorem cert_e2249237507446 : check e2249237507446 [[],[.under,.left]] .chain = true := by decide
def e2249237507502 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2249237507502 : Closed e2249237507502 ∧ code e2249237507502 = 11045330529710 := by decide
theorem cert_e2249237507502 : check e2249237507502 [[],[.under,.left]] .chain = true := by decide
def e2249237507514 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2249237507514 : Closed e2249237507514 ∧ code e2249237507514 = 11045330529722 := by decide
theorem cert_e2249237507514 : check e2249237507514 [[],[.under,.left]] .chain = true := by decide
def e2249237507542 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2249237507542 : Closed e2249237507542 ∧ code e2249237507542 = 11045330529750 := by decide
theorem cert_e2249237507542 : check e2249237507542 [[],[.under,.left]] .chain = true := by decide
def e2249237507546 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2249237507546 : Closed e2249237507546 ∧ code e2249237507546 = 11045330529754 := by decide
theorem cert_e2249237507546 : check e2249237507546 [[],[.under,.left]] .chain = true := by decide
def e2249237507758 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2249237507758 : Closed e2249237507758 ∧ code e2249237507758 = 11045330529966 := by decide
theorem cert_e2249237507758 : check e2249237507758 [[],[.under,.left]] .chain = true := by decide
def e2249237507770 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2249237507770 : Closed e2249237507770 ∧ code e2249237507770 = 11045330529978 := by decide
theorem cert_e2249237507770 : check e2249237507770 [[],[.under,.left]] .chain = true := by decide
def e2249237507818 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2249237507818 : Closed e2249237507818 ∧ code e2249237507818 = 11045330530026 := by decide
theorem cert_e2249237507818 : check e2249237507818 [[],[.under,.left]] .chain = true := by decide
def e2249237507926 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2249237507926 : Closed e2249237507926 ∧ code e2249237507926 = 11045330530134 := by decide
theorem cert_e2249237507926 : check e2249237507926 [[],[.under,.left]] .chain = true := by decide
def e2249237507930 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2249237507930 : Closed e2249237507930 ∧ code e2249237507930 = 11045330530138 := by decide
theorem cert_e2249237507930 : check e2249237507930 [[],[.under,.left]] .chain = true := by decide
def e2249237507946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2249237507946 : Closed e2249237507946 ∧ code e2249237507946 = 11045330530154 := by decide
theorem cert_e2249237507946 : check e2249237507946 [[],[.under,.left]] .chain = true := by decide
def e2249237508974 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2249237508974 : Closed e2249237508974 ∧ code e2249237508974 = 11045330531182 := by decide
theorem cert_e2249237508974 : check e2249237508974 [[],[.under,.left]] .chain = true := by decide
def e2249237508982 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2249237508982 : Closed e2249237508982 ∧ code e2249237508982 = 11045330531190 := by decide
theorem cert_e2249237508982 : check e2249237508982 [[],[.under,.left]] .chain = true := by decide
def e2249237509038 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2249237509038 : Closed e2249237509038 ∧ code e2249237509038 = 11045330531246 := by decide
theorem cert_e2249237509038 : check e2249237509038 [[],[.under,.left]] .chain = true := by decide
def e2249237509050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2249237509050 : Closed e2249237509050 ∧ code e2249237509050 = 11045330531258 := by decide
theorem cert_e2249237509050 : check e2249237509050 [[],[.under,.left]] .chain = true := by decide
def e2249237509078 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2249237509078 : Closed e2249237509078 ∧ code e2249237509078 = 11045330531286 := by decide
theorem cert_e2249237509078 : check e2249237509078 [[],[.under,.left]] .chain = true := by decide
def e2249237509082 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2249237509082 : Closed e2249237509082 ∧ code e2249237509082 = 11045330531290 := by decide
theorem cert_e2249237509082 : check e2249237509082 [[],[.under,.left]] .chain = true := by decide
def e2249237509358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2249237509358 : Closed e2249237509358 ∧ code e2249237509358 = 11045330531566 := by decide
theorem cert_e2249237509358 : check e2249237509358 [[],[.under,.left]] .chain = true := by decide
def e2249237509366 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2249237509366 : Closed e2249237509366 ∧ code e2249237509366 = 11045330531574 := by decide
theorem cert_e2249237509366 : check e2249237509366 [[],[.under,.left]] .chain = true := by decide
def e2249237509742 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2249237509742 : Closed e2249237509742 ∧ code e2249237509742 = 11045330531950 := by decide
theorem cert_e2249237509742 : check e2249237509742 [[],[.under,.left]] .chain = true := by decide
def e2249237509754 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2249237509754 : Closed e2249237509754 ∧ code e2249237509754 = 11045330531962 := by decide
theorem cert_e2249237509754 : check e2249237509754 [[],[.under,.left]] .chain = true := by decide
def e2249237509942 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2249237509942 : Closed e2249237509942 ∧ code e2249237509942 = 11045330532150 := by decide
theorem cert_e2249237509942 : check e2249237509942 [[],[.under,.left]] .chain = true := by decide
def e2249237509946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2249237509946 : Closed e2249237509946 ∧ code e2249237509946 = 11045330532154 := by decide
theorem cert_e2249237509946 : check e2249237509946 [[],[.under,.left]] .chain = true := by decide
def e2249237510574 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2249237510574 : Closed e2249237510574 ∧ code e2249237510574 = 11045330532782 := by decide
theorem cert_e2249237510574 : check e2249237510574 [[],[.under,.left]] .chain = true := by decide
def e2249237510586 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2249237510586 : Closed e2249237510586 ∧ code e2249237510586 = 11045330532794 := by decide
theorem cert_e2249237510586 : check e2249237510586 [[],[.under,.left]] .chain = true := by decide
def e2249237510634 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2249237510634 : Closed e2249237510634 ∧ code e2249237510634 = 11045330532842 := by decide
theorem cert_e2249237510634 : check e2249237510634 [[],[.under,.left]] .chain = true := by decide
def e2249237510766 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2249237510766 : Closed e2249237510766 ∧ code e2249237510766 = 11045330532974 := by decide
theorem cert_e2249237510766 : check e2249237510766 [[],[.under,.left]] .chain = true := by decide
def e2249237510778 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2249237510778 : Closed e2249237510778 ∧ code e2249237510778 = 11045330532986 := by decide
theorem cert_e2249237510778 : check e2249237510778 [[],[.under,.left]] .chain = true := by decide
def e2249237511066 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2249237511066 : Closed e2249237511066 ∧ code e2249237511066 = 11045330533274 := by decide
theorem cert_e2249237511066 : check e2249237511066 [[],[.under,.left]] .chain = true := by decide
def e2249237511382 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2249237511382 : Closed e2249237511382 ∧ code e2249237511382 = 11045330533590 := by decide
theorem cert_e2249237511382 : check e2249237511382 [[],[.under,.left]] .chain = true := by decide
def e2249237511386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2249237511386 : Closed e2249237511386 ∧ code e2249237511386 = 11045330533594 := by decide
theorem cert_e2249237511386 : check e2249237511386 [[],[.under,.left]] .chain = true := by decide
def e2249237511402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2249237511402 : Closed e2249237511402 ∧ code e2249237511402 = 11045330533610 := by decide
theorem cert_e2249237511402 : check e2249237511402 [[],[.under,.left]] .chain = true := by decide
def e2249237511478 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2249237511478 : Closed e2249237511478 ∧ code e2249237511478 = 11045330533686 := by decide
theorem cert_e2249237511478 : check e2249237511478 [[],[.under,.left]] .chain = true := by decide
def e2249237511482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2249237511482 : Closed e2249237511482 ∧ code e2249237511482 = 11045330533690 := by decide
theorem cert_e2249237511482 : check e2249237511482 [[],[.under,.left]] .chain = true := by decide
def e2249237511578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2249237511578 : Closed e2249237511578 ∧ code e2249237511578 = 11045330533786 := by decide
theorem cert_e2249237511578 : check e2249237511578 [[],[.under,.left]] .chain = true := by decide
def e2249237515118 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2249237515118 : Closed e2249237515118 ∧ code e2249237515118 = 11045330537326 := by decide
theorem cert_e2249237515118 : check e2249237515118 [[],[.under,.left]] .chain = true := by decide
def e2249237515126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2249237515126 : Closed e2249237515126 ∧ code e2249237515126 = 11045330537334 := by decide
theorem cert_e2249237515126 : check e2249237515126 [[],[.under,.left]] .chain = true := by decide
def e2249237515182 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2249237515182 : Closed e2249237515182 ∧ code e2249237515182 = 11045330537390 := by decide
theorem cert_e2249237515182 : check e2249237515182 [[],[.under,.left]] .chain = true := by decide
def e2249237515194 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2249237515194 : Closed e2249237515194 ∧ code e2249237515194 = 11045330537402 := by decide
theorem cert_e2249237515194 : check e2249237515194 [[],[.under,.left]] .chain = true := by decide
def e2249237515222 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2249237515222 : Closed e2249237515222 ∧ code e2249237515222 = 11045330537430 := by decide
theorem cert_e2249237515222 : check e2249237515222 [[],[.under,.left]] .chain = true := by decide
def e2249237515226 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2249237515226 : Closed e2249237515226 ∧ code e2249237515226 = 11045330537434 := by decide
theorem cert_e2249237515226 : check e2249237515226 [[],[.under,.left]] .chain = true := by decide
def e2249237515502 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2249237515502 : Closed e2249237515502 ∧ code e2249237515502 = 11045330537710 := by decide
theorem cert_e2249237515502 : check e2249237515502 [[],[.under,.left]] .chain = true := by decide
def e2249237515510 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2249237515510 : Closed e2249237515510 ∧ code e2249237515510 = 11045330537718 := by decide
theorem cert_e2249237515510 : check e2249237515510 [[],[.under,.left]] .chain = true := by decide
def e2249237515886 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2249237515886 : Closed e2249237515886 ∧ code e2249237515886 = 11045330538094 := by decide
theorem cert_e2249237515886 : check e2249237515886 [[],[.under,.left]] .chain = true := by decide
def e2249237515898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2249237515898 : Closed e2249237515898 ∧ code e2249237515898 = 11045330538106 := by decide
theorem cert_e2249237515898 : check e2249237515898 [[],[.under,.left]] .chain = true := by decide
def e2249237516086 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2249237516086 : Closed e2249237516086 ∧ code e2249237516086 = 11045330538294 := by decide
theorem cert_e2249237516086 : check e2249237516086 [[],[.under,.left]] .chain = true := by decide
def e2249237516090 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2249237516090 : Closed e2249237516090 ∧ code e2249237516090 = 11045330538298 := by decide
theorem cert_e2249237516090 : check e2249237516090 [[],[.under,.left]] .chain = true := by decide
def e2249237521838 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2249237521838 : Closed e2249237521838 ∧ code e2249237521838 = 11045330544046 := by decide
theorem cert_e2249237521838 : check e2249237521838 [[],[.under,.left]] .chain = true := by decide
def e2249237521850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2249237521850 : Closed e2249237521850 ∧ code e2249237521850 = 11045330544058 := by decide
theorem cert_e2249237521850 : check e2249237521850 [[],[.under,.left]] .chain = true := by decide
def e2249237521898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2249237521898 : Closed e2249237521898 ∧ code e2249237521898 = 11045330544106 := by decide
theorem cert_e2249237521898 : check e2249237521898 [[],[.under,.left]] .chain = true := by decide
def e2249237522030 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2249237522030 : Closed e2249237522030 ∧ code e2249237522030 = 11045330544238 := by decide
theorem cert_e2249237522030 : check e2249237522030 [[],[.under,.left]] .chain = true := by decide
def e2249237522042 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2249237522042 : Closed e2249237522042 ∧ code e2249237522042 = 11045330544250 := by decide
theorem cert_e2249237522042 : check e2249237522042 [[],[.under,.left]] .chain = true := by decide
def e2249237522330 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2249237522330 : Closed e2249237522330 ∧ code e2249237522330 = 11045330544538 := by decide
theorem cert_e2249237522330 : check e2249237522330 [[],[.under,.left]] .chain = true := by decide
def e2249237525206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2249237525206 : Closed e2249237525206 ∧ code e2249237525206 = 11045330547414 := by decide
theorem cert_e2249237525206 : check e2249237525206 [[],[.under,.left]] .chain = true := by decide
def e2249237525210 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2249237525210 : Closed e2249237525210 ∧ code e2249237525210 = 11045330547418 := by decide
theorem cert_e2249237525210 : check e2249237525210 [[],[.under,.left]] .chain = true := by decide
def e2249237525226 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2249237525226 : Closed e2249237525226 ∧ code e2249237525226 = 11045330547434 := by decide
theorem cert_e2249237525226 : check e2249237525226 [[],[.under,.left]] .chain = true := by decide
def e2249237525302 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2249237525302 : Closed e2249237525302 ∧ code e2249237525302 = 11045330547510 := by decide
theorem cert_e2249237525302 : check e2249237525302 [[],[.under,.left]] .chain = true := by decide
def e2249237525306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2249237525306 : Closed e2249237525306 ∧ code e2249237525306 = 11045330547514 := by decide
theorem cert_e2249237525306 : check e2249237525306 [[],[.under,.left]] .chain = true := by decide
def e2249237525402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2249237525402 : Closed e2249237525402 ∧ code e2249237525402 = 11045330547610 := by decide
theorem cert_e2249237525402 : check e2249237525402 [[],[.under,.left]] .chain = true := by decide
def e2249237662574 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2249237662574 : Closed e2249237662574 ∧ code e2249237662574 = 11045330684782 := by decide
theorem cert_e2249237662574 : check e2249237662574 [[],[.under,.left]] .chain = true := by decide
def e2249237662582 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2249237662582 : Closed e2249237662582 ∧ code e2249237662582 = 11045330684790 := by decide
theorem cert_e2249237662582 : check e2249237662582 [[],[.under,.left]] .chain = true := by decide
def e2249237662638 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2249237662638 : Closed e2249237662638 ∧ code e2249237662638 = 11045330684846 := by decide
theorem cert_e2249237662638 : check e2249237662638 [[],[.under,.left]] .chain = true := by decide
def e2249237662650 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2249237662650 : Closed e2249237662650 ∧ code e2249237662650 = 11045330684858 := by decide
theorem cert_e2249237662650 : check e2249237662650 [[],[.under,.left]] .chain = true := by decide
def e2249237662678 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2249237662678 : Closed e2249237662678 ∧ code e2249237662678 = 11045330684886 := by decide
theorem cert_e2249237662678 : check e2249237662678 [[],[.under,.left]] .chain = true := by decide
def e2249237662682 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2249237662682 : Closed e2249237662682 ∧ code e2249237662682 = 11045330684890 := by decide
theorem cert_e2249237662682 : check e2249237662682 [[],[.under,.left]] .chain = true := by decide
def e2249237662958 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2249237662958 : Closed e2249237662958 ∧ code e2249237662958 = 11045330685166 := by decide
theorem cert_e2249237662958 : check e2249237662958 [[],[.under,.left]] .chain = true := by decide
def e2249237662966 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2249237662966 : Closed e2249237662966 ∧ code e2249237662966 = 11045330685174 := by decide
theorem cert_e2249237662966 : check e2249237662966 [[],[.under,.left]] .chain = true := by decide
def e2249237663342 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2249237663342 : Closed e2249237663342 ∧ code e2249237663342 = 11045330685550 := by decide
theorem cert_e2249237663342 : check e2249237663342 [[],[.under,.left]] .chain = true := by decide
def e2249237663354 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2249237663354 : Closed e2249237663354 ∧ code e2249237663354 = 11045330685562 := by decide
theorem cert_e2249237663354 : check e2249237663354 [[],[.under,.left]] .chain = true := by decide
def e2249237663542 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2249237663542 : Closed e2249237663542 ∧ code e2249237663542 = 11045330685750 := by decide
theorem cert_e2249237663542 : check e2249237663542 [[],[.under,.left]] .chain = true := by decide
def e2249237663546 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2249237663546 : Closed e2249237663546 ∧ code e2249237663546 = 11045330685754 := by decide
theorem cert_e2249237663546 : check e2249237663546 [[],[.under,.left]] .chain = true := by decide
def e2249238252398 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2249238252398 : Closed e2249238252398 ∧ code e2249238252398 = 11045331274606 := by decide
theorem cert_e2249238252398 : check e2249238252398 [[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249238252406 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2249238252406 : Closed e2249238252406 ∧ code e2249238252406 = 11045331274614 := by decide
theorem cert_e2249238252406 : check e2249238252406 [[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e2249238252462 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2249238252462 : Closed e2249238252462 ∧ code e2249238252462 = 11045331274670 := by decide
theorem cert_e2249238252462 : check e2249238252462 [[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2249238252474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2249238252474 : Closed e2249238252474 ∧ code e2249238252474 = 11045331274682 := by decide
private def t_e2249238252474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2249238252474 : ¬ IsSelfInterpreter e2249238252474 :=
  wSource (t := t_e2249238252474) (replay_sound (ps := []) (t := e2249238252474) (by decide)) (by decide)
def e2249238252502 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2249238252502 : Closed e2249238252502 ∧ code e2249238252502 = 11045331274710 := by decide
theorem cert_e2249238252502 : check e2249238252502 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2249238252506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2249238252506 : Closed e2249238252506 ∧ code e2249238252506 = 11045331274714 := by decide
private def t_e2249238252506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2249238252506 : ¬ IsSelfInterpreter e2249238252506 :=
  wSource (t := t_e2249238252506) (replay_sound (ps := []) (t := e2249238252506) (by decide)) (by decide)
def e2249238252782 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2249238252782 : Closed e2249238252782 ∧ code e2249238252782 = 11045331274990 := by decide
theorem cert_e2249238252782 : check e2249238252782 [[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2249238252790 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2249238252790 : Closed e2249238252790 ∧ code e2249238252790 = 11045331274998 := by decide
theorem cert_e2249238252790 : check e2249238252790 [[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[]] .identityHead = true := by decide
def e2249238253166 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2249238253166 : Closed e2249238253166 ∧ code e2249238253166 = 11045331275374 := by decide
theorem cert_e2249238253166 : check e2249238253166 [[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2249238253178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2249238253178 : Closed e2249238253178 ∧ code e2249238253178 = 11045331275386 := by decide
theorem cert_e2249238253178 : check e2249238253178 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2249238253366 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2249238253366 : Closed e2249238253366 ∧ code e2249238253366 = 11045331275574 := by decide
theorem cert_e2249238253366 : check e2249238253366 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249238253370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2249238253370 : Closed e2249238253370 ∧ code e2249238253370 = 11045331275578 := by decide
theorem cert_e2249238253370 : check e2249238253370 [[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2249271766554 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271766554 : Closed e2249271766554 ∧ code e2249271766554 = 11045364788762 := by decide
private def t_e2249271766554 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271766554 : ¬ IsSelfInterpreter e2249271766554 :=
  wSource (t := t_e2249271766554) (replay_sound (ps := []) (t := e2249271766554) (by decide)) (by decide)
def e2249271768602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271768602 : Closed e2249271768602 ∧ code e2249271768602 = 11045364790810 := by decide
private def t_e2249271768602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271768602 : ¬ IsSelfInterpreter e2249271768602 :=
  wSource (t := t_e2249271768602) (replay_sound (ps := []) (t := e2249271768602) (by decide)) (by decide)
def e2249271782938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271782938 : Closed e2249271782938 ∧ code e2249271782938 = 11045364805146 := by decide
private def t_e2249271782938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271782938 : ¬ IsSelfInterpreter e2249271782938 :=
  wSource (t := t_e2249271782938) (replay_sound (ps := []) (t := e2249271782938) (by decide)) (by decide)
def e2249271786010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271786010 : Closed e2249271786010 ∧ code e2249271786010 = 11045364808218 := by decide
private def t_e2249271786010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271786010 : ¬ IsSelfInterpreter e2249271786010 :=
  wSource (t := t_e2249271786010) (replay_sound (ps := []) (t := e2249271786010) (by decide)) (by decide)
def e2249271793178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271793178 : Closed e2249271793178 ∧ code e2249271793178 = 11045364815386 := by decide
private def t_e2249271793178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271793178 : ¬ IsSelfInterpreter e2249271793178 :=
  wSource (t := t_e2249271793178) (replay_sound (ps := []) (t := e2249271793178) (by decide)) (by decide)
def e2249271794202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271794202 : Closed e2249271794202 ∧ code e2249271794202 = 11045364816410 := by decide
private def t_e2249271794202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271794202 : ¬ IsSelfInterpreter e2249271794202 :=
  wSource (t := t_e2249271794202) (replay_sound (ps := []) (t := e2249271794202) (by decide)) (by decide)
def e2249271864858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271864858 : Closed e2249271864858 ∧ code e2249271864858 = 11045364887066 := by decide
private def t_e2249271864858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271864858 : ¬ IsSelfInterpreter e2249271864858 :=
  wSource (t := t_e2249271864858) (replay_sound (ps := []) (t := e2249271864858) (by decide)) (by decide)
def e2249271866906 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271866906 : Closed e2249271866906 ∧ code e2249271866906 = 11045364889114 := by decide
private def t_e2249271866906 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271866906 : ¬ IsSelfInterpreter e2249271866906 :=
  wSource (t := t_e2249271866906) (replay_sound (ps := []) (t := e2249271866906) (by decide)) (by decide)
def e2249271963162 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271963162 : Closed e2249271963162 ∧ code e2249271963162 = 11045364985370 := by decide
private def t_e2249271963162 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271963162 : ¬ IsSelfInterpreter e2249271963162 :=
  wSource (t := t_e2249271963162) (replay_sound (ps := []) (t := e2249271963162) (by decide)) (by decide)
def e2249271966234 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249271966234 : Closed e2249271966234 ∧ code e2249271966234 = 11045364988442 := by decide
private def t_e2249271966234 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249271966234 : ¬ IsSelfInterpreter e2249271966234 :=
  wSource (t := t_e2249271966234) (replay_sound (ps := []) (t := e2249271966234) (by decide)) (by decide)
def e2249272014362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249272014362 : Closed e2249272014362 ∧ code e2249272014362 = 11045365036570 := by decide
private def t_e2249272014362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249272014362 : ¬ IsSelfInterpreter e2249272014362 :=
  wSource (t := t_e2249272014362) (replay_sound (ps := []) (t := e2249272014362) (by decide)) (by decide)
def e2249272015386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249272015386 : Closed e2249272015386 ∧ code e2249272015386 = 11045365037594 := by decide
private def t_e2249272015386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2249272015386 : ¬ IsSelfInterpreter e2249272015386 :=
  wSource (t := t_e2249272015386) (replay_sound (ps := []) (t := e2249272015386) (by decide)) (by decide)
def e2249287839086 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2249287839086 : Closed e2249287839086 ∧ code e2249287839086 = 11045380861294 := by decide
theorem cert_e2249287839086 : check e2249287839086 [[],[.under,.left]] .smaller = true := by decide
def e2249287839094 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2249287839094 : Closed e2249287839094 ∧ code e2249287839094 = 11045380861302 := by decide
theorem cert_e2249287839094 : check e2249287839094 [[],[.under,.left]] .smaller = true := by decide
def e2249287839150 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2249287839150 : Closed e2249287839150 ∧ code e2249287839150 = 11045380861358 := by decide
theorem cert_e2249287839150 : check e2249287839150 [[],[.under,.left]] .smaller = true := by decide
def e2249287839162 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2249287839162 : Closed e2249287839162 ∧ code e2249287839162 = 11045380861370 := by decide
theorem cert_e2249287839162 : check e2249287839162 [[],[.under,.left]] .smaller = true := by decide
def e2249287839190 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2249287839190 : Closed e2249287839190 ∧ code e2249287839190 = 11045380861398 := by decide
theorem cert_e2249287839190 : check e2249287839190 [[],[.under,.left]] .smaller = true := by decide
def e2249287839194 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2249287839194 : Closed e2249287839194 ∧ code e2249287839194 = 11045380861402 := by decide
theorem cert_e2249287839194 : check e2249287839194 [[],[.under,.left]] .smaller = true := by decide
def e2249287839406 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2249287839406 : Closed e2249287839406 ∧ code e2249287839406 = 11045380861614 := by decide
theorem cert_e2249287839406 : check e2249287839406 [[],[.under,.left]] .smaller = true := by decide
def e2249287839418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2249287839418 : Closed e2249287839418 ∧ code e2249287839418 = 11045380861626 := by decide
theorem cert_e2249287839418 : check e2249287839418 [[],[.under,.left]] .smaller = true := by decide
def e2249287839466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2249287839466 : Closed e2249287839466 ∧ code e2249287839466 = 11045380861674 := by decide
theorem cert_e2249287839466 : check e2249287839466 [[],[.under,.left]] .smaller = true := by decide
def e2249287839574 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2249287839574 : Closed e2249287839574 ∧ code e2249287839574 = 11045380861782 := by decide
theorem cert_e2249287839574 : check e2249287839574 [[],[.under,.left]] .smaller = true := by decide
def e2249287839578 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2249287839578 : Closed e2249287839578 ∧ code e2249287839578 = 11045380861786 := by decide
theorem cert_e2249287839578 : check e2249287839578 [[],[.under,.left]] .smaller = true := by decide
def e2249287839594 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2249287839594 : Closed e2249287839594 ∧ code e2249287839594 = 11045380861802 := by decide
theorem cert_e2249287839594 : check e2249287839594 [[],[.under,.left]] .smaller = true := by decide
def e2249287840622 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2249287840622 : Closed e2249287840622 ∧ code e2249287840622 = 11045380862830 := by decide
theorem cert_e2249287840622 : check e2249287840622 [[],[.under,.left]] .smaller = true := by decide
def e2249287840630 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2249287840630 : Closed e2249287840630 ∧ code e2249287840630 = 11045380862838 := by decide
theorem cert_e2249287840630 : check e2249287840630 [[],[.under,.left]] .smaller = true := by decide
def e2249287840686 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2249287840686 : Closed e2249287840686 ∧ code e2249287840686 = 11045380862894 := by decide
theorem cert_e2249287840686 : check e2249287840686 [[],[.under,.left]] .smaller = true := by decide
def e2249287840698 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2249287840698 : Closed e2249287840698 ∧ code e2249287840698 = 11045380862906 := by decide
theorem cert_e2249287840698 : check e2249287840698 [[],[.under,.left]] .smaller = true := by decide
def e2249287840726 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2249287840726 : Closed e2249287840726 ∧ code e2249287840726 = 11045380862934 := by decide
theorem cert_e2249287840726 : check e2249287840726 [[],[.under,.left]] .smaller = true := by decide
def e2249287840730 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2249287840730 : Closed e2249287840730 ∧ code e2249287840730 = 11045380862938 := by decide
theorem cert_e2249287840730 : check e2249287840730 [[],[.under,.left]] .smaller = true := by decide
def e2249287841006 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2249287841006 : Closed e2249287841006 ∧ code e2249287841006 = 11045380863214 := by decide
theorem cert_e2249287841006 : check e2249287841006 [[],[.under,.left]] .smaller = true := by decide
def e2249287841014 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2249287841014 : Closed e2249287841014 ∧ code e2249287841014 = 11045380863222 := by decide
theorem cert_e2249287841014 : check e2249287841014 [[],[.under,.left]] .smaller = true := by decide
def e2249287841390 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2249287841390 : Closed e2249287841390 ∧ code e2249287841390 = 11045380863598 := by decide
theorem cert_e2249287841390 : check e2249287841390 [[],[.under,.left]] .smaller = true := by decide
def e2249287841402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2249287841402 : Closed e2249287841402 ∧ code e2249287841402 = 11045380863610 := by decide
theorem cert_e2249287841402 : check e2249287841402 [[],[.under,.left]] .smaller = true := by decide
def e2249287841590 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2249287841590 : Closed e2249287841590 ∧ code e2249287841590 = 11045380863798 := by decide
theorem cert_e2249287841590 : check e2249287841590 [[],[.under,.left]] .smaller = true := by decide
def e2249287841594 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2249287841594 : Closed e2249287841594 ∧ code e2249287841594 = 11045380863802 := by decide
theorem cert_e2249287841594 : check e2249287841594 [[],[.under,.left]] .smaller = true := by decide
def e2249287842222 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2249287842222 : Closed e2249287842222 ∧ code e2249287842222 = 11045380864430 := by decide
theorem cert_e2249287842222 : check e2249287842222 [[],[.under,.left]] .smaller = true := by decide
def e2249287842234 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2249287842234 : Closed e2249287842234 ∧ code e2249287842234 = 11045380864442 := by decide
theorem cert_e2249287842234 : check e2249287842234 [[],[.under,.left]] .smaller = true := by decide
def e2249287842282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2249287842282 : Closed e2249287842282 ∧ code e2249287842282 = 11045380864490 := by decide
theorem cert_e2249287842282 : check e2249287842282 [[],[.under,.left]] .smaller = true := by decide
def e2249287842414 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2249287842414 : Closed e2249287842414 ∧ code e2249287842414 = 11045380864622 := by decide
theorem cert_e2249287842414 : check e2249287842414 [[],[.under,.left]] .smaller = true := by decide
def e2249287842426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2249287842426 : Closed e2249287842426 ∧ code e2249287842426 = 11045380864634 := by decide
theorem cert_e2249287842426 : check e2249287842426 [[],[.under,.left]] .smaller = true := by decide
def e2249287842714 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2249287842714 : Closed e2249287842714 ∧ code e2249287842714 = 11045380864922 := by decide
theorem cert_e2249287842714 : check e2249287842714 [[],[.under,.left]] .smaller = true := by decide
def e2249287843030 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2249287843030 : Closed e2249287843030 ∧ code e2249287843030 = 11045380865238 := by decide
theorem cert_e2249287843030 : check e2249287843030 [[],[.under,.left]] .smaller = true := by decide
def e2249287843034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2249287843034 : Closed e2249287843034 ∧ code e2249287843034 = 11045380865242 := by decide
theorem cert_e2249287843034 : check e2249287843034 [[],[.under,.left]] .smaller = true := by decide
def e2249287843050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2249287843050 : Closed e2249287843050 ∧ code e2249287843050 = 11045380865258 := by decide
theorem cert_e2249287843050 : check e2249287843050 [[],[.under,.left]] .smaller = true := by decide
def e2249287843126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2249287843126 : Closed e2249287843126 ∧ code e2249287843126 = 11045380865334 := by decide
theorem cert_e2249287843126 : check e2249287843126 [[],[.under,.left]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2249235738138
#print axioms Blc.Floor43.cert_e2249235741210
#print axioms Blc.Floor43.cert_e2249235753498
#print axioms Blc.Floor43.cert_e2249235787290
#print axioms Blc.Floor43.cert_e2249235790362
#print axioms Blc.Floor43.cert_e2249235816566
#print axioms Blc.Floor43.cert_e2249235816810
#print axioms Blc.Floor43.cert_e2249235816858
#print axioms Blc.Floor43.cert_e2249235864090
#print axioms Blc.Floor43.cert_e2249235865718
#print axioms Blc.Floor43.cert_e2249235865962
#print axioms Blc.Floor43.cert_e2249235866010
#print axioms Blc.Floor43.cert_e2249236475418
#print axioms Blc.Floor43.cert_e2249236477466
#print axioms Blc.Floor43.cert_e2249236600346
#print axioms Blc.Floor43.cert_e2249236601370
#print axioms Blc.Floor43.cert_e2249236605466
#print axioms Blc.Floor43.cert_e2249236624922
#print axioms Blc.Floor43.cert_e2249236625946
#print axioms Blc.Floor43.cert_e2249236635766
#print axioms Blc.Floor43.cert_e2249236636010
#print axioms Blc.Floor43.cert_e2249236636058
#print axioms Blc.Floor43.cert_e2249236650522
#print axioms Blc.Floor43.cert_e2249236652150
#print axioms Blc.Floor43.cert_e2249236652394
#print axioms Blc.Floor43.cert_e2249236652442
#print axioms Blc.Floor43.cert_e2249238252474
#print axioms Blc.Floor43.cert_e2249238252506
#print axioms Blc.Floor43.cert_e2249271766554
#print axioms Blc.Floor43.cert_e2249271768602
#print axioms Blc.Floor43.cert_e2249271782938
#print axioms Blc.Floor43.cert_e2249271786010
#print axioms Blc.Floor43.cert_e2249271793178
#print axioms Blc.Floor43.cert_e2249271794202
#print axioms Blc.Floor43.cert_e2249271864858
#print axioms Blc.Floor43.cert_e2249271866906
#print axioms Blc.Floor43.cert_e2249271963162
#print axioms Blc.Floor43.cert_e2249271966234
#print axioms Blc.Floor43.cert_e2249272014362
#print axioms Blc.Floor43.cert_e2249272015386
