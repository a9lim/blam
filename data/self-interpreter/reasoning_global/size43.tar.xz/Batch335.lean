import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418335855470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2418335855470 : Closed e2418335855470 ∧ code e2418335855470 = 11214428877678 := by decide
theorem cert_e2418335855470 : check e2418335855470 [[],[]] .chain = true := by decide
def e2418335855478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2418335855478 : Closed e2418335855478 ∧ code e2418335855478 = 11214428877686 := by decide
theorem cert_e2418335855478 : check e2418335855478 [[],[]] .chain = true := by decide
def e2418335855534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2418335855534 : Closed e2418335855534 ∧ code e2418335855534 = 11214428877742 := by decide
theorem cert_e2418335855534 : check e2418335855534 [[],[]] .chain = true := by decide
def e2418335855546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2418335855546 : Closed e2418335855546 ∧ code e2418335855546 = 11214428877754 := by decide
theorem cert_e2418335855546 : check e2418335855546 [[],[]] .chain = true := by decide
def e2418335855574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2418335855574 : Closed e2418335855574 ∧ code e2418335855574 = 11214428877782 := by decide
theorem cert_e2418335855574 : check e2418335855574 [[],[]] .chain = true := by decide
def e2418335855578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2418335855578 : Closed e2418335855578 ∧ code e2418335855578 = 11214428877786 := by decide
theorem cert_e2418335855578 : check e2418335855578 [[],[]] .chain = true := by decide
def e2418335855854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2418335855854 : Closed e2418335855854 ∧ code e2418335855854 = 11214428878062 := by decide
theorem cert_e2418335855854 : check e2418335855854 [[],[]] .chain = true := by decide
def e2418335855862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2418335855862 : Closed e2418335855862 ∧ code e2418335855862 = 11214428878070 := by decide
theorem cert_e2418335855862 : check e2418335855862 [[],[]] .chain = true := by decide
def e2418335856238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335856238 : Closed e2418335856238 ∧ code e2418335856238 = 11214428878446 := by decide
theorem cert_e2418335856238 : check e2418335856238 [[],[]] .chain = true := by decide
def e2418335856250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335856250 : Closed e2418335856250 ∧ code e2418335856250 = 11214428878458 := by decide
theorem cert_e2418335856250 : check e2418335856250 [[],[]] .chain = true := by decide
def e2418335856438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418335856438 : Closed e2418335856438 ∧ code e2418335856438 = 11214428878646 := by decide
theorem cert_e2418335856438 : check e2418335856438 [[],[]] .chain = true := by decide
def e2418335856442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418335856442 : Closed e2418335856442 ∧ code e2418335856442 = 11214428878650 := by decide
theorem cert_e2418335856442 : check e2418335856442 [[],[]] .chain = true := by decide
def e2418335856878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2418335856878 : Closed e2418335856878 ∧ code e2418335856878 = 11214428879086 := by decide
theorem cert_e2418335856878 : check e2418335856878 [[],[]] .chain = true := by decide
def e2418335856886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2418335856886 : Closed e2418335856886 ∧ code e2418335856886 = 11214428879094 := by decide
theorem cert_e2418335856886 : check e2418335856886 [[],[]] .chain = true := by decide
def e2418335857070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2418335857070 : Closed e2418335857070 ∧ code e2418335857070 = 11214428879278 := by decide
theorem cert_e2418335857070 : check e2418335857070 [[],[]] .chain = true := by decide
def e2418335857082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2418335857082 : Closed e2418335857082 ∧ code e2418335857082 = 11214428879290 := by decide
theorem cert_e2418335857082 : check e2418335857082 [[],[]] .chain = true := by decide
def e2418335857130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2418335857130 : Closed e2418335857130 ∧ code e2418335857130 = 11214428879338 := by decide
theorem cert_e2418335857130 : check e2418335857130 [[],[]] .chain = true := by decide
def e2418335857262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335857262 : Closed e2418335857262 ∧ code e2418335857262 = 11214428879470 := by decide
theorem cert_e2418335857262 : check e2418335857262 [[],[]] .chain = true := by decide
def e2418335857274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335857274 : Closed e2418335857274 ∧ code e2418335857274 = 11214428879482 := by decide
theorem cert_e2418335857274 : check e2418335857274 [[],[]] .chain = true := by decide
def e2418335857438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2418335857438 : Closed e2418335857438 ∧ code e2418335857438 = 11214428879646 := by decide
theorem cert_e2418335857438 : check e2418335857438 [[],[]] .chain = true := by decide
def e2418335857550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2418335857550 : Closed e2418335857550 ∧ code e2418335857550 = 11214428879758 := by decide
theorem cert_e2418335857550 : check e2418335857550 [[],[]] .chain = true := by decide
def e2418335857562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335857562 : Closed e2418335857562 ∧ code e2418335857562 = 11214428879770 := by decide
theorem cert_e2418335857562 : check e2418335857562 [[],[]] .chain = true := by decide
def e2418335857782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2418335857782 : Closed e2418335857782 ∧ code e2418335857782 = 11214428879990 := by decide
theorem cert_e2418335857782 : check e2418335857782 [[],[]] .chain = true := by decide
def e2418335857878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2418335857878 : Closed e2418335857878 ∧ code e2418335857878 = 11214428880086 := by decide
theorem cert_e2418335857878 : check e2418335857878 [[],[]] .chain = true := by decide
def e2418335857882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2418335857882 : Closed e2418335857882 ∧ code e2418335857882 = 11214428880090 := by decide
theorem cert_e2418335857882 : check e2418335857882 [[],[]] .chain = true := by decide
def e2418335857898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2418335857898 : Closed e2418335857898 ∧ code e2418335857898 = 11214428880106 := by decide
theorem cert_e2418335857898 : check e2418335857898 [[],[]] .chain = true := by decide
def e2418335857974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418335857974 : Closed e2418335857974 ∧ code e2418335857974 = 11214428880182 := by decide
theorem cert_e2418335857974 : check e2418335857974 [[],[]] .chain = true := by decide
def e2418335857978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418335857978 : Closed e2418335857978 ∧ code e2418335857978 = 11214428880186 := by decide
theorem cert_e2418335857978 : check e2418335857978 [[],[]] .chain = true := by decide
def e2418335858062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2418335858062 : Closed e2418335858062 ∧ code e2418335858062 = 11214428880270 := by decide
theorem cert_e2418335858062 : check e2418335858062 [[],[]] .chain = true := by decide
def e2418335858074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335858074 : Closed e2418335858074 ∧ code e2418335858074 = 11214428880282 := by decide
theorem cert_e2418335858074 : check e2418335858074 [[],[]] .chain = true := by decide
def e2418335859678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2418335859678 : Closed e2418335859678 ∧ code e2418335859678 = 11214428881886 := by decide
theorem cert_e2418335859678 : check e2418335859678 [[],[]] .chain = true := by decide
def e2418335859694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2418335859694 : Closed e2418335859694 ∧ code e2418335859694 = 11214428881902 := by decide
theorem cert_e2418335859694 : check e2418335859694 [[],[]] .chain = true := by decide
def e2418335861614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418335861614 : Closed e2418335861614 ∧ code e2418335861614 = 11214428883822 := by decide
theorem cert_e2418335861614 : check e2418335861614 [[],[]] .chain = true := by decide
def e2418335861622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418335861622 : Closed e2418335861622 ∧ code e2418335861622 = 11214428883830 := by decide
theorem cert_e2418335861622 : check e2418335861622 [[],[]] .chain = true := by decide
def e2418335861678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418335861678 : Closed e2418335861678 ∧ code e2418335861678 = 11214428883886 := by decide
theorem cert_e2418335861678 : check e2418335861678 [[],[]] .chain = true := by decide
def e2418335861690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418335861690 : Closed e2418335861690 ∧ code e2418335861690 = 11214428883898 := by decide
theorem cert_e2418335861690 : check e2418335861690 [[],[]] .chain = true := by decide
def e2418335861718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418335861718 : Closed e2418335861718 ∧ code e2418335861718 = 11214428883926 := by decide
theorem cert_e2418335861718 : check e2418335861718 [[],[]] .chain = true := by decide
def e2418335861722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418335861722 : Closed e2418335861722 ∧ code e2418335861722 = 11214428883930 := by decide
theorem cert_e2418335861722 : check e2418335861722 [[],[]] .chain = true := by decide
def e2418335861998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418335861998 : Closed e2418335861998 ∧ code e2418335861998 = 11214428884206 := by decide
theorem cert_e2418335861998 : check e2418335861998 [[],[]] .chain = true := by decide
def e2418335862006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418335862006 : Closed e2418335862006 ∧ code e2418335862006 = 11214428884214 := by decide
theorem cert_e2418335862006 : check e2418335862006 [[],[]] .chain = true := by decide
def e2418335862382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418335862382 : Closed e2418335862382 ∧ code e2418335862382 = 11214428884590 := by decide
theorem cert_e2418335862382 : check e2418335862382 [[],[]] .chain = true := by decide
def e2418335862394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418335862394 : Closed e2418335862394 ∧ code e2418335862394 = 11214428884602 := by decide
theorem cert_e2418335862394 : check e2418335862394 [[],[]] .chain = true := by decide
def e2418335862582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418335862582 : Closed e2418335862582 ∧ code e2418335862582 = 11214428884790 := by decide
theorem cert_e2418335862582 : check e2418335862582 [[],[]] .chain = true := by decide
def e2418335862586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418335862586 : Closed e2418335862586 ∧ code e2418335862586 = 11214428884794 := by decide
theorem cert_e2418335862586 : check e2418335862586 [[],[]] .chain = true := by decide
def e2418335867358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2418335867358 : Closed e2418335867358 ∧ code e2418335867358 = 11214428889566 := by decide
theorem cert_e2418335867358 : check e2418335867358 [[],[]] .chain = true := by decide
def e2418335867382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2418335867382 : Closed e2418335867382 ∧ code e2418335867382 = 11214428889590 := by decide
theorem cert_e2418335867382 : check e2418335867382 [[],[]] .chain = true := by decide
def e2418335868334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2418335868334 : Closed e2418335868334 ∧ code e2418335868334 = 11214428890542 := by decide
theorem cert_e2418335868334 : check e2418335868334 [[],[]] .chain = true := by decide
def e2418335868346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2418335868346 : Closed e2418335868346 ∧ code e2418335868346 = 11214428890554 := by decide
theorem cert_e2418335868346 : check e2418335868346 [[],[]] .chain = true := by decide
def e2418335868394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2418335868394 : Closed e2418335868394 ∧ code e2418335868394 = 11214428890602 := by decide
theorem cert_e2418335868394 : check e2418335868394 [[],[]] .chain = true := by decide
def e2418335868526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418335868526 : Closed e2418335868526 ∧ code e2418335868526 = 11214428890734 := by decide
theorem cert_e2418335868526 : check e2418335868526 [[],[]] .chain = true := by decide
def e2418335868538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418335868538 : Closed e2418335868538 ∧ code e2418335868538 = 11214428890746 := by decide
theorem cert_e2418335868538 : check e2418335868538 [[],[]] .chain = true := by decide
def e2418335868702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2418335868702 : Closed e2418335868702 ∧ code e2418335868702 = 11214428890910 := by decide
theorem cert_e2418335868702 : check e2418335868702 [[],[]] .chain = true := by decide
def e2418335868814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2418335868814 : Closed e2418335868814 ∧ code e2418335868814 = 11214428891022 := by decide
theorem cert_e2418335868814 : check e2418335868814 [[],[]] .chain = true := by decide
def e2418335868826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418335868826 : Closed e2418335868826 ∧ code e2418335868826 = 11214428891034 := by decide
theorem cert_e2418335868826 : check e2418335868826 [[],[]] .chain = true := by decide
def e2418335871214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2418335871214 : Closed e2418335871214 ∧ code e2418335871214 = 11214428893422 := by decide
theorem cert_e2418335871214 : check e2418335871214 [[],[]] .chain = true := by decide
def e2418335871222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2418335871222 : Closed e2418335871222 ∧ code e2418335871222 = 11214428893430 := by decide
theorem cert_e2418335871222 : check e2418335871222 [[],[]] .chain = true := by decide
def e2418335871702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2418335871702 : Closed e2418335871702 ∧ code e2418335871702 = 11214428893910 := by decide
theorem cert_e2418335871702 : check e2418335871702 [[],[]] .chain = true := by decide
def e2418335871706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2418335871706 : Closed e2418335871706 ∧ code e2418335871706 = 11214428893914 := by decide
theorem cert_e2418335871706 : check e2418335871706 [[],[]] .chain = true := by decide
def e2418335871722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2418335871722 : Closed e2418335871722 ∧ code e2418335871722 = 11214428893930 := by decide
theorem cert_e2418335871722 : check e2418335871722 [[],[]] .chain = true := by decide
def e2418335871798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418335871798 : Closed e2418335871798 ∧ code e2418335871798 = 11214428894006 := by decide
theorem cert_e2418335871798 : check e2418335871798 [[],[]] .chain = true := by decide
def e2418335871802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418335871802 : Closed e2418335871802 ∧ code e2418335871802 = 11214428894010 := by decide
theorem cert_e2418335871802 : check e2418335871802 [[],[]] .chain = true := by decide
def e2418335871886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2418335871886 : Closed e2418335871886 ∧ code e2418335871886 = 11214428894094 := by decide
theorem cert_e2418335871886 : check e2418335871886 [[],[]] .chain = true := by decide
def e2418335871898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418335871898 : Closed e2418335871898 ∧ code e2418335871898 = 11214428894106 := by decide
theorem cert_e2418335871898 : check e2418335871898 [[],[]] .chain = true := by decide
def e2418335962798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2418335962798 : Closed e2418335962798 ∧ code e2418335962798 = 11214428985006 := by decide
theorem cert_e2418335962798 : check e2418335962798 [[],[]] .chain = true := by decide
def e2418335962810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2418335962810 : Closed e2418335962810 ∧ code e2418335962810 = 11214428985018 := by decide
theorem cert_e2418335962810 : check e2418335962810 [[],[]] .chain = true := by decide
def e2418335962858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2418335962858 : Closed e2418335962858 ∧ code e2418335962858 = 11214428985066 := by decide
theorem cert_e2418335962858 : check e2418335962858 [[],[]] .chain = true := by decide
def e2418335963050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2418335963050 : Closed e2418335963050 ∧ code e2418335963050 = 11214428985258 := by decide
theorem cert_e2418335963050 : check e2418335963050 [[],[]] .chain = true := by decide
def e2418335963374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2418335963374 : Closed e2418335963374 ∧ code e2418335963374 = 11214428985582 := by decide
theorem cert_e2418335963374 : check e2418335963374 [[],[]] .chain = true := by decide
def e2418335963382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2418335963382 : Closed e2418335963382 ∧ code e2418335963382 = 11214428985590 := by decide
theorem cert_e2418335963382 : check e2418335963382 [[],[]] .chain = true := by decide
def e2418335963566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2418335963566 : Closed e2418335963566 ∧ code e2418335963566 = 11214428985774 := by decide
theorem cert_e2418335963566 : check e2418335963566 [[],[]] .chain = true := by decide
def e2418335963578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2418335963578 : Closed e2418335963578 ∧ code e2418335963578 = 11214428985786 := by decide
theorem cert_e2418335963578 : check e2418335963578 [[],[]] .chain = true := by decide
def e2418335963626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2418335963626 : Closed e2418335963626 ∧ code e2418335963626 = 11214428985834 := by decide
theorem cert_e2418335963626 : check e2418335963626 [[],[]] .chain = true := by decide
def e2418335963758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335963758 : Closed e2418335963758 ∧ code e2418335963758 = 11214428985966 := by decide
theorem cert_e2418335963758 : check e2418335963758 [[],[]] .chain = true := by decide
def e2418335963770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335963770 : Closed e2418335963770 ∧ code e2418335963770 = 11214428985978 := by decide
theorem cert_e2418335963770 : check e2418335963770 [[],[]] .chain = true := by decide
def e2418335963934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2418335963934 : Closed e2418335963934 ∧ code e2418335963934 = 11214428986142 := by decide
theorem cert_e2418335963934 : check e2418335963934 [[],[]] .chain = true := by decide
def e2418335964046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2418335964046 : Closed e2418335964046 ∧ code e2418335964046 = 11214428986254 := by decide
theorem cert_e2418335964046 : check e2418335964046 [[],[]] .chain = true := by decide
def e2418335964058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335964058 : Closed e2418335964058 ∧ code e2418335964058 = 11214428986266 := by decide
theorem cert_e2418335964058 : check e2418335964058 [[],[]] .chain = true := by decide
def e2418335964270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2418335964270 : Closed e2418335964270 ∧ code e2418335964270 = 11214428986478 := by decide
theorem cert_e2418335964270 : check e2418335964270 [[],[]] .chain = true := by decide
def e2418335964282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2418335964282 : Closed e2418335964282 ∧ code e2418335964282 = 11214428986490 := by decide
theorem cert_e2418335964282 : check e2418335964282 [[],[]] .chain = true := by decide
def e2418335964446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2418335964446 : Closed e2418335964446 ∧ code e2418335964446 = 11214428986654 := by decide
theorem cert_e2418335964446 : check e2418335964446 [[],[]] .chain = true := by decide
def e2418335964614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2418335964614 : Closed e2418335964614 ∧ code e2418335964614 = 11214428986822 := by decide
theorem cert_e2418335964614 : check e2418335964614 [[],[]] .chain = true := by decide
def e2418335964726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2418335964726 : Closed e2418335964726 ∧ code e2418335964726 = 11214428986934 := by decide
theorem cert_e2418335964726 : check e2418335964726 [[],[]] .chain = true := by decide
def e2418335964730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2418335964730 : Closed e2418335964730 ∧ code e2418335964730 = 11214428986938 := by decide
theorem cert_e2418335964730 : check e2418335964730 [[],[]] .chain = true := by decide
def e2418335964778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2418335964778 : Closed e2418335964778 ∧ code e2418335964778 = 11214428986986 := by decide
theorem cert_e2418335964778 : check e2418335964778 [[],[]] .chain = true := by decide
def e2418335964814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2418335964814 : Closed e2418335964814 ∧ code e2418335964814 = 11214428987022 := by decide
theorem cert_e2418335964814 : check e2418335964814 [[],[]] .chain = true := by decide
def e2418335964826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335964826 : Closed e2418335964826 ∧ code e2418335964826 = 11214428987034 := by decide
theorem cert_e2418335964826 : check e2418335964826 [[],[]] .chain = true := by decide
def e2418335964870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2418335964870 : Closed e2418335964870 ∧ code e2418335964870 = 11214428987078 := by decide
theorem cert_e2418335964870 : check e2418335964870 [[],[]] .chain = true := by decide
def e2418335965662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2418335965662 : Closed e2418335965662 ∧ code e2418335965662 = 11214428987870 := by decide
theorem cert_e2418335965662 : check e2418335965662 [[],[]] .chain = true := by decide
def e2418335965686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2418335965686 : Closed e2418335965686 ∧ code e2418335965686 = 11214428987894 := by decide
theorem cert_e2418335965686 : check e2418335965686 [[],[]] .chain = true := by decide
def e2418335966638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2418335966638 : Closed e2418335966638 ∧ code e2418335966638 = 11214428988846 := by decide
theorem cert_e2418335966638 : check e2418335966638 [[],[]] .chain = true := by decide
def e2418335966650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2418335966650 : Closed e2418335966650 ∧ code e2418335966650 = 11214428988858 := by decide
theorem cert_e2418335966650 : check e2418335966650 [[],[]] .chain = true := by decide
def e2418335966698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2418335966698 : Closed e2418335966698 ∧ code e2418335966698 = 11214428988906 := by decide
theorem cert_e2418335966698 : check e2418335966698 [[],[]] .chain = true := by decide
def e2418335966830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418335966830 : Closed e2418335966830 ∧ code e2418335966830 = 11214428989038 := by decide
theorem cert_e2418335966830 : check e2418335966830 [[],[]] .chain = true := by decide
def e2418335966842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418335966842 : Closed e2418335966842 ∧ code e2418335966842 = 11214428989050 := by decide
theorem cert_e2418335966842 : check e2418335966842 [[],[]] .chain = true := by decide
def e2418335967006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2418335967006 : Closed e2418335967006 ∧ code e2418335967006 = 11214428989214 := by decide
theorem cert_e2418335967006 : check e2418335967006 [[],[]] .chain = true := by decide
def e2418335967118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2418335967118 : Closed e2418335967118 ∧ code e2418335967118 = 11214428989326 := by decide
theorem cert_e2418335967118 : check e2418335967118 [[],[]] .chain = true := by decide
def e2418335967130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418335967130 : Closed e2418335967130 ∧ code e2418335967130 = 11214428989338 := by decide
theorem cert_e2418335967130 : check e2418335967130 [[],[]] .chain = true := by decide
def e2418335970078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2418335970078 : Closed e2418335970078 ∧ code e2418335970078 = 11214428992286 := by decide
theorem cert_e2418335970078 : check e2418335970078 [[],[]] .chain = true := by decide
def e2418335970246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2418335970246 : Closed e2418335970246 ∧ code e2418335970246 = 11214428992454 := by decide
theorem cert_e2418335970246 : check e2418335970246 [[],[]] .chain = true := by decide
def e2418335971446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2418335971446 : Closed e2418335971446 ∧ code e2418335971446 = 11214428993654 := by decide
theorem cert_e2418335971446 : check e2418335971446 [[],[]] .chain = true := by decide
def e2418335971690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2418335971690 : Closed e2418335971690 ∧ code e2418335971690 = 11214428993898 := by decide
theorem cert_e2418335971690 : check e2418335971690 [[],[]] .chain = true := by decide
def e2418335971726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2418335971726 : Closed e2418335971726 ∧ code e2418335971726 = 11214428993934 := by decide
theorem cert_e2418335971726 : check e2418335971726 [[],[]] .chain = true := by decide
def e2418335971738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418335971738 : Closed e2418335971738 ∧ code e2418335971738 = 11214428993946 := by decide
theorem cert_e2418335971738 : check e2418335971738 [[],[]] .chain = true := by decide
def e2418335971782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2418335971782 : Closed e2418335971782 ∧ code e2418335971782 = 11214428993990 := by decide
theorem cert_e2418335971782 : check e2418335971782 [[],[]] .chain = true := by decide
def e2418336017238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2418336017238 : Closed e2418336017238 ∧ code e2418336017238 = 11214429039446 := by decide
theorem cert_e2418336017238 : check e2418336017238 [[],[]] .chain = true := by decide
def e2418336017242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2418336017242 : Closed e2418336017242 ∧ code e2418336017242 = 11214429039450 := by decide
theorem cert_e2418336017242 : check e2418336017242 [[],[]] .chain = true := by decide
def e2418336017258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2418336017258 : Closed e2418336017258 ∧ code e2418336017258 = 11214429039466 := by decide
theorem cert_e2418336017258 : check e2418336017258 [[],[]] .chain = true := by decide
def e2418336017322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2418336017322 : Closed e2418336017322 ∧ code e2418336017322 = 11214429039530 := by decide
theorem cert_e2418336017322 : check e2418336017322 [[],[]] .chain = true := by decide
def e2418336017526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2418336017526 : Closed e2418336017526 ∧ code e2418336017526 = 11214429039734 := by decide
theorem cert_e2418336017526 : check e2418336017526 [[],[]] .chain = true := by decide
def e2418336017622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2418336017622 : Closed e2418336017622 ∧ code e2418336017622 = 11214429039830 := by decide
theorem cert_e2418336017622 : check e2418336017622 [[],[]] .chain = true := by decide
def e2418336017626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2418336017626 : Closed e2418336017626 ∧ code e2418336017626 = 11214429039834 := by decide
theorem cert_e2418336017626 : check e2418336017626 [[],[]] .chain = true := by decide
def e2418336017642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2418336017642 : Closed e2418336017642 ∧ code e2418336017642 = 11214429039850 := by decide
theorem cert_e2418336017642 : check e2418336017642 [[],[]] .chain = true := by decide
def e2418336017718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418336017718 : Closed e2418336017718 ∧ code e2418336017718 = 11214429039926 := by decide
theorem cert_e2418336017718 : check e2418336017718 [[],[]] .chain = true := by decide
def e2418336017722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418336017722 : Closed e2418336017722 ∧ code e2418336017722 = 11214429039930 := by decide
theorem cert_e2418336017722 : check e2418336017722 [[],[]] .chain = true := by decide
def e2418336017806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2418336017806 : Closed e2418336017806 ∧ code e2418336017806 = 11214429040014 := by decide
theorem cert_e2418336017806 : check e2418336017806 [[],[]] .chain = true := by decide
def e2418336017818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418336017818 : Closed e2418336017818 ∧ code e2418336017818 = 11214429040026 := by decide
theorem cert_e2418336017818 : check e2418336017818 [[],[]] .chain = true := by decide
def e2418336017974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2418336017974 : Closed e2418336017974 ∧ code e2418336017974 = 11214429040182 := by decide
theorem cert_e2418336017974 : check e2418336017974 [[],[]] .chain = true := by decide
def e2418336017978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2418336017978 : Closed e2418336017978 ∧ code e2418336017978 = 11214429040186 := by decide
theorem cert_e2418336017978 : check e2418336017978 [[],[]] .chain = true := by decide
def e2418336018026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2418336018026 : Closed e2418336018026 ∧ code e2418336018026 = 11214429040234 := by decide
theorem cert_e2418336018026 : check e2418336018026 [[],[]] .chain = true := by decide
def e2418336018062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2418336018062 : Closed e2418336018062 ∧ code e2418336018062 = 11214429040270 := by decide
theorem cert_e2418336018062 : check e2418336018062 [[],[]] .chain = true := by decide
def e2418336018074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418336018074 : Closed e2418336018074 ∧ code e2418336018074 = 11214429040282 := by decide
theorem cert_e2418336018074 : check e2418336018074 [[],[]] .chain = true := by decide
def e2418336018118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2418336018118 : Closed e2418336018118 ∧ code e2418336018118 = 11214429040326 := by decide
theorem cert_e2418336018118 : check e2418336018118 [[],[]] .chain = true := by decide
def e2418336018670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2418336018670 : Closed e2418336018670 ∧ code e2418336018670 = 11214429040878 := by decide
theorem cert_e2418336018670 : check e2418336018670 [[],[]] .chain = true := by decide
def e2418336018678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2418336018678 : Closed e2418336018678 ∧ code e2418336018678 = 11214429040886 := by decide
theorem cert_e2418336018678 : check e2418336018678 [[],[]] .chain = true := by decide
def e2418336019158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2418336019158 : Closed e2418336019158 ∧ code e2418336019158 = 11214429041366 := by decide
theorem cert_e2418336019158 : check e2418336019158 [[],[]] .chain = true := by decide
def e2418336019162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2418336019162 : Closed e2418336019162 ∧ code e2418336019162 = 11214429041370 := by decide
theorem cert_e2418336019162 : check e2418336019162 [[],[]] .chain = true := by decide
def e2418336019178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2418336019178 : Closed e2418336019178 ∧ code e2418336019178 = 11214429041386 := by decide
theorem cert_e2418336019178 : check e2418336019178 [[],[]] .chain = true := by decide
def e2418336019254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418336019254 : Closed e2418336019254 ∧ code e2418336019254 = 11214429041462 := by decide
theorem cert_e2418336019254 : check e2418336019254 [[],[]] .chain = true := by decide
def e2418336019258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418336019258 : Closed e2418336019258 ∧ code e2418336019258 = 11214429041466 := by decide
theorem cert_e2418336019258 : check e2418336019258 [[],[]] .chain = true := by decide
def e2418336019342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2418336019342 : Closed e2418336019342 ∧ code e2418336019342 = 11214429041550 := by decide
theorem cert_e2418336019342 : check e2418336019342 [[],[]] .chain = true := by decide
def e2418336019354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418336019354 : Closed e2418336019354 ∧ code e2418336019354 = 11214429041562 := by decide
theorem cert_e2418336019354 : check e2418336019354 [[],[]] .chain = true := by decide
def e2418336020598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2418336020598 : Closed e2418336020598 ∧ code e2418336020598 = 11214429042806 := by decide
theorem cert_e2418336020598 : check e2418336020598 [[],[]] .chain = true := by decide
def e2418336020842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2418336020842 : Closed e2418336020842 ∧ code e2418336020842 = 11214429043050 := by decide
theorem cert_e2418336020842 : check e2418336020842 [[],[]] .chain = true := by decide
def e2418336020878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2418336020878 : Closed e2418336020878 ∧ code e2418336020878 = 11214429043086 := by decide
theorem cert_e2418336020878 : check e2418336020878 [[],[]] .chain = true := by decide
def e2418336020890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418336020890 : Closed e2418336020890 ∧ code e2418336020890 = 11214429043098 := by decide
theorem cert_e2418336020890 : check e2418336020890 [[],[]] .chain = true := by decide
def e2418336020934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2418336020934 : Closed e2418336020934 ∧ code e2418336020934 = 11214429043142 := by decide
theorem cert_e2418336020934 : check e2418336020934 [[],[]] .chain = true := by decide
def e2418337918394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e2418337918394 : Closed e2418337918394 ∧ code e2418337918394 = 11214430940602 := by decide
theorem cert_e2418337918394 : check e2418337918394 [[],[]] .chain = true := by decide
def e2418337918426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e2418337918426 : Closed e2418337918426 ∧ code e2418337918426 = 11214430940634 := by decide
theorem cert_e2418337918426 : check e2418337918426 [[],[]] .chain = true := by decide
def e2418337918650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e2418337918650 : Closed e2418337918650 ∧ code e2418337918650 = 11214430940858 := by decide
theorem cert_e2418337918650 : check e2418337918650 [[],[]] .chain = true := by decide
def e2418337918698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e2418337918698 : Closed e2418337918698 ∧ code e2418337918698 = 11214430940906 := by decide
theorem cert_e2418337918698 : check e2418337918698 [[],[]] .chain = true := by decide
def e2418337918810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e2418337918810 : Closed e2418337918810 ∧ code e2418337918810 = 11214430941018 := by decide
theorem cert_e2418337918810 : check e2418337918810 [[],[]] .chain = true := by decide
def e2418337918826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e2418337918826 : Closed e2418337918826 ∧ code e2418337918826 = 11214430941034 := by decide
theorem cert_e2418337918826 : check e2418337918826 [[],[]] .chain = true := by decide
def e2418337919930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e2418337919930 : Closed e2418337919930 ∧ code e2418337919930 = 11214430942138 := by decide
theorem cert_e2418337919930 : check e2418337919930 [[],[]] .chain = true := by decide
def e2418337919962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e2418337919962 : Closed e2418337919962 ∧ code e2418337919962 = 11214430942170 := by decide
theorem cert_e2418337919962 : check e2418337919962 [[],[]] .chain = true := by decide
def e2418337921466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e2418337921466 : Closed e2418337921466 ∧ code e2418337921466 = 11214430943674 := by decide
theorem cert_e2418337921466 : check e2418337921466 [[],[]] .chain = true := by decide
def e2418337921514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e2418337921514 : Closed e2418337921514 ∧ code e2418337921514 = 11214430943722 := by decide
theorem cert_e2418337921514 : check e2418337921514 [[],[]] .chain = true := by decide
def e2418337922266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e2418337922266 : Closed e2418337922266 ∧ code e2418337922266 = 11214430944474 := by decide
theorem cert_e2418337922266 : check e2418337922266 [[],[]] .chain = true := by decide
def e2418337922282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e2418337922282 : Closed e2418337922282 ∧ code e2418337922282 = 11214430944490 := by decide
theorem cert_e2418337922282 : check e2418337922282 [[],[]] .chain = true := by decide
def e2418337975150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418337975150 : Closed e2418337975150 ∧ code e2418337975150 = 11214430997358 := by decide
theorem cert_e2418337975150 : check e2418337975150 [[],[]] .chain = true := by decide
def e2418337975158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418337975158 : Closed e2418337975158 ∧ code e2418337975158 = 11214430997366 := by decide
theorem cert_e2418337975158 : check e2418337975158 [[],[]] .chain = true := by decide
def e2418337975214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418337975214 : Closed e2418337975214 ∧ code e2418337975214 = 11214430997422 := by decide
theorem cert_e2418337975214 : check e2418337975214 [[],[]] .chain = true := by decide
def e2418337975226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418337975226 : Closed e2418337975226 ∧ code e2418337975226 = 11214430997434 := by decide
theorem cert_e2418337975226 : check e2418337975226 [[],[]] .chain = true := by decide
def e2418337975254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418337975254 : Closed e2418337975254 ∧ code e2418337975254 = 11214430997462 := by decide
theorem cert_e2418337975254 : check e2418337975254 [[],[]] .chain = true := by decide
def e2418337975258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418337975258 : Closed e2418337975258 ∧ code e2418337975258 = 11214430997466 := by decide
theorem cert_e2418337975258 : check e2418337975258 [[],[]] .chain = true := by decide
def e2418337975534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418337975534 : Closed e2418337975534 ∧ code e2418337975534 = 11214430997742 := by decide
theorem cert_e2418337975534 : check e2418337975534 [[],[]] .chain = true := by decide
def e2418337975542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418337975542 : Closed e2418337975542 ∧ code e2418337975542 = 11214430997750 := by decide
theorem cert_e2418337975542 : check e2418337975542 [[],[]] .chain = true := by decide
def e2418337975918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418337975918 : Closed e2418337975918 ∧ code e2418337975918 = 11214430998126 := by decide
theorem cert_e2418337975918 : check e2418337975918 [[],[]] .chain = true := by decide
def e2418337975930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418337975930 : Closed e2418337975930 ∧ code e2418337975930 = 11214430998138 := by decide
theorem cert_e2418337975930 : check e2418337975930 [[],[]] .chain = true := by decide
def e2418337976118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418337976118 : Closed e2418337976118 ∧ code e2418337976118 = 11214430998326 := by decide
theorem cert_e2418337976118 : check e2418337976118 [[],[]] .chain = true := by decide
def e2418337976122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418337976122 : Closed e2418337976122 ∧ code e2418337976122 = 11214430998330 := by decide
theorem cert_e2418337976122 : check e2418337976122 [[],[]] .chain = true := by decide
end Blc.Floor43
