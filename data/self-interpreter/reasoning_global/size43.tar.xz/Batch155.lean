import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2259634471110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259634471110 : Closed e2259634471110 ∧ code e2259634471110 = 11055727493318 := by decide
theorem cert_e2259634471110 : check e2259634471110 [[]] .width = true := by decide
def e2259634544666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259634544666 : Closed e2259634544666 ∧ code e2259634544666 = 11055727566874 := by decide
theorem cert_e2259634544666 : check e2259634544666 [[]] .width = true := by decide
def e2259634544758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259634544758 : Closed e2259634544758 ∧ code e2259634544758 = 11055727566966 := by decide
theorem cert_e2259634544758 : check e2259634544758 [[]] .width = true := by decide
def e2259634545002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259634545002 : Closed e2259634545002 ∧ code e2259634545002 = 11055727567210 := by decide
theorem cert_e2259634545002 : check e2259634545002 [[]] .width = true := by decide
def e2259634545050 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259634545050 : Closed e2259634545050 ∧ code e2259634545050 = 11055727567258 := by decide
theorem cert_e2259634545050 : check e2259634545050 [[]] .width = true := by decide
def e2259634557126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259634557126 : Closed e2259634557126 ∧ code e2259634557126 = 11055727579334 := by decide
theorem cert_e2259634557126 : check e2259634557126 [[]] .width = true := by decide
def e2259634560538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259634560538 : Closed e2259634560538 ∧ code e2259634560538 = 11055727582746 := by decide
theorem cert_e2259634560538 : check e2259634560538 [[]] .width = true := by decide
def e2259634569414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259634569414 : Closed e2259634569414 ∧ code e2259634569414 = 11055727591622 := by decide
theorem cert_e2259634569414 : check e2259634569414 [[]] .width = true := by decide
def e2259634577434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259634577434 : Closed e2259634577434 ∧ code e2259634577434 = 11055727599642 := by decide
theorem cert_e2259634577434 : check e2259634577434 [[]] .width = true := by decide
def e2259634577526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259634577526 : Closed e2259634577526 ∧ code e2259634577526 = 11055727599734 := by decide
theorem cert_e2259634577526 : check e2259634577526 [[]] .width = true := by decide
def e2259634577770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259634577770 : Closed e2259634577770 ∧ code e2259634577770 = 11055727599978 := by decide
theorem cert_e2259634577770 : check e2259634577770 [[]] .width = true := by decide
def e2259634577818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259634577818 : Closed e2259634577818 ∧ code e2259634577818 = 11055727600026 := by decide
theorem cert_e2259634577818 : check e2259634577818 [[]] .width = true := by decide
def e2259634581702 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259634581702 : Closed e2259634581702 ∧ code e2259634581702 = 11055727603910 := by decide
theorem cert_e2259634581702 : check e2259634581702 [[]] .width = true := by decide
def e2259634806810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259634806810 : Closed e2259634806810 ∧ code e2259634806810 = 11055727829018 := by decide
theorem cert_e2259634806810 : check e2259634806810 [[]] .width = true := by decide
def e2259634806902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259634806902 : Closed e2259634806902 ∧ code e2259634806902 = 11055727829110 := by decide
theorem cert_e2259634806902 : check e2259634806902 [[]] .width = true := by decide
def e2259634807146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259634807146 : Closed e2259634807146 ∧ code e2259634807146 = 11055727829354 := by decide
theorem cert_e2259634807146 : check e2259634807146 [[]] .width = true := by decide
def e2259634807194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259634807194 : Closed e2259634807194 ∧ code e2259634807194 = 11055727829402 := by decide
theorem cert_e2259634807194 : check e2259634807194 [[]] .width = true := by decide
def e2259634855962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259634855962 : Closed e2259634855962 ∧ code e2259634855962 = 11055727878170 := by decide
theorem cert_e2259634855962 : check e2259634855962 [[]] .width = true := by decide
def e2259634856054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259634856054 : Closed e2259634856054 ∧ code e2259634856054 = 11055727878262 := by decide
theorem cert_e2259634856054 : check e2259634856054 [[]] .width = true := by decide
def e2259634856298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259634856298 : Closed e2259634856298 ∧ code e2259634856298 = 11055727878506 := by decide
theorem cert_e2259634856298 : check e2259634856298 [[]] .width = true := by decide
def e2259634856346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259634856346 : Closed e2259634856346 ∧ code e2259634856346 = 11055727878554 := by decide
theorem cert_e2259634856346 : check e2259634856346 [[]] .width = true := by decide
def e2259634901190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259634901190 : Closed e2259634901190 ∧ code e2259634901190 = 11055727923398 := by decide
theorem cert_e2259634901190 : check e2259634901190 [[]] .width = true := by decide
def e2259634908698 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259634908698 : Closed e2259634908698 ∧ code e2259634908698 = 11055727930906 := by decide
theorem cert_e2259634908698 : check e2259634908698 [[]] .width = true := by decide
def e2259634911770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259634911770 : Closed e2259634911770 ∧ code e2259634911770 = 11055727933978 := by decide
theorem cert_e2259634911770 : check e2259634911770 [[]] .width = true := by decide
def e2259634950342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259634950342 : Closed e2259634950342 ∧ code e2259634950342 = 11055727972550 := by decide
theorem cert_e2259634950342 : check e2259634950342 [[]] .width = true := by decide
def e2259634953754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259634953754 : Closed e2259634953754 ∧ code e2259634953754 = 11055727975962 := by decide
theorem cert_e2259634953754 : check e2259634953754 [[]] .width = true := by decide
def e2259634962630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259634962630 : Closed e2259634962630 ∧ code e2259634962630 = 11055727984838 := by decide
theorem cert_e2259634962630 : check e2259634962630 [[]] .width = true := by decide
def e2259634970650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259634970650 : Closed e2259634970650 ∧ code e2259634970650 = 11055727992858 := by decide
theorem cert_e2259634970650 : check e2259634970650 [[]] .width = true := by decide
def e2259634970742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259634970742 : Closed e2259634970742 ∧ code e2259634970742 = 11055727992950 := by decide
theorem cert_e2259634970742 : check e2259634970742 [[]] .width = true := by decide
def e2259634970986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259634970986 : Closed e2259634970986 ∧ code e2259634970986 = 11055727993194 := by decide
theorem cert_e2259634970986 : check e2259634970986 [[]] .width = true := by decide
def e2259634971034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259634971034 : Closed e2259634971034 ∧ code e2259634971034 = 11055727993242 := by decide
theorem cert_e2259634971034 : check e2259634971034 [[]] .width = true := by decide
def e2259634974918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259634974918 : Closed e2259634974918 ∧ code e2259634974918 = 11055727997126 := by decide
theorem cert_e2259634974918 : check e2259634974918 [[]] .width = true := by decide
def e2259634987034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259634987034 : Closed e2259634987034 ∧ code e2259634987034 = 11055728009242 := by decide
theorem cert_e2259634987034 : check e2259634987034 [[]] .width = true := by decide
def e2259634987126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259634987126 : Closed e2259634987126 ∧ code e2259634987126 = 11055728009334 := by decide
theorem cert_e2259634987126 : check e2259634987126 [[]] .width = true := by decide
def e2259634987370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259634987370 : Closed e2259634987370 ∧ code e2259634987370 = 11055728009578 := by decide
theorem cert_e2259634987370 : check e2259634987370 [[]] .width = true := by decide
def e2259634987418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259634987418 : Closed e2259634987418 ∧ code e2259634987418 = 11055728009626 := by decide
theorem cert_e2259634987418 : check e2259634987418 [[]] .width = true := by decide
def e2259634996762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259634996762 : Closed e2259634996762 ∧ code e2259634996762 = 11055728018970 := by decide
theorem cert_e2259634996762 : check e2259634996762 [[]] .width = true := by decide
def e2259634999494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259634999494 : Closed e2259634999494 ∧ code e2259634999494 = 11055728021702 := by decide
theorem cert_e2259634999494 : check e2259634999494 [[]] .width = true := by decide
def e2259635634202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259635634202 : Closed e2259635634202 ∧ code e2259635634202 = 11055728656410 := by decide
theorem cert_e2259635634202 : check e2259635634202 [[]] .width = true := by decide
def e2259635634294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259635634294 : Closed e2259635634294 ∧ code e2259635634294 = 11055728656502 := by decide
theorem cert_e2259635634294 : check e2259635634294 [[]] .width = true := by decide
def e2259635634538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259635634538 : Closed e2259635634538 ∧ code e2259635634538 = 11055728656746 := by decide
theorem cert_e2259635634538 : check e2259635634538 [[]] .width = true := by decide
def e2259635634586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259635634586 : Closed e2259635634586 ∧ code e2259635634586 = 11055728656794 := by decide
theorem cert_e2259635634586 : check e2259635634586 [[]] .width = true := by decide
def e2259635635594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259635635594 : Closed e2259635635594 ∧ code e2259635635594 = 11055728657802 := by decide
theorem cert_e2259635635594 : check e2259635635594 [[]] .width = true := by decide
def e2259635635618 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259635635618 : Closed e2259635635618 ∧ code e2259635635618 = 11055728657826 := by decide
theorem cert_e2259635635618 : check e2259635635618 [[]] .width = true := by decide
def e2259635635726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259635635726 : Closed e2259635635726 ∧ code e2259635635726 = 11055728657934 := by decide
theorem cert_e2259635635726 : check e2259635635726 [[]] .width = true := by decide
def e2259635635738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259635635738 : Closed e2259635635738 ∧ code e2259635635738 = 11055728657946 := by decide
theorem cert_e2259635635738 : check e2259635635738 [[]] .width = true := by decide
def e2259635635810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259635635810 : Closed e2259635635810 ∧ code e2259635635810 = 11055728658018 := by decide
theorem cert_e2259635635810 : check e2259635635810 [[]] .width = true := by decide
def e2259636043974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259636043974 : Closed e2259636043974 ∧ code e2259636043974 = 11055729066182 := by decide
theorem cert_e2259636043974 : check e2259636043974 [[]] .width = true := by decide
def e2259636117530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259636117530 : Closed e2259636117530 ∧ code e2259636117530 = 11055729139738 := by decide
theorem cert_e2259636117530 : check e2259636117530 [[]] .width = true := by decide
def e2259636117622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259636117622 : Closed e2259636117622 ∧ code e2259636117622 = 11055729139830 := by decide
theorem cert_e2259636117622 : check e2259636117622 [[]] .width = true := by decide
def e2259636117866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259636117866 : Closed e2259636117866 ∧ code e2259636117866 = 11055729140074 := by decide
theorem cert_e2259636117866 : check e2259636117866 [[]] .width = true := by decide
def e2259636117914 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259636117914 : Closed e2259636117914 ∧ code e2259636117914 = 11055729140122 := by decide
theorem cert_e2259636117914 : check e2259636117914 [[]] .width = true := by decide
def e2259636129990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259636129990 : Closed e2259636129990 ∧ code e2259636129990 = 11055729152198 := by decide
theorem cert_e2259636129990 : check e2259636129990 [[]] .width = true := by decide
def e2259636133402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259636133402 : Closed e2259636133402 ∧ code e2259636133402 = 11055729155610 := by decide
theorem cert_e2259636133402 : check e2259636133402 [[]] .width = true := by decide
def e2259636142278 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259636142278 : Closed e2259636142278 ∧ code e2259636142278 = 11055729164486 := by decide
theorem cert_e2259636142278 : check e2259636142278 [[]] .width = true := by decide
def e2259636150298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259636150298 : Closed e2259636150298 ∧ code e2259636150298 = 11055729172506 := by decide
theorem cert_e2259636150298 : check e2259636150298 [[]] .width = true := by decide
def e2259636150390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259636150390 : Closed e2259636150390 ∧ code e2259636150390 = 11055729172598 := by decide
theorem cert_e2259636150390 : check e2259636150390 [[]] .width = true := by decide
def e2259636150634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259636150634 : Closed e2259636150634 ∧ code e2259636150634 = 11055729172842 := by decide
theorem cert_e2259636150634 : check e2259636150634 [[]] .width = true := by decide
def e2259636150682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259636150682 : Closed e2259636150682 ∧ code e2259636150682 = 11055729172890 := by decide
theorem cert_e2259636150682 : check e2259636150682 [[]] .width = true := by decide
def e2259636154566 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259636154566 : Closed e2259636154566 ∧ code e2259636154566 = 11055729176774 := by decide
theorem cert_e2259636154566 : check e2259636154566 [[]] .width = true := by decide
def e2259636977862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259636977862 : Closed e2259636977862 ∧ code e2259636977862 = 11055730000070 := by decide
theorem cert_e2259636977862 : check e2259636977862 [[]] .width = true := by decide
def e2259636978390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259636978390 : Closed e2259636978390 ∧ code e2259636978390 = 11055730000598 := by decide
theorem cert_e2259636978390 : check e2259636978390 [[]] .width = true := by decide
def e2259636978394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259636978394 : Closed e2259636978394 ∧ code e2259636978394 = 11055730000602 := by decide
theorem cert_e2259636978394 : check e2259636978394 [[]] .width = true := by decide
def e2259636978410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259636978410 : Closed e2259636978410 ∧ code e2259636978410 = 11055730000618 := by decide
theorem cert_e2259636978410 : check e2259636978410 [[]] .width = true := by decide
def e2259636978486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259636978486 : Closed e2259636978486 ∧ code e2259636978486 = 11055730000694 := by decide
theorem cert_e2259636978486 : check e2259636978486 [[]] .width = true := by decide
def e2259636978490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259636978490 : Closed e2259636978490 ∧ code e2259636978490 = 11055730000698 := by decide
theorem cert_e2259636978490 : check e2259636978490 [[]] .width = true := by decide
def e2259636978574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259636978574 : Closed e2259636978574 ∧ code e2259636978574 = 11055730000782 := by decide
theorem cert_e2259636978574 : check e2259636978574 [[]] .width = true := by decide
def e2259636978586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259636978586 : Closed e2259636978586 ∧ code e2259636978586 = 11055730000794 := by decide
theorem cert_e2259636978586 : check e2259636978586 [[]] .width = true := by decide
def e2259636980506 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259636980506 : Closed e2259636980506 ∧ code e2259636980506 = 11055730002714 := by decide
theorem cert_e2259636980506 : check e2259636980506 [[]] .width = true := by decide
def e2259636980550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259636980550 : Closed e2259636980550 ∧ code e2259636980550 = 11055730002758 := by decide
theorem cert_e2259636980550 : check e2259636980550 [[]] .width = true := by decide
def e2259636980662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259636980662 : Closed e2259636980662 ∧ code e2259636980662 = 11055730002870 := by decide
theorem cert_e2259636980662 : check e2259636980662 [[]] .width = true := by decide
def e2259636980790 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259636980790 : Closed e2259636980790 ∧ code e2259636980790 = 11055730002998 := by decide
theorem cert_e2259636980790 : check e2259636980790 [[]] .width = true := by decide
def e2259636980794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259636980794 : Closed e2259636980794 ∧ code e2259636980794 = 11055730003002 := by decide
theorem cert_e2259636980794 : check e2259636980794 [[]] .width = true := by decide
def e2259636980934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259636980934 : Closed e2259636980934 ∧ code e2259636980934 = 11055730003142 := by decide
theorem cert_e2259636980934 : check e2259636980934 [[]] .width = true := by decide
def e2259636981274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259636981274 : Closed e2259636981274 ∧ code e2259636981274 = 11055730003482 := by decide
theorem cert_e2259636981274 : check e2259636981274 [[]] .width = true := by decide
def e2259636981366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259636981366 : Closed e2259636981366 ∧ code e2259636981366 = 11055730003574 := by decide
theorem cert_e2259636981366 : check e2259636981366 [[]] .width = true := by decide
def e2259636988954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259636988954 : Closed e2259636988954 ∧ code e2259636988954 = 11055730011162 := by decide
theorem cert_e2259636988954 : check e2259636988954 [[]] .width = true := by decide
def e2259636988998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259636988998 : Closed e2259636988998 ∧ code e2259636988998 = 11055730011206 := by decide
theorem cert_e2259636988998 : check e2259636988998 [[]] .width = true := by decide
def e2259636989026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259636989026 : Closed e2259636989026 ∧ code e2259636989026 = 11055730011234 := by decide
theorem cert_e2259636989026 : check e2259636989026 [[]] .width = true := by decide
def e2259636989190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259636989190 : Closed e2259636989190 ∧ code e2259636989190 = 11055730011398 := by decide
theorem cert_e2259636989190 : check e2259636989190 [[]] .width = true := by decide
def e2259636989982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259636989982 : Closed e2259636989982 ∧ code e2259636989982 = 11055730012190 := by decide
theorem cert_e2259636989982 : check e2259636989982 [[]] .width = true := by decide
def e2259636990150 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259636990150 : Closed e2259636990150 ∧ code e2259636990150 = 11055730012358 := by decide
theorem cert_e2259636990150 : check e2259636990150 [[]] .width = true := by decide
def e2259636990178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259636990178 : Closed e2259636990178 ∧ code e2259636990178 = 11055730012386 := by decide
theorem cert_e2259636990178 : check e2259636990178 [[]] .width = true := by decide
def e2259636990726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259636990726 : Closed e2259636990726 ∧ code e2259636990726 = 11055730012934 := by decide
theorem cert_e2259636990726 : check e2259636990726 [[]] .width = true := by decide
def e2259637690394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259637690394 : Closed e2259637690394 ∧ code e2259637690394 = 11055730712602 := by decide
theorem cert_e2259637690394 : check e2259637690394 [[]] .width = true := by decide
def e2259637690486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259637690486 : Closed e2259637690486 ∧ code e2259637690486 = 11055730712694 := by decide
theorem cert_e2259637690486 : check e2259637690486 [[]] .width = true := by decide
def e2259637690730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259637690730 : Closed e2259637690730 ∧ code e2259637690730 = 11055730712938 := by decide
theorem cert_e2259637690730 : check e2259637690730 [[]] .width = true := by decide
def e2259637690778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259637690778 : Closed e2259637690778 ∧ code e2259637690778 = 11055730712986 := by decide
theorem cert_e2259637690778 : check e2259637690778 [[]] .width = true := by decide
def e2259637739546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259637739546 : Closed e2259637739546 ∧ code e2259637739546 = 11055730761754 := by decide
theorem cert_e2259637739546 : check e2259637739546 [[]] .width = true := by decide
def e2259637739638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259637739638 : Closed e2259637739638 ∧ code e2259637739638 = 11055730761846 := by decide
theorem cert_e2259637739638 : check e2259637739638 [[]] .width = true := by decide
def e2259637739882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259637739882 : Closed e2259637739882 ∧ code e2259637739882 = 11055730762090 := by decide
theorem cert_e2259637739882 : check e2259637739882 [[]] .width = true := by decide
def e2259637739930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259637739930 : Closed e2259637739930 ∧ code e2259637739930 = 11055730762138 := by decide
theorem cert_e2259637739930 : check e2259637739930 [[]] .width = true := by decide
def e2259638317254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259638317254 : Closed e2259638317254 ∧ code e2259638317254 = 11055731339462 := by decide
theorem cert_e2259638317254 : check e2259638317254 [[]] .width = true := by decide
def e2259638386714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259638386714 : Closed e2259638386714 ∧ code e2259638386714 = 11055731408922 := by decide
theorem cert_e2259638386714 : check e2259638386714 [[]] .width = true := by decide
def e2259638386806 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259638386806 : Closed e2259638386806 ∧ code e2259638386806 = 11055731409014 := by decide
theorem cert_e2259638386806 : check e2259638386806 [[]] .width = true := by decide
def e2259638387050 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259638387050 : Closed e2259638387050 ∧ code e2259638387050 = 11055731409258 := by decide
theorem cert_e2259638387050 : check e2259638387050 [[]] .width = true := by decide
def e2259638387098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259638387098 : Closed e2259638387098 ∧ code e2259638387098 = 11055731409306 := by decide
theorem cert_e2259638387098 : check e2259638387098 [[]] .width = true := by decide
def e2259638388106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259638388106 : Closed e2259638388106 ∧ code e2259638388106 = 11055731410314 := by decide
theorem cert_e2259638388106 : check e2259638388106 [[]] .width = true := by decide
def e2259638388130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259638388130 : Closed e2259638388130 ∧ code e2259638388130 = 11055731410338 := by decide
theorem cert_e2259638388130 : check e2259638388130 [[]] .width = true := by decide
def e2259638388238 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259638388238 : Closed e2259638388238 ∧ code e2259638388238 = 11055731410446 := by decide
theorem cert_e2259638388238 : check e2259638388238 [[]] .width = true := by decide
def e2259638388250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259638388250 : Closed e2259638388250 ∧ code e2259638388250 = 11055731410458 := by decide
theorem cert_e2259638388250 : check e2259638388250 [[]] .width = true := by decide
def e2259638388322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259638388322 : Closed e2259638388322 ∧ code e2259638388322 = 11055731410530 := by decide
theorem cert_e2259638388322 : check e2259638388322 [[]] .width = true := by decide
def e2259638489286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259638489286 : Closed e2259638489286 ∧ code e2259638489286 = 11055731511494 := by decide
theorem cert_e2259638489286 : check e2259638489286 [[]] .width = true := by decide
def e2259638492698 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259638492698 : Closed e2259638492698 ∧ code e2259638492698 = 11055731514906 := by decide
theorem cert_e2259638492698 : check e2259638492698 [[]] .width = true := by decide
def e2259638501574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259638501574 : Closed e2259638501574 ∧ code e2259638501574 = 11055731523782 := by decide
theorem cert_e2259638501574 : check e2259638501574 [[]] .width = true := by decide
def e2259638509594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259638509594 : Closed e2259638509594 ∧ code e2259638509594 = 11055731531802 := by decide
theorem cert_e2259638509594 : check e2259638509594 [[]] .width = true := by decide
def e2259638509686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259638509686 : Closed e2259638509686 ∧ code e2259638509686 = 11055731531894 := by decide
theorem cert_e2259638509686 : check e2259638509686 [[]] .width = true := by decide
def e2259638509930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259638509930 : Closed e2259638509930 ∧ code e2259638509930 = 11055731532138 := by decide
theorem cert_e2259638509930 : check e2259638509930 [[]] .width = true := by decide
def e2259638509978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259638509978 : Closed e2259638509978 ∧ code e2259638509978 = 11055731532186 := by decide
theorem cert_e2259638509978 : check e2259638509978 [[]] .width = true := by decide
def e2259638513862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259638513862 : Closed e2259638513862 ∧ code e2259638513862 = 11055731536070 := by decide
theorem cert_e2259638513862 : check e2259638513862 [[]] .width = true := by decide
def e2259638525978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259638525978 : Closed e2259638525978 ∧ code e2259638525978 = 11055731548186 := by decide
theorem cert_e2259638525978 : check e2259638525978 [[]] .width = true := by decide
def e2259638526070 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259638526070 : Closed e2259638526070 ∧ code e2259638526070 = 11055731548278 := by decide
theorem cert_e2259638526070 : check e2259638526070 [[]] .width = true := by decide
def e2259638526314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259638526314 : Closed e2259638526314 ∧ code e2259638526314 = 11055731548522 := by decide
theorem cert_e2259638526314 : check e2259638526314 [[]] .width = true := by decide
def e2259638526362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259638526362 : Closed e2259638526362 ∧ code e2259638526362 = 11055731548570 := by decide
theorem cert_e2259638526362 : check e2259638526362 [[]] .width = true := by decide
def e2259638535706 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259638535706 : Closed e2259638535706 ∧ code e2259638535706 = 11055731557914 := by decide
theorem cert_e2259638535706 : check e2259638535706 [[]] .width = true := by decide
def e2259638538438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259638538438 : Closed e2259638538438 ∧ code e2259638538438 = 11055731560646 := by decide
theorem cert_e2259638538438 : check e2259638538438 [[]] .width = true := by decide
def e2259638550726 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259638550726 : Closed e2259638550726 ∧ code e2259638550726 = 11055731572934 := by decide
theorem cert_e2259638550726 : check e2259638550726 [[]] .width = true := by decide
def e2259638551254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259638551254 : Closed e2259638551254 ∧ code e2259638551254 = 11055731573462 := by decide
theorem cert_e2259638551254 : check e2259638551254 [[]] .width = true := by decide
def e2259638551258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259638551258 : Closed e2259638551258 ∧ code e2259638551258 = 11055731573466 := by decide
theorem cert_e2259638551258 : check e2259638551258 [[]] .width = true := by decide
def e2259638551274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259638551274 : Closed e2259638551274 ∧ code e2259638551274 = 11055731573482 := by decide
theorem cert_e2259638551274 : check e2259638551274 [[]] .width = true := by decide
def e2259638551350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259638551350 : Closed e2259638551350 ∧ code e2259638551350 = 11055731573558 := by decide
theorem cert_e2259638551350 : check e2259638551350 [[]] .width = true := by decide
def e2259638551354 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259638551354 : Closed e2259638551354 ∧ code e2259638551354 = 11055731573562 := by decide
theorem cert_e2259638551354 : check e2259638551354 [[]] .width = true := by decide
def e2259638551438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259638551438 : Closed e2259638551438 ∧ code e2259638551438 = 11055731573646 := by decide
theorem cert_e2259638551438 : check e2259638551438 [[]] .width = true := by decide
def e2259638551450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259638551450 : Closed e2259638551450 ∧ code e2259638551450 = 11055731573658 := by decide
theorem cert_e2259638551450 : check e2259638551450 [[]] .width = true := by decide
def e2259638553370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259638553370 : Closed e2259638553370 ∧ code e2259638553370 = 11055731575578 := by decide
theorem cert_e2259638553370 : check e2259638553370 [[]] .width = true := by decide
def e2259638553414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259638553414 : Closed e2259638553414 ∧ code e2259638553414 = 11055731575622 := by decide
theorem cert_e2259638553414 : check e2259638553414 [[]] .width = true := by decide
def e2259638553526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259638553526 : Closed e2259638553526 ∧ code e2259638553526 = 11055731575734 := by decide
theorem cert_e2259638553526 : check e2259638553526 [[]] .width = true := by decide
def e2259638553654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259638553654 : Closed e2259638553654 ∧ code e2259638553654 = 11055731575862 := by decide
theorem cert_e2259638553654 : check e2259638553654 [[]] .width = true := by decide
def e2259638553658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259638553658 : Closed e2259638553658 ∧ code e2259638553658 = 11055731575866 := by decide
theorem cert_e2259638553658 : check e2259638553658 [[]] .width = true := by decide
def e2259638553798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259638553798 : Closed e2259638553798 ∧ code e2259638553798 = 11055731576006 := by decide
theorem cert_e2259638553798 : check e2259638553798 [[]] .width = true := by decide
def e2259638554138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259638554138 : Closed e2259638554138 ∧ code e2259638554138 = 11055731576346 := by decide
theorem cert_e2259638554138 : check e2259638554138 [[]] .width = true := by decide
def e2259638554230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259638554230 : Closed e2259638554230 ∧ code e2259638554230 = 11055731576438 := by decide
theorem cert_e2259638554230 : check e2259638554230 [[]] .width = true := by decide
def e2259638561818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259638561818 : Closed e2259638561818 ∧ code e2259638561818 = 11055731584026 := by decide
theorem cert_e2259638561818 : check e2259638561818 [[]] .width = true := by decide
def e2259638561862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259638561862 : Closed e2259638561862 ∧ code e2259638561862 = 11055731584070 := by decide
theorem cert_e2259638561862 : check e2259638561862 [[]] .width = true := by decide
def e2259638561890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259638561890 : Closed e2259638561890 ∧ code e2259638561890 = 11055731584098 := by decide
theorem cert_e2259638561890 : check e2259638561890 [[]] .width = true := by decide
def e2259638562054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259638562054 : Closed e2259638562054 ∧ code e2259638562054 = 11055731584262 := by decide
theorem cert_e2259638562054 : check e2259638562054 [[]] .width = true := by decide
def e2259638562846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259638562846 : Closed e2259638562846 ∧ code e2259638562846 = 11055731585054 := by decide
theorem cert_e2259638562846 : check e2259638562846 [[]] .width = true := by decide
def e2259638563014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259638563014 : Closed e2259638563014 ∧ code e2259638563014 = 11055731585222 := by decide
theorem cert_e2259638563014 : check e2259638563014 [[]] .width = true := by decide
def e2259638563042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259638563042 : Closed e2259638563042 ∧ code e2259638563042 = 11055731585250 := by decide
theorem cert_e2259638563042 : check e2259638563042 [[]] .width = true := by decide
def e2259638563590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259638563590 : Closed e2259638563590 ∧ code e2259638563590 = 11055731585798 := by decide
theorem cert_e2259638563590 : check e2259638563590 [[]] .width = true := by decide
def e2259657612826 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259657612826 : Closed e2259657612826 ∧ code e2259657612826 = 11055750635034 := by decide
private def t_e2259657612826 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259657612826 : ¬ IsSelfInterpreter e2259657612826 :=
  wSource (t := t_e2259657612826) (replay_sound (ps := []) (t := e2259657612826) (by decide)) (by decide)
def e2259657618970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259657618970 : Closed e2259657618970 ∧ code e2259657618970 = 11055750641178 := by decide
private def t_e2259657618970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259657618970 : ¬ IsSelfInterpreter e2259657618970 :=
  wSource (t := t_e2259657618970) (replay_sound (ps := []) (t := e2259657618970) (by decide)) (by decide)
def e2259657645594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259657645594 : Closed e2259657645594 ∧ code e2259657645594 = 11055750667802 := by decide
private def t_e2259657645594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259657645594 : ¬ IsSelfInterpreter e2259657645594 :=
  wSource (t := t_e2259657645594) (replay_sound (ps := []) (t := e2259657645594) (by decide)) (by decide)
def e2259657652762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259657652762 : Closed e2259657652762 ∧ code e2259657652762 = 11055750674970 := by decide
private def t_e2259657652762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259657652762 : ¬ IsSelfInterpreter e2259657652762 :=
  wSource (t := t_e2259657652762) (replay_sound (ps := []) (t := e2259657652762) (by decide)) (by decide)
def e2259657676314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259657676314 : Closed e2259657676314 ∧ code e2259657676314 = 11055750698522 := by decide
private def t_e2259657676314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259657676314 : ¬ IsSelfInterpreter e2259657676314 :=
  wSource (t := t_e2259657676314) (replay_sound (ps := []) (t := e2259657676314) (by decide)) (by decide)
def e2259657677338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259657677338 : Closed e2259657677338 ∧ code e2259657677338 = 11055750699546 := by decide
private def t_e2259657677338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259657677338 : ¬ IsSelfInterpreter e2259657677338 :=
  wSource (t := t_e2259657677338) (replay_sound (ps := []) (t := e2259657677338) (by decide)) (by decide)
def e2259657809434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259657809434 : Closed e2259657809434 ∧ code e2259657809434 = 11055750831642 := by decide
private def t_e2259657809434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259657809434 : ¬ IsSelfInterpreter e2259657809434 :=
  wSource (t := t_e2259657809434) (replay_sound (ps := []) (t := e2259657809434) (by decide)) (by decide)
def e2259657815578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259657815578 : Closed e2259657815578 ∧ code e2259657815578 = 11055750837786 := by decide
private def t_e2259657815578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259657815578 : ¬ IsSelfInterpreter e2259657815578 :=
  wSource (t := t_e2259657815578) (replay_sound (ps := []) (t := e2259657815578) (by decide)) (by decide)
def e2259658006042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259658006042 : Closed e2259658006042 ∧ code e2259658006042 = 11055751028250 := by decide
private def t_e2259658006042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259658006042 : ¬ IsSelfInterpreter e2259658006042 :=
  wSource (t := t_e2259658006042) (replay_sound (ps := []) (t := e2259658006042) (by decide)) (by decide)
def e2259658013210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259658013210 : Closed e2259658013210 ∧ code e2259658013210 = 11055751035418 := by decide
private def t_e2259658013210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259658013210 : ¬ IsSelfInterpreter e2259658013210 :=
  wSource (t := t_e2259658013210) (replay_sound (ps := []) (t := e2259658013210) (by decide)) (by decide)
def e2259658064070 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259658064070 : Closed e2259658064070 ∧ code e2259658064070 = 11055751086278 := by decide
theorem cert_e2259658064070 : check e2259658064070 [[]] .width = true := by decide
def e2259658129606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259658129606 : Closed e2259658129606 ∧ code e2259658129606 = 11055751151814 := by decide
theorem cert_e2259658129606 : check e2259658129606 [[]] .width = true := by decide
def e2259658159642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259658159642 : Closed e2259658159642 ∧ code e2259658159642 = 11055751181850 := by decide
private def t_e2259658159642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259658159642 : ¬ IsSelfInterpreter e2259658159642 :=
  wSource (t := t_e2259658159642) (replay_sound (ps := []) (t := e2259658159642) (by decide)) (by decide)
def e2259658160666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259658160666 : Closed e2259658160666 ∧ code e2259658160666 = 11055751182874 := by decide
private def t_e2259658160666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259658160666 : ¬ IsSelfInterpreter e2259658160666 :=
  wSource (t := t_e2259658160666) (replay_sound (ps := []) (t := e2259658160666) (by decide)) (by decide)
def e2259661926598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259661926598 : Closed e2259661926598 ∧ code e2259661926598 = 11055754948806 := by decide
theorem cert_e2259661926598 : check e2259661926598 [[]] .width = true := by decide
def e2259661942298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259661942298 : Closed e2259661942298 ∧ code e2259661942298 = 11055754964506 := by decide
theorem cert_e2259661942298 : check e2259661942298 [[]] .width = true := by decide
def e2259661944346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259661944346 : Closed e2259661944346 ∧ code e2259661944346 = 11055754966554 := by decide
theorem cert_e2259661944346 : check e2259661944346 [[]] .width = true := by decide
def e2259662061766 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259662061766 : Closed e2259662061766 ∧ code e2259662061766 = 11055755083974 := by decide
theorem cert_e2259662061766 : check e2259662061766 [[]] .width = true := by decide
def e2259662082246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662082246 : Closed e2259662082246 ∧ code e2259662082246 = 11055755104454 := by decide
theorem cert_e2259662082246 : check e2259662082246 [[]] .width = true := by decide
def e2259662085658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662085658 : Closed e2259662085658 ∧ code e2259662085658 = 11055755107866 := by decide
theorem cert_e2259662085658 : check e2259662085658 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2259657612826
#print axioms Blc.Floor43.cert_e2259657618970
#print axioms Blc.Floor43.cert_e2259657645594
#print axioms Blc.Floor43.cert_e2259657652762
#print axioms Blc.Floor43.cert_e2259657676314
#print axioms Blc.Floor43.cert_e2259657677338
#print axioms Blc.Floor43.cert_e2259657809434
#print axioms Blc.Floor43.cert_e2259657815578
#print axioms Blc.Floor43.cert_e2259658006042
#print axioms Blc.Floor43.cert_e2259658013210
#print axioms Blc.Floor43.cert_e2259658159642
#print axioms Blc.Floor43.cert_e2259658160666
