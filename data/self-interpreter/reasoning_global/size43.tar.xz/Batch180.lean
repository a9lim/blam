import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262385625966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262385625966 : Closed e2262385625966 ∧ code e2262385625966 = 11058478648174 := by decide
theorem cert_e2262385625966 : check e2262385625966 [[],[.under]] .chain = true := by decide
def e2262385625974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262385625974 : Closed e2262385625974 ∧ code e2262385625974 = 11058478648182 := by decide
theorem cert_e2262385625974 : check e2262385625974 [[],[.under]] .chain = true := by decide
def e2262385626030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262385626030 : Closed e2262385626030 ∧ code e2262385626030 = 11058478648238 := by decide
theorem cert_e2262385626030 : check e2262385626030 [[],[.under]] .chain = true := by decide
def e2262385626042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262385626042 : Closed e2262385626042 ∧ code e2262385626042 = 11058478648250 := by decide
theorem cert_e2262385626042 : check e2262385626042 [[],[.under]] .chain = true := by decide
def e2262385626070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262385626070 : Closed e2262385626070 ∧ code e2262385626070 = 11058478648278 := by decide
theorem cert_e2262385626070 : check e2262385626070 [[],[.under]] .chain = true := by decide
def e2262385626074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262385626074 : Closed e2262385626074 ∧ code e2262385626074 = 11058478648282 := by decide
theorem cert_e2262385626074 : check e2262385626074 [[],[.under]] .chain = true := by decide
def e2262385626350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262385626350 : Closed e2262385626350 ∧ code e2262385626350 = 11058478648558 := by decide
theorem cert_e2262385626350 : check e2262385626350 [[],[.under]] .chain = true := by decide
def e2262385626358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262385626358 : Closed e2262385626358 ∧ code e2262385626358 = 11058478648566 := by decide
theorem cert_e2262385626358 : check e2262385626358 [[],[.under]] .chain = true := by decide
def e2262385626734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262385626734 : Closed e2262385626734 ∧ code e2262385626734 = 11058478648942 := by decide
theorem cert_e2262385626734 : check e2262385626734 [[],[.under]] .chain = true := by decide
def e2262385626746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262385626746 : Closed e2262385626746 ∧ code e2262385626746 = 11058478648954 := by decide
theorem cert_e2262385626746 : check e2262385626746 [[],[.under]] .chain = true := by decide
def e2262385626934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262385626934 : Closed e2262385626934 ∧ code e2262385626934 = 11058478649142 := by decide
theorem cert_e2262385626934 : check e2262385626934 [[],[.under]] .chain = true := by decide
def e2262385626938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262385626938 : Closed e2262385626938 ∧ code e2262385626938 = 11058478649146 := by decide
theorem cert_e2262385626938 : check e2262385626938 [[],[.under]] .chain = true := by decide
def e2262385822574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262385822574 : Closed e2262385822574 ∧ code e2262385822574 = 11058478844782 := by decide
theorem cert_e2262385822574 : check e2262385822574 [[],[.under]] .smaller = true := by decide
def e2262385822582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262385822582 : Closed e2262385822582 ∧ code e2262385822582 = 11058478844790 := by decide
theorem cert_e2262385822582 : check e2262385822582 [[],[.under]] .smaller = true := by decide
def e2262385822638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262385822638 : Closed e2262385822638 ∧ code e2262385822638 = 11058478844846 := by decide
theorem cert_e2262385822638 : check e2262385822638 [[],[.under]] .smaller = true := by decide
def e2262385822650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262385822650 : Closed e2262385822650 ∧ code e2262385822650 = 11058478844858 := by decide
theorem cert_e2262385822650 : check e2262385822650 [[],[.under]] .smaller = true := by decide
def e2262385822678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262385822678 : Closed e2262385822678 ∧ code e2262385822678 = 11058478844886 := by decide
theorem cert_e2262385822678 : check e2262385822678 [[],[.under]] .smaller = true := by decide
def e2262385822682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262385822682 : Closed e2262385822682 ∧ code e2262385822682 = 11058478844890 := by decide
theorem cert_e2262385822682 : check e2262385822682 [[],[.under]] .smaller = true := by decide
def e2262385822958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262385822958 : Closed e2262385822958 ∧ code e2262385822958 = 11058478845166 := by decide
theorem cert_e2262385822958 : check e2262385822958 [[],[.under]] .smaller = true := by decide
def e2262385822966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262385822966 : Closed e2262385822966 ∧ code e2262385822966 = 11058478845174 := by decide
theorem cert_e2262385822966 : check e2262385822966 [[],[.under]] .smaller = true := by decide
def e2262385823342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262385823342 : Closed e2262385823342 ∧ code e2262385823342 = 11058478845550 := by decide
theorem cert_e2262385823342 : check e2262385823342 [[],[.under]] .smaller = true := by decide
def e2262385823354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262385823354 : Closed e2262385823354 ∧ code e2262385823354 = 11058478845562 := by decide
theorem cert_e2262385823354 : check e2262385823354 [[],[.under]] .smaller = true := by decide
def e2262385823542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262385823542 : Closed e2262385823542 ∧ code e2262385823542 = 11058478845750 := by decide
theorem cert_e2262385823542 : check e2262385823542 [[],[.under]] .smaller = true := by decide
def e2262385823546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262385823546 : Closed e2262385823546 ∧ code e2262385823546 = 11058478845754 := by decide
theorem cert_e2262385823546 : check e2262385823546 [[],[.under]] .smaller = true := by decide
def e2262386105206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e2262386105206 : Closed e2262386105206 ∧ code e2262386105206 = 11058479127414 := by decide
theorem cert_e2262386105206 : check e2262386105206 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386105270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e2262386105270 : Closed e2262386105270 ∧ code e2262386105270 = 11058479127478 := by decide
private def t_e2262386105270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem cert_e2262386105270 : ¬ IsSelfInterpreter e2262386105270 :=
  wSource (t := t_e2262386105270) (replay_sound (ps := []) (t := e2262386105270) (by decide)) (by decide)
def e2262386105718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e2262386105718 : Closed e2262386105718 ∧ code e2262386105718 = 11058479127926 := by decide
theorem cert_e2262386105718 : check e2262386105718 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386105814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e2262386105814 : Closed e2262386105814 ∧ code e2262386105814 = 11058479128022 := by decide
theorem cert_e2262386105814 : check e2262386105814 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2262386106038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e2262386106038 : Closed e2262386106038 ∧ code e2262386106038 = 11058479128246 := by decide
private def t_e2262386106038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem cert_e2262386106038 : ¬ IsSelfInterpreter e2262386106038 :=
  wSource (t := t_e2262386106038) (replay_sound (ps := []) (t := e2262386106038) (by decide)) (by decide)
def e2262386106070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e2262386106070 : Closed e2262386106070 ∧ code e2262386106070 = 11058479128278 := by decide
theorem cert_e2262386106070 : check e2262386106070 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386108278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e2262386108278 : Closed e2262386108278 ∧ code e2262386108278 = 11058479130486 := by decide
theorem cert_e2262386108278 : check e2262386108278 [[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2262386108342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e2262386108342 : Closed e2262386108342 ∧ code e2262386108342 = 11058479130550 := by decide
def e2262386111350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e2262386111350 : Closed e2262386111350 ∧ code e2262386111350 = 11058479133558 := by decide
def e2262386111446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e2262386111446 : Closed e2262386111446 ∧ code e2262386111446 = 11058479133654 := by decide
def e2262386112950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e2262386112950 : Closed e2262386112950 ∧ code e2262386112950 = 11058479135158 := by decide
def e2262386112982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e2262386112982 : Closed e2262386112982 ∧ code e2262386112982 = 11058479135190 := by decide
def e2262386281326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262386281326 : Closed e2262386281326 ∧ code e2262386281326 = 11058479303534 := by decide
private def t_e2262386281326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e2262386281326 : ¬ IsSelfInterpreter e2262386281326 :=
  wSource (t := t_e2262386281326) (replay_sound (ps := []) (t := e2262386281326) (by decide)) (by decide)
def e2262386281334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262386281334 : Closed e2262386281334 ∧ code e2262386281334 = 11058479303542 := by decide
private def t_e2262386281334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2262386281334 : ¬ IsSelfInterpreter e2262386281334 :=
  wSource (t := t_e2262386281334) (replay_sound (ps := []) (t := e2262386281334) (by decide)) (by decide)
def e2262386281390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262386281390 : Closed e2262386281390 ∧ code e2262386281390 = 11058479303598 := by decide
private def t_e2262386281390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e2262386281390 : ¬ IsSelfInterpreter e2262386281390 :=
  wSource (t := t_e2262386281390) (replay_sound (ps := []) (t := e2262386281390) (by decide)) (by decide)
def e2262386281402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262386281402 : Closed e2262386281402 ∧ code e2262386281402 = 11058479303610 := by decide
private def t_e2262386281402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2262386281402 : ¬ IsSelfInterpreter e2262386281402 :=
  wSource (t := t_e2262386281402) (replay_sound (ps := []) (t := e2262386281402) (by decide)) (by decide)
def e2262386281430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262386281430 : Closed e2262386281430 ∧ code e2262386281430 = 11058479303638 := by decide
private def t_e2262386281430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2262386281430 : ¬ IsSelfInterpreter e2262386281430 :=
  wSource (t := t_e2262386281430) (replay_sound (ps := []) (t := e2262386281430) (by decide)) (by decide)
def e2262386281434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262386281434 : Closed e2262386281434 ∧ code e2262386281434 = 11058479303642 := by decide
private def t_e2262386281434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2262386281434 : ¬ IsSelfInterpreter e2262386281434 :=
  wSource (t := t_e2262386281434) (replay_sound (ps := []) (t := e2262386281434) (by decide)) (by decide)
def e2262386281710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262386281710 : Closed e2262386281710 ∧ code e2262386281710 = 11058479303918 := by decide
private def t_e2262386281710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e2262386281710 : ¬ IsSelfInterpreter e2262386281710 :=
  wSource (t := t_e2262386281710) (replay_sound (ps := []) (t := e2262386281710) (by decide)) (by decide)
def e2262386281718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262386281718 : Closed e2262386281718 ∧ code e2262386281718 = 11058479303926 := by decide
private def t_e2262386281718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e2262386281718 : ¬ IsSelfInterpreter e2262386281718 :=
  wSource (t := t_e2262386281718) (replay_sound (ps := []) (t := e2262386281718) (by decide)) (by decide)
def e2262386282094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262386282094 : Closed e2262386282094 ∧ code e2262386282094 = 11058479304302 := by decide
private def t_e2262386282094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e2262386282094 : ¬ IsSelfInterpreter e2262386282094 :=
  wSource (t := t_e2262386282094) (replay_sound (ps := []) (t := e2262386282094) (by decide)) (by decide)
def e2262386282106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262386282106 : Closed e2262386282106 ∧ code e2262386282106 = 11058479304314 := by decide
private def t_e2262386282106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e2262386282106 : ¬ IsSelfInterpreter e2262386282106 :=
  wSource (t := t_e2262386282106) (replay_sound (ps := []) (t := e2262386282106) (by decide)) (by decide)
def e2262386282294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262386282294 : Closed e2262386282294 ∧ code e2262386282294 = 11058479304502 := by decide
private def t_e2262386282294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e2262386282294 : ¬ IsSelfInterpreter e2262386282294 :=
  wSource (t := t_e2262386282294) (replay_sound (ps := []) (t := e2262386282294) (by decide)) (by decide)
def e2262386282298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262386282298 : Closed e2262386282298 ∧ code e2262386282298 = 11058479304506 := by decide
private def t_e2262386282298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e2262386282298 : ¬ IsSelfInterpreter e2262386282298 :=
  wSource (t := t_e2262386282298) (replay_sound (ps := []) (t := e2262386282298) (by decide)) (by decide)
def e2262386617822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2262386617822 : Closed e2262386617822 ∧ code e2262386617822 = 11058479640030 := by decide
theorem cert_e2262386617822 : check e2262386617822 [[],[.under]] .smaller = true := by decide
def e2262386617838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2262386617838 : Closed e2262386617838 ∧ code e2262386617838 = 11058479640046 := by decide
theorem cert_e2262386617838 : check e2262386617838 [[],[.under]] .smaller = true := by decide
def e2262386618206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2262386618206 : Closed e2262386618206 ∧ code e2262386618206 = 11058479640414 := by decide
theorem cert_e2262386618206 : check e2262386618206 [[],[.under]] .smaller = true := by decide
def e2262386618234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2262386618234 : Closed e2262386618234 ∧ code e2262386618234 = 11058479640442 := by decide
theorem cert_e2262386618234 : check e2262386618234 [[],[.under]] .smaller = true := by decide
def e2262386618286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2262386618286 : Closed e2262386618286 ∧ code e2262386618286 = 11058479640494 := by decide
theorem cert_e2262386618286 : check e2262386618286 [[],[.under]] .smaller = true := by decide
def e2262386618298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2262386618298 : Closed e2262386618298 ∧ code e2262386618298 = 11058479640506 := by decide
theorem cert_e2262386618298 : check e2262386618298 [[],[.under]] .smaller = true := by decide
def e2262386619358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2262386619358 : Closed e2262386619358 ∧ code e2262386619358 = 11058479641566 := by decide
theorem cert_e2262386619358 : check e2262386619358 [[],[.under]] .smaller = true := by decide
def e2262386619374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2262386619374 : Closed e2262386619374 ∧ code e2262386619374 = 11058479641582 := by decide
theorem cert_e2262386619374 : check e2262386619374 [[],[.under]] .smaller = true := by decide
def e2262386621662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2262386621662 : Closed e2262386621662 ∧ code e2262386621662 = 11058479643870 := by decide
theorem cert_e2262386621662 : check e2262386621662 [[],[.under]] .smaller = true := by decide
def e2262386621690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2262386621690 : Closed e2262386621690 ∧ code e2262386621690 = 11058479643898 := by decide
theorem cert_e2262386621690 : check e2262386621690 [[],[.under]] .smaller = true := by decide
def e2262386622062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262386622062 : Closed e2262386622062 ∧ code e2262386622062 = 11058479644270 := by decide
theorem cert_e2262386622062 : check e2262386622062 [[],[.under]] .smaller = true := by decide
def e2262386622074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262386622074 : Closed e2262386622074 ∧ code e2262386622074 = 11058479644282 := by decide
theorem cert_e2262386622074 : check e2262386622074 [[],[.under]] .smaller = true := by decide
def e2262386650478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2262386650478 : Closed e2262386650478 ∧ code e2262386650478 = 11058479672686 := by decide
theorem cert_e2262386650478 : check e2262386650478 [[],[.under]] .smaller = true := by decide
def e2262386650486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2262386650486 : Closed e2262386650486 ∧ code e2262386650486 = 11058479672694 := by decide
theorem cert_e2262386650486 : check e2262386650486 [[],[.under]] .smaller = true := by decide
def e2262386650542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2262386650542 : Closed e2262386650542 ∧ code e2262386650542 = 11058479672750 := by decide
theorem cert_e2262386650542 : check e2262386650542 [[],[.under]] .smaller = true := by decide
def e2262386650554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2262386650554 : Closed e2262386650554 ∧ code e2262386650554 = 11058479672762 := by decide
theorem cert_e2262386650554 : check e2262386650554 [[],[.under]] .smaller = true := by decide
def e2262386650582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2262386650582 : Closed e2262386650582 ∧ code e2262386650582 = 11058479672790 := by decide
theorem cert_e2262386650582 : check e2262386650582 [[],[.under]] .smaller = true := by decide
def e2262386650586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2262386650586 : Closed e2262386650586 ∧ code e2262386650586 = 11058479672794 := by decide
theorem cert_e2262386650586 : check e2262386650586 [[],[.under]] .smaller = true := by decide
def e2262386650798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2262386650798 : Closed e2262386650798 ∧ code e2262386650798 = 11058479673006 := by decide
theorem cert_e2262386650798 : check e2262386650798 [[],[.under]] .smaller = true := by decide
def e2262386650810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2262386650810 : Closed e2262386650810 ∧ code e2262386650810 = 11058479673018 := by decide
theorem cert_e2262386650810 : check e2262386650810 [[],[.under]] .smaller = true := by decide
def e2262386650858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2262386650858 : Closed e2262386650858 ∧ code e2262386650858 = 11058479673066 := by decide
theorem cert_e2262386650858 : check e2262386650858 [[],[.under]] .smaller = true := by decide
def e2262386650966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2262386650966 : Closed e2262386650966 ∧ code e2262386650966 = 11058479673174 := by decide
theorem cert_e2262386650966 : check e2262386650966 [[],[.under]] .smaller = true := by decide
def e2262386650970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2262386650970 : Closed e2262386650970 ∧ code e2262386650970 = 11058479673178 := by decide
theorem cert_e2262386650970 : check e2262386650970 [[],[.under]] .smaller = true := by decide
def e2262386650986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2262386650986 : Closed e2262386650986 ∧ code e2262386650986 = 11058479673194 := by decide
theorem cert_e2262386650986 : check e2262386650986 [[],[.under]] .smaller = true := by decide
def e2262386652014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2262386652014 : Closed e2262386652014 ∧ code e2262386652014 = 11058479674222 := by decide
theorem cert_e2262386652014 : check e2262386652014 [[],[.under]] .smaller = true := by decide
def e2262386652022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2262386652022 : Closed e2262386652022 ∧ code e2262386652022 = 11058479674230 := by decide
theorem cert_e2262386652022 : check e2262386652022 [[],[.under]] .smaller = true := by decide
def e2262386652078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2262386652078 : Closed e2262386652078 ∧ code e2262386652078 = 11058479674286 := by decide
theorem cert_e2262386652078 : check e2262386652078 [[],[.under]] .smaller = true := by decide
def e2262386652090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2262386652090 : Closed e2262386652090 ∧ code e2262386652090 = 11058479674298 := by decide
theorem cert_e2262386652090 : check e2262386652090 [[],[.under]] .smaller = true := by decide
def e2262386652118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2262386652118 : Closed e2262386652118 ∧ code e2262386652118 = 11058479674326 := by decide
theorem cert_e2262386652118 : check e2262386652118 [[],[.under]] .smaller = true := by decide
def e2262386652122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2262386652122 : Closed e2262386652122 ∧ code e2262386652122 = 11058479674330 := by decide
theorem cert_e2262386652122 : check e2262386652122 [[],[.under]] .smaller = true := by decide
def e2262386652398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262386652398 : Closed e2262386652398 ∧ code e2262386652398 = 11058479674606 := by decide
theorem cert_e2262386652398 : check e2262386652398 [[],[.under]] .smaller = true := by decide
def e2262386652406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262386652406 : Closed e2262386652406 ∧ code e2262386652406 = 11058479674614 := by decide
theorem cert_e2262386652406 : check e2262386652406 [[],[.under]] .smaller = true := by decide
def e2262386652782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262386652782 : Closed e2262386652782 ∧ code e2262386652782 = 11058479674990 := by decide
theorem cert_e2262386652782 : check e2262386652782 [[],[.under]] .smaller = true := by decide
def e2262386652794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262386652794 : Closed e2262386652794 ∧ code e2262386652794 = 11058479675002 := by decide
theorem cert_e2262386652794 : check e2262386652794 [[],[.under]] .smaller = true := by decide
def e2262386652982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262386652982 : Closed e2262386652982 ∧ code e2262386652982 = 11058479675190 := by decide
theorem cert_e2262386652982 : check e2262386652982 [[],[.under]] .smaller = true := by decide
def e2262386652986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262386652986 : Closed e2262386652986 ∧ code e2262386652986 = 11058479675194 := by decide
theorem cert_e2262386652986 : check e2262386652986 [[],[.under]] .smaller = true := by decide
def e2262386653614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2262386653614 : Closed e2262386653614 ∧ code e2262386653614 = 11058479675822 := by decide
theorem cert_e2262386653614 : check e2262386653614 [[],[.under]] .smaller = true := by decide
def e2262386653626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2262386653626 : Closed e2262386653626 ∧ code e2262386653626 = 11058479675834 := by decide
theorem cert_e2262386653626 : check e2262386653626 [[],[.under]] .smaller = true := by decide
def e2262386653674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2262386653674 : Closed e2262386653674 ∧ code e2262386653674 = 11058479675882 := by decide
theorem cert_e2262386653674 : check e2262386653674 [[],[.under]] .smaller = true := by decide
def e2262386653806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262386653806 : Closed e2262386653806 ∧ code e2262386653806 = 11058479676014 := by decide
theorem cert_e2262386653806 : check e2262386653806 [[],[.under]] .smaller = true := by decide
def e2262386653818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262386653818 : Closed e2262386653818 ∧ code e2262386653818 = 11058479676026 := by decide
theorem cert_e2262386653818 : check e2262386653818 [[],[.under]] .smaller = true := by decide
def e2262386654106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262386654106 : Closed e2262386654106 ∧ code e2262386654106 = 11058479676314 := by decide
theorem cert_e2262386654106 : check e2262386654106 [[],[.under]] .smaller = true := by decide
def e2262386654422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2262386654422 : Closed e2262386654422 ∧ code e2262386654422 = 11058479676630 := by decide
theorem cert_e2262386654422 : check e2262386654422 [[],[.under]] .smaller = true := by decide
def e2262386654426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2262386654426 : Closed e2262386654426 ∧ code e2262386654426 = 11058479676634 := by decide
theorem cert_e2262386654426 : check e2262386654426 [[],[.under]] .smaller = true := by decide
def e2262386654442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2262386654442 : Closed e2262386654442 ∧ code e2262386654442 = 11058479676650 := by decide
theorem cert_e2262386654442 : check e2262386654442 [[],[.under]] .smaller = true := by decide
def e2262386654518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262386654518 : Closed e2262386654518 ∧ code e2262386654518 = 11058479676726 := by decide
theorem cert_e2262386654518 : check e2262386654518 [[],[.under]] .smaller = true := by decide
def e2262386654522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262386654522 : Closed e2262386654522 ∧ code e2262386654522 = 11058479676730 := by decide
theorem cert_e2262386654522 : check e2262386654522 [[],[.under]] .smaller = true := by decide
def e2262386654618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262386654618 : Closed e2262386654618 ∧ code e2262386654618 = 11058479676826 := by decide
theorem cert_e2262386654618 : check e2262386654618 [[],[.under]] .smaller = true := by decide
def e2262386656222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2262386656222 : Closed e2262386656222 ∧ code e2262386656222 = 11058479678430 := by decide
theorem cert_e2262386656222 : check e2262386656222 [[],[.under]] .smaller = true := by decide
def e2262386656238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2262386656238 : Closed e2262386656238 ∧ code e2262386656238 = 11058479678446 := by decide
theorem cert_e2262386656238 : check e2262386656238 [[],[.under]] .smaller = true := by decide
def e2262386658158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262386658158 : Closed e2262386658158 ∧ code e2262386658158 = 11058479680366 := by decide
theorem cert_e2262386658158 : check e2262386658158 [[],[.under]] .smaller = true := by decide
def e2262386658166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262386658166 : Closed e2262386658166 ∧ code e2262386658166 = 11058479680374 := by decide
theorem cert_e2262386658166 : check e2262386658166 [[],[.under]] .smaller = true := by decide
def e2262386658222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262386658222 : Closed e2262386658222 ∧ code e2262386658222 = 11058479680430 := by decide
theorem cert_e2262386658222 : check e2262386658222 [[],[.under]] .smaller = true := by decide
def e2262386658234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262386658234 : Closed e2262386658234 ∧ code e2262386658234 = 11058479680442 := by decide
theorem cert_e2262386658234 : check e2262386658234 [[],[.under]] .smaller = true := by decide
def e2262386658262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262386658262 : Closed e2262386658262 ∧ code e2262386658262 = 11058479680470 := by decide
theorem cert_e2262386658262 : check e2262386658262 [[],[.under]] .smaller = true := by decide
def e2262386658266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262386658266 : Closed e2262386658266 ∧ code e2262386658266 = 11058479680474 := by decide
theorem cert_e2262386658266 : check e2262386658266 [[],[.under]] .smaller = true := by decide
def e2262386658542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262386658542 : Closed e2262386658542 ∧ code e2262386658542 = 11058479680750 := by decide
theorem cert_e2262386658542 : check e2262386658542 [[],[.under]] .smaller = true := by decide
def e2262386658550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262386658550 : Closed e2262386658550 ∧ code e2262386658550 = 11058479680758 := by decide
theorem cert_e2262386658550 : check e2262386658550 [[],[.under]] .smaller = true := by decide
def e2262386658926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262386658926 : Closed e2262386658926 ∧ code e2262386658926 = 11058479681134 := by decide
theorem cert_e2262386658926 : check e2262386658926 [[],[.under]] .smaller = true := by decide
def e2262386658938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262386658938 : Closed e2262386658938 ∧ code e2262386658938 = 11058479681146 := by decide
theorem cert_e2262386658938 : check e2262386658938 [[],[.under]] .smaller = true := by decide
def e2262386659126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262386659126 : Closed e2262386659126 ∧ code e2262386659126 = 11058479681334 := by decide
theorem cert_e2262386659126 : check e2262386659126 [[],[.under]] .smaller = true := by decide
def e2262386659130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262386659130 : Closed e2262386659130 ∧ code e2262386659130 = 11058479681338 := by decide
theorem cert_e2262386659130 : check e2262386659130 [[],[.under]] .smaller = true := by decide
def e2262386663902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2262386663902 : Closed e2262386663902 ∧ code e2262386663902 = 11058479686110 := by decide
theorem cert_e2262386663902 : check e2262386663902 [[],[.under]] .smaller = true := by decide
def e2262386663926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2262386663926 : Closed e2262386663926 ∧ code e2262386663926 = 11058479686134 := by decide
theorem cert_e2262386663926 : check e2262386663926 [[],[.under]] .smaller = true := by decide
def e2262386664878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2262386664878 : Closed e2262386664878 ∧ code e2262386664878 = 11058479687086 := by decide
theorem cert_e2262386664878 : check e2262386664878 [[],[.under]] .smaller = true := by decide
def e2262386664890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2262386664890 : Closed e2262386664890 ∧ code e2262386664890 = 11058479687098 := by decide
theorem cert_e2262386664890 : check e2262386664890 [[],[.under]] .smaller = true := by decide
def e2262386664938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2262386664938 : Closed e2262386664938 ∧ code e2262386664938 = 11058479687146 := by decide
theorem cert_e2262386664938 : check e2262386664938 [[],[.under]] .smaller = true := by decide
def e2262386665070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262386665070 : Closed e2262386665070 ∧ code e2262386665070 = 11058479687278 := by decide
theorem cert_e2262386665070 : check e2262386665070 [[],[.under]] .smaller = true := by decide
def e2262386665082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262386665082 : Closed e2262386665082 ∧ code e2262386665082 = 11058479687290 := by decide
theorem cert_e2262386665082 : check e2262386665082 [[],[.under]] .smaller = true := by decide
def e2262386665370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262386665370 : Closed e2262386665370 ∧ code e2262386665370 = 11058479687578 := by decide
theorem cert_e2262386665370 : check e2262386665370 [[],[.under]] .smaller = true := by decide
def e2262386667758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2262386667758 : Closed e2262386667758 ∧ code e2262386667758 = 11058479689966 := by decide
theorem cert_e2262386667758 : check e2262386667758 [[],[.under]] .smaller = true := by decide
def e2262386667766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2262386667766 : Closed e2262386667766 ∧ code e2262386667766 = 11058479689974 := by decide
theorem cert_e2262386667766 : check e2262386667766 [[],[.under]] .smaller = true := by decide
def e2262386668246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2262386668246 : Closed e2262386668246 ∧ code e2262386668246 = 11058479690454 := by decide
theorem cert_e2262386668246 : check e2262386668246 [[],[.under]] .smaller = true := by decide
def e2262386668250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2262386668250 : Closed e2262386668250 ∧ code e2262386668250 = 11058479690458 := by decide
theorem cert_e2262386668250 : check e2262386668250 [[],[.under]] .smaller = true := by decide
def e2262386668266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2262386668266 : Closed e2262386668266 ∧ code e2262386668266 = 11058479690474 := by decide
theorem cert_e2262386668266 : check e2262386668266 [[],[.under]] .smaller = true := by decide
def e2262386668342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262386668342 : Closed e2262386668342 ∧ code e2262386668342 = 11058479690550 := by decide
theorem cert_e2262386668342 : check e2262386668342 [[],[.under]] .smaller = true := by decide
def e2262386668346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262386668346 : Closed e2262386668346 ∧ code e2262386668346 = 11058479690554 := by decide
theorem cert_e2262386668346 : check e2262386668346 [[],[.under]] .smaller = true := by decide
def e2262386668442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262386668442 : Closed e2262386668442 ∧ code e2262386668442 = 11058479690650 := by decide
theorem cert_e2262386668442 : check e2262386668442 [[],[.under]] .smaller = true := by decide
def e2262386782574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2262386782574 : Closed e2262386782574 ∧ code e2262386782574 = 11058479804782 := by decide
theorem cert_e2262386782574 : check e2262386782574 [[],[.under]] .chain = true := by decide
def e2262386782582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2262386782582 : Closed e2262386782582 ∧ code e2262386782582 = 11058479804790 := by decide
theorem cert_e2262386782582 : check e2262386782582 [[],[.under]] .chain = true := by decide
def e2262386783790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262386783790 : Closed e2262386783790 ∧ code e2262386783790 = 11058479805998 := by decide
theorem cert_e2262386783790 : check e2262386783790 [[],[.under]] .chain = true := by decide
def e2262386783970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262386783970 : Closed e2262386783970 ∧ code e2262386783970 = 11058479806178 := by decide
theorem cert_e2262386783970 : check e2262386783970 [[],[.under]] .chain = true := by decide
def e2262386783982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2262386783982 : Closed e2262386783982 ∧ code e2262386783982 = 11058479806190 := by decide
theorem cert_e2262386783982 : check e2262386783982 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386784022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262386784022 : Closed e2262386784022 ∧ code e2262386784022 = 11058479806230 := by decide
theorem cert_e2262386784022 : check e2262386784022 [[],[.under]] .chain = true := by decide
def e2262386784098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262386784098 : Closed e2262386784098 ∧ code e2262386784098 = 11058479806306 := by decide
theorem cert_e2262386784098 : check e2262386784098 [[],[.under]] .chain = true := by decide
def e2262386784110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2262386784110 : Closed e2262386784110 ∧ code e2262386784110 = 11058479806318 := by decide
theorem cert_e2262386784110 : check e2262386784110 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262386784118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2262386784118 : Closed e2262386784118 ∧ code e2262386784118 = 11058479806326 := by decide
theorem cert_e2262386784118 : check e2262386784118 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386784430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2262386784430 : Closed e2262386784430 ∧ code e2262386784430 = 11058479806638 := by decide
theorem cert_e2262386784430 : check e2262386784430 [[],[.under]] .chain = true := by decide
def e2262386784442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2262386784442 : Closed e2262386784442 ∧ code e2262386784442 = 11058479806650 := by decide
theorem cert_e2262386784442 : check e2262386784442 [[],[.under]] .chain = true := by decide
def e2262386784814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262386784814 : Closed e2262386784814 ∧ code e2262386784814 = 11058479807022 := by decide
theorem cert_e2262386784814 : check e2262386784814 [[],[.under]] .chain = true := by decide
def e2262386784994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262386784994 : Closed e2262386784994 ∧ code e2262386784994 = 11058479807202 := by decide
theorem cert_e2262386784994 : check e2262386784994 [[],[.under]] .chain = true := by decide
def e2262386785006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2262386785006 : Closed e2262386785006 ∧ code e2262386785006 = 11058479807214 := by decide
theorem cert_e2262386785006 : check e2262386785006 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386785162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262386785162 : Closed e2262386785162 ∧ code e2262386785162 = 11058479807370 := by decide
theorem cert_e2262386785162 : check e2262386785162 [[],[.under]] .chain = true := by decide
def e2262386785186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262386785186 : Closed e2262386785186 ∧ code e2262386785186 = 11058479807394 := by decide
theorem cert_e2262386785186 : check e2262386785186 [[],[.under]] .chain = true := by decide
def e2262386785198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2262386785198 : Closed e2262386785198 ∧ code e2262386785198 = 11058479807406 := by decide
theorem cert_e2262386785198 : check e2262386785198 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2262386785210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2262386785210 : Closed e2262386785210 ∧ code e2262386785210 = 11058479807418 := by decide
theorem cert_e2262386785210 : check e2262386785210 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386785366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2262386785366 : Closed e2262386785366 ∧ code e2262386785366 = 11058479807574 := by decide
theorem cert_e2262386785366 : check e2262386785366 [[],[.under]] .chain = true := by decide
def e2262386785370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2262386785370 : Closed e2262386785370 ∧ code e2262386785370 = 11058479807578 := by decide
theorem cert_e2262386785370 : check e2262386785370 [[],[.under]] .chain = true := by decide
def e2262386785558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262386785558 : Closed e2262386785558 ∧ code e2262386785558 = 11058479807766 := by decide
theorem cert_e2262386785558 : check e2262386785558 [[],[.under]] .chain = true := by decide
def e2262386785634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262386785634 : Closed e2262386785634 ∧ code e2262386785634 = 11058479807842 := by decide
theorem cert_e2262386785634 : check e2262386785634 [[],[.under]] .chain = true := by decide
def e2262386785646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2262386785646 : Closed e2262386785646 ∧ code e2262386785646 = 11058479807854 := by decide
theorem cert_e2262386785646 : check e2262386785646 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386785654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2262386785654 : Closed e2262386785654 ∧ code e2262386785654 = 11058479807862 := by decide
theorem cert_e2262386785654 : check e2262386785654 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386785674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262386785674 : Closed e2262386785674 ∧ code e2262386785674 = 11058479807882 := by decide
theorem cert_e2262386785674 : check e2262386785674 [[],[.under]] .chain = true := by decide
def e2262386785698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262386785698 : Closed e2262386785698 ∧ code e2262386785698 = 11058479807906 := by decide
theorem cert_e2262386785698 : check e2262386785698 [[],[.under]] .chain = true := by decide
def e2262386785710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2262386785710 : Closed e2262386785710 ∧ code e2262386785710 = 11058479807918 := by decide
theorem cert_e2262386785710 : check e2262386785710 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386785722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2262386785722 : Closed e2262386785722 ∧ code e2262386785722 = 11058479807930 := by decide
theorem cert_e2262386785722 : check e2262386785722 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2262386785750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2262386785750 : Closed e2262386785750 ∧ code e2262386785750 = 11058479807958 := by decide
theorem cert_e2262386785750 : check e2262386785750 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2262386785754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2262386785754 : Closed e2262386785754 ∧ code e2262386785754 = 11058479807962 := by decide
def e2262386786798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2262386786798 : Closed e2262386786798 ∧ code e2262386786798 = 11058479809006 := by decide
theorem cert_e2262386786798 : check e2262386786798 [[],[.under]] .chain = true := by decide
def e2262386786806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2262386786806 : Closed e2262386786806 ∧ code e2262386786806 = 11058479809014 := by decide
theorem cert_e2262386786806 : check e2262386786806 [[],[.under]] .chain = true := by decide
def e2262386787566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2262386787566 : Closed e2262386787566 ∧ code e2262386787566 = 11058479809774 := by decide
theorem cert_e2262386787566 : check e2262386787566 [[],[.under]] .chain = true := by decide
def e2262386787574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2262386787574 : Closed e2262386787574 ∧ code e2262386787574 = 11058479809782 := by decide
theorem cert_e2262386787574 : check e2262386787574 [[],[.under]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262386105270
#print axioms Blc.Floor43.cert_e2262386106038
#print axioms Blc.Floor43.cert_e2262386281326
#print axioms Blc.Floor43.cert_e2262386281334
#print axioms Blc.Floor43.cert_e2262386281390
#print axioms Blc.Floor43.cert_e2262386281402
#print axioms Blc.Floor43.cert_e2262386281430
#print axioms Blc.Floor43.cert_e2262386281434
#print axioms Blc.Floor43.cert_e2262386281710
#print axioms Blc.Floor43.cert_e2262386281718
#print axioms Blc.Floor43.cert_e2262386282094
#print axioms Blc.Floor43.cert_e2262386282106
#print axioms Blc.Floor43.cert_e2262386282294
#print axioms Blc.Floor43.cert_e2262386282298
