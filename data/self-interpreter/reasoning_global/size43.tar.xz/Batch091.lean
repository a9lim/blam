import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e827600190778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e827600190778 : Closed e827600190778 ∧ code e827600190778 = 9623693212986 := by decide
theorem cert_e827600190778 : check e827600190778 [] .sourceHead = true := by decide
def e827600190874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e827600190874 : Closed e827600190874 ∧ code e827600190874 = 9623693213082 := by decide
theorem cert_e827600190874 : check e827600190874 [] .sourceHead = true := by decide
def e827600194414 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e827600194414 : Closed e827600194414 ∧ code e827600194414 = 9623693216622 := by decide
theorem cert_e827600194414 : check e827600194414 [] .sourceHead = true := by decide
def e827600194422 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e827600194422 : Closed e827600194422 ∧ code e827600194422 = 9623693216630 := by decide
theorem cert_e827600194422 : check e827600194422 [] .sourceHead = true := by decide
def e827600194478 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e827600194478 : Closed e827600194478 ∧ code e827600194478 = 9623693216686 := by decide
theorem cert_e827600194478 : check e827600194478 [] .sourceHead = true := by decide
def e827600194490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e827600194490 : Closed e827600194490 ∧ code e827600194490 = 9623693216698 := by decide
theorem cert_e827600194490 : check e827600194490 [] .sourceHead = true := by decide
def e827600194518 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e827600194518 : Closed e827600194518 ∧ code e827600194518 = 9623693216726 := by decide
theorem cert_e827600194518 : check e827600194518 [] .sourceHead = true := by decide
def e827600194522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e827600194522 : Closed e827600194522 ∧ code e827600194522 = 9623693216730 := by decide
theorem cert_e827600194522 : check e827600194522 [] .sourceHead = true := by decide
def e827600194798 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e827600194798 : Closed e827600194798 ∧ code e827600194798 = 9623693217006 := by decide
theorem cert_e827600194798 : check e827600194798 [] .sourceHead = true := by decide
def e827600194806 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e827600194806 : Closed e827600194806 ∧ code e827600194806 = 9623693217014 := by decide
theorem cert_e827600194806 : check e827600194806 [] .sourceHead = true := by decide
def e827600195182 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e827600195182 : Closed e827600195182 ∧ code e827600195182 = 9623693217390 := by decide
theorem cert_e827600195182 : check e827600195182 [] .sourceHead = true := by decide
def e827600195194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e827600195194 : Closed e827600195194 ∧ code e827600195194 = 9623693217402 := by decide
theorem cert_e827600195194 : check e827600195194 [] .sourceHead = true := by decide
def e827600195382 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e827600195382 : Closed e827600195382 ∧ code e827600195382 = 9623693217590 := by decide
theorem cert_e827600195382 : check e827600195382 [] .sourceHead = true := by decide
def e827600195386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e827600195386 : Closed e827600195386 ∧ code e827600195386 = 9623693217594 := by decide
theorem cert_e827600195386 : check e827600195386 [] .sourceHead = true := by decide
def e827600201134 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e827600201134 : Closed e827600201134 ∧ code e827600201134 = 9623693223342 := by decide
theorem cert_e827600201134 : check e827600201134 [] .sourceHead = true := by decide
def e827600201146 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e827600201146 : Closed e827600201146 ∧ code e827600201146 = 9623693223354 := by decide
theorem cert_e827600201146 : check e827600201146 [] .sourceHead = true := by decide
def e827600201194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e827600201194 : Closed e827600201194 ∧ code e827600201194 = 9623693223402 := by decide
theorem cert_e827600201194 : check e827600201194 [] .sourceHead = true := by decide
def e827600201326 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e827600201326 : Closed e827600201326 ∧ code e827600201326 = 9623693223534 := by decide
theorem cert_e827600201326 : check e827600201326 [] .sourceHead = true := by decide
def e827600201338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e827600201338 : Closed e827600201338 ∧ code e827600201338 = 9623693223546 := by decide
theorem cert_e827600201338 : check e827600201338 [] .sourceHead = true := by decide
def e827600201626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e827600201626 : Closed e827600201626 ∧ code e827600201626 = 9623693223834 := by decide
theorem cert_e827600201626 : check e827600201626 [] .sourceHead = true := by decide
def e827600204502 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e827600204502 : Closed e827600204502 ∧ code e827600204502 = 9623693226710 := by decide
theorem cert_e827600204502 : check e827600204502 [] .sourceHead = true := by decide
def e827600204506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e827600204506 : Closed e827600204506 ∧ code e827600204506 = 9623693226714 := by decide
theorem cert_e827600204506 : check e827600204506 [] .sourceHead = true := by decide
def e827600204522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e827600204522 : Closed e827600204522 ∧ code e827600204522 = 9623693226730 := by decide
theorem cert_e827600204522 : check e827600204522 [] .sourceHead = true := by decide
def e827600204598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e827600204598 : Closed e827600204598 ∧ code e827600204598 = 9623693226806 := by decide
theorem cert_e827600204598 : check e827600204598 [] .sourceHead = true := by decide
def e827600204602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e827600204602 : Closed e827600204602 ∧ code e827600204602 = 9623693226810 := by decide
theorem cert_e827600204602 : check e827600204602 [] .sourceHead = true := by decide
def e827600204698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e827600204698 : Closed e827600204698 ∧ code e827600204698 = 9623693226906 := by decide
theorem cert_e827600204698 : check e827600204698 [] .sourceHead = true := by decide
def e827601563162 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827601563162 : Closed e827601563162 ∧ code e827601563162 = 9623694585370 := by decide
theorem cert_e827601563162 : check e827601563162 [] .sourceHead = true := by decide
def e827601566234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827601566234 : Closed e827601566234 ∧ code e827601566234 = 9623694588442 := by decide
theorem cert_e827601566234 : check e827601566234 [] .sourceHead = true := by decide
def e827601578522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827601578522 : Closed e827601578522 ∧ code e827601578522 = 9623694600730 := by decide
theorem cert_e827601578522 : check e827601578522 [] .sourceHead = true := by decide
def e827601612314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827601612314 : Closed e827601612314 ∧ code e827601612314 = 9623694634522 := by decide
theorem cert_e827601612314 : check e827601612314 [] .sourceHead = true := by decide
def e827601615386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827601615386 : Closed e827601615386 ∧ code e827601615386 = 9623694637594 := by decide
theorem cert_e827601615386 : check e827601615386 [] .sourceHead = true := by decide
def e827601689114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827601689114 : Closed e827601689114 ∧ code e827601689114 = 9623694711322 := by decide
theorem cert_e827601689114 : check e827601689114 [] .sourceHead = true := by decide
def e827602425370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827602425370 : Closed e827602425370 ∧ code e827602425370 = 9623695447578 := by decide
theorem cert_e827602425370 : check e827602425370 [] .sourceHead = true := by decide
def e827602426394 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827602426394 : Closed e827602426394 ∧ code e827602426394 = 9623695448602 := by decide
theorem cert_e827602426394 : check e827602426394 [] .sourceHead = true := by decide
def e827602430490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827602430490 : Closed e827602430490 ∧ code e827602430490 = 9623695452698 := by decide
theorem cert_e827602430490 : check e827602430490 [] .sourceHead = true := by decide
def e827602449946 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827602449946 : Closed e827602449946 ∧ code e827602449946 = 9623695472154 := by decide
theorem cert_e827602449946 : check e827602449946 [] .sourceHead = true := by decide
def e827602450970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827602450970 : Closed e827602450970 ∧ code e827602450970 = 9623695473178 := by decide
theorem cert_e827602450970 : check e827602450970 [] .sourceHead = true := by decide
def e827602475546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827602475546 : Closed e827602475546 ∧ code e827602475546 = 9623695497754 := by decide
theorem cert_e827602475546 : check e827602475546 [] .sourceHead = true := by decide
def e828002839918 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e828002839918 : Closed e828002839918 ∧ code e828002839918 = 9624095862126 := by decide
theorem cert_e828002839918 : check e828002839918 [] .sourceHead = true := by decide
def e828002839926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e828002839926 : Closed e828002839926 ∧ code e828002839926 = 9624095862134 := by decide
theorem cert_e828002839926 : check e828002839926 [] .sourceHead = true := by decide
def e828002839982 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e828002839982 : Closed e828002839982 ∧ code e828002839982 = 9624095862190 := by decide
theorem cert_e828002839982 : check e828002839982 [] .sourceHead = true := by decide
def e828002839994 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e828002839994 : Closed e828002839994 ∧ code e828002839994 = 9624095862202 := by decide
theorem cert_e828002839994 : check e828002839994 [] .sourceHead = true := by decide
def e828002840022 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e828002840022 : Closed e828002840022 ∧ code e828002840022 = 9624095862230 := by decide
theorem cert_e828002840022 : check e828002840022 [] .sourceHead = true := by decide
def e828002840026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e828002840026 : Closed e828002840026 ∧ code e828002840026 = 9624095862234 := by decide
theorem cert_e828002840026 : check e828002840026 [] .sourceHead = true := by decide
def e828002840238 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e828002840238 : Closed e828002840238 ∧ code e828002840238 = 9624095862446 := by decide
theorem cert_e828002840238 : check e828002840238 [] .sourceHead = true := by decide
def e828002840250 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e828002840250 : Closed e828002840250 ∧ code e828002840250 = 9624095862458 := by decide
theorem cert_e828002840250 : check e828002840250 [] .sourceHead = true := by decide
def e828002840298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e828002840298 : Closed e828002840298 ∧ code e828002840298 = 9624095862506 := by decide
theorem cert_e828002840298 : check e828002840298 [] .sourceHead = true := by decide
def e828002840406 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e828002840406 : Closed e828002840406 ∧ code e828002840406 = 9624095862614 := by decide
theorem cert_e828002840406 : check e828002840406 [] .sourceHead = true := by decide
def e828002840410 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e828002840410 : Closed e828002840410 ∧ code e828002840410 = 9624095862618 := by decide
theorem cert_e828002840410 : check e828002840410 [] .sourceHead = true := by decide
def e828002840426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e828002840426 : Closed e828002840426 ∧ code e828002840426 = 9624095862634 := by decide
theorem cert_e828002840426 : check e828002840426 [] .sourceHead = true := by decide
def e828002841454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e828002841454 : Closed e828002841454 ∧ code e828002841454 = 9624095863662 := by decide
theorem cert_e828002841454 : check e828002841454 [] .sourceHead = true := by decide
def e828002841462 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e828002841462 : Closed e828002841462 ∧ code e828002841462 = 9624095863670 := by decide
theorem cert_e828002841462 : check e828002841462 [] .sourceHead = true := by decide
def e828002841518 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e828002841518 : Closed e828002841518 ∧ code e828002841518 = 9624095863726 := by decide
theorem cert_e828002841518 : check e828002841518 [] .sourceHead = true := by decide
def e828002841530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e828002841530 : Closed e828002841530 ∧ code e828002841530 = 9624095863738 := by decide
theorem cert_e828002841530 : check e828002841530 [] .sourceHead = true := by decide
def e828002841558 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e828002841558 : Closed e828002841558 ∧ code e828002841558 = 9624095863766 := by decide
theorem cert_e828002841558 : check e828002841558 [] .sourceHead = true := by decide
def e828002841562 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e828002841562 : Closed e828002841562 ∧ code e828002841562 = 9624095863770 := by decide
theorem cert_e828002841562 : check e828002841562 [] .sourceHead = true := by decide
def e828002841838 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e828002841838 : Closed e828002841838 ∧ code e828002841838 = 9624095864046 := by decide
theorem cert_e828002841838 : check e828002841838 [] .sourceHead = true := by decide
def e828002841846 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e828002841846 : Closed e828002841846 ∧ code e828002841846 = 9624095864054 := by decide
theorem cert_e828002841846 : check e828002841846 [] .sourceHead = true := by decide
def e828002842222 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e828002842222 : Closed e828002842222 ∧ code e828002842222 = 9624095864430 := by decide
theorem cert_e828002842222 : check e828002842222 [] .sourceHead = true := by decide
def e828002842234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e828002842234 : Closed e828002842234 ∧ code e828002842234 = 9624095864442 := by decide
theorem cert_e828002842234 : check e828002842234 [] .sourceHead = true := by decide
def e828002842422 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e828002842422 : Closed e828002842422 ∧ code e828002842422 = 9624095864630 := by decide
theorem cert_e828002842422 : check e828002842422 [] .sourceHead = true := by decide
def e828002842426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e828002842426 : Closed e828002842426 ∧ code e828002842426 = 9624095864634 := by decide
theorem cert_e828002842426 : check e828002842426 [] .sourceHead = true := by decide
def e828002843054 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e828002843054 : Closed e828002843054 ∧ code e828002843054 = 9624095865262 := by decide
theorem cert_e828002843054 : check e828002843054 [] .sourceHead = true := by decide
def e828002843066 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e828002843066 : Closed e828002843066 ∧ code e828002843066 = 9624095865274 := by decide
theorem cert_e828002843066 : check e828002843066 [] .sourceHead = true := by decide
def e828002843114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e828002843114 : Closed e828002843114 ∧ code e828002843114 = 9624095865322 := by decide
theorem cert_e828002843114 : check e828002843114 [] .sourceHead = true := by decide
def e828002843246 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e828002843246 : Closed e828002843246 ∧ code e828002843246 = 9624095865454 := by decide
theorem cert_e828002843246 : check e828002843246 [] .sourceHead = true := by decide
def e828002843258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e828002843258 : Closed e828002843258 ∧ code e828002843258 = 9624095865466 := by decide
theorem cert_e828002843258 : check e828002843258 [] .sourceHead = true := by decide
def e828002843546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e828002843546 : Closed e828002843546 ∧ code e828002843546 = 9624095865754 := by decide
theorem cert_e828002843546 : check e828002843546 [] .sourceHead = true := by decide
def e828002843862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e828002843862 : Closed e828002843862 ∧ code e828002843862 = 9624095866070 := by decide
theorem cert_e828002843862 : check e828002843862 [] .sourceHead = true := by decide
def e828002843866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e828002843866 : Closed e828002843866 ∧ code e828002843866 = 9624095866074 := by decide
theorem cert_e828002843866 : check e828002843866 [] .sourceHead = true := by decide
def e828002843882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e828002843882 : Closed e828002843882 ∧ code e828002843882 = 9624095866090 := by decide
theorem cert_e828002843882 : check e828002843882 [] .sourceHead = true := by decide
def e828002843958 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e828002843958 : Closed e828002843958 ∧ code e828002843958 = 9624095866166 := by decide
theorem cert_e828002843958 : check e828002843958 [] .sourceHead = true := by decide
def e828002843962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e828002843962 : Closed e828002843962 ∧ code e828002843962 = 9624095866170 := by decide
theorem cert_e828002843962 : check e828002843962 [] .sourceHead = true := by decide
def e828002844058 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e828002844058 : Closed e828002844058 ∧ code e828002844058 = 9624095866266 := by decide
theorem cert_e828002844058 : check e828002844058 [] .sourceHead = true := by decide
def e828002847598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e828002847598 : Closed e828002847598 ∧ code e828002847598 = 9624095869806 := by decide
theorem cert_e828002847598 : check e828002847598 [] .sourceHead = true := by decide
def e828002847606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e828002847606 : Closed e828002847606 ∧ code e828002847606 = 9624095869814 := by decide
theorem cert_e828002847606 : check e828002847606 [] .sourceHead = true := by decide
def e828002847662 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e828002847662 : Closed e828002847662 ∧ code e828002847662 = 9624095869870 := by decide
theorem cert_e828002847662 : check e828002847662 [] .sourceHead = true := by decide
def e828002847674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e828002847674 : Closed e828002847674 ∧ code e828002847674 = 9624095869882 := by decide
theorem cert_e828002847674 : check e828002847674 [] .sourceHead = true := by decide
def e828002847702 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e828002847702 : Closed e828002847702 ∧ code e828002847702 = 9624095869910 := by decide
theorem cert_e828002847702 : check e828002847702 [] .sourceHead = true := by decide
def e828002847706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e828002847706 : Closed e828002847706 ∧ code e828002847706 = 9624095869914 := by decide
theorem cert_e828002847706 : check e828002847706 [] .sourceHead = true := by decide
def e828002847982 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e828002847982 : Closed e828002847982 ∧ code e828002847982 = 9624095870190 := by decide
theorem cert_e828002847982 : check e828002847982 [] .sourceHead = true := by decide
def e828002847990 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e828002847990 : Closed e828002847990 ∧ code e828002847990 = 9624095870198 := by decide
theorem cert_e828002847990 : check e828002847990 [] .sourceHead = true := by decide
def e828002848366 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e828002848366 : Closed e828002848366 ∧ code e828002848366 = 9624095870574 := by decide
theorem cert_e828002848366 : check e828002848366 [] .sourceHead = true := by decide
def e828002848378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e828002848378 : Closed e828002848378 ∧ code e828002848378 = 9624095870586 := by decide
theorem cert_e828002848378 : check e828002848378 [] .sourceHead = true := by decide
def e828002848566 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e828002848566 : Closed e828002848566 ∧ code e828002848566 = 9624095870774 := by decide
theorem cert_e828002848566 : check e828002848566 [] .sourceHead = true := by decide
def e828002848570 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e828002848570 : Closed e828002848570 ∧ code e828002848570 = 9624095870778 := by decide
theorem cert_e828002848570 : check e828002848570 [] .sourceHead = true := by decide
def e828002854318 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e828002854318 : Closed e828002854318 ∧ code e828002854318 = 9624095876526 := by decide
theorem cert_e828002854318 : check e828002854318 [] .sourceHead = true := by decide
def e828002854330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e828002854330 : Closed e828002854330 ∧ code e828002854330 = 9624095876538 := by decide
theorem cert_e828002854330 : check e828002854330 [] .sourceHead = true := by decide
def e828002854378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e828002854378 : Closed e828002854378 ∧ code e828002854378 = 9624095876586 := by decide
theorem cert_e828002854378 : check e828002854378 [] .sourceHead = true := by decide
def e828002854510 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e828002854510 : Closed e828002854510 ∧ code e828002854510 = 9624095876718 := by decide
theorem cert_e828002854510 : check e828002854510 [] .sourceHead = true := by decide
def e828002854522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e828002854522 : Closed e828002854522 ∧ code e828002854522 = 9624095876730 := by decide
theorem cert_e828002854522 : check e828002854522 [] .sourceHead = true := by decide
def e828002854810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e828002854810 : Closed e828002854810 ∧ code e828002854810 = 9624095877018 := by decide
theorem cert_e828002854810 : check e828002854810 [] .sourceHead = true := by decide
def e828002857686 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e828002857686 : Closed e828002857686 ∧ code e828002857686 = 9624095879894 := by decide
theorem cert_e828002857686 : check e828002857686 [] .sourceHead = true := by decide
def e828002857690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e828002857690 : Closed e828002857690 ∧ code e828002857690 = 9624095879898 := by decide
theorem cert_e828002857690 : check e828002857690 [] .sourceHead = true := by decide
def e828002857706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e828002857706 : Closed e828002857706 ∧ code e828002857706 = 9624095879914 := by decide
theorem cert_e828002857706 : check e828002857706 [] .sourceHead = true := by decide
def e828002857782 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e828002857782 : Closed e828002857782 ∧ code e828002857782 = 9624095879990 := by decide
theorem cert_e828002857782 : check e828002857782 [] .sourceHead = true := by decide
def e828002857786 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e828002857786 : Closed e828002857786 ∧ code e828002857786 = 9624095879994 := by decide
theorem cert_e828002857786 : check e828002857786 [] .sourceHead = true := by decide
def e828002857882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e828002857882 : Closed e828002857882 ∧ code e828002857882 = 9624095880090 := by decide
theorem cert_e828002857882 : check e828002857882 [] .sourceHead = true := by decide
def e833405808838 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833405808838 : Closed e833405808838 ∧ code e833405808838 = 9629498831046 := by decide
theorem cert_e833405808838 : check e833405808838 [] .sourceHead = true := by decide
def e833405825222 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833405825222 : Closed e833405825222 ∧ code e833405825222 = 9629498847430 := by decide
theorem cert_e833405825222 : check e833405825222 [] .sourceHead = true := by decide
def e833405956294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833405956294 : Closed e833405956294 ∧ code e833405956294 = 9629498978502 := by decide
theorem cert_e833405956294 : check e833405956294 [] .sourceHead = true := by decide
def e833406857414 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833406857414 : Closed e833406857414 ∧ code e833406857414 = 9629499879622 := by decide
theorem cert_e833406857414 : check e833406857414 [] .sourceHead = true := by decide
def e833406873798 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833406873798 : Closed e833406873798 ∧ code e833406873798 = 9629499896006 := by decide
theorem cert_e833406873798 : check e833406873798 [] .sourceHead = true := by decide
def e833406988486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833406988486 : Closed e833406988486 ∧ code e833406988486 = 9629500010694 := by decide
theorem cert_e833406988486 : check e833406988486 [] .sourceHead = true := by decide
def e833407013062 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833407013062 : Closed e833407013062 ∧ code e833407013062 = 9629500035270 := by decide
theorem cert_e833407013062 : check e833407013062 [] .sourceHead = true := by decide
def e833407070406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833407070406 : Closed e833407070406 ∧ code e833407070406 = 9629500092614 := by decide
theorem cert_e833407070406 : check e833407070406 [] .sourceHead = true := by decide
def e833407078598 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833407078598 : Closed e833407078598 ∧ code e833407078598 = 9629500100806 := by decide
theorem cert_e833407078598 : check e833407078598 [] .sourceHead = true := by decide
def e833407529158 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833407529158 : Closed e833407529158 ∧ code e833407529158 = 9629500551366 := by decide
theorem cert_e833407529158 : check e833407529158 [] .sourceHead = true := by decide
def e833407594694 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833407594694 : Closed e833407594694 ∧ code e833407594694 = 9629500616902 := by decide
theorem cert_e833407594694 : check e833407594694 [] .sourceHead = true := by decide
def e833407602886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833407602886 : Closed e833407602886 ∧ code e833407602886 = 9629500625094 := by decide
theorem cert_e833407602886 : check e833407602886 [] .sourceHead = true := by decide
def e833412100294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833412100294 : Closed e833412100294 ∧ code e833412100294 = 9629505122502 := by decide
theorem cert_e833412100294 : check e833412100294 [] .sourceHead = true := by decide
def e833412116678 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833412116678 : Closed e833412116678 ∧ code e833412116678 = 9629505138886 := by decide
theorem cert_e833412116678 : check e833412116678 [] .sourceHead = true := by decide
def e833412247750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833412247750 : Closed e833412247750 ∧ code e833412247750 = 9629505269958 := by decide
theorem cert_e833412247750 : check e833412247750 [] .sourceHead = true := by decide
def e833414983878 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833414983878 : Closed e833414983878 ∧ code e833414983878 = 9629508006086 := by decide
theorem cert_e833414983878 : check e833414983878 [] .sourceHead = true := by decide
def e833415000262 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833415000262 : Closed e833415000262 ∧ code e833415000262 = 9629508022470 := by decide
theorem cert_e833415000262 : check e833415000262 [] .sourceHead = true := by decide
def e833415786694 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833415786694 : Closed e833415786694 ∧ code e833415786694 = 9629508808902 := by decide
theorem cert_e833415786694 : check e833415786694 [] .sourceHead = true := by decide
def e833418391750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833418391750 : Closed e833418391750 ∧ code e833418391750 = 9629511413958 := by decide
theorem cert_e833418391750 : check e833418391750 [] .sourceHead = true := by decide
def e833418408134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833418408134 : Closed e833418408134 ∧ code e833418408134 = 9629511430342 := by decide
theorem cert_e833418408134 : check e833418408134 [] .sourceHead = true := by decide
def e833418522822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833418522822 : Closed e833418522822 ∧ code e833418522822 = 9629511545030 := by decide
theorem cert_e833418522822 : check e833418522822 [] .sourceHead = true := by decide
def e833418547398 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833418547398 : Closed e833418547398 ∧ code e833418547398 = 9629511569606 := by decide
theorem cert_e833418547398 : check e833418547398 [] .sourceHead = true := by decide
def e833418604742 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833418604742 : Closed e833418604742 ∧ code e833418604742 = 9629511626950 := by decide
theorem cert_e833418604742 : check e833418604742 [] .sourceHead = true := by decide
def e833418612934 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833418612934 : Closed e833418612934 ∧ code e833418612934 = 9629511635142 := by decide
theorem cert_e833418612934 : check e833418612934 [] .sourceHead = true := by decide
def e833419178182 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833419178182 : Closed e833419178182 ∧ code e833419178182 = 9629512200390 := by decide
theorem cert_e833419178182 : check e833419178182 [] .sourceHead = true := by decide
def e833419194566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833419194566 : Closed e833419194566 ∧ code e833419194566 = 9629512216774 := by decide
theorem cert_e833419194566 : check e833419194566 [] .sourceHead = true := by decide
def e833419964614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833419964614 : Closed e833419964614 ∧ code e833419964614 = 9629512986822 := by decide
theorem cert_e833419964614 : check e833419964614 [] .sourceHead = true := by decide
def e833419989190 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833419989190 : Closed e833419989190 ∧ code e833419989190 = 9629513011398 := by decide
theorem cert_e833419989190 : check e833419989190 [] .sourceHead = true := by decide
def e833420374214 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833420374214 : Closed e833420374214 ∧ code e833420374214 = 9629513396422 := by decide
theorem cert_e833420374214 : check e833420374214 [] .sourceHead = true := by decide
def e833420382406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833420382406 : Closed e833420382406 ∧ code e833420382406 = 9629513404614 := by decide
theorem cert_e833420382406 : check e833420382406 [] .sourceHead = true := by decide
def e833421684934 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833421684934 : Closed e833421684934 ∧ code e833421684934 = 9629514707142 := by decide
theorem cert_e833421684934 : check e833421684934 [] .sourceHead = true := by decide
def e833421750470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833421750470 : Closed e833421750470 ∧ code e833421750470 = 9629514772678 := by decide
theorem cert_e833421750470 : check e833421750470 [] .sourceHead = true := by decide
def e833421758662 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833421758662 : Closed e833421758662 ∧ code e833421758662 = 9629514780870 := by decide
theorem cert_e833421758662 : check e833421758662 [] .sourceHead = true := by decide
def e833422078150 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833422078150 : Closed e833422078150 ∧ code e833422078150 = 9629515100358 := by decide
theorem cert_e833422078150 : check e833422078150 [] .sourceHead = true := by decide
def e833422471366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833422471366 : Closed e833422471366 ∧ code e833422471366 = 9629515493574 := by decide
theorem cert_e833422471366 : check e833422471366 [] .sourceHead = true := by decide
def e833422479558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833422479558 : Closed e833422479558 ∧ code e833422479558 = 9629515501766 := by decide
theorem cert_e833422479558 : check e833422479558 [] .sourceHead = true := by decide
def e833437266118 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833437266118 : Closed e833437266118 ∧ code e833437266118 = 9629530288326 := by decide
theorem cert_e833437266118 : check e833437266118 [] .sourceHead = true := by decide
def e833437282502 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833437282502 : Closed e833437282502 ∧ code e833437282502 = 9629530304710 := by decide
theorem cert_e833437282502 : check e833437282502 [] .sourceHead = true := by decide
def e833437413574 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833437413574 : Closed e833437413574 ∧ code e833437413574 = 9629530435782 := by decide
theorem cert_e833437413574 : check e833437413574 [] .sourceHead = true := by decide
def e833440149702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833440149702 : Closed e833440149702 ∧ code e833440149702 = 9629533171910 := by decide
theorem cert_e833440149702 : check e833440149702 [] .sourceHead = true := by decide
def e833440166086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833440166086 : Closed e833440166086 ∧ code e833440166086 = 9629533188294 := by decide
theorem cert_e833440166086 : check e833440166086 [] .sourceHead = true := by decide
def e833440952518 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833440952518 : Closed e833440952518 ∧ code e833440952518 = 9629533974726 := by decide
theorem cert_e833440952518 : check e833440952518 [] .sourceHead = true := by decide
def e833464529094 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833464529094 : Closed e833464529094 ∧ code e833464529094 = 9629557551302 := by decide
theorem cert_e833464529094 : check e833464529094 [] .sourceHead = true := by decide
def e833464545478 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833464545478 : Closed e833464545478 ∧ code e833464545478 = 9629557567686 := by decide
theorem cert_e833464545478 : check e833464545478 [] .sourceHead = true := by decide
def e833464660166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833464660166 : Closed e833464660166 ∧ code e833464660166 = 9629557682374 := by decide
theorem cert_e833464660166 : check e833464660166 [] .sourceHead = true := by decide
def e833464684742 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833464684742 : Closed e833464684742 ∧ code e833464684742 = 9629557706950 := by decide
theorem cert_e833464684742 : check e833464684742 [] .sourceHead = true := by decide
def e833464742086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833464742086 : Closed e833464742086 ∧ code e833464742086 = 9629557764294 := by decide
theorem cert_e833464742086 : check e833464742086 [] .sourceHead = true := by decide
def e833464750278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833464750278 : Closed e833464750278 ∧ code e833464750278 = 9629557772486 := by decide
theorem cert_e833464750278 : check e833464750278 [] .sourceHead = true := by decide
def e833465315526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833465315526 : Closed e833465315526 ∧ code e833465315526 = 9629558337734 := by decide
theorem cert_e833465315526 : check e833465315526 [] .sourceHead = true := by decide
def e833465331910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833465331910 : Closed e833465331910 ∧ code e833465331910 = 9629558354118 := by decide
theorem cert_e833465331910 : check e833465331910 [] .sourceHead = true := by decide
def e833466101958 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833466101958 : Closed e833466101958 ∧ code e833466101958 = 9629559124166 := by decide
theorem cert_e833466101958 : check e833466101958 [] .sourceHead = true := by decide
def e833466126534 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833466126534 : Closed e833466126534 ∧ code e833466126534 = 9629559148742 := by decide
theorem cert_e833466126534 : check e833466126534 [] .sourceHead = true := by decide
def e833466511558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833466511558 : Closed e833466511558 ∧ code e833466511558 = 9629559533766 := by decide
theorem cert_e833466511558 : check e833466511558 [] .sourceHead = true := by decide
def e833466519750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e833466519750 : Closed e833466519750 ∧ code e833466519750 = 9629559541958 := by decide
theorem cert_e833466519750 : check e833466519750 [] .sourceHead = true := by decide
def e833471163758 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e833471163758 : Closed e833471163758 ∧ code e833471163758 = 9629564185966 := by decide
theorem cert_e833471163758 : check e833471163758 [] .sourceHead = true := by decide
def e833471163766 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e833471163766 : Closed e833471163766 ∧ code e833471163766 = 9629564185974 := by decide
theorem cert_e833471163766 : check e833471163766 [] .sourceHead = true := by decide
def e833471163822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e833471163822 : Closed e833471163822 ∧ code e833471163822 = 9629564186030 := by decide
theorem cert_e833471163822 : check e833471163822 [] .sourceHead = true := by decide
def e833471163834 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e833471163834 : Closed e833471163834 ∧ code e833471163834 = 9629564186042 := by decide
theorem cert_e833471163834 : check e833471163834 [] .sourceHead = true := by decide
def e833471163862 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e833471163862 : Closed e833471163862 ∧ code e833471163862 = 9629564186070 := by decide
theorem cert_e833471163862 : check e833471163862 [] .sourceHead = true := by decide
def e833471163866 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e833471163866 : Closed e833471163866 ∧ code e833471163866 = 9629564186074 := by decide
theorem cert_e833471163866 : check e833471163866 [] .sourceHead = true := by decide
def e833471164078 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e833471164078 : Closed e833471164078 ∧ code e833471164078 = 9629564186286 := by decide
theorem cert_e833471164078 : check e833471164078 [] .sourceHead = true := by decide
def e833471164090 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e833471164090 : Closed e833471164090 ∧ code e833471164090 = 9629564186298 := by decide
theorem cert_e833471164090 : check e833471164090 [] .sourceHead = true := by decide
end Blc.Floor43
