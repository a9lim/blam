import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422408441974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422408441974 : Closed e2422408441974 ∧ code e2422408441974 = 11218501464182 := by decide
theorem cert_e2422408441974 : check e2422408441974 [[],[]] .chain = true := by decide
def e2422408441978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2422408441978 : Closed e2422408441978 ∧ code e2422408441978 = 11218501464186 := by decide
theorem cert_e2422408441978 : check e2422408441978 [[],[]] .chain = true := by decide
def e2422408442070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2422408442070 : Closed e2422408442070 ∧ code e2422408442070 = 11218501464278 := by decide
theorem cert_e2422408442070 : check e2422408442070 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408442166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408442166 : Closed e2422408442166 ∧ code e2422408442166 = 11218501464374 := by decide
theorem cert_e2422408442166 : check e2422408442166 [[],[]] .chain = true := by decide
def e2422408442170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408442170 : Closed e2422408442170 ∧ code e2422408442170 = 11218501464378 := by decide
theorem cert_e2422408442170 : check e2422408442170 [[],[]] .chain = true := by decide
def e2422408442254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422408442254 : Closed e2422408442254 ∧ code e2422408442254 = 11218501464462 := by decide
theorem cert_e2422408442254 : check e2422408442254 [[],[]] .chain = true := by decide
def e2422408442310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2422408442310 : Closed e2422408442310 ∧ code e2422408442310 = 11218501464518 := by decide
theorem cert_e2422408442310 : check e2422408442310 [[],[]] .chain = true := by decide
def e2422408442646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422408442646 : Closed e2422408442646 ∧ code e2422408442646 = 11218501464854 := by decide
theorem cert_e2422408442646 : check e2422408442646 [[],[]] .chain = true := by decide
def e2422408442722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422408442722 : Closed e2422408442722 ∧ code e2422408442722 = 11218501464930 := by decide
theorem cert_e2422408442722 : check e2422408442722 [[],[]] .chain = true := by decide
def e2422408442734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422408442734 : Closed e2422408442734 ∧ code e2422408442734 = 11218501464942 := by decide
theorem cert_e2422408442734 : check e2422408442734 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408442742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422408442742 : Closed e2422408442742 ∧ code e2422408442742 = 11218501464950 := by decide
def e2422408442762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408442762 : Closed e2422408442762 ∧ code e2422408442762 = 11218501464970 := by decide
theorem cert_e2422408442762 : check e2422408442762 [[],[]] .chain = true := by decide
def e2422408442786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408442786 : Closed e2422408442786 ∧ code e2422408442786 = 11218501464994 := by decide
theorem cert_e2422408442786 : check e2422408442786 [[],[]] .chain = true := by decide
def e2422408442798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422408442798 : Closed e2422408442798 ∧ code e2422408442798 = 11218501465006 := by decide
theorem cert_e2422408442798 : check e2422408442798 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408442806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2422408442806 : Closed e2422408442806 ∧ code e2422408442806 = 11218501465014 := by decide
theorem cert_e2422408442806 : check e2422408442806 [[],[]] .chain = true := by decide
def e2422408442810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422408442810 : Closed e2422408442810 ∧ code e2422408442810 = 11218501465018 := by decide
theorem cert_e2422408442810 : check e2422408442810 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408442838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422408442838 : Closed e2422408442838 ∧ code e2422408442838 = 11218501465046 := by decide
theorem cert_e2422408442838 : check e2422408442838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408442842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422408442842 : Closed e2422408442842 ∧ code e2422408442842 = 11218501465050 := by decide
def e2422408442910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2422408442910 : Closed e2422408442910 ∧ code e2422408442910 = 11218501465118 := by decide
theorem cert_e2422408442910 : check e2422408442910 [[],[]] .chain = true := by decide
def e2422408443106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422408443106 : Closed e2422408443106 ∧ code e2422408443106 = 11218501465314 := by decide
theorem cert_e2422408443106 : check e2422408443106 [[],[]] .chain = true := by decide
def e2422408443118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408443118 : Closed e2422408443118 ∧ code e2422408443118 = 11218501465326 := by decide
theorem cert_e2422408443118 : check e2422408443118 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408443126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408443126 : Closed e2422408443126 ∧ code e2422408443126 = 11218501465334 := by decide
theorem cert_e2422408443126 : check e2422408443126 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408443394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408443394 : Closed e2422408443394 ∧ code e2422408443394 = 11218501465602 := by decide
theorem cert_e2422408443394 : check e2422408443394 [[],[]] .chain = true := by decide
def e2422408443406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408443406 : Closed e2422408443406 ∧ code e2422408443406 = 11218501465614 := by decide
theorem cert_e2422408443406 : check e2422408443406 [[],[]] .chain = true := by decide
def e2422408443418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408443418 : Closed e2422408443418 ∧ code e2422408443418 = 11218501465626 := by decide
theorem cert_e2422408443418 : check e2422408443418 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408443490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408443490 : Closed e2422408443490 ∧ code e2422408443490 = 11218501465698 := by decide
theorem cert_e2422408443490 : check e2422408443490 [[],[]] .chain = true := by decide
def e2422408443502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408443502 : Closed e2422408443502 ∧ code e2422408443502 = 11218501465710 := by decide
theorem cert_e2422408443502 : check e2422408443502 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408443510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408443510 : Closed e2422408443510 ∧ code e2422408443510 = 11218501465718 := by decide
theorem cert_e2422408443510 : check e2422408443510 [[],[]] .chain = true := by decide
def e2422408443514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408443514 : Closed e2422408443514 ∧ code e2422408443514 = 11218501465722 := by decide
theorem cert_e2422408443514 : check e2422408443514 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408443702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408443702 : Closed e2422408443702 ∧ code e2422408443702 = 11218501465910 := by decide
theorem cert_e2422408443702 : check e2422408443702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422408443706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408443706 : Closed e2422408443706 ∧ code e2422408443706 = 11218501465914 := by decide
theorem cert_e2422408443706 : check e2422408443706 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408446126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.var 2))))))
theorem wire_e2422408446126 : Closed e2422408446126 ∧ code e2422408446126 = 11218501468334 := by decide
theorem cert_e2422408446126 : check e2422408446126 [[],[]] .chain = true := by decide
def e2422408446138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.var 2))) (.var 0))))))
theorem wire_e2422408446138 : Closed e2422408446138 ∧ code e2422408446138 = 11218501468346 := by decide
theorem cert_e2422408446138 : check e2422408446138 [[],[]] .chain = true := by decide
def e2422408446702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))) (.var 2))))))
theorem wire_e2422408446702 : Closed e2422408446702 ∧ code e2422408446702 = 11218501468910 := by decide
theorem cert_e2422408446702 : check e2422408446702 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408446830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1))) (.var 2))))))
theorem wire_e2422408446830 : Closed e2422408446830 ∧ code e2422408446830 = 11218501469038 := by decide
theorem cert_e2422408446830 : check e2422408446830 [[],[]] .chain = true := by decide
def e2422408446838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2))) (.var 1))))))
theorem wire_e2422408446838 : Closed e2422408446838 ∧ code e2422408446838 = 11218501469046 := by decide
theorem cert_e2422408446838 : check e2422408446838 [[],[]] .chain = true := by decide
def e2422408446894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0))) (.var 2))))))
theorem wire_e2422408446894 : Closed e2422408446894 ∧ code e2422408446894 = 11218501469102 := by decide
theorem cert_e2422408446894 : check e2422408446894 [[],[]] .chain = true := by decide
def e2422408446906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2))) (.var 0))))))
theorem wire_e2422408446906 : Closed e2422408446906 ∧ code e2422408446906 = 11218501469114 := by decide
theorem cert_e2422408446906 : check e2422408446906 [[],[]] .chain = true := by decide
def e2422408446954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0))) (.var 0))))))
theorem wire_e2422408446954 : Closed e2422408446954 ∧ code e2422408446954 = 11218501469162 := by decide
theorem cert_e2422408446954 : check e2422408446954 [[],[]] .chain = true := by decide
def e2422408447662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.var 2))))))
theorem wire_e2422408447662 : Closed e2422408447662 ∧ code e2422408447662 = 11218501469870 := by decide
theorem cert_e2422408447662 : check e2422408447662 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408447674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2))) (.var 0))))))
theorem wire_e2422408447674 : Closed e2422408447674 ∧ code e2422408447674 = 11218501469882 := by decide
theorem cert_e2422408447674 : check e2422408447674 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408448238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422408448238 : Closed e2422408448238 ∧ code e2422408448238 = 11218501470446 := by decide
theorem cert_e2422408448238 : check e2422408448238 [[],[]] .chain = true := by decide
def e2422408448246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422408448246 : Closed e2422408448246 ∧ code e2422408448246 = 11218501470454 := by decide
theorem cert_e2422408448246 : check e2422408448246 [[],[]] .chain = true := by decide
def e2422408448430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422408448430 : Closed e2422408448430 ∧ code e2422408448430 = 11218501470638 := by decide
theorem cert_e2422408448430 : check e2422408448430 [[],[]] .chain = true := by decide
def e2422408448442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422408448442 : Closed e2422408448442 ∧ code e2422408448442 = 11218501470650 := by decide
theorem cert_e2422408448442 : check e2422408448442 [[],[]] .chain = true := by decide
def e2422408448490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422408448490 : Closed e2422408448490 ∧ code e2422408448490 = 11218501470698 := by decide
theorem cert_e2422408448490 : check e2422408448490 [[],[]] .chain = true := by decide
def e2422408448622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408448622 : Closed e2422408448622 ∧ code e2422408448622 = 11218501470830 := by decide
theorem cert_e2422408448622 : check e2422408448622 [[],[]] .chain = true := by decide
def e2422408448634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408448634 : Closed e2422408448634 ∧ code e2422408448634 = 11218501470842 := by decide
theorem cert_e2422408448634 : check e2422408448634 [[],[]] .chain = true := by decide
def e2422408448798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422408448798 : Closed e2422408448798 ∧ code e2422408448798 = 11218501471006 := by decide
theorem cert_e2422408448798 : check e2422408448798 [[],[]] .chain = true := by decide
def e2422408448910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422408448910 : Closed e2422408448910 ∧ code e2422408448910 = 11218501471118 := by decide
theorem cert_e2422408448910 : check e2422408448910 [[],[]] .chain = true := by decide
def e2422408448922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408448922 : Closed e2422408448922 ∧ code e2422408448922 = 11218501471130 := by decide
theorem cert_e2422408448922 : check e2422408448922 [[],[]] .chain = true := by decide
def e2422408449134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422408449134 : Closed e2422408449134 ∧ code e2422408449134 = 11218501471342 := by decide
theorem cert_e2422408449134 : check e2422408449134 [[],[]] .chain = true := by decide
def e2422408449146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422408449146 : Closed e2422408449146 ∧ code e2422408449146 = 11218501471354 := by decide
theorem cert_e2422408449146 : check e2422408449146 [[],[]] .chain = true := by decide
def e2422408449310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422408449310 : Closed e2422408449310 ∧ code e2422408449310 = 11218501471518 := by decide
theorem cert_e2422408449310 : check e2422408449310 [[],[]] .chain = true := by decide
def e2422408449478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422408449478 : Closed e2422408449478 ∧ code e2422408449478 = 11218501471686 := by decide
theorem cert_e2422408449478 : check e2422408449478 [[],[]] .chain = true := by decide
def e2422408449582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422408449582 : Closed e2422408449582 ∧ code e2422408449582 = 11218501471790 := by decide
theorem cert_e2422408449582 : check e2422408449582 [[],[]] .chain = true := by decide
def e2422408449762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422408449762 : Closed e2422408449762 ∧ code e2422408449762 = 11218501471970 := by decide
theorem cert_e2422408449762 : check e2422408449762 [[],[]] .chain = true := by decide
def e2422408449774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))) (.var 2))))))
theorem wire_e2422408449774 : Closed e2422408449774 ∧ code e2422408449774 = 11218501471982 := by decide
theorem cert_e2422408449774 : check e2422408449774 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408449814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422408449814 : Closed e2422408449814 ∧ code e2422408449814 = 11218501472022 := by decide
theorem cert_e2422408449814 : check e2422408449814 [[],[]] .chain = true := by decide
def e2422408449818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422408449818 : Closed e2422408449818 ∧ code e2422408449818 = 11218501472026 := by decide
theorem cert_e2422408449818 : check e2422408449818 [[],[]] .chain = true := by decide
def e2422408449862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422408449862 : Closed e2422408449862 ∧ code e2422408449862 = 11218501472070 := by decide
theorem cert_e2422408449862 : check e2422408449862 [[],[]] .chain = true := by decide
def e2422408449890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422408449890 : Closed e2422408449890 ∧ code e2422408449890 = 11218501472098 := by decide
theorem cert_e2422408449890 : check e2422408449890 [[],[]] .chain = true := by decide
def e2422408449902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))) (.var 2))))))
theorem wire_e2422408449902 : Closed e2422408449902 ∧ code e2422408449902 = 11218501472110 := by decide
theorem cert_e2422408449902 : check e2422408449902 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408449910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))) (.var 1))))))
theorem wire_e2422408449910 : Closed e2422408449910 ∧ code e2422408449910 = 11218501472118 := by decide
theorem cert_e2422408449910 : check e2422408449910 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408452270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.var 2))))))
theorem wire_e2422408452270 : Closed e2422408452270 ∧ code e2422408452270 = 11218501474478 := by decide
theorem cert_e2422408452270 : check e2422408452270 [[],[]] .chain = true := by decide
def e2422408452282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2))) (.var 0))))))
theorem wire_e2422408452282 : Closed e2422408452282 ∧ code e2422408452282 = 11218501474490 := by decide
theorem cert_e2422408452282 : check e2422408452282 [[],[]] .chain = true := by decide
def e2422408452654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422408452654 : Closed e2422408452654 ∧ code e2422408452654 = 11218501474862 := by decide
theorem cert_e2422408452654 : check e2422408452654 [[],[]] .chain = true := by decide
def e2422408452834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422408452834 : Closed e2422408452834 ∧ code e2422408452834 = 11218501475042 := by decide
theorem cert_e2422408452834 : check e2422408452834 [[],[]] .chain = true := by decide
def e2422408452846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.var 2))))))
theorem wire_e2422408452846 : Closed e2422408452846 ∧ code e2422408452846 = 11218501475054 := by decide
theorem cert_e2422408452846 : check e2422408452846 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408452974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e2422408452974 : Closed e2422408452974 ∧ code e2422408452974 = 11218501475182 := by decide
theorem cert_e2422408452974 : check e2422408452974 [[],[]] .chain = true := by decide
def e2422408452982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e2422408452982 : Closed e2422408452982 ∧ code e2422408452982 = 11218501475190 := by decide
theorem cert_e2422408452982 : check e2422408452982 [[],[]] .chain = true := by decide
def e2422408453002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408453002 : Closed e2422408453002 ∧ code e2422408453002 = 11218501475210 := by decide
theorem cert_e2422408453002 : check e2422408453002 [[],[]] .chain = true := by decide
def e2422408453026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408453026 : Closed e2422408453026 ∧ code e2422408453026 = 11218501475234 := by decide
theorem cert_e2422408453026 : check e2422408453026 [[],[]] .chain = true := by decide
def e2422408453038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.var 2))))))
theorem wire_e2422408453038 : Closed e2422408453038 ∧ code e2422408453038 = 11218501475246 := by decide
theorem cert_e2422408453038 : check e2422408453038 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408453046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))) (.var 1))))))
theorem wire_e2422408453046 : Closed e2422408453046 ∧ code e2422408453046 = 11218501475254 := by decide
theorem cert_e2422408453046 : check e2422408453046 [[],[]] .chain = true := by decide
def e2422408453050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))) (.var 0))))))
theorem wire_e2422408453050 : Closed e2422408453050 ∧ code e2422408453050 = 11218501475258 := by decide
theorem cert_e2422408453050 : check e2422408453050 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408453486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2422408453486 : Closed e2422408453486 ∧ code e2422408453486 = 11218501475694 := by decide
theorem cert_e2422408453486 : check e2422408453486 [[],[]] .chain = true := by decide
def e2422408453494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2422408453494 : Closed e2422408453494 ∧ code e2422408453494 = 11218501475702 := by decide
theorem cert_e2422408453494 : check e2422408453494 [[],[]] .chain = true := by decide
def e2422408453550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e2422408453550 : Closed e2422408453550 ∧ code e2422408453550 = 11218501475758 := by decide
theorem cert_e2422408453550 : check e2422408453550 [[],[]] .chain = true := by decide
def e2422408453562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e2422408453562 : Closed e2422408453562 ∧ code e2422408453562 = 11218501475770 := by decide
theorem cert_e2422408453562 : check e2422408453562 [[],[]] .chain = true := by decide
def e2422408453590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e2422408453590 : Closed e2422408453590 ∧ code e2422408453590 = 11218501475798 := by decide
theorem cert_e2422408453590 : check e2422408453590 [[],[]] .chain = true := by decide
def e2422408453594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e2422408453594 : Closed e2422408453594 ∧ code e2422408453594 = 11218501475802 := by decide
theorem cert_e2422408453594 : check e2422408453594 [[],[]] .chain = true := by decide
def e2422408453674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0))) (.var 0))))))
theorem wire_e2422408453674 : Closed e2422408453674 ∧ code e2422408453674 = 11218501475882 := by decide
theorem cert_e2422408453674 : check e2422408453674 [[],[]] .chain = true := by decide
def e2422408453770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408453770 : Closed e2422408453770 ∧ code e2422408453770 = 11218501475978 := by decide
theorem cert_e2422408453770 : check e2422408453770 [[],[]] .chain = true := by decide
def e2422408453794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408453794 : Closed e2422408453794 ∧ code e2422408453794 = 11218501476002 := by decide
theorem cert_e2422408453794 : check e2422408453794 [[],[]] .chain = true := by decide
def e2422408453806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2422408453806 : Closed e2422408453806 ∧ code e2422408453806 = 11218501476014 := by decide
theorem cert_e2422408453806 : check e2422408453806 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408453814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))) (.var 1))))))
theorem wire_e2422408453814 : Closed e2422408453814 ∧ code e2422408453814 = 11218501476022 := by decide
theorem cert_e2422408453814 : check e2422408453814 [[],[]] .chain = true := by decide
def e2422408453818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2422408453818 : Closed e2422408453818 ∧ code e2422408453818 = 11218501476026 := by decide
theorem cert_e2422408453818 : check e2422408453818 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408453846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e2422408453846 : Closed e2422408453846 ∧ code e2422408453846 = 11218501476054 := by decide
theorem cert_e2422408453846 : check e2422408453846 [[],[]] .chain = true := by decide
def e2422408453850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e2422408453850 : Closed e2422408453850 ∧ code e2422408453850 = 11218501476058 := by decide
theorem cert_e2422408453850 : check e2422408453850 [[],[]] .chain = true := by decide
def e2422408453866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e2422408453866 : Closed e2422408453866 ∧ code e2422408453866 = 11218501476074 := by decide
theorem cert_e2422408453866 : check e2422408453866 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408454190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422408454190 : Closed e2422408454190 ∧ code e2422408454190 = 11218501476398 := by decide
theorem cert_e2422408454190 : check e2422408454190 [[],[]] .chain = true := by decide
def e2422408454382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2422408454382 : Closed e2422408454382 ∧ code e2422408454382 = 11218501476590 := by decide
theorem cert_e2422408454382 : check e2422408454382 [[],[]] .chain = true := by decide
def e2422408454394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422408454394 : Closed e2422408454394 ∧ code e2422408454394 = 11218501476602 := by decide
theorem cert_e2422408454394 : check e2422408454394 [[],[]] .chain = true := by decide
def e2422408454574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2422408454574 : Closed e2422408454574 ∧ code e2422408454574 = 11218501476782 := by decide
theorem cert_e2422408454574 : check e2422408454574 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408454766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408454766 : Closed e2422408454766 ∧ code e2422408454766 = 11218501476974 := by decide
theorem cert_e2422408454766 : check e2422408454766 [[],[]] .chain = true := by decide
def e2422408454778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408454778 : Closed e2422408454778 ∧ code e2422408454778 = 11218501476986 := by decide
theorem cert_e2422408454778 : check e2422408454778 [[],[]] .chain = true := by decide
def e2422408454942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2422408454942 : Closed e2422408454942 ∧ code e2422408454942 = 11218501477150 := by decide
theorem cert_e2422408454942 : check e2422408454942 [[],[]] .chain = true := by decide
def e2422408455110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422408455110 : Closed e2422408455110 ∧ code e2422408455110 = 11218501477318 := by decide
theorem cert_e2422408455110 : check e2422408455110 [[],[]] .chain = true := by decide
def e2422408455726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422408455726 : Closed e2422408455726 ∧ code e2422408455726 = 11218501477934 := by decide
theorem cert_e2422408455726 : check e2422408455726 [[],[]] .chain = true := by decide
def e2422408455906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422408455906 : Closed e2422408455906 ∧ code e2422408455906 = 11218501478114 := by decide
theorem cert_e2422408455906 : check e2422408455906 [[],[]] .chain = true := by decide
def e2422408455918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2422408455918 : Closed e2422408455918 ∧ code e2422408455918 = 11218501478126 := by decide
theorem cert_e2422408455918 : check e2422408455918 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408456046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2422408456046 : Closed e2422408456046 ∧ code e2422408456046 = 11218501478254 := by decide
theorem cert_e2422408456046 : check e2422408456046 [[],[]] .chain = true := by decide
def e2422408456054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2422408456054 : Closed e2422408456054 ∧ code e2422408456054 = 11218501478262 := by decide
theorem cert_e2422408456054 : check e2422408456054 [[],[]] .chain = true := by decide
def e2422408456074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408456074 : Closed e2422408456074 ∧ code e2422408456074 = 11218501478282 := by decide
theorem cert_e2422408456074 : check e2422408456074 [[],[]] .chain = true := by decide
def e2422408456098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408456098 : Closed e2422408456098 ∧ code e2422408456098 = 11218501478306 := by decide
theorem cert_e2422408456098 : check e2422408456098 [[],[]] .chain = true := by decide
def e2422408456110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2422408456110 : Closed e2422408456110 ∧ code e2422408456110 = 11218501478318 := by decide
theorem cert_e2422408456110 : check e2422408456110 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408456118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2422408456118 : Closed e2422408456118 ∧ code e2422408456118 = 11218501478326 := by decide
theorem cert_e2422408456118 : check e2422408456118 [[],[]] .chain = true := by decide
def e2422408456122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2422408456122 : Closed e2422408456122 ∧ code e2422408456122 = 11218501478330 := by decide
theorem cert_e2422408456122 : check e2422408456122 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408456254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2422408456254 : Closed e2422408456254 ∧ code e2422408456254 = 11218501478462 := by decide
theorem cert_e2422408456254 : check e2422408456254 [[],[]] .chain = true := by decide
def e2422408456674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422408456674 : Closed e2422408456674 ∧ code e2422408456674 = 11218501478882 := by decide
theorem cert_e2422408456674 : check e2422408456674 [[],[]] .chain = true := by decide
def e2422408456686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422408456686 : Closed e2422408456686 ∧ code e2422408456686 = 11218501478894 := by decide
theorem cert_e2422408456686 : check e2422408456686 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408457454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408457454 : Closed e2422408457454 ∧ code e2422408457454 = 11218501479662 := by decide
theorem cert_e2422408457454 : check e2422408457454 [[],[]] .chain = true := by decide
def e2422408457462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408457462 : Closed e2422408457462 ∧ code e2422408457462 = 11218501479670 := by decide
theorem cert_e2422408457462 : check e2422408457462 [[],[]] .chain = true := by decide
def e2422408457730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408457730 : Closed e2422408457730 ∧ code e2422408457730 = 11218501479938 := by decide
theorem cert_e2422408457730 : check e2422408457730 [[],[]] .chain = true := by decide
def e2422408457742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408457742 : Closed e2422408457742 ∧ code e2422408457742 = 11218501479950 := by decide
theorem cert_e2422408457742 : check e2422408457742 [[],[]] .chain = true := by decide
def e2422408457754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408457754 : Closed e2422408457754 ∧ code e2422408457754 = 11218501479962 := by decide
theorem cert_e2422408457754 : check e2422408457754 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408457826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408457826 : Closed e2422408457826 ∧ code e2422408457826 = 11218501480034 := by decide
theorem cert_e2422408457826 : check e2422408457826 [[],[]] .chain = true := by decide
def e2422408457838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408457838 : Closed e2422408457838 ∧ code e2422408457838 = 11218501480046 := by decide
theorem cert_e2422408457838 : check e2422408457838 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408457846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408457846 : Closed e2422408457846 ∧ code e2422408457846 = 11218501480054 := by decide
theorem cert_e2422408457846 : check e2422408457846 [[],[]] .chain = true := by decide
def e2422408457850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408457850 : Closed e2422408457850 ∧ code e2422408457850 = 11218501480058 := by decide
theorem cert_e2422408457850 : check e2422408457850 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408458350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e2422408458350 : Closed e2422408458350 ∧ code e2422408458350 = 11218501480558 := by decide
theorem cert_e2422408458350 : check e2422408458350 [[],[]] .chain = true := by decide
def e2422408458526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2422408458526 : Closed e2422408458526 ∧ code e2422408458526 = 11218501480734 := by decide
theorem cert_e2422408458526 : check e2422408458526 [[],[]] .chain = true := by decide
def e2422408458722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e2422408458722 : Closed e2422408458722 ∧ code e2422408458722 = 11218501480930 := by decide
theorem cert_e2422408458722 : check e2422408458722 [[],[]] .chain = true := by decide
def e2422408458734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))) (.var 2))))))
theorem wire_e2422408458734 : Closed e2422408458734 ∧ code e2422408458734 = 11218501480942 := by decide
theorem cert_e2422408458734 : check e2422408458734 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408459118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422408459118 : Closed e2422408459118 ∧ code e2422408459118 = 11218501481326 := by decide
theorem cert_e2422408459118 : check e2422408459118 [[],[]] .chain = true := by decide
def e2422408459126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422408459126 : Closed e2422408459126 ∧ code e2422408459126 = 11218501481334 := by decide
theorem cert_e2422408459126 : check e2422408459126 [[],[]] .chain = true := by decide
def e2422408459182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422408459182 : Closed e2422408459182 ∧ code e2422408459182 = 11218501481390 := by decide
theorem cert_e2422408459182 : check e2422408459182 [[],[]] .chain = true := by decide
def e2422408459194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422408459194 : Closed e2422408459194 ∧ code e2422408459194 = 11218501481402 := by decide
theorem cert_e2422408459194 : check e2422408459194 [[],[]] .chain = true := by decide
def e2422408459222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422408459222 : Closed e2422408459222 ∧ code e2422408459222 = 11218501481430 := by decide
theorem cert_e2422408459222 : check e2422408459222 [[],[]] .chain = true := by decide
def e2422408459226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422408459226 : Closed e2422408459226 ∧ code e2422408459226 = 11218501481434 := by decide
theorem cert_e2422408459226 : check e2422408459226 [[],[]] .chain = true := by decide
def e2422408459502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408459502 : Closed e2422408459502 ∧ code e2422408459502 = 11218501481710 := by decide
theorem cert_e2422408459502 : check e2422408459502 [[],[]] .chain = true := by decide
def e2422408459510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408459510 : Closed e2422408459510 ∧ code e2422408459510 = 11218501481718 := by decide
theorem cert_e2422408459510 : check e2422408459510 [[],[]] .chain = true := by decide
def e2422408459886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408459886 : Closed e2422408459886 ∧ code e2422408459886 = 11218501482094 := by decide
theorem cert_e2422408459886 : check e2422408459886 [[],[]] .chain = true := by decide
def e2422408459898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408459898 : Closed e2422408459898 ∧ code e2422408459898 = 11218501482106 := by decide
theorem cert_e2422408459898 : check e2422408459898 [[],[]] .chain = true := by decide
def e2422408460038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e2422408460038 : Closed e2422408460038 ∧ code e2422408460038 = 11218501482246 := by decide
theorem cert_e2422408460038 : check e2422408460038 [[],[]] .chain = true := by decide
def e2422408460062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.var 3)))))))
theorem wire_e2422408460062 : Closed e2422408460062 ∧ code e2422408460062 = 11218501482270 := by decide
theorem cert_e2422408460062 : check e2422408460062 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408460086 : Closed e2422408460086 ∧ code e2422408460086 = 11218501482294 := by decide
theorem cert_e2422408460086 : check e2422408460086 [[],[]] .chain = true := by decide
def e2422408460090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408460090 : Closed e2422408460090 ∧ code e2422408460090 = 11218501482298 := by decide
theorem cert_e2422408460090 : check e2422408460090 [[],[]] .chain = true := by decide
def e2422408460298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422408460298 : Closed e2422408460298 ∧ code e2422408460298 = 11218501482506 := by decide
theorem cert_e2422408460298 : check e2422408460298 [[],[]] .chain = true := by decide
def e2422408460334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422408460334 : Closed e2422408460334 ∧ code e2422408460334 = 11218501482542 := by decide
theorem cert_e2422408460334 : check e2422408460334 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422408460342 : Closed e2422408460342 ∧ code e2422408460342 = 11218501482550 := by decide
theorem cert_e2422408460342 : check e2422408460342 [[],[]] .chain = true := by decide
def e2422408460346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422408460346 : Closed e2422408460346 ∧ code e2422408460346 = 11218501482554 := by decide
theorem cert_e2422408460346 : check e2422408460346 [[],[]] .chain = true := by decide
def e2422408460394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422408460394 : Closed e2422408460394 ∧ code e2422408460394 = 11218501482602 := by decide
theorem cert_e2422408460394 : check e2422408460394 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422408460430 : Closed e2422408460430 ∧ code e2422408460430 = 11218501482638 := by decide
theorem cert_e2422408460430 : check e2422408460430 [[],[]] .chain = true := by decide
def e2422408460442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408460442 : Closed e2422408460442 ∧ code e2422408460442 = 11218501482650 := by decide
theorem cert_e2422408460442 : check e2422408460442 [[],[]] .chain = true := by decide
def e2422408460486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422408460486 : Closed e2422408460486 ∧ code e2422408460486 = 11218501482694 := by decide
theorem cert_e2422408460486 : check e2422408460486 [[],[]] .chain = true := by decide
def e2422408460514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422408460514 : Closed e2422408460514 ∧ code e2422408460514 = 11218501482722 := by decide
theorem cert_e2422408460514 : check e2422408460514 [[],[]] .chain = true := by decide
def e2422408460526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422408460526 : Closed e2422408460526 ∧ code e2422408460526 = 11218501482734 := by decide
theorem cert_e2422408460526 : check e2422408460526 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422408460534 : Closed e2422408460534 ∧ code e2422408460534 = 11218501482742 := by decide
theorem cert_e2422408460534 : check e2422408460534 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408460682 : Closed e2422408460682 ∧ code e2422408460682 = 11218501482890 := by decide
theorem cert_e2422408460682 : check e2422408460682 [[],[]] .chain = true := by decide
def e2422408460706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408460706 : Closed e2422408460706 ∧ code e2422408460706 = 11218501482914 := by decide
theorem cert_e2422408460706 : check e2422408460706 [[],[]] .chain = true := by decide
def e2422408460718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422408460718 : Closed e2422408460718 ∧ code e2422408460718 = 11218501482926 := by decide
theorem cert_e2422408460718 : check e2422408460718 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422408460726 : Closed e2422408460726 ∧ code e2422408460726 = 11218501482934 := by decide
theorem cert_e2422408460726 : check e2422408460726 [[],[]] .chain = true := by decide
def e2422408460730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422408460730 : Closed e2422408460730 ∧ code e2422408460730 = 11218501482938 := by decide
theorem cert_e2422408460730 : check e2422408460730 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422408460758 : Closed e2422408460758 ∧ code e2422408460758 = 11218501482966 := by decide
theorem cert_e2422408460758 : check e2422408460758 [[],[]] .chain = true := by decide
def e2422408460762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2422408460762 : Closed e2422408460762 ∧ code e2422408460762 = 11218501482970 := by decide
theorem cert_e2422408460762 : check e2422408460762 [[],[]] .chain = true := by decide
def e2422408460778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422408460778 : Closed e2422408460778 ∧ code e2422408460778 = 11218501482986 := by decide
theorem cert_e2422408460778 : check e2422408460778 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408460802 : Closed e2422408460802 ∧ code e2422408460802 = 11218501483010 := by decide
theorem cert_e2422408460802 : check e2422408460802 [[],[]] .chain = true := by decide
def e2422408460814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408460814 : Closed e2422408460814 ∧ code e2422408460814 = 11218501483022 := by decide
theorem cert_e2422408460814 : check e2422408460814 [[],[]] .chain = true := by decide
end Blc.Floor43
