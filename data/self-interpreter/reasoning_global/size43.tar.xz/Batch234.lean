import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393373397946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2393373397946 : Closed e2393373397946 ∧ code e2393373397946 = 11189466420154 := by decide
theorem cert_e2393373397946 : check e2393373397946 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2393373397974 : Closed e2393373397974 ∧ code e2393373397974 = 11189466420182 := by decide
theorem cert_e2393373397974 : check e2393373397974 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2393373397978 : Closed e2393373397978 ∧ code e2393373397978 = 11189466420186 := by decide
theorem cert_e2393373397978 : check e2393373397978 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2393373398046 : Closed e2393373398046 ∧ code e2393373398046 = 11189466420254 := by decide
theorem cert_e2393373398046 : check e2393373398046 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2393373398242 : Closed e2393373398242 ∧ code e2393373398242 = 11189466420450 := by decide
theorem cert_e2393373398242 : check e2393373398242 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373398254 : Closed e2393373398254 ∧ code e2393373398254 = 11189466420462 := by decide
theorem cert_e2393373398254 : check e2393373398254 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373398262 : Closed e2393373398262 ∧ code e2393373398262 = 11189466420470 := by decide
theorem cert_e2393373398262 : check e2393373398262 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2393373398542 : Closed e2393373398542 ∧ code e2393373398542 = 11189466420750 := by decide
theorem cert_e2393373398542 : check e2393373398542 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373398554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373398554 : Closed e2393373398554 ∧ code e2393373398554 = 11189466420762 := by decide
theorem cert_e2393373398554 : check e2393373398554 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373398626 : Closed e2393373398626 ∧ code e2393373398626 = 11189466420834 := by decide
theorem cert_e2393373398626 : check e2393373398626 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373398638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373398638 : Closed e2393373398638 ∧ code e2393373398638 = 11189466420846 := by decide
theorem cert_e2393373398638 : check e2393373398638 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373398646 : Closed e2393373398646 ∧ code e2393373398646 = 11189466420854 := by decide
theorem cert_e2393373398646 : check e2393373398646 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373398650 : Closed e2393373398650 ∧ code e2393373398650 = 11189466420858 := by decide
theorem cert_e2393373398650 : check e2393373398650 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373398838 : Closed e2393373398838 ∧ code e2393373398838 = 11189466421046 := by decide
theorem cert_e2393373398838 : check e2393373398838 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373398842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373398842 : Closed e2393373398842 ∧ code e2393373398842 = 11189466421050 := by decide
theorem cert_e2393373398842 : check e2393373398842 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373399098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2393373399098 : Closed e2393373399098 ∧ code e2393373399098 = 11189466421306 := by decide
theorem cert_e2393373399098 : check e2393373399098 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373399146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2393373399146 : Closed e2393373399146 ∧ code e2393373399146 = 11189466421354 := by decide
theorem cert_e2393373399146 : check e2393373399146 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .width = true := by decide
def e2393373399194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373399194 : Closed e2393373399194 ∧ code e2393373399194 = 11189466421402 := by decide
theorem cert_e2393373399194 : check e2393373399194 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373399238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2393373399238 : Closed e2393373399238 ∧ code e2393373399238 = 11189466421446 := by decide
theorem cert_e2393373399238 : check e2393373399238 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373399434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373399434 : Closed e2393373399434 ∧ code e2393373399434 = 11189466421642 := by decide
theorem cert_e2393373399434 : check e2393373399434 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373399458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373399458 : Closed e2393373399458 ∧ code e2393373399458 = 11189466421666 := by decide
theorem cert_e2393373399458 : check e2393373399458 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373399470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2393373399470 : Closed e2393373399470 ∧ code e2393373399470 = 11189466421678 := by decide
theorem cert_e2393373399470 : check e2393373399470 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373399478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2393373399478 : Closed e2393373399478 ∧ code e2393373399478 = 11189466421686 := by decide
theorem cert_e2393373399478 : check e2393373399478 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373399482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2393373399482 : Closed e2393373399482 ∧ code e2393373399482 = 11189466421690 := by decide
theorem cert_e2393373399482 : check e2393373399482 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373399510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2393373399510 : Closed e2393373399510 ∧ code e2393373399510 = 11189466421718 := by decide
theorem cert_e2393373399510 : check e2393373399510 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373399514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2393373399514 : Closed e2393373399514 ∧ code e2393373399514 = 11189466421722 := by decide
def e2393373399530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2393373399530 : Closed e2393373399530 ∧ code e2393373399530 = 11189466421738 := by decide
theorem cert_e2393373399530 : check e2393373399530 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373399566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2393373399566 : Closed e2393373399566 ∧ code e2393373399566 = 11189466421774 := by decide
theorem cert_e2393373399566 : check e2393373399566 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373399578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373399578 : Closed e2393373399578 ∧ code e2393373399578 = 11189466421786 := by decide
theorem cert_e2393373399578 : check e2393373399578 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .width = true := by decide
def e2393373399650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373399650 : Closed e2393373399650 ∧ code e2393373399650 = 11189466421858 := by decide
theorem cert_e2393373399650 : check e2393373399650 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373399662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373399662 : Closed e2393373399662 ∧ code e2393373399662 = 11189466421870 := by decide
theorem cert_e2393373399662 : check e2393373399662 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373399670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373399670 : Closed e2393373399670 ∧ code e2393373399670 = 11189466421878 := by decide
theorem cert_e2393373399670 : check e2393373399670 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373399674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373399674 : Closed e2393373399674 ∧ code e2393373399674 = 11189466421882 := by decide
theorem cert_e2393373399674 : check e2393373399674 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373399862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373399862 : Closed e2393373399862 ∧ code e2393373399862 = 11189466422070 := by decide
def e2393373399866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373399866 : Closed e2393373399866 ∧ code e2393373399866 = 11189466422074 := by decide
def e2393373399962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373399962 : Closed e2393373399962 ∧ code e2393373399962 = 11189466422170 := by decide
def e2393373400278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2393373400278 : Closed e2393373400278 ∧ code e2393373400278 = 11189466422486 := by decide
private def t_e2393373400278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem cert_e2393373400278 : ¬ IsSelfInterpreter e2393373400278 :=
  wSource (t := t_e2393373400278) (replay_sound (ps := []) (t := e2393373400278) (by decide)) (by decide)
def e2393373400282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2393373400282 : Closed e2393373400282 ∧ code e2393373400282 = 11189466422490 := by decide
private def t_e2393373400282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem cert_e2393373400282 : ¬ IsSelfInterpreter e2393373400282 :=
  wSource (t := t_e2393373400282) (replay_sound (ps := []) (t := e2393373400282) (by decide)) (by decide)
def e2393373400298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2393373400298 : Closed e2393373400298 ∧ code e2393373400298 = 11189466422506 := by decide
private def t_e2393373400298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem cert_e2393373400298 : ¬ IsSelfInterpreter e2393373400298 :=
  wSource (t := t_e2393373400298) (replay_sound (ps := []) (t := e2393373400298) (by decide)) (by decide)
def e2393373400374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373400374 : Closed e2393373400374 ∧ code e2393373400374 = 11189466422582 := by decide
private def t_e2393373400374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem cert_e2393373400374 : ¬ IsSelfInterpreter e2393373400374 :=
  wSource (t := t_e2393373400374) (replay_sound (ps := []) (t := e2393373400374) (by decide)) (by decide)
def e2393373400378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373400378 : Closed e2393373400378 ∧ code e2393373400378 = 11189466422586 := by decide
private def t_e2393373400378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem cert_e2393373400378 : ¬ IsSelfInterpreter e2393373400378 :=
  wSource (t := t_e2393373400378) (replay_sound (ps := []) (t := e2393373400378) (by decide)) (by decide)
def e2393373400474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373400474 : Closed e2393373400474 ∧ code e2393373400474 = 11189466422682 := by decide
private def t_e2393373400474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem cert_e2393373400474 : ¬ IsSelfInterpreter e2393373400474 :=
  wSource (t := t_e2393373400474) (replay_sound (ps := []) (t := e2393373400474) (by decide)) (by decide)
def e2393373416686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373416686 : Closed e2393373416686 ∧ code e2393373416686 = 11189466438894 := by decide
theorem cert_e2393373416686 : check e2393373416686 [[],[.left],[]] .sourceHead = true := by decide
def e2393373416694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373416694 : Closed e2393373416694 ∧ code e2393373416694 = 11189466438902 := by decide
theorem cert_e2393373416694 : check e2393373416694 [[],[.left],[]] .sourceHead = true := by decide
def e2393373417070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373417070 : Closed e2393373417070 ∧ code e2393373417070 = 11189466439278 := by decide
theorem cert_e2393373417070 : check e2393373417070 [[],[.left],[]] .sourceHead = true := by decide
def e2393373417082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373417082 : Closed e2393373417082 ∧ code e2393373417082 = 11189466439290 := by decide
theorem cert_e2393373417082 : check e2393373417082 [[],[.left],[]] .sourceHead = true := by decide
def e2393373417270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373417270 : Closed e2393373417270 ∧ code e2393373417270 = 11189466439478 := by decide
theorem cert_e2393373417270 : check e2393373417270 [[],[.left],[]] .sourceHead = true := by decide
def e2393373417274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373417274 : Closed e2393373417274 ∧ code e2393373417274 = 11189466439482 := by decide
theorem cert_e2393373417274 : check e2393373417274 [[],[.left],[]] .sourceHead = true := by decide
def e2393373420986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e2393373420986 : Closed e2393373420986 ∧ code e2393373420986 = 11189466443194 := by decide
theorem cert_e2393373420986 : check e2393373420986 [[],[.left],[]] .chain = true := by decide
def e2393373421018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e2393373421018 : Closed e2393373421018 ∧ code e2393373421018 = 11189466443226 := by decide
theorem cert_e2393373421018 : check e2393373421018 [[],[.left],[]] .chain = true := by decide
def e2393373421242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2393373421242 : Closed e2393373421242 ∧ code e2393373421242 = 11189466443450 := by decide
theorem cert_e2393373421242 : check e2393373421242 [[],[.left],[]] .chain = true := by decide
def e2393373421290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2393373421290 : Closed e2393373421290 ∧ code e2393373421290 = 11189466443498 := by decide
theorem cert_e2393373421290 : check e2393373421290 [[],[.left],[]] .chain = true := by decide
def e2393373421402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e2393373421402 : Closed e2393373421402 ∧ code e2393373421402 = 11189466443610 := by decide
theorem cert_e2393373421402 : check e2393373421402 [[],[.left],[]] .chain = true := by decide
def e2393373421418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e2393373421418 : Closed e2393373421418 ∧ code e2393373421418 = 11189466443626 := by decide
theorem cert_e2393373421418 : check e2393373421418 [[],[.left],[]] .chain = true := by decide
def e2393373422522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e2393373422522 : Closed e2393373422522 ∧ code e2393373422522 = 11189466444730 := by decide
theorem cert_e2393373422522 : check e2393373422522 [[],[.left],[]] .chain = true := by decide
def e2393373422554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e2393373422554 : Closed e2393373422554 ∧ code e2393373422554 = 11189466444762 := by decide
theorem cert_e2393373422554 : check e2393373422554 [[],[.left],[]] .chain = true := by decide
def e2393373422830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373422830 : Closed e2393373422830 ∧ code e2393373422830 = 11189466445038 := by decide
theorem cert_e2393373422830 : check e2393373422830 [[],[.left],[]] .sourceHead = true := by decide
def e2393373422838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373422838 : Closed e2393373422838 ∧ code e2393373422838 = 11189466445046 := by decide
theorem cert_e2393373422838 : check e2393373422838 [[],[.left],[]] .sourceHead = true := by decide
def e2393373424058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2393373424058 : Closed e2393373424058 ∧ code e2393373424058 = 11189466446266 := by decide
theorem cert_e2393373424058 : check e2393373424058 [[],[.left],[]] .chain = true := by decide
def e2393373424106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2393373424106 : Closed e2393373424106 ∧ code e2393373424106 = 11189466446314 := by decide
theorem cert_e2393373424106 : check e2393373424106 [[],[.left],[]] .chain = true := by decide
def e2393373424858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2393373424858 : Closed e2393373424858 ∧ code e2393373424858 = 11189466447066 := by decide
theorem cert_e2393373424858 : check e2393373424858 [[],[.left],[]] .chain = true := by decide
def e2393373424874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2393373424874 : Closed e2393373424874 ∧ code e2393373424874 = 11189466447082 := by decide
theorem cert_e2393373424874 : check e2393373424874 [[],[.left],[]] .chain = true := by decide
def e2393373425134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 2))))))
theorem wire_e2393373425134 : Closed e2393373425134 ∧ code e2393373425134 = 11189466447342 := by decide
theorem cert_e2393373425134 : check e2393373425134 [[],[.left],[]] .sourceHead = true := by decide
def e2393373425390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 2))))))
theorem wire_e2393373425390 : Closed e2393373425390 ∧ code e2393373425390 = 11189466447598 := by decide
theorem cert_e2393373425390 : check e2393373425390 [[],[.left],[]] .sourceHead = true := by decide
def e2393373425398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 1))))))
theorem wire_e2393373425398 : Closed e2393373425398 ∧ code e2393373425398 = 11189466447606 := by decide
theorem cert_e2393373425398 : check e2393373425398 [[],[.left],[]] .sourceHead = true := by decide
def e2393373428590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393373428590 : Closed e2393373428590 ∧ code e2393373428590 = 11189466450798 := by decide
theorem cert_e2393373428590 : check e2393373428590 [[],[.left],[]] .sourceHead = true := by decide
def e2393373428598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393373428598 : Closed e2393373428598 ∧ code e2393373428598 = 11189466450806 := by decide
theorem cert_e2393373428598 : check e2393373428598 [[],[.left],[]] .sourceHead = true := by decide
def e2393373428654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393373428654 : Closed e2393373428654 ∧ code e2393373428654 = 11189466450862 := by decide
theorem cert_e2393373428654 : check e2393373428654 [[],[.left],[]] .sourceHead = true := by decide
def e2393373428666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393373428666 : Closed e2393373428666 ∧ code e2393373428666 = 11189466450874 := by decide
theorem cert_e2393373428666 : check e2393373428666 [[],[.left],[]] .sourceHead = true := by decide
def e2393373428694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393373428694 : Closed e2393373428694 ∧ code e2393373428694 = 11189466450902 := by decide
theorem cert_e2393373428694 : check e2393373428694 [[],[.left],[]] .sourceHead = true := by decide
def e2393373428698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393373428698 : Closed e2393373428698 ∧ code e2393373428698 = 11189466450906 := by decide
theorem cert_e2393373428698 : check e2393373428698 [[],[.left],[]] .sourceHead = true := by decide
def e2393373428974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373428974 : Closed e2393373428974 ∧ code e2393373428974 = 11189466451182 := by decide
theorem cert_e2393373428974 : check e2393373428974 [[],[.left],[]] .sourceHead = true := by decide
def e2393373428982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373428982 : Closed e2393373428982 ∧ code e2393373428982 = 11189466451190 := by decide
theorem cert_e2393373428982 : check e2393373428982 [[],[.left],[]] .sourceHead = true := by decide
def e2393373429358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373429358 : Closed e2393373429358 ∧ code e2393373429358 = 11189466451566 := by decide
theorem cert_e2393373429358 : check e2393373429358 [[],[.left],[]] .sourceHead = true := by decide
def e2393373429370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373429370 : Closed e2393373429370 ∧ code e2393373429370 = 11189466451578 := by decide
theorem cert_e2393373429370 : check e2393373429370 [[],[.left],[]] .sourceHead = true := by decide
def e2393373429558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373429558 : Closed e2393373429558 ∧ code e2393373429558 = 11189466451766 := by decide
theorem cert_e2393373429558 : check e2393373429558 [[],[.left],[]] .sourceHead = true := by decide
def e2393373429562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373429562 : Closed e2393373429562 ∧ code e2393373429562 = 11189466451770 := by decide
theorem cert_e2393373429562 : check e2393373429562 [[],[.left],[]] .sourceHead = true := by decide
def e2393373435678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2393373435678 : Closed e2393373435678 ∧ code e2393373435678 = 11189466457886 := by decide
theorem cert_e2393373435678 : check e2393373435678 [[],[.left],[]] .sourceHead = true := by decide
def e2393373435790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2393373435790 : Closed e2393373435790 ∧ code e2393373435790 = 11189466457998 := by decide
theorem cert_e2393373435790 : check e2393373435790 [[],[.left],[]] .sourceHead = true := by decide
def e2393373438750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2393373438750 : Closed e2393373438750 ∧ code e2393373438750 = 11189466460958 := by decide
theorem cert_e2393373438750 : check e2393373438750 [[],[.left],[]] .sourceHead = true := by decide
def e2393373438918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2393373438918 : Closed e2393373438918 ∧ code e2393373438918 = 11189466461126 := by decide
theorem cert_e2393373438918 : check e2393373438918 [[],[.left],[]] .sourceHead = true := by decide
def e2393373440398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2393373440398 : Closed e2393373440398 ∧ code e2393373440398 = 11189466462606 := by decide
theorem cert_e2393373440398 : check e2393373440398 [[],[.left],[]] .sourceHead = true := by decide
def e2393373440454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2393373440454 : Closed e2393373440454 ∧ code e2393373440454 = 11189466462662 := by decide
theorem cert_e2393373440454 : check e2393373440454 [[],[.left],[]] .sourceHead = true := by decide
def e2393373454702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2393373454702 : Closed e2393373454702 ∧ code e2393373454702 = 11189466476910 := by decide
theorem cert_e2393373454702 : check e2393373454702 [[],[.left],[]] .sourceHead = true := by decide
def e2393373454710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2393373454710 : Closed e2393373454710 ∧ code e2393373454710 = 11189466476918 := by decide
theorem cert_e2393373454710 : check e2393373454710 [[],[.left],[]] .sourceHead = true := by decide
def e2393373455918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2393373455918 : Closed e2393373455918 ∧ code e2393373455918 = 11189466478126 := by decide
theorem cert_e2393373455918 : check e2393373455918 [[],[.left],[]] .sourceHead = true := by decide
def e2393373456098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2393373456098 : Closed e2393373456098 ∧ code e2393373456098 = 11189466478306 := by decide
theorem cert_e2393373456098 : check e2393373456098 [[],[.left],[]] .sourceHead = true := by decide
def e2393373456110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e2393373456110 : Closed e2393373456110 ∧ code e2393373456110 = 11189466478318 := by decide
theorem cert_e2393373456110 : check e2393373456110 [[],[.left],[]] .sourceHead = true := by decide
def e2393373456150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2393373456150 : Closed e2393373456150 ∧ code e2393373456150 = 11189466478358 := by decide
theorem cert_e2393373456150 : check e2393373456150 [[],[.left],[]] .sourceHead = true := by decide
def e2393373456226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2393373456226 : Closed e2393373456226 ∧ code e2393373456226 = 11189466478434 := by decide
theorem cert_e2393373456226 : check e2393373456226 [[],[.left],[]] .sourceHead = true := by decide
def e2393373456238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e2393373456238 : Closed e2393373456238 ∧ code e2393373456238 = 11189466478446 := by decide
theorem cert_e2393373456238 : check e2393373456238 [[],[.left],[]] .sourceHead = true := by decide
def e2393373456246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e2393373456246 : Closed e2393373456246 ∧ code e2393373456246 = 11189466478454 := by decide
theorem cert_e2393373456246 : check e2393373456246 [[],[.left],[]] .sourceHead = true := by decide
def e2393373456558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2393373456558 : Closed e2393373456558 ∧ code e2393373456558 = 11189466478766 := by decide
theorem cert_e2393373456558 : check e2393373456558 [[],[.left],[]] .sourceHead = true := by decide
def e2393373456570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2393373456570 : Closed e2393373456570 ∧ code e2393373456570 = 11189466478778 := by decide
theorem cert_e2393373456570 : check e2393373456570 [[],[.left],[]] .sourceHead = true := by decide
def e2393373456942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2393373456942 : Closed e2393373456942 ∧ code e2393373456942 = 11189466479150 := by decide
theorem cert_e2393373456942 : check e2393373456942 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2393373457122 : Closed e2393373457122 ∧ code e2393373457122 = 11189466479330 := by decide
theorem cert_e2393373457122 : check e2393373457122 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2393373457134 : Closed e2393373457134 ∧ code e2393373457134 = 11189466479342 := by decide
theorem cert_e2393373457134 : check e2393373457134 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2393373457262 : Closed e2393373457262 ∧ code e2393373457262 = 11189466479470 := by decide
theorem cert_e2393373457262 : check e2393373457262 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2393373457270 : Closed e2393373457270 ∧ code e2393373457270 = 11189466479478 := by decide
theorem cert_e2393373457270 : check e2393373457270 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373457290 : Closed e2393373457290 ∧ code e2393373457290 = 11189466479498 := by decide
theorem cert_e2393373457290 : check e2393373457290 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373457314 : Closed e2393373457314 ∧ code e2393373457314 = 11189466479522 := by decide
theorem cert_e2393373457314 : check e2393373457314 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2393373457326 : Closed e2393373457326 ∧ code e2393373457326 = 11189466479534 := by decide
theorem cert_e2393373457326 : check e2393373457326 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2393373457334 : Closed e2393373457334 ∧ code e2393373457334 = 11189466479542 := by decide
theorem cert_e2393373457334 : check e2393373457334 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2393373457338 : Closed e2393373457338 ∧ code e2393373457338 = 11189466479546 := by decide
theorem cert_e2393373457338 : check e2393373457338 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2393373457494 : Closed e2393373457494 ∧ code e2393373457494 = 11189466479702 := by decide
theorem cert_e2393373457494 : check e2393373457494 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2393373457498 : Closed e2393373457498 ∧ code e2393373457498 = 11189466479706 := by decide
theorem cert_e2393373457498 : check e2393373457498 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2393373457686 : Closed e2393373457686 ∧ code e2393373457686 = 11189466479894 := by decide
theorem cert_e2393373457686 : check e2393373457686 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2393373457762 : Closed e2393373457762 ∧ code e2393373457762 = 11189466479970 := by decide
theorem cert_e2393373457762 : check e2393373457762 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2393373457774 : Closed e2393373457774 ∧ code e2393373457774 = 11189466479982 := by decide
theorem cert_e2393373457774 : check e2393373457774 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2393373457782 : Closed e2393373457782 ∧ code e2393373457782 = 11189466479990 := by decide
theorem cert_e2393373457782 : check e2393373457782 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373457802 : Closed e2393373457802 ∧ code e2393373457802 = 11189466480010 := by decide
theorem cert_e2393373457802 : check e2393373457802 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373457826 : Closed e2393373457826 ∧ code e2393373457826 = 11189466480034 := by decide
theorem cert_e2393373457826 : check e2393373457826 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2393373457838 : Closed e2393373457838 ∧ code e2393373457838 = 11189466480046 := by decide
theorem cert_e2393373457838 : check e2393373457838 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2393373457846 : Closed e2393373457846 ∧ code e2393373457846 = 11189466480054 := by decide
theorem cert_e2393373457846 : check e2393373457846 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2393373457850 : Closed e2393373457850 ∧ code e2393373457850 = 11189466480058 := by decide
theorem cert_e2393373457850 : check e2393373457850 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2393373457878 : Closed e2393373457878 ∧ code e2393373457878 = 11189466480086 := by decide
theorem cert_e2393373457878 : check e2393373457878 [[],[.left],[]] .sourceHead = true := by decide
def e2393373457882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2393373457882 : Closed e2393373457882 ∧ code e2393373457882 = 11189466480090 := by decide
theorem cert_e2393373457882 : check e2393373457882 [[],[.left],[]] .sourceHead = true := by decide
def e2393373458926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e2393373458926 : Closed e2393373458926 ∧ code e2393373458926 = 11189466481134 := by decide
theorem cert_e2393373458926 : check e2393373458926 [[],[.left],[]] .sourceHead = true := by decide
def e2393373458934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e2393373458934 : Closed e2393373458934 ∧ code e2393373458934 = 11189466481142 := by decide
theorem cert_e2393373458934 : check e2393373458934 [[],[.left],[]] .sourceHead = true := by decide
def e2393373459694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373459694 : Closed e2393373459694 ∧ code e2393373459694 = 11189466481902 := by decide
theorem cert_e2393373459694 : check e2393373459694 [[],[.left],[]] .sourceHead = true := by decide
def e2393373459702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373459702 : Closed e2393373459702 ∧ code e2393373459702 = 11189466481910 := by decide
theorem cert_e2393373459702 : check e2393373459702 [[],[.left],[]] .sourceHead = true := by decide
def e2393373460254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2393373460254 : Closed e2393373460254 ∧ code e2393373460254 = 11189466482462 := by decide
theorem cert_e2393373460254 : check e2393373460254 [[],[.left],[]] .sourceHead = true := by decide
def e2393373460366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2393373460366 : Closed e2393373460366 ∧ code e2393373460366 = 11189466482574 := by decide
theorem cert_e2393373460366 : check e2393373460366 [[],[.left],[]] .sourceHead = true := by decide
def e2393373462062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2393373462062 : Closed e2393373462062 ∧ code e2393373462062 = 11189466484270 := by decide
theorem cert_e2393373462062 : check e2393373462062 [[],[.left],[]] .sourceHead = true := by decide
def e2393373462242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2393373462242 : Closed e2393373462242 ∧ code e2393373462242 = 11189466484450 := by decide
theorem cert_e2393373462242 : check e2393373462242 [[],[.left],[]] .sourceHead = true := by decide
def e2393373462254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2393373462254 : Closed e2393373462254 ∧ code e2393373462254 = 11189466484462 := by decide
theorem cert_e2393373462254 : check e2393373462254 [[],[.left],[]] .sourceHead = true := by decide
def e2393373462294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2393373462294 : Closed e2393373462294 ∧ code e2393373462294 = 11189466484502 := by decide
theorem cert_e2393373462294 : check e2393373462294 [[],[.left],[]] .sourceHead = true := by decide
def e2393373462370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2393373462370 : Closed e2393373462370 ∧ code e2393373462370 = 11189466484578 := by decide
theorem cert_e2393373462370 : check e2393373462370 [[],[.left],[]] .sourceHead = true := by decide
def e2393373462382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2393373462382 : Closed e2393373462382 ∧ code e2393373462382 = 11189466484590 := by decide
theorem cert_e2393373462382 : check e2393373462382 [[],[.left],[]] .sourceHead = true := by decide
def e2393373462390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e2393373462390 : Closed e2393373462390 ∧ code e2393373462390 = 11189466484598 := by decide
theorem cert_e2393373462390 : check e2393373462390 [[],[.left],[]] .sourceHead = true := by decide
def e2393373464638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e2393373464638 : Closed e2393373464638 ∧ code e2393373464638 = 11189466486846 := by decide
theorem cert_e2393373464638 : check e2393373464638 [[],[.left],[]] .sourceHead = true := by decide
def e2393373465058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2393373465058 : Closed e2393373465058 ∧ code e2393373465058 = 11189466487266 := by decide
theorem cert_e2393373465058 : check e2393373465058 [[],[.left],[]] .sourceHead = true := by decide
def e2393373465070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e2393373465070 : Closed e2393373465070 ∧ code e2393373465070 = 11189466487278 := by decide
theorem cert_e2393373465070 : check e2393373465070 [[],[.left],[]] .sourceHead = true := by decide
def e2393373465630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e2393373465630 : Closed e2393373465630 ∧ code e2393373465630 = 11189466487838 := by decide
theorem cert_e2393373465630 : check e2393373465630 [[],[.left],[]] .sourceHead = true := by decide
def e2393373465826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2393373465826 : Closed e2393373465826 ∧ code e2393373465826 = 11189466488034 := by decide
theorem cert_e2393373465826 : check e2393373465826 [[],[.left],[]] .sourceHead = true := by decide
def e2393373465838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373465838 : Closed e2393373465838 ∧ code e2393373465838 = 11189466488046 := by decide
theorem cert_e2393373465838 : check e2393373465838 [[],[.left],[]] .sourceHead = true := by decide
def e2393373465846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373465846 : Closed e2393373465846 ∧ code e2393373465846 = 11189466488054 := by decide
theorem cert_e2393373465846 : check e2393373465846 [[],[.left],[]] .sourceHead = true := by decide
def e2393373466862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2393373466862 : Closed e2393373466862 ∧ code e2393373466862 = 11189466489070 := by decide
theorem cert_e2393373466862 : check e2393373466862 [[],[.left],[]] .sourceHead = true := by decide
def e2393373466874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2393373466874 : Closed e2393373466874 ∧ code e2393373466874 = 11189466489082 := by decide
theorem cert_e2393373466874 : check e2393373466874 [[],[.left],[]] .sourceHead = true := by decide
def e2393373467054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2393373467054 : Closed e2393373467054 ∧ code e2393373467054 = 11189466489262 := by decide
theorem cert_e2393373467054 : check e2393373467054 [[],[.left],[]] .sourceHead = true := by decide
def e2393373467246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373467246 : Closed e2393373467246 ∧ code e2393373467246 = 11189466489454 := by decide
theorem cert_e2393373467246 : check e2393373467246 [[],[.left],[]] .sourceHead = true := by decide
def e2393373467258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373467258 : Closed e2393373467258 ∧ code e2393373467258 = 11189466489466 := by decide
theorem cert_e2393373467258 : check e2393373467258 [[],[.left],[]] .sourceHead = true := by decide
def e2393373467422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2393373467422 : Closed e2393373467422 ∧ code e2393373467422 = 11189466489630 := by decide
theorem cert_e2393373467422 : check e2393373467422 [[],[.left],[]] .sourceHead = true := by decide
def e2393373467590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2393373467590 : Closed e2393373467590 ∧ code e2393373467590 = 11189466489798 := by decide
theorem cert_e2393373467590 : check e2393373467590 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2393373468206 : Closed e2393373468206 ∧ code e2393373468206 = 11189466490414 := by decide
theorem cert_e2393373468206 : check e2393373468206 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2393373468386 : Closed e2393373468386 ∧ code e2393373468386 = 11189466490594 := by decide
theorem cert_e2393373468386 : check e2393373468386 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2393373468398 : Closed e2393373468398 ∧ code e2393373468398 = 11189466490606 := by decide
theorem cert_e2393373468398 : check e2393373468398 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2393373468526 : Closed e2393373468526 ∧ code e2393373468526 = 11189466490734 := by decide
theorem cert_e2393373468526 : check e2393373468526 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2393373468534 : Closed e2393373468534 ∧ code e2393373468534 = 11189466490742 := by decide
theorem cert_e2393373468534 : check e2393373468534 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2393373468554 : Closed e2393373468554 ∧ code e2393373468554 = 11189466490762 := by decide
theorem cert_e2393373468554 : check e2393373468554 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2393373468578 : Closed e2393373468578 ∧ code e2393373468578 = 11189466490786 := by decide
theorem cert_e2393373468578 : check e2393373468578 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2393373468590 : Closed e2393373468590 ∧ code e2393373468590 = 11189466490798 := by decide
theorem cert_e2393373468590 : check e2393373468590 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2393373468598 : Closed e2393373468598 ∧ code e2393373468598 = 11189466490806 := by decide
theorem cert_e2393373468598 : check e2393373468598 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2393373468602 : Closed e2393373468602 ∧ code e2393373468602 = 11189466490810 := by decide
theorem cert_e2393373468602 : check e2393373468602 [[],[.left],[]] .sourceHead = true := by decide
def e2393373468734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2393373468734 : Closed e2393373468734 ∧ code e2393373468734 = 11189466490942 := by decide
theorem cert_e2393373468734 : check e2393373468734 [[],[.left],[]] .sourceHead = true := by decide
def e2393373469154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2393373469154 : Closed e2393373469154 ∧ code e2393373469154 = 11189466491362 := by decide
theorem cert_e2393373469154 : check e2393373469154 [[],[.left],[]] .sourceHead = true := by decide
def e2393373469166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2393373469166 : Closed e2393373469166 ∧ code e2393373469166 = 11189466491374 := by decide
theorem cert_e2393373469166 : check e2393373469166 [[],[.left],[]] .sourceHead = true := by decide
def e2393373469934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373469934 : Closed e2393373469934 ∧ code e2393373469934 = 11189466492142 := by decide
theorem cert_e2393373469934 : check e2393373469934 [[],[.left],[]] .sourceHead = true := by decide
def e2393373469942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373469942 : Closed e2393373469942 ∧ code e2393373469942 = 11189466492150 := by decide
theorem cert_e2393373469942 : check e2393373469942 [[],[.left],[]] .sourceHead = true := by decide
def e2393373470222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2393373470222 : Closed e2393373470222 ∧ code e2393373470222 = 11189466492430 := by decide
theorem cert_e2393373470222 : check e2393373470222 [[],[.left],[]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393373400278
#print axioms Blc.Floor43.cert_e2393373400282
#print axioms Blc.Floor43.cert_e2393373400298
#print axioms Blc.Floor43.cert_e2393373400374
#print axioms Blc.Floor43.cert_e2393373400378
#print axioms Blc.Floor43.cert_e2393373400474
