import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e756169109018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169109018 : Closed e756169109018 ∧ code e756169109018 = 9552262131226 := by decide
theorem cert_e756169109018 : check e756169109018 [] .sourceHead = true := by decide
def e756169111066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169111066 : Closed e756169111066 ∧ code e756169111066 = 9552262133274 := by decide
theorem cert_e756169111066 : check e756169111066 [] .sourceHead = true := by decide
def e756169233946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169233946 : Closed e756169233946 ∧ code e756169233946 = 9552262256154 := by decide
theorem cert_e756169233946 : check e756169233946 [] .sourceHead = true := by decide
def e756169234970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169234970 : Closed e756169234970 ∧ code e756169234970 = 9552262257178 := by decide
theorem cert_e756169234970 : check e756169234970 [] .sourceHead = true := by decide
def e756169239066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169239066 : Closed e756169239066 ∧ code e756169239066 = 9552262261274 := by decide
theorem cert_e756169239066 : check e756169239066 [] .sourceHead = true := by decide
def e756169258522 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169258522 : Closed e756169258522 ∧ code e756169258522 = 9552262280730 := by decide
theorem cert_e756169258522 : check e756169258522 [] .sourceHead = true := by decide
def e756169259546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169259546 : Closed e756169259546 ∧ code e756169259546 = 9552262281754 := by decide
theorem cert_e756169259546 : check e756169259546 [] .sourceHead = true := by decide
def e756169269274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756169269274 : Closed e756169269274 ∧ code e756169269274 = 9552262291482 := by decide
theorem cert_e756169269274 : check e756169269274 [] .sourceHead = true := by decide
def e756169269366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756169269366 : Closed e756169269366 ∧ code e756169269366 = 9552262291574 := by decide
theorem cert_e756169269366 : check e756169269366 [] .sourceHead = true := by decide
def e756169269610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756169269610 : Closed e756169269610 ∧ code e756169269610 = 9552262291818 := by decide
theorem cert_e756169269610 : check e756169269610 [] .sourceHead = true := by decide
def e756169269658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756169269658 : Closed e756169269658 ∧ code e756169269658 = 9552262291866 := by decide
theorem cert_e756169269658 : check e756169269658 [] .sourceHead = true := by decide
def e756169270810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169270810 : Closed e756169270810 ∧ code e756169270810 = 9552262293018 := by decide
theorem cert_e756169270810 : check e756169270810 [] .sourceHead = true := by decide
def e756169281050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169281050 : Closed e756169281050 ∧ code e756169281050 = 9552262303258 := by decide
theorem cert_e756169281050 : check e756169281050 [] .sourceHead = true := by decide
def e756169284122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169284122 : Closed e756169284122 ∧ code e756169284122 = 9552262306330 := by decide
theorem cert_e756169284122 : check e756169284122 [] .sourceHead = true := by decide
def e756169285658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756169285658 : Closed e756169285658 ∧ code e756169285658 = 9552262307866 := by decide
theorem cert_e756169285658 : check e756169285658 [] .sourceHead = true := by decide
def e756169285750 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756169285750 : Closed e756169285750 ∧ code e756169285750 = 9552262307958 := by decide
theorem cert_e756169285750 : check e756169285750 [] .sourceHead = true := by decide
def e756169285994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756169285994 : Closed e756169285994 ∧ code e756169285994 = 9552262308202 := by decide
theorem cert_e756169285994 : check e756169285994 [] .sourceHead = true := by decide
def e756169286042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756169286042 : Closed e756169286042 ∧ code e756169286042 = 9552262308250 := by decide
theorem cert_e756169286042 : check e756169286042 [] .sourceHead = true := by decide
def e756169287194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169287194 : Closed e756169287194 ∧ code e756169287194 = 9552262309402 := by decide
theorem cert_e756169287194 : check e756169287194 [] .sourceHead = true := by decide
def e756169289926 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756169289926 : Closed e756169289926 ∧ code e756169289926 = 9552262312134 := by decide
theorem cert_e756169289926 : check e756169289926 [] .sourceHead = true := by decide
def e756169291802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169291802 : Closed e756169291802 ∧ code e756169291802 = 9552262314010 := by decide
theorem cert_e756169291802 : check e756169291802 [] .sourceHead = true := by decide
def e756169299994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169299994 : Closed e756169299994 ∧ code e756169299994 = 9552262322202 := by decide
theorem cert_e756169299994 : check e756169299994 [] .sourceHead = true := by decide
def e756169602586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169602586 : Closed e756169602586 ∧ code e756169602586 = 9552262624794 := by decide
theorem cert_e756169602586 : check e756169602586 [] .sourceHead = true := by decide
def e756169665050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169665050 : Closed e756169665050 ∧ code e756169665050 = 9552262687258 := by decide
theorem cert_e756169665050 : check e756169665050 [] .sourceHead = true := by decide
def e756169674266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169674266 : Closed e756169674266 ∧ code e756169674266 = 9552262696474 := by decide
theorem cert_e756169674266 : check e756169674266 [] .sourceHead = true := by decide
def e756169677338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169677338 : Closed e756169677338 ∧ code e756169677338 = 9552262699546 := by decide
theorem cert_e756169677338 : check e756169677338 [] .sourceHead = true := by decide
def e756169678874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756169678874 : Closed e756169678874 ∧ code e756169678874 = 9552262701082 := by decide
theorem cert_e756169678874 : check e756169678874 [] .sourceHead = true := by decide
def e756169678966 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756169678966 : Closed e756169678966 ∧ code e756169678966 = 9552262701174 := by decide
theorem cert_e756169678966 : check e756169678966 [] .sourceHead = true := by decide
def e756169679210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756169679210 : Closed e756169679210 ∧ code e756169679210 = 9552262701418 := by decide
theorem cert_e756169679210 : check e756169679210 [] .sourceHead = true := by decide
def e756169679258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756169679258 : Closed e756169679258 ∧ code e756169679258 = 9552262701466 := by decide
theorem cert_e756169679258 : check e756169679258 [] .sourceHead = true := by decide
def e756169680410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169680410 : Closed e756169680410 ∧ code e756169680410 = 9552262702618 := by decide
theorem cert_e756169680410 : check e756169680410 [] .sourceHead = true := by decide
def e756169683142 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756169683142 : Closed e756169683142 ∧ code e756169683142 = 9552262705350 := by decide
theorem cert_e756169683142 : check e756169683142 [] .sourceHead = true := by decide
def e756169685018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169685018 : Closed e756169685018 ∧ code e756169685018 = 9552262707226 := by decide
theorem cert_e756169685018 : check e756169685018 [] .sourceHead = true := by decide
def e756169688602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756169688602 : Closed e756169688602 ∧ code e756169688602 = 9552262710810 := by decide
theorem cert_e756169688602 : check e756169688602 [] .sourceHead = true := by decide
def e756169691334 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756169691334 : Closed e756169691334 ∧ code e756169691334 = 9552262713542 := by decide
theorem cert_e756169691334 : check e756169691334 [] .sourceHead = true := by decide
def e756169697306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169697306 : Closed e756169697306 ∧ code e756169697306 = 9552262719514 := by decide
theorem cert_e756169697306 : check e756169697306 [] .sourceHead = true := by decide
def e756169889818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169889818 : Closed e756169889818 ∧ code e756169889818 = 9552262912026 := by decide
theorem cert_e756169889818 : check e756169889818 [] .sourceHead = true := by decide
def e756169893914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756169893914 : Closed e756169893914 ∧ code e756169893914 = 9552262916122 := by decide
theorem cert_e756169893914 : check e756169893914 [] .sourceHead = true := by decide
def e756505818554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e756505818554 : Closed e756505818554 ∧ code e756505818554 = 9552598840762 := by decide
theorem cert_e756505818554 : check e756505818554 [] .sourceHead = true := by decide
def e756505818586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e756505818586 : Closed e756505818586 ∧ code e756505818586 = 9552598840794 := by decide
theorem cert_e756505818586 : check e756505818586 [] .sourceHead = true := by decide
def e756505818810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e756505818810 : Closed e756505818810 ∧ code e756505818810 = 9552598841018 := by decide
theorem cert_e756505818810 : check e756505818810 [] .sourceHead = true := by decide
def e756505818858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e756505818858 : Closed e756505818858 ∧ code e756505818858 = 9552598841066 := by decide
theorem cert_e756505818858 : check e756505818858 [] .sourceHead = true := by decide
def e756505818970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e756505818970 : Closed e756505818970 ∧ code e756505818970 = 9552598841178 := by decide
theorem cert_e756505818970 : check e756505818970 [] .sourceHead = true := by decide
def e756505818986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e756505818986 : Closed e756505818986 ∧ code e756505818986 = 9552598841194 := by decide
theorem cert_e756505818986 : check e756505818986 [] .sourceHead = true := by decide
def e756505819834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e756505819834 : Closed e756505819834 ∧ code e756505819834 = 9552598842042 := by decide
theorem cert_e756505819834 : check e756505819834 [] .sourceHead = true := by decide
def e756505819882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e756505819882 : Closed e756505819882 ∧ code e756505819882 = 9552598842090 := by decide
theorem cert_e756505819882 : check e756505819882 [] .sourceHead = true := by decide
def e756505820074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e756505820074 : Closed e756505820074 ∧ code e756505820074 = 9552598842282 := by decide
theorem cert_e756505820074 : check e756505820074 [] .sourceHead = true := by decide
def e756505820506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e756505820506 : Closed e756505820506 ∧ code e756505820506 = 9552598842714 := by decide
theorem cert_e756505820506 : check e756505820506 [] .sourceHead = true := by decide
def e756505820522 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e756505820522 : Closed e756505820522 ∧ code e756505820522 = 9552598842730 := by decide
theorem cert_e756505820522 : check e756505820522 [] .sourceHead = true := by decide
def e756505820586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e756505820586 : Closed e756505820586 ∧ code e756505820586 = 9552598842794 := by decide
theorem cert_e756505820586 : check e756505820586 [] .sourceHead = true := by decide
def e756505824698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e756505824698 : Closed e756505824698 ∧ code e756505824698 = 9552598846906 := by decide
theorem cert_e756505824698 : check e756505824698 [] .sourceHead = true := by decide
def e756505824730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e756505824730 : Closed e756505824730 ∧ code e756505824730 = 9552598846938 := by decide
theorem cert_e756505824730 : check e756505824730 [] .sourceHead = true := by decide
def e756505824954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e756505824954 : Closed e756505824954 ∧ code e756505824954 = 9552598847162 := by decide
theorem cert_e756505824954 : check e756505824954 [] .sourceHead = true := by decide
def e756505825002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e756505825002 : Closed e756505825002 ∧ code e756505825002 = 9552598847210 := by decide
theorem cert_e756505825002 : check e756505825002 [] .sourceHead = true := by decide
def e756505825114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e756505825114 : Closed e756505825114 ∧ code e756505825114 = 9552598847322 := by decide
theorem cert_e756505825114 : check e756505825114 [] .sourceHead = true := by decide
def e756505825130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e756505825130 : Closed e756505825130 ∧ code e756505825130 = 9552598847338 := by decide
theorem cert_e756505825130 : check e756505825130 [] .sourceHead = true := by decide
def e756505826234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e756505826234 : Closed e756505826234 ∧ code e756505826234 = 9552598848442 := by decide
theorem cert_e756505826234 : check e756505826234 [] .sourceHead = true := by decide
def e756505826266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e756505826266 : Closed e756505826266 ∧ code e756505826266 = 9552598848474 := by decide
theorem cert_e756505826266 : check e756505826266 [] .sourceHead = true := by decide
def e756505827770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e756505827770 : Closed e756505827770 ∧ code e756505827770 = 9552598849978 := by decide
theorem cert_e756505827770 : check e756505827770 [] .sourceHead = true := by decide
def e756505827818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e756505827818 : Closed e756505827818 ∧ code e756505827818 = 9552598850026 := by decide
theorem cert_e756505827818 : check e756505827818 [] .sourceHead = true := by decide
def e756505828570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e756505828570 : Closed e756505828570 ∧ code e756505828570 = 9552598850778 := by decide
theorem cert_e756505828570 : check e756505828570 [] .sourceHead = true := by decide
def e756505828586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e756505828586 : Closed e756505828586 ∧ code e756505828586 = 9552598850794 := by decide
theorem cert_e756505828586 : check e756505828586 [] .sourceHead = true := by decide
def e756505831098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e756505831098 : Closed e756505831098 ∧ code e756505831098 = 9552598853306 := by decide
theorem cert_e756505831098 : check e756505831098 [] .sourceHead = true := by decide
def e756505831146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e756505831146 : Closed e756505831146 ∧ code e756505831146 = 9552598853354 := by decide
theorem cert_e756505831146 : check e756505831146 [] .sourceHead = true := by decide
def e756505831338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e756505831338 : Closed e756505831338 ∧ code e756505831338 = 9552598853546 := by decide
theorem cert_e756505831338 : check e756505831338 [] .sourceHead = true := by decide
def e756505831866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e756505831866 : Closed e756505831866 ∧ code e756505831866 = 9552598854074 := by decide
theorem cert_e756505831866 : check e756505831866 [] .sourceHead = true := by decide
def e756505831914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e756505831914 : Closed e756505831914 ∧ code e756505831914 = 9552598854122 := by decide
theorem cert_e756505831914 : check e756505831914 [] .sourceHead = true := by decide
def e756505833066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e756505833066 : Closed e756505833066 ∧ code e756505833066 = 9552598855274 := by decide
theorem cert_e756505833066 : check e756505833066 [] .sourceHead = true := by decide
def e756505834330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e756505834330 : Closed e756505834330 ∧ code e756505834330 = 9552598856538 := by decide
theorem cert_e756505834330 : check e756505834330 [] .sourceHead = true := by decide
def e756505834346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e756505834346 : Closed e756505834346 ∧ code e756505834346 = 9552598856554 := by decide
theorem cert_e756505834346 : check e756505834346 [] .sourceHead = true := by decide
def e756505834410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e756505834410 : Closed e756505834410 ∧ code e756505834410 = 9552598856618 := by decide
theorem cert_e756505834410 : check e756505834410 [] .sourceHead = true := by decide
def e756505834714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e756505834714 : Closed e756505834714 ∧ code e756505834714 = 9552598856922 := by decide
theorem cert_e756505834714 : check e756505834714 [] .sourceHead = true := by decide
def e756505834730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e756505834730 : Closed e756505834730 ∧ code e756505834730 = 9552598856938 := by decide
theorem cert_e756505834730 : check e756505834730 [] .sourceHead = true := by decide
def e756505835114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e756505835114 : Closed e756505835114 ∧ code e756505835114 = 9552598857322 := by decide
theorem cert_e756505835114 : check e756505835114 [] .sourceHead = true := by decide
def e756505849274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e756505849274 : Closed e756505849274 ∧ code e756505849274 = 9552598871482 := by decide
theorem cert_e756505849274 : check e756505849274 [] .sourceHead = true := by decide
def e756505849306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e756505849306 : Closed e756505849306 ∧ code e756505849306 = 9552598871514 := by decide
theorem cert_e756505849306 : check e756505849306 [] .sourceHead = true := by decide
def e756505849530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e756505849530 : Closed e756505849530 ∧ code e756505849530 = 9552598871738 := by decide
theorem cert_e756505849530 : check e756505849530 [] .sourceHead = true := by decide
def e756505849578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e756505849578 : Closed e756505849578 ∧ code e756505849578 = 9552598871786 := by decide
theorem cert_e756505849578 : check e756505849578 [] .sourceHead = true := by decide
def e756505849690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e756505849690 : Closed e756505849690 ∧ code e756505849690 = 9552598871898 := by decide
theorem cert_e756505849690 : check e756505849690 [] .sourceHead = true := by decide
def e756505849706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e756505849706 : Closed e756505849706 ∧ code e756505849706 = 9552598871914 := by decide
theorem cert_e756505849706 : check e756505849706 [] .sourceHead = true := by decide
def e756505850810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e756505850810 : Closed e756505850810 ∧ code e756505850810 = 9552598873018 := by decide
theorem cert_e756505850810 : check e756505850810 [] .sourceHead = true := by decide
def e756505850842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e756505850842 : Closed e756505850842 ∧ code e756505850842 = 9552598873050 := by decide
theorem cert_e756505850842 : check e756505850842 [] .sourceHead = true := by decide
def e756505852346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e756505852346 : Closed e756505852346 ∧ code e756505852346 = 9552598874554 := by decide
theorem cert_e756505852346 : check e756505852346 [] .sourceHead = true := by decide
def e756505852394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e756505852394 : Closed e756505852394 ∧ code e756505852394 = 9552598874602 := by decide
theorem cert_e756505852394 : check e756505852394 [] .sourceHead = true := by decide
def e756505853146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e756505853146 : Closed e756505853146 ∧ code e756505853146 = 9552598875354 := by decide
theorem cert_e756505853146 : check e756505853146 [] .sourceHead = true := by decide
def e756505853162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e756505853162 : Closed e756505853162 ∧ code e756505853162 = 9552598875370 := by decide
theorem cert_e756505853162 : check e756505853162 [] .sourceHead = true := by decide
def e756505876154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e756505876154 : Closed e756505876154 ∧ code e756505876154 = 9552598898362 := by decide
theorem cert_e756505876154 : check e756505876154 [] .sourceHead = true := by decide
def e756505876202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e756505876202 : Closed e756505876202 ∧ code e756505876202 = 9552598898410 := by decide
theorem cert_e756505876202 : check e756505876202 [] .sourceHead = true := by decide
def e756505876394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e756505876394 : Closed e756505876394 ∧ code e756505876394 = 9552598898602 := by decide
theorem cert_e756505876394 : check e756505876394 [] .sourceHead = true := by decide
def e756505876922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e756505876922 : Closed e756505876922 ∧ code e756505876922 = 9552598899130 := by decide
theorem cert_e756505876922 : check e756505876922 [] .sourceHead = true := by decide
def e756505876970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e756505876970 : Closed e756505876970 ∧ code e756505876970 = 9552598899178 := by decide
theorem cert_e756505876970 : check e756505876970 [] .sourceHead = true := by decide
def e756505878122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e756505878122 : Closed e756505878122 ∧ code e756505878122 = 9552598900330 := by decide
theorem cert_e756505878122 : check e756505878122 [] .sourceHead = true := by decide
def e756505889626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e756505889626 : Closed e756505889626 ∧ code e756505889626 = 9552598911834 := by decide
theorem cert_e756505889626 : check e756505889626 [] .sourceHead = true := by decide
def e756505889642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e756505889642 : Closed e756505889642 ∧ code e756505889642 = 9552598911850 := by decide
theorem cert_e756505889642 : check e756505889642 [] .sourceHead = true := by decide
def e756505889706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e756505889706 : Closed e756505889706 ∧ code e756505889706 = 9552598911914 := by decide
theorem cert_e756505889706 : check e756505889706 [] .sourceHead = true := by decide
def e756505890010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e756505890010 : Closed e756505890010 ∧ code e756505890010 = 9552598912218 := by decide
theorem cert_e756505890010 : check e756505890010 [] .sourceHead = true := by decide
def e756505890026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e756505890026 : Closed e756505890026 ∧ code e756505890026 = 9552598912234 := by decide
theorem cert_e756505890026 : check e756505890026 [] .sourceHead = true := by decide
def e756505890410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e756505890410 : Closed e756505890410 ∧ code e756505890410 = 9552598912618 := by decide
theorem cert_e756505890410 : check e756505890410 [] .sourceHead = true := by decide
def e756655438362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756655438362 : Closed e756655438362 ∧ code e756655438362 = 9552748460570 := by decide
theorem cert_e756655438362 : check e756655438362 [] .sourceHead = true := by decide
def e756655446554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756655446554 : Closed e756655446554 ∧ code e756655446554 = 9552748468762 := by decide
theorem cert_e756655446554 : check e756655446554 [] .sourceHead = true := by decide
def e756655503898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756655503898 : Closed e756655503898 ∧ code e756655503898 = 9552748526106 := by decide
theorem cert_e756655503898 : check e756655503898 [] .sourceHead = true := by decide
def e756655516186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756655516186 : Closed e756655516186 ∧ code e756655516186 = 9552748538394 := by decide
theorem cert_e756655516186 : check e756655516186 [] .sourceHead = true := by decide
def e756655544858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756655544858 : Closed e756655544858 ∧ code e756655544858 = 9552748567066 := by decide
theorem cert_e756655544858 : check e756655544858 [] .sourceHead = true := by decide
def e756655548954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756655548954 : Closed e756655548954 ∧ code e756655548954 = 9552748571162 := by decide
theorem cert_e756655548954 : check e756655548954 [] .sourceHead = true := by decide
def e756655831578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756655831578 : Closed e756655831578 ∧ code e756655831578 = 9552748853786 := by decide
theorem cert_e756655831578 : check e756655831578 [] .sourceHead = true := by decide
def e756655839770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756655839770 : Closed e756655839770 ∧ code e756655839770 = 9552748861978 := by decide
theorem cert_e756655839770 : check e756655839770 [] .sourceHead = true := by decide
def e756656224794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756656224794 : Closed e756656224794 ∧ code e756656224794 = 9552749247002 := by decide
theorem cert_e756656224794 : check e756656224794 [] .sourceHead = true := by decide
def e756656237082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756656237082 : Closed e756656237082 ∧ code e756656237082 = 9552749259290 := by decide
theorem cert_e756656237082 : check e756656237082 [] .sourceHead = true := by decide
def e756656429594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756656429594 : Closed e756656429594 ∧ code e756656429594 = 9552749451802 := by decide
theorem cert_e756656429594 : check e756656429594 [] .sourceHead = true := by decide
def e756656433690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756656433690 : Closed e756656433690 ∧ code e756656433690 = 9552749455898 := by decide
theorem cert_e756656433690 : check e756656433690 [] .sourceHead = true := by decide
def e756669967898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756669967898 : Closed e756669967898 ∧ code e756669967898 = 9552762990106 := by decide
theorem cert_e756669967898 : check e756669967898 [] .sourceHead = true := by decide
def e756669969946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756669969946 : Closed e756669969946 ∧ code e756669969946 = 9552762992154 := by decide
theorem cert_e756669969946 : check e756669969946 [] .sourceHead = true := by decide
def e756669984282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756669984282 : Closed e756669984282 ∧ code e756669984282 = 9552763006490 := by decide
theorem cert_e756669984282 : check e756669984282 [] .sourceHead = true := by decide
def e756669987354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756669987354 : Closed e756669987354 ∧ code e756669987354 = 9552763009562 := by decide
theorem cert_e756669987354 : check e756669987354 [] .sourceHead = true := by decide
def e756669994522 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756669994522 : Closed e756669994522 ∧ code e756669994522 = 9552763016730 := by decide
theorem cert_e756669994522 : check e756669994522 [] .sourceHead = true := by decide
def e756669995546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756669995546 : Closed e756669995546 ∧ code e756669995546 = 9552763017754 := by decide
theorem cert_e756669995546 : check e756669995546 [] .sourceHead = true := by decide
def e756670066202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756670066202 : Closed e756670066202 ∧ code e756670066202 = 9552763088410 := by decide
theorem cert_e756670066202 : check e756670066202 [] .sourceHead = true := by decide
def e756670068250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756670068250 : Closed e756670068250 ∧ code e756670068250 = 9552763090458 := by decide
theorem cert_e756670068250 : check e756670068250 [] .sourceHead = true := by decide
def e756670164506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756670164506 : Closed e756670164506 ∧ code e756670164506 = 9552763186714 := by decide
theorem cert_e756670164506 : check e756670164506 [] .sourceHead = true := by decide
def e756670167578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756670167578 : Closed e756670167578 ∧ code e756670167578 = 9552763189786 := by decide
theorem cert_e756670167578 : check e756670167578 [] .sourceHead = true := by decide
def e756670215706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756670215706 : Closed e756670215706 ∧ code e756670215706 = 9552763237914 := by decide
theorem cert_e756670215706 : check e756670215706 [] .sourceHead = true := by decide
def e756670216730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756670216730 : Closed e756670216730 ∧ code e756670216730 = 9552763238938 := by decide
theorem cert_e756670216730 : check e756670216730 [] .sourceHead = true := by decide
def e756722546714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756722546714 : Closed e756722546714 ∧ code e756722546714 = 9552815568922 := by decide
theorem cert_e756722546714 : check e756722546714 [] .sourceHead = true := by decide
def e756722554906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756722554906 : Closed e756722554906 ∧ code e756722554906 = 9552815577114 := by decide
theorem cert_e756722554906 : check e756722554906 [] .sourceHead = true := by decide
def e756722556442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756722556442 : Closed e756722556442 ∧ code e756722556442 = 9552815578650 := by decide
theorem cert_e756722556442 : check e756722556442 [] .sourceHead = true := by decide
def e756722560538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756722560538 : Closed e756722560538 ∧ code e756722560538 = 9552815582746 := by decide
theorem cert_e756722560538 : check e756722560538 [] .sourceHead = true := by decide
def e756722612250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756722612250 : Closed e756722612250 ∧ code e756722612250 = 9552815634458 := by decide
theorem cert_e756722612250 : check e756722612250 [] .sourceHead = true := by decide
def e756722624538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756722624538 : Closed e756722624538 ∧ code e756722624538 = 9552815646746 := by decide
theorem cert_e756722624538 : check e756722624538 [] .sourceHead = true := by decide
def e756722653210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756722653210 : Closed e756722653210 ∧ code e756722653210 = 9552815675418 := by decide
theorem cert_e756722653210 : check e756722653210 [] .sourceHead = true := by decide
def e756722654746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756722654746 : Closed e756722654746 ∧ code e756722654746 = 9552815676954 := by decide
theorem cert_e756722654746 : check e756722654746 [] .sourceHead = true := by decide
def e756722657306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756722657306 : Closed e756722657306 ∧ code e756722657306 = 9552815679514 := by decide
theorem cert_e756722657306 : check e756722657306 [] .sourceHead = true := by decide
def e756722661914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756722661914 : Closed e756722661914 ∧ code e756722661914 = 9552815684122 := by decide
theorem cert_e756722661914 : check e756722661914 [] .sourceHead = true := by decide
def e756722675226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756722675226 : Closed e756722675226 ∧ code e756722675226 = 9552815697434 := by decide
theorem cert_e756722675226 : check e756722675226 [] .sourceHead = true := by decide
def e756722678298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756722678298 : Closed e756722678298 ∧ code e756722678298 = 9552815700506 := by decide
theorem cert_e756722678298 : check e756722678298 [] .sourceHead = true := by decide
def e756722939930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756722939930 : Closed e756722939930 ∧ code e756722939930 = 9552815962138 := by decide
theorem cert_e756722939930 : check e756722939930 [] .sourceHead = true := by decide
def e756722948122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756722948122 : Closed e756722948122 ∧ code e756722948122 = 9552815970330 := by decide
theorem cert_e756722948122 : check e756722948122 [] .sourceHead = true := by decide
def e756722949658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756722949658 : Closed e756722949658 ∧ code e756722949658 = 9552815971866 := by decide
theorem cert_e756722949658 : check e756722949658 [] .sourceHead = true := by decide
def e756722953754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756722953754 : Closed e756722953754 ∧ code e756722953754 = 9552815975962 := by decide
theorem cert_e756722953754 : check e756722953754 [] .sourceHead = true := by decide
def e756723333146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756723333146 : Closed e756723333146 ∧ code e756723333146 = 9552816355354 := by decide
theorem cert_e756723333146 : check e756723333146 [] .sourceHead = true := by decide
def e756723345434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756723345434 : Closed e756723345434 ∧ code e756723345434 = 9552816367642 := by decide
theorem cert_e756723345434 : check e756723345434 [] .sourceHead = true := by decide
def e756723537946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756723537946 : Closed e756723537946 ∧ code e756723537946 = 9552816560154 := by decide
theorem cert_e756723537946 : check e756723537946 [] .sourceHead = true := by decide
def e756723539482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756723539482 : Closed e756723539482 ∧ code e756723539482 = 9552816561690 := by decide
theorem cert_e756723539482 : check e756723539482 [] .sourceHead = true := by decide
def e756723542042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756723542042 : Closed e756723542042 ∧ code e756723542042 = 9552816564250 := by decide
theorem cert_e756723542042 : check e756723542042 [] .sourceHead = true := by decide
def e756723546650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756723546650 : Closed e756723546650 ∧ code e756723546650 = 9552816568858 := by decide
theorem cert_e756723546650 : check e756723546650 [] .sourceHead = true := by decide
def e756723641882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756723641882 : Closed e756723641882 ∧ code e756723641882 = 9552816664090 := by decide
theorem cert_e756723641882 : check e756723641882 [] .sourceHead = true := by decide
def e756723644954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756723644954 : Closed e756723644954 ∧ code e756723644954 = 9552816667162 := by decide
theorem cert_e756723644954 : check e756723644954 [] .sourceHead = true := by decide
def e756730916378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756730916378 : Closed e756730916378 ∧ code e756730916378 = 9552823938586 := by decide
theorem cert_e756730916378 : check e756730916378 [] .sourceHead = true := by decide
def e756730918426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756730918426 : Closed e756730918426 ∧ code e756730918426 = 9552823940634 := by decide
theorem cert_e756730918426 : check e756730918426 [] .sourceHead = true := by decide
def e756730932762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756730932762 : Closed e756730932762 ∧ code e756730932762 = 9552823954970 := by decide
theorem cert_e756730932762 : check e756730932762 [] .sourceHead = true := by decide
def e756730935834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756730935834 : Closed e756730935834 ∧ code e756730935834 = 9552823958042 := by decide
theorem cert_e756730935834 : check e756730935834 [] .sourceHead = true := by decide
def e756730943002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756730943002 : Closed e756730943002 ∧ code e756730943002 = 9552823965210 := by decide
theorem cert_e756730943002 : check e756730943002 [] .sourceHead = true := by decide
def e756730944026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756730944026 : Closed e756730944026 ∧ code e756730944026 = 9552823966234 := by decide
theorem cert_e756730944026 : check e756730944026 [] .sourceHead = true := by decide
def e756730998298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756730998298 : Closed e756730998298 ∧ code e756730998298 = 9552824020506 := by decide
theorem cert_e756730998298 : check e756730998298 [] .sourceHead = true := by decide
def e756731001370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731001370 : Closed e756731001370 ∧ code e756731001370 = 9552824023578 := by decide
theorem cert_e756731001370 : check e756731001370 [] .sourceHead = true := by decide
def e756731013658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731013658 : Closed e756731013658 ∧ code e756731013658 = 9552824035866 := by decide
theorem cert_e756731013658 : check e756731013658 [] .sourceHead = true := by decide
def e756731041306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731041306 : Closed e756731041306 ∧ code e756731041306 = 9552824063514 := by decide
theorem cert_e756731041306 : check e756731041306 [] .sourceHead = true := by decide
def e756731042330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731042330 : Closed e756731042330 ∧ code e756731042330 = 9552824064538 := by decide
theorem cert_e756731042330 : check e756731042330 [] .sourceHead = true := by decide
def e756731046426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731046426 : Closed e756731046426 ∧ code e756731046426 = 9552824068634 := by decide
theorem cert_e756731046426 : check e756731046426 [] .sourceHead = true := by decide
def e756731309594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731309594 : Closed e756731309594 ∧ code e756731309594 = 9552824331802 := by decide
theorem cert_e756731309594 : check e756731309594 [] .sourceHead = true := by decide
def e756731311642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756731311642 : Closed e756731311642 ∧ code e756731311642 = 9552824333850 := by decide
theorem cert_e756731311642 : check e756731311642 [] .sourceHead = true := by decide
end Blc.Floor43
