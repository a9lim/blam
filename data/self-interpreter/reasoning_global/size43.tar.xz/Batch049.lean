import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e701156740538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e701156740538 : Closed e701156740538 ∧ code e701156740538 = 9497249762746 := by decide
theorem cert_e701156740538 : check e701156740538 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156740570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e701156740570 : Closed e701156740570 ∧ code e701156740570 = 9497249762778 := by decide
theorem cert_e701156740570 : check e701156740570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156740794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701156740794 : Closed e701156740794 ∧ code e701156740794 = 9497249763002 := by decide
theorem cert_e701156740794 : check e701156740794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156740842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701156740842 : Closed e701156740842 ∧ code e701156740842 = 9497249763050 := by decide
theorem cert_e701156740842 : check e701156740842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156740954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701156740954 : Closed e701156740954 ∧ code e701156740954 = 9497249763162 := by decide
theorem cert_e701156740954 : check e701156740954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156740970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701156740970 : Closed e701156740970 ∧ code e701156740970 = 9497249763178 := by decide
theorem cert_e701156740970 : check e701156740970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156742074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701156742074 : Closed e701156742074 ∧ code e701156742074 = 9497249764282 := by decide
theorem cert_e701156742074 : check e701156742074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156742106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701156742106 : Closed e701156742106 ∧ code e701156742106 = 9497249764314 := by decide
theorem cert_e701156742106 : check e701156742106 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156743610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701156743610 : Closed e701156743610 ∧ code e701156743610 = 9497249765818 := by decide
theorem cert_e701156743610 : check e701156743610 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156743658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701156743658 : Closed e701156743658 ∧ code e701156743658 = 9497249765866 := by decide
theorem cert_e701156743658 : check e701156743658 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156744090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156744090 : Closed e701156744090 ∧ code e701156744090 = 9497249766298 := by decide
theorem cert_e701156744090 : check e701156744090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156744410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701156744410 : Closed e701156744410 ∧ code e701156744410 = 9497249766618 := by decide
theorem cert_e701156744410 : check e701156744410 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156744426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701156744426 : Closed e701156744426 ∧ code e701156744426 = 9497249766634 := by decide
theorem cert_e701156744426 : check e701156744426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156744602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156744602 : Closed e701156744602 ∧ code e701156744602 = 9497249766810 := by decide
theorem cert_e701156744602 : check e701156744602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156746170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))) (.var 0)))
theorem wire_e701156746170 : Closed e701156746170 ∧ code e701156746170 = 9497249768378 := by decide
theorem cert_e701156746170 : check e701156746170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156746202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))) (.var 0)))
theorem wire_e701156746202 : Closed e701156746202 ∧ code e701156746202 = 9497249768410 := by decide
theorem cert_e701156746202 : check e701156746202 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156746938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701156746938 : Closed e701156746938 ∧ code e701156746938 = 9497249769146 := by decide
theorem cert_e701156746938 : check e701156746938 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156746986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701156746986 : Closed e701156746986 ∧ code e701156746986 = 9497249769194 := by decide
theorem cert_e701156746986 : check e701156746986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156747178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701156747178 : Closed e701156747178 ∧ code e701156747178 = 9497249769386 := by decide
theorem cert_e701156747178 : check e701156747178 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156747706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701156747706 : Closed e701156747706 ∧ code e701156747706 = 9497249769914 := by decide
theorem cert_e701156747706 : check e701156747706 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156747754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701156747754 : Closed e701156747754 ∧ code e701156747754 = 9497249769962 := by decide
theorem cert_e701156747754 : check e701156747754 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156748186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156748186 : Closed e701156748186 ∧ code e701156748186 = 9497249770394 := by decide
theorem cert_e701156748186 : check e701156748186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156748410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e701156748410 : Closed e701156748410 ∧ code e701156748410 = 9497249770618 := by decide
theorem cert_e701156748410 : check e701156748410 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156748742 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e701156748742 : Closed e701156748742 ∧ code e701156748742 = 9497249770950 := by decide
theorem cert_e701156748742 : check e701156748742 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156748858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701156748858 : Closed e701156748858 ∧ code e701156748858 = 9497249771066 := by decide
theorem cert_e701156748858 : check e701156748858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156748906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701156748906 : Closed e701156748906 ∧ code e701156748906 = 9497249771114 := by decide
theorem cert_e701156748906 : check e701156748906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156748954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156748954 : Closed e701156748954 ∧ code e701156748954 = 9497249771162 := by decide
theorem cert_e701156748954 : check e701156748954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156748998 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701156748998 : Closed e701156748998 ∧ code e701156748998 = 9497249771206 := by decide
theorem cert_e701156748998 : check e701156748998 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156749786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e701156749786 : Closed e701156749786 ∧ code e701156749786 = 9497249771994 := by decide
theorem cert_e701156749786 : check e701156749786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156750170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701156750170 : Closed e701156750170 ∧ code e701156750170 = 9497249772378 := by decide
theorem cert_e701156750170 : check e701156750170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156750186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701156750186 : Closed e701156750186 ∧ code e701156750186 = 9497249772394 := by decide
theorem cert_e701156750186 : check e701156750186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156750250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701156750250 : Closed e701156750250 ∧ code e701156750250 = 9497249772458 := by decide
theorem cert_e701156750250 : check e701156750250 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156750554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701156750554 : Closed e701156750554 ∧ code e701156750554 = 9497249772762 := by decide
theorem cert_e701156750554 : check e701156750554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156750570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701156750570 : Closed e701156750570 ∧ code e701156750570 = 9497249772778 := by decide
theorem cert_e701156750570 : check e701156750570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156750746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156750746 : Closed e701156750746 ∧ code e701156750746 = 9497249772954 := by decide
theorem cert_e701156750746 : check e701156750746 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156750906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701156750906 : Closed e701156750906 ∧ code e701156750906 = 9497249773114 := by decide
theorem cert_e701156750906 : check e701156750906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156750954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701156750954 : Closed e701156750954 ∧ code e701156750954 = 9497249773162 := by decide
theorem cert_e701156750954 : check e701156750954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156751002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156751002 : Closed e701156751002 ∧ code e701156751002 = 9497249773210 := by decide
theorem cert_e701156751002 : check e701156751002 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156751046 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701156751046 : Closed e701156751046 ∧ code e701156751046 = 9497249773254 := by decide
theorem cert_e701156751046 : check e701156751046 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156757370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.var 0)))
theorem wire_e701156757370 : Closed e701156757370 ∧ code e701156757370 = 9497249779578 := by decide
theorem cert_e701156757370 : check e701156757370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156757434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.var 0)))
theorem wire_e701156757434 : Closed e701156757434 ∧ code e701156757434 = 9497249779642 := by decide
theorem cert_e701156757434 : check e701156757434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156765114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701156765114 : Closed e701156765114 ∧ code e701156765114 = 9497249787322 := by decide
theorem cert_e701156765114 : check e701156765114 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156765146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701156765146 : Closed e701156765146 ∧ code e701156765146 = 9497249787354 := by decide
theorem cert_e701156765146 : check e701156765146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156765370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701156765370 : Closed e701156765370 ∧ code e701156765370 = 9497249787578 := by decide
theorem cert_e701156765370 : check e701156765370 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156765418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701156765418 : Closed e701156765418 ∧ code e701156765418 = 9497249787626 := by decide
theorem cert_e701156765418 : check e701156765418 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156765530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701156765530 : Closed e701156765530 ∧ code e701156765530 = 9497249787738 := by decide
theorem cert_e701156765530 : check e701156765530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156765546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701156765546 : Closed e701156765546 ∧ code e701156765546 = 9497249787754 := by decide
theorem cert_e701156765546 : check e701156765546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156766650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701156766650 : Closed e701156766650 ∧ code e701156766650 = 9497249788858 := by decide
theorem cert_e701156766650 : check e701156766650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156766682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701156766682 : Closed e701156766682 ∧ code e701156766682 = 9497249788890 := by decide
theorem cert_e701156766682 : check e701156766682 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156768186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701156768186 : Closed e701156768186 ∧ code e701156768186 = 9497249790394 := by decide
theorem cert_e701156768186 : check e701156768186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156768234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701156768234 : Closed e701156768234 ∧ code e701156768234 = 9497249790442 := by decide
theorem cert_e701156768234 : check e701156768234 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156768666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156768666 : Closed e701156768666 ∧ code e701156768666 = 9497249790874 := by decide
theorem cert_e701156768666 : check e701156768666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156768986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701156768986 : Closed e701156768986 ∧ code e701156768986 = 9497249791194 := by decide
theorem cert_e701156768986 : check e701156768986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156769002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701156769002 : Closed e701156769002 ∧ code e701156769002 = 9497249791210 := by decide
theorem cert_e701156769002 : check e701156769002 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156769178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156769178 : Closed e701156769178 ∧ code e701156769178 = 9497249791386 := by decide
theorem cert_e701156769178 : check e701156769178 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156788090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e701156788090 : Closed e701156788090 ∧ code e701156788090 = 9497249810298 := by decide
theorem cert_e701156788090 : check e701156788090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156788186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e701156788186 : Closed e701156788186 ∧ code e701156788186 = 9497249810394 := by decide
theorem cert_e701156788186 : check e701156788186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156791994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701156791994 : Closed e701156791994 ∧ code e701156791994 = 9497249814202 := by decide
theorem cert_e701156791994 : check e701156791994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156792042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701156792042 : Closed e701156792042 ∧ code e701156792042 = 9497249814250 := by decide
theorem cert_e701156792042 : check e701156792042 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156792234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701156792234 : Closed e701156792234 ∧ code e701156792234 = 9497249814442 := by decide
theorem cert_e701156792234 : check e701156792234 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156792762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701156792762 : Closed e701156792762 ∧ code e701156792762 = 9497249814970 := by decide
theorem cert_e701156792762 : check e701156792762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156792810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701156792810 : Closed e701156792810 ∧ code e701156792810 = 9497249815018 := by decide
theorem cert_e701156792810 : check e701156792810 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156793242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156793242 : Closed e701156793242 ∧ code e701156793242 = 9497249815450 := by decide
theorem cert_e701156793242 : check e701156793242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156793466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e701156793466 : Closed e701156793466 ∧ code e701156793466 = 9497249815674 := by decide
theorem cert_e701156793466 : check e701156793466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156793798 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e701156793798 : Closed e701156793798 ∧ code e701156793798 = 9497249816006 := by decide
theorem cert_e701156793798 : check e701156793798 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156793914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e701156793914 : Closed e701156793914 ∧ code e701156793914 = 9497249816122 := by decide
theorem cert_e701156793914 : check e701156793914 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156793962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701156793962 : Closed e701156793962 ∧ code e701156793962 = 9497249816170 := by decide
theorem cert_e701156793962 : check e701156793962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156794010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156794010 : Closed e701156794010 ∧ code e701156794010 = 9497249816218 := by decide
theorem cert_e701156794010 : check e701156794010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156794054 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e701156794054 : Closed e701156794054 ∧ code e701156794054 = 9497249816262 := by decide
theorem cert_e701156794054 : check e701156794054 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156803514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701156803514 : Closed e701156803514 ∧ code e701156803514 = 9497249825722 := by decide
theorem cert_e701156803514 : check e701156803514 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156803546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701156803546 : Closed e701156803546 ∧ code e701156803546 = 9497249825754 := by decide
theorem cert_e701156803546 : check e701156803546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156805466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701156805466 : Closed e701156805466 ∧ code e701156805466 = 9497249827674 := by decide
theorem cert_e701156805466 : check e701156805466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156805482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701156805482 : Closed e701156805482 ∧ code e701156805482 = 9497249827690 := by decide
theorem cert_e701156805482 : check e701156805482 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156805546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701156805546 : Closed e701156805546 ∧ code e701156805546 = 9497249827754 := by decide
theorem cert_e701156805546 : check e701156805546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156805850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701156805850 : Closed e701156805850 ∧ code e701156805850 = 9497249828058 := by decide
theorem cert_e701156805850 : check e701156805850 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156805866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701156805866 : Closed e701156805866 ∧ code e701156805866 = 9497249828074 := by decide
theorem cert_e701156805866 : check e701156805866 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156806042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156806042 : Closed e701156806042 ∧ code e701156806042 = 9497249828250 := by decide
theorem cert_e701156806042 : check e701156806042 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156806202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e701156806202 : Closed e701156806202 ∧ code e701156806202 = 9497249828410 := by decide
theorem cert_e701156806202 : check e701156806202 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156806250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701156806250 : Closed e701156806250 ∧ code e701156806250 = 9497249828458 := by decide
theorem cert_e701156806250 : check e701156806250 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156806298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156806298 : Closed e701156806298 ∧ code e701156806298 = 9497249828506 := by decide
theorem cert_e701156806298 : check e701156806298 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156806342 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e701156806342 : Closed e701156806342 ∧ code e701156806342 = 9497249828550 := by decide
theorem cert_e701156806342 : check e701156806342 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157169850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701157169850 : Closed e701157169850 ∧ code e701157169850 = 9497250192058 := by decide
theorem cert_e701157169850 : check e701157169850 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157169898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701157169898 : Closed e701157169898 ∧ code e701157169898 = 9497250192106 := by decide
theorem cert_e701157169898 : check e701157169898 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157170090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701157170090 : Closed e701157170090 ∧ code e701157170090 = 9497250192298 := by decide
theorem cert_e701157170090 : check e701157170090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157170858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701157170858 : Closed e701157170858 ∧ code e701157170858 = 9497250193066 := by decide
theorem cert_e701157170858 : check e701157170858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157172154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.var 0)))
theorem wire_e701157172154 : Closed e701157172154 ∧ code e701157172154 = 9497250194362 := by decide
theorem cert_e701157172154 : check e701157172154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157172186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.var 0)))
theorem wire_e701157172186 : Closed e701157172186 ∧ code e701157172186 = 9497250194394 := by decide
theorem cert_e701157172186 : check e701157172186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157172922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701157172922 : Closed e701157172922 ∧ code e701157172922 = 9497250195130 := by decide
theorem cert_e701157172922 : check e701157172922 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157172970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701157172970 : Closed e701157172970 ∧ code e701157172970 = 9497250195178 := by decide
theorem cert_e701157172970 : check e701157172970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157173162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701157173162 : Closed e701157173162 ∧ code e701157173162 = 9497250195370 := by decide
theorem cert_e701157173162 : check e701157173162 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157173690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701157173690 : Closed e701157173690 ∧ code e701157173690 = 9497250195898 := by decide
theorem cert_e701157173690 : check e701157173690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157173738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701157173738 : Closed e701157173738 ∧ code e701157173738 = 9497250195946 := by decide
theorem cert_e701157173738 : check e701157173738 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157174170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157174170 : Closed e701157174170 ∧ code e701157174170 = 9497250196378 := by decide
theorem cert_e701157174170 : check e701157174170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157174394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e701157174394 : Closed e701157174394 ∧ code e701157174394 = 9497250196602 := by decide
theorem cert_e701157174394 : check e701157174394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157174726 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e701157174726 : Closed e701157174726 ∧ code e701157174726 = 9497250196934 := by decide
theorem cert_e701157174726 : check e701157174726 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157174842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701157174842 : Closed e701157174842 ∧ code e701157174842 = 9497250197050 := by decide
theorem cert_e701157174842 : check e701157174842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157174890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701157174890 : Closed e701157174890 ∧ code e701157174890 = 9497250197098 := by decide
theorem cert_e701157174890 : check e701157174890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157174938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157174938 : Closed e701157174938 ∧ code e701157174938 = 9497250197146 := by decide
theorem cert_e701157174938 : check e701157174938 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157174982 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701157174982 : Closed e701157174982 ∧ code e701157174982 = 9497250197190 := by decide
theorem cert_e701157174982 : check e701157174982 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157175738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e701157175738 : Closed e701157175738 ∧ code e701157175738 = 9497250197946 := by decide
theorem cert_e701157175738 : check e701157175738 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157175786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e701157175786 : Closed e701157175786 ∧ code e701157175786 = 9497250197994 := by decide
theorem cert_e701157175786 : check e701157175786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157176442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e701157176442 : Closed e701157176442 ∧ code e701157176442 = 9497250198650 := by decide
theorem cert_e701157176442 : check e701157176442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157176774 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e701157176774 : Closed e701157176774 ∧ code e701157176774 = 9497250198982 := by decide
theorem cert_e701157176774 : check e701157176774 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157177114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e701157177114 : Closed e701157177114 ∧ code e701157177114 = 9497250199322 := by decide
theorem cert_e701157177114 : check e701157177114 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157177158 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e701157177158 : Closed e701157177158 ∧ code e701157177158 = 9497250199366 := by decide
theorem cert_e701157177158 : check e701157177158 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157177562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e701157177562 : Closed e701157177562 ∧ code e701157177562 = 9497250199770 := by decide
theorem cert_e701157177562 : check e701157177562 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157177578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701157177578 : Closed e701157177578 ∧ code e701157177578 = 9497250199786 := by decide
theorem cert_e701157177578 : check e701157177578 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157177770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701157177770 : Closed e701157177770 ∧ code e701157177770 = 9497250199978 := by decide
theorem cert_e701157177770 : check e701157177770 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157177914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701157177914 : Closed e701157177914 ∧ code e701157177914 = 9497250200122 := by decide
theorem cert_e701157177914 : check e701157177914 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157177962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701157177962 : Closed e701157177962 ∧ code e701157177962 = 9497250200170 := by decide
theorem cert_e701157177962 : check e701157177962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157178010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157178010 : Closed e701157178010 ∧ code e701157178010 = 9497250200218 := by decide
theorem cert_e701157178010 : check e701157178010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157178054 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701157178054 : Closed e701157178054 ∧ code e701157178054 = 9497250200262 := by decide
theorem cert_e701157178054 : check e701157178054 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157178138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e701157178138 : Closed e701157178138 ∧ code e701157178138 = 9497250200346 := by decide
theorem cert_e701157178138 : check e701157178138 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157178182 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e701157178182 : Closed e701157178182 ∧ code e701157178182 = 9497250200390 := by decide
theorem cert_e701157178182 : check e701157178182 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157181306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e701157181306 : Closed e701157181306 ∧ code e701157181306 = 9497250203514 := by decide
theorem cert_e701157181306 : check e701157181306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157181402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e701157181402 : Closed e701157181402 ∧ code e701157181402 = 9497250203610 := by decide
theorem cert_e701157181402 : check e701157181402 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157185210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701157185210 : Closed e701157185210 ∧ code e701157185210 = 9497250207418 := by decide
theorem cert_e701157185210 : check e701157185210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157185258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701157185258 : Closed e701157185258 ∧ code e701157185258 = 9497250207466 := by decide
theorem cert_e701157185258 : check e701157185258 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157185450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701157185450 : Closed e701157185450 ∧ code e701157185450 = 9497250207658 := by decide
theorem cert_e701157185450 : check e701157185450 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157185978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701157185978 : Closed e701157185978 ∧ code e701157185978 = 9497250208186 := by decide
theorem cert_e701157185978 : check e701157185978 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157186026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701157186026 : Closed e701157186026 ∧ code e701157186026 = 9497250208234 := by decide
theorem cert_e701157186026 : check e701157186026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157186458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157186458 : Closed e701157186458 ∧ code e701157186458 = 9497250208666 := by decide
theorem cert_e701157186458 : check e701157186458 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157186682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e701157186682 : Closed e701157186682 ∧ code e701157186682 = 9497250208890 := by decide
theorem cert_e701157186682 : check e701157186682 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157187014 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e701157187014 : Closed e701157187014 ∧ code e701157187014 = 9497250209222 := by decide
theorem cert_e701157187014 : check e701157187014 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157187130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e701157187130 : Closed e701157187130 ∧ code e701157187130 = 9497250209338 := by decide
theorem cert_e701157187130 : check e701157187130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157187178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701157187178 : Closed e701157187178 ∧ code e701157187178 = 9497250209386 := by decide
theorem cert_e701157187178 : check e701157187178 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157187226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157187226 : Closed e701157187226 ∧ code e701157187226 = 9497250209434 := by decide
theorem cert_e701157187226 : check e701157187226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157187270 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e701157187270 : Closed e701157187270 ∧ code e701157187270 = 9497250209478 := by decide
theorem cert_e701157187270 : check e701157187270 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157198970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e701157198970 : Closed e701157198970 ∧ code e701157198970 = 9497250221178 := by decide
theorem cert_e701157198970 : check e701157198970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157199302 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e701157199302 : Closed e701157199302 ∧ code e701157199302 = 9497250221510 := by decide
theorem cert_e701157199302 : check e701157199302 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157199642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e701157199642 : Closed e701157199642 ∧ code e701157199642 = 9497250221850 := by decide
theorem cert_e701157199642 : check e701157199642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157199686 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e701157199686 : Closed e701157199686 ∧ code e701157199686 = 9497250221894 := by decide
theorem cert_e701157199686 : check e701157199686 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157204442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))) (.var 0)))
theorem wire_e701157204442 : Closed e701157204442 ∧ code e701157204442 = 9497250226650 := by decide
theorem cert_e701157204442 : check e701157204442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157205418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701157205418 : Closed e701157205418 ∧ code e701157205418 = 9497250227626 := by decide
theorem cert_e701157205418 : check e701157205418 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157205562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e701157205562 : Closed e701157205562 ∧ code e701157205562 = 9497250227770 := by decide
theorem cert_e701157205562 : check e701157205562 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157205610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701157205610 : Closed e701157205610 ∧ code e701157205610 = 9497250227818 := by decide
theorem cert_e701157205610 : check e701157205610 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157205658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157205658 : Closed e701157205658 ∧ code e701157205658 = 9497250227866 := by decide
theorem cert_e701157205658 : check e701157205658 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157205702 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e701157205702 : Closed e701157205702 ∧ code e701157205702 = 9497250227910 := by decide
theorem cert_e701157205702 : check e701157205702 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157205786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e701157205786 : Closed e701157205786 ∧ code e701157205786 = 9497250227994 := by decide
theorem cert_e701157205786 : check e701157205786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157205830 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e701157205830 : Closed e701157205830 ∧ code e701157205830 = 9497250228038 := by decide
theorem cert_e701157205830 : check e701157205830 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157387610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701157387610 : Closed e701157387610 ∧ code e701157387610 = 9497250409818 := by decide
theorem cert_e701157387610 : check e701157387610 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157387626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701157387626 : Closed e701157387626 ∧ code e701157387626 = 9497250409834 := by decide
theorem cert_e701157387626 : check e701157387626 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157387690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701157387690 : Closed e701157387690 ∧ code e701157387690 = 9497250409898 := by decide
theorem cert_e701157387690 : check e701157387690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157387946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701157387946 : Closed e701157387946 ∧ code e701157387946 = 9497250410154 := by decide
theorem cert_e701157387946 : check e701157387946 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157388762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e701157388762 : Closed e701157388762 ∧ code e701157388762 = 9497250410970 := by decide
theorem cert_e701157388762 : check e701157388762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157389146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701157389146 : Closed e701157389146 ∧ code e701157389146 = 9497250411354 := by decide
theorem cert_e701157389146 : check e701157389146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157389162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701157389162 : Closed e701157389162 ∧ code e701157389162 = 9497250411370 := by decide
theorem cert_e701157389162 : check e701157389162 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157389226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701157389226 : Closed e701157389226 ∧ code e701157389226 = 9497250411434 := by decide
theorem cert_e701157389226 : check e701157389226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157389530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701157389530 : Closed e701157389530 ∧ code e701157389530 = 9497250411738 := by decide
theorem cert_e701157389530 : check e701157389530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157389546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701157389546 : Closed e701157389546 ∧ code e701157389546 = 9497250411754 := by decide
theorem cert_e701157389546 : check e701157389546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157389722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157389722 : Closed e701157389722 ∧ code e701157389722 = 9497250411930 := by decide
theorem cert_e701157389722 : check e701157389722 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157389882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701157389882 : Closed e701157389882 ∧ code e701157389882 = 9497250412090 := by decide
theorem cert_e701157389882 : check e701157389882 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157389930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701157389930 : Closed e701157389930 ∧ code e701157389930 = 9497250412138 := by decide
theorem cert_e701157389930 : check e701157389930 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157389978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701157389978 : Closed e701157389978 ∧ code e701157389978 = 9497250412186 := by decide
theorem cert_e701157389978 : check e701157389978 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157390022 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701157390022 : Closed e701157390022 ∧ code e701157390022 = 9497250412230 := by decide
theorem cert_e701157390022 : check e701157390022 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157390554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e701157390554 : Closed e701157390554 ∧ code e701157390554 = 9497250412762 := by decide
theorem cert_e701157390554 : check e701157390554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157390570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701157390570 : Closed e701157390570 ∧ code e701157390570 = 9497250412778 := by decide
theorem cert_e701157390570 : check e701157390570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157390762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701157390762 : Closed e701157390762 ∧ code e701157390762 = 9497250412970 := by decide
theorem cert_e701157390762 : check e701157390762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157390906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701157390906 : Closed e701157390906 ∧ code e701157390906 = 9497250413114 := by decide
theorem cert_e701157390906 : check e701157390906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701157390954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701157390954 : Closed e701157390954 ∧ code e701157390954 = 9497250413162 := by decide
theorem cert_e701157390954 : check e701157390954 [[.under,.left],[.under,.left]] .chain = true := by decide
end Blc.Floor43
