import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422376734306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422376734306 : Closed e2422376734306 ∧ code e2422376734306 = 11218469756514 := by decide
theorem cert_e2422376734306 : check e2422376734306 [[],[]] .smaller = true := by decide
def e2422376734318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422376734318 : Closed e2422376734318 ∧ code e2422376734318 = 11218469756526 := by decide
theorem cert_e2422376734318 : check e2422376734318 [[],[]] .smaller = true := by decide
def e2422376734330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422376734330 : Closed e2422376734330 ∧ code e2422376734330 = 11218469756538 := by decide
theorem cert_e2422376734330 : check e2422376734330 [[],[]] .smaller = true := by decide
def e2422376734494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2422376734494 : Closed e2422376734494 ∧ code e2422376734494 = 11218469756702 := by decide
theorem cert_e2422376734494 : check e2422376734494 [[],[]] .three = true := by decide
def e2422376734518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376734518 : Closed e2422376734518 ∧ code e2422376734518 = 11218469756726 := by decide
theorem cert_e2422376734518 : check e2422376734518 [[],[]] .three = true := by decide
def e2422376734522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376734522 : Closed e2422376734522 ∧ code e2422376734522 = 11218469756730 := by decide
theorem cert_e2422376734522 : check e2422376734522 [[],[]] .three = true := by decide
def e2422376743638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422376743638 : Closed e2422376743638 ∧ code e2422376743638 = 11218469765846 := by decide
theorem cert_e2422376743638 : check e2422376743638 [[],[]] .three = true := by decide
def e2422376743642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422376743642 : Closed e2422376743642 ∧ code e2422376743642 = 11218469765850 := by decide
theorem cert_e2422376743642 : check e2422376743642 [[],[]] .three = true := by decide
def e2422376743658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422376743658 : Closed e2422376743658 ∧ code e2422376743658 = 11218469765866 := by decide
theorem cert_e2422376743658 : check e2422376743658 [[],[]] .three = true := by decide
def e2422376743734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376743734 : Closed e2422376743734 ∧ code e2422376743734 = 11218469765942 := by decide
theorem cert_e2422376743734 : check e2422376743734 [[],[]] .three = true := by decide
def e2422376743738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376743738 : Closed e2422376743738 ∧ code e2422376743738 = 11218469765946 := by decide
theorem cert_e2422376743738 : check e2422376743738 [[],[]] .three = true := by decide
def e2422376743822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422376743822 : Closed e2422376743822 ∧ code e2422376743822 = 11218469766030 := by decide
theorem cert_e2422376743822 : check e2422376743822 [[],[]] .three = true := by decide
def e2422376743834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422376743834 : Closed e2422376743834 ∧ code e2422376743834 = 11218469766042 := by decide
theorem cert_e2422376743834 : check e2422376743834 [[],[]] .three = true := by decide
def e2422376743870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2422376743870 : Closed e2422376743870 ∧ code e2422376743870 = 11218469766078 := by decide
theorem cert_e2422376743870 : check e2422376743870 [[],[]] .three = true := by decide
def e2422376743902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2422376743902 : Closed e2422376743902 ∧ code e2422376743902 = 11218469766110 := by decide
theorem cert_e2422376743902 : check e2422376743902 [[],[]] .three = true := by decide
def e2422376743918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2422376743918 : Closed e2422376743918 ∧ code e2422376743918 = 11218469766126 := by decide
theorem cert_e2422376743918 : check e2422376743918 [[],[]] .three = true := by decide
def e2422376743926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2422376743926 : Closed e2422376743926 ∧ code e2422376743926 = 11218469766134 := by decide
theorem cert_e2422376743926 : check e2422376743926 [[],[]] .three = true := by decide
def e2422376745750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422376745750 : Closed e2422376745750 ∧ code e2422376745750 = 11218469767958 := by decide
theorem cert_e2422376745750 : check e2422376745750 [[],[]] .three = true := by decide
def e2422376745754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422376745754 : Closed e2422376745754 ∧ code e2422376745754 = 11218469767962 := by decide
theorem cert_e2422376745754 : check e2422376745754 [[],[]] .three = true := by decide
def e2422376745798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422376745798 : Closed e2422376745798 ∧ code e2422376745798 = 11218469768006 := by decide
theorem cert_e2422376745798 : check e2422376745798 [[],[]] .three = true := by decide
def e2422376745822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2422376745822 : Closed e2422376745822 ∧ code e2422376745822 = 11218469768030 := by decide
theorem cert_e2422376745822 : check e2422376745822 [[],[]] .three = true := by decide
def e2422376745826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422376745826 : Closed e2422376745826 ∧ code e2422376745826 = 11218469768034 := by decide
theorem cert_e2422376745826 : check e2422376745826 [[],[]] .three = true := by decide
def e2422376745838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422376745838 : Closed e2422376745838 ∧ code e2422376745838 = 11218469768046 := by decide
theorem cert_e2422376745838 : check e2422376745838 [[],[]] .three = true := by decide
def e2422376745846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422376745846 : Closed e2422376745846 ∧ code e2422376745846 = 11218469768054 := by decide
theorem cert_e2422376745846 : check e2422376745846 [[],[]] .three = true := by decide
def e2422376745850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2422376745850 : Closed e2422376745850 ∧ code e2422376745850 = 11218469768058 := by decide
theorem cert_e2422376745850 : check e2422376745850 [[],[]] .three = true := by decide
def e2422376745866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422376745866 : Closed e2422376745866 ∧ code e2422376745866 = 11218469768074 := by decide
theorem cert_e2422376745866 : check e2422376745866 [[],[]] .three = true := by decide
def e2422376745890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422376745890 : Closed e2422376745890 ∧ code e2422376745890 = 11218469768098 := by decide
theorem cert_e2422376745890 : check e2422376745890 [[],[]] .three = true := by decide
def e2422376745902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422376745902 : Closed e2422376745902 ∧ code e2422376745902 = 11218469768110 := by decide
theorem cert_e2422376745902 : check e2422376745902 [[],[]] .three = true := by decide
def e2422376745914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422376745914 : Closed e2422376745914 ∧ code e2422376745914 = 11218469768122 := by decide
theorem cert_e2422376745914 : check e2422376745914 [[],[]] .three = true := by decide
def e2422376745942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422376745942 : Closed e2422376745942 ∧ code e2422376745942 = 11218469768150 := by decide
theorem cert_e2422376745942 : check e2422376745942 [[],[]] .three = true := by decide
def e2422376745946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422376745946 : Closed e2422376745946 ∧ code e2422376745946 = 11218469768154 := by decide
theorem cert_e2422376745946 : check e2422376745946 [[],[]] .three = true := by decide
def e2422376745962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2422376745962 : Closed e2422376745962 ∧ code e2422376745962 = 11218469768170 := by decide
theorem cert_e2422376745962 : check e2422376745962 [[],[]] .three = true := by decide
def e2422376746014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422376746014 : Closed e2422376746014 ∧ code e2422376746014 = 11218469768222 := by decide
theorem cert_e2422376746014 : check e2422376746014 [[],[]] .three = true := by decide
def e2422376746038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376746038 : Closed e2422376746038 ∧ code e2422376746038 = 11218469768246 := by decide
theorem cert_e2422376746038 : check e2422376746038 [[],[]] .three = true := by decide
def e2422376746042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376746042 : Closed e2422376746042 ∧ code e2422376746042 = 11218469768250 := by decide
theorem cert_e2422376746042 : check e2422376746042 [[],[]] .three = true := by decide
def e2422376746182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422376746182 : Closed e2422376746182 ∧ code e2422376746182 = 11218469768390 := by decide
theorem cert_e2422376746182 : check e2422376746182 [[],[]] .three = true := by decide
def e2422376746206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422376746206 : Closed e2422376746206 ∧ code e2422376746206 = 11218469768414 := by decide
theorem cert_e2422376746206 : check e2422376746206 [[],[]] .three = true := by decide
def e2422376746210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422376746210 : Closed e2422376746210 ∧ code e2422376746210 = 11218469768418 := by decide
theorem cert_e2422376746210 : check e2422376746210 [[],[]] .three = true := by decide
def e2422376746222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422376746222 : Closed e2422376746222 ∧ code e2422376746222 = 11218469768430 := by decide
theorem cert_e2422376746222 : check e2422376746222 [[],[]] .three = true := by decide
def e2422376746230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422376746230 : Closed e2422376746230 ∧ code e2422376746230 = 11218469768438 := by decide
theorem cert_e2422376746230 : check e2422376746230 [[],[]] .three = true := by decide
def e2422376746234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422376746234 : Closed e2422376746234 ∧ code e2422376746234 = 11218469768442 := by decide
theorem cert_e2422376746234 : check e2422376746234 [[],[]] .three = true := by decide
def e2422376746510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422376746510 : Closed e2422376746510 ∧ code e2422376746510 = 11218469768718 := by decide
theorem cert_e2422376746510 : check e2422376746510 [[],[]] .three = true := by decide
def e2422376746594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422376746594 : Closed e2422376746594 ∧ code e2422376746594 = 11218469768802 := by decide
theorem cert_e2422376746594 : check e2422376746594 [[],[]] .three = true := by decide
def e2422376746606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422376746606 : Closed e2422376746606 ∧ code e2422376746606 = 11218469768814 := by decide
theorem cert_e2422376746606 : check e2422376746606 [[],[]] .three = true := by decide
def e2422376746618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422376746618 : Closed e2422376746618 ∧ code e2422376746618 = 11218469768826 := by decide
theorem cert_e2422376746618 : check e2422376746618 [[],[]] .three = true := by decide
def e2422376746782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e2422376746782 : Closed e2422376746782 ∧ code e2422376746782 = 11218469768990 := by decide
theorem cert_e2422376746782 : check e2422376746782 [[],[]] .three = true := by decide
def e2422376746806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376746806 : Closed e2422376746806 ∧ code e2422376746806 = 11218469769014 := by decide
theorem cert_e2422376746806 : check e2422376746806 [[],[]] .three = true := by decide
def e2422376746810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376746810 : Closed e2422376746810 ∧ code e2422376746810 = 11218469769018 := by decide
theorem cert_e2422376746810 : check e2422376746810 [[],[]] .three = true := by decide
def e2422376746906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422376746906 : Closed e2422376746906 ∧ code e2422376746906 = 11218469769114 := by decide
theorem cert_e2422376746906 : check e2422376746906 [[],[]] .three = true := by decide
def e2422377295294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4))))))))))
theorem wire_e2422377295294 : Closed e2422377295294 ∧ code e2422377295294 = 11218470317502 := by decide
theorem cert_e2422377295294 : check e2422377295294 [[],[]] .smaller = true := by decide
def e2422377295350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1))))))))))
theorem wire_e2422377295350 : Closed e2422377295350 ∧ code e2422377295350 = 11218470317558 := by decide
theorem cert_e2422377295350 : check e2422377295350 [[],[]] .smaller = true := by decide
def e2422377295550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4))))))))))
theorem wire_e2422377295550 : Closed e2422377295550 ∧ code e2422377295550 = 11218470317758 := by decide
theorem cert_e2422377295550 : check e2422377295550 [[],[]] .smaller = true := by decide
def e2422377295610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0))))))))))
theorem wire_e2422377295610 : Closed e2422377295610 ∧ code e2422377295610 = 11218470317818 := by decide
theorem cert_e2422377295610 : check e2422377295610 [[],[]] .smaller = true := by decide
def e2422377295830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1))))))))))
theorem wire_e2422377295830 : Closed e2422377295830 ∧ code e2422377295830 = 11218470318038 := by decide
theorem cert_e2422377295830 : check e2422377295830 [[],[]] .smaller = true := by decide
def e2422377295834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0))))))))))
theorem wire_e2422377295834 : Closed e2422377295834 ∧ code e2422377295834 = 11218470318042 := by decide
theorem cert_e2422377295834 : check e2422377295834 [[],[]] .smaller = true := by decide
def e2422377296830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422377296830 : Closed e2422377296830 ∧ code e2422377296830 = 11218470319038 := by decide
theorem cert_e2422377296830 : check e2422377296830 [[],[]] .smaller = true := by decide
def e2422377296886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422377296886 : Closed e2422377296886 ∧ code e2422377296886 = 11218470319094 := by decide
theorem cert_e2422377296886 : check e2422377296886 [[],[]] .smaller = true := by decide
def e2422377298366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422377298366 : Closed e2422377298366 ∧ code e2422377298366 = 11218470320574 := by decide
theorem cert_e2422377298366 : check e2422377298366 [[],[]] .smaller = true := by decide
def e2422377298426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422377298426 : Closed e2422377298426 ∧ code e2422377298426 = 11218470320634 := by decide
theorem cert_e2422377298426 : check e2422377298426 [[],[]] .smaller = true := by decide
def e2422377299766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377299766 : Closed e2422377299766 ∧ code e2422377299766 = 11218470321974 := by decide
theorem cert_e2422377299766 : check e2422377299766 [[],[]] .smaller = true := by decide
def e2422377299770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377299770 : Closed e2422377299770 ∧ code e2422377299770 = 11218470321978 := by decide
theorem cert_e2422377299770 : check e2422377299770 [[],[]] .smaller = true := by decide
def e2422377327982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2422377327982 : Closed e2422377327982 ∧ code e2422377327982 = 11218470350190 := by decide
theorem cert_e2422377327982 : check e2422377327982 [[],[]] .smaller = true := by decide
def e2422377327990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2422377327990 : Closed e2422377327990 ∧ code e2422377327990 = 11218470350198 := by decide
theorem cert_e2422377327990 : check e2422377327990 [[],[]] .smaller = true := by decide
def e2422377328046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2422377328046 : Closed e2422377328046 ∧ code e2422377328046 = 11218470350254 := by decide
theorem cert_e2422377328046 : check e2422377328046 [[],[]] .smaller = true := by decide
def e2422377328058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2422377328058 : Closed e2422377328058 ∧ code e2422377328058 = 11218470350266 := by decide
theorem cert_e2422377328058 : check e2422377328058 [[],[]] .smaller = true := by decide
def e2422377328086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2422377328086 : Closed e2422377328086 ∧ code e2422377328086 = 11218470350294 := by decide
theorem cert_e2422377328086 : check e2422377328086 [[],[]] .smaller = true := by decide
def e2422377328090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2422377328090 : Closed e2422377328090 ∧ code e2422377328090 = 11218470350298 := by decide
theorem cert_e2422377328090 : check e2422377328090 [[],[]] .smaller = true := by decide
def e2422377328302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422377328302 : Closed e2422377328302 ∧ code e2422377328302 = 11218470350510 := by decide
theorem cert_e2422377328302 : check e2422377328302 [[],[]] .smaller = true := by decide
def e2422377328314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422377328314 : Closed e2422377328314 ∧ code e2422377328314 = 11218470350522 := by decide
theorem cert_e2422377328314 : check e2422377328314 [[],[]] .smaller = true := by decide
def e2422377328362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422377328362 : Closed e2422377328362 ∧ code e2422377328362 = 11218470350570 := by decide
theorem cert_e2422377328362 : check e2422377328362 [[],[]] .smaller = true := by decide
def e2422377328470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422377328470 : Closed e2422377328470 ∧ code e2422377328470 = 11218470350678 := by decide
theorem cert_e2422377328470 : check e2422377328470 [[],[]] .smaller = true := by decide
def e2422377328474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422377328474 : Closed e2422377328474 ∧ code e2422377328474 = 11218470350682 := by decide
theorem cert_e2422377328474 : check e2422377328474 [[],[]] .smaller = true := by decide
def e2422377328490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422377328490 : Closed e2422377328490 ∧ code e2422377328490 = 11218470350698 := by decide
theorem cert_e2422377328490 : check e2422377328490 [[],[]] .smaller = true := by decide
def e2422377329118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e2422377329118 : Closed e2422377329118 ∧ code e2422377329118 = 11218470351326 := by decide
theorem cert_e2422377329118 : check e2422377329118 [[],[]] .smaller = true := by decide
def e2422377329142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e2422377329142 : Closed e2422377329142 ∧ code e2422377329142 = 11218470351350 := by decide
theorem cert_e2422377329142 : check e2422377329142 [[],[]] .smaller = true := by decide
def e2422377329518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2422377329518 : Closed e2422377329518 ∧ code e2422377329518 = 11218470351726 := by decide
theorem cert_e2422377329518 : check e2422377329518 [[],[]] .smaller = true := by decide
def e2422377329526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2422377329526 : Closed e2422377329526 ∧ code e2422377329526 = 11218470351734 := by decide
theorem cert_e2422377329526 : check e2422377329526 [[],[]] .smaller = true := by decide
def e2422377329582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2422377329582 : Closed e2422377329582 ∧ code e2422377329582 = 11218470351790 := by decide
theorem cert_e2422377329582 : check e2422377329582 [[],[]] .smaller = true := by decide
def e2422377329594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2422377329594 : Closed e2422377329594 ∧ code e2422377329594 = 11218470351802 := by decide
theorem cert_e2422377329594 : check e2422377329594 [[],[]] .smaller = true := by decide
def e2422377329622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2422377329622 : Closed e2422377329622 ∧ code e2422377329622 = 11218470351830 := by decide
theorem cert_e2422377329622 : check e2422377329622 [[],[]] .smaller = true := by decide
def e2422377329626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2422377329626 : Closed e2422377329626 ∧ code e2422377329626 = 11218470351834 := by decide
theorem cert_e2422377329626 : check e2422377329626 [[],[]] .smaller = true := by decide
def e2422377329902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422377329902 : Closed e2422377329902 ∧ code e2422377329902 = 11218470352110 := by decide
theorem cert_e2422377329902 : check e2422377329902 [[],[]] .smaller = true := by decide
def e2422377329910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422377329910 : Closed e2422377329910 ∧ code e2422377329910 = 11218470352118 := by decide
theorem cert_e2422377329910 : check e2422377329910 [[],[]] .smaller = true := by decide
def e2422377330238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e2422377330238 : Closed e2422377330238 ∧ code e2422377330238 = 11218470352446 := by decide
theorem cert_e2422377330238 : check e2422377330238 [[],[]] .smaller = true := by decide
def e2422377330286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377330286 : Closed e2422377330286 ∧ code e2422377330286 = 11218470352494 := by decide
theorem cert_e2422377330286 : check e2422377330286 [[],[]] .smaller = true := by decide
def e2422377330298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377330298 : Closed e2422377330298 ∧ code e2422377330298 = 11218470352506 := by decide
theorem cert_e2422377330298 : check e2422377330298 [[],[]] .smaller = true := by decide
def e2422377330486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377330486 : Closed e2422377330486 ∧ code e2422377330486 = 11218470352694 := by decide
theorem cert_e2422377330486 : check e2422377330486 [[],[]] .smaller = true := by decide
def e2422377330490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377330490 : Closed e2422377330490 ∧ code e2422377330490 = 11218470352698 := by decide
theorem cert_e2422377330490 : check e2422377330490 [[],[]] .smaller = true := by decide
def e2422377330574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e2422377330574 : Closed e2422377330574 ∧ code e2422377330574 = 11218470352782 := by decide
theorem cert_e2422377330574 : check e2422377330574 [[],[]] .smaller = true := by decide
def e2422377330622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 4)))))))))
theorem wire_e2422377330622 : Closed e2422377330622 ∧ code e2422377330622 = 11218470352830 := by decide
theorem cert_e2422377330622 : check e2422377330622 [[],[]] .three = true := by decide
def e2422377330654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 4)) (.var 3)))))))))
theorem wire_e2422377330654 : Closed e2422377330654 ∧ code e2422377330654 = 11218470352862 := by decide
theorem cert_e2422377330654 : check e2422377330654 [[],[]] .three = true := by decide
def e2422377330910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e2422377330910 : Closed e2422377330910 ∧ code e2422377330910 = 11218470353118 := by decide
theorem cert_e2422377330910 : check e2422377330910 [[],[]] .smaller = true := by decide
def e2422377330926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2422377330926 : Closed e2422377330926 ∧ code e2422377330926 = 11218470353134 := by decide
theorem cert_e2422377330926 : check e2422377330926 [[],[]] .smaller = true := by decide
def e2422377330934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2422377330934 : Closed e2422377330934 ∧ code e2422377330934 = 11218470353142 := by decide
theorem cert_e2422377330934 : check e2422377330934 [[],[]] .smaller = true := by decide
def e2422377330938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e2422377330938 : Closed e2422377330938 ∧ code e2422377330938 = 11218470353146 := by decide
theorem cert_e2422377330938 : check e2422377330938 [[],[]] .smaller = true := by decide
def e2422377331118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422377331118 : Closed e2422377331118 ∧ code e2422377331118 = 11218470353326 := by decide
theorem cert_e2422377331118 : check e2422377331118 [[],[]] .smaller = true := by decide
def e2422377331130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422377331130 : Closed e2422377331130 ∧ code e2422377331130 = 11218470353338 := by decide
theorem cert_e2422377331130 : check e2422377331130 [[],[]] .smaller = true := by decide
def e2422377331178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422377331178 : Closed e2422377331178 ∧ code e2422377331178 = 11218470353386 := by decide
theorem cert_e2422377331178 : check e2422377331178 [[],[]] .smaller = true := by decide
def e2422377331262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e2422377331262 : Closed e2422377331262 ∧ code e2422377331262 = 11218470353470 := by decide
theorem cert_e2422377331262 : check e2422377331262 [[],[]] .smaller = true := by decide
def e2422377331310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377331310 : Closed e2422377331310 ∧ code e2422377331310 = 11218470353518 := by decide
theorem cert_e2422377331310 : check e2422377331310 [[],[]] .smaller = true := by decide
def e2422377331322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377331322 : Closed e2422377331322 ∧ code e2422377331322 = 11218470353530 := by decide
theorem cert_e2422377331322 : check e2422377331322 [[],[]] .smaller = true := by decide
def e2422377331486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2422377331486 : Closed e2422377331486 ∧ code e2422377331486 = 11218470353694 := by decide
theorem cert_e2422377331486 : check e2422377331486 [[],[]] .smaller = true := by decide
def e2422377331598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2422377331598 : Closed e2422377331598 ∧ code e2422377331598 = 11218470353806 := by decide
theorem cert_e2422377331598 : check e2422377331598 [[],[]] .smaller = true := by decide
def e2422377331610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377331610 : Closed e2422377331610 ∧ code e2422377331610 = 11218470353818 := by decide
theorem cert_e2422377331610 : check e2422377331610 [[],[]] .smaller = true := by decide
def e2422377331654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e2422377331654 : Closed e2422377331654 ∧ code e2422377331654 = 11218470353862 := by decide
theorem cert_e2422377331654 : check e2422377331654 [[],[]] .smaller = true := by decide
def e2422377331830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e2422377331830 : Closed e2422377331830 ∧ code e2422377331830 = 11218470354038 := by decide
theorem cert_e2422377331830 : check e2422377331830 [[],[]] .smaller = true := by decide
def e2422377331926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422377331926 : Closed e2422377331926 ∧ code e2422377331926 = 11218470354134 := by decide
theorem cert_e2422377331926 : check e2422377331926 [[],[]] .smaller = true := by decide
def e2422377331930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422377331930 : Closed e2422377331930 ∧ code e2422377331930 = 11218470354138 := by decide
theorem cert_e2422377331930 : check e2422377331930 [[],[]] .smaller = true := by decide
def e2422377331946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422377331946 : Closed e2422377331946 ∧ code e2422377331946 = 11218470354154 := by decide
theorem cert_e2422377331946 : check e2422377331946 [[],[]] .smaller = true := by decide
def e2422377332022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377332022 : Closed e2422377332022 ∧ code e2422377332022 = 11218470354230 := by decide
theorem cert_e2422377332022 : check e2422377332022 [[],[]] .smaller = true := by decide
def e2422377332026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377332026 : Closed e2422377332026 ∧ code e2422377332026 = 11218470354234 := by decide
theorem cert_e2422377332026 : check e2422377332026 [[],[]] .smaller = true := by decide
def e2422377332110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e2422377332110 : Closed e2422377332110 ∧ code e2422377332110 = 11218470354318 := by decide
theorem cert_e2422377332110 : check e2422377332110 [[],[]] .smaller = true := by decide
def e2422377332122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377332122 : Closed e2422377332122 ∧ code e2422377332122 = 11218470354330 := by decide
theorem cert_e2422377332122 : check e2422377332122 [[],[]] .smaller = true := by decide
def e2422377332278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422377332278 : Closed e2422377332278 ∧ code e2422377332278 = 11218470354486 := by decide
theorem cert_e2422377332278 : check e2422377332278 [[],[]] .smaller = true := by decide
def e2422377332282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422377332282 : Closed e2422377332282 ∧ code e2422377332282 = 11218470354490 := by decide
theorem cert_e2422377332282 : check e2422377332282 [[],[]] .smaller = true := by decide
def e2422377332366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422377332366 : Closed e2422377332366 ∧ code e2422377332366 = 11218470354574 := by decide
theorem cert_e2422377332366 : check e2422377332366 [[],[]] .smaller = true := by decide
def e2422377332414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 4)))))))))
theorem wire_e2422377332414 : Closed e2422377332414 ∧ code e2422377332414 = 11218470354622 := by decide
theorem cert_e2422377332414 : check e2422377332414 [[],[]] .three = true := by decide
def e2422377332422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422377332422 : Closed e2422377332422 ∧ code e2422377332422 = 11218470354630 := by decide
theorem cert_e2422377332422 : check e2422377332422 [[],[]] .smaller = true := by decide
def e2422377332474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 4)) (.var 0)))))))))
theorem wire_e2422377332474 : Closed e2422377332474 ∧ code e2422377332474 = 11218470354682 := by decide
theorem cert_e2422377332474 : check e2422377332474 [[],[]] .three = true := by decide
def e2422377332574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 4) (.var 0)) (.var 3)))))))))
theorem wire_e2422377332574 : Closed e2422377332574 ∧ code e2422377332574 = 11218470354782 := by decide
theorem cert_e2422377332574 : check e2422377332574 [[],[]] .three = true := by decide
def e2422377332602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 4) (.var 3)) (.var 0)))))))))
theorem wire_e2422377332602 : Closed e2422377332602 ∧ code e2422377332602 = 11218470354810 := by decide
theorem cert_e2422377332602 : check e2422377332602 [[],[]] .three = true := by decide
def e2422377335662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422377335662 : Closed e2422377335662 ∧ code e2422377335662 = 11218470357870 := by decide
theorem cert_e2422377335662 : check e2422377335662 [[],[]] .smaller = true := by decide
def e2422377335670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422377335670 : Closed e2422377335670 ∧ code e2422377335670 = 11218470357878 := by decide
theorem cert_e2422377335670 : check e2422377335670 [[],[]] .smaller = true := by decide
def e2422377335726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422377335726 : Closed e2422377335726 ∧ code e2422377335726 = 11218470357934 := by decide
theorem cert_e2422377335726 : check e2422377335726 [[],[]] .smaller = true := by decide
def e2422377335738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422377335738 : Closed e2422377335738 ∧ code e2422377335738 = 11218470357946 := by decide
theorem cert_e2422377335738 : check e2422377335738 [[],[]] .smaller = true := by decide
def e2422377335766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422377335766 : Closed e2422377335766 ∧ code e2422377335766 = 11218470357974 := by decide
theorem cert_e2422377335766 : check e2422377335766 [[],[]] .smaller = true := by decide
def e2422377335770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422377335770 : Closed e2422377335770 ∧ code e2422377335770 = 11218470357978 := by decide
theorem cert_e2422377335770 : check e2422377335770 [[],[]] .smaller = true := by decide
def e2422377336046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422377336046 : Closed e2422377336046 ∧ code e2422377336046 = 11218470358254 := by decide
theorem cert_e2422377336046 : check e2422377336046 [[],[]] .smaller = true := by decide
def e2422377336054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422377336054 : Closed e2422377336054 ∧ code e2422377336054 = 11218470358262 := by decide
theorem cert_e2422377336054 : check e2422377336054 [[],[]] .smaller = true := by decide
def e2422377336382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e2422377336382 : Closed e2422377336382 ∧ code e2422377336382 = 11218470358590 := by decide
theorem cert_e2422377336382 : check e2422377336382 [[],[]] .smaller = true := by decide
def e2422377336430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422377336430 : Closed e2422377336430 ∧ code e2422377336430 = 11218470358638 := by decide
theorem cert_e2422377336430 : check e2422377336430 [[],[]] .smaller = true := by decide
def e2422377336442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422377336442 : Closed e2422377336442 ∧ code e2422377336442 = 11218470358650 := by decide
theorem cert_e2422377336442 : check e2422377336442 [[],[]] .smaller = true := by decide
def e2422377336630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377336630 : Closed e2422377336630 ∧ code e2422377336630 = 11218470358838 := by decide
theorem cert_e2422377336630 : check e2422377336630 [[],[]] .smaller = true := by decide
def e2422377336634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377336634 : Closed e2422377336634 ∧ code e2422377336634 = 11218470358842 := by decide
theorem cert_e2422377336634 : check e2422377336634 [[],[]] .smaller = true := by decide
def e2422377336718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e2422377336718 : Closed e2422377336718 ∧ code e2422377336718 = 11218470358926 := by decide
theorem cert_e2422377336718 : check e2422377336718 [[],[]] .smaller = true := by decide
def e2422377336766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 4))))))))))
theorem wire_e2422377336766 : Closed e2422377336766 ∧ code e2422377336766 = 11218470358974 := by decide
theorem cert_e2422377336766 : check e2422377336766 [[],[]] .three = true := by decide
def e2422377336798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 4) (.var 3))))))))))
theorem wire_e2422377336798 : Closed e2422377336798 ∧ code e2422377336798 = 11218470359006 := by decide
theorem cert_e2422377336798 : check e2422377336798 [[],[]] .three = true := by decide
def e2422377342382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422377342382 : Closed e2422377342382 ∧ code e2422377342382 = 11218470364590 := by decide
theorem cert_e2422377342382 : check e2422377342382 [[],[]] .smaller = true := by decide
def e2422377342394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422377342394 : Closed e2422377342394 ∧ code e2422377342394 = 11218470364602 := by decide
theorem cert_e2422377342394 : check e2422377342394 [[],[]] .smaller = true := by decide
def e2422377342442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422377342442 : Closed e2422377342442 ∧ code e2422377342442 = 11218470364650 := by decide
theorem cert_e2422377342442 : check e2422377342442 [[],[]] .smaller = true := by decide
def e2422377342526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e2422377342526 : Closed e2422377342526 ∧ code e2422377342526 = 11218470364734 := by decide
theorem cert_e2422377342526 : check e2422377342526 [[],[]] .smaller = true := by decide
def e2422377342574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422377342574 : Closed e2422377342574 ∧ code e2422377342574 = 11218470364782 := by decide
theorem cert_e2422377342574 : check e2422377342574 [[],[]] .smaller = true := by decide
def e2422377342586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422377342586 : Closed e2422377342586 ∧ code e2422377342586 = 11218470364794 := by decide
theorem cert_e2422377342586 : check e2422377342586 [[],[]] .smaller = true := by decide
def e2422377342750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422377342750 : Closed e2422377342750 ∧ code e2422377342750 = 11218470364958 := by decide
theorem cert_e2422377342750 : check e2422377342750 [[],[]] .smaller = true := by decide
def e2422377342862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422377342862 : Closed e2422377342862 ∧ code e2422377342862 = 11218470365070 := by decide
theorem cert_e2422377342862 : check e2422377342862 [[],[]] .smaller = true := by decide
def e2422377342874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377342874 : Closed e2422377342874 ∧ code e2422377342874 = 11218470365082 := by decide
theorem cert_e2422377342874 : check e2422377342874 [[],[]] .smaller = true := by decide
def e2422377342918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e2422377342918 : Closed e2422377342918 ∧ code e2422377342918 = 11218470365126 := by decide
theorem cert_e2422377342918 : check e2422377342918 [[],[]] .smaller = true := by decide
def e2422377345750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422377345750 : Closed e2422377345750 ∧ code e2422377345750 = 11218470367958 := by decide
theorem cert_e2422377345750 : check e2422377345750 [[],[]] .smaller = true := by decide
def e2422377345754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422377345754 : Closed e2422377345754 ∧ code e2422377345754 = 11218470367962 := by decide
theorem cert_e2422377345754 : check e2422377345754 [[],[]] .smaller = true := by decide
def e2422377345770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422377345770 : Closed e2422377345770 ∧ code e2422377345770 = 11218470367978 := by decide
theorem cert_e2422377345770 : check e2422377345770 [[],[]] .smaller = true := by decide
def e2422377345846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377345846 : Closed e2422377345846 ∧ code e2422377345846 = 11218470368054 := by decide
theorem cert_e2422377345846 : check e2422377345846 [[],[]] .smaller = true := by decide
def e2422377345850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377345850 : Closed e2422377345850 ∧ code e2422377345850 = 11218470368058 := by decide
theorem cert_e2422377345850 : check e2422377345850 [[],[]] .smaller = true := by decide
def e2422377345934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422377345934 : Closed e2422377345934 ∧ code e2422377345934 = 11218470368142 := by decide
theorem cert_e2422377345934 : check e2422377345934 [[],[]] .smaller = true := by decide
def e2422377345946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377345946 : Closed e2422377345946 ∧ code e2422377345946 = 11218470368154 := by decide
theorem cert_e2422377345946 : check e2422377345946 [[],[]] .smaller = true := by decide
def e2422377347470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422377347470 : Closed e2422377347470 ∧ code e2422377347470 = 11218470369678 := by decide
theorem cert_e2422377347470 : check e2422377347470 [[],[]] .smaller = true := by decide
def e2422377347518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422377347518 : Closed e2422377347518 ∧ code e2422377347518 = 11218470369726 := by decide
theorem cert_e2422377347518 : check e2422377347518 [[],[]] .three = true := by decide
def e2422377347526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422377347526 : Closed e2422377347526 ∧ code e2422377347526 = 11218470369734 := by decide
theorem cert_e2422377347526 : check e2422377347526 [[],[]] .smaller = true := by decide
def e2422377347578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422377347578 : Closed e2422377347578 ∧ code e2422377347578 = 11218470369786 := by decide
theorem cert_e2422377347578 : check e2422377347578 [[],[]] .three = true := by decide
def e2422377348318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 4) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422377348318 : Closed e2422377348318 ∧ code e2422377348318 = 11218470370526 := by decide
theorem cert_e2422377348318 : check e2422377348318 [[],[]] .three = true := by decide
def e2422377348346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 4) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422377348346 : Closed e2422377348346 ∧ code e2422377348346 = 11218470370554 := by decide
theorem cert_e2422377348346 : check e2422377348346 [[],[]] .three = true := by decide
end Blc.Floor43
