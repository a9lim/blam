import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598661598446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598661598446 : Closed e598661598446 ∧ code e598661598446 = 9394754620654 := by decide
theorem cert_e598661598446 : check e598661598446 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661598454 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598661598454 : Closed e598661598454 ∧ code e598661598454 = 9394754620662 := by decide
theorem cert_e598661598454 : check e598661598454 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661598830 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598661598830 : Closed e598661598830 ∧ code e598661598830 = 9394754621038 := by decide
theorem cert_e598661598830 : check e598661598830 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661598842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598661598842 : Closed e598661598842 ∧ code e598661598842 = 9394754621050 := by decide
theorem cert_e598661598842 : check e598661598842 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661599030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598661599030 : Closed e598661599030 ∧ code e598661599030 = 9394754621238 := by decide
theorem cert_e598661599030 : check e598661599030 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661599034 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598661599034 : Closed e598661599034 ∧ code e598661599034 = 9394754621242 := by decide
theorem cert_e598661599034 : check e598661599034 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598662187886 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598662187886 : Closed e598662187886 ∧ code e598662187886 = 9394755210094 := by decide
theorem cert_e598662187886 : check e598662187886 [[.under],[.under,.left]] .chain = true := by decide
def e598662187894 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598662187894 : Closed e598662187894 ∧ code e598662187894 = 9394755210102 := by decide
theorem cert_e598662187894 : check e598662187894 [[.under],[.under,.left]] .chain = true := by decide
def e598662187950 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598662187950 : Closed e598662187950 ∧ code e598662187950 = 9394755210158 := by decide
theorem cert_e598662187950 : check e598662187950 [[.under],[.under,.left]] .chain = true := by decide
def e598662187962 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598662187962 : Closed e598662187962 ∧ code e598662187962 = 9394755210170 := by decide
theorem cert_e598662187962 : check e598662187962 [[.under],[.under,.left]] .chain = true := by decide
def e598662187990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598662187990 : Closed e598662187990 ∧ code e598662187990 = 9394755210198 := by decide
theorem cert_e598662187990 : check e598662187990 [[.under],[.under,.left]] .chain = true := by decide
def e598662187994 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598662187994 : Closed e598662187994 ∧ code e598662187994 = 9394755210202 := by decide
theorem cert_e598662187994 : check e598662187994 [[.under],[.under,.left]] .chain = true := by decide
def e598662188270 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598662188270 : Closed e598662188270 ∧ code e598662188270 = 9394755210478 := by decide
theorem cert_e598662188270 : check e598662188270 [[.under],[.under,.left]] .chain = true := by decide
def e598662188278 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598662188278 : Closed e598662188278 ∧ code e598662188278 = 9394755210486 := by decide
theorem cert_e598662188278 : check e598662188278 [[.under],[.under,.left]] .chain = true := by decide
def e598662188654 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598662188654 : Closed e598662188654 ∧ code e598662188654 = 9394755210862 := by decide
theorem cert_e598662188654 : check e598662188654 [[.under],[.under,.left]] .chain = true := by decide
def e598662188666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598662188666 : Closed e598662188666 ∧ code e598662188666 = 9394755210874 := by decide
theorem cert_e598662188666 : check e598662188666 [[.under],[.under,.left]] .chain = true := by decide
def e598662188854 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598662188854 : Closed e598662188854 ∧ code e598662188854 = 9394755211062 := by decide
theorem cert_e598662188854 : check e598662188854 [[.under],[.under,.left]] .chain = true := by decide
def e598662188858 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598662188858 : Closed e598662188858 ∧ code e598662188858 = 9394755211066 := by decide
theorem cert_e598662188858 : check e598662188858 [[.under],[.under,.left]] .chain = true := by decide
def e598745373406 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e598745373406 : Closed e598745373406 ∧ code e598745373406 = 9394838395614 := by decide
theorem cert_e598745373406 : check e598745373406 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745373430 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e598745373430 : Closed e598745373430 ∧ code e598745373430 = 9394838395638 := by decide
theorem cert_e598745373430 : check e598745373430 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745373534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e598745373534 : Closed e598745373534 ∧ code e598745373534 = 9394838395742 := by decide
theorem cert_e598745373534 : check e598745373534 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745373550 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e598745373550 : Closed e598745373550 ∧ code e598745373550 = 9394838395758 := by decide
theorem cert_e598745373550 : check e598745373550 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745373558 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e598745373558 : Closed e598745373558 ∧ code e598745373558 = 9394838395766 := by decide
theorem cert_e598745373558 : check e598745373558 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745373562 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e598745373562 : Closed e598745373562 ∧ code e598745373562 = 9394838395770 := by decide
theorem cert_e598745373562 : check e598745373562 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745373622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e598745373622 : Closed e598745373622 ∧ code e598745373622 = 9394838395830 := by decide
theorem cert_e598745373622 : check e598745373622 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745373654 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e598745373654 : Closed e598745373654 ∧ code e598745373654 = 9394838395862 := by decide
theorem cert_e598745373654 : check e598745373654 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745373658 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e598745373658 : Closed e598745373658 ∧ code e598745373658 = 9394838395866 := by decide
theorem cert_e598745373658 : check e598745373658 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745374046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e598745374046 : Closed e598745374046 ∧ code e598745374046 = 9394838396254 := by decide
theorem cert_e598745374046 : check e598745374046 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745374062 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e598745374062 : Closed e598745374062 ∧ code e598745374062 = 9394838396270 := by decide
theorem cert_e598745374062 : check e598745374062 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745374070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e598745374070 : Closed e598745374070 ∧ code e598745374070 = 9394838396278 := by decide
theorem cert_e598745374070 : check e598745374070 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745374074 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e598745374074 : Closed e598745374074 ∧ code e598745374074 = 9394838396282 := by decide
theorem cert_e598745374074 : check e598745374074 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745374126 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e598745374126 : Closed e598745374126 ∧ code e598745374126 = 9394838396334 := by decide
theorem cert_e598745374126 : check e598745374126 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745374138 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e598745374138 : Closed e598745374138 ∧ code e598745374138 = 9394838396346 := by decide
theorem cert_e598745374138 : check e598745374138 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745374166 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e598745374166 : Closed e598745374166 ∧ code e598745374166 = 9394838396374 := by decide
theorem cert_e598745374166 : check e598745374166 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745374170 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e598745374170 : Closed e598745374170 ∧ code e598745374170 = 9394838396378 := by decide
theorem cert_e598745374170 : check e598745374170 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745374186 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e598745374186 : Closed e598745374186 ∧ code e598745374186 = 9394838396394 := by decide
theorem cert_e598745374186 : check e598745374186 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745374390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e598745374390 : Closed e598745374390 ∧ code e598745374390 = 9394838396598 := by decide
theorem cert_e598745374390 : check e598745374390 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745374422 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e598745374422 : Closed e598745374422 ∧ code e598745374422 = 9394838396630 := by decide
theorem cert_e598745374422 : check e598745374422 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745374426 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e598745374426 : Closed e598745374426 ∧ code e598745374426 = 9394838396634 := by decide
theorem cert_e598745374426 : check e598745374426 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745374550 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e598745374550 : Closed e598745374550 ∧ code e598745374550 = 9394838396758 := by decide
theorem cert_e598745374550 : check e598745374550 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745374554 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e598745374554 : Closed e598745374554 ∧ code e598745374554 = 9394838396762 := by decide
theorem cert_e598745374554 : check e598745374554 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745374570 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e598745374570 : Closed e598745374570 ∧ code e598745374570 = 9394838396778 := by decide
theorem cert_e598745374570 : check e598745374570 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745376478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e598745376478 : Closed e598745376478 ∧ code e598745376478 = 9394838398686 := by decide
theorem cert_e598745376478 : check e598745376478 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745376502 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e598745376502 : Closed e598745376502 ∧ code e598745376502 = 9394838398710 := by decide
theorem cert_e598745376502 : check e598745376502 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745376606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e598745376606 : Closed e598745376606 ∧ code e598745376606 = 9394838398814 := by decide
theorem cert_e598745376606 : check e598745376606 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745376622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e598745376622 : Closed e598745376622 ∧ code e598745376622 = 9394838398830 := by decide
theorem cert_e598745376622 : check e598745376622 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745376630 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e598745376630 : Closed e598745376630 ∧ code e598745376630 = 9394838398838 := by decide
theorem cert_e598745376630 : check e598745376630 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745376634 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e598745376634 : Closed e598745376634 ∧ code e598745376634 = 9394838398842 := by decide
theorem cert_e598745376634 : check e598745376634 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745376694 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e598745376694 : Closed e598745376694 ∧ code e598745376694 = 9394838398902 := by decide
theorem cert_e598745376694 : check e598745376694 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745376726 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e598745376726 : Closed e598745376726 ∧ code e598745376726 = 9394838398934 := by decide
theorem cert_e598745376726 : check e598745376726 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745376730 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e598745376730 : Closed e598745376730 ∧ code e598745376730 = 9394838398938 := by decide
theorem cert_e598745376730 : check e598745376730 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745377246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e598745377246 : Closed e598745377246 ∧ code e598745377246 = 9394838399454 := by decide
theorem cert_e598745377246 : check e598745377246 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745377270 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e598745377270 : Closed e598745377270 ∧ code e598745377270 = 9394838399478 := by decide
theorem cert_e598745377270 : check e598745377270 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745378014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e598745378014 : Closed e598745378014 ∧ code e598745378014 = 9394838400222 := by decide
theorem cert_e598745378014 : check e598745378014 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745378030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e598745378030 : Closed e598745378030 ∧ code e598745378030 = 9394838400238 := by decide
theorem cert_e598745378030 : check e598745378030 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745378038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e598745378038 : Closed e598745378038 ∧ code e598745378038 = 9394838400246 := by decide
theorem cert_e598745378038 : check e598745378038 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745378042 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e598745378042 : Closed e598745378042 ∧ code e598745378042 = 9394838400250 := by decide
theorem cert_e598745378042 : check e598745378042 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745378422 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e598745378422 : Closed e598745378422 ∧ code e598745378422 = 9394838400630 := by decide
theorem cert_e598745378422 : check e598745378422 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745378614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598745378614 : Closed e598745378614 ∧ code e598745378614 = 9394838400822 := by decide
theorem cert_e598745378614 : check e598745378614 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745378618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598745378618 : Closed e598745378618 ∧ code e598745378618 = 9394838400826 := by decide
theorem cert_e598745378618 : check e598745378618 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745379678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e598745379678 : Closed e598745379678 ∧ code e598745379678 = 9394838401886 := by decide
theorem cert_e598745379678 : check e598745379678 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745379694 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e598745379694 : Closed e598745379694 ∧ code e598745379694 = 9394838401902 := by decide
theorem cert_e598745379694 : check e598745379694 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745379702 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e598745379702 : Closed e598745379702 ∧ code e598745379702 = 9394838401910 := by decide
theorem cert_e598745379702 : check e598745379702 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745379706 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e598745379706 : Closed e598745379706 ∧ code e598745379706 = 9394838401914 := by decide
theorem cert_e598745379706 : check e598745379706 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745379758 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e598745379758 : Closed e598745379758 ∧ code e598745379758 = 9394838401966 := by decide
theorem cert_e598745379758 : check e598745379758 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745379770 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e598745379770 : Closed e598745379770 ∧ code e598745379770 = 9394838401978 := by decide
theorem cert_e598745379770 : check e598745379770 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745379798 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e598745379798 : Closed e598745379798 ∧ code e598745379798 = 9394838402006 := by decide
theorem cert_e598745379798 : check e598745379798 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745379802 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e598745379802 : Closed e598745379802 ∧ code e598745379802 = 9394838402010 := by decide
theorem cert_e598745379802 : check e598745379802 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745379818 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e598745379818 : Closed e598745379818 ∧ code e598745379818 = 9394838402026 := by decide
theorem cert_e598745379818 : check e598745379818 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745380062 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e598745380062 : Closed e598745380062 ∧ code e598745380062 = 9394838402270 := by decide
theorem cert_e598745380062 : check e598745380062 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745380078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e598745380078 : Closed e598745380078 ∧ code e598745380078 = 9394838402286 := by decide
theorem cert_e598745380078 : check e598745380078 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745380086 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e598745380086 : Closed e598745380086 ∧ code e598745380086 = 9394838402294 := by decide
theorem cert_e598745380086 : check e598745380086 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745380090 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e598745380090 : Closed e598745380090 ∧ code e598745380090 = 9394838402298 := by decide
theorem cert_e598745380090 : check e598745380090 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745380462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e598745380462 : Closed e598745380462 ∧ code e598745380462 = 9394838402670 := by decide
theorem cert_e598745380462 : check e598745380462 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745380474 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e598745380474 : Closed e598745380474 ∧ code e598745380474 = 9394838402682 := by decide
theorem cert_e598745380474 : check e598745380474 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745380662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598745380662 : Closed e598745380662 ∧ code e598745380662 = 9394838402870 := by decide
theorem cert_e598745380662 : check e598745380662 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745380666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598745380666 : Closed e598745380666 ∧ code e598745380666 = 9394838402874 := by decide
theorem cert_e598745380666 : check e598745380666 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745380762 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e598745380762 : Closed e598745380762 ∧ code e598745380762 = 9394838402970 := by decide
theorem cert_e598745380762 : check e598745380762 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745381302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e598745381302 : Closed e598745381302 ∧ code e598745381302 = 9394838403510 := by decide
theorem cert_e598745381302 : check e598745381302 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745381334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e598745381334 : Closed e598745381334 ∧ code e598745381334 = 9394838403542 := by decide
theorem cert_e598745381334 : check e598745381334 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745381338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e598745381338 : Closed e598745381338 ∧ code e598745381338 = 9394838403546 := by decide
theorem cert_e598745381338 : check e598745381338 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745381494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e598745381494 : Closed e598745381494 ∧ code e598745381494 = 9394838403702 := by decide
theorem cert_e598745381494 : check e598745381494 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745381686 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598745381686 : Closed e598745381686 ∧ code e598745381686 = 9394838403894 := by decide
theorem cert_e598745381686 : check e598745381686 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745381690 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598745381690 : Closed e598745381690 ∧ code e598745381690 = 9394838403898 := by decide
theorem cert_e598745381690 : check e598745381690 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745382102 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e598745382102 : Closed e598745382102 ∧ code e598745382102 = 9394838404310 := by decide
theorem cert_e598745382102 : check e598745382102 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745382106 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e598745382106 : Closed e598745382106 ∧ code e598745382106 = 9394838404314 := by decide
theorem cert_e598745382106 : check e598745382106 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745382122 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e598745382122 : Closed e598745382122 ∧ code e598745382122 = 9394838404330 := by decide
theorem cert_e598745382122 : check e598745382122 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745382198 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598745382198 : Closed e598745382198 ∧ code e598745382198 = 9394838404406 := by decide
theorem cert_e598745382198 : check e598745382198 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745382202 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598745382202 : Closed e598745382202 ∧ code e598745382202 = 9394838404410 := by decide
theorem cert_e598745382202 : check e598745382202 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745382298 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e598745382298 : Closed e598745382298 ∧ code e598745382298 = 9394838404506 := by decide
theorem cert_e598745382298 : check e598745382298 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745388766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e598745388766 : Closed e598745388766 ∧ code e598745388766 = 9394838410974 := by decide
theorem cert_e598745388766 : check e598745388766 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745388790 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e598745388790 : Closed e598745388790 ∧ code e598745388790 = 9394838410998 := by decide
theorem cert_e598745388790 : check e598745388790 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745388894 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e598745388894 : Closed e598745388894 ∧ code e598745388894 = 9394838411102 := by decide
theorem cert_e598745388894 : check e598745388894 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745388910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e598745388910 : Closed e598745388910 ∧ code e598745388910 = 9394838411118 := by decide
theorem cert_e598745388910 : check e598745388910 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745388918 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e598745388918 : Closed e598745388918 ∧ code e598745388918 = 9394838411126 := by decide
theorem cert_e598745388918 : check e598745388918 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745388922 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e598745388922 : Closed e598745388922 ∧ code e598745388922 = 9394838411130 := by decide
theorem cert_e598745388922 : check e598745388922 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745388982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e598745388982 : Closed e598745388982 ∧ code e598745388982 = 9394838411190 := by decide
theorem cert_e598745388982 : check e598745388982 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745389014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e598745389014 : Closed e598745389014 ∧ code e598745389014 = 9394838411222 := by decide
theorem cert_e598745389014 : check e598745389014 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745389018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e598745389018 : Closed e598745389018 ∧ code e598745389018 = 9394838411226 := by decide
theorem cert_e598745389018 : check e598745389018 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745389534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e598745389534 : Closed e598745389534 ∧ code e598745389534 = 9394838411742 := by decide
theorem cert_e598745389534 : check e598745389534 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745389558 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e598745389558 : Closed e598745389558 ∧ code e598745389558 = 9394838411766 := by decide
theorem cert_e598745389558 : check e598745389558 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745390302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e598745390302 : Closed e598745390302 ∧ code e598745390302 = 9394838412510 := by decide
theorem cert_e598745390302 : check e598745390302 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745390318 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e598745390318 : Closed e598745390318 ∧ code e598745390318 = 9394838412526 := by decide
theorem cert_e598745390318 : check e598745390318 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745390326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e598745390326 : Closed e598745390326 ∧ code e598745390326 = 9394838412534 := by decide
theorem cert_e598745390326 : check e598745390326 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745390330 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e598745390330 : Closed e598745390330 ∧ code e598745390330 = 9394838412538 := by decide
theorem cert_e598745390330 : check e598745390330 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745390710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e598745390710 : Closed e598745390710 ∧ code e598745390710 = 9394838412918 := by decide
theorem cert_e598745390710 : check e598745390710 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745390902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e598745390902 : Closed e598745390902 ∧ code e598745390902 = 9394838413110 := by decide
theorem cert_e598745390902 : check e598745390902 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745390906 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e598745390906 : Closed e598745390906 ∧ code e598745390906 = 9394838413114 := by decide
theorem cert_e598745390906 : check e598745390906 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745402206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e598745402206 : Closed e598745402206 ∧ code e598745402206 = 9394838424414 := by decide
theorem cert_e598745402206 : check e598745402206 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745402222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598745402222 : Closed e598745402222 ∧ code e598745402222 = 9394838424430 := by decide
theorem cert_e598745402222 : check e598745402222 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745402230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598745402230 : Closed e598745402230 ∧ code e598745402230 = 9394838424438 := by decide
theorem cert_e598745402230 : check e598745402230 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745402234 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e598745402234 : Closed e598745402234 ∧ code e598745402234 = 9394838424442 := by decide
theorem cert_e598745402234 : check e598745402234 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745402286 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598745402286 : Closed e598745402286 ∧ code e598745402286 = 9394838424494 := by decide
theorem cert_e598745402286 : check e598745402286 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745402298 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598745402298 : Closed e598745402298 ∧ code e598745402298 = 9394838424506 := by decide
theorem cert_e598745402298 : check e598745402298 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745402326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598745402326 : Closed e598745402326 ∧ code e598745402326 = 9394838424534 := by decide
theorem cert_e598745402326 : check e598745402326 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745402330 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598745402330 : Closed e598745402330 ∧ code e598745402330 = 9394838424538 := by decide
theorem cert_e598745402330 : check e598745402330 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745402346 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e598745402346 : Closed e598745402346 ∧ code e598745402346 = 9394838424554 := by decide
theorem cert_e598745402346 : check e598745402346 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745402590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e598745402590 : Closed e598745402590 ∧ code e598745402590 = 9394838424798 := by decide
theorem cert_e598745402590 : check e598745402590 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745402606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598745402606 : Closed e598745402606 ∧ code e598745402606 = 9394838424814 := by decide
theorem cert_e598745402606 : check e598745402606 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745402614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598745402614 : Closed e598745402614 ∧ code e598745402614 = 9394838424822 := by decide
theorem cert_e598745402614 : check e598745402614 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745402618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e598745402618 : Closed e598745402618 ∧ code e598745402618 = 9394838424826 := by decide
theorem cert_e598745402618 : check e598745402618 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745402990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598745402990 : Closed e598745402990 ∧ code e598745402990 = 9394838425198 := by decide
theorem cert_e598745402990 : check e598745402990 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745403002 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598745403002 : Closed e598745403002 ∧ code e598745403002 = 9394838425210 := by decide
theorem cert_e598745403002 : check e598745403002 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745403190 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598745403190 : Closed e598745403190 ∧ code e598745403190 = 9394838425398 := by decide
theorem cert_e598745403190 : check e598745403190 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745403194 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598745403194 : Closed e598745403194 ∧ code e598745403194 = 9394838425402 := by decide
theorem cert_e598745403194 : check e598745403194 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745403290 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e598745403290 : Closed e598745403290 ∧ code e598745403290 = 9394838425498 := by decide
theorem cert_e598745403290 : check e598745403290 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745408950 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e598745408950 : Closed e598745408950 ∧ code e598745408950 = 9394838431158 := by decide
theorem cert_e598745408950 : check e598745408950 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745408982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e598745408982 : Closed e598745408982 ∧ code e598745408982 = 9394838431190 := by decide
theorem cert_e598745408982 : check e598745408982 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745408986 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e598745408986 : Closed e598745408986 ∧ code e598745408986 = 9394838431194 := by decide
theorem cert_e598745408986 : check e598745408986 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745409142 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e598745409142 : Closed e598745409142 ∧ code e598745409142 = 9394838431350 := by decide
theorem cert_e598745409142 : check e598745409142 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745409334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e598745409334 : Closed e598745409334 ∧ code e598745409334 = 9394838431542 := by decide
theorem cert_e598745409334 : check e598745409334 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745409338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e598745409338 : Closed e598745409338 ∧ code e598745409338 = 9394838431546 := by decide
theorem cert_e598745409338 : check e598745409338 [[.under],[.under,.left],[.under]] .three = true := by decide
def e598745412310 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e598745412310 : Closed e598745412310 ∧ code e598745412310 = 9394838434518 := by decide
theorem cert_e598745412310 : check e598745412310 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745412314 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e598745412314 : Closed e598745412314 ∧ code e598745412314 = 9394838434522 := by decide
theorem cert_e598745412314 : check e598745412314 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745412330 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e598745412330 : Closed e598745412330 ∧ code e598745412330 = 9394838434538 := by decide
theorem cert_e598745412330 : check e598745412330 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745412406 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e598745412406 : Closed e598745412406 ∧ code e598745412406 = 9394838434614 := by decide
theorem cert_e598745412406 : check e598745412406 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745412410 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e598745412410 : Closed e598745412410 ∧ code e598745412410 = 9394838434618 := by decide
theorem cert_e598745412410 : check e598745412410 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745412506 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e598745412506 : Closed e598745412506 ∧ code e598745412506 = 9394838434714 := by decide
theorem cert_e598745412506 : check e598745412506 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745637742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e598745637742 : Closed e598745637742 ∧ code e598745637742 = 9394838659950 := by decide
theorem cert_e598745637742 : check e598745637742 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745637750 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e598745637750 : Closed e598745637750 ∧ code e598745637750 = 9394838659958 := by decide
theorem cert_e598745637750 : check e598745637750 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745637806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e598745637806 : Closed e598745637806 ∧ code e598745637806 = 9394838660014 := by decide
theorem cert_e598745637806 : check e598745637806 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745637818 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e598745637818 : Closed e598745637818 ∧ code e598745637818 = 9394838660026 := by decide
theorem cert_e598745637818 : check e598745637818 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745637846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e598745637846 : Closed e598745637846 ∧ code e598745637846 = 9394838660054 := by decide
theorem cert_e598745637846 : check e598745637846 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745637850 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e598745637850 : Closed e598745637850 ∧ code e598745637850 = 9394838660058 := by decide
theorem cert_e598745637850 : check e598745637850 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745639150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e598745639150 : Closed e598745639150 ∧ code e598745639150 = 9394838661358 := by decide
theorem cert_e598745639150 : check e598745639150 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745639158 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e598745639158 : Closed e598745639158 ∧ code e598745639158 = 9394838661366 := by decide
theorem cert_e598745639158 : check e598745639158 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745639710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e598745639710 : Closed e598745639710 ∧ code e598745639710 = 9394838661918 := by decide
theorem cert_e598745639710 : check e598745639710 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745639822 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e598745639822 : Closed e598745639822 ∧ code e598745639822 = 9394838662030 := by decide
theorem cert_e598745639822 : check e598745639822 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745640046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e598745640046 : Closed e598745640046 ∧ code e598745640046 = 9394838662254 := by decide
theorem cert_e598745640046 : check e598745640046 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745640058 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e598745640058 : Closed e598745640058 ∧ code e598745640058 = 9394838662266 := by decide
theorem cert_e598745640058 : check e598745640058 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745640222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e598745640222 : Closed e598745640222 ∧ code e598745640222 = 9394838662430 := by decide
theorem cert_e598745640222 : check e598745640222 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745640390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e598745640390 : Closed e598745640390 ∧ code e598745640390 = 9394838662598 := by decide
theorem cert_e598745640390 : check e598745640390 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745640502 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e598745640502 : Closed e598745640502 ∧ code e598745640502 = 9394838662710 := by decide
theorem cert_e598745640502 : check e598745640502 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745640506 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e598745640506 : Closed e598745640506 ∧ code e598745640506 = 9394838662714 := by decide
theorem cert_e598745640506 : check e598745640506 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745640590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e598745640590 : Closed e598745640590 ∧ code e598745640590 = 9394838662798 := by decide
theorem cert_e598745640590 : check e598745640590 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745640646 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e598745640646 : Closed e598745640646 ∧ code e598745640646 = 9394838662854 := by decide
theorem cert_e598745640646 : check e598745640646 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745641390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e598745641390 : Closed e598745641390 ∧ code e598745641390 = 9394838663598 := by decide
theorem cert_e598745641390 : check e598745641390 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745641402 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e598745641402 : Closed e598745641402 ∧ code e598745641402 = 9394838663610 := by decide
theorem cert_e598745641402 : check e598745641402 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745641450 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e598745641450 : Closed e598745641450 ∧ code e598745641450 = 9394838663658 := by decide
theorem cert_e598745641450 : check e598745641450 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745642094 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e598745642094 : Closed e598745642094 ∧ code e598745642094 = 9394838664302 := by decide
theorem cert_e598745642094 : check e598745642094 [[.under],[.under,.left],[.under]] .chain = true := by decide
end Blc.Floor43
