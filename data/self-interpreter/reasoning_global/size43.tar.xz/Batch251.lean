import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405910152718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405910152718 : Closed e2405910152718 ∧ code e2405910152718 = 11202003174926 := by decide
theorem cert_e2405910152718 : check e2405910152718 [[]] .width = true := by decide
def e2405910152730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910152730 : Closed e2405910152730 ∧ code e2405910152730 = 11202003174938 := by decide
theorem cert_e2405910152730 : check e2405910152730 [[]] .width = true := by decide
def e2405910152802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405910152802 : Closed e2405910152802 ∧ code e2405910152802 = 11202003175010 := by decide
theorem cert_e2405910152802 : check e2405910152802 [[]] .width = true := by decide
def e2405910298822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405910298822 : Closed e2405910298822 ∧ code e2405910298822 = 11202003321030 := by decide
theorem cert_e2405910298822 : check e2405910298822 [[]] .width = true := by decide
def e2405910317082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910317082 : Closed e2405910317082 ∧ code e2405910317082 = 11202003339290 := by decide
theorem cert_e2405910317082 : check e2405910317082 [[]] .width = true := by decide
def e2405910323226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910323226 : Closed e2405910323226 ∧ code e2405910323226 = 11202003345434 := by decide
theorem cert_e2405910323226 : check e2405910323226 [[]] .width = true := by decide
def e2405910323318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405910323318 : Closed e2405910323318 ∧ code e2405910323318 = 11202003345526 := by decide
theorem cert_e2405910323318 : check e2405910323318 [[]] .width = true := by decide
def e2405910323562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405910323562 : Closed e2405910323562 ∧ code e2405910323562 = 11202003345770 := by decide
theorem cert_e2405910323562 : check e2405910323562 [[]] .width = true := by decide
def e2405910323610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405910323610 : Closed e2405910323610 ∧ code e2405910323610 = 11202003345818 := by decide
theorem cert_e2405910323610 : check e2405910323610 [[]] .width = true := by decide
def e2405910327494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405910327494 : Closed e2405910327494 ∧ code e2405910327494 = 11202003349702 := by decide
theorem cert_e2405910327494 : check e2405910327494 [[]] .width = true := by decide
def e2405910329370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910329370 : Closed e2405910329370 ∧ code e2405910329370 = 11202003351578 := by decide
theorem cert_e2405910329370 : check e2405910329370 [[]] .width = true := by decide
def e2405910341658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910341658 : Closed e2405910341658 ∧ code e2405910341658 = 11202003363866 := by decide
theorem cert_e2405910341658 : check e2405910341658 [[]] .width = true := by decide
def e2405910343194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910343194 : Closed e2405910343194 ∧ code e2405910343194 = 11202003365402 := by decide
theorem cert_e2405910343194 : check e2405910343194 [[]] .width = true := by decide
def e2405910346266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910346266 : Closed e2405910346266 ∧ code e2405910346266 = 11202003368474 := by decide
theorem cert_e2405910346266 : check e2405910346266 [[]] .width = true := by decide
def e2405910347802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405910347802 : Closed e2405910347802 ∧ code e2405910347802 = 11202003370010 := by decide
theorem cert_e2405910347802 : check e2405910347802 [[]] .width = true := by decide
def e2405910347894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405910347894 : Closed e2405910347894 ∧ code e2405910347894 = 11202003370102 := by decide
theorem cert_e2405910347894 : check e2405910347894 [[]] .width = true := by decide
def e2405910348138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405910348138 : Closed e2405910348138 ∧ code e2405910348138 = 11202003370346 := by decide
theorem cert_e2405910348138 : check e2405910348138 [[]] .width = true := by decide
def e2405910348186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405910348186 : Closed e2405910348186 ∧ code e2405910348186 = 11202003370394 := by decide
theorem cert_e2405910348186 : check e2405910348186 [[]] .width = true := by decide
def e2405910349194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405910349194 : Closed e2405910349194 ∧ code e2405910349194 = 11202003371402 := by decide
theorem cert_e2405910349194 : check e2405910349194 [[]] .width = true := by decide
def e2405910349218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405910349218 : Closed e2405910349218 ∧ code e2405910349218 = 11202003371426 := by decide
theorem cert_e2405910349218 : check e2405910349218 [[]] .width = true := by decide
def e2405910349326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405910349326 : Closed e2405910349326 ∧ code e2405910349326 = 11202003371534 := by decide
theorem cert_e2405910349326 : check e2405910349326 [[]] .width = true := by decide
def e2405910349338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910349338 : Closed e2405910349338 ∧ code e2405910349338 = 11202003371546 := by decide
theorem cert_e2405910349338 : check e2405910349338 [[]] .width = true := by decide
def e2405910349410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405910349410 : Closed e2405910349410 ∧ code e2405910349410 = 11202003371618 := by decide
theorem cert_e2405910349410 : check e2405910349410 [[]] .width = true := by decide
def e2405910364358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405910364358 : Closed e2405910364358 ∧ code e2405910364358 = 11202003386566 := by decide
theorem cert_e2405910364358 : check e2405910364358 [[]] .width = true := by decide
def e2405910372378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910372378 : Closed e2405910372378 ∧ code e2405910372378 = 11202003394586 := by decide
theorem cert_e2405910372378 : check e2405910372378 [[]] .width = true := by decide
def e2405910372470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405910372470 : Closed e2405910372470 ∧ code e2405910372470 = 11202003394678 := by decide
theorem cert_e2405910372470 : check e2405910372470 [[]] .width = true := by decide
def e2405910372714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405910372714 : Closed e2405910372714 ∧ code e2405910372714 = 11202003394922 := by decide
theorem cert_e2405910372714 : check e2405910372714 [[]] .width = true := by decide
def e2405910372762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405910372762 : Closed e2405910372762 ∧ code e2405910372762 = 11202003394970 := by decide
theorem cert_e2405910372762 : check e2405910372762 [[]] .width = true := by decide
def e2405910468634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910468634 : Closed e2405910468634 ∧ code e2405910468634 = 11202003490842 := by decide
theorem cert_e2405910468634 : check e2405910468634 [[]] .width = true := by decide
def e2405910536218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910536218 : Closed e2405910536218 ∧ code e2405910536218 = 11202003558426 := by decide
theorem cert_e2405910536218 : check e2405910536218 [[]] .width = true := by decide
def e2405910536310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405910536310 : Closed e2405910536310 ∧ code e2405910536310 = 11202003558518 := by decide
theorem cert_e2405910536310 : check e2405910536310 [[]] .width = true := by decide
def e2405910536554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405910536554 : Closed e2405910536554 ∧ code e2405910536554 = 11202003558762 := by decide
theorem cert_e2405910536554 : check e2405910536554 [[]] .width = true := by decide
def e2405910536602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405910536602 : Closed e2405910536602 ∧ code e2405910536602 = 11202003558810 := by decide
theorem cert_e2405910536602 : check e2405910536602 [[]] .width = true := by decide
def e2405910556870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405910556870 : Closed e2405910556870 ∧ code e2405910556870 = 11202003579078 := by decide
theorem cert_e2405910556870 : check e2405910556870 [[]] .width = true := by decide
def e2405910565062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405910565062 : Closed e2405910565062 ∧ code e2405910565062 = 11202003587270 := by decide
theorem cert_e2405910565062 : check e2405910565062 [[]] .width = true := by decide
def e2405910566938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910566938 : Closed e2405910566938 ∧ code e2405910566938 = 11202003589146 := by decide
theorem cert_e2405910566938 : check e2405910566938 [[]] .width = true := by decide
def e2405910665242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910665242 : Closed e2405910665242 ∧ code e2405910665242 = 11202003687450 := by decide
theorem cert_e2405910665242 : check e2405910665242 [[]] .width = true := by decide
def e2405910669338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910669338 : Closed e2405910669338 ∧ code e2405910669338 = 11202003691546 := by decide
theorem cert_e2405910669338 : check e2405910669338 [[]] .width = true := by decide
def e2405910670874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910670874 : Closed e2405910670874 ∧ code e2405910670874 = 11202003693082 := by decide
theorem cert_e2405910670874 : check e2405910670874 [[]] .width = true := by decide
def e2405910672922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910672922 : Closed e2405910672922 ∧ code e2405910672922 = 11202003695130 := by decide
theorem cert_e2405910672922 : check e2405910672922 [[]] .width = true := by decide
def e2405910685722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910685722 : Closed e2405910685722 ∧ code e2405910685722 = 11202003707930 := by decide
theorem cert_e2405910685722 : check e2405910685722 [[]] .width = true := by decide
def e2405910687258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910687258 : Closed e2405910687258 ∧ code e2405910687258 = 11202003709466 := by decide
theorem cert_e2405910687258 : check e2405910687258 [[]] .width = true := by decide
def e2405910690330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910690330 : Closed e2405910690330 ∧ code e2405910690330 = 11202003712538 := by decide
theorem cert_e2405910690330 : check e2405910690330 [[]] .width = true := by decide
def e2405910697498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910697498 : Closed e2405910697498 ∧ code e2405910697498 = 11202003719706 := by decide
theorem cert_e2405910697498 : check e2405910697498 [[]] .width = true := by decide
def e2405910698522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910698522 : Closed e2405910698522 ∧ code e2405910698522 = 11202003720730 := by decide
theorem cert_e2405910698522 : check e2405910698522 [[]] .width = true := by decide
def e2405910737094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405910737094 : Closed e2405910737094 ∧ code e2405910737094 = 11202003759302 := by decide
theorem cert_e2405910737094 : check e2405910737094 [[]] .width = true := by decide
def e2405910763546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910763546 : Closed e2405910763546 ∧ code e2405910763546 = 11202003785754 := by decide
theorem cert_e2405910763546 : check e2405910763546 [[]] .width = true := by decide
def e2405910767642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910767642 : Closed e2405910767642 ∧ code e2405910767642 = 11202003789850 := by decide
theorem cert_e2405910767642 : check e2405910767642 [[]] .width = true := by decide
def e2405910769178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910769178 : Closed e2405910769178 ∧ code e2405910769178 = 11202003791386 := by decide
theorem cert_e2405910769178 : check e2405910769178 [[]] .width = true := by decide
def e2405910771226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910771226 : Closed e2405910771226 ∧ code e2405910771226 = 11202003793434 := by decide
theorem cert_e2405910771226 : check e2405910771226 [[]] .width = true := by decide
def e2405910806554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405910806554 : Closed e2405910806554 ∧ code e2405910806554 = 11202003828762 := by decide
theorem cert_e2405910806554 : check e2405910806554 [[]] .width = true := by decide
def e2405910806646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405910806646 : Closed e2405910806646 ∧ code e2405910806646 = 11202003828854 := by decide
theorem cert_e2405910806646 : check e2405910806646 [[]] .width = true := by decide
def e2405910806890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405910806890 : Closed e2405910806890 ∧ code e2405910806890 = 11202003829098 := by decide
theorem cert_e2405910806890 : check e2405910806890 [[]] .width = true := by decide
def e2405910806938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405910806938 : Closed e2405910806938 ∧ code e2405910806938 = 11202003829146 := by decide
theorem cert_e2405910806938 : check e2405910806938 [[]] .width = true := by decide
def e2405910807946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405910807946 : Closed e2405910807946 ∧ code e2405910807946 = 11202003830154 := by decide
theorem cert_e2405910807946 : check e2405910807946 [[]] .width = true := by decide
def e2405910807970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405910807970 : Closed e2405910807970 ∧ code e2405910807970 = 11202003830178 := by decide
theorem cert_e2405910807970 : check e2405910807970 [[]] .width = true := by decide
def e2405910808078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405910808078 : Closed e2405910808078 ∧ code e2405910808078 = 11202003830286 := by decide
theorem cert_e2405910808078 : check e2405910808078 [[]] .width = true := by decide
def e2405910808090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910808090 : Closed e2405910808090 ∧ code e2405910808090 = 11202003830298 := by decide
theorem cert_e2405910808090 : check e2405910808090 [[]] .width = true := by decide
def e2405910808162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405910808162 : Closed e2405910808162 ∧ code e2405910808162 = 11202003830370 := by decide
theorem cert_e2405910808162 : check e2405910808162 [[]] .width = true := by decide
def e2405910841370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910841370 : Closed e2405910841370 ∧ code e2405910841370 = 11202003863578 := by decide
theorem cert_e2405910841370 : check e2405910841370 [[]] .width = true := by decide
def e2405910847514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910847514 : Closed e2405910847514 ∧ code e2405910847514 = 11202003869722 := by decide
theorem cert_e2405910847514 : check e2405910847514 [[]] .width = true := by decide
def e2405910847606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405910847606 : Closed e2405910847606 ∧ code e2405910847606 = 11202003869814 := by decide
theorem cert_e2405910847606 : check e2405910847606 [[]] .width = true := by decide
def e2405910847850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405910847850 : Closed e2405910847850 ∧ code e2405910847850 = 11202003870058 := by decide
theorem cert_e2405910847850 : check e2405910847850 [[]] .width = true := by decide
def e2405910847898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405910847898 : Closed e2405910847898 ∧ code e2405910847898 = 11202003870106 := by decide
theorem cert_e2405910847898 : check e2405910847898 [[]] .width = true := by decide
def e2405910851782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405910851782 : Closed e2405910851782 ∧ code e2405910851782 = 11202003873990 := by decide
theorem cert_e2405910851782 : check e2405910851782 [[]] .width = true := by decide
def e2405910853658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910853658 : Closed e2405910853658 ∧ code e2405910853658 = 11202003875866 := by decide
theorem cert_e2405910853658 : check e2405910853658 [[]] .width = true := by decide
def e2405910865946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405910865946 : Closed e2405910865946 ∧ code e2405910865946 = 11202003888154 := by decide
theorem cert_e2405910865946 : check e2405910865946 [[]] .width = true := by decide
def e2405910867482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910867482 : Closed e2405910867482 ∧ code e2405910867482 = 11202003889690 := by decide
theorem cert_e2405910867482 : check e2405910867482 [[]] .width = true := by decide
def e2405910870554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910870554 : Closed e2405910870554 ∧ code e2405910870554 = 11202003892762 := by decide
theorem cert_e2405910870554 : check e2405910870554 [[]] .width = true := by decide
def e2405910872090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405910872090 : Closed e2405910872090 ∧ code e2405910872090 = 11202003894298 := by decide
theorem cert_e2405910872090 : check e2405910872090 [[]] .width = true := by decide
def e2405910872182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405910872182 : Closed e2405910872182 ∧ code e2405910872182 = 11202003894390 := by decide
theorem cert_e2405910872182 : check e2405910872182 [[]] .width = true := by decide
def e2405910872426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405910872426 : Closed e2405910872426 ∧ code e2405910872426 = 11202003894634 := by decide
theorem cert_e2405910872426 : check e2405910872426 [[]] .width = true := by decide
def e2405910872474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405910872474 : Closed e2405910872474 ∧ code e2405910872474 = 11202003894682 := by decide
theorem cert_e2405910872474 : check e2405910872474 [[]] .width = true := by decide
def e2405910873482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405910873482 : Closed e2405910873482 ∧ code e2405910873482 = 11202003895690 := by decide
theorem cert_e2405910873482 : check e2405910873482 [[]] .width = true := by decide
def e2405910873506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405910873506 : Closed e2405910873506 ∧ code e2405910873506 = 11202003895714 := by decide
theorem cert_e2405910873506 : check e2405910873506 [[]] .width = true := by decide
def e2405910873614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405910873614 : Closed e2405910873614 ∧ code e2405910873614 = 11202003895822 := by decide
theorem cert_e2405910873614 : check e2405910873614 [[]] .width = true := by decide
def e2405910873626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910873626 : Closed e2405910873626 ∧ code e2405910873626 = 11202003895834 := by decide
theorem cert_e2405910873626 : check e2405910873626 [[]] .width = true := by decide
def e2405910873698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405910873698 : Closed e2405910873698 ∧ code e2405910873698 = 11202003895906 := by decide
theorem cert_e2405910873698 : check e2405910873698 [[]] .width = true := by decide
def e2405910888646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405910888646 : Closed e2405910888646 ∧ code e2405910888646 = 11202003910854 := by decide
theorem cert_e2405910888646 : check e2405910888646 [[]] .width = true := by decide
def e2405910896666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910896666 : Closed e2405910896666 ∧ code e2405910896666 = 11202003918874 := by decide
theorem cert_e2405910896666 : check e2405910896666 [[]] .width = true := by decide
def e2405910896758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405910896758 : Closed e2405910896758 ∧ code e2405910896758 = 11202003918966 := by decide
theorem cert_e2405910896758 : check e2405910896758 [[]] .width = true := by decide
def e2405910897002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405910897002 : Closed e2405910897002 ∧ code e2405910897002 = 11202003919210 := by decide
theorem cert_e2405910897002 : check e2405910897002 [[]] .width = true := by decide
def e2405910897050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405910897050 : Closed e2405910897050 ∧ code e2405910897050 = 11202003919258 := by decide
theorem cert_e2405910897050 : check e2405910897050 [[]] .width = true := by decide
def e2405910918682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910918682 : Closed e2405910918682 ∧ code e2405910918682 = 11202003940890 := by decide
theorem cert_e2405910918682 : check e2405910918682 [[]] .width = true := by decide
def e2405910919706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405910919706 : Closed e2405910919706 ∧ code e2405910919706 = 11202003941914 := by decide
theorem cert_e2405910919706 : check e2405910919706 [[]] .width = true := by decide
def e2405910929434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405910929434 : Closed e2405910929434 ∧ code e2405910929434 = 11202003951642 := by decide
theorem cert_e2405910929434 : check e2405910929434 [[]] .width = true := by decide
def e2405910929526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405910929526 : Closed e2405910929526 ∧ code e2405910929526 = 11202003951734 := by decide
theorem cert_e2405910929526 : check e2405910929526 [[]] .width = true := by decide
def e2405910929770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405910929770 : Closed e2405910929770 ∧ code e2405910929770 = 11202003951978 := by decide
theorem cert_e2405910929770 : check e2405910929770 [[]] .width = true := by decide
def e2405910929818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405910929818 : Closed e2405910929818 ∧ code e2405910929818 = 11202003952026 := by decide
theorem cert_e2405910929818 : check e2405910929818 [[]] .width = true := by decide
def e2405911672858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405911672858 : Closed e2405911672858 ∧ code e2405911672858 = 11202004695066 := by decide
theorem cert_e2405911672858 : check e2405911672858 [[]] .width = true := by decide
def e2405911685146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405911685146 : Closed e2405911685146 ∧ code e2405911685146 = 11202004707354 := by decide
theorem cert_e2405911685146 : check e2405911685146 [[]] .width = true := by decide
def e2405912207386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405912207386 : Closed e2405912207386 ∧ code e2405912207386 = 11202005229594 := by decide
theorem cert_e2405912207386 : check e2405912207386 [[]] .width = true := by decide
def e2405912207478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405912207478 : Closed e2405912207478 ∧ code e2405912207478 = 11202005229686 := by decide
theorem cert_e2405912207478 : check e2405912207478 [[]] .width = true := by decide
def e2405912207722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405912207722 : Closed e2405912207722 ∧ code e2405912207722 = 11202005229930 := by decide
theorem cert_e2405912207722 : check e2405912207722 [[]] .width = true := by decide
def e2405912207770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405912207770 : Closed e2405912207770 ∧ code e2405912207770 = 11202005229978 := by decide
theorem cert_e2405912207770 : check e2405912207770 [[]] .width = true := by decide
def e2405912256538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405912256538 : Closed e2405912256538 ∧ code e2405912256538 = 11202005278746 := by decide
theorem cert_e2405912256538 : check e2405912256538 [[]] .width = true := by decide
def e2405912256630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405912256630 : Closed e2405912256630 ∧ code e2405912256630 = 11202005278838 := by decide
theorem cert_e2405912256630 : check e2405912256630 [[]] .width = true := by decide
def e2405912256874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405912256874 : Closed e2405912256874 ∧ code e2405912256874 = 11202005279082 := by decide
theorem cert_e2405912256874 : check e2405912256874 [[]] .width = true := by decide
def e2405912256922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405912256922 : Closed e2405912256922 ∧ code e2405912256922 = 11202005279130 := by decide
theorem cert_e2405912256922 : check e2405912256922 [[]] .width = true := by decide
def e2405912375494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405912375494 : Closed e2405912375494 ∧ code e2405912375494 = 11202005397702 := by decide
theorem cert_e2405912375494 : check e2405912375494 [[]] .width = true := by decide
def e2405912393754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405912393754 : Closed e2405912393754 ∧ code e2405912393754 = 11202005415962 := by decide
theorem cert_e2405912393754 : check e2405912393754 [[]] .width = true := by decide
def e2405912400070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405912400070 : Closed e2405912400070 ∧ code e2405912400070 = 11202005422278 := by decide
theorem cert_e2405912400070 : check e2405912400070 [[]] .width = true := by decide
def e2405912401946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405912401946 : Closed e2405912401946 ∧ code e2405912401946 = 11202005424154 := by decide
theorem cert_e2405912401946 : check e2405912401946 [[]] .width = true := by decide
def e2405912459290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405912459290 : Closed e2405912459290 ∧ code e2405912459290 = 11202005481498 := by decide
theorem cert_e2405912459290 : check e2405912459290 [[]] .width = true := by decide
def e2405912471578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405912471578 : Closed e2405912471578 ∧ code e2405912471578 = 11202005493786 := by decide
theorem cert_e2405912471578 : check e2405912471578 [[]] .width = true := by decide
def e2405912498374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405912498374 : Closed e2405912498374 ∧ code e2405912498374 = 11202005520582 := by decide
theorem cert_e2405912498374 : check e2405912498374 [[]] .width = true := by decide
def e2405913245722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405913245722 : Closed e2405913245722 ∧ code e2405913245722 = 11202006267930 := by decide
theorem cert_e2405913245722 : check e2405913245722 [[]] .width = true := by decide
def e2405913258010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405913258010 : Closed e2405913258010 ∧ code e2405913258010 = 11202006280218 := by decide
theorem cert_e2405913258010 : check e2405913258010 [[]] .width = true := by decide
def e2405913259546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405913259546 : Closed e2405913259546 ∧ code e2405913259546 = 11202006281754 := by decide
theorem cert_e2405913259546 : check e2405913259546 [[]] .width = true := by decide
def e2405913307162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405913307162 : Closed e2405913307162 ∧ code e2405913307162 = 11202006329370 := by decide
theorem cert_e2405913307162 : check e2405913307162 [[]] .width = true := by decide
def e2405913308698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405913308698 : Closed e2405913308698 ∧ code e2405913308698 = 11202006330906 := by decide
theorem cert_e2405913308698 : check e2405913308698 [[]] .width = true := by decide
def e2405913311770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405913311770 : Closed e2405913311770 ∧ code e2405913311770 = 11202006333978 := by decide
theorem cert_e2405913311770 : check e2405913311770 [[]] .width = true := by decide
def e2405913503770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405913503770 : Closed e2405913503770 ∧ code e2405913503770 = 11202006525978 := by decide
theorem cert_e2405913503770 : check e2405913503770 [[]] .width = true := by decide
def e2405913505306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405913505306 : Closed e2405913505306 ∧ code e2405913505306 = 11202006527514 := by decide
theorem cert_e2405913505306 : check e2405913505306 [[]] .width = true := by decide
def e2405913508378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405913508378 : Closed e2405913508378 ∧ code e2405913508378 = 11202006530586 := by decide
theorem cert_e2405913508378 : check e2405913508378 [[]] .width = true := by decide
def e2405913520666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405913520666 : Closed e2405913520666 ∧ code e2405913520666 = 11202006542874 := by decide
private def t_e2405913520666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405913520666 : ¬ IsSelfInterpreter e2405913520666 :=
  wSource (t := t_e2405913520666) (replay_sound (ps := []) (t := e2405913520666) (by decide)) (by decide)
def e2405913638938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405913638938 : Closed e2405913638938 ∧ code e2405913638938 = 11202006661146 := by decide
theorem cert_e2405913638938 : check e2405913638938 [[]] .width = true := by decide
def e2405913780250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405913780250 : Closed e2405913780250 ∧ code e2405913780250 = 11202006802458 := by decide
theorem cert_e2405913780250 : check e2405913780250 [[]] .width = true := by decide
def e2405913780342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405913780342 : Closed e2405913780342 ∧ code e2405913780342 = 11202006802550 := by decide
theorem cert_e2405913780342 : check e2405913780342 [[]] .width = true := by decide
def e2405913780586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405913780586 : Closed e2405913780586 ∧ code e2405913780586 = 11202006802794 := by decide
theorem cert_e2405913780586 : check e2405913780586 [[]] .width = true := by decide
def e2405913780634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405913780634 : Closed e2405913780634 ∧ code e2405913780634 = 11202006802842 := by decide
theorem cert_e2405913780634 : check e2405913780634 [[]] .width = true := by decide
def e2405913817286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405913817286 : Closed e2405913817286 ∧ code e2405913817286 = 11202006839494 := by decide
theorem cert_e2405913817286 : check e2405913817286 [[]] .width = true := by decide
def e2405913835546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405913835546 : Closed e2405913835546 ∧ code e2405913835546 = 11202006857754 := by decide
theorem cert_e2405913835546 : check e2405913835546 [[]] .width = true := by decide
def e2405913841862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405913841862 : Closed e2405913841862 ∧ code e2405913841862 = 11202006864070 := by decide
theorem cert_e2405913841862 : check e2405913841862 [[]] .width = true := by decide
def e2405914032154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405914032154 : Closed e2405914032154 ∧ code e2405914032154 = 11202007054362 := by decide
theorem cert_e2405914032154 : check e2405914032154 [[]] .width = true := by decide
def e2405914044442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405914044442 : Closed e2405914044442 ∧ code e2405914044442 = 11202007066650 := by decide
theorem cert_e2405914044442 : check e2405914044442 [[]] .width = true := by decide
def e2405914045978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405914045978 : Closed e2405914045978 ∧ code e2405914045978 = 11202007068186 := by decide
theorem cert_e2405914045978 : check e2405914045978 [[]] .width = true := by decide
def e2405914093594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405914093594 : Closed e2405914093594 ∧ code e2405914093594 = 11202007115802 := by decide
theorem cert_e2405914093594 : check e2405914093594 [[]] .width = true := by decide
def e2405914095130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405914095130 : Closed e2405914095130 ∧ code e2405914095130 = 11202007117338 := by decide
theorem cert_e2405914095130 : check e2405914095130 [[]] .width = true := by decide
def e2405914098202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405914098202 : Closed e2405914098202 ∧ code e2405914098202 = 11202007120410 := by decide
theorem cert_e2405914098202 : check e2405914098202 [[]] .width = true := by decide
def e2405914177734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405914177734 : Closed e2405914177734 ∧ code e2405914177734 = 11202007199942 := by decide
theorem cert_e2405914177734 : check e2405914177734 [[]] .width = true := by decide
def e2405914228762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405914228762 : Closed e2405914228762 ∧ code e2405914228762 = 11202007250970 := by decide
theorem cert_e2405914228762 : check e2405914228762 [[]] .width = true := by decide
def e2405914241050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405914241050 : Closed e2405914241050 ∧ code e2405914241050 = 11202007263258 := by decide
theorem cert_e2405914241050 : check e2405914241050 [[]] .width = true := by decide
def e2405914242586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405914242586 : Closed e2405914242586 ∧ code e2405914242586 = 11202007264794 := by decide
theorem cert_e2405914242586 : check e2405914242586 [[]] .width = true := by decide
def e2405914345498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405914345498 : Closed e2405914345498 ∧ code e2405914345498 = 11202007367706 := by decide
theorem cert_e2405914345498 : check e2405914345498 [[]] .width = true := by decide
def e2405914345590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405914345590 : Closed e2405914345590 ∧ code e2405914345590 = 11202007367798 := by decide
theorem cert_e2405914345590 : check e2405914345590 [[]] .width = true := by decide
def e2405914345834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405914345834 : Closed e2405914345834 ∧ code e2405914345834 = 11202007368042 := by decide
theorem cert_e2405914345834 : check e2405914345834 [[]] .width = true := by decide
def e2405914345882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405914345882 : Closed e2405914345882 ∧ code e2405914345882 = 11202007368090 := by decide
theorem cert_e2405914345882 : check e2405914345882 [[]] .width = true := by decide
def e2405914346890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405914346890 : Closed e2405914346890 ∧ code e2405914346890 = 11202007369098 := by decide
theorem cert_e2405914346890 : check e2405914346890 [[]] .width = true := by decide
def e2405914346914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405914346914 : Closed e2405914346914 ∧ code e2405914346914 = 11202007369122 := by decide
theorem cert_e2405914346914 : check e2405914346914 [[]] .width = true := by decide
def e2405914347022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405914347022 : Closed e2405914347022 ∧ code e2405914347022 = 11202007369230 := by decide
theorem cert_e2405914347022 : check e2405914347022 [[]] .width = true := by decide
def e2405914347034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405914347034 : Closed e2405914347034 ∧ code e2405914347034 = 11202007369242 := by decide
theorem cert_e2405914347034 : check e2405914347034 [[]] .width = true := by decide
def e2405914347106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405914347106 : Closed e2405914347106 ∧ code e2405914347106 = 11202007369314 := by decide
theorem cert_e2405914347106 : check e2405914347106 [[]] .width = true := by decide
def e2405914493126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405914493126 : Closed e2405914493126 ∧ code e2405914493126 = 11202007515334 := by decide
theorem cert_e2405914493126 : check e2405914493126 [[]] .width = true := by decide
def e2405914511386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405914511386 : Closed e2405914511386 ∧ code e2405914511386 = 11202007533594 := by decide
theorem cert_e2405914511386 : check e2405914511386 [[]] .width = true := by decide
def e2405914517530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405914517530 : Closed e2405914517530 ∧ code e2405914517530 = 11202007539738 := by decide
theorem cert_e2405914517530 : check e2405914517530 [[]] .width = true := by decide
def e2405914517622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405914517622 : Closed e2405914517622 ∧ code e2405914517622 = 11202007539830 := by decide
theorem cert_e2405914517622 : check e2405914517622 [[]] .width = true := by decide
def e2405914517866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405914517866 : Closed e2405914517866 ∧ code e2405914517866 = 11202007540074 := by decide
theorem cert_e2405914517866 : check e2405914517866 [[]] .width = true := by decide
def e2405914517914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405914517914 : Closed e2405914517914 ∧ code e2405914517914 = 11202007540122 := by decide
theorem cert_e2405914517914 : check e2405914517914 [[]] .width = true := by decide
def e2405914521798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405914521798 : Closed e2405914521798 ∧ code e2405914521798 = 11202007544006 := by decide
theorem cert_e2405914521798 : check e2405914521798 [[]] .width = true := by decide
def e2405914523674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405914523674 : Closed e2405914523674 ∧ code e2405914523674 = 11202007545882 := by decide
theorem cert_e2405914523674 : check e2405914523674 [[]] .width = true := by decide
def e2405914535962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405914535962 : Closed e2405914535962 ∧ code e2405914535962 = 11202007558170 := by decide
theorem cert_e2405914535962 : check e2405914535962 [[]] .width = true := by decide
def e2405914537498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405914537498 : Closed e2405914537498 ∧ code e2405914537498 = 11202007559706 := by decide
theorem cert_e2405914537498 : check e2405914537498 [[]] .width = true := by decide
def e2405914540570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405914540570 : Closed e2405914540570 ∧ code e2405914540570 = 11202007562778 := by decide
theorem cert_e2405914540570 : check e2405914540570 [[]] .width = true := by decide
def e2405914542106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405914542106 : Closed e2405914542106 ∧ code e2405914542106 = 11202007564314 := by decide
theorem cert_e2405914542106 : check e2405914542106 [[]] .width = true := by decide
def e2405914542198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405914542198 : Closed e2405914542198 ∧ code e2405914542198 = 11202007564406 := by decide
theorem cert_e2405914542198 : check e2405914542198 [[]] .width = true := by decide
def e2405914542442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405914542442 : Closed e2405914542442 ∧ code e2405914542442 = 11202007564650 := by decide
theorem cert_e2405914542442 : check e2405914542442 [[]] .width = true := by decide
def e2405914542490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405914542490 : Closed e2405914542490 ∧ code e2405914542490 = 11202007564698 := by decide
theorem cert_e2405914542490 : check e2405914542490 [[]] .width = true := by decide
def e2405914543498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405914543498 : Closed e2405914543498 ∧ code e2405914543498 = 11202007565706 := by decide
theorem cert_e2405914543498 : check e2405914543498 [[]] .width = true := by decide
def e2405914543522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405914543522 : Closed e2405914543522 ∧ code e2405914543522 = 11202007565730 := by decide
theorem cert_e2405914543522 : check e2405914543522 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405913520666
