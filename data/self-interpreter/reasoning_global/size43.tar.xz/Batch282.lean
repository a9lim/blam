import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2408805688758 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2408805688758 : Closed e2408805688758 ∧ code e2408805688758 = 11204898710966 := by decide
theorem cert_e2408805688758 : check e2408805688758 [[],[]] .smaller = true := by decide
def e2408805688790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2408805688790 : Closed e2408805688790 ∧ code e2408805688790 = 11204898710998 := by decide
theorem cert_e2408805688790 : check e2408805688790 [[],[]] .smaller = true := by decide
def e2408805688794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2408805688794 : Closed e2408805688794 ∧ code e2408805688794 = 11204898711002 := by decide
theorem cert_e2408805688794 : check e2408805688794 [[],[]] .smaller = true := by decide
def e2408805688950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2408805688950 : Closed e2408805688950 ∧ code e2408805688950 = 11204898711158 := by decide
theorem cert_e2408805688950 : check e2408805688950 [[],[]] .smaller = true := by decide
def e2408805689142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2408805689142 : Closed e2408805689142 ∧ code e2408805689142 = 11204898711350 := by decide
theorem cert_e2408805689142 : check e2408805689142 [[],[]] .smaller = true := by decide
def e2408805689146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2408805689146 : Closed e2408805689146 ∧ code e2408805689146 = 11204898711354 := by decide
theorem cert_e2408805689146 : check e2408805689146 [[],[]] .smaller = true := by decide
def e2408805692118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2408805692118 : Closed e2408805692118 ∧ code e2408805692118 = 11204898714326 := by decide
theorem cert_e2408805692118 : check e2408805692118 [[],[]] .three = true := by decide
def e2408805692122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2408805692122 : Closed e2408805692122 ∧ code e2408805692122 = 11204898714330 := by decide
theorem cert_e2408805692122 : check e2408805692122 [[],[]] .three = true := by decide
def e2408805692138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2408805692138 : Closed e2408805692138 ∧ code e2408805692138 = 11204898714346 := by decide
theorem cert_e2408805692138 : check e2408805692138 [[],[]] .three = true := by decide
def e2408805692214 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2408805692214 : Closed e2408805692214 ∧ code e2408805692214 = 11204898714422 := by decide
theorem cert_e2408805692214 : check e2408805692214 [[],[]] .three = true := by decide
def e2408805692218 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2408805692218 : Closed e2408805692218 ∧ code e2408805692218 = 11204898714426 := by decide
theorem cert_e2408805692218 : check e2408805692218 [[],[]] .three = true := by decide
def e2408805692314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2408805692314 : Closed e2408805692314 ∧ code e2408805692314 = 11204898714522 := by decide
theorem cert_e2408805692314 : check e2408805692314 [[],[]] .three = true := by decide
def e2408805917550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2408805917550 : Closed e2408805917550 ∧ code e2408805917550 = 11204898939758 := by decide
theorem cert_e2408805917550 : check e2408805917550 [[],[]] .chain = true := by decide
def e2408805917558 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2408805917558 : Closed e2408805917558 ∧ code e2408805917558 = 11204898939766 := by decide
theorem cert_e2408805917558 : check e2408805917558 [[],[]] .chain = true := by decide
def e2408805917614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2408805917614 : Closed e2408805917614 ∧ code e2408805917614 = 11204898939822 := by decide
theorem cert_e2408805917614 : check e2408805917614 [[],[]] .chain = true := by decide
def e2408805917626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2408805917626 : Closed e2408805917626 ∧ code e2408805917626 = 11204898939834 := by decide
theorem cert_e2408805917626 : check e2408805917626 [[],[]] .chain = true := by decide
def e2408805917654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2408805917654 : Closed e2408805917654 ∧ code e2408805917654 = 11204898939862 := by decide
theorem cert_e2408805917654 : check e2408805917654 [[],[]] .chain = true := by decide
def e2408805917658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2408805917658 : Closed e2408805917658 ∧ code e2408805917658 = 11204898939866 := by decide
theorem cert_e2408805917658 : check e2408805917658 [[],[]] .chain = true := by decide
def e2408805918958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2408805918958 : Closed e2408805918958 ∧ code e2408805918958 = 11204898941166 := by decide
theorem cert_e2408805918958 : check e2408805918958 [[],[]] .chain = true := by decide
def e2408805918966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2408805918966 : Closed e2408805918966 ∧ code e2408805918966 = 11204898941174 := by decide
theorem cert_e2408805918966 : check e2408805918966 [[],[]] .chain = true := by decide
def e2408805919518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2408805919518 : Closed e2408805919518 ∧ code e2408805919518 = 11204898941726 := by decide
theorem cert_e2408805919518 : check e2408805919518 [[],[]] .chain = true := by decide
def e2408805919630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2408805919630 : Closed e2408805919630 ∧ code e2408805919630 = 11204898941838 := by decide
theorem cert_e2408805919630 : check e2408805919630 [[],[]] .chain = true := by decide
def e2408805919854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2408805919854 : Closed e2408805919854 ∧ code e2408805919854 = 11204898942062 := by decide
theorem cert_e2408805919854 : check e2408805919854 [[],[]] .chain = true := by decide
def e2408805919866 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2408805919866 : Closed e2408805919866 ∧ code e2408805919866 = 11204898942074 := by decide
theorem cert_e2408805919866 : check e2408805919866 [[],[]] .chain = true := by decide
def e2408805920030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2408805920030 : Closed e2408805920030 ∧ code e2408805920030 = 11204898942238 := by decide
theorem cert_e2408805920030 : check e2408805920030 [[],[]] .chain = true := by decide
def e2408805920198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2408805920198 : Closed e2408805920198 ∧ code e2408805920198 = 11204898942406 := by decide
theorem cert_e2408805920198 : check e2408805920198 [[],[]] .chain = true := by decide
def e2408805920310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2408805920310 : Closed e2408805920310 ∧ code e2408805920310 = 11204898942518 := by decide
theorem cert_e2408805920310 : check e2408805920310 [[],[]] .chain = true := by decide
def e2408805920314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2408805920314 : Closed e2408805920314 ∧ code e2408805920314 = 11204898942522 := by decide
theorem cert_e2408805920314 : check e2408805920314 [[],[]] .chain = true := by decide
def e2408805920398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2408805920398 : Closed e2408805920398 ∧ code e2408805920398 = 11204898942606 := by decide
theorem cert_e2408805920398 : check e2408805920398 [[],[]] .chain = true := by decide
def e2408805920454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2408805920454 : Closed e2408805920454 ∧ code e2408805920454 = 11204898942662 := by decide
theorem cert_e2408805920454 : check e2408805920454 [[],[]] .chain = true := by decide
def e2408805921198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2408805921198 : Closed e2408805921198 ∧ code e2408805921198 = 11204898943406 := by decide
theorem cert_e2408805921198 : check e2408805921198 [[],[]] .chain = true := by decide
def e2408805921210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2408805921210 : Closed e2408805921210 ∧ code e2408805921210 = 11204898943418 := by decide
theorem cert_e2408805921210 : check e2408805921210 [[],[]] .chain = true := by decide
def e2408805921258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2408805921258 : Closed e2408805921258 ∧ code e2408805921258 = 11204898943466 := by decide
theorem cert_e2408805921258 : check e2408805921258 [[],[]] .chain = true := by decide
def e2408805921902 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2408805921902 : Closed e2408805921902 ∧ code e2408805921902 = 11204898944110 := by decide
theorem cert_e2408805921902 : check e2408805921902 [[],[]] .chain = true := by decide
def e2408805921914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2408805921914 : Closed e2408805921914 ∧ code e2408805921914 = 11204898944122 := by decide
theorem cert_e2408805921914 : check e2408805921914 [[],[]] .chain = true := by decide
def e2408805922078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2408805922078 : Closed e2408805922078 ∧ code e2408805922078 = 11204898944286 := by decide
theorem cert_e2408805922078 : check e2408805922078 [[],[]] .chain = true := by decide
def e2408805922246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2408805922246 : Closed e2408805922246 ∧ code e2408805922246 = 11204898944454 := by decide
theorem cert_e2408805922246 : check e2408805922246 [[],[]] .chain = true := by decide
def e2408805922586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2408805922586 : Closed e2408805922586 ∧ code e2408805922586 = 11204898944794 := by decide
theorem cert_e2408805922586 : check e2408805922586 [[],[]] .chain = true := by decide
def e2408805922630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2408805922630 : Closed e2408805922630 ∧ code e2408805922630 = 11204898944838 := by decide
theorem cert_e2408805922630 : check e2408805922630 [[],[]] .chain = true := by decide
def e2408805923030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2408805923030 : Closed e2408805923030 ∧ code e2408805923030 = 11204898945238 := by decide
theorem cert_e2408805923030 : check e2408805923030 [[],[]] .chain = true := by decide
def e2408805923034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2408805923034 : Closed e2408805923034 ∧ code e2408805923034 = 11204898945242 := by decide
theorem cert_e2408805923034 : check e2408805923034 [[],[]] .chain = true := by decide
def e2408805923050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2408805923050 : Closed e2408805923050 ∧ code e2408805923050 = 11204898945258 := by decide
theorem cert_e2408805923050 : check e2408805923050 [[],[]] .chain = true := by decide
def e2408805923382 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2408805923382 : Closed e2408805923382 ∧ code e2408805923382 = 11204898945590 := by decide
theorem cert_e2408805923382 : check e2408805923382 [[],[]] .chain = true := by decide
def e2408805923386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2408805923386 : Closed e2408805923386 ∧ code e2408805923386 = 11204898945594 := by decide
theorem cert_e2408805923386 : check e2408805923386 [[],[]] .chain = true := by decide
def e2408805923470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2408805923470 : Closed e2408805923470 ∧ code e2408805923470 = 11204898945678 := by decide
theorem cert_e2408805923470 : check e2408805923470 [[],[]] .chain = true := by decide
def e2408805923526 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2408805923526 : Closed e2408805923526 ∧ code e2408805923526 = 11204898945734 := by decide
theorem cert_e2408805923526 : check e2408805923526 [[],[]] .chain = true := by decide
def e2408805923610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2408805923610 : Closed e2408805923610 ∧ code e2408805923610 = 11204898945818 := by decide
theorem cert_e2408805923610 : check e2408805923610 [[],[]] .chain = true := by decide
def e2408805923654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2408805923654 : Closed e2408805923654 ∧ code e2408805923654 = 11204898945862 := by decide
theorem cert_e2408805923654 : check e2408805923654 [[],[]] .chain = true := by decide
def e2408805928174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2408805928174 : Closed e2408805928174 ∧ code e2408805928174 = 11204898950382 := by decide
theorem cert_e2408805928174 : check e2408805928174 [[],[]] .chain = true := by decide
def e2408805928182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2408805928182 : Closed e2408805928182 ∧ code e2408805928182 = 11204898950390 := by decide
theorem cert_e2408805928182 : check e2408805928182 [[],[]] .chain = true := by decide
def e2408805928558 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2408805928558 : Closed e2408805928558 ∧ code e2408805928558 = 11204898950766 := by decide
theorem cert_e2408805928558 : check e2408805928558 [[],[]] .chain = true := by decide
def e2408805928570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2408805928570 : Closed e2408805928570 ∧ code e2408805928570 = 11204898950778 := by decide
theorem cert_e2408805928570 : check e2408805928570 [[],[]] .chain = true := by decide
def e2408805928758 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2408805928758 : Closed e2408805928758 ∧ code e2408805928758 = 11204898950966 := by decide
theorem cert_e2408805928758 : check e2408805928758 [[],[]] .chain = true := by decide
def e2408805928762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2408805928762 : Closed e2408805928762 ∧ code e2408805928762 = 11204898950970 := by decide
theorem cert_e2408805928762 : check e2408805928762 [[],[]] .chain = true := by decide
def e2408805931246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2408805931246 : Closed e2408805931246 ∧ code e2408805931246 = 11204898953454 := by decide
theorem cert_e2408805931246 : check e2408805931246 [[],[]] .chain = true := by decide
def e2408805931254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2408805931254 : Closed e2408805931254 ∧ code e2408805931254 = 11204898953462 := by decide
theorem cert_e2408805931254 : check e2408805931254 [[],[]] .chain = true := by decide
def e2408805931806 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2408805931806 : Closed e2408805931806 ∧ code e2408805931806 = 11204898954014 := by decide
theorem cert_e2408805931806 : check e2408805931806 [[],[]] .chain = true := by decide
def e2408805931918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2408805931918 : Closed e2408805931918 ∧ code e2408805931918 = 11204898954126 := by decide
theorem cert_e2408805931918 : check e2408805931918 [[],[]] .chain = true := by decide
def e2408805932142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2408805932142 : Closed e2408805932142 ∧ code e2408805932142 = 11204898954350 := by decide
theorem cert_e2408805932142 : check e2408805932142 [[],[]] .chain = true := by decide
def e2408805932154 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2408805932154 : Closed e2408805932154 ∧ code e2408805932154 = 11204898954362 := by decide
theorem cert_e2408805932154 : check e2408805932154 [[],[]] .chain = true := by decide
def e2408805932318 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2408805932318 : Closed e2408805932318 ∧ code e2408805932318 = 11204898954526 := by decide
theorem cert_e2408805932318 : check e2408805932318 [[],[]] .chain = true := by decide
def e2408805932486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2408805932486 : Closed e2408805932486 ∧ code e2408805932486 = 11204898954694 := by decide
theorem cert_e2408805932486 : check e2408805932486 [[],[]] .chain = true := by decide
def e2408805932598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2408805932598 : Closed e2408805932598 ∧ code e2408805932598 = 11204898954806 := by decide
theorem cert_e2408805932598 : check e2408805932598 [[],[]] .chain = true := by decide
def e2408805932602 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2408805932602 : Closed e2408805932602 ∧ code e2408805932602 = 11204898954810 := by decide
theorem cert_e2408805932602 : check e2408805932602 [[],[]] .chain = true := by decide
def e2408805932686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2408805932686 : Closed e2408805932686 ∧ code e2408805932686 = 11204898954894 := by decide
theorem cert_e2408805932686 : check e2408805932686 [[],[]] .chain = true := by decide
def e2408805932742 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2408805932742 : Closed e2408805932742 ∧ code e2408805932742 = 11204898954950 := by decide
theorem cert_e2408805932742 : check e2408805932742 [[],[]] .chain = true := by decide
def e2408805934878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2408805934878 : Closed e2408805934878 ∧ code e2408805934878 = 11204898957086 := by decide
theorem cert_e2408805934878 : check e2408805934878 [[],[]] .chain = true := by decide
def e2408805934990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2408805934990 : Closed e2408805934990 ∧ code e2408805934990 = 11204898957198 := by decide
theorem cert_e2408805934990 : check e2408805934990 [[],[]] .chain = true := by decide
def e2408805937950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2408805937950 : Closed e2408805937950 ∧ code e2408805937950 = 11204898960158 := by decide
theorem cert_e2408805937950 : check e2408805937950 [[],[]] .chain = true := by decide
def e2408805938118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2408805938118 : Closed e2408805938118 ∧ code e2408805938118 = 11204898960326 := by decide
theorem cert_e2408805938118 : check e2408805938118 [[],[]] .chain = true := by decide
def e2408805939598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2408805939598 : Closed e2408805939598 ∧ code e2408805939598 = 11204898961806 := by decide
theorem cert_e2408805939598 : check e2408805939598 [[],[]] .chain = true := by decide
def e2408805939654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2408805939654 : Closed e2408805939654 ∧ code e2408805939654 = 11204898961862 := by decide
theorem cert_e2408805939654 : check e2408805939654 [[],[]] .chain = true := by decide
def e2408805942894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2408805942894 : Closed e2408805942894 ∧ code e2408805942894 = 11204898965102 := by decide
theorem cert_e2408805942894 : check e2408805942894 [[],[]] .chain = true := by decide
def e2408805942906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2408805942906 : Closed e2408805942906 ∧ code e2408805942906 = 11204898965114 := by decide
theorem cert_e2408805942906 : check e2408805942906 [[],[]] .chain = true := by decide
def e2408805943194 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2408805943194 : Closed e2408805943194 ∧ code e2408805943194 = 11204898965402 := by decide
theorem cert_e2408805943194 : check e2408805943194 [[],[]] .chain = true := by decide
def e2408805944430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2408805944430 : Closed e2408805944430 ∧ code e2408805944430 = 11204898966638 := by decide
theorem cert_e2408805944430 : check e2408805944430 [[],[]] .chain = true := by decide
def e2408805944442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2408805944442 : Closed e2408805944442 ∧ code e2408805944442 = 11204898966650 := by decide
theorem cert_e2408805944442 : check e2408805944442 [[],[]] .chain = true := by decide
def e2408805944606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2408805944606 : Closed e2408805944606 ∧ code e2408805944606 = 11204898966814 := by decide
theorem cert_e2408805944606 : check e2408805944606 [[],[]] .chain = true := by decide
def e2408805944774 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2408805944774 : Closed e2408805944774 ∧ code e2408805944774 = 11204898966982 := by decide
theorem cert_e2408805944774 : check e2408805944774 [[],[]] .chain = true := by decide
def e2408805945114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2408805945114 : Closed e2408805945114 ∧ code e2408805945114 = 11204898967322 := by decide
theorem cert_e2408805945114 : check e2408805945114 [[],[]] .chain = true := by decide
def e2408805945158 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2408805945158 : Closed e2408805945158 ∧ code e2408805945158 = 11204898967366 := by decide
theorem cert_e2408805945158 : check e2408805945158 [[],[]] .chain = true := by decide
def e2408805946142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2408805946142 : Closed e2408805946142 ∧ code e2408805946142 = 11204898968350 := by decide
theorem cert_e2408805946142 : check e2408805946142 [[],[]] .chain = true := by decide
def e2408805946310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2408805946310 : Closed e2408805946310 ∧ code e2408805946310 = 11204898968518 := by decide
theorem cert_e2408805946310 : check e2408805946310 [[],[]] .chain = true := by decide
def e2408805948614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2408805948614 : Closed e2408805948614 ∧ code e2408805948614 = 11204898970822 := by decide
theorem cert_e2408805948614 : check e2408805948614 [[],[]] .chain = true := by decide
def e2408805950262 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2408805950262 : Closed e2408805950262 ∧ code e2408805950262 = 11204898972470 := by decide
theorem cert_e2408805950262 : check e2408805950262 [[],[]] .chain = true := by decide
def e2408805950266 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2408805950266 : Closed e2408805950266 ∧ code e2408805950266 = 11204898972474 := by decide
theorem cert_e2408805950266 : check e2408805950266 [[],[]] .chain = true := by decide
def e2408805950362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2408805950362 : Closed e2408805950362 ∧ code e2408805950362 = 11204898972570 := by decide
theorem cert_e2408805950362 : check e2408805950362 [[],[]] .chain = true := by decide
def e2408805951030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2408805951030 : Closed e2408805951030 ∧ code e2408805951030 = 11204898973238 := by decide
theorem cert_e2408805951030 : check e2408805951030 [[],[]] .chain = true := by decide
def e2408805951034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2408805951034 : Closed e2408805951034 ∧ code e2408805951034 = 11204898973242 := by decide
theorem cert_e2408805951034 : check e2408805951034 [[],[]] .chain = true := by decide
def e2408805951118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2408805951118 : Closed e2408805951118 ∧ code e2408805951118 = 11204898973326 := by decide
theorem cert_e2408805951118 : check e2408805951118 [[],[]] .chain = true := by decide
def e2408805951174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2408805951174 : Closed e2408805951174 ∧ code e2408805951174 = 11204898973382 := by decide
theorem cert_e2408805951174 : check e2408805951174 [[],[]] .chain = true := by decide
def e2408805951258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2408805951258 : Closed e2408805951258 ∧ code e2408805951258 = 11204898973466 := by decide
theorem cert_e2408805951258 : check e2408805951258 [[],[]] .chain = true := by decide
def e2408805951302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2408805951302 : Closed e2408805951302 ∧ code e2408805951302 = 11204898973510 := by decide
theorem cert_e2408805951302 : check e2408805951302 [[],[]] .chain = true := by decide
def e2408805951886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2408805951886 : Closed e2408805951886 ∧ code e2408805951886 = 11204898974094 := by decide
theorem cert_e2408805951886 : check e2408805951886 [[],[]] .chain = true := by decide
def e2408805951942 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2408805951942 : Closed e2408805951942 ∧ code e2408805951942 = 11204898974150 := by decide
theorem cert_e2408805951942 : check e2408805951942 [[],[]] .chain = true := by decide
def e2408805952710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2408805952710 : Closed e2408805952710 ∧ code e2408805952710 = 11204898974918 := by decide
theorem cert_e2408805952710 : check e2408805952710 [[],[]] .chain = true := by decide
def e2408805963486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2408805963486 : Closed e2408805963486 ∧ code e2408805963486 = 11204898985694 := by decide
theorem cert_e2408805963486 : check e2408805963486 [[],[]] .chain = true := by decide
def e2408805963510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2408805963510 : Closed e2408805963510 ∧ code e2408805963510 = 11204898985718 := by decide
theorem cert_e2408805963510 : check e2408805963510 [[],[]] .chain = true := by decide
def e2408805963614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2408805963614 : Closed e2408805963614 ∧ code e2408805963614 = 11204898985822 := by decide
theorem cert_e2408805963614 : check e2408805963614 [[],[]] .chain = true := by decide
def e2408805963642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2408805963642 : Closed e2408805963642 ∧ code e2408805963642 = 11204898985850 := by decide
theorem cert_e2408805963642 : check e2408805963642 [[],[]] .chain = true := by decide
def e2408805963734 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2408805963734 : Closed e2408805963734 ∧ code e2408805963734 = 11204898985942 := by decide
theorem cert_e2408805963734 : check e2408805963734 [[],[]] .chain = true := by decide
def e2408805963738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2408805963738 : Closed e2408805963738 ∧ code e2408805963738 = 11204898985946 := by decide
theorem cert_e2408805963738 : check e2408805963738 [[],[]] .chain = true := by decide
def e2408805964254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2408805964254 : Closed e2408805964254 ∧ code e2408805964254 = 11204898986462 := by decide
theorem cert_e2408805964254 : check e2408805964254 [[],[]] .chain = true := by decide
def e2408805964278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2408805964278 : Closed e2408805964278 ∧ code e2408805964278 = 11204898986486 := by decide
theorem cert_e2408805964278 : check e2408805964278 [[],[]] .chain = true := by decide
def e2408805965022 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2408805965022 : Closed e2408805965022 ∧ code e2408805965022 = 11204898987230 := by decide
theorem cert_e2408805965022 : check e2408805965022 [[],[]] .chain = true := by decide
def e2408805965050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2408805965050 : Closed e2408805965050 ∧ code e2408805965050 = 11204898987258 := by decide
theorem cert_e2408805965050 : check e2408805965050 [[],[]] .chain = true := by decide
def e2408805965622 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2408805965622 : Closed e2408805965622 ∧ code e2408805965622 = 11204898987830 := by decide
theorem cert_e2408805965622 : check e2408805965622 [[],[]] .chain = true := by decide
def e2408805965626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2408805965626 : Closed e2408805965626 ∧ code e2408805965626 = 11204898987834 := by decide
theorem cert_e2408805965626 : check e2408805965626 [[],[]] .chain = true := by decide
def e2408805980398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2408805980398 : Closed e2408805980398 ∧ code e2408805980398 = 11204899002606 := by decide
theorem cert_e2408805980398 : check e2408805980398 [[],[]] .chain = true := by decide
def e2408805980406 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2408805980406 : Closed e2408805980406 ∧ code e2408805980406 = 11204899002614 := by decide
theorem cert_e2408805980406 : check e2408805980406 [[],[]] .chain = true := by decide
def e2408805980958 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2408805980958 : Closed e2408805980958 ∧ code e2408805980958 = 11204899003166 := by decide
theorem cert_e2408805980958 : check e2408805980958 [[],[]] .chain = true := by decide
def e2408805981070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2408805981070 : Closed e2408805981070 ∧ code e2408805981070 = 11204899003278 := by decide
theorem cert_e2408805981070 : check e2408805981070 [[],[]] .chain = true := by decide
def e2408805981294 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2408805981294 : Closed e2408805981294 ∧ code e2408805981294 = 11204899003502 := by decide
theorem cert_e2408805981294 : check e2408805981294 [[],[]] .chain = true := by decide
def e2408805981306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2408805981306 : Closed e2408805981306 ∧ code e2408805981306 = 11204899003514 := by decide
theorem cert_e2408805981306 : check e2408805981306 [[],[]] .chain = true := by decide
def e2408805981470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2408805981470 : Closed e2408805981470 ∧ code e2408805981470 = 11204899003678 := by decide
theorem cert_e2408805981470 : check e2408805981470 [[],[]] .chain = true := by decide
def e2408805981638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2408805981638 : Closed e2408805981638 ∧ code e2408805981638 = 11204899003846 := by decide
theorem cert_e2408805981638 : check e2408805981638 [[],[]] .chain = true := by decide
def e2408805981750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2408805981750 : Closed e2408805981750 ∧ code e2408805981750 = 11204899003958 := by decide
theorem cert_e2408805981750 : check e2408805981750 [[],[]] .chain = true := by decide
def e2408805981754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2408805981754 : Closed e2408805981754 ∧ code e2408805981754 = 11204899003962 := by decide
theorem cert_e2408805981754 : check e2408805981754 [[],[]] .chain = true := by decide
def e2408805981838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2408805981838 : Closed e2408805981838 ∧ code e2408805981838 = 11204899004046 := by decide
theorem cert_e2408805981838 : check e2408805981838 [[],[]] .chain = true := by decide
def e2408805981894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2408805981894 : Closed e2408805981894 ∧ code e2408805981894 = 11204899004102 := by decide
theorem cert_e2408805981894 : check e2408805981894 [[],[]] .chain = true := by decide
def e2408805984030 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2408805984030 : Closed e2408805984030 ∧ code e2408805984030 = 11204899006238 := by decide
theorem cert_e2408805984030 : check e2408805984030 [[],[]] .chain = true := by decide
def e2408805984142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2408805984142 : Closed e2408805984142 ∧ code e2408805984142 = 11204899006350 := by decide
theorem cert_e2408805984142 : check e2408805984142 [[],[]] .chain = true := by decide
def e2408805987102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2408805987102 : Closed e2408805987102 ∧ code e2408805987102 = 11204899009310 := by decide
theorem cert_e2408805987102 : check e2408805987102 [[],[]] .chain = true := by decide
def e2408805987270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2408805987270 : Closed e2408805987270 ∧ code e2408805987270 = 11204899009478 := by decide
theorem cert_e2408805987270 : check e2408805987270 [[],[]] .chain = true := by decide
def e2408805988750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2408805988750 : Closed e2408805988750 ∧ code e2408805988750 = 11204899010958 := by decide
theorem cert_e2408805988750 : check e2408805988750 [[],[]] .chain = true := by decide
def e2408805988806 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2408805988806 : Closed e2408805988806 ∧ code e2408805988806 = 11204899011014 := by decide
theorem cert_e2408805988806 : check e2408805988806 [[],[]] .chain = true := by decide
def e2408806026094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2408806026094 : Closed e2408806026094 ∧ code e2408806026094 = 11204899048302 := by decide
theorem cert_e2408806026094 : check e2408806026094 [[],[]] .smaller = true := by decide
def e2408806026102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2408806026102 : Closed e2408806026102 ∧ code e2408806026102 = 11204899048310 := by decide
theorem cert_e2408806026102 : check e2408806026102 [[],[]] .smaller = true := by decide
def e2408806026158 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2408806026158 : Closed e2408806026158 ∧ code e2408806026158 = 11204899048366 := by decide
theorem cert_e2408806026158 : check e2408806026158 [[],[]] .smaller = true := by decide
def e2408806026170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2408806026170 : Closed e2408806026170 ∧ code e2408806026170 = 11204899048378 := by decide
theorem cert_e2408806026170 : check e2408806026170 [[],[]] .smaller = true := by decide
def e2408806026198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2408806026198 : Closed e2408806026198 ∧ code e2408806026198 = 11204899048406 := by decide
theorem cert_e2408806026198 : check e2408806026198 [[],[]] .smaller = true := by decide
def e2408806026202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2408806026202 : Closed e2408806026202 ∧ code e2408806026202 = 11204899048410 := by decide
theorem cert_e2408806026202 : check e2408806026202 [[],[]] .smaller = true := by decide
def e2408806026478 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2408806026478 : Closed e2408806026478 ∧ code e2408806026478 = 11204899048686 := by decide
theorem cert_e2408806026478 : check e2408806026478 [[],[]] .smaller = true := by decide
def e2408806026486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2408806026486 : Closed e2408806026486 ∧ code e2408806026486 = 11204899048694 := by decide
theorem cert_e2408806026486 : check e2408806026486 [[],[]] .smaller = true := by decide
def e2408806026862 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2408806026862 : Closed e2408806026862 ∧ code e2408806026862 = 11204899049070 := by decide
theorem cert_e2408806026862 : check e2408806026862 [[],[]] .smaller = true := by decide
def e2408806026874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2408806026874 : Closed e2408806026874 ∧ code e2408806026874 = 11204899049082 := by decide
theorem cert_e2408806026874 : check e2408806026874 [[],[]] .smaller = true := by decide
def e2408806027062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2408806027062 : Closed e2408806027062 ∧ code e2408806027062 = 11204899049270 := by decide
theorem cert_e2408806027062 : check e2408806027062 [[],[]] .smaller = true := by decide
def e2408806027066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2408806027066 : Closed e2408806027066 ∧ code e2408806027066 = 11204899049274 := by decide
theorem cert_e2408806027066 : check e2408806027066 [[],[]] .smaller = true := by decide
def e2408806034542 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2408806034542 : Closed e2408806034542 ∧ code e2408806034542 = 11204899056750 := by decide
theorem cert_e2408806034542 : check e2408806034542 [[],[]] .chain = true := by decide
def e2408806034554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2408806034554 : Closed e2408806034554 ∧ code e2408806034554 = 11204899056762 := by decide
theorem cert_e2408806034554 : check e2408806034554 [[],[]] .chain = true := by decide
def e2408806034718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2408806034718 : Closed e2408806034718 ∧ code e2408806034718 = 11204899056926 := by decide
theorem cert_e2408806034718 : check e2408806034718 [[],[]] .chain = true := by decide
def e2408806034886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2408806034886 : Closed e2408806034886 ∧ code e2408806034886 = 11204899057094 := by decide
theorem cert_e2408806034886 : check e2408806034886 [[],[]] .chain = true := by decide
def e2408806035226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2408806035226 : Closed e2408806035226 ∧ code e2408806035226 = 11204899057434 := by decide
theorem cert_e2408806035226 : check e2408806035226 [[],[]] .chain = true := by decide
def e2408806035270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2408806035270 : Closed e2408806035270 ∧ code e2408806035270 = 11204899057478 := by decide
theorem cert_e2408806035270 : check e2408806035270 [[],[]] .chain = true := by decide
def e2408806036254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2408806036254 : Closed e2408806036254 ∧ code e2408806036254 = 11204899058462 := by decide
theorem cert_e2408806036254 : check e2408806036254 [[],[]] .chain = true := by decide
def e2408806036422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2408806036422 : Closed e2408806036422 ∧ code e2408806036422 = 11204899058630 := by decide
theorem cert_e2408806036422 : check e2408806036422 [[],[]] .chain = true := by decide
def e2408806038726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2408806038726 : Closed e2408806038726 ∧ code e2408806038726 = 11204899060934 := by decide
theorem cert_e2408806038726 : check e2408806038726 [[],[]] .chain = true := by decide
def e2408806061622 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2408806061622 : Closed e2408806061622 ∧ code e2408806061622 = 11204899083830 := by decide
theorem cert_e2408806061622 : check e2408806061622 [[],[]] .chain = true := by decide
def e2408806061626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2408806061626 : Closed e2408806061626 ∧ code e2408806061626 = 11204899083834 := by decide
theorem cert_e2408806061626 : check e2408806061626 [[],[]] .chain = true := by decide
def e2408806061710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2408806061710 : Closed e2408806061710 ∧ code e2408806061710 = 11204899083918 := by decide
theorem cert_e2408806061710 : check e2408806061710 [[],[]] .chain = true := by decide
def e2408806061766 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2408806061766 : Closed e2408806061766 ∧ code e2408806061766 = 11204899083974 := by decide
theorem cert_e2408806061766 : check e2408806061766 [[],[]] .chain = true := by decide
def e2408806061850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2408806061850 : Closed e2408806061850 ∧ code e2408806061850 = 11204899084058 := by decide
theorem cert_e2408806061850 : check e2408806061850 [[],[]] .chain = true := by decide
def e2408806061894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2408806061894 : Closed e2408806061894 ∧ code e2408806061894 = 11204899084102 := by decide
theorem cert_e2408806061894 : check e2408806061894 [[],[]] .chain = true := by decide
def e2408806062478 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2408806062478 : Closed e2408806062478 ∧ code e2408806062478 = 11204899084686 := by decide
theorem cert_e2408806062478 : check e2408806062478 [[],[]] .chain = true := by decide
def e2408806062534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2408806062534 : Closed e2408806062534 ∧ code e2408806062534 = 11204899084742 := by decide
theorem cert_e2408806062534 : check e2408806062534 [[],[]] .chain = true := by decide
def e2408806063302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2408806063302 : Closed e2408806063302 ∧ code e2408806063302 = 11204899085510 := by decide
theorem cert_e2408806063302 : check e2408806063302 [[],[]] .chain = true := by decide
def e2408807160046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2408807160046 : Closed e2408807160046 ∧ code e2408807160046 = 11204900182254 := by decide
theorem cert_e2408807160046 : check e2408807160046 [[],[]] .chain = true := by decide
def e2408807160054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2408807160054 : Closed e2408807160054 ∧ code e2408807160054 = 11204900182262 := by decide
theorem cert_e2408807160054 : check e2408807160054 [[],[]] .chain = true := by decide
def e2408807160606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2408807160606 : Closed e2408807160606 ∧ code e2408807160606 = 11204900182814 := by decide
theorem cert_e2408807160606 : check e2408807160606 [[],[]] .chain = true := by decide
def e2408807160718 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2408807160718 : Closed e2408807160718 ∧ code e2408807160718 = 11204900182926 := by decide
theorem cert_e2408807160718 : check e2408807160718 [[],[]] .chain = true := by decide
end Blc.Floor43
