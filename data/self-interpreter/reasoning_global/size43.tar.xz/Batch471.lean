import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407024442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407024442 : Closed e2422407024442 ∧ code e2422407024442 = 11218500046650 := by decide
theorem cert_e2422407024442 : check e2422407024442 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407037358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e2422407037358 : Closed e2422407037358 ∧ code e2422407037358 = 11218500059566 := by decide
theorem cert_e2422407037358 : check e2422407037358 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407037550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407037550 : Closed e2422407037550 ∧ code e2422407037550 = 11218500059758 := by decide
theorem cert_e2422407037550 : check e2422407037550 [[],[]] .chain = true := by decide
def e2422407037562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407037562 : Closed e2422407037562 ∧ code e2422407037562 = 11218500059770 := by decide
theorem cert_e2422407037562 : check e2422407037562 [[],[]] .chain = true := by decide
def e2422407037934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 4))))) (.var 2))))))
theorem wire_e2422407037934 : Closed e2422407037934 ∧ code e2422407037934 = 11218500060142 := by decide
theorem cert_e2422407037934 : check e2422407037934 [[],[]] .chain = true := by decide
def e2422407037942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 5))))) (.var 1))))))
theorem wire_e2422407037942 : Closed e2422407037942 ∧ code e2422407037942 = 11218500060150 := by decide
theorem cert_e2422407037942 : check e2422407037942 [[],[]] .chain = true := by decide
def e2422407038702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e2422407038702 : Closed e2422407038702 ∧ code e2422407038702 = 11218500060910 := by decide
theorem cert_e2422407038702 : check e2422407038702 [[],[]] .chain = true := by decide
def e2422407038714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.var 4))))) (.var 0))))))
theorem wire_e2422407038714 : Closed e2422407038714 ∧ code e2422407038714 = 11218500060922 := by decide
theorem cert_e2422407038714 : check e2422407038714 [[],[]] .chain = true := by decide
def e2422407038830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e2422407038830 : Closed e2422407038830 ∧ code e2422407038830 = 11218500061038 := by decide
theorem cert_e2422407038830 : check e2422407038830 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407038894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e2422407038894 : Closed e2422407038894 ∧ code e2422407038894 = 11218500061102 := by decide
theorem cert_e2422407038894 : check e2422407038894 [[],[]] .chain = true := by decide
def e2422407038954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 4) (.var 0))))) (.var 0))))))
theorem wire_e2422407038954 : Closed e2422407038954 ∧ code e2422407038954 = 11218500061162 := by decide
theorem cert_e2422407038954 : check e2422407038954 [[],[]] .chain = true := by decide
def e2422407039470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407039470 : Closed e2422407039470 ∧ code e2422407039470 = 11218500061678 := by decide
theorem cert_e2422407039470 : check e2422407039470 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407040238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407040238 : Closed e2422407040238 ∧ code e2422407040238 = 11218500062446 := by decide
theorem cert_e2422407040238 : check e2422407040238 [[],[]] .chain = true := by decide
def e2422407040246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407040246 : Closed e2422407040246 ∧ code e2422407040246 = 11218500062454 := by decide
theorem cert_e2422407040246 : check e2422407040246 [[],[]] .chain = true := by decide
def e2422407040622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407040622 : Closed e2422407040622 ∧ code e2422407040622 = 11218500062830 := by decide
theorem cert_e2422407040622 : check e2422407040622 [[],[]] .chain = true := by decide
def e2422407040634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407040634 : Closed e2422407040634 ∧ code e2422407040634 = 11218500062842 := by decide
theorem cert_e2422407040634 : check e2422407040634 [[],[]] .chain = true := by decide
def e2422407040798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 3)))) (.lam (.var 3)))))))
theorem wire_e2422407040798 : Closed e2422407040798 ∧ code e2422407040798 = 11218500063006 := by decide
theorem cert_e2422407040798 : check e2422407040798 [[],[]] .chain = true := by decide
def e2422407040910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.lam (.var 2)))))))
theorem wire_e2422407040910 : Closed e2422407040910 ∧ code e2422407040910 = 11218500063118 := by decide
theorem cert_e2422407040910 : check e2422407040910 [[],[]] .chain = true := by decide
def e2422407040922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407040922 : Closed e2422407040922 ∧ code e2422407040922 = 11218500063130 := by decide
theorem cert_e2422407040922 : check e2422407040922 [[],[]] .chain = true := by decide
def e2422407042734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e2422407042734 : Closed e2422407042734 ∧ code e2422407042734 = 11218500064942 := by decide
theorem cert_e2422407042734 : check e2422407042734 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407043310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 2))))))
theorem wire_e2422407043310 : Closed e2422407043310 ∧ code e2422407043310 = 11218500065518 := by decide
theorem cert_e2422407043310 : check e2422407043310 [[],[]] .chain = true := by decide
def e2422407043322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422407043322 : Closed e2422407043322 ∧ code e2422407043322 = 11218500065530 := by decide
theorem cert_e2422407043322 : check e2422407043322 [[],[]] .chain = true := by decide
def e2422407043502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2422407043502 : Closed e2422407043502 ∧ code e2422407043502 = 11218500065710 := by decide
theorem cert_e2422407043502 : check e2422407043502 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407043694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407043694 : Closed e2422407043694 ∧ code e2422407043694 = 11218500065902 := by decide
theorem cert_e2422407043694 : check e2422407043694 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407043706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407043706 : Closed e2422407043706 ∧ code e2422407043706 = 11218500065914 := by decide
theorem cert_e2422407043706 : check e2422407043706 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407043870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2422407043870 : Closed e2422407043870 ∧ code e2422407043870 = 11218500066078 := by decide
theorem cert_e2422407043870 : check e2422407043870 [[],[]] .chain = true := by decide
def e2422407044038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422407044038 : Closed e2422407044038 ∧ code e2422407044038 = 11218500066246 := by decide
theorem cert_e2422407044038 : check e2422407044038 [[],[]] .chain = true := by decide
def e2422407044206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 2))))))
theorem wire_e2422407044206 : Closed e2422407044206 ∧ code e2422407044206 = 11218500066414 := by decide
theorem cert_e2422407044206 : check e2422407044206 [[],[]] .chain = true := by decide
def e2422407044382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2422407044382 : Closed e2422407044382 ∧ code e2422407044382 = 11218500066590 := by decide
theorem cert_e2422407044382 : check e2422407044382 [[],[]] .chain = true := by decide
def e2422407044578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 0)))))))
theorem wire_e2422407044578 : Closed e2422407044578 ∧ code e2422407044578 = 11218500066786 := by decide
theorem cert_e2422407044578 : check e2422407044578 [[],[]] .chain = true := by decide
def e2422407044590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))) (.var 2))))))
theorem wire_e2422407044590 : Closed e2422407044590 ∧ code e2422407044590 = 11218500066798 := by decide
theorem cert_e2422407044590 : check e2422407044590 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407044654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407044654 : Closed e2422407044654 ∧ code e2422407044654 = 11218500066862 := by decide
theorem cert_e2422407044654 : check e2422407044654 [[],[]] .chain = true := by decide
def e2422407044846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 2)))) (.var 2))))))
theorem wire_e2422407044846 : Closed e2422407044846 ∧ code e2422407044846 = 11218500067054 := by decide
theorem cert_e2422407044846 : check e2422407044846 [[],[]] .chain = true := by decide
def e2422407044854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3)))) (.var 1))))))
theorem wire_e2422407044854 : Closed e2422407044854 ∧ code e2422407044854 = 11218500067062 := by decide
theorem cert_e2422407044854 : check e2422407044854 [[],[]] .chain = true := by decide
def e2422407044886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407044886 : Closed e2422407044886 ∧ code e2422407044886 = 11218500067094 := by decide
theorem cert_e2422407044886 : check e2422407044886 [[],[]] .chain = true := by decide
def e2422407044890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407044890 : Closed e2422407044890 ∧ code e2422407044890 = 11218500067098 := by decide
theorem cert_e2422407044890 : check e2422407044890 [[],[]] .chain = true := by decide
def e2422407044934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407044934 : Closed e2422407044934 ∧ code e2422407044934 = 11218500067142 := by decide
theorem cert_e2422407044934 : check e2422407044934 [[],[]] .chain = true := by decide
def e2422407044962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407044962 : Closed e2422407044962 ∧ code e2422407044962 = 11218500067170 := by decide
theorem cert_e2422407044962 : check e2422407044962 [[],[]] .chain = true := by decide
def e2422407044974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))) (.var 2))))))
theorem wire_e2422407044974 : Closed e2422407044974 ∧ code e2422407044974 = 11218500067182 := by decide
theorem cert_e2422407044974 : check e2422407044974 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407044982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2)))) (.var 1))))))
theorem wire_e2422407044982 : Closed e2422407044982 ∧ code e2422407044982 = 11218500067190 := by decide
theorem cert_e2422407044982 : check e2422407044982 [[],[]] .chain = true := by decide
def e2422407044986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 3)))) (.var 0))))))
theorem wire_e2422407044986 : Closed e2422407044986 ∧ code e2422407044986 = 11218500067194 := by decide
theorem cert_e2422407044986 : check e2422407044986 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407045598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407045598 : Closed e2422407045598 ∧ code e2422407045598 = 11218500067806 := by decide
theorem cert_e2422407045598 : check e2422407045598 [[],[]] .chain = true := by decide
def e2422407045622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407045622 : Closed e2422407045622 ∧ code e2422407045622 = 11218500067830 := by decide
theorem cert_e2422407045622 : check e2422407045622 [[],[]] .chain = true := by decide
def e2422407046574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407046574 : Closed e2422407046574 ∧ code e2422407046574 = 11218500068782 := by decide
theorem cert_e2422407046574 : check e2422407046574 [[],[]] .chain = true := by decide
def e2422407046586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407046586 : Closed e2422407046586 ∧ code e2422407046586 = 11218500068794 := by decide
theorem cert_e2422407046586 : check e2422407046586 [[],[]] .chain = true := by decide
def e2422407046634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407046634 : Closed e2422407046634 ∧ code e2422407046634 = 11218500068842 := by decide
theorem cert_e2422407046634 : check e2422407046634 [[],[]] .chain = true := by decide
def e2422407046766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407046766 : Closed e2422407046766 ∧ code e2422407046766 = 11218500068974 := by decide
theorem cert_e2422407046766 : check e2422407046766 [[],[]] .chain = true := by decide
def e2422407046778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407046778 : Closed e2422407046778 ∧ code e2422407046778 = 11218500068986 := by decide
theorem cert_e2422407046778 : check e2422407046778 [[],[]] .chain = true := by decide
def e2422407046942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407046942 : Closed e2422407046942 ∧ code e2422407046942 = 11218500069150 := by decide
theorem cert_e2422407046942 : check e2422407046942 [[],[]] .chain = true := by decide
def e2422407047054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407047054 : Closed e2422407047054 ∧ code e2422407047054 = 11218500069262 := by decide
theorem cert_e2422407047054 : check e2422407047054 [[],[]] .chain = true := by decide
def e2422407047066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407047066 : Closed e2422407047066 ∧ code e2422407047066 = 11218500069274 := by decide
theorem cert_e2422407047066 : check e2422407047066 [[],[]] .chain = true := by decide
def e2422407049438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2422407049438 : Closed e2422407049438 ∧ code e2422407049438 = 11218500071646 := by decide
theorem cert_e2422407049438 : check e2422407049438 [[],[]] .chain = true := by decide
def e2422407049466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2422407049466 : Closed e2422407049466 ∧ code e2422407049466 = 11218500071674 := by decide
theorem cert_e2422407049466 : check e2422407049466 [[],[]] .chain = true := by decide
def e2422407050014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407050014 : Closed e2422407050014 ∧ code e2422407050014 = 11218500072222 := by decide
theorem cert_e2422407050014 : check e2422407050014 [[],[]] .chain = true := by decide
def e2422407050182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407050182 : Closed e2422407050182 ∧ code e2422407050182 = 11218500072390 := by decide
theorem cert_e2422407050182 : check e2422407050182 [[],[]] .chain = true := by decide
def e2422407051326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.lam (.lam (.var 4))))))))
theorem wire_e2422407051326 : Closed e2422407051326 ∧ code e2422407051326 = 11218500073534 := by decide
theorem cert_e2422407051326 : check e2422407051326 [[],[]] .chain = true := by decide
def e2422407051746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407051746 : Closed e2422407051746 ∧ code e2422407051746 = 11218500073954 := by decide
theorem cert_e2422407051746 : check e2422407051746 [[],[]] .chain = true := by decide
def e2422407051758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407051758 : Closed e2422407051758 ∧ code e2422407051758 = 11218500073966 := by decide
theorem cert_e2422407051758 : check e2422407051758 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407052318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407052318 : Closed e2422407052318 ∧ code e2422407052318 = 11218500074526 := by decide
theorem cert_e2422407052318 : check e2422407052318 [[],[]] .chain = true := by decide
def e2422407052342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407052342 : Closed e2422407052342 ∧ code e2422407052342 = 11218500074550 := by decide
theorem cert_e2422407052342 : check e2422407052342 [[],[]] .chain = true := by decide
def e2422407052346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407052346 : Closed e2422407052346 ∧ code e2422407052346 = 11218500074554 := by decide
theorem cert_e2422407052346 : check e2422407052346 [[],[]] .chain = true := by decide
def e2422407052486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407052486 : Closed e2422407052486 ∧ code e2422407052486 = 11218500074694 := by decide
theorem cert_e2422407052486 : check e2422407052486 [[],[]] .chain = true := by decide
def e2422407052514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407052514 : Closed e2422407052514 ∧ code e2422407052514 = 11218500074722 := by decide
theorem cert_e2422407052514 : check e2422407052514 [[],[]] .chain = true := by decide
def e2422407052526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407052526 : Closed e2422407052526 ∧ code e2422407052526 = 11218500074734 := by decide
theorem cert_e2422407052526 : check e2422407052526 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407052534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407052534 : Closed e2422407052534 ∧ code e2422407052534 = 11218500074742 := by decide
theorem cert_e2422407052534 : check e2422407052534 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407059630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2422407059630 : Closed e2422407059630 ∧ code e2422407059630 = 11218500081838 := by decide
theorem cert_e2422407059630 : check e2422407059630 [[],[]] .chain = true := by decide
def e2422407059642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2422407059642 : Closed e2422407059642 ∧ code e2422407059642 = 11218500081850 := by decide
theorem cert_e2422407059642 : check e2422407059642 [[],[]] .chain = true := by decide
def e2422407060014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422407060014 : Closed e2422407060014 ∧ code e2422407060014 = 11218500082222 := by decide
theorem cert_e2422407060014 : check e2422407060014 [[],[]] .chain = true := by decide
def e2422407060194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422407060194 : Closed e2422407060194 ∧ code e2422407060194 = 11218500082402 := by decide
theorem cert_e2422407060194 : check e2422407060194 [[],[]] .chain = true := by decide
def e2422407060206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2422407060206 : Closed e2422407060206 ∧ code e2422407060206 = 11218500082414 := by decide
theorem cert_e2422407060206 : check e2422407060206 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407060334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2422407060334 : Closed e2422407060334 ∧ code e2422407060334 = 11218500082542 := by decide
theorem cert_e2422407060334 : check e2422407060334 [[],[]] .chain = true := by decide
def e2422407060342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2422407060342 : Closed e2422407060342 ∧ code e2422407060342 = 11218500082550 := by decide
theorem cert_e2422407060342 : check e2422407060342 [[],[]] .chain = true := by decide
def e2422407060362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407060362 : Closed e2422407060362 ∧ code e2422407060362 = 11218500082570 := by decide
theorem cert_e2422407060362 : check e2422407060362 [[],[]] .chain = true := by decide
def e2422407060386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407060386 : Closed e2422407060386 ∧ code e2422407060386 = 11218500082594 := by decide
theorem cert_e2422407060386 : check e2422407060386 [[],[]] .chain = true := by decide
def e2422407060398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2422407060398 : Closed e2422407060398 ∧ code e2422407060398 = 11218500082606 := by decide
theorem cert_e2422407060398 : check e2422407060398 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407060406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2422407060406 : Closed e2422407060406 ∧ code e2422407060406 = 11218500082614 := by decide
theorem cert_e2422407060406 : check e2422407060406 [[],[]] .chain = true := by decide
def e2422407060410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2422407060410 : Closed e2422407060410 ∧ code e2422407060410 = 11218500082618 := by decide
theorem cert_e2422407060410 : check e2422407060410 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407060846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422407060846 : Closed e2422407060846 ∧ code e2422407060846 = 11218500083054 := by decide
theorem cert_e2422407060846 : check e2422407060846 [[],[]] .chain = true := by decide
def e2422407060854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422407060854 : Closed e2422407060854 ∧ code e2422407060854 = 11218500083062 := by decide
theorem cert_e2422407060854 : check e2422407060854 [[],[]] .chain = true := by decide
def e2422407060910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422407060910 : Closed e2422407060910 ∧ code e2422407060910 = 11218500083118 := by decide
theorem cert_e2422407060910 : check e2422407060910 [[],[]] .chain = true := by decide
def e2422407060922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422407060922 : Closed e2422407060922 ∧ code e2422407060922 = 11218500083130 := by decide
theorem cert_e2422407060922 : check e2422407060922 [[],[]] .chain = true := by decide
def e2422407060950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422407060950 : Closed e2422407060950 ∧ code e2422407060950 = 11218500083158 := by decide
theorem cert_e2422407060950 : check e2422407060950 [[],[]] .chain = true := by decide
def e2422407060954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422407060954 : Closed e2422407060954 ∧ code e2422407060954 = 11218500083162 := by decide
theorem cert_e2422407060954 : check e2422407060954 [[],[]] .chain = true := by decide
def e2422407061034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2422407061034 : Closed e2422407061034 ∧ code e2422407061034 = 11218500083242 := by decide
theorem cert_e2422407061034 : check e2422407061034 [[],[]] .chain = true := by decide
def e2422407061130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407061130 : Closed e2422407061130 ∧ code e2422407061130 = 11218500083338 := by decide
theorem cert_e2422407061130 : check e2422407061130 [[],[]] .chain = true := by decide
def e2422407061154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407061154 : Closed e2422407061154 ∧ code e2422407061154 = 11218500083362 := by decide
theorem cert_e2422407061154 : check e2422407061154 [[],[]] .chain = true := by decide
def e2422407061166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422407061166 : Closed e2422407061166 ∧ code e2422407061166 = 11218500083374 := by decide
theorem cert_e2422407061166 : check e2422407061166 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407061174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2422407061174 : Closed e2422407061174 ∧ code e2422407061174 = 11218500083382 := by decide
theorem cert_e2422407061174 : check e2422407061174 [[],[]] .chain = true := by decide
def e2422407061178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422407061178 : Closed e2422407061178 ∧ code e2422407061178 = 11218500083386 := by decide
theorem cert_e2422407061178 : check e2422407061178 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407061206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2422407061206 : Closed e2422407061206 ∧ code e2422407061206 = 11218500083414 := by decide
theorem cert_e2422407061206 : check e2422407061206 [[],[]] .chain = true := by decide
def e2422407061210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2422407061210 : Closed e2422407061210 ∧ code e2422407061210 = 11218500083418 := by decide
theorem cert_e2422407061210 : check e2422407061210 [[],[]] .chain = true := by decide
def e2422407061226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422407061226 : Closed e2422407061226 ∧ code e2422407061226 = 11218500083434 := by decide
theorem cert_e2422407061226 : check e2422407061226 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407061550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422407061550 : Closed e2422407061550 ∧ code e2422407061550 = 11218500083758 := by decide
theorem cert_e2422407061550 : check e2422407061550 [[],[]] .chain = true := by decide
def e2422407061742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2422407061742 : Closed e2422407061742 ∧ code e2422407061742 = 11218500083950 := by decide
theorem cert_e2422407061742 : check e2422407061742 [[],[]] .chain = true := by decide
def e2422407061754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422407061754 : Closed e2422407061754 ∧ code e2422407061754 = 11218500083962 := by decide
theorem cert_e2422407061754 : check e2422407061754 [[],[]] .chain = true := by decide
def e2422407061934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2422407061934 : Closed e2422407061934 ∧ code e2422407061934 = 11218500084142 := by decide
theorem cert_e2422407061934 : check e2422407061934 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407062126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407062126 : Closed e2422407062126 ∧ code e2422407062126 = 11218500084334 := by decide
theorem cert_e2422407062126 : check e2422407062126 [[],[]] .chain = true := by decide
def e2422407062138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407062138 : Closed e2422407062138 ∧ code e2422407062138 = 11218500084346 := by decide
theorem cert_e2422407062138 : check e2422407062138 [[],[]] .chain = true := by decide
def e2422407062302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2422407062302 : Closed e2422407062302 ∧ code e2422407062302 = 11218500084510 := by decide
theorem cert_e2422407062302 : check e2422407062302 [[],[]] .chain = true := by decide
def e2422407062470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422407062470 : Closed e2422407062470 ∧ code e2422407062470 = 11218500084678 := by decide
theorem cert_e2422407062470 : check e2422407062470 [[],[]] .chain = true := by decide
def e2422407063086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407063086 : Closed e2422407063086 ∧ code e2422407063086 = 11218500085294 := by decide
theorem cert_e2422407063086 : check e2422407063086 [[],[]] .chain = true := by decide
def e2422407063266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407063266 : Closed e2422407063266 ∧ code e2422407063266 = 11218500085474 := by decide
theorem cert_e2422407063266 : check e2422407063266 [[],[]] .chain = true := by decide
def e2422407063278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2422407063278 : Closed e2422407063278 ∧ code e2422407063278 = 11218500085486 := by decide
theorem cert_e2422407063278 : check e2422407063278 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407063406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2422407063406 : Closed e2422407063406 ∧ code e2422407063406 = 11218500085614 := by decide
theorem cert_e2422407063406 : check e2422407063406 [[],[]] .chain = true := by decide
def e2422407063414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2422407063414 : Closed e2422407063414 ∧ code e2422407063414 = 11218500085622 := by decide
theorem cert_e2422407063414 : check e2422407063414 [[],[]] .chain = true := by decide
def e2422407063434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407063434 : Closed e2422407063434 ∧ code e2422407063434 = 11218500085642 := by decide
theorem cert_e2422407063434 : check e2422407063434 [[],[]] .chain = true := by decide
def e2422407063458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407063458 : Closed e2422407063458 ∧ code e2422407063458 = 11218500085666 := by decide
theorem cert_e2422407063458 : check e2422407063458 [[],[]] .chain = true := by decide
def e2422407063470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2422407063470 : Closed e2422407063470 ∧ code e2422407063470 = 11218500085678 := by decide
theorem cert_e2422407063470 : check e2422407063470 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407063478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2422407063478 : Closed e2422407063478 ∧ code e2422407063478 = 11218500085686 := by decide
theorem cert_e2422407063478 : check e2422407063478 [[],[]] .chain = true := by decide
def e2422407063482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2422407063482 : Closed e2422407063482 ∧ code e2422407063482 = 11218500085690 := by decide
theorem cert_e2422407063482 : check e2422407063482 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407063614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2422407063614 : Closed e2422407063614 ∧ code e2422407063614 = 11218500085822 := by decide
theorem cert_e2422407063614 : check e2422407063614 [[],[]] .chain = true := by decide
def e2422407064034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407064034 : Closed e2422407064034 ∧ code e2422407064034 = 11218500086242 := by decide
theorem cert_e2422407064034 : check e2422407064034 [[],[]] .chain = true := by decide
def e2422407064046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407064046 : Closed e2422407064046 ∧ code e2422407064046 = 11218500086254 := by decide
theorem cert_e2422407064046 : check e2422407064046 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407064814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407064814 : Closed e2422407064814 ∧ code e2422407064814 = 11218500087022 := by decide
theorem cert_e2422407064814 : check e2422407064814 [[],[]] .chain = true := by decide
def e2422407064822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407064822 : Closed e2422407064822 ∧ code e2422407064822 = 11218500087030 := by decide
theorem cert_e2422407064822 : check e2422407064822 [[],[]] .chain = true := by decide
def e2422407065090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407065090 : Closed e2422407065090 ∧ code e2422407065090 = 11218500087298 := by decide
theorem cert_e2422407065090 : check e2422407065090 [[],[]] .chain = true := by decide
def e2422407065102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407065102 : Closed e2422407065102 ∧ code e2422407065102 = 11218500087310 := by decide
theorem cert_e2422407065102 : check e2422407065102 [[],[]] .chain = true := by decide
def e2422407065114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407065114 : Closed e2422407065114 ∧ code e2422407065114 = 11218500087322 := by decide
theorem cert_e2422407065114 : check e2422407065114 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407065186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407065186 : Closed e2422407065186 ∧ code e2422407065186 = 11218500087394 := by decide
theorem cert_e2422407065186 : check e2422407065186 [[],[]] .chain = true := by decide
def e2422407065198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407065198 : Closed e2422407065198 ∧ code e2422407065198 = 11218500087406 := by decide
theorem cert_e2422407065198 : check e2422407065198 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407065206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407065206 : Closed e2422407065206 ∧ code e2422407065206 = 11218500087414 := by decide
theorem cert_e2422407065206 : check e2422407065206 [[],[]] .chain = true := by decide
def e2422407065210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407065210 : Closed e2422407065210 ∧ code e2422407065210 = 11218500087418 := by decide
theorem cert_e2422407065210 : check e2422407065210 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407065710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e2422407065710 : Closed e2422407065710 ∧ code e2422407065710 = 11218500087918 := by decide
theorem cert_e2422407065710 : check e2422407065710 [[],[]] .chain = true := by decide
def e2422407065886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2422407065886 : Closed e2422407065886 ∧ code e2422407065886 = 11218500088094 := by decide
theorem cert_e2422407065886 : check e2422407065886 [[],[]] .chain = true := by decide
def e2422407066082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e2422407066082 : Closed e2422407066082 ∧ code e2422407066082 = 11218500088290 := by decide
theorem cert_e2422407066082 : check e2422407066082 [[],[]] .chain = true := by decide
def e2422407066094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))) (.var 2))))))
theorem wire_e2422407066094 : Closed e2422407066094 ∧ code e2422407066094 = 11218500088302 := by decide
theorem cert_e2422407066094 : check e2422407066094 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407066478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422407066478 : Closed e2422407066478 ∧ code e2422407066478 = 11218500088686 := by decide
theorem cert_e2422407066478 : check e2422407066478 [[],[]] .chain = true := by decide
def e2422407066486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422407066486 : Closed e2422407066486 ∧ code e2422407066486 = 11218500088694 := by decide
theorem cert_e2422407066486 : check e2422407066486 [[],[]] .chain = true := by decide
def e2422407066542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422407066542 : Closed e2422407066542 ∧ code e2422407066542 = 11218500088750 := by decide
theorem cert_e2422407066542 : check e2422407066542 [[],[]] .chain = true := by decide
def e2422407066554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422407066554 : Closed e2422407066554 ∧ code e2422407066554 = 11218500088762 := by decide
theorem cert_e2422407066554 : check e2422407066554 [[],[]] .chain = true := by decide
def e2422407066582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422407066582 : Closed e2422407066582 ∧ code e2422407066582 = 11218500088790 := by decide
theorem cert_e2422407066582 : check e2422407066582 [[],[]] .chain = true := by decide
def e2422407066586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422407066586 : Closed e2422407066586 ∧ code e2422407066586 = 11218500088794 := by decide
theorem cert_e2422407066586 : check e2422407066586 [[],[]] .chain = true := by decide
def e2422407066862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407066862 : Closed e2422407066862 ∧ code e2422407066862 = 11218500089070 := by decide
theorem cert_e2422407066862 : check e2422407066862 [[],[]] .chain = true := by decide
def e2422407066870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407066870 : Closed e2422407066870 ∧ code e2422407066870 = 11218500089078 := by decide
theorem cert_e2422407066870 : check e2422407066870 [[],[]] .chain = true := by decide
def e2422407067246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407067246 : Closed e2422407067246 ∧ code e2422407067246 = 11218500089454 := by decide
theorem cert_e2422407067246 : check e2422407067246 [[],[]] .chain = true := by decide
def e2422407067258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407067258 : Closed e2422407067258 ∧ code e2422407067258 = 11218500089466 := by decide
theorem cert_e2422407067258 : check e2422407067258 [[],[]] .chain = true := by decide
def e2422407067398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407067398 : Closed e2422407067398 ∧ code e2422407067398 = 11218500089606 := by decide
theorem cert_e2422407067398 : check e2422407067398 [[],[]] .chain = true := by decide
def e2422407067422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 3)))))))
theorem wire_e2422407067422 : Closed e2422407067422 ∧ code e2422407067422 = 11218500089630 := by decide
theorem cert_e2422407067422 : check e2422407067422 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407067446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407067446 : Closed e2422407067446 ∧ code e2422407067446 = 11218500089654 := by decide
theorem cert_e2422407067446 : check e2422407067446 [[],[]] .chain = true := by decide
def e2422407067450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407067450 : Closed e2422407067450 ∧ code e2422407067450 = 11218500089658 := by decide
theorem cert_e2422407067450 : check e2422407067450 [[],[]] .chain = true := by decide
def e2422407067658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422407067658 : Closed e2422407067658 ∧ code e2422407067658 = 11218500089866 := by decide
theorem cert_e2422407067658 : check e2422407067658 [[],[]] .chain = true := by decide
def e2422407067694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407067694 : Closed e2422407067694 ∧ code e2422407067694 = 11218500089902 := by decide
theorem cert_e2422407067694 : check e2422407067694 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407067702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407067702 : Closed e2422407067702 ∧ code e2422407067702 = 11218500089910 := by decide
theorem cert_e2422407067702 : check e2422407067702 [[],[]] .chain = true := by decide
def e2422407067706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407067706 : Closed e2422407067706 ∧ code e2422407067706 = 11218500089914 := by decide
theorem cert_e2422407067706 : check e2422407067706 [[],[]] .chain = true := by decide
def e2422407067754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407067754 : Closed e2422407067754 ∧ code e2422407067754 = 11218500089962 := by decide
theorem cert_e2422407067754 : check e2422407067754 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407067790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407067790 : Closed e2422407067790 ∧ code e2422407067790 = 11218500089998 := by decide
theorem cert_e2422407067790 : check e2422407067790 [[],[]] .chain = true := by decide
def e2422407067802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407067802 : Closed e2422407067802 ∧ code e2422407067802 = 11218500090010 := by decide
theorem cert_e2422407067802 : check e2422407067802 [[],[]] .chain = true := by decide
def e2422407067846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407067846 : Closed e2422407067846 ∧ code e2422407067846 = 11218500090054 := by decide
theorem cert_e2422407067846 : check e2422407067846 [[],[]] .chain = true := by decide
def e2422407067874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407067874 : Closed e2422407067874 ∧ code e2422407067874 = 11218500090082 := by decide
theorem cert_e2422407067874 : check e2422407067874 [[],[]] .chain = true := by decide
def e2422407067886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422407067886 : Closed e2422407067886 ∧ code e2422407067886 = 11218500090094 := by decide
theorem cert_e2422407067886 : check e2422407067886 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407067894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422407067894 : Closed e2422407067894 ∧ code e2422407067894 = 11218500090102 := by decide
theorem cert_e2422407067894 : check e2422407067894 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407068042 : Closed e2422407068042 ∧ code e2422407068042 = 11218500090250 := by decide
theorem cert_e2422407068042 : check e2422407068042 [[],[]] .chain = true := by decide
def e2422407068066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407068066 : Closed e2422407068066 ∧ code e2422407068066 = 11218500090274 := by decide
theorem cert_e2422407068066 : check e2422407068066 [[],[]] .chain = true := by decide
def e2422407068078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422407068078 : Closed e2422407068078 ∧ code e2422407068078 = 11218500090286 := by decide
theorem cert_e2422407068078 : check e2422407068078 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422407068086 : Closed e2422407068086 ∧ code e2422407068086 = 11218500090294 := by decide
theorem cert_e2422407068086 : check e2422407068086 [[],[]] .chain = true := by decide
def e2422407068090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422407068090 : Closed e2422407068090 ∧ code e2422407068090 = 11218500090298 := by decide
theorem cert_e2422407068090 : check e2422407068090 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422407068118 : Closed e2422407068118 ∧ code e2422407068118 = 11218500090326 := by decide
theorem cert_e2422407068118 : check e2422407068118 [[],[]] .chain = true := by decide
def e2422407068122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2422407068122 : Closed e2422407068122 ∧ code e2422407068122 = 11218500090330 := by decide
theorem cert_e2422407068122 : check e2422407068122 [[],[]] .chain = true := by decide
def e2422407068138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422407068138 : Closed e2422407068138 ∧ code e2422407068138 = 11218500090346 := by decide
theorem cert_e2422407068138 : check e2422407068138 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407068162 : Closed e2422407068162 ∧ code e2422407068162 = 11218500090370 := by decide
theorem cert_e2422407068162 : check e2422407068162 [[],[]] .chain = true := by decide
end Blc.Floor43
