import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411630115298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2411630115298 : Closed e2411630115298 ∧ code e2411630115298 = 11207723137506 := by decide
theorem cert_e2411630115298 : check e2411630115298 [[],[]] .chain = true := by decide
def e2411630115310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2411630115310 : Closed e2411630115310 ∧ code e2411630115310 = 11207723137518 := by decide
theorem cert_e2411630115310 : check e2411630115310 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630115870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e2411630115870 : Closed e2411630115870 ∧ code e2411630115870 = 11207723138078 := by decide
theorem cert_e2411630115870 : check e2411630115870 [[],[]] .chain = true := by decide
def e2411630115894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630115894 : Closed e2411630115894 ∧ code e2411630115894 = 11207723138102 := by decide
theorem cert_e2411630115894 : check e2411630115894 [[],[]] .chain = true := by decide
def e2411630115898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630115898 : Closed e2411630115898 ∧ code e2411630115898 = 11207723138106 := by decide
theorem cert_e2411630115898 : check e2411630115898 [[],[]] .chain = true := by decide
def e2411630116038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411630116038 : Closed e2411630116038 ∧ code e2411630116038 = 11207723138246 := by decide
theorem cert_e2411630116038 : check e2411630116038 [[],[]] .chain = true := by decide
def e2411630116066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411630116066 : Closed e2411630116066 ∧ code e2411630116066 = 11207723138274 := by decide
theorem cert_e2411630116066 : check e2411630116066 [[],[]] .chain = true := by decide
def e2411630116078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630116078 : Closed e2411630116078 ∧ code e2411630116078 = 11207723138286 := by decide
theorem cert_e2411630116078 : check e2411630116078 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630116086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630116086 : Closed e2411630116086 ∧ code e2411630116086 = 11207723138294 := by decide
theorem cert_e2411630116086 : check e2411630116086 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630134702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2411630134702 : Closed e2411630134702 ∧ code e2411630134702 = 11207723156910 := by decide
theorem cert_e2411630134702 : check e2411630134702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630134714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2411630134714 : Closed e2411630134714 ∧ code e2411630134714 = 11207723156922 := by decide
theorem cert_e2411630134714 : check e2411630134714 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630134762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2411630134762 : Closed e2411630134762 ∧ code e2411630134762 = 11207723156970 := by decide
theorem cert_e2411630134762 : check e2411630134762 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630134894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630134894 : Closed e2411630134894 ∧ code e2411630134894 = 11207723157102 := by decide
theorem cert_e2411630134894 : check e2411630134894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630134906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630134906 : Closed e2411630134906 ∧ code e2411630134906 = 11207723157114 := by decide
theorem cert_e2411630134906 : check e2411630134906 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630135070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411630135070 : Closed e2411630135070 ∧ code e2411630135070 = 11207723157278 := by decide
theorem cert_e2411630135070 : check e2411630135070 [[],[]] .chain = true := by decide
def e2411630135182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411630135182 : Closed e2411630135182 ∧ code e2411630135182 = 11207723157390 := by decide
theorem cert_e2411630135182 : check e2411630135182 [[],[]] .chain = true := by decide
def e2411630135194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411630135194 : Closed e2411630135194 ∧ code e2411630135194 = 11207723157402 := by decide
theorem cert_e2411630135194 : check e2411630135194 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630138934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411630138934 : Closed e2411630138934 ∧ code e2411630138934 = 11207723161142 := by decide
theorem cert_e2411630138934 : check e2411630138934 [[],[]] .chain = true := by decide
def e2411630138938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411630138938 : Closed e2411630138938 ∧ code e2411630138938 = 11207723161146 := by decide
theorem cert_e2411630138938 : check e2411630138938 [[],[]] .chain = true := by decide
def e2411630139022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411630139022 : Closed e2411630139022 ∧ code e2411630139022 = 11207723161230 := by decide
theorem cert_e2411630139022 : check e2411630139022 [[],[]] .chain = true := by decide
def e2411630139078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411630139078 : Closed e2411630139078 ∧ code e2411630139078 = 11207723161286 := by decide
theorem cert_e2411630139078 : check e2411630139078 [[],[]] .chain = true := by decide
def e2411630139158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411630139158 : Closed e2411630139158 ∧ code e2411630139158 = 11207723161366 := by decide
theorem cert_e2411630139158 : check e2411630139158 [[],[]] .chain = true := by decide
def e2411630139162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411630139162 : Closed e2411630139162 ∧ code e2411630139162 = 11207723161370 := by decide
theorem cert_e2411630139162 : check e2411630139162 [[],[]] .chain = true := by decide
def e2411630139206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411630139206 : Closed e2411630139206 ∧ code e2411630139206 = 11207723161414 := by decide
theorem cert_e2411630139206 : check e2411630139206 [[],[]] .chain = true := by decide
def e2411630139234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411630139234 : Closed e2411630139234 ∧ code e2411630139234 = 11207723161442 := by decide
theorem cert_e2411630139234 : check e2411630139234 [[],[]] .chain = true := by decide
def e2411630139246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2411630139246 : Closed e2411630139246 ∧ code e2411630139246 = 11207723161454 := by decide
theorem cert_e2411630139246 : check e2411630139246 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630139254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2411630139254 : Closed e2411630139254 ∧ code e2411630139254 = 11207723161462 := by decide
theorem cert_e2411630139254 : check e2411630139254 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630139318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2411630139318 : Closed e2411630139318 ∧ code e2411630139318 = 11207723161526 := by decide
theorem cert_e2411630139318 : check e2411630139318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630139502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630139502 : Closed e2411630139502 ∧ code e2411630139502 = 11207723161710 := by decide
theorem cert_e2411630139502 : check e2411630139502 [[],[]] .chain = true := by decide
def e2411630139514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630139514 : Closed e2411630139514 ∧ code e2411630139514 = 11207723161722 := by decide
theorem cert_e2411630139514 : check e2411630139514 [[],[]] .chain = true := by decide
def e2411630139790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411630139790 : Closed e2411630139790 ∧ code e2411630139790 = 11207723161998 := by decide
theorem cert_e2411630139790 : check e2411630139790 [[],[]] .chain = true := by decide
def e2411630139846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411630139846 : Closed e2411630139846 ∧ code e2411630139846 = 11207723162054 := by decide
theorem cert_e2411630139846 : check e2411630139846 [[],[]] .chain = true := by decide
def e2411630140446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 3)))))))))
theorem wire_e2411630140446 : Closed e2411630140446 ∧ code e2411630140446 = 11207723162654 := by decide
theorem cert_e2411630140446 : check e2411630140446 [[],[]] .chain = true := by decide
def e2411630140470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630140470 : Closed e2411630140470 ∧ code e2411630140470 = 11207723162678 := by decide
theorem cert_e2411630140470 : check e2411630140470 [[],[]] .chain = true := by decide
def e2411630140474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630140474 : Closed e2411630140474 ∧ code e2411630140474 = 11207723162682 := by decide
theorem cert_e2411630140474 : check e2411630140474 [[],[]] .chain = true := by decide
def e2411630140614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411630140614 : Closed e2411630140614 ∧ code e2411630140614 = 11207723162822 := by decide
theorem cert_e2411630140614 : check e2411630140614 [[],[]] .chain = true := by decide
def e2411630140642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411630140642 : Closed e2411630140642 ∧ code e2411630140642 = 11207723162850 := by decide
theorem cert_e2411630140642 : check e2411630140642 [[],[]] .chain = true := by decide
def e2411630140654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630140654 : Closed e2411630140654 ∧ code e2411630140654 = 11207723162862 := by decide
theorem cert_e2411630140654 : check e2411630140654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630140662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630140662 : Closed e2411630140662 ∧ code e2411630140662 = 11207723162870 := by decide
theorem cert_e2411630140662 : check e2411630140662 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630141046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2411630141046 : Closed e2411630141046 ∧ code e2411630141046 = 11207723163254 := by decide
theorem cert_e2411630141046 : check e2411630141046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630173422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630173422 : Closed e2411630173422 ∧ code e2411630173422 = 11207723195630 := by decide
theorem cert_e2411630173422 : check e2411630173422 [[],[]] .chain = true := by decide
def e2411630173430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630173430 : Closed e2411630173430 ∧ code e2411630173430 = 11207723195638 := by decide
theorem cert_e2411630173430 : check e2411630173430 [[],[]] .chain = true := by decide
def e2411630173806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630173806 : Closed e2411630173806 ∧ code e2411630173806 = 11207723196014 := by decide
theorem cert_e2411630173806 : check e2411630173806 [[],[]] .chain = true := by decide
def e2411630173818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630173818 : Closed e2411630173818 ∧ code e2411630173818 = 11207723196026 := by decide
theorem cert_e2411630173818 : check e2411630173818 [[],[]] .chain = true := by decide
def e2411630174006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630174006 : Closed e2411630174006 ∧ code e2411630174006 = 11207723196214 := by decide
theorem cert_e2411630174006 : check e2411630174006 [[],[]] .chain = true := by decide
def e2411630174010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630174010 : Closed e2411630174010 ∧ code e2411630174010 = 11207723196218 := by decide
theorem cert_e2411630174010 : check e2411630174010 [[],[]] .chain = true := by decide
def e2411630177646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e2411630177646 : Closed e2411630177646 ∧ code e2411630177646 = 11207723199854 := by decide
theorem cert_e2411630177646 : checkPay e2411630177646 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630177658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))) (.var 0))))))
theorem wire_e2411630177658 : Closed e2411630177658 ∧ code e2411630177658 = 11207723199866 := by decide
theorem cert_e2411630177658 : check e2411630177658 [[],[]] .chain = true := by decide
def e2411630177710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e2411630177710 : Closed e2411630177710 ∧ code e2411630177710 = 11207723199918 := by decide
theorem cert_e2411630177710 : checkPay e2411630177710 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630177722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e2411630177722 : Closed e2411630177722 ∧ code e2411630177722 = 11207723199930 := by decide
theorem cert_e2411630177722 : check e2411630177722 [[],[]] .smaller = true := by decide
def e2411630177754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e2411630177754 : Closed e2411630177754 ∧ code e2411630177754 = 11207723199962 := by decide
theorem cert_e2411630177754 : check e2411630177754 [[],[]] .smaller = true := by decide
def e2411630177770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))) (.var 0))))))
theorem wire_e2411630177770 : Closed e2411630177770 ∧ code e2411630177770 = 11207723199978 := by decide
theorem cert_e2411630177770 : check e2411630177770 [[],[]] .chain = true := by decide
def e2411630177966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e2411630177966 : Closed e2411630177966 ∧ code e2411630177966 = 11207723200174 := by decide
theorem cert_e2411630177966 : checkPay e2411630177966 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.left]] = true := by decide
def e2411630177978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2411630177978 : Closed e2411630177978 ∧ code e2411630177978 = 11207723200186 := by decide
theorem cert_e2411630177978 : check e2411630177978 [[],[]] .smaller = true := by decide
def e2411630178026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2411630178026 : Closed e2411630178026 ∧ code e2411630178026 = 11207723200234 := by decide
theorem cert_e2411630178026 : check e2411630178026 [[],[]] .smaller = true := by decide
def e2411630178138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e2411630178138 : Closed e2411630178138 ∧ code e2411630178138 = 11207723200346 := by decide
theorem cert_e2411630178138 : check e2411630178138 [[],[]] .smaller = true := by decide
def e2411630178154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e2411630178154 : Closed e2411630178154 ∧ code e2411630178154 = 11207723200362 := by decide
theorem cert_e2411630178154 : check e2411630178154 [[],[]] .smaller = true := by decide
def e2411630178218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e2411630178218 : Closed e2411630178218 ∧ code e2411630178218 = 11207723200426 := by decide
theorem cert_e2411630178218 : check e2411630178218 [[],[]] .chain = true := by decide
def e2411630179182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e2411630179182 : Closed e2411630179182 ∧ code e2411630179182 = 11207723201390 := by decide
theorem cert_e2411630179182 : checkPay e2411630179182 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630179194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e2411630179194 : Closed e2411630179194 ∧ code e2411630179194 = 11207723201402 := by decide
theorem cert_e2411630179194 : check e2411630179194 [[],[]] .chain = true := by decide
def e2411630179246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e2411630179246 : Closed e2411630179246 ∧ code e2411630179246 = 11207723201454 := by decide
theorem cert_e2411630179246 : checkPay e2411630179246 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.right]] = true := by decide
def e2411630179258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e2411630179258 : Closed e2411630179258 ∧ code e2411630179258 = 11207723201466 := by decide
theorem cert_e2411630179258 : check e2411630179258 [[],[]] .smaller = true := by decide
def e2411630179290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e2411630179290 : Closed e2411630179290 ∧ code e2411630179290 = 11207723201498 := by decide
theorem cert_e2411630179290 : check e2411630179290 [[],[]] .smaller = true := by decide
def e2411630179306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e2411630179306 : Closed e2411630179306 ∧ code e2411630179306 = 11207723201514 := by decide
theorem cert_e2411630179306 : check e2411630179306 [[],[]] .chain = true := by decide
def e2411630179950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630179950 : Closed e2411630179950 ∧ code e2411630179950 = 11207723202158 := by decide
theorem cert_e2411630179950 : check e2411630179950 [[],[]] .chain = true := by decide
def e2411630179962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630179962 : Closed e2411630179962 ∧ code e2411630179962 = 11207723202170 := by decide
theorem cert_e2411630179962 : check e2411630179962 [[],[]] .chain = true := by decide
def e2411630180250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630180250 : Closed e2411630180250 ∧ code e2411630180250 = 11207723202458 := by decide
theorem cert_e2411630180250 : check e2411630180250 [[],[]] .chain = true := by decide
def e2411630180590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 2))))))
theorem wire_e2411630180590 : Closed e2411630180590 ∧ code e2411630180590 = 11207723202798 := by decide
theorem cert_e2411630180590 : check e2411630180590 [[],[]] .chain = true := by decide
def e2411630180602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 0))))))
theorem wire_e2411630180602 : Closed e2411630180602 ∧ code e2411630180602 = 11207723202810 := by decide
theorem cert_e2411630180602 : check e2411630180602 [[],[]] .chain = true := by decide
def e2411630180782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2411630180782 : Closed e2411630180782 ∧ code e2411630180782 = 11207723202990 := by decide
theorem cert_e2411630180782 : checkPay e2411630180782 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e2411630180794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2411630180794 : Closed e2411630180794 ∧ code e2411630180794 = 11207723203002 := by decide
theorem cert_e2411630180794 : check e2411630180794 [[],[]] .smaller = true := by decide
def e2411630180842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2411630180842 : Closed e2411630180842 ∧ code e2411630180842 = 11207723203050 := by decide
theorem cert_e2411630180842 : check e2411630180842 [[],[]] .smaller = true := by decide
def e2411630180974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630180974 : Closed e2411630180974 ∧ code e2411630180974 = 11207723203182 := by decide
theorem cert_e2411630180974 : check e2411630180974 [[],[]] .chain = true := by decide
def e2411630180986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630180986 : Closed e2411630180986 ∧ code e2411630180986 = 11207723203194 := by decide
theorem cert_e2411630180986 : check e2411630180986 [[],[]] .chain = true := by decide
def e2411630181150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2411630181150 : Closed e2411630181150 ∧ code e2411630181150 = 11207723203358 := by decide
theorem cert_e2411630181150 : check e2411630181150 [[],[]] .chain = true := by decide
def e2411630181318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2411630181318 : Closed e2411630181318 ∧ code e2411630181318 = 11207723203526 := by decide
theorem cert_e2411630181318 : check e2411630181318 [[],[]] .chain = true := by decide
def e2411630181594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2411630181594 : Closed e2411630181594 ∧ code e2411630181594 = 11207723203802 := by decide
theorem cert_e2411630181594 : check e2411630181594 [[],[]] .smaller = true := by decide
def e2411630181610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2411630181610 : Closed e2411630181610 ∧ code e2411630181610 = 11207723203818 := by decide
theorem cert_e2411630181610 : check e2411630181610 [[],[]] .smaller = true := by decide
def e2411630181946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 0))))))
theorem wire_e2411630181946 : Closed e2411630181946 ∧ code e2411630181946 = 11207723204154 := by decide
theorem cert_e2411630181946 : check e2411630181946 [[],[]] .chain = true := by decide
def e2411630181994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2411630181994 : Closed e2411630181994 ∧ code e2411630181994 = 11207723204202 := by decide
theorem cert_e2411630181994 : check e2411630181994 [[],[]] .chain = true := by decide
def e2411630182042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630182042 : Closed e2411630182042 ∧ code e2411630182042 = 11207723204250 := by decide
theorem cert_e2411630182042 : check e2411630182042 [[],[]] .chain = true := by decide
def e2411630182086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2411630182086 : Closed e2411630182086 ∧ code e2411630182086 = 11207723204294 := by decide
theorem cert_e2411630182086 : check e2411630182086 [[],[]] .chain = true := by decide
def e2411630185326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2411630185326 : Closed e2411630185326 ∧ code e2411630185326 = 11207723207534 := by decide
theorem cert_e2411630185326 : check e2411630185326 [[],[]] .chain = true := by decide
def e2411630185334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2411630185334 : Closed e2411630185334 ∧ code e2411630185334 = 11207723207542 := by decide
theorem cert_e2411630185334 : check e2411630185334 [[],[]] .chain = true := by decide
def e2411630185390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2411630185390 : Closed e2411630185390 ∧ code e2411630185390 = 11207723207598 := by decide
theorem cert_e2411630185390 : check e2411630185390 [[],[]] .chain = true := by decide
def e2411630185402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2411630185402 : Closed e2411630185402 ∧ code e2411630185402 = 11207723207610 := by decide
theorem cert_e2411630185402 : check e2411630185402 [[],[]] .chain = true := by decide
def e2411630185430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2411630185430 : Closed e2411630185430 ∧ code e2411630185430 = 11207723207638 := by decide
theorem cert_e2411630185430 : check e2411630185430 [[],[]] .chain = true := by decide
def e2411630185434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2411630185434 : Closed e2411630185434 ∧ code e2411630185434 = 11207723207642 := by decide
theorem cert_e2411630185434 : check e2411630185434 [[],[]] .chain = true := by decide
def e2411630185710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630185710 : Closed e2411630185710 ∧ code e2411630185710 = 11207723207918 := by decide
theorem cert_e2411630185710 : check e2411630185710 [[],[]] .chain = true := by decide
def e2411630185718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630185718 : Closed e2411630185718 ∧ code e2411630185718 = 11207723207926 := by decide
theorem cert_e2411630185718 : check e2411630185718 [[],[]] .chain = true := by decide
def e2411630186094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2411630186094 : Closed e2411630186094 ∧ code e2411630186094 = 11207723208302 := by decide
theorem cert_e2411630186094 : check e2411630186094 [[],[]] .chain = true := by decide
def e2411630186106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2411630186106 : Closed e2411630186106 ∧ code e2411630186106 = 11207723208314 := by decide
theorem cert_e2411630186106 : check e2411630186106 [[],[]] .chain = true := by decide
def e2411630186294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2411630186294 : Closed e2411630186294 ∧ code e2411630186294 = 11207723208502 := by decide
theorem cert_e2411630186294 : check e2411630186294 [[],[]] .chain = true := by decide
def e2411630186298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2411630186298 : Closed e2411630186298 ∧ code e2411630186298 = 11207723208506 := by decide
theorem cert_e2411630186298 : check e2411630186298 [[],[]] .chain = true := by decide
def e2411630191070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2411630191070 : Closed e2411630191070 ∧ code e2411630191070 = 11207723213278 := by decide
theorem cert_e2411630191070 : check e2411630191070 [[],[]] .chain = true := by decide
def e2411630191094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2411630191094 : Closed e2411630191094 ∧ code e2411630191094 = 11207723213302 := by decide
theorem cert_e2411630191094 : check e2411630191094 [[],[]] .chain = true := by decide
def e2411630192046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2411630192046 : Closed e2411630192046 ∧ code e2411630192046 = 11207723214254 := by decide
theorem cert_e2411630192046 : check e2411630192046 [[],[]] .chain = true := by decide
def e2411630192058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2411630192058 : Closed e2411630192058 ∧ code e2411630192058 = 11207723214266 := by decide
theorem cert_e2411630192058 : check e2411630192058 [[],[]] .chain = true := by decide
def e2411630192106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2411630192106 : Closed e2411630192106 ∧ code e2411630192106 = 11207723214314 := by decide
theorem cert_e2411630192106 : check e2411630192106 [[],[]] .chain = true := by decide
def e2411630192238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2411630192238 : Closed e2411630192238 ∧ code e2411630192238 = 11207723214446 := by decide
theorem cert_e2411630192238 : check e2411630192238 [[],[]] .chain = true := by decide
def e2411630192250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2411630192250 : Closed e2411630192250 ∧ code e2411630192250 = 11207723214458 := by decide
theorem cert_e2411630192250 : check e2411630192250 [[],[]] .chain = true := by decide
def e2411630192414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2411630192414 : Closed e2411630192414 ∧ code e2411630192414 = 11207723214622 := by decide
theorem cert_e2411630192414 : check e2411630192414 [[],[]] .chain = true := by decide
def e2411630192526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2411630192526 : Closed e2411630192526 ∧ code e2411630192526 = 11207723214734 := by decide
theorem cert_e2411630192526 : check e2411630192526 [[],[]] .chain = true := by decide
def e2411630192538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2411630192538 : Closed e2411630192538 ∧ code e2411630192538 = 11207723214746 := by decide
theorem cert_e2411630192538 : check e2411630192538 [[],[]] .chain = true := by decide
def e2411630195486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2411630195486 : Closed e2411630195486 ∧ code e2411630195486 = 11207723217694 := by decide
theorem cert_e2411630195486 : check e2411630195486 [[],[]] .chain = true := by decide
def e2411630195654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2411630195654 : Closed e2411630195654 ∧ code e2411630195654 = 11207723217862 := by decide
theorem cert_e2411630195654 : check e2411630195654 [[],[]] .chain = true := by decide
def e2411630196854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2411630196854 : Closed e2411630196854 ∧ code e2411630196854 = 11207723219062 := by decide
theorem cert_e2411630196854 : check e2411630196854 [[],[]] .chain = true := by decide
def e2411630197098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2411630197098 : Closed e2411630197098 ∧ code e2411630197098 = 11207723219306 := by decide
theorem cert_e2411630197098 : check e2411630197098 [[],[]] .chain = true := by decide
def e2411630197134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2411630197134 : Closed e2411630197134 ∧ code e2411630197134 = 11207723219342 := by decide
theorem cert_e2411630197134 : check e2411630197134 [[],[]] .chain = true := by decide
def e2411630197146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2411630197146 : Closed e2411630197146 ∧ code e2411630197146 = 11207723219354 := by decide
theorem cert_e2411630197146 : check e2411630197146 [[],[]] .chain = true := by decide
def e2411630197190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2411630197190 : Closed e2411630197190 ∧ code e2411630197190 = 11207723219398 := by decide
theorem cert_e2411630197190 : check e2411630197190 [[],[]] .chain = true := by decide
def e2411630211438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2411630211438 : Closed e2411630211438 ∧ code e2411630211438 = 11207723233646 := by decide
theorem cert_e2411630211438 : check e2411630211438 [[],[]] .chain = true := by decide
def e2411630211446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2411630211446 : Closed e2411630211446 ∧ code e2411630211446 = 11207723233654 := by decide
theorem cert_e2411630211446 : check e2411630211446 [[],[]] .chain = true := by decide
def e2411630211502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e2411630211502 : Closed e2411630211502 ∧ code e2411630211502 = 11207723233710 := by decide
theorem cert_e2411630211502 : check e2411630211502 [[],[]] .chain = true := by decide
def e2411630211514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e2411630211514 : Closed e2411630211514 ∧ code e2411630211514 = 11207723233722 := by decide
theorem cert_e2411630211514 : check e2411630211514 [[],[]] .chain = true := by decide
def e2411630211562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 0))))))
theorem wire_e2411630211562 : Closed e2411630211562 ∧ code e2411630211562 = 11207723233770 := by decide
theorem cert_e2411630211562 : check e2411630211562 [[],[]] .chain = true := by decide
def e2411630212206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2411630212206 : Closed e2411630212206 ∧ code e2411630212206 = 11207723234414 := by decide
theorem cert_e2411630212206 : check e2411630212206 [[],[]] .chain = true := by decide
def e2411630212218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2411630212218 : Closed e2411630212218 ∧ code e2411630212218 = 11207723234426 := by decide
theorem cert_e2411630212218 : check e2411630212218 [[],[]] .chain = true := by decide
def e2411630212382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2411630212382 : Closed e2411630212382 ∧ code e2411630212382 = 11207723234590 := by decide
theorem cert_e2411630212382 : check e2411630212382 [[],[]] .chain = true := by decide
def e2411630212550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2411630212550 : Closed e2411630212550 ∧ code e2411630212550 = 11207723234758 := by decide
theorem cert_e2411630212550 : check e2411630212550 [[],[]] .chain = true := by decide
def e2411630212654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2411630212654 : Closed e2411630212654 ∧ code e2411630212654 = 11207723234862 := by decide
theorem cert_e2411630212654 : check e2411630212654 [[],[]] .chain = true := by decide
def e2411630212834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2411630212834 : Closed e2411630212834 ∧ code e2411630212834 = 11207723235042 := by decide
theorem cert_e2411630212834 : check e2411630212834 [[],[]] .chain = true := by decide
def e2411630212846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e2411630212846 : Closed e2411630212846 ∧ code e2411630212846 = 11207723235054 := by decide
theorem cert_e2411630212846 : checkPay e2411630212846 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left]] = true := by decide
def e2411630212886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411630212886 : Closed e2411630212886 ∧ code e2411630212886 = 11207723235094 := by decide
theorem cert_e2411630212886 : check e2411630212886 [[],[]] .chain = true := by decide
def e2411630212890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411630212890 : Closed e2411630212890 ∧ code e2411630212890 = 11207723235098 := by decide
theorem cert_e2411630212890 : check e2411630212890 [[],[]] .chain = true := by decide
def e2411630212934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411630212934 : Closed e2411630212934 ∧ code e2411630212934 = 11207723235142 := by decide
theorem cert_e2411630212934 : check e2411630212934 [[],[]] .chain = true := by decide
def e2411630212962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411630212962 : Closed e2411630212962 ∧ code e2411630212962 = 11207723235170 := by decide
theorem cert_e2411630212962 : check e2411630212962 [[],[]] .chain = true := by decide
def e2411630212974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e2411630212974 : Closed e2411630212974 ∧ code e2411630212974 = 11207723235182 := by decide
theorem cert_e2411630212974 : checkPay e2411630212974 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[]] = true := by decide
def e2411630212982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e2411630212982 : Closed e2411630212982 ∧ code e2411630212982 = 11207723235190 := by decide
theorem cert_e2411630212982 : checkPay e2411630212982 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[],[.under,.left],[.under]] = true := by decide
def e2411630213294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2411630213294 : Closed e2411630213294 ∧ code e2411630213294 = 11207723235502 := by decide
theorem cert_e2411630213294 : check e2411630213294 [[],[]] .chain = true := by decide
def e2411630213306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2411630213306 : Closed e2411630213306 ∧ code e2411630213306 = 11207723235514 := by decide
theorem cert_e2411630213306 : check e2411630213306 [[],[]] .chain = true := by decide
def e2411630213678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2411630213678 : Closed e2411630213678 ∧ code e2411630213678 = 11207723235886 := by decide
theorem cert_e2411630213678 : check e2411630213678 [[],[]] .chain = true := by decide
def e2411630213858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2411630213858 : Closed e2411630213858 ∧ code e2411630213858 = 11207723236066 := by decide
theorem cert_e2411630213858 : check e2411630213858 [[],[]] .chain = true := by decide
def e2411630213870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2411630213870 : Closed e2411630213870 ∧ code e2411630213870 = 11207723236078 := by decide
theorem cert_e2411630213870 : checkPay e2411630213870 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630214026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2411630214026 : Closed e2411630214026 ∧ code e2411630214026 = 11207723236234 := by decide
theorem cert_e2411630214026 : check e2411630214026 [[],[]] .chain = true := by decide
def e2411630214050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2411630214050 : Closed e2411630214050 ∧ code e2411630214050 = 11207723236258 := by decide
theorem cert_e2411630214050 : check e2411630214050 [[],[]] .chain = true := by decide
def e2411630214062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2411630214062 : Closed e2411630214062 ∧ code e2411630214062 = 11207723236270 := by decide
theorem cert_e2411630214062 : checkPay e2411630214062 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630214074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2411630214074 : Closed e2411630214074 ∧ code e2411630214074 = 11207723236282 := by decide
theorem cert_e2411630214074 : checkPay e2411630214074 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630214230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2411630214230 : Closed e2411630214230 ∧ code e2411630214230 = 11207723236438 := by decide
theorem cert_e2411630214230 : check e2411630214230 [[],[]] .chain = true := by decide
def e2411630214234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2411630214234 : Closed e2411630214234 ∧ code e2411630214234 = 11207723236442 := by decide
theorem cert_e2411630214234 : check e2411630214234 [[],[]] .chain = true := by decide
def e2411630214250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e2411630214250 : Closed e2411630214250 ∧ code e2411630214250 = 11207723236458 := by decide
theorem cert_e2411630214250 : check e2411630214250 [[],[]] .chain = true := by decide
def e2411630214422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411630214422 : Closed e2411630214422 ∧ code e2411630214422 = 11207723236630 := by decide
theorem cert_e2411630214422 : check e2411630214422 [[],[]] .chain = true := by decide
def e2411630214426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411630214426 : Closed e2411630214426 ∧ code e2411630214426 = 11207723236634 := by decide
theorem cert_e2411630214426 : check e2411630214426 [[],[]] .chain = true := by decide
def e2411630214470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411630214470 : Closed e2411630214470 ∧ code e2411630214470 = 11207723236678 := by decide
theorem cert_e2411630214470 : check e2411630214470 [[],[]] .chain = true := by decide
def e2411630214498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411630214498 : Closed e2411630214498 ∧ code e2411630214498 = 11207723236706 := by decide
theorem cert_e2411630214498 : check e2411630214498 [[],[]] .chain = true := by decide
def e2411630214510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2411630214510 : Closed e2411630214510 ∧ code e2411630214510 = 11207723236718 := by decide
theorem cert_e2411630214510 : checkPay e2411630214510 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[]] = true := by decide
def e2411630214518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2411630214518 : Closed e2411630214518 ∧ code e2411630214518 = 11207723236726 := by decide
theorem cert_e2411630214518 : checkPay e2411630214518 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2411630214538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2411630214538 : Closed e2411630214538 ∧ code e2411630214538 = 11207723236746 := by decide
theorem cert_e2411630214538 : check e2411630214538 [[],[]] .chain = true := by decide
def e2411630214562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2411630214562 : Closed e2411630214562 ∧ code e2411630214562 = 11207723236770 := by decide
theorem cert_e2411630214562 : check e2411630214562 [[],[]] .chain = true := by decide
def e2411630214574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2411630214574 : Closed e2411630214574 ∧ code e2411630214574 = 11207723236782 := by decide
theorem cert_e2411630214574 : checkPay e2411630214574 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.under,.left,.right,.left]] = true := by decide
def e2411630214586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2411630214586 : Closed e2411630214586 ∧ code e2411630214586 = 11207723236794 := by decide
theorem cert_e2411630214586 : checkPay e2411630214586 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2411630214614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2411630214614 : Closed e2411630214614 ∧ code e2411630214614 = 11207723236822 := by decide
theorem cert_e2411630214614 : checkPay e2411630214614 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right]] = true := by decide
def e2411630214618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2411630214618 : Closed e2411630214618 ∧ code e2411630214618 = 11207723236826 := by decide
theorem cert_e2411630214618 : checkPay e2411630214618 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[]] = true := by decide
def e2411630215662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e2411630215662 : Closed e2411630215662 ∧ code e2411630215662 = 11207723237870 := by decide
theorem cert_e2411630215662 : check e2411630215662 [[],[]] .chain = true := by decide
def e2411630215670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e2411630215670 : Closed e2411630215670 ∧ code e2411630215670 = 11207723237878 := by decide
theorem cert_e2411630215670 : check e2411630215670 [[],[]] .chain = true := by decide
def e2411630216046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e2411630216046 : Closed e2411630216046 ∧ code e2411630216046 = 11207723238254 := by decide
theorem cert_e2411630216046 : check e2411630216046 [[],[]] .chain = true := by decide
def e2411630216058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e2411630216058 : Closed e2411630216058 ∧ code e2411630216058 = 11207723238266 := by decide
theorem cert_e2411630216058 : check e2411630216058 [[],[]] .chain = true := by decide
def e2411630216110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e2411630216110 : Closed e2411630216110 ∧ code e2411630216110 = 11207723238318 := by decide
theorem cert_e2411630216110 : check e2411630216110 [[],[]] .chain = true := by decide
def e2411630216170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e2411630216170 : Closed e2411630216170 ∧ code e2411630216170 = 11207723238378 := by decide
theorem cert_e2411630216170 : check e2411630216170 [[],[]] .chain = true := by decide
def e2411630216430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630216430 : Closed e2411630216430 ∧ code e2411630216430 = 11207723238638 := by decide
theorem cert_e2411630216430 : check e2411630216430 [[],[]] .chain = true := by decide
end Blc.Floor43
