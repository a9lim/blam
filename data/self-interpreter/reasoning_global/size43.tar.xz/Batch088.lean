import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e827000058682 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e827000058682 : Closed e827000058682 ∧ code e827000058682 = 9623093080890 := by decide
theorem cert_e827000058682 : check e827000058682 [] .sourceHead = true := by decide
def e827000058778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000058778 : Closed e827000058778 ∧ code e827000058778 = 9623093080986 := by decide
theorem cert_e827000058778 : check e827000058778 [] .sourceHead = true := by decide
def e827000063854 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e827000063854 : Closed e827000063854 ∧ code e827000063854 = 9623093086062 := by decide
theorem cert_e827000063854 : check e827000063854 [] .sourceHead = true := by decide
def e827000063866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e827000063866 : Closed e827000063866 ∧ code e827000063866 = 9623093086074 := by decide
theorem cert_e827000063866 : check e827000063866 [] .sourceHead = true := by decide
def e827000063962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e827000063962 : Closed e827000063962 ∧ code e827000063962 = 9623093086170 := by decide
theorem cert_e827000063962 : check e827000063962 [] .sourceHead = true := by decide
def e827000067758 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e827000067758 : Closed e827000067758 ∧ code e827000067758 = 9623093089966 := by decide
theorem cert_e827000067758 : check e827000067758 [] .sourceHead = true := by decide
def e827000067770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e827000067770 : Closed e827000067770 ∧ code e827000067770 = 9623093089978 := by decide
theorem cert_e827000067770 : check e827000067770 [] .sourceHead = true := by decide
def e827000067818 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e827000067818 : Closed e827000067818 ∧ code e827000067818 = 9623093090026 := by decide
theorem cert_e827000067818 : check e827000067818 [] .sourceHead = true := by decide
def e827000068010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e827000068010 : Closed e827000068010 ∧ code e827000068010 = 9623093090218 := by decide
theorem cert_e827000068010 : check e827000068010 [] .sourceHead = true := by decide
def e827000068526 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e827000068526 : Closed e827000068526 ∧ code e827000068526 = 9623093090734 := by decide
theorem cert_e827000068526 : check e827000068526 [] .sourceHead = true := by decide
def e827000068538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e827000068538 : Closed e827000068538 ∧ code e827000068538 = 9623093090746 := by decide
theorem cert_e827000068538 : check e827000068538 [] .sourceHead = true := by decide
def e827000068586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e827000068586 : Closed e827000068586 ∧ code e827000068586 = 9623093090794 := by decide
theorem cert_e827000068586 : check e827000068586 [] .sourceHead = true := by decide
def e827000068718 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e827000068718 : Closed e827000068718 ∧ code e827000068718 = 9623093090926 := by decide
theorem cert_e827000068718 : check e827000068718 [] .sourceHead = true := by decide
def e827000068730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e827000068730 : Closed e827000068730 ∧ code e827000068730 = 9623093090938 := by decide
theorem cert_e827000068730 : check e827000068730 [] .sourceHead = true := by decide
def e827000069018 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000069018 : Closed e827000069018 ∧ code e827000069018 = 9623093091226 := by decide
theorem cert_e827000069018 : check e827000069018 [] .sourceHead = true := by decide
def e827000069738 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e827000069738 : Closed e827000069738 ∧ code e827000069738 = 9623093091946 := by decide
theorem cert_e827000069738 : check e827000069738 [] .sourceHead = true := by decide
def e827000069786 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000069786 : Closed e827000069786 ∧ code e827000069786 = 9623093091994 := by decide
theorem cert_e827000069786 : check e827000069786 [] .sourceHead = true := by decide
def e827000070622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e827000070622 : Closed e827000070622 ∧ code e827000070622 = 9623093092830 := by decide
theorem cert_e827000070622 : check e827000070622 [] .sourceHead = true := by decide
def e827000070646 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e827000070646 : Closed e827000070646 ∧ code e827000070646 = 9623093092854 := by decide
theorem cert_e827000070646 : check e827000070646 [] .sourceHead = true := by decide
def e827000071598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e827000071598 : Closed e827000071598 ∧ code e827000071598 = 9623093093806 := by decide
theorem cert_e827000071598 : check e827000071598 [] .sourceHead = true := by decide
def e827000071610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e827000071610 : Closed e827000071610 ∧ code e827000071610 = 9623093093818 := by decide
theorem cert_e827000071610 : check e827000071610 [] .sourceHead = true := by decide
def e827000071658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e827000071658 : Closed e827000071658 ∧ code e827000071658 = 9623093093866 := by decide
theorem cert_e827000071658 : check e827000071658 [] .sourceHead = true := by decide
def e827000071790 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e827000071790 : Closed e827000071790 ∧ code e827000071790 = 9623093093998 := by decide
theorem cert_e827000071790 : check e827000071790 [] .sourceHead = true := by decide
def e827000071802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e827000071802 : Closed e827000071802 ∧ code e827000071802 = 9623093094010 := by decide
theorem cert_e827000071802 : check e827000071802 [] .sourceHead = true := by decide
def e827000072090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000072090 : Closed e827000072090 ∧ code e827000072090 = 9623093094298 := by decide
theorem cert_e827000072090 : check e827000072090 [] .sourceHead = true := by decide
def e827000076406 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e827000076406 : Closed e827000076406 ∧ code e827000076406 = 9623093098614 := by decide
theorem cert_e827000076406 : check e827000076406 [] .sourceHead = true := by decide
def e827000076650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e827000076650 : Closed e827000076650 ∧ code e827000076650 = 9623093098858 := by decide
theorem cert_e827000076650 : check e827000076650 [] .sourceHead = true := by decide
def e827000076698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000076698 : Closed e827000076698 ∧ code e827000076698 = 9623093098906 := by decide
theorem cert_e827000076698 : check e827000076698 [] .sourceHead = true := by decide
def e827000079286 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e827000079286 : Closed e827000079286 ∧ code e827000079286 = 9623093101494 := by decide
theorem cert_e827000079286 : check e827000079286 [] .sourceHead = true := by decide
def e827000079290 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e827000079290 : Closed e827000079290 ∧ code e827000079290 = 9623093101498 := by decide
theorem cert_e827000079290 : check e827000079290 [] .sourceHead = true := by decide
def e827000079322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e827000079322 : Closed e827000079322 ∧ code e827000079322 = 9623093101530 := by decide
theorem cert_e827000079322 : check e827000079322 [] .sourceHead = true := by decide
def e827000081238 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e827000081238 : Closed e827000081238 ∧ code e827000081238 = 9623093103446 := by decide
theorem cert_e827000081238 : check e827000081238 [] .sourceHead = true := by decide
def e827000081242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e827000081242 : Closed e827000081242 ∧ code e827000081242 = 9623093103450 := by decide
theorem cert_e827000081242 : check e827000081242 [] .sourceHead = true := by decide
def e827000081258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e827000081258 : Closed e827000081258 ∧ code e827000081258 = 9623093103466 := by decide
theorem cert_e827000081258 : check e827000081258 [] .sourceHead = true := by decide
def e827000081322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e827000081322 : Closed e827000081322 ∧ code e827000081322 = 9623093103530 := by decide
theorem cert_e827000081322 : check e827000081322 [] .sourceHead = true := by decide
def e827000081622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e827000081622 : Closed e827000081622 ∧ code e827000081622 = 9623093103830 := by decide
theorem cert_e827000081622 : check e827000081622 [] .sourceHead = true := by decide
def e827000081626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e827000081626 : Closed e827000081626 ∧ code e827000081626 = 9623093103834 := by decide
theorem cert_e827000081626 : check e827000081626 [] .sourceHead = true := by decide
def e827000081642 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e827000081642 : Closed e827000081642 ∧ code e827000081642 = 9623093103850 := by decide
theorem cert_e827000081642 : check e827000081642 [] .sourceHead = true := by decide
def e827000081718 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e827000081718 : Closed e827000081718 ∧ code e827000081718 = 9623093103926 := by decide
theorem cert_e827000081718 : check e827000081718 [] .sourceHead = true := by decide
def e827000081722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e827000081722 : Closed e827000081722 ∧ code e827000081722 = 9623093103930 := by decide
theorem cert_e827000081722 : check e827000081722 [] .sourceHead = true := by decide
def e827000081818 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000081818 : Closed e827000081818 ∧ code e827000081818 = 9623093104026 := by decide
theorem cert_e827000081818 : check e827000081818 [] .sourceHead = true := by decide
def e827000082026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e827000082026 : Closed e827000082026 ∧ code e827000082026 = 9623093104234 := by decide
theorem cert_e827000082026 : check e827000082026 [] .sourceHead = true := by decide
def e827000082074 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e827000082074 : Closed e827000082074 ∧ code e827000082074 = 9623093104282 := by decide
theorem cert_e827000082074 : check e827000082074 [] .sourceHead = true := by decide
def e827000082670 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e827000082670 : Closed e827000082670 ∧ code e827000082670 = 9623093104878 := by decide
theorem cert_e827000082670 : check e827000082670 [] .sourceHead = true := by decide
def e827000082678 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e827000082678 : Closed e827000082678 ∧ code e827000082678 = 9623093104886 := by decide
theorem cert_e827000082678 : check e827000082678 [] .sourceHead = true := by decide
def e827000083158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e827000083158 : Closed e827000083158 ∧ code e827000083158 = 9623093105366 := by decide
theorem cert_e827000083158 : check e827000083158 [] .sourceHead = true := by decide
def e827000083162 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e827000083162 : Closed e827000083162 ∧ code e827000083162 = 9623093105370 := by decide
theorem cert_e827000083162 : check e827000083162 [] .sourceHead = true := by decide
def e827000083178 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e827000083178 : Closed e827000083178 ∧ code e827000083178 = 9623093105386 := by decide
theorem cert_e827000083178 : check e827000083178 [] .sourceHead = true := by decide
def e827000083254 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e827000083254 : Closed e827000083254 ∧ code e827000083254 = 9623093105462 := by decide
theorem cert_e827000083254 : check e827000083254 [] .sourceHead = true := by decide
def e827000083258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e827000083258 : Closed e827000083258 ∧ code e827000083258 = 9623093105466 := by decide
theorem cert_e827000083258 : check e827000083258 [] .sourceHead = true := by decide
def e827000083354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000083354 : Closed e827000083354 ∧ code e827000083354 = 9623093105562 := by decide
theorem cert_e827000083354 : check e827000083354 [] .sourceHead = true := by decide
def e827000084598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e827000084598 : Closed e827000084598 ∧ code e827000084598 = 9623093106806 := by decide
theorem cert_e827000084598 : check e827000084598 [] .sourceHead = true := by decide
def e827000084842 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e827000084842 : Closed e827000084842 ∧ code e827000084842 = 9623093107050 := by decide
theorem cert_e827000084842 : check e827000084842 [] .sourceHead = true := by decide
def e827000084890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000084890 : Closed e827000084890 ∧ code e827000084890 = 9623093107098 := by decide
theorem cert_e827000084890 : check e827000084890 [] .sourceHead = true := by decide
def e827000097646 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e827000097646 : Closed e827000097646 ∧ code e827000097646 = 9623093119854 := by decide
theorem cert_e827000097646 : check e827000097646 [] .sourceHead = true := by decide
def e827000097654 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e827000097654 : Closed e827000097654 ∧ code e827000097654 = 9623093119862 := by decide
theorem cert_e827000097654 : check e827000097654 [] .sourceHead = true := by decide
def e827000097710 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e827000097710 : Closed e827000097710 ∧ code e827000097710 = 9623093119918 := by decide
theorem cert_e827000097710 : check e827000097710 [] .sourceHead = true := by decide
def e827000097722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e827000097722 : Closed e827000097722 ∧ code e827000097722 = 9623093119930 := by decide
theorem cert_e827000097722 : check e827000097722 [] .sourceHead = true := by decide
def e827000097750 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e827000097750 : Closed e827000097750 ∧ code e827000097750 = 9623093119958 := by decide
theorem cert_e827000097750 : check e827000097750 [] .sourceHead = true := by decide
def e827000097754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e827000097754 : Closed e827000097754 ∧ code e827000097754 = 9623093119962 := by decide
theorem cert_e827000097754 : check e827000097754 [] .sourceHead = true := by decide
def e827000098030 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e827000098030 : Closed e827000098030 ∧ code e827000098030 = 9623093120238 := by decide
theorem cert_e827000098030 : check e827000098030 [] .sourceHead = true := by decide
def e827000098038 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e827000098038 : Closed e827000098038 ∧ code e827000098038 = 9623093120246 := by decide
theorem cert_e827000098038 : check e827000098038 [] .sourceHead = true := by decide
def e827000098414 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e827000098414 : Closed e827000098414 ∧ code e827000098414 = 9623093120622 := by decide
theorem cert_e827000098414 : check e827000098414 [] .sourceHead = true := by decide
def e827000098426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e827000098426 : Closed e827000098426 ∧ code e827000098426 = 9623093120634 := by decide
theorem cert_e827000098426 : check e827000098426 [] .sourceHead = true := by decide
def e827000098614 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e827000098614 : Closed e827000098614 ∧ code e827000098614 = 9623093120822 := by decide
theorem cert_e827000098614 : check e827000098614 [] .sourceHead = true := by decide
def e827000098618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e827000098618 : Closed e827000098618 ∧ code e827000098618 = 9623093120826 := by decide
theorem cert_e827000098618 : check e827000098618 [] .sourceHead = true := by decide
def e827000139118 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e827000139118 : Closed e827000139118 ∧ code e827000139118 = 9623093161326 := by decide
theorem cert_e827000139118 : check e827000139118 [] .sourceHead = true := by decide
def e827000139126 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e827000139126 : Closed e827000139126 ∧ code e827000139126 = 9623093161334 := by decide
theorem cert_e827000139126 : check e827000139126 [] .sourceHead = true := by decide
def e827000139182 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e827000139182 : Closed e827000139182 ∧ code e827000139182 = 9623093161390 := by decide
theorem cert_e827000139182 : check e827000139182 [] .sourceHead = true := by decide
def e827000139194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e827000139194 : Closed e827000139194 ∧ code e827000139194 = 9623093161402 := by decide
theorem cert_e827000139194 : check e827000139194 [] .sourceHead = true := by decide
def e827000139222 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e827000139222 : Closed e827000139222 ∧ code e827000139222 = 9623093161430 := by decide
theorem cert_e827000139222 : check e827000139222 [] .sourceHead = true := by decide
def e827000139226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e827000139226 : Closed e827000139226 ∧ code e827000139226 = 9623093161434 := by decide
theorem cert_e827000139226 : check e827000139226 [] .sourceHead = true := by decide
def e827000139438 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e827000139438 : Closed e827000139438 ∧ code e827000139438 = 9623093161646 := by decide
theorem cert_e827000139438 : check e827000139438 [] .sourceHead = true := by decide
def e827000139450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e827000139450 : Closed e827000139450 ∧ code e827000139450 = 9623093161658 := by decide
theorem cert_e827000139450 : check e827000139450 [] .sourceHead = true := by decide
def e827000139498 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e827000139498 : Closed e827000139498 ∧ code e827000139498 = 9623093161706 := by decide
theorem cert_e827000139498 : check e827000139498 [] .sourceHead = true := by decide
def e827000139606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e827000139606 : Closed e827000139606 ∧ code e827000139606 = 9623093161814 := by decide
theorem cert_e827000139606 : check e827000139606 [] .sourceHead = true := by decide
def e827000139610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e827000139610 : Closed e827000139610 ∧ code e827000139610 = 9623093161818 := by decide
theorem cert_e827000139610 : check e827000139610 [] .sourceHead = true := by decide
def e827000139626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e827000139626 : Closed e827000139626 ∧ code e827000139626 = 9623093161834 := by decide
theorem cert_e827000139626 : check e827000139626 [] .sourceHead = true := by decide
def e827000140654 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e827000140654 : Closed e827000140654 ∧ code e827000140654 = 9623093162862 := by decide
theorem cert_e827000140654 : check e827000140654 [] .sourceHead = true := by decide
def e827000140662 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e827000140662 : Closed e827000140662 ∧ code e827000140662 = 9623093162870 := by decide
theorem cert_e827000140662 : check e827000140662 [] .sourceHead = true := by decide
def e827000140718 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e827000140718 : Closed e827000140718 ∧ code e827000140718 = 9623093162926 := by decide
theorem cert_e827000140718 : check e827000140718 [] .sourceHead = true := by decide
def e827000140730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e827000140730 : Closed e827000140730 ∧ code e827000140730 = 9623093162938 := by decide
theorem cert_e827000140730 : check e827000140730 [] .sourceHead = true := by decide
def e827000140758 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e827000140758 : Closed e827000140758 ∧ code e827000140758 = 9623093162966 := by decide
theorem cert_e827000140758 : check e827000140758 [] .sourceHead = true := by decide
def e827000140762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e827000140762 : Closed e827000140762 ∧ code e827000140762 = 9623093162970 := by decide
theorem cert_e827000140762 : check e827000140762 [] .sourceHead = true := by decide
def e827000141038 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e827000141038 : Closed e827000141038 ∧ code e827000141038 = 9623093163246 := by decide
theorem cert_e827000141038 : check e827000141038 [] .sourceHead = true := by decide
def e827000141046 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e827000141046 : Closed e827000141046 ∧ code e827000141046 = 9623093163254 := by decide
theorem cert_e827000141046 : check e827000141046 [] .sourceHead = true := by decide
def e827000141422 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e827000141422 : Closed e827000141422 ∧ code e827000141422 = 9623093163630 := by decide
theorem cert_e827000141422 : check e827000141422 [] .sourceHead = true := by decide
def e827000141434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e827000141434 : Closed e827000141434 ∧ code e827000141434 = 9623093163642 := by decide
theorem cert_e827000141434 : check e827000141434 [] .sourceHead = true := by decide
def e827000141622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e827000141622 : Closed e827000141622 ∧ code e827000141622 = 9623093163830 := by decide
theorem cert_e827000141622 : check e827000141622 [] .sourceHead = true := by decide
def e827000141626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e827000141626 : Closed e827000141626 ∧ code e827000141626 = 9623093163834 := by decide
theorem cert_e827000141626 : check e827000141626 [] .sourceHead = true := by decide
def e827000142254 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e827000142254 : Closed e827000142254 ∧ code e827000142254 = 9623093164462 := by decide
theorem cert_e827000142254 : check e827000142254 [] .sourceHead = true := by decide
def e827000142266 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e827000142266 : Closed e827000142266 ∧ code e827000142266 = 9623093164474 := by decide
theorem cert_e827000142266 : check e827000142266 [] .sourceHead = true := by decide
def e827000142314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e827000142314 : Closed e827000142314 ∧ code e827000142314 = 9623093164522 := by decide
theorem cert_e827000142314 : check e827000142314 [] .sourceHead = true := by decide
def e827000142446 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e827000142446 : Closed e827000142446 ∧ code e827000142446 = 9623093164654 := by decide
theorem cert_e827000142446 : check e827000142446 [] .sourceHead = true := by decide
def e827000142458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e827000142458 : Closed e827000142458 ∧ code e827000142458 = 9623093164666 := by decide
theorem cert_e827000142458 : check e827000142458 [] .sourceHead = true := by decide
def e827000142746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000142746 : Closed e827000142746 ∧ code e827000142746 = 9623093164954 := by decide
theorem cert_e827000142746 : check e827000142746 [] .sourceHead = true := by decide
def e827000143062 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e827000143062 : Closed e827000143062 ∧ code e827000143062 = 9623093165270 := by decide
theorem cert_e827000143062 : check e827000143062 [] .sourceHead = true := by decide
def e827000143066 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e827000143066 : Closed e827000143066 ∧ code e827000143066 = 9623093165274 := by decide
theorem cert_e827000143066 : check e827000143066 [] .sourceHead = true := by decide
def e827000143082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e827000143082 : Closed e827000143082 ∧ code e827000143082 = 9623093165290 := by decide
theorem cert_e827000143082 : check e827000143082 [] .sourceHead = true := by decide
def e827000143158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e827000143158 : Closed e827000143158 ∧ code e827000143158 = 9623093165366 := by decide
theorem cert_e827000143158 : check e827000143158 [] .sourceHead = true := by decide
def e827000143162 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e827000143162 : Closed e827000143162 ∧ code e827000143162 = 9623093165370 := by decide
theorem cert_e827000143162 : check e827000143162 [] .sourceHead = true := by decide
def e827000143258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000143258 : Closed e827000143258 ∧ code e827000143258 = 9623093165466 := by decide
theorem cert_e827000143258 : check e827000143258 [] .sourceHead = true := by decide
def e827000144862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e827000144862 : Closed e827000144862 ∧ code e827000144862 = 9623093167070 := by decide
theorem cert_e827000144862 : check e827000144862 [] .sourceHead = true := by decide
def e827000144878 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e827000144878 : Closed e827000144878 ∧ code e827000144878 = 9623093167086 := by decide
theorem cert_e827000144878 : check e827000144878 [] .sourceHead = true := by decide
def e827000146798 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e827000146798 : Closed e827000146798 ∧ code e827000146798 = 9623093169006 := by decide
theorem cert_e827000146798 : check e827000146798 [] .sourceHead = true := by decide
def e827000146806 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e827000146806 : Closed e827000146806 ∧ code e827000146806 = 9623093169014 := by decide
theorem cert_e827000146806 : check e827000146806 [] .sourceHead = true := by decide
def e827000146862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e827000146862 : Closed e827000146862 ∧ code e827000146862 = 9623093169070 := by decide
theorem cert_e827000146862 : check e827000146862 [] .sourceHead = true := by decide
def e827000146874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e827000146874 : Closed e827000146874 ∧ code e827000146874 = 9623093169082 := by decide
theorem cert_e827000146874 : check e827000146874 [] .sourceHead = true := by decide
def e827000146902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e827000146902 : Closed e827000146902 ∧ code e827000146902 = 9623093169110 := by decide
theorem cert_e827000146902 : check e827000146902 [] .sourceHead = true := by decide
def e827000146906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e827000146906 : Closed e827000146906 ∧ code e827000146906 = 9623093169114 := by decide
theorem cert_e827000146906 : check e827000146906 [] .sourceHead = true := by decide
def e827000147182 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e827000147182 : Closed e827000147182 ∧ code e827000147182 = 9623093169390 := by decide
theorem cert_e827000147182 : check e827000147182 [] .sourceHead = true := by decide
def e827000147190 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e827000147190 : Closed e827000147190 ∧ code e827000147190 = 9623093169398 := by decide
theorem cert_e827000147190 : check e827000147190 [] .sourceHead = true := by decide
def e827000147566 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e827000147566 : Closed e827000147566 ∧ code e827000147566 = 9623093169774 := by decide
theorem cert_e827000147566 : check e827000147566 [] .sourceHead = true := by decide
def e827000147578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e827000147578 : Closed e827000147578 ∧ code e827000147578 = 9623093169786 := by decide
theorem cert_e827000147578 : check e827000147578 [] .sourceHead = true := by decide
def e827000147766 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e827000147766 : Closed e827000147766 ∧ code e827000147766 = 9623093169974 := by decide
theorem cert_e827000147766 : check e827000147766 [] .sourceHead = true := by decide
def e827000147770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e827000147770 : Closed e827000147770 ∧ code e827000147770 = 9623093169978 := by decide
theorem cert_e827000147770 : check e827000147770 [] .sourceHead = true := by decide
def e827000152542 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e827000152542 : Closed e827000152542 ∧ code e827000152542 = 9623093174750 := by decide
theorem cert_e827000152542 : check e827000152542 [] .sourceHead = true := by decide
def e827000152566 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e827000152566 : Closed e827000152566 ∧ code e827000152566 = 9623093174774 := by decide
theorem cert_e827000152566 : check e827000152566 [] .sourceHead = true := by decide
def e827000153518 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e827000153518 : Closed e827000153518 ∧ code e827000153518 = 9623093175726 := by decide
theorem cert_e827000153518 : check e827000153518 [] .sourceHead = true := by decide
def e827000153530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e827000153530 : Closed e827000153530 ∧ code e827000153530 = 9623093175738 := by decide
theorem cert_e827000153530 : check e827000153530 [] .sourceHead = true := by decide
def e827000153578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e827000153578 : Closed e827000153578 ∧ code e827000153578 = 9623093175786 := by decide
theorem cert_e827000153578 : check e827000153578 [] .sourceHead = true := by decide
def e827000153710 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e827000153710 : Closed e827000153710 ∧ code e827000153710 = 9623093175918 := by decide
theorem cert_e827000153710 : check e827000153710 [] .sourceHead = true := by decide
def e827000153722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e827000153722 : Closed e827000153722 ∧ code e827000153722 = 9623093175930 := by decide
theorem cert_e827000153722 : check e827000153722 [] .sourceHead = true := by decide
def e827000154010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e827000154010 : Closed e827000154010 ∧ code e827000154010 = 9623093176218 := by decide
theorem cert_e827000154010 : check e827000154010 [] .sourceHead = true := by decide
def e827000156398 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e827000156398 : Closed e827000156398 ∧ code e827000156398 = 9623093178606 := by decide
theorem cert_e827000156398 : check e827000156398 [] .sourceHead = true := by decide
def e827000156406 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e827000156406 : Closed e827000156406 ∧ code e827000156406 = 9623093178614 := by decide
theorem cert_e827000156406 : check e827000156406 [] .sourceHead = true := by decide
def e827000156886 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e827000156886 : Closed e827000156886 ∧ code e827000156886 = 9623093179094 := by decide
theorem cert_e827000156886 : check e827000156886 [] .sourceHead = true := by decide
def e827000156890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e827000156890 : Closed e827000156890 ∧ code e827000156890 = 9623093179098 := by decide
theorem cert_e827000156890 : check e827000156890 [] .sourceHead = true := by decide
def e827000156906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e827000156906 : Closed e827000156906 ∧ code e827000156906 = 9623093179114 := by decide
theorem cert_e827000156906 : check e827000156906 [] .sourceHead = true := by decide
def e827000156982 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e827000156982 : Closed e827000156982 ∧ code e827000156982 = 9623093179190 := by decide
theorem cert_e827000156982 : check e827000156982 [] .sourceHead = true := by decide
def e827000156986 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e827000156986 : Closed e827000156986 ∧ code e827000156986 = 9623093179194 := by decide
theorem cert_e827000156986 : check e827000156986 [] .sourceHead = true := by decide
def e827000157082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e827000157082 : Closed e827000157082 ∧ code e827000157082 = 9623093179290 := by decide
theorem cert_e827000157082 : check e827000157082 [] .sourceHead = true := by decide
def e827000247982 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e827000247982 : Closed e827000247982 ∧ code e827000247982 = 9623093270190 := by decide
theorem cert_e827000247982 : check e827000247982 [] .sourceHead = true := by decide
def e827000247994 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e827000247994 : Closed e827000247994 ∧ code e827000247994 = 9623093270202 := by decide
theorem cert_e827000247994 : check e827000247994 [] .sourceHead = true := by decide
def e827000248042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e827000248042 : Closed e827000248042 ∧ code e827000248042 = 9623093270250 := by decide
theorem cert_e827000248042 : check e827000248042 [] .sourceHead = true := by decide
def e827000248234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e827000248234 : Closed e827000248234 ∧ code e827000248234 = 9623093270442 := by decide
theorem cert_e827000248234 : check e827000248234 [] .sourceHead = true := by decide
def e827000248750 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e827000248750 : Closed e827000248750 ∧ code e827000248750 = 9623093270958 := by decide
theorem cert_e827000248750 : check e827000248750 [] .sourceHead = true := by decide
def e827000248762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e827000248762 : Closed e827000248762 ∧ code e827000248762 = 9623093270970 := by decide
theorem cert_e827000248762 : check e827000248762 [] .sourceHead = true := by decide
def e827000248810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e827000248810 : Closed e827000248810 ∧ code e827000248810 = 9623093271018 := by decide
theorem cert_e827000248810 : check e827000248810 [] .sourceHead = true := by decide
def e827000248942 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e827000248942 : Closed e827000248942 ∧ code e827000248942 = 9623093271150 := by decide
theorem cert_e827000248942 : check e827000248942 [] .sourceHead = true := by decide
def e827000248954 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e827000248954 : Closed e827000248954 ∧ code e827000248954 = 9623093271162 := by decide
theorem cert_e827000248954 : check e827000248954 [] .sourceHead = true := by decide
def e827000249242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000249242 : Closed e827000249242 ∧ code e827000249242 = 9623093271450 := by decide
theorem cert_e827000249242 : check e827000249242 [] .sourceHead = true := by decide
def e827000249962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e827000249962 : Closed e827000249962 ∧ code e827000249962 = 9623093272170 := by decide
theorem cert_e827000249962 : check e827000249962 [] .sourceHead = true := by decide
def e827000250010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000250010 : Closed e827000250010 ∧ code e827000250010 = 9623093272218 := by decide
theorem cert_e827000250010 : check e827000250010 [] .sourceHead = true := by decide
def e827000250846 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e827000250846 : Closed e827000250846 ∧ code e827000250846 = 9623093273054 := by decide
theorem cert_e827000250846 : check e827000250846 [] .sourceHead = true := by decide
def e827000250870 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e827000250870 : Closed e827000250870 ∧ code e827000250870 = 9623093273078 := by decide
theorem cert_e827000250870 : check e827000250870 [] .sourceHead = true := by decide
def e827000251822 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e827000251822 : Closed e827000251822 ∧ code e827000251822 = 9623093274030 := by decide
theorem cert_e827000251822 : check e827000251822 [] .sourceHead = true := by decide
def e827000251834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e827000251834 : Closed e827000251834 ∧ code e827000251834 = 9623093274042 := by decide
theorem cert_e827000251834 : check e827000251834 [] .sourceHead = true := by decide
def e827000251882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e827000251882 : Closed e827000251882 ∧ code e827000251882 = 9623093274090 := by decide
theorem cert_e827000251882 : check e827000251882 [] .sourceHead = true := by decide
def e827000252014 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e827000252014 : Closed e827000252014 ∧ code e827000252014 = 9623093274222 := by decide
theorem cert_e827000252014 : check e827000252014 [] .sourceHead = true := by decide
def e827000252026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e827000252026 : Closed e827000252026 ∧ code e827000252026 = 9623093274234 := by decide
theorem cert_e827000252026 : check e827000252026 [] .sourceHead = true := by decide
def e827000252314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e827000252314 : Closed e827000252314 ∧ code e827000252314 = 9623093274522 := by decide
theorem cert_e827000252314 : check e827000252314 [] .sourceHead = true := by decide
def e827000256630 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e827000256630 : Closed e827000256630 ∧ code e827000256630 = 9623093278838 := by decide
theorem cert_e827000256630 : check e827000256630 [] .sourceHead = true := by decide
def e827000256874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e827000256874 : Closed e827000256874 ∧ code e827000256874 = 9623093279082 := by decide
theorem cert_e827000256874 : check e827000256874 [] .sourceHead = true := by decide
def e827000256922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e827000256922 : Closed e827000256922 ∧ code e827000256922 = 9623093279130 := by decide
theorem cert_e827000256922 : check e827000256922 [] .sourceHead = true := by decide
def e827000302422 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e827000302422 : Closed e827000302422 ∧ code e827000302422 = 9623093324630 := by decide
theorem cert_e827000302422 : check e827000302422 [] .sourceHead = true := by decide
def e827000302426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e827000302426 : Closed e827000302426 ∧ code e827000302426 = 9623093324634 := by decide
theorem cert_e827000302426 : check e827000302426 [] .sourceHead = true := by decide
def e827000302442 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e827000302442 : Closed e827000302442 ∧ code e827000302442 = 9623093324650 := by decide
theorem cert_e827000302442 : check e827000302442 [] .sourceHead = true := by decide
def e827000302506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e827000302506 : Closed e827000302506 ∧ code e827000302506 = 9623093324714 := by decide
theorem cert_e827000302506 : check e827000302506 [] .sourceHead = true := by decide
def e827000302806 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e827000302806 : Closed e827000302806 ∧ code e827000302806 = 9623093325014 := by decide
theorem cert_e827000302806 : check e827000302806 [] .sourceHead = true := by decide
end Blc.Floor43
