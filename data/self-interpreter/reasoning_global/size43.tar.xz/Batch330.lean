import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418167346998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418167346998 : Closed e2418167346998 ∧ code e2418167346998 = 11214260369206 := by decide
theorem cert_e2418167346998 : check e2418167346998 [[],[]] .chain = true := by decide
def e2418167347002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418167347002 : Closed e2418167347002 ∧ code e2418167347002 = 11214260369210 := by decide
theorem cert_e2418167347002 : check e2418167347002 [[],[]] .chain = true := by decide
def e2418167347638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2418167347638 : Closed e2418167347638 ∧ code e2418167347638 = 11214260369846 := by decide
theorem cert_e2418167347638 : check e2418167347638 [[],[]] .chain = true := by decide
def e2418167347670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2418167347670 : Closed e2418167347670 ∧ code e2418167347670 = 11214260369878 := by decide
theorem cert_e2418167347670 : check e2418167347670 [[],[]] .chain = true := by decide
def e2418167347674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2418167347674 : Closed e2418167347674 ∧ code e2418167347674 = 11214260369882 := by decide
theorem cert_e2418167347674 : check e2418167347674 [[],[]] .chain = true := by decide
def e2418167347830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2418167347830 : Closed e2418167347830 ∧ code e2418167347830 = 11214260370038 := by decide
theorem cert_e2418167347830 : check e2418167347830 [[],[]] .chain = true := by decide
def e2418167348022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418167348022 : Closed e2418167348022 ∧ code e2418167348022 = 11214260370230 := by decide
theorem cert_e2418167348022 : check e2418167348022 [[],[]] .chain = true := by decide
def e2418167348026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418167348026 : Closed e2418167348026 ∧ code e2418167348026 = 11214260370234 := by decide
theorem cert_e2418167348026 : check e2418167348026 [[],[]] .chain = true := by decide
def e2418167355246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2418167355246 : Closed e2418167355246 ∧ code e2418167355246 = 11214260377454 := by decide
theorem cert_e2418167355246 : check e2418167355246 [[],[]] .chain = true := by decide
def e2418167355254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2418167355254 : Closed e2418167355254 ∧ code e2418167355254 = 11214260377462 := by decide
theorem cert_e2418167355254 : check e2418167355254 [[],[]] .chain = true := by decide
def e2418167355318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2418167355318 : Closed e2418167355318 ∧ code e2418167355318 = 11214260377526 := by decide
theorem cert_e2418167355318 : check e2418167355318 [[],[]] .chain = true := by decide
def e2418167356654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2418167356654 : Closed e2418167356654 ∧ code e2418167356654 = 11214260378862 := by decide
theorem cert_e2418167356654 : check e2418167356654 [[],[]] .chain = true := by decide
def e2418167356662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2418167356662 : Closed e2418167356662 ∧ code e2418167356662 = 11214260378870 := by decide
theorem cert_e2418167356662 : check e2418167356662 [[],[]] .chain = true := by decide
def e2418167357046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2418167357046 : Closed e2418167357046 ∧ code e2418167357046 = 11214260379254 := by decide
theorem cert_e2418167357046 : check e2418167357046 [[],[]] .chain = true := by decide
def e2418167368558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418167368558 : Closed e2418167368558 ∧ code e2418167368558 = 11214260390766 := by decide
theorem cert_e2418167368558 : check e2418167368558 [[],[]] .chain = true := by decide
def e2418167368566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418167368566 : Closed e2418167368566 ∧ code e2418167368566 = 11214260390774 := by decide
theorem cert_e2418167368566 : check e2418167368566 [[],[]] .chain = true := by decide
def e2418167368622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418167368622 : Closed e2418167368622 ∧ code e2418167368622 = 11214260390830 := by decide
theorem cert_e2418167368622 : check e2418167368622 [[],[]] .chain = true := by decide
def e2418167368634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418167368634 : Closed e2418167368634 ∧ code e2418167368634 = 11214260390842 := by decide
theorem cert_e2418167368634 : check e2418167368634 [[],[]] .chain = true := by decide
def e2418167368662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418167368662 : Closed e2418167368662 ∧ code e2418167368662 = 11214260390870 := by decide
theorem cert_e2418167368662 : check e2418167368662 [[],[]] .chain = true := by decide
def e2418167368666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418167368666 : Closed e2418167368666 ∧ code e2418167368666 = 11214260390874 := by decide
theorem cert_e2418167368666 : check e2418167368666 [[],[]] .chain = true := by decide
def e2418167368942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418167368942 : Closed e2418167368942 ∧ code e2418167368942 = 11214260391150 := by decide
theorem cert_e2418167368942 : check e2418167368942 [[],[]] .chain = true := by decide
def e2418167368950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418167368950 : Closed e2418167368950 ∧ code e2418167368950 = 11214260391158 := by decide
theorem cert_e2418167368950 : check e2418167368950 [[],[]] .chain = true := by decide
def e2418167369326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418167369326 : Closed e2418167369326 ∧ code e2418167369326 = 11214260391534 := by decide
theorem cert_e2418167369326 : check e2418167369326 [[],[]] .chain = true := by decide
def e2418167369338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418167369338 : Closed e2418167369338 ∧ code e2418167369338 = 11214260391546 := by decide
theorem cert_e2418167369338 : check e2418167369338 [[],[]] .chain = true := by decide
def e2418167369526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418167369526 : Closed e2418167369526 ∧ code e2418167369526 = 11214260391734 := by decide
theorem cert_e2418167369526 : check e2418167369526 [[],[]] .chain = true := by decide
def e2418167369530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418167369530 : Closed e2418167369530 ∧ code e2418167369530 = 11214260391738 := by decide
theorem cert_e2418167369530 : check e2418167369530 [[],[]] .chain = true := by decide
def e2418167375286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2418167375286 : Closed e2418167375286 ∧ code e2418167375286 = 11214260397494 := by decide
theorem cert_e2418167375286 : check e2418167375286 [[],[]] .chain = true := by decide
def e2418167375318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2418167375318 : Closed e2418167375318 ∧ code e2418167375318 = 11214260397526 := by decide
theorem cert_e2418167375318 : check e2418167375318 [[],[]] .chain = true := by decide
def e2418167375322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2418167375322 : Closed e2418167375322 ∧ code e2418167375322 = 11214260397530 := by decide
theorem cert_e2418167375322 : check e2418167375322 [[],[]] .chain = true := by decide
def e2418167375478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2418167375478 : Closed e2418167375478 ∧ code e2418167375478 = 11214260397686 := by decide
theorem cert_e2418167375478 : check e2418167375478 [[],[]] .chain = true := by decide
def e2418167375670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2418167375670 : Closed e2418167375670 ∧ code e2418167375670 = 11214260397878 := by decide
theorem cert_e2418167375670 : check e2418167375670 [[],[]] .chain = true := by decide
def e2418167375674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2418167375674 : Closed e2418167375674 ∧ code e2418167375674 = 11214260397882 := by decide
theorem cert_e2418167375674 : check e2418167375674 [[],[]] .chain = true := by decide
def e2418167712622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418167712622 : Closed e2418167712622 ∧ code e2418167712622 = 11214260734830 := by decide
theorem cert_e2418167712622 : check e2418167712622 [[],[],[.under,.left]] .chain = true := by decide
def e2418167712630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418167712630 : Closed e2418167712630 ∧ code e2418167712630 = 11214260734838 := by decide
theorem cert_e2418167712630 : check e2418167712630 [[],[],[.under,.left]] .chain = true := by decide
def e2418167712686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418167712686 : Closed e2418167712686 ∧ code e2418167712686 = 11214260734894 := by decide
theorem cert_e2418167712686 : check e2418167712686 [[],[],[.under,.left]] .chain = true := by decide
def e2418167712698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418167712698 : Closed e2418167712698 ∧ code e2418167712698 = 11214260734906 := by decide
theorem cert_e2418167712698 : check e2418167712698 [[],[],[.under,.left]] .chain = true := by decide
def e2418167712726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418167712726 : Closed e2418167712726 ∧ code e2418167712726 = 11214260734934 := by decide
theorem cert_e2418167712726 : check e2418167712726 [[],[],[.under,.left]] .chain = true := by decide
def e2418167712730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418167712730 : Closed e2418167712730 ∧ code e2418167712730 = 11214260734938 := by decide
theorem cert_e2418167712730 : check e2418167712730 [[],[],[.under,.left]] .chain = true := by decide
def e2418167713006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418167713006 : Closed e2418167713006 ∧ code e2418167713006 = 11214260735214 := by decide
theorem cert_e2418167713006 : check e2418167713006 [[],[],[.under,.left]] .chain = true := by decide
def e2418167713014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418167713014 : Closed e2418167713014 ∧ code e2418167713014 = 11214260735222 := by decide
theorem cert_e2418167713014 : check e2418167713014 [[],[],[.under,.left]] .chain = true := by decide
def e2418167713390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418167713390 : Closed e2418167713390 ∧ code e2418167713390 = 11214260735598 := by decide
theorem cert_e2418167713390 : check e2418167713390 [[],[],[.under,.left]] .chain = true := by decide
def e2418167713402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418167713402 : Closed e2418167713402 ∧ code e2418167713402 = 11214260735610 := by decide
theorem cert_e2418167713402 : check e2418167713402 [[],[],[.under,.left]] .chain = true := by decide
def e2418167713590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418167713590 : Closed e2418167713590 ∧ code e2418167713590 = 11214260735798 := by decide
theorem cert_e2418167713590 : check e2418167713590 [[],[],[.under,.left]] .chain = true := by decide
def e2418167713594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418167713594 : Closed e2418167713594 ∧ code e2418167713594 = 11214260735802 := by decide
theorem cert_e2418167713594 : check e2418167713594 [[],[],[.under,.left]] .chain = true := by decide
def e2418184072558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2418184072558 : Closed e2418184072558 ∧ code e2418184072558 = 11214277094766 := by decide
theorem cert_e2418184072558 : check e2418184072558 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2418184072566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2418184072566 : Closed e2418184072566 ∧ code e2418184072566 = 11214277094774 := by decide
theorem cert_e2418184072566 : checkPay e2418184072566 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418184072622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2418184072622 : Closed e2418184072622 ∧ code e2418184072622 = 11214277094830 := by decide
theorem cert_e2418184072622 : check e2418184072622 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418184072634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2418184072634 : Closed e2418184072634 ∧ code e2418184072634 = 11214277094842 := by decide
theorem cert_e2418184072634 : check e2418184072634 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418184072662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2418184072662 : Closed e2418184072662 ∧ code e2418184072662 = 11214277094870 := by decide
theorem cert_e2418184072662 : check e2418184072662 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418184072666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2418184072666 : Closed e2418184072666 ∧ code e2418184072666 = 11214277094874 := by decide
theorem cert_e2418184072666 : check e2418184072666 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2418184072878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2418184072878 : Closed e2418184072878 ∧ code e2418184072878 = 11214277095086 := by decide
theorem cert_e2418184072878 : check e2418184072878 [[],[]] .sourceHead = true := by decide
def e2418184072890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2418184072890 : Closed e2418184072890 ∧ code e2418184072890 = 11214277095098 := by decide
theorem cert_e2418184072890 : check e2418184072890 [[],[]] .sourceHead = true := by decide
def e2418184072938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2418184072938 : Closed e2418184072938 ∧ code e2418184072938 = 11214277095146 := by decide
theorem cert_e2418184072938 : check e2418184072938 [[],[]] .sourceHead = true := by decide
def e2418184073046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2418184073046 : Closed e2418184073046 ∧ code e2418184073046 = 11214277095254 := by decide
theorem cert_e2418184073046 : check e2418184073046 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418184073050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2418184073050 : Closed e2418184073050 ∧ code e2418184073050 = 11214277095258 := by decide
theorem cert_e2418184073050 : check e2418184073050 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418184073066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2418184073066 : Closed e2418184073066 ∧ code e2418184073066 = 11214277095274 := by decide
theorem cert_e2418184073066 : check e2418184073066 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418184074094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2418184074094 : Closed e2418184074094 ∧ code e2418184074094 = 11214277096302 := by decide
theorem cert_e2418184074094 : check e2418184074094 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418184074102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2418184074102 : Closed e2418184074102 ∧ code e2418184074102 = 11214277096310 := by decide
theorem cert_e2418184074102 : check e2418184074102 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418184074158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2418184074158 : Closed e2418184074158 ∧ code e2418184074158 = 11214277096366 := by decide
theorem cert_e2418184074158 : check e2418184074158 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418184074170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2418184074170 : Closed e2418184074170 ∧ code e2418184074170 = 11214277096378 := by decide
theorem cert_e2418184074170 : check e2418184074170 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418184074198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2418184074198 : Closed e2418184074198 ∧ code e2418184074198 = 11214277096406 := by decide
theorem cert_e2418184074198 : check e2418184074198 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418184074202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2418184074202 : Closed e2418184074202 ∧ code e2418184074202 = 11214277096410 := by decide
theorem cert_e2418184074202 : check e2418184074202 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418184074478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418184074478 : Closed e2418184074478 ∧ code e2418184074478 = 11214277096686 := by decide
theorem cert_e2418184074478 : check e2418184074478 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418184074486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418184074486 : Closed e2418184074486 ∧ code e2418184074486 = 11214277096694 := by decide
theorem cert_e2418184074486 : check e2418184074486 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418184074862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418184074862 : Closed e2418184074862 ∧ code e2418184074862 = 11214277097070 := by decide
theorem cert_e2418184074862 : check e2418184074862 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418184074874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418184074874 : Closed e2418184074874 ∧ code e2418184074874 = 11214277097082 := by decide
theorem cert_e2418184074874 : check e2418184074874 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418184075062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418184075062 : Closed e2418184075062 ∧ code e2418184075062 = 11214277097270 := by decide
theorem cert_e2418184075062 : check e2418184075062 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418184075066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418184075066 : Closed e2418184075066 ∧ code e2418184075066 = 11214277097274 := by decide
theorem cert_e2418184075066 : check e2418184075066 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418184075694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2418184075694 : Closed e2418184075694 ∧ code e2418184075694 = 11214277097902 := by decide
theorem cert_e2418184075694 : checkPay e2418184075694 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2418184075706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2418184075706 : Closed e2418184075706 ∧ code e2418184075706 = 11214277097914 := by decide
theorem cert_e2418184075706 : checkPay e2418184075706 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[]] = true := by decide
def e2418184075754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2418184075754 : Closed e2418184075754 ∧ code e2418184075754 = 11214277097962 := by decide
theorem cert_e2418184075754 : checkPay e2418184075754 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.right]] = true := by decide
def e2418184075886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418184075886 : Closed e2418184075886 ∧ code e2418184075886 = 11214277098094 := by decide
theorem cert_e2418184075886 : checkPay e2418184075886 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418184075898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418184075898 : Closed e2418184075898 ∧ code e2418184075898 = 11214277098106 := by decide
theorem cert_e2418184075898 : checkPay e2418184075898 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418184076186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418184076186 : Closed e2418184076186 ∧ code e2418184076186 = 11214277098394 := by decide
theorem cert_e2418184076186 : checkPay e2418184076186 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2418184076502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2418184076502 : Closed e2418184076502 ∧ code e2418184076502 = 11214277098710 := by decide
theorem cert_e2418184076502 : check e2418184076502 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418184076506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2418184076506 : Closed e2418184076506 ∧ code e2418184076506 = 11214277098714 := by decide
theorem cert_e2418184076506 : check e2418184076506 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418184076522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2418184076522 : Closed e2418184076522 ∧ code e2418184076522 = 11214277098730 := by decide
theorem cert_e2418184076522 : check e2418184076522 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418184076598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418184076598 : Closed e2418184076598 ∧ code e2418184076598 = 11214277098806 := by decide
theorem cert_e2418184076598 : check e2418184076598 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418184076602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418184076602 : Closed e2418184076602 ∧ code e2418184076602 = 11214277098810 := by decide
theorem cert_e2418184076602 : check e2418184076602 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418184076698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418184076698 : Closed e2418184076698 ∧ code e2418184076698 = 11214277098906 := by decide
theorem cert_e2418184076698 : check e2418184076698 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418184080238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418184080238 : Closed e2418184080238 ∧ code e2418184080238 = 11214277102446 := by decide
theorem cert_e2418184080238 : check e2418184080238 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2418184080246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418184080246 : Closed e2418184080246 ∧ code e2418184080246 = 11214277102454 := by decide
theorem cert_e2418184080246 : checkPay e2418184080246 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2418184080302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418184080302 : Closed e2418184080302 ∧ code e2418184080302 = 11214277102510 := by decide
theorem cert_e2418184080302 : check e2418184080302 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418184080314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418184080314 : Closed e2418184080314 ∧ code e2418184080314 = 11214277102522 := by decide
theorem cert_e2418184080314 : check e2418184080314 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418184080342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418184080342 : Closed e2418184080342 ∧ code e2418184080342 = 11214277102550 := by decide
theorem cert_e2418184080342 : check e2418184080342 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2418184080346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418184080346 : Closed e2418184080346 ∧ code e2418184080346 = 11214277102554 := by decide
theorem cert_e2418184080346 : check e2418184080346 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2418184080622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418184080622 : Closed e2418184080622 ∧ code e2418184080622 = 11214277102830 := by decide
theorem cert_e2418184080622 : check e2418184080622 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2418184080630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418184080630 : Closed e2418184080630 ∧ code e2418184080630 = 11214277102838 := by decide
theorem cert_e2418184080630 : check e2418184080630 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2418184081006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418184081006 : Closed e2418184081006 ∧ code e2418184081006 = 11214277103214 := by decide
theorem cert_e2418184081006 : check e2418184081006 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418184081018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418184081018 : Closed e2418184081018 ∧ code e2418184081018 = 11214277103226 := by decide
theorem cert_e2418184081018 : check e2418184081018 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418184081206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418184081206 : Closed e2418184081206 ∧ code e2418184081206 = 11214277103414 := by decide
theorem cert_e2418184081206 : check e2418184081206 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2418184081210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418184081210 : Closed e2418184081210 ∧ code e2418184081210 = 11214277103418 := by decide
theorem cert_e2418184081210 : check e2418184081210 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2418184086958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2418184086958 : Closed e2418184086958 ∧ code e2418184086958 = 11214277109166 := by decide
theorem cert_e2418184086958 : check e2418184086958 [[],[]] .sourceHead = true := by decide
def e2418184086970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2418184086970 : Closed e2418184086970 ∧ code e2418184086970 = 11214277109178 := by decide
theorem cert_e2418184086970 : check e2418184086970 [[],[]] .sourceHead = true := by decide
def e2418184087018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2418184087018 : Closed e2418184087018 ∧ code e2418184087018 = 11214277109226 := by decide
theorem cert_e2418184087018 : check e2418184087018 [[],[]] .sourceHead = true := by decide
def e2418184087150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2418184087150 : Closed e2418184087150 ∧ code e2418184087150 = 11214277109358 := by decide
theorem cert_e2418184087150 : check e2418184087150 [[],[]] .sourceHead = true := by decide
def e2418184087162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2418184087162 : Closed e2418184087162 ∧ code e2418184087162 = 11214277109370 := by decide
theorem cert_e2418184087162 : check e2418184087162 [[],[]] .sourceHead = true := by decide
def e2418184087450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2418184087450 : Closed e2418184087450 ∧ code e2418184087450 = 11214277109658 := by decide
theorem cert_e2418184087450 : check e2418184087450 [[],[]] .sourceHead = true := by decide
def e2418184090326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2418184090326 : Closed e2418184090326 ∧ code e2418184090326 = 11214277112534 := by decide
theorem cert_e2418184090326 : check e2418184090326 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418184090330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2418184090330 : Closed e2418184090330 ∧ code e2418184090330 = 11214277112538 := by decide
theorem cert_e2418184090330 : check e2418184090330 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418184090346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2418184090346 : Closed e2418184090346 ∧ code e2418184090346 = 11214277112554 := by decide
theorem cert_e2418184090346 : check e2418184090346 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418184090422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2418184090422 : Closed e2418184090422 ∧ code e2418184090422 = 11214277112630 := by decide
theorem cert_e2418184090422 : check e2418184090422 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418184090426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2418184090426 : Closed e2418184090426 ∧ code e2418184090426 = 11214277112634 := by decide
theorem cert_e2418184090426 : check e2418184090426 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418184090522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2418184090522 : Closed e2418184090522 ∧ code e2418184090522 = 11214277112730 := by decide
theorem cert_e2418184090522 : check e2418184090522 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418184227694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418184227694 : Closed e2418184227694 ∧ code e2418184227694 = 11214277249902 := by decide
theorem cert_e2418184227694 : check e2418184227694 [[],[]] .sourceHead = true := by decide
def e2418184227702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418184227702 : Closed e2418184227702 ∧ code e2418184227702 = 11214277249910 := by decide
theorem cert_e2418184227702 : check e2418184227702 [[],[]] .sourceHead = true := by decide
def e2418184227758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418184227758 : Closed e2418184227758 ∧ code e2418184227758 = 11214277249966 := by decide
theorem cert_e2418184227758 : check e2418184227758 [[],[]] .sourceHead = true := by decide
def e2418184227770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418184227770 : Closed e2418184227770 ∧ code e2418184227770 = 11214277249978 := by decide
theorem cert_e2418184227770 : check e2418184227770 [[],[]] .sourceHead = true := by decide
def e2418184227798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418184227798 : Closed e2418184227798 ∧ code e2418184227798 = 11214277250006 := by decide
theorem cert_e2418184227798 : check e2418184227798 [[],[]] .sourceHead = true := by decide
def e2418184227802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418184227802 : Closed e2418184227802 ∧ code e2418184227802 = 11214277250010 := by decide
theorem cert_e2418184227802 : check e2418184227802 [[],[]] .sourceHead = true := by decide
def e2418184228078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418184228078 : Closed e2418184228078 ∧ code e2418184228078 = 11214277250286 := by decide
theorem cert_e2418184228078 : check e2418184228078 [[],[]] .sourceHead = true := by decide
def e2418184228086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418184228086 : Closed e2418184228086 ∧ code e2418184228086 = 11214277250294 := by decide
theorem cert_e2418184228086 : check e2418184228086 [[],[]] .sourceHead = true := by decide
def e2418184228462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418184228462 : Closed e2418184228462 ∧ code e2418184228462 = 11214277250670 := by decide
theorem cert_e2418184228462 : check e2418184228462 [[],[]] .sourceHead = true := by decide
def e2418184228474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418184228474 : Closed e2418184228474 ∧ code e2418184228474 = 11214277250682 := by decide
theorem cert_e2418184228474 : check e2418184228474 [[],[]] .sourceHead = true := by decide
def e2418184228662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418184228662 : Closed e2418184228662 ∧ code e2418184228662 = 11214277250870 := by decide
theorem cert_e2418184228662 : check e2418184228662 [[],[]] .sourceHead = true := by decide
def e2418184228666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418184228666 : Closed e2418184228666 ∧ code e2418184228666 = 11214277250874 := by decide
theorem cert_e2418184228666 : check e2418184228666 [[],[]] .sourceHead = true := by decide
def e2418184817518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418184817518 : Closed e2418184817518 ∧ code e2418184817518 = 11214277839726 := by decide
theorem cert_e2418184817518 : check e2418184817518 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184817526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418184817526 : Closed e2418184817526 ∧ code e2418184817526 = 11214277839734 := by decide
theorem cert_e2418184817526 : check e2418184817526 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184817582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418184817582 : Closed e2418184817582 ∧ code e2418184817582 = 11214277839790 := by decide
theorem cert_e2418184817582 : check e2418184817582 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184817594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418184817594 : Closed e2418184817594 ∧ code e2418184817594 = 11214277839802 := by decide
theorem cert_e2418184817594 : check e2418184817594 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184817622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418184817622 : Closed e2418184817622 ∧ code e2418184817622 = 11214277839830 := by decide
theorem cert_e2418184817622 : check e2418184817622 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184817626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418184817626 : Closed e2418184817626 ∧ code e2418184817626 = 11214277839834 := by decide
theorem cert_e2418184817626 : check e2418184817626 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184817902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418184817902 : Closed e2418184817902 ∧ code e2418184817902 = 11214277840110 := by decide
theorem cert_e2418184817902 : check e2418184817902 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184817910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418184817910 : Closed e2418184817910 ∧ code e2418184817910 = 11214277840118 := by decide
theorem cert_e2418184817910 : check e2418184817910 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184818286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418184818286 : Closed e2418184818286 ∧ code e2418184818286 = 11214277840494 := by decide
theorem cert_e2418184818286 : check e2418184818286 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184818298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418184818298 : Closed e2418184818298 ∧ code e2418184818298 = 11214277840506 := by decide
theorem cert_e2418184818298 : check e2418184818298 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184818486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418184818486 : Closed e2418184818486 ∧ code e2418184818486 = 11214277840694 := by decide
theorem cert_e2418184818486 : check e2418184818486 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418184818490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418184818490 : Closed e2418184818490 ∧ code e2418184818490 = 11214277840698 := by decide
theorem cert_e2418184818490 : check e2418184818490 [[],[],[.left],[.left],[]] .smaller = true := by decide
def e2418268663322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268663322 : Closed e2418268663322 ∧ code e2418268663322 = 11214361685530 := by decide
def e2418268665370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268665370 : Closed e2418268665370 ∧ code e2418268665370 = 11214361687578 := by decide
def e2418268679706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268679706 : Closed e2418268679706 ∧ code e2418268679706 = 11214361701914 := by decide
def e2418268682778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268682778 : Closed e2418268682778 ∧ code e2418268682778 = 11214361704986 := by decide
private def t_e2418268682778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418268682778 : ¬ IsSelfInterpreter e2418268682778 :=
  wSource (t := t_e2418268682778) (replay_sound (ps := []) (t := e2418268682778) (by decide)) (by decide)
def e2418268689946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268689946 : Closed e2418268689946 ∧ code e2418268689946 = 11214361712154 := by decide
def e2418268690970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268690970 : Closed e2418268690970 ∧ code e2418268690970 = 11214361713178 := by decide
private def t_e2418268690970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418268690970 : ¬ IsSelfInterpreter e2418268690970 :=
  wSource (t := t_e2418268690970) (replay_sound (ps := []) (t := e2418268690970) (by decide)) (by decide)
def e2418268761626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268761626 : Closed e2418268761626 ∧ code e2418268761626 = 11214361783834 := by decide
def e2418268763674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268763674 : Closed e2418268763674 ∧ code e2418268763674 = 11214361785882 := by decide
def e2418268859930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268859930 : Closed e2418268859930 ∧ code e2418268859930 = 11214361882138 := by decide
theorem cert_e2418268859930 : check e2418268859930 [[],[],[.left],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2418268863002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268863002 : Closed e2418268863002 ∧ code e2418268863002 = 11214361885210 := by decide
theorem cert_e2418268863002 : checkPay e2418268863002 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left]] 1 [[],[.under,.left],[.under],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.right,.under,.under,.right,.left],[.under,.left,.right],[.under,.left,.right,.under],[.under,.left,.right,.under,.under]] = true := by decide
def e2418268911130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268911130 : Closed e2418268911130 ∧ code e2418268911130 = 11214361933338 := by decide
def e2418268912154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418268912154 : Closed e2418268912154 ∧ code e2418268912154 = 11214361934362 := by decide
def e2418270910490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418270910490 : Closed e2418270910490 ∧ code e2418270910490 = 11214363932698 := by decide
theorem cert_e2418270910490 : check e2418270910490 [[]] .width = true := by decide
def e2418270918682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418270918682 : Closed e2418270918682 ∧ code e2418270918682 = 11214363940890 := by decide
theorem cert_e2418270918682 : check e2418270918682 [[]] .width = true := by decide
def e2418270976026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418270976026 : Closed e2418270976026 ∧ code e2418270976026 = 11214363998234 := by decide
theorem cert_e2418270976026 : check e2418270976026 [[]] .width = true := by decide
def e2418270988314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418270988314 : Closed e2418270988314 ∧ code e2418270988314 = 11214364010522 := by decide
theorem cert_e2418270988314 : check e2418270988314 [[]] .width = true := by decide
def e2418271016986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418271016986 : Closed e2418271016986 ∧ code e2418271016986 = 11214364039194 := by decide
theorem cert_e2418271016986 : check e2418271016986 [[]] .width = true := by decide
def e2418271021082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418271021082 : Closed e2418271021082 ∧ code e2418271021082 = 11214364043290 := by decide
theorem cert_e2418271021082 : check e2418271021082 [[]] .width = true := by decide
def e2418271303706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418271303706 : Closed e2418271303706 ∧ code e2418271303706 = 11214364325914 := by decide
theorem cert_e2418271303706 : check e2418271303706 [[]] .width = true := by decide
def e2418271311898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418271311898 : Closed e2418271311898 ∧ code e2418271311898 = 11214364334106 := by decide
theorem cert_e2418271311898 : check e2418271311898 [[]] .width = true := by decide
def e2418271696922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418271696922 : Closed e2418271696922 ∧ code e2418271696922 = 11214364719130 := by decide
theorem cert_e2418271696922 : check e2418271696922 [[]] .width = true := by decide
def e2418271709210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418271709210 : Closed e2418271709210 ∧ code e2418271709210 = 11214364731418 := by decide
theorem cert_e2418271709210 : check e2418271709210 [[]] .width = true := by decide
def e2418271901722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418271901722 : Closed e2418271901722 ∧ code e2418271901722 = 11214364923930 := by decide
theorem cert_e2418271901722 : check e2418271901722 [[]] .width = true := by decide
def e2418271905818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418271905818 : Closed e2418271905818 ∧ code e2418271905818 = 11214364928026 := by decide
theorem cert_e2418271905818 : check e2418271905818 [[]] .width = true := by decide
def e2418284735854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2418284735854 : Closed e2418284735854 ∧ code e2418284735854 = 11214377758062 := by decide
theorem cert_e2418284735854 : check e2418284735854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2418284735862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2418284735862 : Closed e2418284735862 ∧ code e2418284735862 = 11214377758070 := by decide
theorem cert_e2418284735862 : checkPay e2418284735862 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418284735918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2418284735918 : Closed e2418284735918 ∧ code e2418284735918 = 11214377758126 := by decide
theorem cert_e2418284735918 : check e2418284735918 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418284735930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2418284735930 : Closed e2418284735930 ∧ code e2418284735930 = 11214377758138 := by decide
theorem cert_e2418284735930 : check e2418284735930 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418284735958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2418284735958 : Closed e2418284735958 ∧ code e2418284735958 = 11214377758166 := by decide
theorem cert_e2418284735958 : check e2418284735958 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418284735962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2418284735962 : Closed e2418284735962 ∧ code e2418284735962 = 11214377758170 := by decide
theorem cert_e2418284735962 : check e2418284735962 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418284736174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2418284736174 : Closed e2418284736174 ∧ code e2418284736174 = 11214377758382 := by decide
theorem cert_e2418284736174 : check e2418284736174 [[],[]] .sourceHead = true := by decide
def e2418284736186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2418284736186 : Closed e2418284736186 ∧ code e2418284736186 = 11214377758394 := by decide
theorem cert_e2418284736186 : check e2418284736186 [[],[]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2418268682778
#print axioms Blc.Floor43.cert_e2418268690970
