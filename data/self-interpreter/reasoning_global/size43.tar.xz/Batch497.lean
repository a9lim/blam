import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422408633718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e2422408633718 : Closed e2422408633718 ∧ code e2422408633718 = 11218501655926 := by decide
theorem cert_e2422408633718 : check e2422408633718 [[],[]] .chain = true := by decide
def e2422408633774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e2422408633774 : Closed e2422408633774 ∧ code e2422408633774 = 11218501655982 := by decide
theorem cert_e2422408633774 : check e2422408633774 [[],[]] .chain = true := by decide
def e2422408633786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e2422408633786 : Closed e2422408633786 ∧ code e2422408633786 = 11218501655994 := by decide
theorem cert_e2422408633786 : check e2422408633786 [[],[]] .chain = true := by decide
def e2422408633814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e2422408633814 : Closed e2422408633814 ∧ code e2422408633814 = 11218501656022 := by decide
theorem cert_e2422408633814 : check e2422408633814 [[],[]] .chain = true := by decide
def e2422408633818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e2422408633818 : Closed e2422408633818 ∧ code e2422408633818 = 11218501656026 := by decide
theorem cert_e2422408633818 : check e2422408633818 [[],[]] .chain = true := by decide
def e2422408633898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))) (.var 0))))))
theorem wire_e2422408633898 : Closed e2422408633898 ∧ code e2422408633898 = 11218501656106 := by decide
theorem cert_e2422408633898 : check e2422408633898 [[],[]] .chain = true := by decide
def e2422408633994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408633994 : Closed e2422408633994 ∧ code e2422408633994 = 11218501656202 := by decide
theorem cert_e2422408633994 : check e2422408633994 [[],[]] .chain = true := by decide
def e2422408634018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408634018 : Closed e2422408634018 ∧ code e2422408634018 = 11218501656226 := by decide
theorem cert_e2422408634018 : check e2422408634018 [[],[]] .chain = true := by decide
def e2422408634030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e2422408634030 : Closed e2422408634030 ∧ code e2422408634030 = 11218501656238 := by decide
theorem cert_e2422408634030 : check e2422408634030 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408634038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e2422408634038 : Closed e2422408634038 ∧ code e2422408634038 = 11218501656246 := by decide
theorem cert_e2422408634038 : check e2422408634038 [[],[]] .chain = true := by decide
def e2422408634042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2422408634042 : Closed e2422408634042 ∧ code e2422408634042 = 11218501656250 := by decide
theorem cert_e2422408634042 : check e2422408634042 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408634070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e2422408634070 : Closed e2422408634070 ∧ code e2422408634070 = 11218501656278 := by decide
theorem cert_e2422408634070 : check e2422408634070 [[],[]] .chain = true := by decide
def e2422408634074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1)))) (.var 0))))))
theorem wire_e2422408634074 : Closed e2422408634074 ∧ code e2422408634074 = 11218501656282 := by decide
theorem cert_e2422408634074 : check e2422408634074 [[],[]] .chain = true := by decide
def e2422408634090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2422408634090 : Closed e2422408634090 ∧ code e2422408634090 = 11218501656298 := by decide
theorem cert_e2422408634090 : check e2422408634090 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408634414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.var 2))))))
theorem wire_e2422408634414 : Closed e2422408634414 ∧ code e2422408634414 = 11218501656622 := by decide
theorem cert_e2422408634414 : check e2422408634414 [[],[]] .chain = true := by decide
def e2422408634606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2)))))) (.var 2))))))
theorem wire_e2422408634606 : Closed e2422408634606 ∧ code e2422408634606 = 11218501656814 := by decide
theorem cert_e2422408634606 : check e2422408634606 [[],[]] .chain = true := by decide
def e2422408634618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4)))))) (.var 0))))))
theorem wire_e2422408634618 : Closed e2422408634618 ∧ code e2422408634618 = 11218501656826 := by decide
theorem cert_e2422408634618 : check e2422408634618 [[],[]] .chain = true := by decide
def e2422408634798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e2422408634798 : Closed e2422408634798 ∧ code e2422408634798 = 11218501657006 := by decide
theorem cert_e2422408634798 : check e2422408634798 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408634990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408634990 : Closed e2422408634990 ∧ code e2422408634990 = 11218501657198 := by decide
theorem cert_e2422408634990 : check e2422408634990 [[],[]] .chain = true := by decide
def e2422408635002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408635002 : Closed e2422408635002 ∧ code e2422408635002 = 11218501657210 := by decide
theorem cert_e2422408635002 : check e2422408635002 [[],[]] .chain = true := by decide
def e2422408635166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.var 3)))))))
theorem wire_e2422408635166 : Closed e2422408635166 ∧ code e2422408635166 = 11218501657374 := by decide
theorem cert_e2422408635166 : check e2422408635166 [[],[]] .chain = true := by decide
def e2422408635334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.lam (.var 1)))))))
theorem wire_e2422408635334 : Closed e2422408635334 ∧ code e2422408635334 = 11218501657542 := by decide
theorem cert_e2422408635334 : check e2422408635334 [[],[]] .chain = true := by decide
def e2422408635950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422408635950 : Closed e2422408635950 ∧ code e2422408635950 = 11218501658158 := by decide
theorem cert_e2422408635950 : check e2422408635950 [[],[]] .chain = true := by decide
def e2422408636130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e2422408636130 : Closed e2422408636130 ∧ code e2422408636130 = 11218501658338 := by decide
theorem cert_e2422408636130 : check e2422408636130 [[],[]] .chain = true := by decide
def e2422408636142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e2422408636142 : Closed e2422408636142 ∧ code e2422408636142 = 11218501658350 := by decide
theorem cert_e2422408636142 : check e2422408636142 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408636270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e2422408636270 : Closed e2422408636270 ∧ code e2422408636270 = 11218501658478 := by decide
theorem cert_e2422408636270 : check e2422408636270 [[],[]] .chain = true := by decide
def e2422408636278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e2422408636278 : Closed e2422408636278 ∧ code e2422408636278 = 11218501658486 := by decide
theorem cert_e2422408636278 : check e2422408636278 [[],[]] .chain = true := by decide
def e2422408636298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422408636298 : Closed e2422408636298 ∧ code e2422408636298 = 11218501658506 := by decide
theorem cert_e2422408636298 : check e2422408636298 [[],[]] .chain = true := by decide
def e2422408636322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e2422408636322 : Closed e2422408636322 ∧ code e2422408636322 = 11218501658530 := by decide
theorem cert_e2422408636322 : check e2422408636322 [[],[]] .chain = true := by decide
def e2422408636334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e2422408636334 : Closed e2422408636334 ∧ code e2422408636334 = 11218501658542 := by decide
theorem cert_e2422408636334 : check e2422408636334 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408636342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e2422408636342 : Closed e2422408636342 ∧ code e2422408636342 = 11218501658550 := by decide
theorem cert_e2422408636342 : check e2422408636342 [[],[]] .chain = true := by decide
def e2422408636346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))) (.var 0))))))
theorem wire_e2422408636346 : Closed e2422408636346 ∧ code e2422408636346 = 11218501658554 := by decide
theorem cert_e2422408636346 : check e2422408636346 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408636478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.var 4))))))))
theorem wire_e2422408636478 : Closed e2422408636478 ∧ code e2422408636478 = 11218501658686 := by decide
theorem cert_e2422408636478 : check e2422408636478 [[],[]] .chain = true := by decide
def e2422408636898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422408636898 : Closed e2422408636898 ∧ code e2422408636898 = 11218501659106 := by decide
theorem cert_e2422408636898 : check e2422408636898 [[],[]] .chain = true := by decide
def e2422408636910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422408636910 : Closed e2422408636910 ∧ code e2422408636910 = 11218501659118 := by decide
theorem cert_e2422408636910 : check e2422408636910 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408637678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408637678 : Closed e2422408637678 ∧ code e2422408637678 = 11218501659886 := by decide
theorem cert_e2422408637678 : check e2422408637678 [[],[]] .chain = true := by decide
def e2422408637686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408637686 : Closed e2422408637686 ∧ code e2422408637686 = 11218501659894 := by decide
theorem cert_e2422408637686 : check e2422408637686 [[],[]] .chain = true := by decide
def e2422408637954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408637954 : Closed e2422408637954 ∧ code e2422408637954 = 11218501660162 := by decide
theorem cert_e2422408637954 : check e2422408637954 [[],[]] .chain = true := by decide
def e2422408637966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408637966 : Closed e2422408637966 ∧ code e2422408637966 = 11218501660174 := by decide
theorem cert_e2422408637966 : check e2422408637966 [[],[]] .chain = true := by decide
def e2422408637978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408637978 : Closed e2422408637978 ∧ code e2422408637978 = 11218501660186 := by decide
theorem cert_e2422408637978 : check e2422408637978 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408638050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408638050 : Closed e2422408638050 ∧ code e2422408638050 = 11218501660258 := by decide
theorem cert_e2422408638050 : check e2422408638050 [[],[]] .chain = true := by decide
def e2422408638062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408638062 : Closed e2422408638062 ∧ code e2422408638062 = 11218501660270 := by decide
theorem cert_e2422408638062 : check e2422408638062 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408638070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408638070 : Closed e2422408638070 ∧ code e2422408638070 = 11218501660278 := by decide
theorem cert_e2422408638070 : check e2422408638070 [[],[]] .chain = true := by decide
def e2422408638074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408638074 : Closed e2422408638074 ∧ code e2422408638074 = 11218501660282 := by decide
theorem cert_e2422408638074 : check e2422408638074 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408638574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 1)))))) (.var 2))))))
theorem wire_e2422408638574 : Closed e2422408638574 ∧ code e2422408638574 = 11218501660782 := by decide
theorem cert_e2422408638574 : check e2422408638574 [[],[]] .chain = true := by decide
def e2422408638750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.lam (.var 3)))))))
theorem wire_e2422408638750 : Closed e2422408638750 ∧ code e2422408638750 = 11218501660958 := by decide
theorem cert_e2422408638750 : check e2422408638750 [[],[]] .chain = true := by decide
def e2422408638946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))) (.lam (.var 0)))))))
theorem wire_e2422408638946 : Closed e2422408638946 ∧ code e2422408638946 = 11218501661154 := by decide
theorem cert_e2422408638946 : check e2422408638946 [[],[]] .chain = true := by decide
def e2422408638958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))) (.var 2))))))
theorem wire_e2422408638958 : Closed e2422408638958 ∧ code e2422408638958 = 11218501661166 := by decide
theorem cert_e2422408638958 : check e2422408638958 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408639342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e2422408639342 : Closed e2422408639342 ∧ code e2422408639342 = 11218501661550 := by decide
theorem cert_e2422408639342 : check e2422408639342 [[],[]] .chain = true := by decide
def e2422408639350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e2422408639350 : Closed e2422408639350 ∧ code e2422408639350 = 11218501661558 := by decide
theorem cert_e2422408639350 : check e2422408639350 [[],[]] .chain = true := by decide
def e2422408639406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e2422408639406 : Closed e2422408639406 ∧ code e2422408639406 = 11218501661614 := by decide
theorem cert_e2422408639406 : check e2422408639406 [[],[]] .chain = true := by decide
def e2422408639418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e2422408639418 : Closed e2422408639418 ∧ code e2422408639418 = 11218501661626 := by decide
theorem cert_e2422408639418 : check e2422408639418 [[],[]] .chain = true := by decide
def e2422408639446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e2422408639446 : Closed e2422408639446 ∧ code e2422408639446 = 11218501661654 := by decide
theorem cert_e2422408639446 : check e2422408639446 [[],[]] .chain = true := by decide
def e2422408639450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e2422408639450 : Closed e2422408639450 ∧ code e2422408639450 = 11218501661658 := by decide
theorem cert_e2422408639450 : check e2422408639450 [[],[]] .chain = true := by decide
def e2422408639726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408639726 : Closed e2422408639726 ∧ code e2422408639726 = 11218501661934 := by decide
theorem cert_e2422408639726 : check e2422408639726 [[],[]] .chain = true := by decide
def e2422408639734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408639734 : Closed e2422408639734 ∧ code e2422408639734 = 11218501661942 := by decide
theorem cert_e2422408639734 : check e2422408639734 [[],[]] .chain = true := by decide
def e2422408640110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408640110 : Closed e2422408640110 ∧ code e2422408640110 = 11218501662318 := by decide
theorem cert_e2422408640110 : check e2422408640110 [[],[]] .chain = true := by decide
def e2422408640122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408640122 : Closed e2422408640122 ∧ code e2422408640122 = 11218501662330 := by decide
theorem cert_e2422408640122 : check e2422408640122 [[],[]] .chain = true := by decide
def e2422408640262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.lam (.var 1))))))))
theorem wire_e2422408640262 : Closed e2422408640262 ∧ code e2422408640262 = 11218501662470 := by decide
theorem cert_e2422408640262 : check e2422408640262 [[],[]] .chain = true := by decide
def e2422408640286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2422408640286 : Closed e2422408640286 ∧ code e2422408640286 = 11218501662494 := by decide
theorem cert_e2422408640286 : check e2422408640286 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408640310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408640310 : Closed e2422408640310 ∧ code e2422408640310 = 11218501662518 := by decide
theorem cert_e2422408640310 : check e2422408640310 [[],[]] .chain = true := by decide
def e2422408640314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408640314 : Closed e2422408640314 ∧ code e2422408640314 = 11218501662522 := by decide
theorem cert_e2422408640314 : check e2422408640314 [[],[]] .chain = true := by decide
def e2422408640522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.lam (.var 0))))))) (.var 0))))))
theorem wire_e2422408640522 : Closed e2422408640522 ∧ code e2422408640522 = 11218501662730 := by decide
theorem cert_e2422408640522 : check e2422408640522 [[],[]] .chain = true := by decide
def e2422408640558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422408640558 : Closed e2422408640558 ∧ code e2422408640558 = 11218501662766 := by decide
theorem cert_e2422408640558 : check e2422408640558 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408640566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1)))))) (.var 1))))))
theorem wire_e2422408640566 : Closed e2422408640566 ∧ code e2422408640566 = 11218501662774 := by decide
theorem cert_e2422408640566 : check e2422408640566 [[],[]] .chain = true := by decide
def e2422408640570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2)))))) (.var 0))))))
theorem wire_e2422408640570 : Closed e2422408640570 ∧ code e2422408640570 = 11218501662778 := by decide
theorem cert_e2422408640570 : check e2422408640570 [[],[]] .chain = true := by decide
def e2422408640618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e2422408640618 : Closed e2422408640618 ∧ code e2422408640618 = 11218501662826 := by decide
theorem cert_e2422408640618 : check e2422408640618 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408640654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.lam (.var 2)))))))
theorem wire_e2422408640654 : Closed e2422408640654 ∧ code e2422408640654 = 11218501662862 := by decide
theorem cert_e2422408640654 : check e2422408640654 [[],[]] .chain = true := by decide
def e2422408640666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408640666 : Closed e2422408640666 ∧ code e2422408640666 = 11218501662874 := by decide
theorem cert_e2422408640666 : check e2422408640666 [[],[]] .chain = true := by decide
def e2422408640710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.lam (.var 1)))))))
theorem wire_e2422408640710 : Closed e2422408640710 ∧ code e2422408640710 = 11218501662918 := by decide
theorem cert_e2422408640710 : check e2422408640710 [[],[]] .chain = true := by decide
def e2422408640738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))) (.lam (.var 0)))))))
theorem wire_e2422408640738 : Closed e2422408640738 ∧ code e2422408640738 = 11218501662946 := by decide
theorem cert_e2422408640738 : check e2422408640738 [[],[]] .chain = true := by decide
def e2422408640750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))) (.var 2))))))
theorem wire_e2422408640750 : Closed e2422408640750 ∧ code e2422408640750 = 11218501662958 := by decide
theorem cert_e2422408640750 : check e2422408640750 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408640758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))) (.var 1))))))
theorem wire_e2422408640758 : Closed e2422408640758 ∧ code e2422408640758 = 11218501662966 := by decide
theorem cert_e2422408640758 : check e2422408640758 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408640906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422408640906 : Closed e2422408640906 ∧ code e2422408640906 = 11218501663114 := by decide
theorem cert_e2422408640906 : check e2422408640906 [[],[]] .chain = true := by decide
def e2422408640930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e2422408640930 : Closed e2422408640930 ∧ code e2422408640930 = 11218501663138 := by decide
theorem cert_e2422408640930 : check e2422408640930 [[],[]] .chain = true := by decide
def e2422408640942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2422408640942 : Closed e2422408640942 ∧ code e2422408640942 = 11218501663150 := by decide
theorem cert_e2422408640942 : check e2422408640942 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408640950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e2422408640950 : Closed e2422408640950 ∧ code e2422408640950 = 11218501663158 := by decide
theorem cert_e2422408640950 : check e2422408640950 [[],[]] .chain = true := by decide
def e2422408640954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2422408640954 : Closed e2422408640954 ∧ code e2422408640954 = 11218501663162 := by decide
theorem cert_e2422408640954 : check e2422408640954 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408640982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e2422408640982 : Closed e2422408640982 ∧ code e2422408640982 = 11218501663190 := by decide
theorem cert_e2422408640982 : check e2422408640982 [[],[]] .chain = true := by decide
def e2422408640986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e2422408640986 : Closed e2422408640986 ∧ code e2422408640986 = 11218501663194 := by decide
theorem cert_e2422408640986 : check e2422408640986 [[],[]] .chain = true := by decide
def e2422408641002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2422408641002 : Closed e2422408641002 ∧ code e2422408641002 = 11218501663210 := by decide
theorem cert_e2422408641002 : check e2422408641002 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408641026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408641026 : Closed e2422408641026 ∧ code e2422408641026 = 11218501663234 := by decide
theorem cert_e2422408641026 : check e2422408641026 [[],[]] .chain = true := by decide
def e2422408641038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408641038 : Closed e2422408641038 ∧ code e2422408641038 = 11218501663246 := by decide
theorem cert_e2422408641038 : check e2422408641038 [[],[]] .chain = true := by decide
def e2422408641050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408641050 : Closed e2422408641050 ∧ code e2422408641050 = 11218501663258 := by decide
theorem cert_e2422408641050 : check e2422408641050 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408641122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408641122 : Closed e2422408641122 ∧ code e2422408641122 = 11218501663330 := by decide
theorem cert_e2422408641122 : check e2422408641122 [[],[]] .chain = true := by decide
def e2422408641134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408641134 : Closed e2422408641134 ∧ code e2422408641134 = 11218501663342 := by decide
theorem cert_e2422408641134 : check e2422408641134 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408641142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408641142 : Closed e2422408641142 ∧ code e2422408641142 = 11218501663350 := by decide
theorem cert_e2422408641142 : check e2422408641142 [[],[]] .chain = true := by decide
def e2422408641146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408641146 : Closed e2422408641146 ∧ code e2422408641146 = 11218501663354 := by decide
theorem cert_e2422408641146 : check e2422408641146 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408641286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.lam (.var 1))))))))
theorem wire_e2422408641286 : Closed e2422408641286 ∧ code e2422408641286 = 11218501663494 := by decide
theorem cert_e2422408641286 : check e2422408641286 [[],[]] .chain = true := by decide
def e2422408641310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2422408641310 : Closed e2422408641310 ∧ code e2422408641310 = 11218501663518 := by decide
theorem cert_e2422408641310 : check e2422408641310 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408641334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408641334 : Closed e2422408641334 ∧ code e2422408641334 = 11218501663542 := by decide
theorem cert_e2422408641334 : check e2422408641334 [[],[]] .chain = true := by decide
def e2422408641338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408641338 : Closed e2422408641338 ∧ code e2422408641338 = 11218501663546 := by decide
theorem cert_e2422408641338 : check e2422408641338 [[],[]] .chain = true := by decide
def e2422408641410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e2422408641410 : Closed e2422408641410 ∧ code e2422408641410 = 11218501663618 := by decide
theorem cert_e2422408641410 : check e2422408641410 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408641422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e2422408641422 : Closed e2422408641422 ∧ code e2422408641422 = 11218501663630 := by decide
theorem cert_e2422408641422 : check e2422408641422 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408641434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408641434 : Closed e2422408641434 ∧ code e2422408641434 = 11218501663642 := by decide
theorem cert_e2422408641434 : check e2422408641434 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408643006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422408643006 : Closed e2422408643006 ∧ code e2422408643006 = 11218501665214 := by decide
theorem cert_e2422408643006 : check e2422408643006 [[],[]] .chain = true := by decide
def e2422408643066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422408643066 : Closed e2422408643066 ∧ code e2422408643066 = 11218501665274 := by decide
theorem cert_e2422408643066 : check e2422408643066 [[],[]] .chain = true := by decide
def e2422408644158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422408644158 : Closed e2422408644158 ∧ code e2422408644158 = 11218501666366 := by decide
theorem cert_e2422408644158 : check e2422408644158 [[],[]] .chain = true := by decide
def e2422408644550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422408644550 : Closed e2422408644550 ∧ code e2422408644550 = 11218501666758 := by decide
theorem cert_e2422408644550 : check e2422408644550 [[],[]] .chain = true := by decide
def e2422408644574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2422408644574 : Closed e2422408644574 ∧ code e2422408644574 = 11218501666782 := by decide
theorem cert_e2422408644574 : check e2422408644574 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408648238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422408648238 : Closed e2422408648238 ∧ code e2422408648238 = 11218501670446 := by decide
theorem cert_e2422408648238 : check e2422408648238 [[],[]] .chain = true := by decide
def e2422408648418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422408648418 : Closed e2422408648418 ∧ code e2422408648418 = 11218501670626 := by decide
theorem cert_e2422408648418 : check e2422408648418 [[],[]] .chain = true := by decide
def e2422408648430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2422408648430 : Closed e2422408648430 ∧ code e2422408648430 = 11218501670638 := by decide
theorem cert_e2422408648430 : check e2422408648430 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408648558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2422408648558 : Closed e2422408648558 ∧ code e2422408648558 = 11218501670766 := by decide
theorem cert_e2422408648558 : check e2422408648558 [[],[]] .chain = true := by decide
def e2422408648566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2422408648566 : Closed e2422408648566 ∧ code e2422408648566 = 11218501670774 := by decide
theorem cert_e2422408648566 : check e2422408648566 [[],[]] .chain = true := by decide
def e2422408648586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422408648586 : Closed e2422408648586 ∧ code e2422408648586 = 11218501670794 := by decide
theorem cert_e2422408648586 : check e2422408648586 [[],[]] .chain = true := by decide
def e2422408648610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422408648610 : Closed e2422408648610 ∧ code e2422408648610 = 11218501670818 := by decide
theorem cert_e2422408648610 : check e2422408648610 [[],[]] .chain = true := by decide
def e2422408648622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2422408648622 : Closed e2422408648622 ∧ code e2422408648622 = 11218501670830 := by decide
theorem cert_e2422408648622 : check e2422408648622 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408648630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2422408648630 : Closed e2422408648630 ∧ code e2422408648630 = 11218501670838 := by decide
theorem cert_e2422408648630 : check e2422408648630 [[],[]] .chain = true := by decide
def e2422408648634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2422408648634 : Closed e2422408648634 ∧ code e2422408648634 = 11218501670842 := by decide
theorem cert_e2422408648634 : check e2422408648634 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408648766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2422408648766 : Closed e2422408648766 ∧ code e2422408648766 = 11218501670974 := by decide
theorem cert_e2422408648766 : check e2422408648766 [[],[]] .chain = true := by decide
def e2422408649186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422408649186 : Closed e2422408649186 ∧ code e2422408649186 = 11218501671394 := by decide
theorem cert_e2422408649186 : check e2422408649186 [[],[]] .chain = true := by decide
def e2422408649198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2422408649198 : Closed e2422408649198 ∧ code e2422408649198 = 11218501671406 := by decide
theorem cert_e2422408649198 : check e2422408649198 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408649966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408649966 : Closed e2422408649966 ∧ code e2422408649966 = 11218501672174 := by decide
theorem cert_e2422408649966 : check e2422408649966 [[],[]] .chain = true := by decide
def e2422408649974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408649974 : Closed e2422408649974 ∧ code e2422408649974 = 11218501672182 := by decide
theorem cert_e2422408649974 : check e2422408649974 [[],[]] .chain = true := by decide
def e2422408650242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422408650242 : Closed e2422408650242 ∧ code e2422408650242 = 11218501672450 := by decide
theorem cert_e2422408650242 : check e2422408650242 [[],[]] .chain = true := by decide
def e2422408650254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2422408650254 : Closed e2422408650254 ∧ code e2422408650254 = 11218501672462 := by decide
theorem cert_e2422408650254 : check e2422408650254 [[],[]] .chain = true := by decide
def e2422408650266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408650266 : Closed e2422408650266 ∧ code e2422408650266 = 11218501672474 := by decide
theorem cert_e2422408650266 : check e2422408650266 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408650338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422408650338 : Closed e2422408650338 ∧ code e2422408650338 = 11218501672546 := by decide
theorem cert_e2422408650338 : check e2422408650338 [[],[]] .chain = true := by decide
def e2422408650350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408650350 : Closed e2422408650350 ∧ code e2422408650350 = 11218501672558 := by decide
theorem cert_e2422408650350 : check e2422408650350 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408650358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2422408650358 : Closed e2422408650358 ∧ code e2422408650358 = 11218501672566 := by decide
theorem cert_e2422408650358 : check e2422408650358 [[],[]] .chain = true := by decide
def e2422408650362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408650362 : Closed e2422408650362 ∧ code e2422408650362 = 11218501672570 := by decide
theorem cert_e2422408650362 : check e2422408650362 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408659070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e2422408659070 : Closed e2422408659070 ∧ code e2422408659070 = 11218501681278 := by decide
theorem cert_e2422408659070 : check e2422408659070 [[],[]] .chain = true := by decide
def e2422408659934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422408659934 : Closed e2422408659934 ∧ code e2422408659934 = 11218501682142 := by decide
theorem cert_e2422408659934 : check e2422408659934 [[],[]] .chain = true := by decide
def e2422408659938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422408659938 : Closed e2422408659938 ∧ code e2422408659938 = 11218501682146 := by decide
theorem cert_e2422408659938 : check e2422408659938 [[],[]] .chain = true := by decide
def e2422408659950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422408659950 : Closed e2422408659950 ∧ code e2422408659950 = 11218501682158 := by decide
theorem cert_e2422408659950 : check e2422408659950 [[],[]] .chain = true := by decide
def e2422408661870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422408661870 : Closed e2422408661870 ∧ code e2422408661870 = 11218501684078 := by decide
theorem cert_e2422408661870 : check e2422408661870 [[],[]] .chain = true := by decide
def e2422408661878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422408661878 : Closed e2422408661878 ∧ code e2422408661878 = 11218501684086 := by decide
theorem cert_e2422408661878 : check e2422408661878 [[],[]] .chain = true := by decide
def e2422408661934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422408661934 : Closed e2422408661934 ∧ code e2422408661934 = 11218501684142 := by decide
theorem cert_e2422408661934 : check e2422408661934 [[],[]] .chain = true := by decide
def e2422408661946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422408661946 : Closed e2422408661946 ∧ code e2422408661946 = 11218501684154 := by decide
theorem cert_e2422408661946 : check e2422408661946 [[],[]] .chain = true := by decide
def e2422408661974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422408661974 : Closed e2422408661974 ∧ code e2422408661974 = 11218501684182 := by decide
theorem cert_e2422408661974 : check e2422408661974 [[],[]] .chain = true := by decide
def e2422408661978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422408661978 : Closed e2422408661978 ∧ code e2422408661978 = 11218501684186 := by decide
theorem cert_e2422408661978 : check e2422408661978 [[],[]] .chain = true := by decide
def e2422408662254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408662254 : Closed e2422408662254 ∧ code e2422408662254 = 11218501684462 := by decide
theorem cert_e2422408662254 : check e2422408662254 [[],[]] .chain = true := by decide
def e2422408662262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408662262 : Closed e2422408662262 ∧ code e2422408662262 = 11218501684470 := by decide
theorem cert_e2422408662262 : check e2422408662262 [[],[]] .chain = true := by decide
def e2422408662638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408662638 : Closed e2422408662638 ∧ code e2422408662638 = 11218501684846 := by decide
theorem cert_e2422408662638 : check e2422408662638 [[],[]] .chain = true := by decide
def e2422408662650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408662650 : Closed e2422408662650 ∧ code e2422408662650 = 11218501684858 := by decide
theorem cert_e2422408662650 : check e2422408662650 [[],[]] .chain = true := by decide
def e2422408662790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e2422408662790 : Closed e2422408662790 ∧ code e2422408662790 = 11218501684998 := by decide
theorem cert_e2422408662790 : check e2422408662790 [[],[]] .chain = true := by decide
def e2422408662814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e2422408662814 : Closed e2422408662814 ∧ code e2422408662814 = 11218501685022 := by decide
theorem cert_e2422408662814 : check e2422408662814 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408662838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408662838 : Closed e2422408662838 ∧ code e2422408662838 = 11218501685046 := by decide
theorem cert_e2422408662838 : check e2422408662838 [[],[]] .chain = true := by decide
def e2422408662842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408662842 : Closed e2422408662842 ∧ code e2422408662842 = 11218501685050 := by decide
theorem cert_e2422408662842 : check e2422408662842 [[],[]] .chain = true := by decide
def e2422408667162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422408667162 : Closed e2422408667162 ∧ code e2422408667162 = 11218501689370 := by decide
theorem cert_e2422408667162 : check e2422408667162 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408667198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e2422408667198 : Closed e2422408667198 ∧ code e2422408667198 = 11218501689406 := by decide
theorem cert_e2422408667198 : check e2422408667198 [[],[]] .chain = true := by decide
def e2422408667246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408667246 : Closed e2422408667246 ∧ code e2422408667246 = 11218501689454 := by decide
theorem cert_e2422408667246 : check e2422408667246 [[],[]] .chain = true := by decide
def e2422408667254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422408667254 : Closed e2422408667254 ∧ code e2422408667254 = 11218501689462 := by decide
theorem cert_e2422408667254 : check e2422408667254 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408667258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408667258 : Closed e2422408667258 ∧ code e2422408667258 = 11218501689466 := by decide
theorem cert_e2422408667258 : check e2422408667258 [[],[]] .chain = true := by decide
def e2422408667498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422408667498 : Closed e2422408667498 ∧ code e2422408667498 = 11218501689706 := by decide
theorem cert_e2422408667498 : check e2422408667498 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408667534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422408667534 : Closed e2422408667534 ∧ code e2422408667534 = 11218501689742 := by decide
theorem cert_e2422408667534 : check e2422408667534 [[],[]] .chain = true := by decide
def e2422408667546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408667546 : Closed e2422408667546 ∧ code e2422408667546 = 11218501689754 := by decide
theorem cert_e2422408667546 : check e2422408667546 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408667590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422408667590 : Closed e2422408667590 ∧ code e2422408667590 = 11218501689798 := by decide
theorem cert_e2422408667590 : check e2422408667590 [[],[]] .chain = true := by decide
def e2422408667614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422408667614 : Closed e2422408667614 ∧ code e2422408667614 = 11218501689822 := by decide
theorem cert_e2422408667614 : check e2422408667614 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408667618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422408667618 : Closed e2422408667618 ∧ code e2422408667618 = 11218501689826 := by decide
theorem cert_e2422408667618 : check e2422408667618 [[],[]] .chain = true := by decide
def e2422408667630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e2422408667630 : Closed e2422408667630 ∧ code e2422408667630 = 11218501689838 := by decide
theorem cert_e2422408667630 : check e2422408667630 [[],[]] .chain = true := by decide
def e2422408667638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422408667638 : Closed e2422408667638 ∧ code e2422408667638 = 11218501689846 := by decide
theorem cert_e2422408667638 : check e2422408667638 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408668554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422408668554 : Closed e2422408668554 ∧ code e2422408668554 = 11218501690762 := by decide
theorem cert_e2422408668554 : check e2422408668554 [[],[]] .chain = true := by decide
def e2422408668578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422408668578 : Closed e2422408668578 ∧ code e2422408668578 = 11218501690786 := by decide
theorem cert_e2422408668578 : check e2422408668578 [[],[]] .chain = true := by decide
def e2422408668590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422408668590 : Closed e2422408668590 ∧ code e2422408668590 = 11218501690798 := by decide
theorem cert_e2422408668590 : check e2422408668590 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408668598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2422408668598 : Closed e2422408668598 ∧ code e2422408668598 = 11218501690806 := by decide
theorem cert_e2422408668598 : check e2422408668598 [[],[]] .chain = true := by decide
def e2422408668602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422408668602 : Closed e2422408668602 ∧ code e2422408668602 = 11218501690810 := by decide
theorem cert_e2422408668602 : check e2422408668602 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408668630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2422408668630 : Closed e2422408668630 ∧ code e2422408668630 = 11218501690838 := by decide
theorem cert_e2422408668630 : check e2422408668630 [[],[]] .chain = true := by decide
def e2422408668634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2422408668634 : Closed e2422408668634 ∧ code e2422408668634 = 11218501690842 := by decide
theorem cert_e2422408668634 : check e2422408668634 [[],[]] .chain = true := by decide
end Blc.Floor43
