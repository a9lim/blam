import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422362335094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e2422362335094 : Closed e2422362335094 ∧ code e2422362335094 = 11218455357302 := by decide
theorem cert_e2422362335094 : check e2422362335094 [[],[]] .smaller = true := by decide
def e2422362335098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e2422362335098 : Closed e2422362335098 ∧ code e2422362335098 = 11218455357306 := by decide
theorem cert_e2422362335098 : check e2422362335098 [[],[]] .smaller = true := by decide
def e2422362335150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 2)))))))))
theorem wire_e2422362335150 : Closed e2422362335150 ∧ code e2422362335150 = 11218455357358 := by decide
theorem cert_e2422362335150 : check e2422362335150 [[],[]] .smaller = true := by decide
def e2422362335158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e2422362335158 : Closed e2422362335158 ∧ code e2422362335158 = 11218455357366 := by decide
theorem cert_e2422362335158 : check e2422362335158 [[],[]] .smaller = true := by decide
def e2422362335162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 0)))))))))
theorem wire_e2422362335162 : Closed e2422362335162 ∧ code e2422362335162 = 11218455357370 := by decide
theorem cert_e2422362335162 : check e2422362335162 [[],[]] .smaller = true := by decide
def e2422362335190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e2422362335190 : Closed e2422362335190 ∧ code e2422362335190 = 11218455357398 := by decide
theorem cert_e2422362335190 : check e2422362335190 [[],[]] .smaller = true := by decide
def e2422362335194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e2422362335194 : Closed e2422362335194 ∧ code e2422362335194 = 11218455357402 := by decide
theorem cert_e2422362335194 : check e2422362335194 [[],[]] .smaller = true := by decide
def e2422362335210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 4) (.var 0))) (.var 0)))))))))
theorem wire_e2422362335210 : Closed e2422362335210 ∧ code e2422362335210 = 11218455357418 := by decide
theorem cert_e2422362335210 : check e2422362335210 [[],[]] .smaller = true := by decide
def e2422362335630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422362335630 : Closed e2422362335630 ∧ code e2422362335630 = 11218455357838 := by decide
theorem cert_e2422362335630 : check e2422362335630 [[],[]] .smaller = true := by decide
def e2422362335678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422362335678 : Closed e2422362335678 ∧ code e2422362335678 = 11218455357886 := by decide
theorem cert_e2422362335678 : check e2422362335678 [[],[]] .smaller = true := by decide
def e2422362335686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422362335686 : Closed e2422362335686 ∧ code e2422362335686 = 11218455357894 := by decide
theorem cert_e2422362335686 : check e2422362335686 [[],[]] .smaller = true := by decide
def e2422362335710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422362335710 : Closed e2422362335710 ∧ code e2422362335710 = 11218455357918 := by decide
theorem cert_e2422362335710 : check e2422362335710 [[],[]] .smaller = true := by decide
def e2422362335726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422362335726 : Closed e2422362335726 ∧ code e2422362335726 = 11218455357934 := by decide
theorem cert_e2422362335726 : check e2422362335726 [[],[]] .smaller = true := by decide
def e2422362335734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422362335734 : Closed e2422362335734 ∧ code e2422362335734 = 11218455357942 := by decide
theorem cert_e2422362335734 : check e2422362335734 [[],[]] .smaller = true := by decide
def e2422362335738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422362335738 : Closed e2422362335738 ∧ code e2422362335738 = 11218455357946 := by decide
theorem cert_e2422362335738 : check e2422362335738 [[],[]] .smaller = true := by decide
def e2422362336454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422362336454 : Closed e2422362336454 ∧ code e2422362336454 = 11218455358662 := by decide
theorem cert_e2422362336454 : check e2422362336454 [[],[]] .smaller = true := by decide
def e2422362336478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422362336478 : Closed e2422362336478 ∧ code e2422362336478 = 11218455358686 := by decide
theorem cert_e2422362336478 : check e2422362336478 [[],[]] .smaller = true := by decide
def e2422362336494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422362336494 : Closed e2422362336494 ∧ code e2422362336494 = 11218455358702 := by decide
theorem cert_e2422362336494 : check e2422362336494 [[],[]] .smaller = true := by decide
def e2422362336502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422362336502 : Closed e2422362336502 ∧ code e2422362336502 = 11218455358710 := by decide
theorem cert_e2422362336502 : check e2422362336502 [[],[]] .smaller = true := by decide
def e2422362336506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422362336506 : Closed e2422362336506 ∧ code e2422362336506 = 11218455358714 := by decide
theorem cert_e2422362336506 : check e2422362336506 [[],[]] .smaller = true := by decide
def e2422362336878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362336878 : Closed e2422362336878 ∧ code e2422362336878 = 11218455359086 := by decide
theorem cert_e2422362336878 : check e2422362336878 [[],[]] .smaller = true := by decide
def e2422362336886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422362336886 : Closed e2422362336886 ∧ code e2422362336886 = 11218455359094 := by decide
theorem cert_e2422362336886 : check e2422362336886 [[],[]] .smaller = true := by decide
def e2422362336890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362336890 : Closed e2422362336890 ∧ code e2422362336890 = 11218455359098 := by decide
theorem cert_e2422362336890 : check e2422362336890 [[],[]] .smaller = true := by decide
def e2422362337078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362337078 : Closed e2422362337078 ∧ code e2422362337078 = 11218455359286 := by decide
theorem cert_e2422362337078 : check e2422362337078 [[],[]] .smaller = true := by decide
def e2422362337082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362337082 : Closed e2422362337082 ∧ code e2422362337082 = 11218455359290 := by decide
theorem cert_e2422362337082 : check e2422362337082 [[],[]] .smaller = true := by decide
def e2422362337178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362337178 : Closed e2422362337178 ∧ code e2422362337178 = 11218455359386 := by decide
theorem cert_e2422362337178 : check e2422362337178 [[],[]] .smaller = true := by decide
def e2422362338142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e2422362338142 : Closed e2422362338142 ∧ code e2422362338142 = 11218455360350 := by decide
theorem cert_e2422362338142 : check e2422362338142 [[],[]] .smaller = true := by decide
def e2422362338170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e2422362338170 : Closed e2422362338170 ∧ code e2422362338170 = 11218455360378 := by decide
theorem cert_e2422362338170 : check e2422362338170 [[],[]] .smaller = true := by decide
def e2422362338282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e2422362338282 : Closed e2422362338282 ∧ code e2422362338282 = 11218455360490 := by decide
theorem cert_e2422362338282 : check e2422362338282 [[],[]] .smaller = true := by decide
def e2422362338526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422362338526 : Closed e2422362338526 ∧ code e2422362338526 = 11218455360734 := by decide
theorem cert_e2422362338526 : check e2422362338526 [[],[]] .smaller = true := by decide
def e2422362338554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422362338554 : Closed e2422362338554 ∧ code e2422362338554 = 11218455360762 := by decide
theorem cert_e2422362338554 : check e2422362338554 [[],[]] .smaller = true := by decide
def e2422362339226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362339226 : Closed e2422362339226 ∧ code e2422362339226 = 11218455361434 := by decide
theorem cert_e2422362339226 : check e2422362339226 [[],[]] .smaller = true := by decide
def e2422362339758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422362339758 : Closed e2422362339758 ∧ code e2422362339758 = 11218455361966 := by decide
theorem cert_e2422362339758 : check e2422362339758 [[],[]] .three = true := by decide
def e2422362339766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e2422362339766 : Closed e2422362339766 ∧ code e2422362339766 = 11218455361974 := by decide
theorem cert_e2422362339766 : check e2422362339766 [[],[]] .three = true := by decide
def e2422362339770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422362339770 : Closed e2422362339770 ∧ code e2422362339770 = 11218455361978 := by decide
theorem cert_e2422362339770 : check e2422362339770 [[],[]] .three = true := by decide
def e2422362339798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e2422362339798 : Closed e2422362339798 ∧ code e2422362339798 = 11218455362006 := by decide
theorem cert_e2422362339798 : check e2422362339798 [[],[]] .three = true := by decide
def e2422362339802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e2422362339802 : Closed e2422362339802 ∧ code e2422362339802 = 11218455362010 := by decide
theorem cert_e2422362339802 : check e2422362339802 [[],[]] .three = true := by decide
def e2422362339818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422362339818 : Closed e2422362339818 ∧ code e2422362339818 = 11218455362026 := by decide
theorem cert_e2422362339818 : check e2422362339818 [[],[]] .three = true := by decide
def e2422362339950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362339950 : Closed e2422362339950 ∧ code e2422362339950 = 11218455362158 := by decide
theorem cert_e2422362339950 : check e2422362339950 [[],[]] .three = true := by decide
def e2422362339958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422362339958 : Closed e2422362339958 ∧ code e2422362339958 = 11218455362166 := by decide
theorem cert_e2422362339958 : check e2422362339958 [[],[]] .three = true := by decide
def e2422362339962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362339962 : Closed e2422362339962 ∧ code e2422362339962 = 11218455362170 := by decide
theorem cert_e2422362339962 : check e2422362339962 [[],[]] .three = true := by decide
def e2422362340150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362340150 : Closed e2422362340150 ∧ code e2422362340150 = 11218455362358 := by decide
theorem cert_e2422362340150 : check e2422362340150 [[],[]] .three = true := by decide
def e2422362340154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362340154 : Closed e2422362340154 ∧ code e2422362340154 = 11218455362362 := by decide
theorem cert_e2422362340154 : check e2422362340154 [[],[]] .three = true := by decide
def e2422362340250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 5) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362340250 : Closed e2422362340250 ∧ code e2422362340250 = 11218455362458 := by decide
theorem cert_e2422362340250 : check e2422362340250 [[],[]] .three = true := by decide
def e2422362344302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))))
theorem wire_e2422362344302 : Closed e2422362344302 ∧ code e2422362344302 = 11218455366510 := by decide
theorem cert_e2422362344302 : check e2422362344302 [[],[]] .smaller = true := by decide
def e2422362344310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))))
theorem wire_e2422362344310 : Closed e2422362344310 ∧ code e2422362344310 = 11218455366518 := by decide
theorem cert_e2422362344310 : check e2422362344310 [[],[]] .smaller = true := by decide
def e2422362344366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))))
theorem wire_e2422362344366 : Closed e2422362344366 ∧ code e2422362344366 = 11218455366574 := by decide
theorem cert_e2422362344366 : check e2422362344366 [[],[]] .smaller = true := by decide
def e2422362344378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))))
theorem wire_e2422362344378 : Closed e2422362344378 ∧ code e2422362344378 = 11218455366586 := by decide
theorem cert_e2422362344378 : check e2422362344378 [[],[]] .smaller = true := by decide
def e2422362344406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))))
theorem wire_e2422362344406 : Closed e2422362344406 ∧ code e2422362344406 = 11218455366614 := by decide
theorem cert_e2422362344406 : check e2422362344406 [[],[]] .smaller = true := by decide
def e2422362344410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))))
theorem wire_e2422362344410 : Closed e2422362344410 ∧ code e2422362344410 = 11218455366618 := by decide
theorem cert_e2422362344410 : check e2422362344410 [[],[]] .smaller = true := by decide
def e2422362344686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))))
theorem wire_e2422362344686 : Closed e2422362344686 ∧ code e2422362344686 = 11218455366894 := by decide
theorem cert_e2422362344686 : check e2422362344686 [[],[]] .smaller = true := by decide
def e2422362344694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))))
theorem wire_e2422362344694 : Closed e2422362344694 ∧ code e2422362344694 = 11218455366902 := by decide
theorem cert_e2422362344694 : check e2422362344694 [[],[]] .smaller = true := by decide
def e2422362345070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))))
theorem wire_e2422362345070 : Closed e2422362345070 ∧ code e2422362345070 = 11218455367278 := by decide
theorem cert_e2422362345070 : check e2422362345070 [[],[]] .smaller = true := by decide
def e2422362345082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))))
theorem wire_e2422362345082 : Closed e2422362345082 ∧ code e2422362345082 = 11218455367290 := by decide
theorem cert_e2422362345082 : check e2422362345082 [[],[]] .smaller = true := by decide
def e2422362345270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))))
theorem wire_e2422362345270 : Closed e2422362345270 ∧ code e2422362345270 = 11218455367478 := by decide
theorem cert_e2422362345270 : check e2422362345270 [[],[]] .smaller = true := by decide
def e2422362345274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))))
theorem wire_e2422362345274 : Closed e2422362345274 ∧ code e2422362345274 = 11218455367482 := by decide
theorem cert_e2422362345274 : check e2422362345274 [[],[]] .smaller = true := by decide
def e2422362353086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))))
theorem wire_e2422362353086 : Closed e2422362353086 ∧ code e2422362353086 = 11218455375294 := by decide
theorem cert_e2422362353086 : check e2422362353086 [[],[]] .smaller = true := by decide
def e2422362353142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))))
theorem wire_e2422362353142 : Closed e2422362353142 ∧ code e2422362353142 = 11218455375350 := by decide
theorem cert_e2422362353142 : check e2422362353142 [[],[]] .smaller = true := by decide
def e2422362353342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))))
theorem wire_e2422362353342 : Closed e2422362353342 ∧ code e2422362353342 = 11218455375550 := by decide
theorem cert_e2422362353342 : check e2422362353342 [[],[]] .smaller = true := by decide
def e2422362353402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))))
theorem wire_e2422362353402 : Closed e2422362353402 ∧ code e2422362353402 = 11218455375610 := by decide
theorem cert_e2422362353402 : check e2422362353402 [[],[]] .smaller = true := by decide
def e2422362353622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))))
theorem wire_e2422362353622 : Closed e2422362353622 ∧ code e2422362353622 = 11218455375830 := by decide
theorem cert_e2422362353622 : check e2422362353622 [[],[]] .smaller = true := by decide
def e2422362353626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))))
theorem wire_e2422362353626 : Closed e2422362353626 ∧ code e2422362353626 = 11218455375834 := by decide
theorem cert_e2422362353626 : check e2422362353626 [[],[]] .smaller = true := by decide
def e2422362354622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))))
theorem wire_e2422362354622 : Closed e2422362354622 ∧ code e2422362354622 = 11218455376830 := by decide
theorem cert_e2422362354622 : check e2422362354622 [[],[]] .smaller = true := by decide
def e2422362354678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))))
theorem wire_e2422362354678 : Closed e2422362354678 ∧ code e2422362354678 = 11218455376886 := by decide
theorem cert_e2422362354678 : check e2422362354678 [[],[]] .smaller = true := by decide
def e2422362356158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))))
theorem wire_e2422362356158 : Closed e2422362356158 ∧ code e2422362356158 = 11218455378366 := by decide
theorem cert_e2422362356158 : check e2422362356158 [[],[]] .smaller = true := by decide
def e2422362356218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))))
theorem wire_e2422362356218 : Closed e2422362356218 ∧ code e2422362356218 = 11218455378426 := by decide
theorem cert_e2422362356218 : check e2422362356218 [[],[]] .smaller = true := by decide
def e2422362357558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422362357558 : Closed e2422362357558 ∧ code e2422362357558 = 11218455379766 := by decide
theorem cert_e2422362357558 : check e2422362357558 [[],[]] .smaller = true := by decide
def e2422362357562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422362357562 : Closed e2422362357562 ∧ code e2422362357562 = 11218455379770 := by decide
theorem cert_e2422362357562 : check e2422362357562 [[],[]] .smaller = true := by decide
def e2422362385774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e2422362385774 : Closed e2422362385774 ∧ code e2422362385774 = 11218455407982 := by decide
theorem cert_e2422362385774 : check e2422362385774 [[],[]] .smaller = true := by decide
def e2422362385782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e2422362385782 : Closed e2422362385782 ∧ code e2422362385782 = 11218455407990 := by decide
theorem cert_e2422362385782 : check e2422362385782 [[],[]] .smaller = true := by decide
def e2422362385838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e2422362385838 : Closed e2422362385838 ∧ code e2422362385838 = 11218455408046 := by decide
theorem cert_e2422362385838 : check e2422362385838 [[],[]] .smaller = true := by decide
def e2422362385850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e2422362385850 : Closed e2422362385850 ∧ code e2422362385850 = 11218455408058 := by decide
theorem cert_e2422362385850 : check e2422362385850 [[],[]] .smaller = true := by decide
def e2422362385878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e2422362385878 : Closed e2422362385878 ∧ code e2422362385878 = 11218455408086 := by decide
theorem cert_e2422362385878 : check e2422362385878 [[],[]] .smaller = true := by decide
def e2422362385882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e2422362385882 : Closed e2422362385882 ∧ code e2422362385882 = 11218455408090 := by decide
theorem cert_e2422362385882 : check e2422362385882 [[],[]] .smaller = true := by decide
def e2422362386094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e2422362386094 : Closed e2422362386094 ∧ code e2422362386094 = 11218455408302 := by decide
theorem cert_e2422362386094 : check e2422362386094 [[],[]] .smaller = true := by decide
def e2422362386106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e2422362386106 : Closed e2422362386106 ∧ code e2422362386106 = 11218455408314 := by decide
theorem cert_e2422362386106 : check e2422362386106 [[],[]] .smaller = true := by decide
def e2422362386154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e2422362386154 : Closed e2422362386154 ∧ code e2422362386154 = 11218455408362 := by decide
theorem cert_e2422362386154 : check e2422362386154 [[],[]] .smaller = true := by decide
def e2422362386262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e2422362386262 : Closed e2422362386262 ∧ code e2422362386262 = 11218455408470 := by decide
theorem cert_e2422362386262 : check e2422362386262 [[],[]] .smaller = true := by decide
def e2422362386266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e2422362386266 : Closed e2422362386266 ∧ code e2422362386266 = 11218455408474 := by decide
theorem cert_e2422362386266 : check e2422362386266 [[],[]] .smaller = true := by decide
def e2422362386282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e2422362386282 : Closed e2422362386282 ∧ code e2422362386282 = 11218455408490 := by decide
theorem cert_e2422362386282 : check e2422362386282 [[],[]] .smaller = true := by decide
def e2422362386910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))))
theorem wire_e2422362386910 : Closed e2422362386910 ∧ code e2422362386910 = 11218455409118 := by decide
theorem cert_e2422362386910 : check e2422362386910 [[],[]] .smaller = true := by decide
def e2422362386934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))))
theorem wire_e2422362386934 : Closed e2422362386934 ∧ code e2422362386934 = 11218455409142 := by decide
theorem cert_e2422362386934 : check e2422362386934 [[],[]] .smaller = true := by decide
def e2422362387310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e2422362387310 : Closed e2422362387310 ∧ code e2422362387310 = 11218455409518 := by decide
theorem cert_e2422362387310 : check e2422362387310 [[],[]] .smaller = true := by decide
def e2422362387318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e2422362387318 : Closed e2422362387318 ∧ code e2422362387318 = 11218455409526 := by decide
theorem cert_e2422362387318 : check e2422362387318 [[],[]] .smaller = true := by decide
def e2422362387374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e2422362387374 : Closed e2422362387374 ∧ code e2422362387374 = 11218455409582 := by decide
theorem cert_e2422362387374 : check e2422362387374 [[],[]] .smaller = true := by decide
def e2422362387386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e2422362387386 : Closed e2422362387386 ∧ code e2422362387386 = 11218455409594 := by decide
theorem cert_e2422362387386 : check e2422362387386 [[],[]] .smaller = true := by decide
def e2422362387414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e2422362387414 : Closed e2422362387414 ∧ code e2422362387414 = 11218455409622 := by decide
theorem cert_e2422362387414 : check e2422362387414 [[],[]] .smaller = true := by decide
def e2422362387418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e2422362387418 : Closed e2422362387418 ∧ code e2422362387418 = 11218455409626 := by decide
theorem cert_e2422362387418 : check e2422362387418 [[],[]] .smaller = true := by decide
def e2422362387694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422362387694 : Closed e2422362387694 ∧ code e2422362387694 = 11218455409902 := by decide
theorem cert_e2422362387694 : check e2422362387694 [[],[]] .smaller = true := by decide
def e2422362387702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422362387702 : Closed e2422362387702 ∧ code e2422362387702 = 11218455409910 := by decide
theorem cert_e2422362387702 : check e2422362387702 [[],[]] .smaller = true := by decide
def e2422362388030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))))
theorem wire_e2422362388030 : Closed e2422362388030 ∧ code e2422362388030 = 11218455410238 := by decide
theorem cert_e2422362388030 : check e2422362388030 [[],[]] .smaller = true := by decide
def e2422362388078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362388078 : Closed e2422362388078 ∧ code e2422362388078 = 11218455410286 := by decide
theorem cert_e2422362388078 : check e2422362388078 [[],[]] .smaller = true := by decide
def e2422362388090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362388090 : Closed e2422362388090 ∧ code e2422362388090 = 11218455410298 := by decide
theorem cert_e2422362388090 : check e2422362388090 [[],[]] .smaller = true := by decide
def e2422362388278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422362388278 : Closed e2422362388278 ∧ code e2422362388278 = 11218455410486 := by decide
theorem cert_e2422362388278 : check e2422362388278 [[],[]] .smaller = true := by decide
def e2422362388282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422362388282 : Closed e2422362388282 ∧ code e2422362388282 = 11218455410490 := by decide
theorem cert_e2422362388282 : check e2422362388282 [[],[]] .smaller = true := by decide
def e2422362388350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 5))))))))))
theorem wire_e2422362388350 : Closed e2422362388350 ∧ code e2422362388350 = 11218455410558 := by decide
theorem cert_e2422362388350 : check e2422362388350 [[],[]] .three = true := by decide
def e2422362388366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))))
theorem wire_e2422362388366 : Closed e2422362388366 ∧ code e2422362388366 = 11218455410574 := by decide
theorem cert_e2422362388366 : check e2422362388366 [[],[]] .smaller = true := by decide
def e2422362388414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 4))))))))))
theorem wire_e2422362388414 : Closed e2422362388414 ∧ code e2422362388414 = 11218455410622 := by decide
theorem cert_e2422362388414 : check e2422362388414 [[],[]] .smaller = true := by decide
def e2422362388446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 3))))))))))
theorem wire_e2422362388446 : Closed e2422362388446 ∧ code e2422362388446 = 11218455410654 := by decide
theorem cert_e2422362388446 : check e2422362388446 [[],[]] .smaller = true := by decide
def e2422362388462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 5)) (.var 2))))))))))
theorem wire_e2422362388462 : Closed e2422362388462 ∧ code e2422362388462 = 11218455410670 := by decide
theorem cert_e2422362388462 : check e2422362388462 [[],[]] .three = true := by decide
def e2422362388702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))))
theorem wire_e2422362388702 : Closed e2422362388702 ∧ code e2422362388702 = 11218455410910 := by decide
theorem cert_e2422362388702 : check e2422362388702 [[],[]] .smaller = true := by decide
def e2422362388718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))))
theorem wire_e2422362388718 : Closed e2422362388718 ∧ code e2422362388718 = 11218455410926 := by decide
theorem cert_e2422362388718 : check e2422362388718 [[],[]] .smaller = true := by decide
def e2422362388726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))))
theorem wire_e2422362388726 : Closed e2422362388726 ∧ code e2422362388726 = 11218455410934 := by decide
theorem cert_e2422362388726 : check e2422362388726 [[],[]] .smaller = true := by decide
def e2422362388730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))))
theorem wire_e2422362388730 : Closed e2422362388730 ∧ code e2422362388730 = 11218455410938 := by decide
theorem cert_e2422362388730 : check e2422362388730 [[],[]] .smaller = true := by decide
def e2422362388910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e2422362388910 : Closed e2422362388910 ∧ code e2422362388910 = 11218455411118 := by decide
theorem cert_e2422362388910 : check e2422362388910 [[],[]] .smaller = true := by decide
def e2422362388922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e2422362388922 : Closed e2422362388922 ∧ code e2422362388922 = 11218455411130 := by decide
theorem cert_e2422362388922 : check e2422362388922 [[],[]] .smaller = true := by decide
def e2422362388970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e2422362388970 : Closed e2422362388970 ∧ code e2422362388970 = 11218455411178 := by decide
theorem cert_e2422362388970 : check e2422362388970 [[],[]] .smaller = true := by decide
def e2422362389054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))))
theorem wire_e2422362389054 : Closed e2422362389054 ∧ code e2422362389054 = 11218455411262 := by decide
theorem cert_e2422362389054 : check e2422362389054 [[],[]] .smaller = true := by decide
def e2422362389102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362389102 : Closed e2422362389102 ∧ code e2422362389102 = 11218455411310 := by decide
theorem cert_e2422362389102 : check e2422362389102 [[],[]] .smaller = true := by decide
def e2422362389114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362389114 : Closed e2422362389114 ∧ code e2422362389114 = 11218455411322 := by decide
theorem cert_e2422362389114 : check e2422362389114 [[],[]] .smaller = true := by decide
def e2422362389278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))))
theorem wire_e2422362389278 : Closed e2422362389278 ∧ code e2422362389278 = 11218455411486 := by decide
theorem cert_e2422362389278 : check e2422362389278 [[],[]] .smaller = true := by decide
def e2422362389374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 5))))))))))
theorem wire_e2422362389374 : Closed e2422362389374 ∧ code e2422362389374 = 11218455411582 := by decide
theorem cert_e2422362389374 : check e2422362389374 [[],[]] .three = true := by decide
def e2422362389390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))))
theorem wire_e2422362389390 : Closed e2422362389390 ∧ code e2422362389390 = 11218455411598 := by decide
theorem cert_e2422362389390 : check e2422362389390 [[],[]] .smaller = true := by decide
def e2422362389402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362389402 : Closed e2422362389402 ∧ code e2422362389402 = 11218455411610 := by decide
theorem cert_e2422362389402 : check e2422362389402 [[],[]] .smaller = true := by decide
def e2422362389446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))))
theorem wire_e2422362389446 : Closed e2422362389446 ∧ code e2422362389446 = 11218455411654 := by decide
theorem cert_e2422362389446 : check e2422362389446 [[],[]] .smaller = true := by decide
def e2422362389470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 3))))))))))
theorem wire_e2422362389470 : Closed e2422362389470 ∧ code e2422362389470 = 11218455411678 := by decide
theorem cert_e2422362389470 : check e2422362389470 [[],[]] .smaller = true := by decide
def e2422362389494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 5)) (.var 1))))))))))
theorem wire_e2422362389494 : Closed e2422362389494 ∧ code e2422362389494 = 11218455411702 := by decide
theorem cert_e2422362389494 : check e2422362389494 [[],[]] .three = true := by decide
def e2422362389622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))))
theorem wire_e2422362389622 : Closed e2422362389622 ∧ code e2422362389622 = 11218455411830 := by decide
theorem cert_e2422362389622 : check e2422362389622 [[],[]] .smaller = true := by decide
def e2422362389718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e2422362389718 : Closed e2422362389718 ∧ code e2422362389718 = 11218455411926 := by decide
theorem cert_e2422362389718 : check e2422362389718 [[],[]] .smaller = true := by decide
def e2422362389722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e2422362389722 : Closed e2422362389722 ∧ code e2422362389722 = 11218455411930 := by decide
theorem cert_e2422362389722 : check e2422362389722 [[],[]] .smaller = true := by decide
def e2422362389738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e2422362389738 : Closed e2422362389738 ∧ code e2422362389738 = 11218455411946 := by decide
theorem cert_e2422362389738 : check e2422362389738 [[],[]] .smaller = true := by decide
def e2422362389814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422362389814 : Closed e2422362389814 ∧ code e2422362389814 = 11218455412022 := by decide
theorem cert_e2422362389814 : check e2422362389814 [[],[]] .smaller = true := by decide
def e2422362389818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422362389818 : Closed e2422362389818 ∧ code e2422362389818 = 11218455412026 := by decide
theorem cert_e2422362389818 : check e2422362389818 [[],[]] .smaller = true := by decide
def e2422362389886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 5))))))))))
theorem wire_e2422362389886 : Closed e2422362389886 ∧ code e2422362389886 = 11218455412094 := by decide
theorem cert_e2422362389886 : check e2422362389886 [[],[]] .three = true := by decide
def e2422362389902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))))
theorem wire_e2422362389902 : Closed e2422362389902 ∧ code e2422362389902 = 11218455412110 := by decide
theorem cert_e2422362389902 : check e2422362389902 [[],[]] .smaller = true := by decide
def e2422362389914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362389914 : Closed e2422362389914 ∧ code e2422362389914 = 11218455412122 := by decide
theorem cert_e2422362389914 : check e2422362389914 [[],[]] .smaller = true := by decide
def e2422362389982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 3))))))))))
theorem wire_e2422362389982 : Closed e2422362389982 ∧ code e2422362389982 = 11218455412190 := by decide
theorem cert_e2422362389982 : check e2422362389982 [[],[]] .smaller = true := by decide
def e2422362389998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 2))))))))))
theorem wire_e2422362389998 : Closed e2422362389998 ∧ code e2422362389998 = 11218455412206 := by decide
theorem cert_e2422362389998 : check e2422362389998 [[],[]] .smaller = true := by decide
def e2422362390010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 5)) (.var 0))))))))))
theorem wire_e2422362390010 : Closed e2422362390010 ∧ code e2422362390010 = 11218455412218 := by decide
theorem cert_e2422362390010 : check e2422362390010 [[],[]] .three = true := by decide
def e2422362390070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e2422362390070 : Closed e2422362390070 ∧ code e2422362390070 = 11218455412278 := by decide
theorem cert_e2422362390070 : check e2422362390070 [[],[]] .smaller = true := by decide
def e2422362390074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e2422362390074 : Closed e2422362390074 ∧ code e2422362390074 = 11218455412282 := by decide
theorem cert_e2422362390074 : check e2422362390074 [[],[]] .smaller = true := by decide
def e2422362390158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e2422362390158 : Closed e2422362390158 ∧ code e2422362390158 = 11218455412366 := by decide
theorem cert_e2422362390158 : check e2422362390158 [[],[]] .smaller = true := by decide
def e2422362390206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 4))))))))))
theorem wire_e2422362390206 : Closed e2422362390206 ∧ code e2422362390206 = 11218455412414 := by decide
theorem cert_e2422362390206 : check e2422362390206 [[],[]] .smaller = true := by decide
def e2422362390214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e2422362390214 : Closed e2422362390214 ∧ code e2422362390214 = 11218455412422 := by decide
theorem cert_e2422362390214 : check e2422362390214 [[],[]] .smaller = true := by decide
def e2422362390238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 3))))))))))
theorem wire_e2422362390238 : Closed e2422362390238 ∧ code e2422362390238 = 11218455412446 := by decide
theorem cert_e2422362390238 : check e2422362390238 [[],[]] .smaller = true := by decide
def e2422362390254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 2))))))))))
theorem wire_e2422362390254 : Closed e2422362390254 ∧ code e2422362390254 = 11218455412462 := by decide
theorem cert_e2422362390254 : check e2422362390254 [[],[]] .smaller = true := by decide
def e2422362390262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 1))))))))))
theorem wire_e2422362390262 : Closed e2422362390262 ∧ code e2422362390262 = 11218455412470 := by decide
theorem cert_e2422362390262 : check e2422362390262 [[],[]] .smaller = true := by decide
def e2422362390266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 4)) (.var 0))))))))))
theorem wire_e2422362390266 : Closed e2422362390266 ∧ code e2422362390266 = 11218455412474 := by decide
theorem cert_e2422362390266 : check e2422362390266 [[],[]] .smaller = true := by decide
def e2422362390366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 3))))))))))
theorem wire_e2422362390366 : Closed e2422362390366 ∧ code e2422362390366 = 11218455412574 := by decide
theorem cert_e2422362390366 : check e2422362390366 [[],[]] .smaller = true := by decide
def e2422362390394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 3)) (.var 0))))))))))
theorem wire_e2422362390394 : Closed e2422362390394 ∧ code e2422362390394 = 11218455412602 := by decide
theorem cert_e2422362390394 : check e2422362390394 [[],[]] .smaller = true := by decide
def e2422362390446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 5) (.var 0)) (.var 2))))))))))
theorem wire_e2422362390446 : Closed e2422362390446 ∧ code e2422362390446 = 11218455412654 := by decide
theorem cert_e2422362390446 : check e2422362390446 [[],[]] .three = true := by decide
def e2422362390454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 5) (.var 1)) (.var 1))))))))))
theorem wire_e2422362390454 : Closed e2422362390454 ∧ code e2422362390454 = 11218455412662 := by decide
theorem cert_e2422362390454 : check e2422362390454 [[],[]] .three = true := by decide
def e2422362390458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 5) (.var 2)) (.var 0))))))))))
theorem wire_e2422362390458 : Closed e2422362390458 ∧ code e2422362390458 = 11218455412666 := by decide
theorem cert_e2422362390458 : check e2422362390458 [[],[]] .three = true := by decide
def e2422362391518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))))
theorem wire_e2422362391518 : Closed e2422362391518 ∧ code e2422362391518 = 11218455413726 := by decide
theorem cert_e2422362391518 : check e2422362391518 [[],[]] .smaller = true := by decide
def e2422362391534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))))
theorem wire_e2422362391534 : Closed e2422362391534 ∧ code e2422362391534 = 11218455413742 := by decide
theorem cert_e2422362391534 : check e2422362391534 [[],[]] .smaller = true := by decide
def e2422362393454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e2422362393454 : Closed e2422362393454 ∧ code e2422362393454 = 11218455415662 := by decide
theorem cert_e2422362393454 : check e2422362393454 [[],[]] .smaller = true := by decide
def e2422362393462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e2422362393462 : Closed e2422362393462 ∧ code e2422362393462 = 11218455415670 := by decide
theorem cert_e2422362393462 : check e2422362393462 [[],[]] .smaller = true := by decide
def e2422362393518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e2422362393518 : Closed e2422362393518 ∧ code e2422362393518 = 11218455415726 := by decide
theorem cert_e2422362393518 : check e2422362393518 [[],[]] .smaller = true := by decide
def e2422362393530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e2422362393530 : Closed e2422362393530 ∧ code e2422362393530 = 11218455415738 := by decide
theorem cert_e2422362393530 : check e2422362393530 [[],[]] .smaller = true := by decide
def e2422362393558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e2422362393558 : Closed e2422362393558 ∧ code e2422362393558 = 11218455415766 := by decide
theorem cert_e2422362393558 : check e2422362393558 [[],[]] .smaller = true := by decide
def e2422362393562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e2422362393562 : Closed e2422362393562 ∧ code e2422362393562 = 11218455415770 := by decide
theorem cert_e2422362393562 : check e2422362393562 [[],[]] .smaller = true := by decide
def e2422362393838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422362393838 : Closed e2422362393838 ∧ code e2422362393838 = 11218455416046 := by decide
theorem cert_e2422362393838 : check e2422362393838 [[],[]] .smaller = true := by decide
def e2422362393846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422362393846 : Closed e2422362393846 ∧ code e2422362393846 = 11218455416054 := by decide
theorem cert_e2422362393846 : check e2422362393846 [[],[]] .smaller = true := by decide
def e2422362394174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))))
theorem wire_e2422362394174 : Closed e2422362394174 ∧ code e2422362394174 = 11218455416382 := by decide
theorem cert_e2422362394174 : check e2422362394174 [[],[]] .smaller = true := by decide
def e2422362394222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422362394222 : Closed e2422362394222 ∧ code e2422362394222 = 11218455416430 := by decide
theorem cert_e2422362394222 : check e2422362394222 [[],[]] .smaller = true := by decide
def e2422362394234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422362394234 : Closed e2422362394234 ∧ code e2422362394234 = 11218455416442 := by decide
theorem cert_e2422362394234 : check e2422362394234 [[],[]] .smaller = true := by decide
def e2422362394422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422362394422 : Closed e2422362394422 ∧ code e2422362394422 = 11218455416630 := by decide
theorem cert_e2422362394422 : check e2422362394422 [[],[]] .smaller = true := by decide
def e2422362394426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422362394426 : Closed e2422362394426 ∧ code e2422362394426 = 11218455416634 := by decide
theorem cert_e2422362394426 : check e2422362394426 [[],[]] .smaller = true := by decide
def e2422362394494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 5)))))))))))
theorem wire_e2422362394494 : Closed e2422362394494 ∧ code e2422362394494 = 11218455416702 := by decide
theorem cert_e2422362394494 : check e2422362394494 [[],[]] .three = true := by decide
def e2422362394510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))))
theorem wire_e2422362394510 : Closed e2422362394510 ∧ code e2422362394510 = 11218455416718 := by decide
theorem cert_e2422362394510 : check e2422362394510 [[],[]] .smaller = true := by decide
end Blc.Floor43
