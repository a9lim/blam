import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411625557242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625557242 : Closed e2411625557242 ∧ code e2411625557242 = 11207718579450 := by decide
theorem cert_e2411625557242 : check e2411625557242 [[],[]] .three = true := by decide
def e2411625557566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 4))))))))
theorem wire_e2411625557566 : Closed e2411625557566 ∧ code e2411625557566 = 11207718579774 := by decide
theorem cert_e2411625557566 : check e2411625557566 [[],[]] .three = true := by decide
def e2411625557622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2411625557622 : Closed e2411625557622 ∧ code e2411625557622 = 11207718579830 := by decide
theorem cert_e2411625557622 : check e2411625557622 [[],[]] .smaller = true := by decide
def e2411625557790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 3))))))))
theorem wire_e2411625557790 : Closed e2411625557790 ∧ code e2411625557790 = 11207718579998 := by decide
theorem cert_e2411625557790 : check e2411625557790 [[],[]] .three = true := by decide
def e2411625557814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625557814 : Closed e2411625557814 ∧ code e2411625557814 = 11207718580022 := by decide
theorem cert_e2411625557814 : check e2411625557814 [[],[]] .three = true := by decide
def e2411625557818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625557818 : Closed e2411625557818 ∧ code e2411625557818 = 11207718580026 := by decide
theorem cert_e2411625557818 : check e2411625557818 [[],[]] .three = true := by decide
def e2411625558494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2411625558494 : Closed e2411625558494 ∧ code e2411625558494 = 11207718580702 := by decide
theorem cert_e2411625558494 : check e2411625558494 [[],[]] .three = true := by decide
def e2411625558510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e2411625558510 : Closed e2411625558510 ∧ code e2411625558510 = 11207718580718 := by decide
theorem cert_e2411625558510 : check e2411625558510 [[],[]] .smaller = true := by decide
def e2411625558518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2411625558518 : Closed e2411625558518 ∧ code e2411625558518 = 11207718580726 := by decide
theorem cert_e2411625558518 : check e2411625558518 [[],[]] .three = true := by decide
def e2411625558878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2411625558878 : Closed e2411625558878 ∧ code e2411625558878 = 11207718581086 := by decide
theorem cert_e2411625558878 : check e2411625558878 [[],[]] .three = true := by decide
def e2411625558894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2411625558894 : Closed e2411625558894 ∧ code e2411625558894 = 11207718581102 := by decide
theorem cert_e2411625558894 : check e2411625558894 [[],[]] .smaller = true := by decide
def e2411625558902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2411625558902 : Closed e2411625558902 ∧ code e2411625558902 = 11207718581110 := by decide
theorem cert_e2411625558902 : check e2411625558902 [[],[]] .smaller = true := by decide
def e2411625558906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2411625558906 : Closed e2411625558906 ∧ code e2411625558906 = 11207718581114 := by decide
theorem cert_e2411625558906 : check e2411625558906 [[],[]] .three = true := by decide
def e2411625558958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2411625558958 : Closed e2411625558958 ∧ code e2411625558958 = 11207718581166 := by decide
theorem cert_e2411625558958 : check e2411625558958 [[],[]] .smaller = true := by decide
def e2411625558970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2411625558970 : Closed e2411625558970 ∧ code e2411625558970 = 11207718581178 := by decide
theorem cert_e2411625558970 : check e2411625558970 [[],[]] .smaller = true := by decide
def e2411625558998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2411625558998 : Closed e2411625558998 ∧ code e2411625558998 = 11207718581206 := by decide
theorem cert_e2411625558998 : check e2411625558998 [[],[]] .smaller = true := by decide
def e2411625559002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2411625559002 : Closed e2411625559002 ∧ code e2411625559002 = 11207718581210 := by decide
theorem cert_e2411625559002 : check e2411625559002 [[],[]] .smaller = true := by decide
def e2411625559018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2411625559018 : Closed e2411625559018 ∧ code e2411625559018 = 11207718581226 := by decide
theorem cert_e2411625559018 : check e2411625559018 [[],[]] .three = true := by decide
def e2411625559262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625559262 : Closed e2411625559262 ∧ code e2411625559262 = 11207718581470 := by decide
theorem cert_e2411625559262 : check e2411625559262 [[],[]] .three = true := by decide
def e2411625559278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625559278 : Closed e2411625559278 ∧ code e2411625559278 = 11207718581486 := by decide
theorem cert_e2411625559278 : check e2411625559278 [[],[]] .smaller = true := by decide
def e2411625559286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625559286 : Closed e2411625559286 ∧ code e2411625559286 = 11207718581494 := by decide
theorem cert_e2411625559286 : check e2411625559286 [[],[]] .smaller = true := by decide
def e2411625559290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625559290 : Closed e2411625559290 ∧ code e2411625559290 = 11207718581498 := by decide
theorem cert_e2411625559290 : check e2411625559290 [[],[]] .three = true := by decide
def e2411625559614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2411625559614 : Closed e2411625559614 ∧ code e2411625559614 = 11207718581822 := by decide
theorem cert_e2411625559614 : check e2411625559614 [[],[]] .three = true := by decide
def e2411625559662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625559662 : Closed e2411625559662 ∧ code e2411625559662 = 11207718581870 := by decide
theorem cert_e2411625559662 : check e2411625559662 [[],[]] .smaller = true := by decide
def e2411625559674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625559674 : Closed e2411625559674 ∧ code e2411625559674 = 11207718581882 := by decide
theorem cert_e2411625559674 : check e2411625559674 [[],[]] .smaller = true := by decide
def e2411625559838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e2411625559838 : Closed e2411625559838 ∧ code e2411625559838 = 11207718582046 := by decide
theorem cert_e2411625559838 : check e2411625559838 [[],[]] .smaller = true := by decide
def e2411625559862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625559862 : Closed e2411625559862 ∧ code e2411625559862 = 11207718582070 := by decide
theorem cert_e2411625559862 : check e2411625559862 [[],[]] .smaller = true := by decide
def e2411625559866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625559866 : Closed e2411625559866 ∧ code e2411625559866 = 11207718582074 := by decide
theorem cert_e2411625559866 : check e2411625559866 [[],[]] .smaller = true := by decide
def e2411625559950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2411625559950 : Closed e2411625559950 ∧ code e2411625559950 = 11207718582158 := by decide
theorem cert_e2411625559950 : check e2411625559950 [[],[]] .three = true := by decide
def e2411625559962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625559962 : Closed e2411625559962 ∧ code e2411625559962 = 11207718582170 := by decide
theorem cert_e2411625559962 : check e2411625559962 [[],[]] .three = true := by decide
def e2411625560286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2411625560286 : Closed e2411625560286 ∧ code e2411625560286 = 11207718582494 := by decide
theorem cert_e2411625560286 : check e2411625560286 [[],[]] .three = true := by decide
def e2411625560302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2411625560302 : Closed e2411625560302 ∧ code e2411625560302 = 11207718582510 := by decide
theorem cert_e2411625560302 : check e2411625560302 [[],[]] .smaller = true := by decide
def e2411625560310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2411625560310 : Closed e2411625560310 ∧ code e2411625560310 = 11207718582518 := by decide
theorem cert_e2411625560310 : check e2411625560310 [[],[]] .smaller = true := by decide
def e2411625560314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2411625560314 : Closed e2411625560314 ∧ code e2411625560314 = 11207718582522 := by decide
theorem cert_e2411625560314 : check e2411625560314 [[],[]] .three = true := by decide
def e2411625560502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2411625560502 : Closed e2411625560502 ∧ code e2411625560502 = 11207718582710 := by decide
theorem cert_e2411625560502 : check e2411625560502 [[],[]] .smaller = true := by decide
def e2411625560534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2411625560534 : Closed e2411625560534 ∧ code e2411625560534 = 11207718582742 := by decide
theorem cert_e2411625560534 : check e2411625560534 [[],[]] .smaller = true := by decide
def e2411625560538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2411625560538 : Closed e2411625560538 ∧ code e2411625560538 = 11207718582746 := by decide
theorem cert_e2411625560538 : check e2411625560538 [[],[]] .smaller = true := by decide
def e2411625560638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2411625560638 : Closed e2411625560638 ∧ code e2411625560638 = 11207718582846 := by decide
theorem cert_e2411625560638 : check e2411625560638 [[],[]] .three = true := by decide
def e2411625560694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2411625560694 : Closed e2411625560694 ∧ code e2411625560694 = 11207718582902 := by decide
theorem cert_e2411625560694 : check e2411625560694 [[],[]] .smaller = true := by decide
def e2411625560862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2411625560862 : Closed e2411625560862 ∧ code e2411625560862 = 11207718583070 := by decide
theorem cert_e2411625560862 : check e2411625560862 [[],[]] .smaller = true := by decide
def e2411625560886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625560886 : Closed e2411625560886 ∧ code e2411625560886 = 11207718583094 := by decide
theorem cert_e2411625560886 : check e2411625560886 [[],[]] .smaller = true := by decide
def e2411625560890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625560890 : Closed e2411625560890 ∧ code e2411625560890 = 11207718583098 := by decide
theorem cert_e2411625560890 : check e2411625560890 [[],[]] .smaller = true := by decide
def e2411625560974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2411625560974 : Closed e2411625560974 ∧ code e2411625560974 = 11207718583182 := by decide
theorem cert_e2411625560974 : check e2411625560974 [[],[]] .smaller = true := by decide
def e2411625561030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2411625561030 : Closed e2411625561030 ∧ code e2411625561030 = 11207718583238 := by decide
theorem cert_e2411625561030 : check e2411625561030 [[],[]] .three = true := by decide
def e2411625561054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 3)))))))
theorem wire_e2411625561054 : Closed e2411625561054 ∧ code e2411625561054 = 11207718583262 := by decide
theorem cert_e2411625561054 : check e2411625561054 [[],[]] .three = true := by decide
def e2411625561198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411625561198 : Closed e2411625561198 ∧ code e2411625561198 = 11207718583406 := by decide
theorem cert_e2411625561198 : check e2411625561198 [[],[]] .three = true := by decide
def e2411625561206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2411625561206 : Closed e2411625561206 ∧ code e2411625561206 = 11207718583414 := by decide
theorem cert_e2411625561206 : check e2411625561206 [[],[]] .three = true := by decide
def e2411625561210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411625561210 : Closed e2411625561210 ∧ code e2411625561210 = 11207718583418 := by decide
theorem cert_e2411625561210 : check e2411625561210 [[],[]] .three = true := by decide
def e2411625561302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2411625561302 : Closed e2411625561302 ∧ code e2411625561302 = 11207718583510 := by decide
theorem cert_e2411625561302 : check e2411625561302 [[],[]] .three = true := by decide
def e2411625561306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2411625561306 : Closed e2411625561306 ∧ code e2411625561306 = 11207718583514 := by decide
theorem cert_e2411625561306 : check e2411625561306 [[],[]] .three = true := by decide
def e2411625561322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2411625561322 : Closed e2411625561322 ∧ code e2411625561322 = 11207718583530 := by decide
theorem cert_e2411625561322 : check e2411625561322 [[],[]] .three = true := by decide
def e2411625561374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411625561374 : Closed e2411625561374 ∧ code e2411625561374 = 11207718583582 := by decide
theorem cert_e2411625561374 : check e2411625561374 [[],[]] .three = true := by decide
def e2411625561398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625561398 : Closed e2411625561398 ∧ code e2411625561398 = 11207718583606 := by decide
theorem cert_e2411625561398 : check e2411625561398 [[],[]] .three = true := by decide
def e2411625561402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625561402 : Closed e2411625561402 ∧ code e2411625561402 = 11207718583610 := by decide
theorem cert_e2411625561402 : check e2411625561402 [[],[]] .three = true := by decide
def e2411625561486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2411625561486 : Closed e2411625561486 ∧ code e2411625561486 = 11207718583694 := by decide
theorem cert_e2411625561486 : check e2411625561486 [[],[]] .three = true := by decide
def e2411625561498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625561498 : Closed e2411625561498 ∧ code e2411625561498 = 11207718583706 := by decide
theorem cert_e2411625561498 : check e2411625561498 [[],[]] .three = true := by decide
def e2411625561542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411625561542 : Closed e2411625561542 ∧ code e2411625561542 = 11207718583750 := by decide
theorem cert_e2411625561542 : check e2411625561542 [[],[]] .three = true := by decide
def e2411625561566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 3)))))))
theorem wire_e2411625561566 : Closed e2411625561566 ∧ code e2411625561566 = 11207718583774 := by decide
theorem cert_e2411625561566 : check e2411625561566 [[],[]] .three = true := by decide
def e2411625561582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 2)))))))
theorem wire_e2411625561582 : Closed e2411625561582 ∧ code e2411625561582 = 11207718583790 := by decide
theorem cert_e2411625561582 : check e2411625561582 [[],[]] .three = true := by decide
def e2411625563870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e2411625563870 : Closed e2411625563870 ∧ code e2411625563870 = 11207718586078 := by decide
theorem cert_e2411625563870 : check e2411625563870 [[],[]] .three = true := by decide
def e2411625563886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e2411625563886 : Closed e2411625563886 ∧ code e2411625563886 = 11207718586094 := by decide
theorem cert_e2411625563886 : check e2411625563886 [[],[]] .smaller = true := by decide
def e2411625563894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e2411625563894 : Closed e2411625563894 ∧ code e2411625563894 = 11207718586102 := by decide
theorem cert_e2411625563894 : check e2411625563894 [[],[]] .three = true := by decide
def e2411625563998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e2411625563998 : Closed e2411625563998 ∧ code e2411625563998 = 11207718586206 := by decide
theorem cert_e2411625563998 : check e2411625563998 [[],[]] .three = true := by decide
def e2411625564026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e2411625564026 : Closed e2411625564026 ∧ code e2411625564026 = 11207718586234 := by decide
theorem cert_e2411625564026 : check e2411625564026 [[],[]] .three = true := by decide
def e2411625564078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e2411625564078 : Closed e2411625564078 ∧ code e2411625564078 = 11207718586286 := by decide
theorem cert_e2411625564078 : check e2411625564078 [[],[]] .smaller = true := by decide
def e2411625564090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e2411625564090 : Closed e2411625564090 ∧ code e2411625564090 = 11207718586298 := by decide
theorem cert_e2411625564090 : check e2411625564090 [[],[]] .smaller = true := by decide
def e2411625564118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 1)))))))
theorem wire_e2411625564118 : Closed e2411625564118 ∧ code e2411625564118 = 11207718586326 := by decide
theorem cert_e2411625564118 : check e2411625564118 [[],[]] .three = true := by decide
def e2411625564122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 1)) (.var 0)))))))
theorem wire_e2411625564122 : Closed e2411625564122 ∧ code e2411625564122 = 11207718586330 := by decide
theorem cert_e2411625564122 : check e2411625564122 [[],[]] .three = true := by decide
def e2411625565534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e2411625565534 : Closed e2411625565534 ∧ code e2411625565534 = 11207718587742 := by decide
theorem cert_e2411625565534 : check e2411625565534 [[],[]] .three = true := by decide
def e2411625565550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2411625565550 : Closed e2411625565550 ∧ code e2411625565550 = 11207718587758 := by decide
theorem cert_e2411625565550 : check e2411625565550 [[],[]] .smaller = true := by decide
def e2411625565558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2411625565558 : Closed e2411625565558 ∧ code e2411625565558 = 11207718587766 := by decide
theorem cert_e2411625565558 : check e2411625565558 [[],[]] .smaller = true := by decide
def e2411625565562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e2411625565562 : Closed e2411625565562 ∧ code e2411625565562 = 11207718587770 := by decide
theorem cert_e2411625565562 : check e2411625565562 [[],[]] .three = true := by decide
def e2411625565614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2411625565614 : Closed e2411625565614 ∧ code e2411625565614 = 11207718587822 := by decide
theorem cert_e2411625565614 : check e2411625565614 [[],[]] .smaller = true := by decide
def e2411625565626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2411625565626 : Closed e2411625565626 ∧ code e2411625565626 = 11207718587834 := by decide
theorem cert_e2411625565626 : check e2411625565626 [[],[]] .smaller = true := by decide
def e2411625565654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2411625565654 : Closed e2411625565654 ∧ code e2411625565654 = 11207718587862 := by decide
theorem cert_e2411625565654 : check e2411625565654 [[],[]] .smaller = true := by decide
def e2411625565658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2411625565658 : Closed e2411625565658 ∧ code e2411625565658 = 11207718587866 := by decide
theorem cert_e2411625565658 : check e2411625565658 [[],[]] .smaller = true := by decide
def e2411625565674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2411625565674 : Closed e2411625565674 ∧ code e2411625565674 = 11207718587882 := by decide
theorem cert_e2411625565674 : check e2411625565674 [[],[]] .three = true := by decide
def e2411625565870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2411625565870 : Closed e2411625565870 ∧ code e2411625565870 = 11207718588078 := by decide
theorem cert_e2411625565870 : check e2411625565870 [[],[]] .smaller = true := by decide
def e2411625565882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2411625565882 : Closed e2411625565882 ∧ code e2411625565882 = 11207718588090 := by decide
theorem cert_e2411625565882 : check e2411625565882 [[],[]] .smaller = true := by decide
def e2411625565930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2411625565930 : Closed e2411625565930 ∧ code e2411625565930 = 11207718588138 := by decide
theorem cert_e2411625565930 : check e2411625565930 [[],[]] .smaller = true := by decide
def e2411625566038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2411625566038 : Closed e2411625566038 ∧ code e2411625566038 = 11207718588246 := by decide
theorem cert_e2411625566038 : check e2411625566038 [[],[]] .smaller = true := by decide
def e2411625566042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2411625566042 : Closed e2411625566042 ∧ code e2411625566042 = 11207718588250 := by decide
theorem cert_e2411625566042 : check e2411625566042 [[],[]] .smaller = true := by decide
def e2411625566058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2411625566058 : Closed e2411625566058 ∧ code e2411625566058 = 11207718588266 := by decide
theorem cert_e2411625566058 : check e2411625566058 [[],[]] .smaller = true := by decide
def e2411625566122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2411625566122 : Closed e2411625566122 ∧ code e2411625566122 = 11207718588330 := by decide
theorem cert_e2411625566122 : check e2411625566122 [[],[]] .three = true := by decide
def e2411625566686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2411625566686 : Closed e2411625566686 ∧ code e2411625566686 = 11207718588894 := by decide
theorem cert_e2411625566686 : check e2411625566686 [[],[]] .three = true := by decide
def e2411625566702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e2411625566702 : Closed e2411625566702 ∧ code e2411625566702 = 11207718588910 := by decide
theorem cert_e2411625566702 : check e2411625566702 [[],[]] .smaller = true := by decide
def e2411625566710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2411625566710 : Closed e2411625566710 ∧ code e2411625566710 = 11207718588918 := by decide
theorem cert_e2411625566710 : check e2411625566710 [[],[]] .three = true := by decide
def e2411625567070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2411625567070 : Closed e2411625567070 ∧ code e2411625567070 = 11207718589278 := by decide
theorem cert_e2411625567070 : check e2411625567070 [[],[]] .three = true := by decide
def e2411625567086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2411625567086 : Closed e2411625567086 ∧ code e2411625567086 = 11207718589294 := by decide
theorem cert_e2411625567086 : check e2411625567086 [[],[]] .smaller = true := by decide
def e2411625567094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2411625567094 : Closed e2411625567094 ∧ code e2411625567094 = 11207718589302 := by decide
theorem cert_e2411625567094 : check e2411625567094 [[],[]] .smaller = true := by decide
def e2411625567098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2411625567098 : Closed e2411625567098 ∧ code e2411625567098 = 11207718589306 := by decide
theorem cert_e2411625567098 : check e2411625567098 [[],[]] .three = true := by decide
def e2411625567150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2411625567150 : Closed e2411625567150 ∧ code e2411625567150 = 11207718589358 := by decide
theorem cert_e2411625567150 : check e2411625567150 [[],[]] .smaller = true := by decide
def e2411625567162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2411625567162 : Closed e2411625567162 ∧ code e2411625567162 = 11207718589370 := by decide
theorem cert_e2411625567162 : check e2411625567162 [[],[]] .smaller = true := by decide
def e2411625567190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2411625567190 : Closed e2411625567190 ∧ code e2411625567190 = 11207718589398 := by decide
theorem cert_e2411625567190 : check e2411625567190 [[],[]] .smaller = true := by decide
def e2411625567194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2411625567194 : Closed e2411625567194 ∧ code e2411625567194 = 11207718589402 := by decide
theorem cert_e2411625567194 : check e2411625567194 [[],[]] .smaller = true := by decide
def e2411625567210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2411625567210 : Closed e2411625567210 ∧ code e2411625567210 = 11207718589418 := by decide
theorem cert_e2411625567210 : check e2411625567210 [[],[]] .three = true := by decide
def e2411625567454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625567454 : Closed e2411625567454 ∧ code e2411625567454 = 11207718589662 := by decide
theorem cert_e2411625567454 : check e2411625567454 [[],[]] .three = true := by decide
def e2411625567470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625567470 : Closed e2411625567470 ∧ code e2411625567470 = 11207718589678 := by decide
theorem cert_e2411625567470 : check e2411625567470 [[],[]] .smaller = true := by decide
def e2411625567478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625567478 : Closed e2411625567478 ∧ code e2411625567478 = 11207718589686 := by decide
theorem cert_e2411625567478 : check e2411625567478 [[],[]] .smaller = true := by decide
def e2411625567482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625567482 : Closed e2411625567482 ∧ code e2411625567482 = 11207718589690 := by decide
theorem cert_e2411625567482 : check e2411625567482 [[],[]] .three = true := by decide
def e2411625567806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2411625567806 : Closed e2411625567806 ∧ code e2411625567806 = 11207718590014 := by decide
theorem cert_e2411625567806 : check e2411625567806 [[],[]] .three = true := by decide
def e2411625567854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625567854 : Closed e2411625567854 ∧ code e2411625567854 = 11207718590062 := by decide
theorem cert_e2411625567854 : check e2411625567854 [[],[]] .smaller = true := by decide
def e2411625567866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625567866 : Closed e2411625567866 ∧ code e2411625567866 = 11207718590074 := by decide
theorem cert_e2411625567866 : check e2411625567866 [[],[]] .smaller = true := by decide
def e2411625568030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e2411625568030 : Closed e2411625568030 ∧ code e2411625568030 = 11207718590238 := by decide
theorem cert_e2411625568030 : check e2411625568030 [[],[]] .smaller = true := by decide
def e2411625568054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625568054 : Closed e2411625568054 ∧ code e2411625568054 = 11207718590262 := by decide
theorem cert_e2411625568054 : check e2411625568054 [[],[]] .smaller = true := by decide
def e2411625568058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625568058 : Closed e2411625568058 ∧ code e2411625568058 = 11207718590266 := by decide
theorem cert_e2411625568058 : check e2411625568058 [[],[]] .smaller = true := by decide
def e2411625568142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2411625568142 : Closed e2411625568142 ∧ code e2411625568142 = 11207718590350 := by decide
theorem cert_e2411625568142 : check e2411625568142 [[],[]] .three = true := by decide
def e2411625568154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625568154 : Closed e2411625568154 ∧ code e2411625568154 = 11207718590362 := by decide
theorem cert_e2411625568154 : check e2411625568154 [[],[]] .three = true := by decide
def e2411625568478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2411625568478 : Closed e2411625568478 ∧ code e2411625568478 = 11207718590686 := by decide
theorem cert_e2411625568478 : check e2411625568478 [[],[]] .three = true := by decide
def e2411625568506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2411625568506 : Closed e2411625568506 ∧ code e2411625568506 = 11207718590714 := by decide
theorem cert_e2411625568506 : check e2411625568506 [[],[]] .three = true := by decide
def e2411625568686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2411625568686 : Closed e2411625568686 ∧ code e2411625568686 = 11207718590894 := by decide
theorem cert_e2411625568686 : check e2411625568686 [[],[]] .smaller = true := by decide
def e2411625568698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2411625568698 : Closed e2411625568698 ∧ code e2411625568698 = 11207718590906 := by decide
theorem cert_e2411625568698 : check e2411625568698 [[],[]] .smaller = true := by decide
def e2411625568746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2411625568746 : Closed e2411625568746 ∧ code e2411625568746 = 11207718590954 := by decide
theorem cert_e2411625568746 : check e2411625568746 [[],[]] .smaller = true := by decide
def e2411625568830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2411625568830 : Closed e2411625568830 ∧ code e2411625568830 = 11207718591038 := by decide
theorem cert_e2411625568830 : check e2411625568830 [[],[]] .three = true := by decide
def e2411625568878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625568878 : Closed e2411625568878 ∧ code e2411625568878 = 11207718591086 := by decide
theorem cert_e2411625568878 : check e2411625568878 [[],[]] .smaller = true := by decide
def e2411625568890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625568890 : Closed e2411625568890 ∧ code e2411625568890 = 11207718591098 := by decide
theorem cert_e2411625568890 : check e2411625568890 [[],[]] .smaller = true := by decide
def e2411625569178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625569178 : Closed e2411625569178 ∧ code e2411625569178 = 11207718591386 := by decide
theorem cert_e2411625569178 : check e2411625569178 [[],[]] .smaller = true := by decide
def e2411625569222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2411625569222 : Closed e2411625569222 ∧ code e2411625569222 = 11207718591430 := by decide
theorem cert_e2411625569222 : check e2411625569222 [[],[]] .three = true := by decide
def e2411625569390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411625569390 : Closed e2411625569390 ∧ code e2411625569390 = 11207718591598 := by decide
theorem cert_e2411625569390 : check e2411625569390 [[],[]] .smaller = true := by decide
def e2411625569402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411625569402 : Closed e2411625569402 ∧ code e2411625569402 = 11207718591610 := by decide
theorem cert_e2411625569402 : check e2411625569402 [[],[]] .smaller = true := by decide
def e2411625569494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2411625569494 : Closed e2411625569494 ∧ code e2411625569494 = 11207718591702 := by decide
theorem cert_e2411625569494 : check e2411625569494 [[],[]] .smaller = true := by decide
def e2411625569498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2411625569498 : Closed e2411625569498 ∧ code e2411625569498 = 11207718591706 := by decide
theorem cert_e2411625569498 : check e2411625569498 [[],[]] .smaller = true := by decide
def e2411625569514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2411625569514 : Closed e2411625569514 ∧ code e2411625569514 = 11207718591722 := by decide
theorem cert_e2411625569514 : check e2411625569514 [[],[]] .smaller = true := by decide
def e2411625569566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411625569566 : Closed e2411625569566 ∧ code e2411625569566 = 11207718591774 := by decide
theorem cert_e2411625569566 : check e2411625569566 [[],[]] .smaller = true := by decide
def e2411625569590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625569590 : Closed e2411625569590 ∧ code e2411625569590 = 11207718591798 := by decide
theorem cert_e2411625569590 : check e2411625569590 [[],[]] .smaller = true := by decide
def e2411625569594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625569594 : Closed e2411625569594 ∧ code e2411625569594 = 11207718591802 := by decide
theorem cert_e2411625569594 : check e2411625569594 [[],[]] .smaller = true := by decide
def e2411625569690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625569690 : Closed e2411625569690 ∧ code e2411625569690 = 11207718591898 := by decide
theorem cert_e2411625569690 : check e2411625569690 [[],[]] .smaller = true := by decide
def e2411625569734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411625569734 : Closed e2411625569734 ∧ code e2411625569734 = 11207718591942 := by decide
theorem cert_e2411625569734 : check e2411625569734 [[],[]] .smaller = true := by decide
def e2411625569758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 3)))))))
theorem wire_e2411625569758 : Closed e2411625569758 ∧ code e2411625569758 = 11207718591966 := by decide
theorem cert_e2411625569758 : check e2411625569758 [[],[]] .three = true := by decide
def e2411625569774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 2)))))))
theorem wire_e2411625569774 : Closed e2411625569774 ∧ code e2411625569774 = 11207718591982 := by decide
theorem cert_e2411625569774 : check e2411625569774 [[],[]] .three = true := by decide
def e2411625569846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411625569846 : Closed e2411625569846 ∧ code e2411625569846 = 11207718592054 := by decide
theorem cert_e2411625569846 : check e2411625569846 [[],[]] .three = true := by decide
def e2411625569850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411625569850 : Closed e2411625569850 ∧ code e2411625569850 = 11207718592058 := by decide
theorem cert_e2411625569850 : check e2411625569850 [[],[]] .three = true := by decide
def e2411625569898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2411625569898 : Closed e2411625569898 ∧ code e2411625569898 = 11207718592106 := by decide
theorem cert_e2411625569898 : check e2411625569898 [[],[]] .three = true := by decide
def e2411625569934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411625569934 : Closed e2411625569934 ∧ code e2411625569934 = 11207718592142 := by decide
theorem cert_e2411625569934 : check e2411625569934 [[],[]] .three = true := by decide
def e2411625569946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625569946 : Closed e2411625569946 ∧ code e2411625569946 = 11207718592154 := by decide
theorem cert_e2411625569946 : check e2411625569946 [[],[]] .three = true := by decide
def e2411625569990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411625569990 : Closed e2411625569990 ∧ code e2411625569990 = 11207718592198 := by decide
theorem cert_e2411625569990 : check e2411625569990 [[],[]] .three = true := by decide
def e2411625570030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 2)))))))
theorem wire_e2411625570030 : Closed e2411625570030 ∧ code e2411625570030 = 11207718592238 := by decide
theorem cert_e2411625570030 : check e2411625570030 [[],[]] .three = true := by decide
def e2411625571166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2411625571166 : Closed e2411625571166 ∧ code e2411625571166 = 11207718593374 := by decide
theorem cert_e2411625571166 : check e2411625571166 [[],[]] .three = true := by decide
def e2411625571182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2411625571182 : Closed e2411625571182 ∧ code e2411625571182 = 11207718593390 := by decide
theorem cert_e2411625571182 : check e2411625571182 [[],[]] .smaller = true := by decide
def e2411625571190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2411625571190 : Closed e2411625571190 ∧ code e2411625571190 = 11207718593398 := by decide
theorem cert_e2411625571190 : check e2411625571190 [[],[]] .smaller = true := by decide
def e2411625571194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2411625571194 : Closed e2411625571194 ∧ code e2411625571194 = 11207718593402 := by decide
theorem cert_e2411625571194 : check e2411625571194 [[],[]] .three = true := by decide
def e2411625571246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2411625571246 : Closed e2411625571246 ∧ code e2411625571246 = 11207718593454 := by decide
theorem cert_e2411625571246 : check e2411625571246 [[],[]] .smaller = true := by decide
def e2411625571258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2411625571258 : Closed e2411625571258 ∧ code e2411625571258 = 11207718593466 := by decide
theorem cert_e2411625571258 : check e2411625571258 [[],[]] .smaller = true := by decide
def e2411625571286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2411625571286 : Closed e2411625571286 ∧ code e2411625571286 = 11207718593494 := by decide
theorem cert_e2411625571286 : check e2411625571286 [[],[]] .smaller = true := by decide
def e2411625571290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2411625571290 : Closed e2411625571290 ∧ code e2411625571290 = 11207718593498 := by decide
theorem cert_e2411625571290 : check e2411625571290 [[],[]] .smaller = true := by decide
def e2411625571306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 0)) (.var 0)))))))
theorem wire_e2411625571306 : Closed e2411625571306 ∧ code e2411625571306 = 11207718593514 := by decide
theorem cert_e2411625571306 : check e2411625571306 [[],[]] .three = true := by decide
def e2411625572022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e2411625572022 : Closed e2411625572022 ∧ code e2411625572022 = 11207718594230 := by decide
theorem cert_e2411625572022 : check e2411625572022 [[],[]] .smaller = true := by decide
def e2411625572054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2411625572054 : Closed e2411625572054 ∧ code e2411625572054 = 11207718594262 := by decide
theorem cert_e2411625572054 : check e2411625572054 [[],[]] .smaller = true := by decide
def e2411625572058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2411625572058 : Closed e2411625572058 ∧ code e2411625572058 = 11207718594266 := by decide
theorem cert_e2411625572058 : check e2411625572058 [[],[]] .smaller = true := by decide
def e2411625572182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2411625572182 : Closed e2411625572182 ∧ code e2411625572182 = 11207718594390 := by decide
theorem cert_e2411625572182 : check e2411625572182 [[],[]] .smaller = true := by decide
def e2411625572186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2411625572186 : Closed e2411625572186 ∧ code e2411625572186 = 11207718594394 := by decide
theorem cert_e2411625572186 : check e2411625572186 [[],[]] .smaller = true := by decide
def e2411625572202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2411625572202 : Closed e2411625572202 ∧ code e2411625572202 = 11207718594410 := by decide
theorem cert_e2411625572202 : check e2411625572202 [[],[]] .smaller = true := by decide
def e2411625572574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2411625572574 : Closed e2411625572574 ∧ code e2411625572574 = 11207718594782 := by decide
theorem cert_e2411625572574 : check e2411625572574 [[],[]] .three = true := by decide
def e2411625572590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2411625572590 : Closed e2411625572590 ∧ code e2411625572590 = 11207718594798 := by decide
theorem cert_e2411625572590 : check e2411625572590 [[],[]] .smaller = true := by decide
def e2411625572598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2411625572598 : Closed e2411625572598 ∧ code e2411625572598 = 11207718594806 := by decide
theorem cert_e2411625572598 : check e2411625572598 [[],[]] .smaller = true := by decide
def e2411625572602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2411625572602 : Closed e2411625572602 ∧ code e2411625572602 = 11207718594810 := by decide
theorem cert_e2411625572602 : check e2411625572602 [[],[]] .three = true := by decide
def e2411625572790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2411625572790 : Closed e2411625572790 ∧ code e2411625572790 = 11207718594998 := by decide
theorem cert_e2411625572790 : check e2411625572790 [[],[]] .smaller = true := by decide
def e2411625572822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2411625572822 : Closed e2411625572822 ∧ code e2411625572822 = 11207718595030 := by decide
theorem cert_e2411625572822 : check e2411625572822 [[],[]] .smaller = true := by decide
def e2411625572826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2411625572826 : Closed e2411625572826 ∧ code e2411625572826 = 11207718595034 := by decide
theorem cert_e2411625572826 : check e2411625572826 [[],[]] .smaller = true := by decide
def e2411625572926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2411625572926 : Closed e2411625572926 ∧ code e2411625572926 = 11207718595134 := by decide
theorem cert_e2411625572926 : check e2411625572926 [[],[]] .three = true := by decide
end Blc.Floor43
