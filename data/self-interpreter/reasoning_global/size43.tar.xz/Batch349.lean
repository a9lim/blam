import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419143171310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143171310 : Closed e2419143171310 ∧ code e2419143171310 = 11215236193518 := by decide
theorem cert_e2419143171310 : check e2419143171310 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143171318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143171318 : Closed e2419143171318 ∧ code e2419143171318 = 11215236193526 := by decide
theorem cert_e2419143171318 : check e2419143171318 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143172334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2419143172334 : Closed e2419143172334 ∧ code e2419143172334 = 11215236194542 := by decide
theorem cert_e2419143172334 : check e2419143172334 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143172346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2419143172346 : Closed e2419143172346 ∧ code e2419143172346 = 11215236194554 := by decide
theorem cert_e2419143172346 : check e2419143172346 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143172526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2419143172526 : Closed e2419143172526 ∧ code e2419143172526 = 11215236194734 := by decide
theorem cert_e2419143172526 : check e2419143172526 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143172718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143172718 : Closed e2419143172718 ∧ code e2419143172718 = 11215236194926 := by decide
theorem cert_e2419143172718 : check e2419143172718 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143172730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143172730 : Closed e2419143172730 ∧ code e2419143172730 = 11215236194938 := by decide
theorem cert_e2419143172730 : check e2419143172730 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143172894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2419143172894 : Closed e2419143172894 ∧ code e2419143172894 = 11215236195102 := by decide
theorem cert_e2419143172894 : check e2419143172894 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143173062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2419143173062 : Closed e2419143173062 ∧ code e2419143173062 = 11215236195270 := by decide
theorem cert_e2419143173062 : check e2419143173062 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143173678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2419143173678 : Closed e2419143173678 ∧ code e2419143173678 = 11215236195886 := by decide
theorem cert_e2419143173678 : check e2419143173678 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143173858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2419143173858 : Closed e2419143173858 ∧ code e2419143173858 = 11215236196066 := by decide
theorem cert_e2419143173858 : check e2419143173858 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143173870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2419143173870 : Closed e2419143173870 ∧ code e2419143173870 = 11215236196078 := by decide
theorem cert_e2419143173870 : check e2419143173870 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143173998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2419143173998 : Closed e2419143173998 ∧ code e2419143173998 = 11215236196206 := by decide
theorem cert_e2419143173998 : check e2419143173998 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143174006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2419143174006 : Closed e2419143174006 ∧ code e2419143174006 = 11215236196214 := by decide
theorem cert_e2419143174006 : check e2419143174006 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143174026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143174026 : Closed e2419143174026 ∧ code e2419143174026 = 11215236196234 := by decide
theorem cert_e2419143174026 : check e2419143174026 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143174050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143174050 : Closed e2419143174050 ∧ code e2419143174050 = 11215236196258 := by decide
theorem cert_e2419143174050 : check e2419143174050 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143174062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2419143174062 : Closed e2419143174062 ∧ code e2419143174062 = 11215236196270 := by decide
theorem cert_e2419143174062 : check e2419143174062 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143174070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2419143174070 : Closed e2419143174070 ∧ code e2419143174070 = 11215236196278 := by decide
theorem cert_e2419143174070 : check e2419143174070 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143174074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2419143174074 : Closed e2419143174074 ∧ code e2419143174074 = 11215236196282 := by decide
theorem cert_e2419143174074 : check e2419143174074 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143174206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2419143174206 : Closed e2419143174206 ∧ code e2419143174206 = 11215236196414 := by decide
theorem cert_e2419143174206 : check e2419143174206 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143174626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2419143174626 : Closed e2419143174626 ∧ code e2419143174626 = 11215236196834 := by decide
theorem cert_e2419143174626 : check e2419143174626 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143174638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2419143174638 : Closed e2419143174638 ∧ code e2419143174638 = 11215236196846 := by decide
theorem cert_e2419143174638 : check e2419143174638 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143175406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143175406 : Closed e2419143175406 ∧ code e2419143175406 = 11215236197614 := by decide
theorem cert_e2419143175406 : check e2419143175406 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143175414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143175414 : Closed e2419143175414 ∧ code e2419143175414 = 11215236197622 := by decide
theorem cert_e2419143175414 : check e2419143175414 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143175694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2419143175694 : Closed e2419143175694 ∧ code e2419143175694 = 11215236197902 := by decide
theorem cert_e2419143175694 : check e2419143175694 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143175706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143175706 : Closed e2419143175706 ∧ code e2419143175706 = 11215236197914 := by decide
theorem cert_e2419143175706 : check e2419143175706 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143175778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143175778 : Closed e2419143175778 ∧ code e2419143175778 = 11215236197986 := by decide
theorem cert_e2419143175778 : check e2419143175778 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143175790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143175790 : Closed e2419143175790 ∧ code e2419143175790 = 11215236197998 := by decide
theorem cert_e2419143175790 : check e2419143175790 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143175798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143175798 : Closed e2419143175798 ∧ code e2419143175798 = 11215236198006 := by decide
theorem cert_e2419143175798 : check e2419143175798 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143175802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143175802 : Closed e2419143175802 ∧ code e2419143175802 = 11215236198010 := by decide
theorem cert_e2419143175802 : check e2419143175802 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2419143176310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2419143176310 : Closed e2419143176310 ∧ code e2419143176310 = 11215236198518 := by decide
theorem cert_e2419143176310 : check e2419143176310 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143176314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2419143176314 : Closed e2419143176314 ∧ code e2419143176314 = 11215236198522 := by decide
theorem cert_e2419143176314 : check e2419143176314 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143176406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2419143176406 : Closed e2419143176406 ∧ code e2419143176406 = 11215236198614 := by decide
theorem cert_e2419143176406 : checkPay e2419143176406 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143176502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143176502 : Closed e2419143176502 ∧ code e2419143176502 = 11215236198710 := by decide
theorem cert_e2419143176502 : check e2419143176502 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143176506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143176506 : Closed e2419143176506 ∧ code e2419143176506 = 11215236198714 := by decide
theorem cert_e2419143176506 : check e2419143176506 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143176590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2419143176590 : Closed e2419143176590 ∧ code e2419143176590 = 11215236198798 := by decide
theorem cert_e2419143176590 : check e2419143176590 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143176646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2419143176646 : Closed e2419143176646 ∧ code e2419143176646 = 11215236198854 := by decide
theorem cert_e2419143176646 : checkPay e2419143176646 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] 0 [] = true := by decide
def e2419143176982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2419143176982 : Closed e2419143176982 ∧ code e2419143176982 = 11215236199190 := by decide
theorem cert_e2419143176982 : check e2419143176982 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143177058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2419143177058 : Closed e2419143177058 ∧ code e2419143177058 = 11215236199266 := by decide
theorem cert_e2419143177058 : check e2419143177058 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e2419143177070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2419143177070 : Closed e2419143177070 ∧ code e2419143177070 = 11215236199278 := by decide
theorem cert_e2419143177070 : checkPay e2419143177070 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] 0 [] = true := by decide
def e2419143177078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2419143177078 : Closed e2419143177078 ∧ code e2419143177078 = 11215236199286 := by decide
theorem cert_e2419143177078 : check e2419143177078 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143177098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143177098 : Closed e2419143177098 ∧ code e2419143177098 = 11215236199306 := by decide
theorem cert_e2419143177098 : checkPay e2419143177098 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e2419143177122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143177122 : Closed e2419143177122 ∧ code e2419143177122 = 11215236199330 := by decide
theorem cert_e2419143177122 : check e2419143177122 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143177134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2419143177134 : Closed e2419143177134 ∧ code e2419143177134 = 11215236199342 := by decide
theorem cert_e2419143177134 : check e2419143177134 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143177142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2419143177142 : Closed e2419143177142 ∧ code e2419143177142 = 11215236199350 := by decide
theorem cert_e2419143177142 : check e2419143177142 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143177146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2419143177146 : Closed e2419143177146 ∧ code e2419143177146 = 11215236199354 := by decide
theorem cert_e2419143177146 : check e2419143177146 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143177174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2419143177174 : Closed e2419143177174 ∧ code e2419143177174 = 11215236199382 := by decide
theorem cert_e2419143177174 : check e2419143177174 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143177178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2419143177178 : Closed e2419143177178 ∧ code e2419143177178 = 11215236199386 := by decide
theorem cert_e2419143177178 : check e2419143177178 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143177246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2419143177246 : Closed e2419143177246 ∧ code e2419143177246 = 11215236199454 := by decide
theorem cert_e2419143177246 : check e2419143177246 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143177442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2419143177442 : Closed e2419143177442 ∧ code e2419143177442 = 11215236199650 := by decide
theorem cert_e2419143177442 : check e2419143177442 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143177454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143177454 : Closed e2419143177454 ∧ code e2419143177454 = 11215236199662 := by decide
theorem cert_e2419143177454 : check e2419143177454 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143177462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143177462 : Closed e2419143177462 ∧ code e2419143177462 = 11215236199670 := by decide
theorem cert_e2419143177462 : check e2419143177462 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2419143177742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2419143177742 : Closed e2419143177742 ∧ code e2419143177742 = 11215236199950 := by decide
theorem cert_e2419143177742 : check e2419143177742 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143177754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143177754 : Closed e2419143177754 ∧ code e2419143177754 = 11215236199962 := by decide
theorem cert_e2419143177754 : checkPay e2419143177754 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e2419143177826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143177826 : Closed e2419143177826 ∧ code e2419143177826 = 11215236200034 := by decide
theorem cert_e2419143177826 : check e2419143177826 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2419143177838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143177838 : Closed e2419143177838 ∧ code e2419143177838 = 11215236200046 := by decide
theorem cert_e2419143177838 : check e2419143177838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .identityHead = true := by decide
def e2419143177846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143177846 : Closed e2419143177846 ∧ code e2419143177846 = 11215236200054 := by decide
theorem cert_e2419143177846 : check e2419143177846 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143177850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143177850 : Closed e2419143177850 ∧ code e2419143177850 = 11215236200058 := by decide
theorem cert_e2419143177850 : check e2419143177850 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2419143178038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143178038 : Closed e2419143178038 ∧ code e2419143178038 = 11215236200246 := by decide
theorem cert_e2419143178038 : check e2419143178038 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143178042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143178042 : Closed e2419143178042 ∧ code e2419143178042 = 11215236200250 := by decide
theorem cert_e2419143178042 : check e2419143178042 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143181230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2419143181230 : Closed e2419143181230 ∧ code e2419143181230 = 11215236203438 := by decide
theorem cert_e2419143181230 : check e2419143181230 [[],[]] .sourceHead = true := by decide
def e2419143181242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2419143181242 : Closed e2419143181242 ∧ code e2419143181242 = 11215236203450 := by decide
theorem cert_e2419143181242 : check e2419143181242 [[],[]] .sourceHead = true := by decide
def e2419143181290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 0))))))
theorem wire_e2419143181290 : Closed e2419143181290 ∧ code e2419143181290 = 11215236203498 := by decide
theorem cert_e2419143181290 : check e2419143181290 [[],[]] .sourceHead = true := by decide
def e2419143181998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2419143181998 : Closed e2419143181998 ∧ code e2419143181998 = 11215236204206 := by decide
theorem cert_e2419143181998 : check e2419143181998 [[],[]] .sourceHead = true := by decide
def e2419143182010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2419143182010 : Closed e2419143182010 ∧ code e2419143182010 = 11215236204218 := by decide
theorem cert_e2419143182010 : check e2419143182010 [[],[]] .sourceHead = true := by decide
def e2419143182766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2419143182766 : Closed e2419143182766 ∧ code e2419143182766 = 11215236204974 := by decide
theorem cert_e2419143182766 : check e2419143182766 [[],[]] .sourceHead = true := by decide
def e2419143182778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2419143182778 : Closed e2419143182778 ∧ code e2419143182778 = 11215236204986 := by decide
theorem cert_e2419143182778 : check e2419143182778 [[],[]] .sourceHead = true := by decide
def e2419143182826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2419143182826 : Closed e2419143182826 ∧ code e2419143182826 = 11215236205034 := by decide
theorem cert_e2419143182826 : check e2419143182826 [[],[]] .sourceHead = true := by decide
def e2419143182958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143182958 : Closed e2419143182958 ∧ code e2419143182958 = 11215236205166 := by decide
theorem cert_e2419143182958 : check e2419143182958 [[],[]] .sourceHead = true := by decide
def e2419143182970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143182970 : Closed e2419143182970 ∧ code e2419143182970 = 11215236205178 := by decide
theorem cert_e2419143182970 : check e2419143182970 [[],[]] .sourceHead = true := by decide
def e2419143183258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143183258 : Closed e2419143183258 ∧ code e2419143183258 = 11215236205466 := by decide
theorem cert_e2419143183258 : check e2419143183258 [[],[]] .sourceHead = true := by decide
def e2419143183470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2419143183470 : Closed e2419143183470 ∧ code e2419143183470 = 11215236205678 := by decide
theorem cert_e2419143183470 : check e2419143183470 [[],[]] .sourceHead = true := by decide
def e2419143183482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2419143183482 : Closed e2419143183482 ∧ code e2419143183482 = 11215236205690 := by decide
theorem cert_e2419143183482 : check e2419143183482 [[],[]] .sourceHead = true := by decide
def e2419143183646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2419143183646 : Closed e2419143183646 ∧ code e2419143183646 = 11215236205854 := by decide
theorem cert_e2419143183646 : check e2419143183646 [[],[]] .sourceHead = true := by decide
def e2419143183814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2419143183814 : Closed e2419143183814 ∧ code e2419143183814 = 11215236206022 := by decide
theorem cert_e2419143183814 : check e2419143183814 [[],[]] .sourceHead = true := by decide
def e2419143184154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2419143184154 : Closed e2419143184154 ∧ code e2419143184154 = 11215236206362 := by decide
theorem cert_e2419143184154 : check e2419143184154 [[],[]] .sourceHead = true := by decide
def e2419143184198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2419143184198 : Closed e2419143184198 ∧ code e2419143184198 = 11215236206406 := by decide
theorem cert_e2419143184198 : check e2419143184198 [[],[]] .sourceHead = true := by decide
def e2419143186606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2419143186606 : Closed e2419143186606 ∧ code e2419143186606 = 11215236208814 := by decide
theorem cert_e2419143186606 : check e2419143186606 [[],[]] .sourceHead = true := by decide
def e2419143186618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2419143186618 : Closed e2419143186618 ∧ code e2419143186618 = 11215236208826 := by decide
theorem cert_e2419143186618 : check e2419143186618 [[],[]] .sourceHead = true := by decide
def e2419143186990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2419143186990 : Closed e2419143186990 ∧ code e2419143186990 = 11215236209198 := by decide
theorem cert_e2419143186990 : check e2419143186990 [[],[]] .sourceHead = true := by decide
def e2419143187170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2419143187170 : Closed e2419143187170 ∧ code e2419143187170 = 11215236209378 := by decide
theorem cert_e2419143187170 : check e2419143187170 [[],[]] .sourceHead = true := by decide
def e2419143187182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2419143187182 : Closed e2419143187182 ∧ code e2419143187182 = 11215236209390 := by decide
theorem cert_e2419143187182 : check e2419143187182 [[],[]] .sourceHead = true := by decide
def e2419143187310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2419143187310 : Closed e2419143187310 ∧ code e2419143187310 = 11215236209518 := by decide
theorem cert_e2419143187310 : check e2419143187310 [[],[]] .sourceHead = true := by decide
def e2419143187318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2419143187318 : Closed e2419143187318 ∧ code e2419143187318 = 11215236209526 := by decide
theorem cert_e2419143187318 : check e2419143187318 [[],[]] .sourceHead = true := by decide
def e2419143187338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2419143187338 : Closed e2419143187338 ∧ code e2419143187338 = 11215236209546 := by decide
theorem cert_e2419143187338 : check e2419143187338 [[],[]] .sourceHead = true := by decide
def e2419143187362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2419143187362 : Closed e2419143187362 ∧ code e2419143187362 = 11215236209570 := by decide
theorem cert_e2419143187362 : check e2419143187362 [[],[]] .sourceHead = true := by decide
def e2419143187374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2419143187374 : Closed e2419143187374 ∧ code e2419143187374 = 11215236209582 := by decide
theorem cert_e2419143187374 : check e2419143187374 [[],[]] .sourceHead = true := by decide
def e2419143187382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2419143187382 : Closed e2419143187382 ∧ code e2419143187382 = 11215236209590 := by decide
theorem cert_e2419143187382 : check e2419143187382 [[],[]] .sourceHead = true := by decide
def e2419143187386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2419143187386 : Closed e2419143187386 ∧ code e2419143187386 = 11215236209594 := by decide
theorem cert_e2419143187386 : check e2419143187386 [[],[]] .sourceHead = true := by decide
def e2419143187822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2419143187822 : Closed e2419143187822 ∧ code e2419143187822 = 11215236210030 := by decide
theorem cert_e2419143187822 : check e2419143187822 [[],[]] .sourceHead = true := by decide
def e2419143187830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2419143187830 : Closed e2419143187830 ∧ code e2419143187830 = 11215236210038 := by decide
theorem cert_e2419143187830 : check e2419143187830 [[],[]] .sourceHead = true := by decide
def e2419143187886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2419143187886 : Closed e2419143187886 ∧ code e2419143187886 = 11215236210094 := by decide
theorem cert_e2419143187886 : check e2419143187886 [[],[]] .sourceHead = true := by decide
def e2419143187898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2419143187898 : Closed e2419143187898 ∧ code e2419143187898 = 11215236210106 := by decide
theorem cert_e2419143187898 : check e2419143187898 [[],[]] .sourceHead = true := by decide
def e2419143187926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2419143187926 : Closed e2419143187926 ∧ code e2419143187926 = 11215236210134 := by decide
theorem cert_e2419143187926 : check e2419143187926 [[],[]] .sourceHead = true := by decide
def e2419143187930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2419143187930 : Closed e2419143187930 ∧ code e2419143187930 = 11215236210138 := by decide
theorem cert_e2419143187930 : check e2419143187930 [[],[]] .sourceHead = true := by decide
def e2419143188010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2419143188010 : Closed e2419143188010 ∧ code e2419143188010 = 11215236210218 := by decide
theorem cert_e2419143188010 : check e2419143188010 [[],[]] .sourceHead = true := by decide
def e2419143188106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2419143188106 : Closed e2419143188106 ∧ code e2419143188106 = 11215236210314 := by decide
theorem cert_e2419143188106 : check e2419143188106 [[],[]] .sourceHead = true := by decide
def e2419143188130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2419143188130 : Closed e2419143188130 ∧ code e2419143188130 = 11215236210338 := by decide
theorem cert_e2419143188130 : check e2419143188130 [[],[]] .sourceHead = true := by decide
def e2419143188142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2419143188142 : Closed e2419143188142 ∧ code e2419143188142 = 11215236210350 := by decide
theorem cert_e2419143188142 : check e2419143188142 [[],[]] .sourceHead = true := by decide
def e2419143188150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2419143188150 : Closed e2419143188150 ∧ code e2419143188150 = 11215236210358 := by decide
theorem cert_e2419143188150 : check e2419143188150 [[],[]] .sourceHead = true := by decide
def e2419143188154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2419143188154 : Closed e2419143188154 ∧ code e2419143188154 = 11215236210362 := by decide
theorem cert_e2419143188154 : check e2419143188154 [[],[]] .sourceHead = true := by decide
def e2419143188182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2419143188182 : Closed e2419143188182 ∧ code e2419143188182 = 11215236210390 := by decide
theorem cert_e2419143188182 : check e2419143188182 [[],[]] .sourceHead = true := by decide
def e2419143188186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2419143188186 : Closed e2419143188186 ∧ code e2419143188186 = 11215236210394 := by decide
theorem cert_e2419143188186 : check e2419143188186 [[],[]] .sourceHead = true := by decide
def e2419143188202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2419143188202 : Closed e2419143188202 ∧ code e2419143188202 = 11215236210410 := by decide
theorem cert_e2419143188202 : check e2419143188202 [[],[]] .sourceHead = true := by decide
def e2419143188718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2419143188718 : Closed e2419143188718 ∧ code e2419143188718 = 11215236210926 := by decide
theorem cert_e2419143188718 : check e2419143188718 [[],[]] .sourceHead = true := by decide
def e2419143188730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2419143188730 : Closed e2419143188730 ∧ code e2419143188730 = 11215236210938 := by decide
theorem cert_e2419143188730 : check e2419143188730 [[],[]] .sourceHead = true := by decide
def e2419143188910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2419143188910 : Closed e2419143188910 ∧ code e2419143188910 = 11215236211118 := by decide
theorem cert_e2419143188910 : check e2419143188910 [[],[]] .sourceHead = true := by decide
def e2419143189102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143189102 : Closed e2419143189102 ∧ code e2419143189102 = 11215236211310 := by decide
theorem cert_e2419143189102 : check e2419143189102 [[],[]] .sourceHead = true := by decide
def e2419143189114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143189114 : Closed e2419143189114 ∧ code e2419143189114 = 11215236211322 := by decide
theorem cert_e2419143189114 : check e2419143189114 [[],[]] .sourceHead = true := by decide
def e2419143189278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2419143189278 : Closed e2419143189278 ∧ code e2419143189278 = 11215236211486 := by decide
theorem cert_e2419143189278 : check e2419143189278 [[],[]] .sourceHead = true := by decide
def e2419143189446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2419143189446 : Closed e2419143189446 ∧ code e2419143189446 = 11215236211654 := by decide
theorem cert_e2419143189446 : check e2419143189446 [[],[]] .sourceHead = true := by decide
def e2419143190062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2419143190062 : Closed e2419143190062 ∧ code e2419143190062 = 11215236212270 := by decide
theorem cert_e2419143190062 : check e2419143190062 [[],[]] .sourceHead = true := by decide
def e2419143190242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2419143190242 : Closed e2419143190242 ∧ code e2419143190242 = 11215236212450 := by decide
theorem cert_e2419143190242 : check e2419143190242 [[],[]] .sourceHead = true := by decide
def e2419143190254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2419143190254 : Closed e2419143190254 ∧ code e2419143190254 = 11215236212462 := by decide
theorem cert_e2419143190254 : check e2419143190254 [[],[]] .sourceHead = true := by decide
def e2419143190382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2419143190382 : Closed e2419143190382 ∧ code e2419143190382 = 11215236212590 := by decide
theorem cert_e2419143190382 : check e2419143190382 [[],[]] .sourceHead = true := by decide
def e2419143190390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2419143190390 : Closed e2419143190390 ∧ code e2419143190390 = 11215236212598 := by decide
theorem cert_e2419143190390 : check e2419143190390 [[],[]] .sourceHead = true := by decide
def e2419143190410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143190410 : Closed e2419143190410 ∧ code e2419143190410 = 11215236212618 := by decide
theorem cert_e2419143190410 : check e2419143190410 [[],[]] .sourceHead = true := by decide
def e2419143190434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143190434 : Closed e2419143190434 ∧ code e2419143190434 = 11215236212642 := by decide
theorem cert_e2419143190434 : check e2419143190434 [[],[]] .sourceHead = true := by decide
def e2419143190446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2419143190446 : Closed e2419143190446 ∧ code e2419143190446 = 11215236212654 := by decide
theorem cert_e2419143190446 : check e2419143190446 [[],[]] .sourceHead = true := by decide
def e2419143190454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2419143190454 : Closed e2419143190454 ∧ code e2419143190454 = 11215236212662 := by decide
theorem cert_e2419143190454 : check e2419143190454 [[],[]] .sourceHead = true := by decide
def e2419143190458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2419143190458 : Closed e2419143190458 ∧ code e2419143190458 = 11215236212666 := by decide
theorem cert_e2419143190458 : check e2419143190458 [[],[]] .sourceHead = true := by decide
def e2419143190590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2419143190590 : Closed e2419143190590 ∧ code e2419143190590 = 11215236212798 := by decide
theorem cert_e2419143190590 : check e2419143190590 [[],[]] .sourceHead = true := by decide
def e2419143191010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2419143191010 : Closed e2419143191010 ∧ code e2419143191010 = 11215236213218 := by decide
theorem cert_e2419143191010 : check e2419143191010 [[],[]] .sourceHead = true := by decide
def e2419143191022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2419143191022 : Closed e2419143191022 ∧ code e2419143191022 = 11215236213230 := by decide
theorem cert_e2419143191022 : check e2419143191022 [[],[]] .sourceHead = true := by decide
def e2419143191790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143191790 : Closed e2419143191790 ∧ code e2419143191790 = 11215236213998 := by decide
theorem cert_e2419143191790 : check e2419143191790 [[],[]] .sourceHead = true := by decide
def e2419143191798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143191798 : Closed e2419143191798 ∧ code e2419143191798 = 11215236214006 := by decide
theorem cert_e2419143191798 : check e2419143191798 [[],[]] .sourceHead = true := by decide
def e2419143192078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2419143192078 : Closed e2419143192078 ∧ code e2419143192078 = 11215236214286 := by decide
theorem cert_e2419143192078 : check e2419143192078 [[],[]] .sourceHead = true := by decide
def e2419143192090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143192090 : Closed e2419143192090 ∧ code e2419143192090 = 11215236214298 := by decide
theorem cert_e2419143192090 : check e2419143192090 [[],[]] .sourceHead = true := by decide
def e2419143192162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143192162 : Closed e2419143192162 ∧ code e2419143192162 = 11215236214370 := by decide
theorem cert_e2419143192162 : check e2419143192162 [[],[]] .sourceHead = true := by decide
def e2419143192174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143192174 : Closed e2419143192174 ∧ code e2419143192174 = 11215236214382 := by decide
theorem cert_e2419143192174 : check e2419143192174 [[],[]] .sourceHead = true := by decide
def e2419143192182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143192182 : Closed e2419143192182 ∧ code e2419143192182 = 11215236214390 := by decide
theorem cert_e2419143192182 : check e2419143192182 [[],[]] .sourceHead = true := by decide
def e2419143192186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143192186 : Closed e2419143192186 ∧ code e2419143192186 = 11215236214394 := by decide
theorem cert_e2419143192186 : check e2419143192186 [[],[]] .sourceHead = true := by decide
def e2419143193454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2419143193454 : Closed e2419143193454 ∧ code e2419143193454 = 11215236215662 := by decide
theorem cert_e2419143193454 : check e2419143193454 [[],[]] .sourceHead = true := by decide
def e2419143193462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2419143193462 : Closed e2419143193462 ∧ code e2419143193462 = 11215236215670 := by decide
theorem cert_e2419143193462 : check e2419143193462 [[],[]] .sourceHead = true := by decide
def e2419143193518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2419143193518 : Closed e2419143193518 ∧ code e2419143193518 = 11215236215726 := by decide
theorem cert_e2419143193518 : check e2419143193518 [[],[]] .sourceHead = true := by decide
def e2419143193530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2419143193530 : Closed e2419143193530 ∧ code e2419143193530 = 11215236215738 := by decide
theorem cert_e2419143193530 : check e2419143193530 [[],[]] .sourceHead = true := by decide
def e2419143193558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2419143193558 : Closed e2419143193558 ∧ code e2419143193558 = 11215236215766 := by decide
theorem cert_e2419143193558 : check e2419143193558 [[],[]] .sourceHead = true := by decide
def e2419143193562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2419143193562 : Closed e2419143193562 ∧ code e2419143193562 = 11215236215770 := by decide
theorem cert_e2419143193562 : check e2419143193562 [[],[]] .sourceHead = true := by decide
def e2419143193838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143193838 : Closed e2419143193838 ∧ code e2419143193838 = 11215236216046 := by decide
theorem cert_e2419143193838 : check e2419143193838 [[],[]] .sourceHead = true := by decide
def e2419143193846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143193846 : Closed e2419143193846 ∧ code e2419143193846 = 11215236216054 := by decide
theorem cert_e2419143193846 : check e2419143193846 [[],[]] .sourceHead = true := by decide
def e2419143194222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143194222 : Closed e2419143194222 ∧ code e2419143194222 = 11215236216430 := by decide
theorem cert_e2419143194222 : check e2419143194222 [[],[]] .sourceHead = true := by decide
def e2419143194234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143194234 : Closed e2419143194234 ∧ code e2419143194234 = 11215236216442 := by decide
theorem cert_e2419143194234 : check e2419143194234 [[],[]] .sourceHead = true := by decide
def e2419143194422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143194422 : Closed e2419143194422 ∧ code e2419143194422 = 11215236216630 := by decide
theorem cert_e2419143194422 : check e2419143194422 [[],[]] .sourceHead = true := by decide
def e2419143194426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143194426 : Closed e2419143194426 ∧ code e2419143194426 = 11215236216634 := by decide
theorem cert_e2419143194426 : check e2419143194426 [[],[]] .sourceHead = true := by decide
def e2419143194682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2419143194682 : Closed e2419143194682 ∧ code e2419143194682 = 11215236216890 := by decide
theorem cert_e2419143194682 : check e2419143194682 [[],[]] .sourceHead = true := by decide
def e2419143194730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2419143194730 : Closed e2419143194730 ∧ code e2419143194730 = 11215236216938 := by decide
theorem cert_e2419143194730 : check e2419143194730 [[],[]] .sourceHead = true := by decide
def e2419143194778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143194778 : Closed e2419143194778 ∧ code e2419143194778 = 11215236216986 := by decide
theorem cert_e2419143194778 : check e2419143194778 [[],[]] .sourceHead = true := by decide
def e2419143194822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2419143194822 : Closed e2419143194822 ∧ code e2419143194822 = 11215236217030 := by decide
theorem cert_e2419143194822 : check e2419143194822 [[],[]] .sourceHead = true := by decide
def e2419143195018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143195018 : Closed e2419143195018 ∧ code e2419143195018 = 11215236217226 := by decide
theorem cert_e2419143195018 : check e2419143195018 [[],[]] .sourceHead = true := by decide
def e2419143195042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143195042 : Closed e2419143195042 ∧ code e2419143195042 = 11215236217250 := by decide
theorem cert_e2419143195042 : check e2419143195042 [[],[]] .sourceHead = true := by decide
def e2419143195054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2419143195054 : Closed e2419143195054 ∧ code e2419143195054 = 11215236217262 := by decide
theorem cert_e2419143195054 : check e2419143195054 [[],[]] .sourceHead = true := by decide
def e2419143195062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2419143195062 : Closed e2419143195062 ∧ code e2419143195062 = 11215236217270 := by decide
theorem cert_e2419143195062 : check e2419143195062 [[],[]] .sourceHead = true := by decide
def e2419143195066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2419143195066 : Closed e2419143195066 ∧ code e2419143195066 = 11215236217274 := by decide
theorem cert_e2419143195066 : check e2419143195066 [[],[]] .sourceHead = true := by decide
def e2419143195094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2419143195094 : Closed e2419143195094 ∧ code e2419143195094 = 11215236217302 := by decide
theorem cert_e2419143195094 : check e2419143195094 [[],[]] .sourceHead = true := by decide
def e2419143195098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2419143195098 : Closed e2419143195098 ∧ code e2419143195098 = 11215236217306 := by decide
theorem cert_e2419143195098 : check e2419143195098 [[],[]] .sourceHead = true := by decide
def e2419143195114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2419143195114 : Closed e2419143195114 ∧ code e2419143195114 = 11215236217322 := by decide
theorem cert_e2419143195114 : check e2419143195114 [[],[]] .sourceHead = true := by decide
def e2419143195150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2419143195150 : Closed e2419143195150 ∧ code e2419143195150 = 11215236217358 := by decide
theorem cert_e2419143195150 : check e2419143195150 [[],[]] .sourceHead = true := by decide
def e2419143195162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143195162 : Closed e2419143195162 ∧ code e2419143195162 = 11215236217370 := by decide
theorem cert_e2419143195162 : check e2419143195162 [[],[]] .sourceHead = true := by decide
def e2419143195234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143195234 : Closed e2419143195234 ∧ code e2419143195234 = 11215236217442 := by decide
theorem cert_e2419143195234 : check e2419143195234 [[],[]] .sourceHead = true := by decide
def e2419143195246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143195246 : Closed e2419143195246 ∧ code e2419143195246 = 11215236217454 := by decide
theorem cert_e2419143195246 : check e2419143195246 [[],[]] .sourceHead = true := by decide
end Blc.Floor43
