import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393371236602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2393371236602 : Closed e2393371236602 ∧ code e2393371236602 = 11189464258810 := by decide
theorem cert_e2393371236602 : check e2393371236602 [[],[.left],[]] .chain = true := by decide
def e2393371236782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2393371236782 : Closed e2393371236782 ∧ code e2393371236782 = 11189464258990 := by decide
theorem cert_e2393371236782 : check e2393371236782 [[],[.left],[]] .chain = true := by decide
def e2393371236794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2393371236794 : Closed e2393371236794 ∧ code e2393371236794 = 11189464259002 := by decide
theorem cert_e2393371236794 : check e2393371236794 [[],[.left],[]] .chain = true := by decide
def e2393371236842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2393371236842 : Closed e2393371236842 ∧ code e2393371236842 = 11189464259050 := by decide
theorem cert_e2393371236842 : check e2393371236842 [[],[.left],[]] .chain = true := by decide
def e2393371236926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2393371236926 : Closed e2393371236926 ∧ code e2393371236926 = 11189464259134 := by decide
theorem cert_e2393371236926 : check e2393371236926 [[],[.left],[]] .chain = true := by decide
def e2393371236974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393371236974 : Closed e2393371236974 ∧ code e2393371236974 = 11189464259182 := by decide
theorem cert_e2393371236974 : check e2393371236974 [[],[.left],[]] .chain = true := by decide
def e2393371236986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393371236986 : Closed e2393371236986 ∧ code e2393371236986 = 11189464259194 := by decide
theorem cert_e2393371236986 : check e2393371236986 [[],[.left],[]] .chain = true := by decide
def e2393371237150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2393371237150 : Closed e2393371237150 ∧ code e2393371237150 = 11189464259358 := by decide
theorem cert_e2393371237150 : check e2393371237150 [[],[.left],[]] .chain = true := by decide
def e2393371237262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2393371237262 : Closed e2393371237262 ∧ code e2393371237262 = 11189464259470 := by decide
theorem cert_e2393371237262 : check e2393371237262 [[],[.left],[]] .chain = true := by decide
def e2393371237274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371237274 : Closed e2393371237274 ∧ code e2393371237274 = 11189464259482 := by decide
theorem cert_e2393371237274 : check e2393371237274 [[],[.left],[]] .chain = true := by decide
def e2393371237318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2393371237318 : Closed e2393371237318 ∧ code e2393371237318 = 11189464259526 := by decide
theorem cert_e2393371237318 : check e2393371237318 [[],[.left],[]] .chain = true := by decide
def e2393371237342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 3)))))))
theorem wire_e2393371237342 : Closed e2393371237342 ∧ code e2393371237342 = 11189464259550 := by decide
theorem cert_e2393371237342 : check e2393371237342 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2393371237494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2393371237494 : Closed e2393371237494 ∧ code e2393371237494 = 11189464259702 := by decide
theorem cert_e2393371237494 : check e2393371237494 [[],[.left],[]] .chain = true := by decide
def e2393371237590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2393371237590 : Closed e2393371237590 ∧ code e2393371237590 = 11189464259798 := by decide
theorem cert_e2393371237590 : check e2393371237590 [[],[.left],[]] .chain = true := by decide
def e2393371237594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2393371237594 : Closed e2393371237594 ∧ code e2393371237594 = 11189464259802 := by decide
theorem cert_e2393371237594 : check e2393371237594 [[],[.left],[]] .chain = true := by decide
def e2393371237610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2393371237610 : Closed e2393371237610 ∧ code e2393371237610 = 11189464259818 := by decide
theorem cert_e2393371237610 : check e2393371237610 [[],[.left],[]] .chain = true := by decide
def e2393371237686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371237686 : Closed e2393371237686 ∧ code e2393371237686 = 11189464259894 := by decide
theorem cert_e2393371237686 : check e2393371237686 [[],[.left],[]] .chain = true := by decide
def e2393371237690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371237690 : Closed e2393371237690 ∧ code e2393371237690 = 11189464259898 := by decide
theorem cert_e2393371237690 : check e2393371237690 [[],[.left],[]] .chain = true := by decide
def e2393371237774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2393371237774 : Closed e2393371237774 ∧ code e2393371237774 = 11189464259982 := by decide
theorem cert_e2393371237774 : check e2393371237774 [[],[.left],[]] .chain = true := by decide
def e2393371237786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371237786 : Closed e2393371237786 ∧ code e2393371237786 = 11189464259994 := by decide
theorem cert_e2393371237786 : check e2393371237786 [[],[.left],[]] .chain = true := by decide
def e2393371237854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 3)))))))
theorem wire_e2393371237854 : Closed e2393371237854 ∧ code e2393371237854 = 11189464260062 := by decide
theorem cert_e2393371237854 : check e2393371237854 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371237870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 2)))))))
theorem wire_e2393371237870 : Closed e2393371237870 ∧ code e2393371237870 = 11189464260078 := by decide
theorem cert_e2393371237870 : check e2393371237870 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371237942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2393371237942 : Closed e2393371237942 ∧ code e2393371237942 = 11189464260150 := by decide
theorem cert_e2393371237942 : check e2393371237942 [[],[.left],[]] .chain = true := by decide
def e2393371237946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2393371237946 : Closed e2393371237946 ∧ code e2393371237946 = 11189464260154 := by decide
theorem cert_e2393371237946 : check e2393371237946 [[],[.left],[]] .chain = true := by decide
def e2393371238030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2393371238030 : Closed e2393371238030 ∧ code e2393371238030 = 11189464260238 := by decide
theorem cert_e2393371238030 : check e2393371238030 [[],[.left],[]] .chain = true := by decide
def e2393371238086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2393371238086 : Closed e2393371238086 ∧ code e2393371238086 = 11189464260294 := by decide
theorem cert_e2393371238086 : check e2393371238086 [[],[.left],[]] .chain = true := by decide
def e2393371238110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 3)))))))
theorem wire_e2393371238110 : Closed e2393371238110 ∧ code e2393371238110 = 11189464260318 := by decide
theorem cert_e2393371238110 : check e2393371238110 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371238126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 2)))))))
theorem wire_e2393371238126 : Closed e2393371238126 ∧ code e2393371238126 = 11189464260334 := by decide
theorem cert_e2393371238126 : check e2393371238126 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371238134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 1)))))))
theorem wire_e2393371238134 : Closed e2393371238134 ∧ code e2393371238134 = 11189464260342 := by decide
theorem cert_e2393371238134 : check e2393371238134 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371239262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2393371239262 : Closed e2393371239262 ∧ code e2393371239262 = 11189464261470 := by decide
theorem cert_e2393371239262 : check e2393371239262 [[],[.left],[]] .chain = true := by decide
def e2393371239278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2393371239278 : Closed e2393371239278 ∧ code e2393371239278 = 11189464261486 := by decide
theorem cert_e2393371239278 : check e2393371239278 [[],[.left],[]] .chain = true := by decide
def e2393371239286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2393371239286 : Closed e2393371239286 ∧ code e2393371239286 = 11189464261494 := by decide
theorem cert_e2393371239286 : check e2393371239286 [[],[.left],[]] .chain = true := by decide
def e2393371239290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2393371239290 : Closed e2393371239290 ∧ code e2393371239290 = 11189464261498 := by decide
theorem cert_e2393371239290 : check e2393371239290 [[],[.left],[]] .chain = true := by decide
def e2393371239342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2393371239342 : Closed e2393371239342 ∧ code e2393371239342 = 11189464261550 := by decide
theorem cert_e2393371239342 : check e2393371239342 [[],[.left],[]] .chain = true := by decide
def e2393371239354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2393371239354 : Closed e2393371239354 ∧ code e2393371239354 = 11189464261562 := by decide
theorem cert_e2393371239354 : check e2393371239354 [[],[.left],[]] .chain = true := by decide
def e2393371239382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2393371239382 : Closed e2393371239382 ∧ code e2393371239382 = 11189464261590 := by decide
theorem cert_e2393371239382 : check e2393371239382 [[],[.left],[]] .chain = true := by decide
def e2393371239386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2393371239386 : Closed e2393371239386 ∧ code e2393371239386 = 11189464261594 := by decide
theorem cert_e2393371239386 : check e2393371239386 [[],[.left],[]] .chain = true := by decide
def e2393371239402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 0)))))))
theorem wire_e2393371239402 : Closed e2393371239402 ∧ code e2393371239402 = 11189464261610 := by decide
theorem cert_e2393371239402 : check e2393371239402 [[],[.left],[]] .chain = true := by decide
def e2393371240110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2393371240110 : Closed e2393371240110 ∧ code e2393371240110 = 11189464262318 := by decide
theorem cert_e2393371240110 : check e2393371240110 [[],[.left],[]] .chain = true := by decide
def e2393371240122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2393371240122 : Closed e2393371240122 ∧ code e2393371240122 = 11189464262330 := by decide
theorem cert_e2393371240122 : check e2393371240122 [[],[.left],[]] .chain = true := by decide
def e2393371240170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2393371240170 : Closed e2393371240170 ∧ code e2393371240170 = 11189464262378 := by decide
theorem cert_e2393371240170 : check e2393371240170 [[],[.left],[]] .chain = true := by decide
def e2393371240362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2393371240362 : Closed e2393371240362 ∧ code e2393371240362 = 11189464262570 := by decide
theorem cert_e2393371240362 : check e2393371240362 [[],[.left],[]] .chain = true := by decide
def e2393371240670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2393371240670 : Closed e2393371240670 ∧ code e2393371240670 = 11189464262878 := by decide
theorem cert_e2393371240670 : check e2393371240670 [[],[.left],[]] .chain = true := by decide
def e2393371240686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2393371240686 : Closed e2393371240686 ∧ code e2393371240686 = 11189464262894 := by decide
theorem cert_e2393371240686 : check e2393371240686 [[],[.left],[]] .chain = true := by decide
def e2393371240694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2393371240694 : Closed e2393371240694 ∧ code e2393371240694 = 11189464262902 := by decide
theorem cert_e2393371240694 : check e2393371240694 [[],[.left],[]] .chain = true := by decide
def e2393371240698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2393371240698 : Closed e2393371240698 ∧ code e2393371240698 = 11189464262906 := by decide
theorem cert_e2393371240698 : check e2393371240698 [[],[.left],[]] .chain = true := by decide
def e2393371240878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2393371240878 : Closed e2393371240878 ∧ code e2393371240878 = 11189464263086 := by decide
theorem cert_e2393371240878 : check e2393371240878 [[],[.left],[]] .chain = true := by decide
def e2393371240890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2393371240890 : Closed e2393371240890 ∧ code e2393371240890 = 11189464263098 := by decide
theorem cert_e2393371240890 : check e2393371240890 [[],[.left],[]] .chain = true := by decide
def e2393371240938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2393371240938 : Closed e2393371240938 ∧ code e2393371240938 = 11189464263146 := by decide
theorem cert_e2393371240938 : check e2393371240938 [[],[.left],[]] .chain = true := by decide
def e2393371241022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2393371241022 : Closed e2393371241022 ∧ code e2393371241022 = 11189464263230 := by decide
theorem cert_e2393371241022 : check e2393371241022 [[],[.left],[]] .chain = true := by decide
def e2393371241070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393371241070 : Closed e2393371241070 ∧ code e2393371241070 = 11189464263278 := by decide
theorem cert_e2393371241070 : check e2393371241070 [[],[.left],[]] .chain = true := by decide
def e2393371241082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393371241082 : Closed e2393371241082 ∧ code e2393371241082 = 11189464263290 := by decide
theorem cert_e2393371241082 : check e2393371241082 [[],[.left],[]] .chain = true := by decide
def e2393371241246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2393371241246 : Closed e2393371241246 ∧ code e2393371241246 = 11189464263454 := by decide
theorem cert_e2393371241246 : check e2393371241246 [[],[.left],[]] .chain = true := by decide
def e2393371241358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2393371241358 : Closed e2393371241358 ∧ code e2393371241358 = 11189464263566 := by decide
theorem cert_e2393371241358 : check e2393371241358 [[],[.left],[]] .chain = true := by decide
def e2393371241370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371241370 : Closed e2393371241370 ∧ code e2393371241370 = 11189464263578 := by decide
theorem cert_e2393371241370 : check e2393371241370 [[],[.left],[]] .chain = true := by decide
def e2393371241414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2393371241414 : Closed e2393371241414 ∧ code e2393371241414 = 11189464263622 := by decide
theorem cert_e2393371241414 : check e2393371241414 [[],[.left],[]] .chain = true := by decide
def e2393371241438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 3)))))))
theorem wire_e2393371241438 : Closed e2393371241438 ∧ code e2393371241438 = 11189464263646 := by decide
theorem cert_e2393371241438 : check e2393371241438 [[],[.left],[]] .sourceHead = true := by decide
def e2393371241582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2393371241582 : Closed e2393371241582 ∧ code e2393371241582 = 11189464263790 := by decide
theorem cert_e2393371241582 : check e2393371241582 [[],[.left],[]] .chain = true := by decide
def e2393371241594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2393371241594 : Closed e2393371241594 ∧ code e2393371241594 = 11189464263802 := by decide
theorem cert_e2393371241594 : check e2393371241594 [[],[.left],[]] .chain = true := by decide
def e2393371241758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2393371241758 : Closed e2393371241758 ∧ code e2393371241758 = 11189464263966 := by decide
theorem cert_e2393371241758 : check e2393371241758 [[],[.left],[]] .chain = true := by decide
def e2393371241926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2393371241926 : Closed e2393371241926 ∧ code e2393371241926 = 11189464264134 := by decide
theorem cert_e2393371241926 : check e2393371241926 [[],[.left],[]] .chain = true := by decide
def e2393371241950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e2393371241950 : Closed e2393371241950 ∧ code e2393371241950 = 11189464264158 := by decide
theorem cert_e2393371241950 : check e2393371241950 [[],[.left],[]] .sourceHead = true := by decide
def e2393371241966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e2393371241966 : Closed e2393371241966 ∧ code e2393371241966 = 11189464264174 := by decide
theorem cert_e2393371241966 : check e2393371241966 [[],[.left],[]] .sourceHead = true := by decide
def e2393371242038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2393371242038 : Closed e2393371242038 ∧ code e2393371242038 = 11189464264246 := by decide
theorem cert_e2393371242038 : check e2393371242038 [[],[.left],[]] .chain = true := by decide
def e2393371242042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2393371242042 : Closed e2393371242042 ∧ code e2393371242042 = 11189464264250 := by decide
theorem cert_e2393371242042 : check e2393371242042 [[],[.left],[]] .chain = true := by decide
def e2393371242090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2393371242090 : Closed e2393371242090 ∧ code e2393371242090 = 11189464264298 := by decide
theorem cert_e2393371242090 : check e2393371242090 [[],[.left],[]] .chain = true := by decide
def e2393371242126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2393371242126 : Closed e2393371242126 ∧ code e2393371242126 = 11189464264334 := by decide
theorem cert_e2393371242126 : check e2393371242126 [[],[.left],[]] .chain = true := by decide
def e2393371242138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371242138 : Closed e2393371242138 ∧ code e2393371242138 = 11189464264346 := by decide
theorem cert_e2393371242138 : check e2393371242138 [[],[.left],[]] .chain = true := by decide
def e2393371242182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2393371242182 : Closed e2393371242182 ∧ code e2393371242182 = 11189464264390 := by decide
theorem cert_e2393371242182 : check e2393371242182 [[],[.left],[]] .chain = true := by decide
def e2393371242206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e2393371242206 : Closed e2393371242206 ∧ code e2393371242206 = 11189464264414 := by decide
theorem cert_e2393371242206 : check e2393371242206 [[],[.left],[]] .sourceHead = true := by decide
def e2393371242230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e2393371242230 : Closed e2393371242230 ∧ code e2393371242230 = 11189464264438 := by decide
theorem cert_e2393371242230 : check e2393371242230 [[],[.left],[]] .sourceHead = true := by decide
def e2393371242266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2393371242266 : Closed e2393371242266 ∧ code e2393371242266 = 11189464264474 := by decide
theorem cert_e2393371242266 : check e2393371242266 [[],[.left],[]] .chain = true := by decide
def e2393371242310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2393371242310 : Closed e2393371242310 ∧ code e2393371242310 = 11189464264518 := by decide
theorem cert_e2393371242310 : check e2393371242310 [[],[.left],[]] .chain = true := by decide
def e2393371242334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 3)))))))
theorem wire_e2393371242334 : Closed e2393371242334 ∧ code e2393371242334 = 11189464264542 := by decide
theorem cert_e2393371242334 : check e2393371242334 [[],[.left],[]] .sourceHead = true := by decide
def e2393371242350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e2393371242350 : Closed e2393371242350 ∧ code e2393371242350 = 11189464264558 := by decide
theorem cert_e2393371242350 : check e2393371242350 [[],[.left],[]] .sourceHead = true := by decide
def e2393371242358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e2393371242358 : Closed e2393371242358 ∧ code e2393371242358 = 11189464264566 := by decide
theorem cert_e2393371242358 : check e2393371242358 [[],[.left],[]] .sourceHead = true := by decide
def e2393371242362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 0)))))))
theorem wire_e2393371242362 : Closed e2393371242362 ∧ code e2393371242362 = 11189464264570 := by decide
theorem cert_e2393371242362 : check e2393371242362 [[],[.left],[]] .sourceHead = true := by decide
def e2393371242934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e2393371242934 : Closed e2393371242934 ∧ code e2393371242934 = 11189464265142 := by decide
theorem cert_e2393371242934 : check e2393371242934 [[],[.left],[]] .chain = true := by decide
def e2393371242966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2393371242966 : Closed e2393371242966 ∧ code e2393371242966 = 11189464265174 := by decide
theorem cert_e2393371242966 : check e2393371242966 [[],[.left],[]] .chain = true := by decide
def e2393371242970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2393371242970 : Closed e2393371242970 ∧ code e2393371242970 = 11189464265178 := by decide
theorem cert_e2393371242970 : check e2393371242970 [[],[.left],[]] .chain = true := by decide
def e2393371243350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2393371243350 : Closed e2393371243350 ∧ code e2393371243350 = 11189464265558 := by decide
theorem cert_e2393371243350 : check e2393371243350 [[],[.left],[]] .chain = true := by decide
def e2393371243354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2393371243354 : Closed e2393371243354 ∧ code e2393371243354 = 11189464265562 := by decide
theorem cert_e2393371243354 : check e2393371243354 [[],[.left],[]] .chain = true := by decide
def e2393371243370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2393371243370 : Closed e2393371243370 ∧ code e2393371243370 = 11189464265578 := by decide
theorem cert_e2393371243370 : check e2393371243370 [[],[.left],[]] .chain = true := by decide
def e2393371243434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2393371243434 : Closed e2393371243434 ∧ code e2393371243434 = 11189464265642 := by decide
theorem cert_e2393371243434 : check e2393371243434 [[],[.left],[]] .chain = true := by decide
def e2393371243638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2393371243638 : Closed e2393371243638 ∧ code e2393371243638 = 11189464265846 := by decide
theorem cert_e2393371243638 : check e2393371243638 [[],[.left],[]] .chain = true := by decide
def e2393371243734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2393371243734 : Closed e2393371243734 ∧ code e2393371243734 = 11189464265942 := by decide
theorem cert_e2393371243734 : check e2393371243734 [[],[.left],[]] .chain = true := by decide
def e2393371243738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2393371243738 : Closed e2393371243738 ∧ code e2393371243738 = 11189464265946 := by decide
theorem cert_e2393371243738 : check e2393371243738 [[],[.left],[]] .chain = true := by decide
def e2393371243754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2393371243754 : Closed e2393371243754 ∧ code e2393371243754 = 11189464265962 := by decide
theorem cert_e2393371243754 : check e2393371243754 [[],[.left],[]] .chain = true := by decide
def e2393371243830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371243830 : Closed e2393371243830 ∧ code e2393371243830 = 11189464266038 := by decide
theorem cert_e2393371243830 : check e2393371243830 [[],[.left],[]] .chain = true := by decide
def e2393371243834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371243834 : Closed e2393371243834 ∧ code e2393371243834 = 11189464266042 := by decide
theorem cert_e2393371243834 : check e2393371243834 [[],[.left],[]] .chain = true := by decide
def e2393371243918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2393371243918 : Closed e2393371243918 ∧ code e2393371243918 = 11189464266126 := by decide
theorem cert_e2393371243918 : check e2393371243918 [[],[.left],[]] .chain = true := by decide
def e2393371243930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371243930 : Closed e2393371243930 ∧ code e2393371243930 = 11189464266138 := by decide
theorem cert_e2393371243930 : check e2393371243930 [[],[.left],[]] .chain = true := by decide
def e2393371243998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2393371243998 : Closed e2393371243998 ∧ code e2393371243998 = 11189464266206 := by decide
theorem cert_e2393371243998 : check e2393371243998 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371244014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2393371244014 : Closed e2393371244014 ∧ code e2393371244014 = 11189464266222 := by decide
theorem cert_e2393371244014 : check e2393371244014 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371244086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2393371244086 : Closed e2393371244086 ∧ code e2393371244086 = 11189464266294 := by decide
theorem cert_e2393371244086 : check e2393371244086 [[],[.left],[]] .chain = true := by decide
def e2393371244090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2393371244090 : Closed e2393371244090 ∧ code e2393371244090 = 11189464266298 := by decide
theorem cert_e2393371244090 : check e2393371244090 [[],[.left],[]] .chain = true := by decide
def e2393371244138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2393371244138 : Closed e2393371244138 ∧ code e2393371244138 = 11189464266346 := by decide
theorem cert_e2393371244138 : check e2393371244138 [[],[.left],[]] .chain = true := by decide
def e2393371244174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2393371244174 : Closed e2393371244174 ∧ code e2393371244174 = 11189464266382 := by decide
theorem cert_e2393371244174 : check e2393371244174 [[],[.left],[]] .chain = true := by decide
def e2393371244186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371244186 : Closed e2393371244186 ∧ code e2393371244186 = 11189464266394 := by decide
theorem cert_e2393371244186 : check e2393371244186 [[],[.left],[]] .chain = true := by decide
def e2393371244230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2393371244230 : Closed e2393371244230 ∧ code e2393371244230 = 11189464266438 := by decide
theorem cert_e2393371244230 : check e2393371244230 [[],[.left],[]] .chain = true := by decide
def e2393371244254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2393371244254 : Closed e2393371244254 ∧ code e2393371244254 = 11189464266462 := by decide
theorem cert_e2393371244254 : check e2393371244254 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371244278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2393371244278 : Closed e2393371244278 ∧ code e2393371244278 = 11189464266486 := by decide
theorem cert_e2393371244278 : check e2393371244278 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2393371244382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2393371244382 : Closed e2393371244382 ∧ code e2393371244382 = 11189464266590 := by decide
theorem cert_e2393371244382 : check e2393371244382 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371244410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2393371244410 : Closed e2393371244410 ∧ code e2393371244410 = 11189464266618 := by decide
theorem cert_e2393371244410 : check e2393371244410 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371244462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2393371244462 : Closed e2393371244462 ∧ code e2393371244462 = 11189464266670 := by decide
theorem cert_e2393371244462 : check e2393371244462 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371244470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2393371244470 : Closed e2393371244470 ∧ code e2393371244470 = 11189464266678 := by decide
theorem cert_e2393371244470 : check e2393371244470 [[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2393371244474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2393371244474 : Closed e2393371244474 ∧ code e2393371244474 = 11189464266682 := by decide
theorem cert_e2393371244474 : check e2393371244474 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371244758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2393371244758 : Closed e2393371244758 ∧ code e2393371244758 = 11189464266966 := by decide
theorem cert_e2393371244758 : check e2393371244758 [[],[.left],[]] .chain = true := by decide
def e2393371244762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2393371244762 : Closed e2393371244762 ∧ code e2393371244762 = 11189464266970 := by decide
theorem cert_e2393371244762 : check e2393371244762 [[],[.left],[]] .chain = true := by decide
def e2393371244778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2393371244778 : Closed e2393371244778 ∧ code e2393371244778 = 11189464266986 := by decide
theorem cert_e2393371244778 : check e2393371244778 [[],[.left],[]] .chain = true := by decide
def e2393371245110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2393371245110 : Closed e2393371245110 ∧ code e2393371245110 = 11189464267318 := by decide
theorem cert_e2393371245110 : check e2393371245110 [[],[.left],[]] .chain = true := by decide
def e2393371245114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2393371245114 : Closed e2393371245114 ∧ code e2393371245114 = 11189464267322 := by decide
theorem cert_e2393371245114 : check e2393371245114 [[],[.left],[]] .chain = true := by decide
def e2393371245198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2393371245198 : Closed e2393371245198 ∧ code e2393371245198 = 11189464267406 := by decide
theorem cert_e2393371245198 : check e2393371245198 [[],[.left],[]] .chain = true := by decide
def e2393371245254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2393371245254 : Closed e2393371245254 ∧ code e2393371245254 = 11189464267462 := by decide
theorem cert_e2393371245254 : check e2393371245254 [[],[.left],[]] .chain = true := by decide
def e2393371245278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2393371245278 : Closed e2393371245278 ∧ code e2393371245278 = 11189464267486 := by decide
theorem cert_e2393371245278 : check e2393371245278 [[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2393371245294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2393371245294 : Closed e2393371245294 ∧ code e2393371245294 = 11189464267502 := by decide
theorem cert_e2393371245294 : check e2393371245294 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371245302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2393371245302 : Closed e2393371245302 ∧ code e2393371245302 = 11189464267510 := by decide
theorem cert_e2393371245302 : check e2393371245302 [[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2393371245338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2393371245338 : Closed e2393371245338 ∧ code e2393371245338 = 11189464267546 := by decide
theorem cert_e2393371245338 : check e2393371245338 [[],[.left],[]] .chain = true := by decide
def e2393371245382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2393371245382 : Closed e2393371245382 ∧ code e2393371245382 = 11189464267590 := by decide
theorem cert_e2393371245382 : check e2393371245382 [[],[.left],[]] .chain = true := by decide
def e2393371245406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2393371245406 : Closed e2393371245406 ∧ code e2393371245406 = 11189464267614 := by decide
theorem cert_e2393371245406 : check e2393371245406 [[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2393371245422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2393371245422 : Closed e2393371245422 ∧ code e2393371245422 = 11189464267630 := by decide
theorem cert_e2393371245422 : check e2393371245422 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371245430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2393371245430 : Closed e2393371245430 ∧ code e2393371245430 = 11189464267638 := by decide
theorem cert_e2393371245430 : check e2393371245430 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2393371245434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2393371245434 : Closed e2393371245434 ∧ code e2393371245434 = 11189464267642 := by decide
theorem cert_e2393371245434 : check e2393371245434 [[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2393371245486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2393371245486 : Closed e2393371245486 ∧ code e2393371245486 = 11189464267694 := by decide
theorem cert_e2393371245486 : check e2393371245486 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371245494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2393371245494 : Closed e2393371245494 ∧ code e2393371245494 = 11189464267702 := by decide
theorem cert_e2393371245494 : check e2393371245494 [[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2393371245498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2393371245498 : Closed e2393371245498 ∧ code e2393371245498 = 11189464267706 := by decide
theorem cert_e2393371245498 : check e2393371245498 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371245526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2393371245526 : Closed e2393371245526 ∧ code e2393371245526 = 11189464267734 := by decide
private def t_e2393371245526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1)))))))
theorem cert_e2393371245526 : ¬ IsSelfInterpreter e2393371245526 :=
  wSource (t := t_e2393371245526) (replay_sound (ps := []) (t := e2393371245526) (by decide)) (by decide)
def e2393371245530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2393371245530 : Closed e2393371245530 ∧ code e2393371245530 = 11189464267738 := by decide
private def t_e2393371245530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0)))))))
theorem cert_e2393371245530 : ¬ IsSelfInterpreter e2393371245530 :=
  wSource (t := t_e2393371245530) (replay_sound (ps := []) (t := e2393371245530) (by decide)) (by decide)
def e2393371250414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e2393371250414 : Closed e2393371250414 ∧ code e2393371250414 = 11189464272622 := by decide
theorem cert_e2393371250414 : check e2393371250414 [[],[.left],[]] .chain = true := by decide
def e2393371250422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e2393371250422 : Closed e2393371250422 ∧ code e2393371250422 = 11189464272630 := by decide
theorem cert_e2393371250422 : check e2393371250422 [[],[.left],[]] .chain = true := by decide
def e2393371250542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e2393371250542 : Closed e2393371250542 ∧ code e2393371250542 = 11189464272750 := by decide
theorem cert_e2393371250542 : check e2393371250542 [[],[.left],[]] .chain = true := by decide
def e2393371250554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e2393371250554 : Closed e2393371250554 ∧ code e2393371250554 = 11189464272762 := by decide
theorem cert_e2393371250554 : check e2393371250554 [[],[.left],[]] .chain = true := by decide
def e2393371250614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e2393371250614 : Closed e2393371250614 ∧ code e2393371250614 = 11189464272822 := by decide
theorem cert_e2393371250614 : check e2393371250614 [[],[.left],[]] .chain = true := by decide
def e2393371250618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e2393371250618 : Closed e2393371250618 ∧ code e2393371250618 = 11189464272826 := by decide
theorem cert_e2393371250618 : check e2393371250618 [[],[.left],[]] .chain = true := by decide
def e2393371253214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e2393371253214 : Closed e2393371253214 ∧ code e2393371253214 = 11189464275422 := by decide
theorem cert_e2393371253214 : check e2393371253214 [[],[.left],[]] .chain = true := by decide
def e2393371253238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e2393371253238 : Closed e2393371253238 ∧ code e2393371253238 = 11189464275446 := by decide
theorem cert_e2393371253238 : check e2393371253238 [[],[.left],[]] .chain = true := by decide
def e2393371253982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e2393371253982 : Closed e2393371253982 ∧ code e2393371253982 = 11189464276190 := by decide
theorem cert_e2393371253982 : check e2393371253982 [[],[.left],[]] .chain = true := by decide
def e2393371253998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e2393371253998 : Closed e2393371253998 ∧ code e2393371253998 = 11189464276206 := by decide
theorem cert_e2393371253998 : check e2393371253998 [[],[.left],[]] .chain = true := by decide
def e2393371254006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e2393371254006 : Closed e2393371254006 ∧ code e2393371254006 = 11189464276214 := by decide
theorem cert_e2393371254006 : check e2393371254006 [[],[.left],[]] .chain = true := by decide
def e2393371254010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e2393371254010 : Closed e2393371254010 ∧ code e2393371254010 = 11189464276218 := by decide
theorem cert_e2393371254010 : check e2393371254010 [[],[.left],[]] .chain = true := by decide
def e2393371254390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e2393371254390 : Closed e2393371254390 ∧ code e2393371254390 = 11189464276598 := by decide
theorem cert_e2393371254390 : check e2393371254390 [[],[.left],[]] .chain = true := by decide
def e2393371254582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371254582 : Closed e2393371254582 ∧ code e2393371254582 = 11189464276790 := by decide
theorem cert_e2393371254582 : check e2393371254582 [[],[.left],[]] .chain = true := by decide
def e2393371254586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371254586 : Closed e2393371254586 ∧ code e2393371254586 = 11189464276794 := by decide
theorem cert_e2393371254586 : check e2393371254586 [[],[.left],[]] .chain = true := by decide
def e2393371258222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2393371258222 : Closed e2393371258222 ∧ code e2393371258222 = 11189464280430 := by decide
theorem cert_e2393371258222 : check e2393371258222 [[],[.left],[]] .chain = true := by decide
def e2393371258230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2393371258230 : Closed e2393371258230 ∧ code e2393371258230 = 11189464280438 := by decide
theorem cert_e2393371258230 : check e2393371258230 [[],[.left],[]] .chain = true := by decide
def e2393371258286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2393371258286 : Closed e2393371258286 ∧ code e2393371258286 = 11189464280494 := by decide
theorem cert_e2393371258286 : check e2393371258286 [[],[.left],[]] .chain = true := by decide
def e2393371258298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2393371258298 : Closed e2393371258298 ∧ code e2393371258298 = 11189464280506 := by decide
theorem cert_e2393371258298 : check e2393371258298 [[],[.left],[]] .chain = true := by decide
def e2393371258326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2393371258326 : Closed e2393371258326 ∧ code e2393371258326 = 11189464280534 := by decide
theorem cert_e2393371258326 : check e2393371258326 [[],[.left],[]] .chain = true := by decide
def e2393371258330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2393371258330 : Closed e2393371258330 ∧ code e2393371258330 = 11189464280538 := by decide
theorem cert_e2393371258330 : check e2393371258330 [[],[.left],[]] .chain = true := by decide
def e2393371258542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2393371258542 : Closed e2393371258542 ∧ code e2393371258542 = 11189464280750 := by decide
theorem cert_e2393371258542 : check e2393371258542 [[],[.left],[]] .chain = true := by decide
def e2393371258554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2393371258554 : Closed e2393371258554 ∧ code e2393371258554 = 11189464280762 := by decide
theorem cert_e2393371258554 : check e2393371258554 [[],[.left],[]] .chain = true := by decide
def e2393371258602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2393371258602 : Closed e2393371258602 ∧ code e2393371258602 = 11189464280810 := by decide
theorem cert_e2393371258602 : check e2393371258602 [[],[.left],[]] .chain = true := by decide
def e2393371258710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2393371258710 : Closed e2393371258710 ∧ code e2393371258710 = 11189464280918 := by decide
theorem cert_e2393371258710 : check e2393371258710 [[],[.left],[]] .chain = true := by decide
def e2393371258714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2393371258714 : Closed e2393371258714 ∧ code e2393371258714 = 11189464280922 := by decide
theorem cert_e2393371258714 : check e2393371258714 [[],[.left],[]] .chain = true := by decide
def e2393371258730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2393371258730 : Closed e2393371258730 ∧ code e2393371258730 = 11189464280938 := by decide
theorem cert_e2393371258730 : check e2393371258730 [[],[.left],[]] .chain = true := by decide
def e2393371259358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2393371259358 : Closed e2393371259358 ∧ code e2393371259358 = 11189464281566 := by decide
theorem cert_e2393371259358 : check e2393371259358 [[],[.left],[]] .chain = true := by decide
def e2393371259382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2393371259382 : Closed e2393371259382 ∧ code e2393371259382 = 11189464281590 := by decide
theorem cert_e2393371259382 : check e2393371259382 [[],[.left],[]] .chain = true := by decide
def e2393371259758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2393371259758 : Closed e2393371259758 ∧ code e2393371259758 = 11189464281966 := by decide
theorem cert_e2393371259758 : check e2393371259758 [[],[.left],[]] .chain = true := by decide
def e2393371259766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2393371259766 : Closed e2393371259766 ∧ code e2393371259766 = 11189464281974 := by decide
theorem cert_e2393371259766 : check e2393371259766 [[],[.left],[]] .chain = true := by decide
def e2393371259822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2393371259822 : Closed e2393371259822 ∧ code e2393371259822 = 11189464282030 := by decide
theorem cert_e2393371259822 : check e2393371259822 [[],[.left],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393371245526
#print axioms Blc.Floor43.cert_e2393371245530
