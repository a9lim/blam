import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2259404502254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2259404502254 : Closed e2259404502254 ∧ code e2259404502254 = 11055497524462 := by decide
theorem cert_e2259404502254 : check e2259404502254 [[],[.under]] .three = true := by decide
def e2259404502262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2259404502262 : Closed e2259404502262 ∧ code e2259404502262 = 11055497524470 := by decide
theorem cert_e2259404502262 : check e2259404502262 [[],[.under]] .three = true := by decide
def e2259404502638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2259404502638 : Closed e2259404502638 ∧ code e2259404502638 = 11055497524846 := by decide
theorem cert_e2259404502638 : check e2259404502638 [[],[.under]] .three = true := by decide
def e2259404502650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2259404502650 : Closed e2259404502650 ∧ code e2259404502650 = 11055497524858 := by decide
theorem cert_e2259404502650 : check e2259404502650 [[],[.under]] .three = true := by decide
def e2259404502838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2259404502838 : Closed e2259404502838 ∧ code e2259404502838 = 11055497525046 := by decide
theorem cert_e2259404502838 : check e2259404502838 [[],[.under]] .three = true := by decide
def e2259404502842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2259404502842 : Closed e2259404502842 ∧ code e2259404502842 = 11055497525050 := by decide
theorem cert_e2259404502842 : check e2259404502842 [[],[.under]] .three = true := by decide
def e2259404503470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2259404503470 : Closed e2259404503470 ∧ code e2259404503470 = 11055497525678 := by decide
theorem cert_e2259404503470 : check e2259404503470 [[],[.under]] .three = true := by decide
def e2259404503482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2259404503482 : Closed e2259404503482 ∧ code e2259404503482 = 11055497525690 := by decide
theorem cert_e2259404503482 : check e2259404503482 [[],[.under]] .three = true := by decide
def e2259404503530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2259404503530 : Closed e2259404503530 ∧ code e2259404503530 = 11055497525738 := by decide
theorem cert_e2259404503530 : check e2259404503530 [[],[.under]] .three = true := by decide
def e2259404503662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2259404503662 : Closed e2259404503662 ∧ code e2259404503662 = 11055497525870 := by decide
theorem cert_e2259404503662 : check e2259404503662 [[],[.under]] .three = true := by decide
def e2259404503674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2259404503674 : Closed e2259404503674 ∧ code e2259404503674 = 11055497525882 := by decide
theorem cert_e2259404503674 : check e2259404503674 [[],[.under]] .three = true := by decide
def e2259404503962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2259404503962 : Closed e2259404503962 ∧ code e2259404503962 = 11055497526170 := by decide
theorem cert_e2259404503962 : check e2259404503962 [[],[.under]] .three = true := by decide
def e2259404504278 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2259404504278 : Closed e2259404504278 ∧ code e2259404504278 = 11055497526486 := by decide
theorem cert_e2259404504278 : check e2259404504278 [[],[.under]] .three = true := by decide
def e2259404504282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2259404504282 : Closed e2259404504282 ∧ code e2259404504282 = 11055497526490 := by decide
theorem cert_e2259404504282 : check e2259404504282 [[],[.under]] .three = true := by decide
def e2259404504298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2259404504298 : Closed e2259404504298 ∧ code e2259404504298 = 11055497526506 := by decide
theorem cert_e2259404504298 : check e2259404504298 [[],[.under]] .three = true := by decide
def e2259404504374 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2259404504374 : Closed e2259404504374 ∧ code e2259404504374 = 11055497526582 := by decide
theorem cert_e2259404504374 : check e2259404504374 [[],[.under]] .three = true := by decide
def e2259404504378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2259404504378 : Closed e2259404504378 ∧ code e2259404504378 = 11055497526586 := by decide
theorem cert_e2259404504378 : check e2259404504378 [[],[.under]] .three = true := by decide
def e2259404504474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2259404504474 : Closed e2259404504474 ∧ code e2259404504474 = 11055497526682 := by decide
theorem cert_e2259404504474 : check e2259404504474 [[],[.under]] .three = true := by decide
def e2259404508014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2259404508014 : Closed e2259404508014 ∧ code e2259404508014 = 11055497530222 := by decide
theorem cert_e2259404508014 : check e2259404508014 [[],[.under]] .three = true := by decide
def e2259404508022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2259404508022 : Closed e2259404508022 ∧ code e2259404508022 = 11055497530230 := by decide
theorem cert_e2259404508022 : check e2259404508022 [[],[.under]] .three = true := by decide
def e2259404508078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2259404508078 : Closed e2259404508078 ∧ code e2259404508078 = 11055497530286 := by decide
theorem cert_e2259404508078 : check e2259404508078 [[],[.under]] .three = true := by decide
def e2259404508090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2259404508090 : Closed e2259404508090 ∧ code e2259404508090 = 11055497530298 := by decide
theorem cert_e2259404508090 : check e2259404508090 [[],[.under]] .three = true := by decide
def e2259404508118 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2259404508118 : Closed e2259404508118 ∧ code e2259404508118 = 11055497530326 := by decide
theorem cert_e2259404508118 : check e2259404508118 [[],[.under]] .three = true := by decide
def e2259404508122 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2259404508122 : Closed e2259404508122 ∧ code e2259404508122 = 11055497530330 := by decide
theorem cert_e2259404508122 : check e2259404508122 [[],[.under]] .three = true := by decide
def e2259404508398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2259404508398 : Closed e2259404508398 ∧ code e2259404508398 = 11055497530606 := by decide
theorem cert_e2259404508398 : check e2259404508398 [[],[.under]] .three = true := by decide
def e2259404508406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2259404508406 : Closed e2259404508406 ∧ code e2259404508406 = 11055497530614 := by decide
theorem cert_e2259404508406 : check e2259404508406 [[],[.under]] .three = true := by decide
def e2259404508782 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2259404508782 : Closed e2259404508782 ∧ code e2259404508782 = 11055497530990 := by decide
theorem cert_e2259404508782 : check e2259404508782 [[],[.under]] .three = true := by decide
def e2259404508794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2259404508794 : Closed e2259404508794 ∧ code e2259404508794 = 11055497531002 := by decide
theorem cert_e2259404508794 : check e2259404508794 [[],[.under]] .three = true := by decide
def e2259404508982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2259404508982 : Closed e2259404508982 ∧ code e2259404508982 = 11055497531190 := by decide
theorem cert_e2259404508982 : check e2259404508982 [[],[.under]] .three = true := by decide
def e2259404508986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2259404508986 : Closed e2259404508986 ∧ code e2259404508986 = 11055497531194 := by decide
theorem cert_e2259404508986 : check e2259404508986 [[],[.under]] .three = true := by decide
def e2259404514734 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2259404514734 : Closed e2259404514734 ∧ code e2259404514734 = 11055497536942 := by decide
theorem cert_e2259404514734 : check e2259404514734 [[],[.under]] .three = true := by decide
def e2259404514746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2259404514746 : Closed e2259404514746 ∧ code e2259404514746 = 11055497536954 := by decide
theorem cert_e2259404514746 : check e2259404514746 [[],[.under]] .three = true := by decide
def e2259404514794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2259404514794 : Closed e2259404514794 ∧ code e2259404514794 = 11055497537002 := by decide
theorem cert_e2259404514794 : check e2259404514794 [[],[.under]] .three = true := by decide
def e2259404514926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2259404514926 : Closed e2259404514926 ∧ code e2259404514926 = 11055497537134 := by decide
theorem cert_e2259404514926 : check e2259404514926 [[],[.under]] .three = true := by decide
def e2259404514938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2259404514938 : Closed e2259404514938 ∧ code e2259404514938 = 11055497537146 := by decide
theorem cert_e2259404514938 : check e2259404514938 [[],[.under]] .three = true := by decide
def e2259404515226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2259404515226 : Closed e2259404515226 ∧ code e2259404515226 = 11055497537434 := by decide
theorem cert_e2259404515226 : check e2259404515226 [[],[.under]] .three = true := by decide
def e2259404518102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2259404518102 : Closed e2259404518102 ∧ code e2259404518102 = 11055497540310 := by decide
theorem cert_e2259404518102 : check e2259404518102 [[],[.under]] .three = true := by decide
def e2259404518106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2259404518106 : Closed e2259404518106 ∧ code e2259404518106 = 11055497540314 := by decide
theorem cert_e2259404518106 : check e2259404518106 [[],[.under]] .three = true := by decide
def e2259404518122 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2259404518122 : Closed e2259404518122 ∧ code e2259404518122 = 11055497540330 := by decide
theorem cert_e2259404518122 : check e2259404518122 [[],[.under]] .three = true := by decide
def e2259404518198 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2259404518198 : Closed e2259404518198 ∧ code e2259404518198 = 11055497540406 := by decide
theorem cert_e2259404518198 : check e2259404518198 [[],[.under]] .three = true := by decide
def e2259404518202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2259404518202 : Closed e2259404518202 ∧ code e2259404518202 = 11055497540410 := by decide
theorem cert_e2259404518202 : check e2259404518202 [[],[.under]] .three = true := by decide
def e2259404518298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2259404518298 : Closed e2259404518298 ∧ code e2259404518298 = 11055497540506 := by decide
theorem cert_e2259404518298 : check e2259404518298 [[],[.under]] .three = true := by decide
def e2259404655470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2259404655470 : Closed e2259404655470 ∧ code e2259404655470 = 11055497677678 := by decide
theorem cert_e2259404655470 : check e2259404655470 [[],[.under]] .chain = true := by decide
def e2259404655478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2259404655478 : Closed e2259404655478 ∧ code e2259404655478 = 11055497677686 := by decide
theorem cert_e2259404655478 : check e2259404655478 [[],[.under]] .chain = true := by decide
def e2259404655534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2259404655534 : Closed e2259404655534 ∧ code e2259404655534 = 11055497677742 := by decide
theorem cert_e2259404655534 : check e2259404655534 [[],[.under]] .chain = true := by decide
def e2259404655546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2259404655546 : Closed e2259404655546 ∧ code e2259404655546 = 11055497677754 := by decide
theorem cert_e2259404655546 : check e2259404655546 [[],[.under]] .chain = true := by decide
def e2259404655574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2259404655574 : Closed e2259404655574 ∧ code e2259404655574 = 11055497677782 := by decide
theorem cert_e2259404655574 : check e2259404655574 [[],[.under]] .chain = true := by decide
def e2259404655578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2259404655578 : Closed e2259404655578 ∧ code e2259404655578 = 11055497677786 := by decide
theorem cert_e2259404655578 : check e2259404655578 [[],[.under]] .chain = true := by decide
def e2259404655854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2259404655854 : Closed e2259404655854 ∧ code e2259404655854 = 11055497678062 := by decide
theorem cert_e2259404655854 : check e2259404655854 [[],[.under]] .chain = true := by decide
def e2259404655862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2259404655862 : Closed e2259404655862 ∧ code e2259404655862 = 11055497678070 := by decide
theorem cert_e2259404655862 : check e2259404655862 [[],[.under]] .chain = true := by decide
def e2259404656238 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2259404656238 : Closed e2259404656238 ∧ code e2259404656238 = 11055497678446 := by decide
theorem cert_e2259404656238 : check e2259404656238 [[],[.under]] .chain = true := by decide
def e2259404656250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2259404656250 : Closed e2259404656250 ∧ code e2259404656250 = 11055497678458 := by decide
theorem cert_e2259404656250 : check e2259404656250 [[],[.under]] .chain = true := by decide
def e2259404656438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2259404656438 : Closed e2259404656438 ∧ code e2259404656438 = 11055497678646 := by decide
theorem cert_e2259404656438 : check e2259404656438 [[],[.under]] .chain = true := by decide
def e2259404656442 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2259404656442 : Closed e2259404656442 ∧ code e2259404656442 = 11055497678650 := by decide
theorem cert_e2259404656442 : check e2259404656442 [[],[.under]] .chain = true := by decide
def e2259405245294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2259405245294 : Closed e2259405245294 ∧ code e2259405245294 = 11055498267502 := by decide
theorem cert_e2259405245294 : check e2259405245294 [[],[.under],[.under]] .smaller = true := by decide
def e2259405245302 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2259405245302 : Closed e2259405245302 ∧ code e2259405245302 = 11055498267510 := by decide
theorem cert_e2259405245302 : check e2259405245302 [[],[.under],[.under]] .smaller = true := by decide
def e2259405245358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2259405245358 : Closed e2259405245358 ∧ code e2259405245358 = 11055498267566 := by decide
theorem cert_e2259405245358 : check e2259405245358 [[],[.under],[.under]] .smaller = true := by decide
def e2259405245370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2259405245370 : Closed e2259405245370 ∧ code e2259405245370 = 11055498267578 := by decide
theorem cert_e2259405245370 : check e2259405245370 [[],[.under],[.under]] .smaller = true := by decide
def e2259405245398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2259405245398 : Closed e2259405245398 ∧ code e2259405245398 = 11055498267606 := by decide
theorem cert_e2259405245398 : check e2259405245398 [[],[.under],[.under]] .smaller = true := by decide
def e2259405245402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2259405245402 : Closed e2259405245402 ∧ code e2259405245402 = 11055498267610 := by decide
theorem cert_e2259405245402 : check e2259405245402 [[],[.under],[.under]] .smaller = true := by decide
def e2259405245678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2259405245678 : Closed e2259405245678 ∧ code e2259405245678 = 11055498267886 := by decide
theorem cert_e2259405245678 : check e2259405245678 [[],[.under],[.under]] .smaller = true := by decide
def e2259405245686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2259405245686 : Closed e2259405245686 ∧ code e2259405245686 = 11055498267894 := by decide
theorem cert_e2259405245686 : check e2259405245686 [[],[.under],[.under]] .smaller = true := by decide
def e2259405246062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2259405246062 : Closed e2259405246062 ∧ code e2259405246062 = 11055498268270 := by decide
theorem cert_e2259405246062 : check e2259405246062 [[],[.under],[.under]] .smaller = true := by decide
def e2259405246074 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2259405246074 : Closed e2259405246074 ∧ code e2259405246074 = 11055498268282 := by decide
theorem cert_e2259405246074 : check e2259405246074 [[],[.under],[.under]] .smaller = true := by decide
def e2259405246262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2259405246262 : Closed e2259405246262 ∧ code e2259405246262 = 11055498268470 := by decide
theorem cert_e2259405246262 : check e2259405246262 [[],[.under],[.under]] .smaller = true := by decide
def e2259405246266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2259405246266 : Closed e2259405246266 ∧ code e2259405246266 = 11055498268474 := by decide
theorem cert_e2259405246266 : check e2259405246266 [[],[.under],[.under]] .smaller = true := by decide
def e2259514257606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259514257606 : Closed e2259514257606 ∧ code e2259514257606 = 11055607279814 := by decide
theorem cert_e2259514257606 : check e2259514257606 [[]] .width = true := by decide
def e2259514273990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259514273990 : Closed e2259514273990 ∧ code e2259514273990 = 11055607296198 := by decide
theorem cert_e2259514273990 : check e2259514273990 [[]] .width = true := by decide
def e2259514486298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259514486298 : Closed e2259514486298 ∧ code e2259514486298 = 11055607508506 := by decide
theorem cert_e2259514486298 : check e2259514486298 [[]] .width = true := by decide
def e2259514519066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259514519066 : Closed e2259514519066 ∧ code e2259514519066 = 11055607541274 := by decide
theorem cert_e2259514519066 : check e2259514519066 [[]] .width = true := by decide
def e2259514521114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259514521114 : Closed e2259514521114 ∧ code e2259514521114 = 11055607543322 := by decide
theorem cert_e2259514521114 : check e2259514521114 [[]] .width = true := by decide
def e2259516506310 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259516506310 : Closed e2259516506310 ∧ code e2259516506310 = 11055609528518 := by decide
theorem cert_e2259516506310 : check e2259516506310 [[]] .width = true := by decide
def e2259516571846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259516571846 : Closed e2259516571846 ∧ code e2259516571846 = 11055609594054 := by decide
theorem cert_e2259516571846 : check e2259516571846 [[]] .width = true := by decide
def e2259516747974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259516747974 : Closed e2259516747974 ∧ code e2259516747974 = 11055609770182 := by decide
theorem cert_e2259516747974 : check e2259516747974 [[]] .width = true := by decide
def e2259516780058 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259516780058 : Closed e2259516780058 ∧ code e2259516780058 = 11055609802266 := by decide
theorem cert_e2259516780058 : check e2259516780058 [[]] .width = true := by decide
def e2259517030598 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259517030598 : Closed e2259517030598 ∧ code e2259517030598 = 11055610052806 := by decide
theorem cert_e2259517030598 : check e2259517030598 [[]] .width = true := by decide
def e2259517104154 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259517104154 : Closed e2259517104154 ∧ code e2259517104154 = 11055610126362 := by decide
theorem cert_e2259517104154 : check e2259517104154 [[]] .width = true := by decide
def e2259517104246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259517104246 : Closed e2259517104246 ∧ code e2259517104246 = 11055610126454 := by decide
theorem cert_e2259517104246 : check e2259517104246 [[]] .width = true := by decide
def e2259517104490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259517104490 : Closed e2259517104490 ∧ code e2259517104490 = 11055610126698 := by decide
theorem cert_e2259517104490 : check e2259517104490 [[]] .width = true := by decide
def e2259517104538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259517104538 : Closed e2259517104538 ∧ code e2259517104538 = 11055610126746 := by decide
theorem cert_e2259517104538 : check e2259517104538 [[]] .width = true := by decide
def e2259517116614 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259517116614 : Closed e2259517116614 ∧ code e2259517116614 = 11055610138822 := by decide
theorem cert_e2259517116614 : check e2259517116614 [[]] .width = true := by decide
def e2259517120026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259517120026 : Closed e2259517120026 ∧ code e2259517120026 = 11055610142234 := by decide
theorem cert_e2259517120026 : check e2259517120026 [[]] .width = true := by decide
def e2259517128902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259517128902 : Closed e2259517128902 ∧ code e2259517128902 = 11055610151110 := by decide
theorem cert_e2259517128902 : check e2259517128902 [[]] .width = true := by decide
def e2259517136922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259517136922 : Closed e2259517136922 ∧ code e2259517136922 = 11055610159130 := by decide
theorem cert_e2259517136922 : check e2259517136922 [[]] .width = true := by decide
def e2259517137014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259517137014 : Closed e2259517137014 ∧ code e2259517137014 = 11055610159222 := by decide
theorem cert_e2259517137014 : check e2259517137014 [[]] .width = true := by decide
def e2259517137258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259517137258 : Closed e2259517137258 ∧ code e2259517137258 = 11055610159466 := by decide
theorem cert_e2259517137258 : check e2259517137258 [[]] .width = true := by decide
def e2259517137306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259517137306 : Closed e2259517137306 ∧ code e2259517137306 = 11055610159514 := by decide
theorem cert_e2259517137306 : check e2259517137306 [[]] .width = true := by decide
def e2259517141190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259517141190 : Closed e2259517141190 ∧ code e2259517141190 = 11055610163398 := by decide
theorem cert_e2259517141190 : check e2259517141190 [[]] .width = true := by decide
def e2259517223110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259517223110 : Closed e2259517223110 ∧ code e2259517223110 = 11055610245318 := by decide
theorem cert_e2259517223110 : check e2259517223110 [[]] .width = true := by decide
def e2259517238810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259517238810 : Closed e2259517238810 ∧ code e2259517238810 = 11055610261018 := by decide
private def t_e2259517238810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259517238810 : ¬ IsSelfInterpreter e2259517238810 :=
  wSource (t := t_e2259517238810) (replay_sound (ps := []) (t := e2259517238810) (by decide)) (by decide)
def e2259517240858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259517240858 : Closed e2259517240858 ∧ code e2259517240858 = 11055610263066 := by decide
private def t_e2259517240858 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259517240858 : ¬ IsSelfInterpreter e2259517240858 :=
  wSource (t := t_e2259517240858) (replay_sound (ps := []) (t := e2259517240858) (by decide)) (by decide)
def e2259517358278 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259517358278 : Closed e2259517358278 ∧ code e2259517358278 = 11055610380486 := by decide
theorem cert_e2259517358278 : check e2259517358278 [[]] .width = true := by decide
def e2259517378758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259517378758 : Closed e2259517378758 ∧ code e2259517378758 = 11055610400966 := by decide
theorem cert_e2259517378758 : check e2259517378758 [[]] .width = true := by decide
def e2259517382170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259517382170 : Closed e2259517382170 ∧ code e2259517382170 = 11055610404378 := by decide
private def t_e2259517382170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259517382170 : ¬ IsSelfInterpreter e2259517382170 :=
  wSource (t := t_e2259517382170) (replay_sound (ps := []) (t := e2259517382170) (by decide)) (by decide)
def e2259517391046 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259517391046 : Closed e2259517391046 ∧ code e2259517391046 = 11055610413254 := by decide
theorem cert_e2259517391046 : check e2259517391046 [[]] .width = true := by decide
def e2259517399066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259517399066 : Closed e2259517399066 ∧ code e2259517399066 = 11055610421274 := by decide
theorem cert_e2259517399066 : check e2259517399066 [[]] .width = true := by decide
def e2259517399158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259517399158 : Closed e2259517399158 ∧ code e2259517399158 = 11055610421366 := by decide
private def t_e2259517399158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2259517399158 : ¬ IsSelfInterpreter e2259517399158 :=
  wSource (t := t_e2259517399158) (replay_sound (ps := []) (t := e2259517399158) (by decide)) (by decide)
def e2259517399402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259517399402 : Closed e2259517399402 ∧ code e2259517399402 = 11055610421610 := by decide
private def t_e2259517399402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2259517399402 : ¬ IsSelfInterpreter e2259517399402 :=
  wSource (t := t_e2259517399402) (replay_sound (ps := []) (t := e2259517399402) (by decide)) (by decide)
def e2259517399450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259517399450 : Closed e2259517399450 ∧ code e2259517399450 = 11055610421658 := by decide
private def t_e2259517399450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2259517399450 : ¬ IsSelfInterpreter e2259517399450 :=
  wSource (t := t_e2259517399450) (replay_sound (ps := []) (t := e2259517399450) (by decide)) (by decide)
def e2259517403334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259517403334 : Closed e2259517403334 ∧ code e2259517403334 = 11055610425542 := by decide
theorem cert_e2259517403334 : check e2259517403334 [[]] .width = true := by decide
def e2259517410842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259517410842 : Closed e2259517410842 ∧ code e2259517410842 = 11055610433050 := by decide
private def t_e2259517410842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259517410842 : ¬ IsSelfInterpreter e2259517410842 :=
  wSource (t := t_e2259517410842) (replay_sound (ps := []) (t := e2259517410842) (by decide)) (by decide)
def e2259517419718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259517419718 : Closed e2259517419718 ∧ code e2259517419718 = 11055610441926 := by decide
theorem cert_e2259517419718 : check e2259517419718 [[]] .width = true := by decide
def e2259518058694 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259518058694 : Closed e2259518058694 ∧ code e2259518058694 = 11055611080902 := by decide
theorem cert_e2259518058694 : check e2259518058694 [[]] .width = true := by decide
def e2259518083270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259518083270 : Closed e2259518083270 ∧ code e2259518083270 = 11055611105478 := by decide
theorem cert_e2259518083270 : check e2259518083270 [[]] .width = true := by decide
def e2259518156314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259518156314 : Closed e2259518156314 ∧ code e2259518156314 = 11055611178522 := by decide
theorem cert_e2259518156314 : check e2259518156314 [[]] .width = true := by decide
def e2259518205466 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259518205466 : Closed e2259518205466 ∧ code e2259518205466 = 11055611227674 := by decide
theorem cert_e2259518205466 : check e2259518205466 [[]] .width = true := by decide
def e2259518208538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259518208538 : Closed e2259518208538 ∧ code e2259518208538 = 11055611230746 := by decide
theorem cert_e2259518208538 : check e2259518208538 [[]] .width = true := by decide
def e2259518845126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259518845126 : Closed e2259518845126 ∧ code e2259518845126 = 11055611867334 := by decide
theorem cert_e2259518845126 : check e2259518845126 [[]] .width = true := by decide
def e2259518877210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259518877210 : Closed e2259518877210 ∧ code e2259518877210 = 11055611899418 := by decide
theorem cert_e2259518877210 : check e2259518877210 [[]] .width = true := by decide
def e2259519127750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259519127750 : Closed e2259519127750 ∧ code e2259519127750 = 11055612149958 := by decide
theorem cert_e2259519127750 : check e2259519127750 [[]] .width = true := by decide
def e2259519201306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259519201306 : Closed e2259519201306 ∧ code e2259519201306 = 11055612223514 := by decide
theorem cert_e2259519201306 : check e2259519201306 [[]] .width = true := by decide
def e2259519201398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259519201398 : Closed e2259519201398 ∧ code e2259519201398 = 11055612223606 := by decide
theorem cert_e2259519201398 : check e2259519201398 [[]] .width = true := by decide
def e2259519201642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259519201642 : Closed e2259519201642 ∧ code e2259519201642 = 11055612223850 := by decide
theorem cert_e2259519201642 : check e2259519201642 [[]] .width = true := by decide
def e2259519201690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259519201690 : Closed e2259519201690 ∧ code e2259519201690 = 11055612223898 := by decide
theorem cert_e2259519201690 : check e2259519201690 [[]] .width = true := by decide
def e2259519213766 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259519213766 : Closed e2259519213766 ∧ code e2259519213766 = 11055612235974 := by decide
theorem cert_e2259519213766 : check e2259519213766 [[]] .width = true := by decide
def e2259519217178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259519217178 : Closed e2259519217178 ∧ code e2259519217178 = 11055612239386 := by decide
theorem cert_e2259519217178 : check e2259519217178 [[]] .width = true := by decide
def e2259519226054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259519226054 : Closed e2259519226054 ∧ code e2259519226054 = 11055612248262 := by decide
theorem cert_e2259519226054 : check e2259519226054 [[]] .width = true := by decide
def e2259519234074 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259519234074 : Closed e2259519234074 ∧ code e2259519234074 = 11055612256282 := by decide
theorem cert_e2259519234074 : check e2259519234074 [[]] .width = true := by decide
def e2259519234166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259519234166 : Closed e2259519234166 ∧ code e2259519234166 = 11055612256374 := by decide
theorem cert_e2259519234166 : check e2259519234166 [[]] .width = true := by decide
def e2259519234410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259519234410 : Closed e2259519234410 ∧ code e2259519234410 = 11055612256618 := by decide
theorem cert_e2259519234410 : check e2259519234410 [[]] .width = true := by decide
def e2259519234458 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259519234458 : Closed e2259519234458 ∧ code e2259519234458 = 11055612256666 := by decide
theorem cert_e2259519234458 : check e2259519234458 [[]] .width = true := by decide
def e2259519238342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259519238342 : Closed e2259519238342 ∧ code e2259519238342 = 11055612260550 := by decide
theorem cert_e2259519238342 : check e2259519238342 [[]] .width = true := by decide
def e2259519463450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259519463450 : Closed e2259519463450 ∧ code e2259519463450 = 11055612485658 := by decide
theorem cert_e2259519463450 : check e2259519463450 [[]] .width = true := by decide
def e2259519463542 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259519463542 : Closed e2259519463542 ∧ code e2259519463542 = 11055612485750 := by decide
theorem cert_e2259519463542 : check e2259519463542 [[]] .width = true := by decide
def e2259519463786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259519463786 : Closed e2259519463786 ∧ code e2259519463786 = 11055612485994 := by decide
theorem cert_e2259519463786 : check e2259519463786 [[]] .width = true := by decide
def e2259519463834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259519463834 : Closed e2259519463834 ∧ code e2259519463834 = 11055612486042 := by decide
theorem cert_e2259519463834 : check e2259519463834 [[]] .width = true := by decide
def e2259519512602 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259519512602 : Closed e2259519512602 ∧ code e2259519512602 = 11055612534810 := by decide
theorem cert_e2259519512602 : check e2259519512602 [[]] .width = true := by decide
def e2259519512694 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259519512694 : Closed e2259519512694 ∧ code e2259519512694 = 11055612534902 := by decide
theorem cert_e2259519512694 : check e2259519512694 [[]] .width = true := by decide
def e2259519512938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259519512938 : Closed e2259519512938 ∧ code e2259519512938 = 11055612535146 := by decide
theorem cert_e2259519512938 : check e2259519512938 [[]] .width = true := by decide
def e2259519512986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259519512986 : Closed e2259519512986 ∧ code e2259519512986 = 11055612535194 := by decide
theorem cert_e2259519512986 : check e2259519512986 [[]] .width = true := by decide
def e2259519557830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259519557830 : Closed e2259519557830 ∧ code e2259519557830 = 11055612580038 := by decide
theorem cert_e2259519557830 : check e2259519557830 [[]] .width = true := by decide
def e2259519565338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259519565338 : Closed e2259519565338 ∧ code e2259519565338 = 11055612587546 := by decide
theorem cert_e2259519565338 : check e2259519565338 [[]] .width = true := by decide
def e2259519568410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259519568410 : Closed e2259519568410 ∧ code e2259519568410 = 11055612590618 := by decide
theorem cert_e2259519568410 : check e2259519568410 [[]] .width = true := by decide
def e2259519606982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259519606982 : Closed e2259519606982 ∧ code e2259519606982 = 11055612629190 := by decide
theorem cert_e2259519606982 : check e2259519606982 [[]] .width = true := by decide
def e2259519610394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259519610394 : Closed e2259519610394 ∧ code e2259519610394 = 11055612632602 := by decide
theorem cert_e2259519610394 : check e2259519610394 [[]] .width = true := by decide
def e2259519619270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259519619270 : Closed e2259519619270 ∧ code e2259519619270 = 11055612641478 := by decide
theorem cert_e2259519619270 : check e2259519619270 [[]] .width = true := by decide
def e2259519627290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259519627290 : Closed e2259519627290 ∧ code e2259519627290 = 11055612649498 := by decide
theorem cert_e2259519627290 : check e2259519627290 [[]] .width = true := by decide
def e2259519627382 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259519627382 : Closed e2259519627382 ∧ code e2259519627382 = 11055612649590 := by decide
theorem cert_e2259519627382 : check e2259519627382 [[]] .width = true := by decide
def e2259519627626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259519627626 : Closed e2259519627626 ∧ code e2259519627626 = 11055612649834 := by decide
theorem cert_e2259519627626 : check e2259519627626 [[]] .width = true := by decide
def e2259519627674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259519627674 : Closed e2259519627674 ∧ code e2259519627674 = 11055612649882 := by decide
theorem cert_e2259519627674 : check e2259519627674 [[]] .width = true := by decide
def e2259519631558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259519631558 : Closed e2259519631558 ∧ code e2259519631558 = 11055612653766 := by decide
theorem cert_e2259519631558 : check e2259519631558 [[]] .width = true := by decide
def e2259519643674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259519643674 : Closed e2259519643674 ∧ code e2259519643674 = 11055612665882 := by decide
theorem cert_e2259519643674 : check e2259519643674 [[]] .width = true := by decide
def e2259519643766 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259519643766 : Closed e2259519643766 ∧ code e2259519643766 = 11055612665974 := by decide
theorem cert_e2259519643766 : check e2259519643766 [[]] .width = true := by decide
def e2259519644010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259519644010 : Closed e2259519644010 ∧ code e2259519644010 = 11055612666218 := by decide
theorem cert_e2259519644010 : check e2259519644010 [[]] .width = true := by decide
def e2259519644058 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259519644058 : Closed e2259519644058 ∧ code e2259519644058 = 11055612666266 := by decide
theorem cert_e2259519644058 : check e2259519644058 [[]] .width = true := by decide
def e2259519653402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259519653402 : Closed e2259519653402 ∧ code e2259519653402 = 11055612675610 := by decide
theorem cert_e2259519653402 : check e2259519653402 [[]] .width = true := by decide
def e2259519656134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259519656134 : Closed e2259519656134 ∧ code e2259519656134 = 11055612678342 := by decide
theorem cert_e2259519656134 : check e2259519656134 [[]] .width = true := by decide
def e2259519975622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259519975622 : Closed e2259519975622 ∧ code e2259519975622 = 11055612997830 := by decide
theorem cert_e2259519975622 : check e2259519975622 [[]] .width = true := by decide
def e2259519983814 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259519983814 : Closed e2259519983814 ∧ code e2259519983814 = 11055613006022 := by decide
theorem cert_e2259519983814 : check e2259519983814 [[]] .width = true := by decide
def e2259520024090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520024090 : Closed e2259520024090 ∧ code e2259520024090 = 11055613046298 := by decide
theorem cert_e2259520024090 : check e2259520024090 [[]] .width = true := by decide
def e2259520026138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520026138 : Closed e2259520026138 ∧ code e2259520026138 = 11055613048346 := by decide
theorem cert_e2259520026138 : check e2259520026138 [[]] .width = true := by decide
def e2259520040474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520040474 : Closed e2259520040474 ∧ code e2259520040474 = 11055613062682 := by decide
theorem cert_e2259520040474 : check e2259520040474 [[]] .width = true := by decide
def e2259520043546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520043546 : Closed e2259520043546 ∧ code e2259520043546 = 11055613065754 := by decide
theorem cert_e2259520043546 : check e2259520043546 [[]] .width = true := by decide
def e2259520050714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520050714 : Closed e2259520050714 ∧ code e2259520050714 = 11055613072922 := by decide
theorem cert_e2259520050714 : check e2259520050714 [[]] .width = true := by decide
def e2259520051738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520051738 : Closed e2259520051738 ∧ code e2259520051738 = 11055613073946 := by decide
theorem cert_e2259520051738 : check e2259520051738 [[]] .width = true := by decide
def e2259520368838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520368838 : Closed e2259520368838 ∧ code e2259520368838 = 11055613391046 := by decide
theorem cert_e2259520368838 : check e2259520368838 [[]] .width = true := by decide
def e2259520384538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520384538 : Closed e2259520384538 ∧ code e2259520384538 = 11055613406746 := by decide
private def t_e2259520384538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259520384538 : ¬ IsSelfInterpreter e2259520384538 :=
  wSource (t := t_e2259520384538) (replay_sound (ps := []) (t := e2259520384538) (by decide)) (by decide)
def e2259520386586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520386586 : Closed e2259520386586 ∧ code e2259520386586 = 11055613408794 := by decide
private def t_e2259520386586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259520386586 : ¬ IsSelfInterpreter e2259520386586 :=
  wSource (t := t_e2259520386586) (replay_sound (ps := []) (t := e2259520386586) (by decide)) (by decide)
def e2259520504006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259520504006 : Closed e2259520504006 ∧ code e2259520504006 = 11055613526214 := by decide
theorem cert_e2259520504006 : check e2259520504006 [[]] .width = true := by decide
def e2259520524486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520524486 : Closed e2259520524486 ∧ code e2259520524486 = 11055613546694 := by decide
theorem cert_e2259520524486 : check e2259520524486 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2259517238810
#print axioms Blc.Floor43.cert_e2259517240858
#print axioms Blc.Floor43.cert_e2259517382170
#print axioms Blc.Floor43.cert_e2259517399158
#print axioms Blc.Floor43.cert_e2259517399402
#print axioms Blc.Floor43.cert_e2259517399450
#print axioms Blc.Floor43.cert_e2259517410842
#print axioms Blc.Floor43.cert_e2259520384538
#print axioms Blc.Floor43.cert_e2259520386586
