import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598745642106 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e598745642106 : Closed e598745642106 ∧ code e598745642106 = 9394838664314 := by decide
theorem cert_e598745642106 : check e598745642106 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745642270 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e598745642270 : Closed e598745642270 ∧ code e598745642270 = 9394838664478 := by decide
theorem cert_e598745642270 : check e598745642270 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745642438 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e598745642438 : Closed e598745642438 ∧ code e598745642438 = 9394838664646 := by decide
theorem cert_e598745642438 : check e598745642438 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745642778 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e598745642778 : Closed e598745642778 ∧ code e598745642778 = 9394838664986 := by decide
theorem cert_e598745642778 : check e598745642778 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745642822 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e598745642822 : Closed e598745642822 ∧ code e598745642822 = 9394838665030 := by decide
theorem cert_e598745642822 : check e598745642822 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745643222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e598745643222 : Closed e598745643222 ∧ code e598745643222 = 9394838665430 := by decide
theorem cert_e598745643222 : check e598745643222 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745643226 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e598745643226 : Closed e598745643226 ∧ code e598745643226 = 9394838665434 := by decide
theorem cert_e598745643226 : check e598745643226 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745643242 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e598745643242 : Closed e598745643242 ∧ code e598745643242 = 9394838665450 := by decide
theorem cert_e598745643242 : check e598745643242 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745643574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e598745643574 : Closed e598745643574 ∧ code e598745643574 = 9394838665782 := by decide
theorem cert_e598745643574 : check e598745643574 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745643578 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e598745643578 : Closed e598745643578 ∧ code e598745643578 = 9394838665786 := by decide
theorem cert_e598745643578 : check e598745643578 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745643662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e598745643662 : Closed e598745643662 ∧ code e598745643662 = 9394838665870 := by decide
theorem cert_e598745643662 : check e598745643662 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745643718 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e598745643718 : Closed e598745643718 ∧ code e598745643718 = 9394838665926 := by decide
theorem cert_e598745643718 : check e598745643718 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745643802 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e598745643802 : Closed e598745643802 ∧ code e598745643802 = 9394838666010 := by decide
theorem cert_e598745643802 : check e598745643802 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745643846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e598745643846 : Closed e598745643846 ∧ code e598745643846 = 9394838666054 := by decide
theorem cert_e598745643846 : check e598745643846 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745648366 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e598745648366 : Closed e598745648366 ∧ code e598745648366 = 9394838670574 := by decide
theorem cert_e598745648366 : check e598745648366 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745648374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e598745648374 : Closed e598745648374 ∧ code e598745648374 = 9394838670582 := by decide
theorem cert_e598745648374 : check e598745648374 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745648750 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e598745648750 : Closed e598745648750 ∧ code e598745648750 = 9394838670958 := by decide
theorem cert_e598745648750 : check e598745648750 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745648762 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e598745648762 : Closed e598745648762 ∧ code e598745648762 = 9394838670970 := by decide
theorem cert_e598745648762 : check e598745648762 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745648950 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e598745648950 : Closed e598745648950 ∧ code e598745648950 = 9394838671158 := by decide
theorem cert_e598745648950 : check e598745648950 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745648954 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e598745648954 : Closed e598745648954 ∧ code e598745648954 = 9394838671162 := by decide
theorem cert_e598745648954 : check e598745648954 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745651438 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e598745651438 : Closed e598745651438 ∧ code e598745651438 = 9394838673646 := by decide
theorem cert_e598745651438 : check e598745651438 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745651446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e598745651446 : Closed e598745651446 ∧ code e598745651446 = 9394838673654 := by decide
theorem cert_e598745651446 : check e598745651446 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745651998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e598745651998 : Closed e598745651998 ∧ code e598745651998 = 9394838674206 := by decide
theorem cert_e598745651998 : check e598745651998 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745652110 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e598745652110 : Closed e598745652110 ∧ code e598745652110 = 9394838674318 := by decide
theorem cert_e598745652110 : check e598745652110 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745652334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e598745652334 : Closed e598745652334 ∧ code e598745652334 = 9394838674542 := by decide
theorem cert_e598745652334 : check e598745652334 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745652346 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e598745652346 : Closed e598745652346 ∧ code e598745652346 = 9394838674554 := by decide
theorem cert_e598745652346 : check e598745652346 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745652510 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e598745652510 : Closed e598745652510 ∧ code e598745652510 = 9394838674718 := by decide
theorem cert_e598745652510 : check e598745652510 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745652678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e598745652678 : Closed e598745652678 ∧ code e598745652678 = 9394838674886 := by decide
theorem cert_e598745652678 : check e598745652678 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745652790 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e598745652790 : Closed e598745652790 ∧ code e598745652790 = 9394838674998 := by decide
theorem cert_e598745652790 : check e598745652790 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745652794 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e598745652794 : Closed e598745652794 ∧ code e598745652794 = 9394838675002 := by decide
theorem cert_e598745652794 : check e598745652794 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745652878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e598745652878 : Closed e598745652878 ∧ code e598745652878 = 9394838675086 := by decide
theorem cert_e598745652878 : check e598745652878 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745652934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e598745652934 : Closed e598745652934 ∧ code e598745652934 = 9394838675142 := by decide
theorem cert_e598745652934 : check e598745652934 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745655070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e598745655070 : Closed e598745655070 ∧ code e598745655070 = 9394838677278 := by decide
theorem cert_e598745655070 : check e598745655070 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745655182 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e598745655182 : Closed e598745655182 ∧ code e598745655182 = 9394838677390 := by decide
theorem cert_e598745655182 : check e598745655182 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745658142 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e598745658142 : Closed e598745658142 ∧ code e598745658142 = 9394838680350 := by decide
theorem cert_e598745658142 : check e598745658142 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745658310 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e598745658310 : Closed e598745658310 ∧ code e598745658310 = 9394838680518 := by decide
theorem cert_e598745658310 : check e598745658310 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745659790 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e598745659790 : Closed e598745659790 ∧ code e598745659790 = 9394838681998 := by decide
theorem cert_e598745659790 : check e598745659790 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745659846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e598745659846 : Closed e598745659846 ∧ code e598745659846 = 9394838682054 := by decide
theorem cert_e598745659846 : check e598745659846 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745663086 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e598745663086 : Closed e598745663086 ∧ code e598745663086 = 9394838685294 := by decide
theorem cert_e598745663086 : check e598745663086 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745663098 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e598745663098 : Closed e598745663098 ∧ code e598745663098 = 9394838685306 := by decide
theorem cert_e598745663098 : check e598745663098 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745663386 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e598745663386 : Closed e598745663386 ∧ code e598745663386 = 9394838685594 := by decide
theorem cert_e598745663386 : check e598745663386 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745664622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e598745664622 : Closed e598745664622 ∧ code e598745664622 = 9394838686830 := by decide
theorem cert_e598745664622 : check e598745664622 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745664634 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e598745664634 : Closed e598745664634 ∧ code e598745664634 = 9394838686842 := by decide
theorem cert_e598745664634 : check e598745664634 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745664798 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e598745664798 : Closed e598745664798 ∧ code e598745664798 = 9394838687006 := by decide
theorem cert_e598745664798 : check e598745664798 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745664966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e598745664966 : Closed e598745664966 ∧ code e598745664966 = 9394838687174 := by decide
theorem cert_e598745664966 : check e598745664966 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745665306 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e598745665306 : Closed e598745665306 ∧ code e598745665306 = 9394838687514 := by decide
theorem cert_e598745665306 : check e598745665306 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745665350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e598745665350 : Closed e598745665350 ∧ code e598745665350 = 9394838687558 := by decide
theorem cert_e598745665350 : check e598745665350 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745666334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e598745666334 : Closed e598745666334 ∧ code e598745666334 = 9394838688542 := by decide
theorem cert_e598745666334 : check e598745666334 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745666502 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e598745666502 : Closed e598745666502 ∧ code e598745666502 = 9394838688710 := by decide
theorem cert_e598745666502 : check e598745666502 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745668806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e598745668806 : Closed e598745668806 ∧ code e598745668806 = 9394838691014 := by decide
theorem cert_e598745668806 : check e598745668806 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745670454 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e598745670454 : Closed e598745670454 ∧ code e598745670454 = 9394838692662 := by decide
theorem cert_e598745670454 : check e598745670454 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745670458 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e598745670458 : Closed e598745670458 ∧ code e598745670458 = 9394838692666 := by decide
theorem cert_e598745670458 : check e598745670458 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745670554 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e598745670554 : Closed e598745670554 ∧ code e598745670554 = 9394838692762 := by decide
theorem cert_e598745670554 : check e598745670554 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745671222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e598745671222 : Closed e598745671222 ∧ code e598745671222 = 9394838693430 := by decide
theorem cert_e598745671222 : check e598745671222 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745671226 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e598745671226 : Closed e598745671226 ∧ code e598745671226 = 9394838693434 := by decide
theorem cert_e598745671226 : check e598745671226 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745671310 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e598745671310 : Closed e598745671310 ∧ code e598745671310 = 9394838693518 := by decide
theorem cert_e598745671310 : check e598745671310 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745671366 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e598745671366 : Closed e598745671366 ∧ code e598745671366 = 9394838693574 := by decide
theorem cert_e598745671366 : check e598745671366 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745671450 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e598745671450 : Closed e598745671450 ∧ code e598745671450 = 9394838693658 := by decide
theorem cert_e598745671450 : check e598745671450 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745671494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e598745671494 : Closed e598745671494 ∧ code e598745671494 = 9394838693702 := by decide
theorem cert_e598745671494 : check e598745671494 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745672078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e598745672078 : Closed e598745672078 ∧ code e598745672078 = 9394838694286 := by decide
theorem cert_e598745672078 : check e598745672078 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745672134 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e598745672134 : Closed e598745672134 ∧ code e598745672134 = 9394838694342 := by decide
theorem cert_e598745672134 : check e598745672134 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745672902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e598745672902 : Closed e598745672902 ∧ code e598745672902 = 9394838695110 := by decide
theorem cert_e598745672902 : check e598745672902 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745683678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e598745683678 : Closed e598745683678 ∧ code e598745683678 = 9394838705886 := by decide
theorem cert_e598745683678 : check e598745683678 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745683702 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e598745683702 : Closed e598745683702 ∧ code e598745683702 = 9394838705910 := by decide
theorem cert_e598745683702 : check e598745683702 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745683806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e598745683806 : Closed e598745683806 ∧ code e598745683806 = 9394838706014 := by decide
theorem cert_e598745683806 : check e598745683806 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745683834 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e598745683834 : Closed e598745683834 ∧ code e598745683834 = 9394838706042 := by decide
theorem cert_e598745683834 : check e598745683834 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745683926 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e598745683926 : Closed e598745683926 ∧ code e598745683926 = 9394838706134 := by decide
theorem cert_e598745683926 : check e598745683926 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745683930 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e598745683930 : Closed e598745683930 ∧ code e598745683930 = 9394838706138 := by decide
theorem cert_e598745683930 : check e598745683930 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745684446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e598745684446 : Closed e598745684446 ∧ code e598745684446 = 9394838706654 := by decide
theorem cert_e598745684446 : check e598745684446 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745684470 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e598745684470 : Closed e598745684470 ∧ code e598745684470 = 9394838706678 := by decide
theorem cert_e598745684470 : check e598745684470 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745685214 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e598745685214 : Closed e598745685214 ∧ code e598745685214 = 9394838707422 := by decide
theorem cert_e598745685214 : check e598745685214 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745685242 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e598745685242 : Closed e598745685242 ∧ code e598745685242 = 9394838707450 := by decide
theorem cert_e598745685242 : check e598745685242 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745685814 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e598745685814 : Closed e598745685814 ∧ code e598745685814 = 9394838708022 := by decide
theorem cert_e598745685814 : check e598745685814 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745685818 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e598745685818 : Closed e598745685818 ∧ code e598745685818 = 9394838708026 := by decide
theorem cert_e598745685818 : check e598745685818 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598745700590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e598745700590 : Closed e598745700590 ∧ code e598745700590 = 9394838722798 := by decide
theorem cert_e598745700590 : check e598745700590 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745700598 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e598745700598 : Closed e598745700598 ∧ code e598745700598 = 9394838722806 := by decide
theorem cert_e598745700598 : check e598745700598 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745701150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e598745701150 : Closed e598745701150 ∧ code e598745701150 = 9394838723358 := by decide
theorem cert_e598745701150 : check e598745701150 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745701262 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e598745701262 : Closed e598745701262 ∧ code e598745701262 = 9394838723470 := by decide
theorem cert_e598745701262 : check e598745701262 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745701486 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e598745701486 : Closed e598745701486 ∧ code e598745701486 = 9394838723694 := by decide
theorem cert_e598745701486 : check e598745701486 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745701498 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e598745701498 : Closed e598745701498 ∧ code e598745701498 = 9394838723706 := by decide
theorem cert_e598745701498 : check e598745701498 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745701662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e598745701662 : Closed e598745701662 ∧ code e598745701662 = 9394838723870 := by decide
theorem cert_e598745701662 : check e598745701662 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745701830 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e598745701830 : Closed e598745701830 ∧ code e598745701830 = 9394838724038 := by decide
theorem cert_e598745701830 : check e598745701830 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745701942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e598745701942 : Closed e598745701942 ∧ code e598745701942 = 9394838724150 := by decide
theorem cert_e598745701942 : check e598745701942 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745701946 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e598745701946 : Closed e598745701946 ∧ code e598745701946 = 9394838724154 := by decide
theorem cert_e598745701946 : check e598745701946 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745702030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e598745702030 : Closed e598745702030 ∧ code e598745702030 = 9394838724238 := by decide
theorem cert_e598745702030 : check e598745702030 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745702086 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e598745702086 : Closed e598745702086 ∧ code e598745702086 = 9394838724294 := by decide
theorem cert_e598745702086 : check e598745702086 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745704222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e598745704222 : Closed e598745704222 ∧ code e598745704222 = 9394838726430 := by decide
theorem cert_e598745704222 : check e598745704222 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745704334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e598745704334 : Closed e598745704334 ∧ code e598745704334 = 9394838726542 := by decide
theorem cert_e598745704334 : check e598745704334 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745707294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e598745707294 : Closed e598745707294 ∧ code e598745707294 = 9394838729502 := by decide
theorem cert_e598745707294 : check e598745707294 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745707462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e598745707462 : Closed e598745707462 ∧ code e598745707462 = 9394838729670 := by decide
theorem cert_e598745707462 : check e598745707462 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745708942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e598745708942 : Closed e598745708942 ∧ code e598745708942 = 9394838731150 := by decide
theorem cert_e598745708942 : check e598745708942 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745708998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e598745708998 : Closed e598745708998 ∧ code e598745708998 = 9394838731206 := by decide
theorem cert_e598745708998 : check e598745708998 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745746286 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598745746286 : Closed e598745746286 ∧ code e598745746286 = 9394838768494 := by decide
theorem cert_e598745746286 : check e598745746286 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745746294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598745746294 : Closed e598745746294 ∧ code e598745746294 = 9394838768502 := by decide
theorem cert_e598745746294 : check e598745746294 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745746350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598745746350 : Closed e598745746350 ∧ code e598745746350 = 9394838768558 := by decide
theorem cert_e598745746350 : check e598745746350 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745746362 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598745746362 : Closed e598745746362 ∧ code e598745746362 = 9394838768570 := by decide
theorem cert_e598745746362 : check e598745746362 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745746390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598745746390 : Closed e598745746390 ∧ code e598745746390 = 9394838768598 := by decide
theorem cert_e598745746390 : check e598745746390 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745746394 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598745746394 : Closed e598745746394 ∧ code e598745746394 = 9394838768602 := by decide
theorem cert_e598745746394 : check e598745746394 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745746670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598745746670 : Closed e598745746670 ∧ code e598745746670 = 9394838768878 := by decide
theorem cert_e598745746670 : check e598745746670 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745746678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598745746678 : Closed e598745746678 ∧ code e598745746678 = 9394838768886 := by decide
theorem cert_e598745746678 : check e598745746678 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745747054 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598745747054 : Closed e598745747054 ∧ code e598745747054 = 9394838769262 := by decide
theorem cert_e598745747054 : check e598745747054 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745747066 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598745747066 : Closed e598745747066 ∧ code e598745747066 = 9394838769274 := by decide
theorem cert_e598745747066 : check e598745747066 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745747254 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598745747254 : Closed e598745747254 ∧ code e598745747254 = 9394838769462 := by decide
theorem cert_e598745747254 : check e598745747254 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745747258 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598745747258 : Closed e598745747258 ∧ code e598745747258 = 9394838769466 := by decide
theorem cert_e598745747258 : check e598745747258 [[.under],[.under,.left],[.under],[.under,.under]] .smaller = true := by decide
def e598745754734 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e598745754734 : Closed e598745754734 ∧ code e598745754734 = 9394838776942 := by decide
theorem cert_e598745754734 : check e598745754734 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745754746 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e598745754746 : Closed e598745754746 ∧ code e598745754746 = 9394838776954 := by decide
theorem cert_e598745754746 : check e598745754746 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745754910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e598745754910 : Closed e598745754910 ∧ code e598745754910 = 9394838777118 := by decide
theorem cert_e598745754910 : check e598745754910 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745755078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e598745755078 : Closed e598745755078 ∧ code e598745755078 = 9394838777286 := by decide
theorem cert_e598745755078 : check e598745755078 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745755418 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e598745755418 : Closed e598745755418 ∧ code e598745755418 = 9394838777626 := by decide
theorem cert_e598745755418 : check e598745755418 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745755462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e598745755462 : Closed e598745755462 ∧ code e598745755462 = 9394838777670 := by decide
theorem cert_e598745755462 : check e598745755462 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745756446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e598745756446 : Closed e598745756446 ∧ code e598745756446 = 9394838778654 := by decide
theorem cert_e598745756446 : check e598745756446 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745756614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e598745756614 : Closed e598745756614 ∧ code e598745756614 = 9394838778822 := by decide
theorem cert_e598745756614 : check e598745756614 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745758918 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e598745758918 : Closed e598745758918 ∧ code e598745758918 = 9394838781126 := by decide
theorem cert_e598745758918 : check e598745758918 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745781814 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e598745781814 : Closed e598745781814 ∧ code e598745781814 = 9394838804022 := by decide
theorem cert_e598745781814 : check e598745781814 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745781818 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e598745781818 : Closed e598745781818 ∧ code e598745781818 = 9394838804026 := by decide
theorem cert_e598745781818 : check e598745781818 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745781902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e598745781902 : Closed e598745781902 ∧ code e598745781902 = 9394838804110 := by decide
theorem cert_e598745781902 : check e598745781902 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745781958 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e598745781958 : Closed e598745781958 ∧ code e598745781958 = 9394838804166 := by decide
theorem cert_e598745781958 : check e598745781958 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745782042 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e598745782042 : Closed e598745782042 ∧ code e598745782042 = 9394838804250 := by decide
theorem cert_e598745782042 : check e598745782042 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745782086 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e598745782086 : Closed e598745782086 ∧ code e598745782086 = 9394838804294 := by decide
theorem cert_e598745782086 : check e598745782086 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745782670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e598745782670 : Closed e598745782670 ∧ code e598745782670 = 9394838804878 := by decide
theorem cert_e598745782670 : check e598745782670 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745782726 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e598745782726 : Closed e598745782726 ∧ code e598745782726 = 9394838804934 := by decide
theorem cert_e598745782726 : check e598745782726 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598745783494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e598745783494 : Closed e598745783494 ∧ code e598745783494 = 9394838805702 := by decide
theorem cert_e598745783494 : check e598745783494 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e598746880238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e598746880238 : Closed e598746880238 ∧ code e598746880238 = 9394839902446 := by decide
theorem cert_e598746880238 : check e598746880238 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746880246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e598746880246 : Closed e598746880246 ∧ code e598746880246 = 9394839902454 := by decide
theorem cert_e598746880246 : check e598746880246 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746880798 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e598746880798 : Closed e598746880798 ∧ code e598746880798 = 9394839903006 := by decide
theorem cert_e598746880798 : check e598746880798 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746880910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e598746880910 : Closed e598746880910 ∧ code e598746880910 = 9394839903118 := by decide
theorem cert_e598746880910 : check e598746880910 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746881134 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e598746881134 : Closed e598746881134 ∧ code e598746881134 = 9394839903342 := by decide
theorem cert_e598746881134 : check e598746881134 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746881146 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e598746881146 : Closed e598746881146 ∧ code e598746881146 = 9394839903354 := by decide
theorem cert_e598746881146 : check e598746881146 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746881310 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e598746881310 : Closed e598746881310 ∧ code e598746881310 = 9394839903518 := by decide
theorem cert_e598746881310 : check e598746881310 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746881478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e598746881478 : Closed e598746881478 ∧ code e598746881478 = 9394839903686 := by decide
theorem cert_e598746881478 : check e598746881478 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746881590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e598746881590 : Closed e598746881590 ∧ code e598746881590 = 9394839903798 := by decide
theorem cert_e598746881590 : check e598746881590 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746881594 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e598746881594 : Closed e598746881594 ∧ code e598746881594 = 9394839903802 := by decide
theorem cert_e598746881594 : check e598746881594 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746881678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e598746881678 : Closed e598746881678 ∧ code e598746881678 = 9394839903886 := by decide
theorem cert_e598746881678 : check e598746881678 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746881734 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e598746881734 : Closed e598746881734 ∧ code e598746881734 = 9394839903942 := by decide
theorem cert_e598746881734 : check e598746881734 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746883870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e598746883870 : Closed e598746883870 ∧ code e598746883870 = 9394839906078 := by decide
theorem cert_e598746883870 : check e598746883870 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746883982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e598746883982 : Closed e598746883982 ∧ code e598746883982 = 9394839906190 := by decide
theorem cert_e598746883982 : check e598746883982 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746886942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e598746886942 : Closed e598746886942 ∧ code e598746886942 = 9394839909150 := by decide
theorem cert_e598746886942 : check e598746886942 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746887110 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e598746887110 : Closed e598746887110 ∧ code e598746887110 = 9394839909318 := by decide
theorem cert_e598746887110 : check e598746887110 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746888590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e598746888590 : Closed e598746888590 ∧ code e598746888590 = 9394839910798 := by decide
theorem cert_e598746888590 : check e598746888590 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598746888646 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e598746888646 : Closed e598746888646 ∧ code e598746888646 = 9394839910854 := by decide
theorem cert_e598746888646 : check e598746888646 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e598751581918 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e598751581918 : Closed e598751581918 ∧ code e598751581918 = 9394844604126 := by decide
theorem cert_e598751581918 : check e598751581918 [[.under],[.under,.left]] .chain = true := by decide
def e598751581942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e598751581942 : Closed e598751581942 ∧ code e598751581942 = 9394844604150 := by decide
theorem cert_e598751581942 : check e598751581942 [[.under],[.under,.left]] .chain = true := by decide
def e598751582046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e598751582046 : Closed e598751582046 ∧ code e598751582046 = 9394844604254 := by decide
theorem cert_e598751582046 : check e598751582046 [[.under],[.under,.left]] .chain = true := by decide
def e598751582074 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e598751582074 : Closed e598751582074 ∧ code e598751582074 = 9394844604282 := by decide
theorem cert_e598751582074 : check e598751582074 [[.under],[.under,.left]] .chain = true := by decide
def e598751582166 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e598751582166 : Closed e598751582166 ∧ code e598751582166 = 9394844604374 := by decide
theorem cert_e598751582166 : check e598751582166 [[.under],[.under,.left]] .chain = true := by decide
def e598751582170 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e598751582170 : Closed e598751582170 ∧ code e598751582170 = 9394844604378 := by decide
theorem cert_e598751582170 : check e598751582170 [[.under],[.under,.left]] .chain = true := by decide
def e598751582686 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e598751582686 : Closed e598751582686 ∧ code e598751582686 = 9394844604894 := by decide
theorem cert_e598751582686 : check e598751582686 [[.under],[.under,.left]] .chain = true := by decide
def e598751582710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e598751582710 : Closed e598751582710 ∧ code e598751582710 = 9394844604918 := by decide
theorem cert_e598751582710 : check e598751582710 [[.under],[.under,.left]] .chain = true := by decide
def e598751583454 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e598751583454 : Closed e598751583454 ∧ code e598751583454 = 9394844605662 := by decide
theorem cert_e598751583454 : check e598751583454 [[.under],[.under,.left]] .chain = true := by decide
def e598751583482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e598751583482 : Closed e598751583482 ∧ code e598751583482 = 9394844605690 := by decide
theorem cert_e598751583482 : check e598751583482 [[.under],[.under,.left]] .chain = true := by decide
def e598751584054 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e598751584054 : Closed e598751584054 ∧ code e598751584054 = 9394844606262 := by decide
theorem cert_e598751584054 : check e598751584054 [[.under],[.under,.left]] .chain = true := by decide
def e598751584058 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e598751584058 : Closed e598751584058 ∧ code e598751584058 = 9394844606266 := by decide
theorem cert_e598751584058 : check e598751584058 [[.under],[.under,.left]] .chain = true := by decide
def e598751598830 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e598751598830 : Closed e598751598830 ∧ code e598751598830 = 9394844621038 := by decide
theorem cert_e598751598830 : check e598751598830 [[.under],[.under,.left]] .chain = true := by decide
def e598751598838 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e598751598838 : Closed e598751598838 ∧ code e598751598838 = 9394844621046 := by decide
theorem cert_e598751598838 : check e598751598838 [[.under],[.under,.left]] .chain = true := by decide
def e598751599390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e598751599390 : Closed e598751599390 ∧ code e598751599390 = 9394844621598 := by decide
theorem cert_e598751599390 : check e598751599390 [[.under],[.under,.left]] .chain = true := by decide
def e598751599502 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e598751599502 : Closed e598751599502 ∧ code e598751599502 = 9394844621710 := by decide
theorem cert_e598751599502 : check e598751599502 [[.under],[.under,.left]] .chain = true := by decide
def e598751599726 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e598751599726 : Closed e598751599726 ∧ code e598751599726 = 9394844621934 := by decide
theorem cert_e598751599726 : check e598751599726 [[.under],[.under,.left]] .chain = true := by decide
def e598751599738 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e598751599738 : Closed e598751599738 ∧ code e598751599738 = 9394844621946 := by decide
theorem cert_e598751599738 : check e598751599738 [[.under],[.under,.left]] .chain = true := by decide
def e598751599902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e598751599902 : Closed e598751599902 ∧ code e598751599902 = 9394844622110 := by decide
theorem cert_e598751599902 : check e598751599902 [[.under],[.under,.left]] .chain = true := by decide
def e598751600070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e598751600070 : Closed e598751600070 ∧ code e598751600070 = 9394844622278 := by decide
theorem cert_e598751600070 : check e598751600070 [[.under],[.under,.left]] .chain = true := by decide
end Blc.Floor43
