import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422362551166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 5)))))))))))
theorem wire_e2422362551166 : Closed e2422362551166 ∧ code e2422362551166 = 11218455573374 := by decide
theorem cert_e2422362551166 : check e2422362551166 [[],[]] .three = true := by decide
def e2422362551182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))))
theorem wire_e2422362551182 : Closed e2422362551182 ∧ code e2422362551182 = 11218455573390 := by decide
theorem cert_e2422362551182 : check e2422362551182 [[],[]] .smaller = true := by decide
def e2422362551194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422362551194 : Closed e2422362551194 ∧ code e2422362551194 = 11218455573402 := by decide
theorem cert_e2422362551194 : check e2422362551194 [[],[]] .smaller = true := by decide
def e2422362551262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422362551262 : Closed e2422362551262 ∧ code e2422362551262 = 11218455573470 := by decide
theorem cert_e2422362551262 : check e2422362551262 [[],[]] .smaller = true := by decide
def e2422362551278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422362551278 : Closed e2422362551278 ∧ code e2422362551278 = 11218455573486 := by decide
theorem cert_e2422362551278 : check e2422362551278 [[],[]] .smaller = true := by decide
def e2422362551290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 5) (.var 0)))))))))))
theorem wire_e2422362551290 : Closed e2422362551290 ∧ code e2422362551290 = 11218455573498 := by decide
theorem cert_e2422362551290 : check e2422362551290 [[],[]] .three = true := by decide
def e2422362552438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))))
theorem wire_e2422362552438 : Closed e2422362552438 ∧ code e2422362552438 = 11218455574646 := by decide
theorem cert_e2422362552438 : check e2422362552438 [[],[]] .smaller = true := by decide
def e2422362552682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))))
theorem wire_e2422362552682 : Closed e2422362552682 ∧ code e2422362552682 = 11218455574890 := by decide
theorem cert_e2422362552682 : check e2422362552682 [[],[]] .smaller = true := by decide
def e2422362552718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e2422362552718 : Closed e2422362552718 ∧ code e2422362552718 = 11218455574926 := by decide
theorem cert_e2422362552718 : check e2422362552718 [[],[]] .smaller = true := by decide
def e2422362552730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422362552730 : Closed e2422362552730 ∧ code e2422362552730 = 11218455574938 := by decide
theorem cert_e2422362552730 : check e2422362552730 [[],[]] .smaller = true := by decide
def e2422362552774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e2422362552774 : Closed e2422362552774 ∧ code e2422362552774 = 11218455574982 := by decide
theorem cert_e2422362552774 : check e2422362552774 [[],[]] .smaller = true := by decide
def e2422362552798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422362552798 : Closed e2422362552798 ∧ code e2422362552798 = 11218455575006 := by decide
theorem cert_e2422362552798 : check e2422362552798 [[],[]] .smaller = true := by decide
def e2422362552822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422362552822 : Closed e2422362552822 ∧ code e2422362552822 = 11218455575030 := by decide
theorem cert_e2422362552822 : check e2422362552822 [[],[]] .smaller = true := by decide
def e2422362553566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422362553566 : Closed e2422362553566 ∧ code e2422362553566 = 11218455575774 := by decide
theorem cert_e2422362553566 : check e2422362553566 [[],[]] .smaller = true := by decide
def e2422362553594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422362553594 : Closed e2422362553594 ∧ code e2422362553594 = 11218455575802 := by decide
theorem cert_e2422362553594 : check e2422362553594 [[],[]] .smaller = true := by decide
def e2422362553966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362553966 : Closed e2422362553966 ∧ code e2422362553966 = 11218455576174 := by decide
theorem cert_e2422362553966 : check e2422362553966 [[],[]] .smaller = true := by decide
def e2422362553974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422362553974 : Closed e2422362553974 ∧ code e2422362553974 = 11218455576182 := by decide
theorem cert_e2422362553974 : check e2422362553974 [[],[]] .smaller = true := by decide
def e2422362553978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362553978 : Closed e2422362553978 ∧ code e2422362553978 = 11218455576186 := by decide
theorem cert_e2422362553978 : check e2422362553978 [[],[]] .smaller = true := by decide
def e2422362554266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 5) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362554266 : Closed e2422362554266 ∧ code e2422362554266 = 11218455576474 := by decide
theorem cert_e2422362554266 : check e2422362554266 [[],[]] .three = true := by decide
def e2422362576438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e2422362576438 : Closed e2422362576438 ∧ code e2422362576438 = 11218455598646 := by decide
theorem cert_e2422362576438 : check e2422362576438 [[],[]] .smaller = true := by decide
def e2422362576442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e2422362576442 : Closed e2422362576442 ∧ code e2422362576442 = 11218455598650 := by decide
theorem cert_e2422362576442 : check e2422362576442 [[],[]] .smaller = true := by decide
def e2422362576526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e2422362576526 : Closed e2422362576526 ∧ code e2422362576526 = 11218455598734 := by decide
theorem cert_e2422362576526 : check e2422362576526 [[],[]] .smaller = true := by decide
def e2422362576574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 4))))))))))
theorem wire_e2422362576574 : Closed e2422362576574 ∧ code e2422362576574 = 11218455598782 := by decide
theorem cert_e2422362576574 : check e2422362576574 [[],[]] .smaller = true := by decide
def e2422362576582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e2422362576582 : Closed e2422362576582 ∧ code e2422362576582 = 11218455598790 := by decide
theorem cert_e2422362576582 : check e2422362576582 [[],[]] .smaller = true := by decide
def e2422362576606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2422362576606 : Closed e2422362576606 ∧ code e2422362576606 = 11218455598814 := by decide
theorem cert_e2422362576606 : check e2422362576606 [[],[]] .smaller = true := by decide
def e2422362576622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 2))))))))))
theorem wire_e2422362576622 : Closed e2422362576622 ∧ code e2422362576622 = 11218455598830 := by decide
theorem cert_e2422362576622 : check e2422362576622 [[],[]] .smaller = true := by decide
def e2422362576630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2422362576630 : Closed e2422362576630 ∧ code e2422362576630 = 11218455598838 := by decide
theorem cert_e2422362576630 : check e2422362576630 [[],[]] .smaller = true := by decide
def e2422362576634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 4)) (.var 0))))))))))
theorem wire_e2422362576634 : Closed e2422362576634 ∧ code e2422362576634 = 11218455598842 := by decide
theorem cert_e2422362576634 : check e2422362576634 [[],[]] .smaller = true := by decide
def e2422362576666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))))
theorem wire_e2422362576666 : Closed e2422362576666 ∧ code e2422362576666 = 11218455598874 := by decide
theorem cert_e2422362576666 : check e2422362576666 [[],[]] .smaller = true := by decide
def e2422362576710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))))
theorem wire_e2422362576710 : Closed e2422362576710 ∧ code e2422362576710 = 11218455598918 := by decide
theorem cert_e2422362576710 : check e2422362576710 [[],[]] .smaller = true := by decide
def e2422362576734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2422362576734 : Closed e2422362576734 ∧ code e2422362576734 = 11218455598942 := by decide
theorem cert_e2422362576734 : check e2422362576734 [[],[]] .smaller = true := by decide
def e2422362576750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e2422362576750 : Closed e2422362576750 ∧ code e2422362576750 = 11218455598958 := by decide
theorem cert_e2422362576750 : check e2422362576750 [[],[]] .smaller = true := by decide
def e2422362576758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e2422362576758 : Closed e2422362576758 ∧ code e2422362576758 = 11218455598966 := by decide
theorem cert_e2422362576758 : check e2422362576758 [[],[]] .smaller = true := by decide
def e2422362576762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2422362576762 : Closed e2422362576762 ∧ code e2422362576762 = 11218455598970 := by decide
theorem cert_e2422362576762 : check e2422362576762 [[],[]] .smaller = true := by decide
def e2422362576814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 2))))))))))
theorem wire_e2422362576814 : Closed e2422362576814 ∧ code e2422362576814 = 11218455599022 := by decide
theorem cert_e2422362576814 : check e2422362576814 [[],[]] .smaller = true := by decide
def e2422362576822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e2422362576822 : Closed e2422362576822 ∧ code e2422362576822 = 11218455599030 := by decide
theorem cert_e2422362576822 : check e2422362576822 [[],[]] .smaller = true := by decide
def e2422362576826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 0))))))))))
theorem wire_e2422362576826 : Closed e2422362576826 ∧ code e2422362576826 = 11218455599034 := by decide
theorem cert_e2422362576826 : check e2422362576826 [[],[]] .smaller = true := by decide
def e2422362576854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2422362576854 : Closed e2422362576854 ∧ code e2422362576854 = 11218455599062 := by decide
theorem cert_e2422362576854 : check e2422362576854 [[],[]] .smaller = true := by decide
def e2422362576858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2422362576858 : Closed e2422362576858 ∧ code e2422362576858 = 11218455599066 := by decide
theorem cert_e2422362576858 : check e2422362576858 [[],[]] .smaller = true := by decide
def e2422362576874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 4) (.var 0)) (.var 0))))))))))
theorem wire_e2422362576874 : Closed e2422362576874 ∧ code e2422362576874 = 11218455599082 := by decide
theorem cert_e2422362576874 : check e2422362576874 [[],[]] .smaller = true := by decide
def e2422362577294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e2422362577294 : Closed e2422362577294 ∧ code e2422362577294 = 11218455599502 := by decide
theorem cert_e2422362577294 : check e2422362577294 [[],[]] .smaller = true := by decide
def e2422362577342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422362577342 : Closed e2422362577342 ∧ code e2422362577342 = 11218455599550 := by decide
theorem cert_e2422362577342 : check e2422362577342 [[],[]] .smaller = true := by decide
def e2422362577350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e2422362577350 : Closed e2422362577350 ∧ code e2422362577350 = 11218455599558 := by decide
theorem cert_e2422362577350 : check e2422362577350 [[],[]] .smaller = true := by decide
def e2422362577374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422362577374 : Closed e2422362577374 ∧ code e2422362577374 = 11218455599582 := by decide
theorem cert_e2422362577374 : check e2422362577374 [[],[]] .smaller = true := by decide
def e2422362577390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422362577390 : Closed e2422362577390 ∧ code e2422362577390 = 11218455599598 := by decide
theorem cert_e2422362577390 : check e2422362577390 [[],[]] .smaller = true := by decide
def e2422362577398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422362577398 : Closed e2422362577398 ∧ code e2422362577398 = 11218455599606 := by decide
theorem cert_e2422362577398 : check e2422362577398 [[],[]] .smaller = true := by decide
def e2422362577402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422362577402 : Closed e2422362577402 ∧ code e2422362577402 = 11218455599610 := by decide
theorem cert_e2422362577402 : check e2422362577402 [[],[]] .smaller = true := by decide
def e2422362578118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))))
theorem wire_e2422362578118 : Closed e2422362578118 ∧ code e2422362578118 = 11218455600326 := by decide
theorem cert_e2422362578118 : check e2422362578118 [[],[]] .smaller = true := by decide
def e2422362578142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422362578142 : Closed e2422362578142 ∧ code e2422362578142 = 11218455600350 := by decide
theorem cert_e2422362578142 : check e2422362578142 [[],[]] .smaller = true := by decide
def e2422362578158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422362578158 : Closed e2422362578158 ∧ code e2422362578158 = 11218455600366 := by decide
theorem cert_e2422362578158 : check e2422362578158 [[],[]] .smaller = true := by decide
def e2422362578166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422362578166 : Closed e2422362578166 ∧ code e2422362578166 = 11218455600374 := by decide
theorem cert_e2422362578166 : check e2422362578166 [[],[]] .smaller = true := by decide
def e2422362578170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422362578170 : Closed e2422362578170 ∧ code e2422362578170 = 11218455600378 := by decide
theorem cert_e2422362578170 : check e2422362578170 [[],[]] .smaller = true := by decide
def e2422362578542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362578542 : Closed e2422362578542 ∧ code e2422362578542 = 11218455600750 := by decide
theorem cert_e2422362578542 : check e2422362578542 [[],[]] .smaller = true := by decide
def e2422362578550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422362578550 : Closed e2422362578550 ∧ code e2422362578550 = 11218455600758 := by decide
theorem cert_e2422362578550 : check e2422362578550 [[],[]] .smaller = true := by decide
def e2422362578554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362578554 : Closed e2422362578554 ∧ code e2422362578554 = 11218455600762 := by decide
theorem cert_e2422362578554 : check e2422362578554 [[],[]] .smaller = true := by decide
def e2422362578742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422362578742 : Closed e2422362578742 ∧ code e2422362578742 = 11218455600950 := by decide
theorem cert_e2422362578742 : check e2422362578742 [[],[]] .smaller = true := by decide
def e2422362578746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422362578746 : Closed e2422362578746 ∧ code e2422362578746 = 11218455600954 := by decide
theorem cert_e2422362578746 : check e2422362578746 [[],[]] .smaller = true := by decide
def e2422362578842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 4) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362578842 : Closed e2422362578842 ∧ code e2422362578842 = 11218455601050 := by decide
theorem cert_e2422362578842 : check e2422362578842 [[],[]] .smaller = true := by decide
def e2422362590046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e2422362590046 : Closed e2422362590046 ∧ code e2422362590046 = 11218455612254 := by decide
theorem cert_e2422362590046 : check e2422362590046 [[],[]] .smaller = true := by decide
def e2422362590074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e2422362590074 : Closed e2422362590074 ∧ code e2422362590074 = 11218455612282 := by decide
theorem cert_e2422362590074 : check e2422362590074 [[],[]] .smaller = true := by decide
def e2422362590186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e2422362590186 : Closed e2422362590186 ∧ code e2422362590186 = 11218455612394 := by decide
theorem cert_e2422362590186 : check e2422362590186 [[],[]] .smaller = true := by decide
def e2422362590430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422362590430 : Closed e2422362590430 ∧ code e2422362590430 = 11218455612638 := by decide
theorem cert_e2422362590430 : check e2422362590430 [[],[]] .smaller = true := by decide
def e2422362590458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422362590458 : Closed e2422362590458 ∧ code e2422362590458 = 11218455612666 := by decide
theorem cert_e2422362590458 : check e2422362590458 [[],[]] .smaller = true := by decide
def e2422362591130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362591130 : Closed e2422362591130 ∧ code e2422362591130 = 11218455613338 := by decide
theorem cert_e2422362591130 : check e2422362591130 [[],[]] .smaller = true := by decide
def e2422362596782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422362596782 : Closed e2422362596782 ∧ code e2422362596782 = 11218455618990 := by decide
theorem cert_e2422362596782 : check e2422362596782 [[],[]] .three = true := by decide
def e2422362596790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2422362596790 : Closed e2422362596790 ∧ code e2422362596790 = 11218455618998 := by decide
theorem cert_e2422362596790 : check e2422362596790 [[],[]] .three = true := by decide
def e2422362596794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422362596794 : Closed e2422362596794 ∧ code e2422362596794 = 11218455619002 := by decide
theorem cert_e2422362596794 : check e2422362596794 [[],[]] .three = true := by decide
def e2422362596822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2422362596822 : Closed e2422362596822 ∧ code e2422362596822 = 11218455619030 := by decide
theorem cert_e2422362596822 : check e2422362596822 [[],[]] .three = true := by decide
def e2422362596826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2422362596826 : Closed e2422362596826 ∧ code e2422362596826 = 11218455619034 := by decide
theorem cert_e2422362596826 : check e2422362596826 [[],[]] .three = true := by decide
def e2422362596842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422362596842 : Closed e2422362596842 ∧ code e2422362596842 = 11218455619050 := by decide
theorem cert_e2422362596842 : check e2422362596842 [[],[]] .three = true := by decide
def e2422362596974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362596974 : Closed e2422362596974 ∧ code e2422362596974 = 11218455619182 := by decide
theorem cert_e2422362596974 : check e2422362596974 [[],[]] .three = true := by decide
def e2422362596982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422362596982 : Closed e2422362596982 ∧ code e2422362596982 = 11218455619190 := by decide
theorem cert_e2422362596982 : check e2422362596982 [[],[]] .three = true := by decide
def e2422362596986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362596986 : Closed e2422362596986 ∧ code e2422362596986 = 11218455619194 := by decide
theorem cert_e2422362596986 : check e2422362596986 [[],[]] .three = true := by decide
def e2422362597174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422362597174 : Closed e2422362597174 ∧ code e2422362597174 = 11218455619382 := by decide
theorem cert_e2422362597174 : check e2422362597174 [[],[]] .three = true := by decide
def e2422362597178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422362597178 : Closed e2422362597178 ∧ code e2422362597178 = 11218455619386 := by decide
theorem cert_e2422362597178 : check e2422362597178 [[],[]] .three = true := by decide
def e2422362597274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 5) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362597274 : Closed e2422362597274 ∧ code e2422362597274 = 11218455619482 := by decide
theorem cert_e2422362597274 : check e2422362597274 [[],[]] .three = true := by decide
def e2422363868014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422363868014 : Closed e2422363868014 ∧ code e2422363868014 = 11218456890222 := by decide
theorem cert_e2422363868014 : check e2422363868014 [[],[]] .smaller = true := by decide
def e2422363868022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422363868022 : Closed e2422363868022 ∧ code e2422363868022 = 11218456890230 := by decide
theorem cert_e2422363868022 : check e2422363868022 [[],[]] .smaller = true := by decide
def e2422363868078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422363868078 : Closed e2422363868078 ∧ code e2422363868078 = 11218456890286 := by decide
theorem cert_e2422363868078 : check e2422363868078 [[],[]] .smaller = true := by decide
def e2422363868090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422363868090 : Closed e2422363868090 ∧ code e2422363868090 = 11218456890298 := by decide
theorem cert_e2422363868090 : check e2422363868090 [[],[]] .smaller = true := by decide
def e2422363868118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422363868118 : Closed e2422363868118 ∧ code e2422363868118 = 11218456890326 := by decide
theorem cert_e2422363868118 : check e2422363868118 [[],[]] .smaller = true := by decide
def e2422363868122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422363868122 : Closed e2422363868122 ∧ code e2422363868122 = 11218456890330 := by decide
theorem cert_e2422363868122 : check e2422363868122 [[],[]] .smaller = true := by decide
def e2422363868398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422363868398 : Closed e2422363868398 ∧ code e2422363868398 = 11218456890606 := by decide
theorem cert_e2422363868398 : check e2422363868398 [[],[]] .smaller = true := by decide
def e2422363868406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422363868406 : Closed e2422363868406 ∧ code e2422363868406 = 11218456890614 := by decide
theorem cert_e2422363868406 : check e2422363868406 [[],[]] .smaller = true := by decide
def e2422363868782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422363868782 : Closed e2422363868782 ∧ code e2422363868782 = 11218456890990 := by decide
theorem cert_e2422363868782 : check e2422363868782 [[],[]] .smaller = true := by decide
def e2422363868794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422363868794 : Closed e2422363868794 ∧ code e2422363868794 = 11218456891002 := by decide
theorem cert_e2422363868794 : check e2422363868794 [[],[]] .smaller = true := by decide
def e2422363868982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422363868982 : Closed e2422363868982 ∧ code e2422363868982 = 11218456891190 := by decide
theorem cert_e2422363868982 : check e2422363868982 [[],[]] .smaller = true := by decide
def e2422363868986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422363868986 : Closed e2422363868986 ∧ code e2422363868986 = 11218456891194 := by decide
theorem cert_e2422363868986 : check e2422363868986 [[],[]] .smaller = true := by decide
def e2422364230518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422364230518 : Closed e2422364230518 ∧ code e2422364230518 = 11218457252726 := by decide
theorem cert_e2422364230518 : check e2422364230518 [[],[]] .smaller = true := by decide
def e2422364230586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422364230586 : Closed e2422364230586 ∧ code e2422364230586 = 11218457252794 := by decide
theorem cert_e2422364230586 : check e2422364230586 [[],[]] .smaller = true := by decide
def e2422364230614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422364230614 : Closed e2422364230614 ∧ code e2422364230614 = 11218457252822 := by decide
theorem cert_e2422364230614 : check e2422364230614 [[],[]] .smaller = true := by decide
def e2422364230618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422364230618 : Closed e2422364230618 ∧ code e2422364230618 = 11218457252826 := by decide
theorem cert_e2422364230618 : check e2422364230618 [[],[]] .smaller = true := by decide
def e2422364357998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422364357998 : Closed e2422364357998 ∧ code e2422364357998 = 11218457380206 := by decide
theorem cert_e2422364357998 : check e2422364357998 [[],[]] .smaller = true := by decide
def e2422364358006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422364358006 : Closed e2422364358006 ∧ code e2422364358006 = 11218457380214 := by decide
theorem cert_e2422364358006 : check e2422364358006 [[],[]] .smaller = true := by decide
def e2422364358062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422364358062 : Closed e2422364358062 ∧ code e2422364358062 = 11218457380270 := by decide
theorem cert_e2422364358062 : check e2422364358062 [[],[]] .smaller = true := by decide
def e2422364358074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422364358074 : Closed e2422364358074 ∧ code e2422364358074 = 11218457380282 := by decide
theorem cert_e2422364358074 : check e2422364358074 [[],[]] .smaller = true := by decide
def e2422364358102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422364358102 : Closed e2422364358102 ∧ code e2422364358102 = 11218457380310 := by decide
theorem cert_e2422364358102 : check e2422364358102 [[],[]] .smaller = true := by decide
def e2422364358106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422364358106 : Closed e2422364358106 ∧ code e2422364358106 = 11218457380314 := by decide
theorem cert_e2422364358106 : check e2422364358106 [[],[]] .smaller = true := by decide
def e2422364361070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e2422364361070 : Closed e2422364361070 ∧ code e2422364361070 = 11218457383278 := by decide
theorem cert_e2422364361070 : check e2422364361070 [[],[]] .smaller = true := by decide
def e2422364361078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e2422364361078 : Closed e2422364361078 ∧ code e2422364361078 = 11218457383286 := by decide
theorem cert_e2422364361078 : check e2422364361078 [[],[]] .smaller = true := by decide
def e2422364362174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 4))))))))
theorem wire_e2422364362174 : Closed e2422364362174 ∧ code e2422364362174 = 11218457384382 := by decide
theorem cert_e2422364362174 : check e2422364362174 [[],[]] .three = true := by decide
def e2422364362206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e2422364362206 : Closed e2422364362206 ∧ code e2422364362206 = 11218457384414 := by decide
theorem cert_e2422364362206 : check e2422364362206 [[],[]] .smaller = true := by decide
def e2422364362222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e2422364362222 : Closed e2422364362222 ∧ code e2422364362222 = 11218457384430 := by decide
theorem cert_e2422364362222 : check e2422364362222 [[],[]] .smaller = true := by decide
def e2422364362230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 4)) (.var 1))))))))
theorem wire_e2422364362230 : Closed e2422364362230 ∧ code e2422364362230 = 11218457384438 := by decide
theorem cert_e2422364362230 : check e2422364362230 [[],[]] .three = true := by decide
def e2422364362286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422364362286 : Closed e2422364362286 ∧ code e2422364362286 = 11218457384494 := by decide
theorem cert_e2422364362286 : check e2422364362286 [[],[]] .smaller = true := by decide
def e2422364362430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 4))))))))
theorem wire_e2422364362430 : Closed e2422364362430 ∧ code e2422364362430 = 11218457384638 := by decide
theorem cert_e2422364362430 : check e2422364362430 [[],[]] .three = true := by decide
def e2422364362462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e2422364362462 : Closed e2422364362462 ∧ code e2422364362462 = 11218457384670 := by decide
theorem cert_e2422364362462 : check e2422364362462 [[],[]] .smaller = true := by decide
def e2422364362466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422364362466 : Closed e2422364362466 ∧ code e2422364362466 = 11218457384674 := by decide
theorem cert_e2422364362466 : check e2422364362466 [[],[]] .smaller = true := by decide
def e2422364362478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e2422364362478 : Closed e2422364362478 ∧ code e2422364362478 = 11218457384686 := by decide
theorem cert_e2422364362478 : check e2422364362478 [[],[]] .smaller = true := by decide
def e2422364362486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e2422364362486 : Closed e2422364362486 ∧ code e2422364362486 = 11218457384694 := by decide
theorem cert_e2422364362486 : check e2422364362486 [[],[]] .smaller = true := by decide
def e2422364362490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 4)) (.var 0))))))))
theorem wire_e2422364362490 : Closed e2422364362490 ∧ code e2422364362490 = 11218457384698 := by decide
theorem cert_e2422364362490 : check e2422364362490 [[],[]] .three = true := by decide
def e2422364362518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422364362518 : Closed e2422364362518 ∧ code e2422364362518 = 11218457384726 := by decide
theorem cert_e2422364362518 : check e2422364362518 [[],[]] .smaller = true := by decide
def e2422364362590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e2422364362590 : Closed e2422364362590 ∧ code e2422364362590 = 11218457384798 := by decide
theorem cert_e2422364362590 : check e2422364362590 [[],[]] .smaller = true := by decide
def e2422364362594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422364362594 : Closed e2422364362594 ∧ code e2422364362594 = 11218457384802 := by decide
theorem cert_e2422364362594 : check e2422364362594 [[],[]] .smaller = true := by decide
def e2422364362606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e2422364362606 : Closed e2422364362606 ∧ code e2422364362606 = 11218457384814 := by decide
theorem cert_e2422364362606 : check e2422364362606 [[],[]] .smaller = true := by decide
def e2422364362614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e2422364362614 : Closed e2422364362614 ∧ code e2422364362614 = 11218457384822 := by decide
theorem cert_e2422364362614 : check e2422364362614 [[],[]] .smaller = true := by decide
def e2422364362618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e2422364362618 : Closed e2422364362618 ∧ code e2422364362618 = 11218457384826 := by decide
theorem cert_e2422364362618 : check e2422364362618 [[],[]] .smaller = true := by decide
def e2422364362670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e2422364362670 : Closed e2422364362670 ∧ code e2422364362670 = 11218457384878 := by decide
theorem cert_e2422364362670 : check e2422364362670 [[],[]] .smaller = true := by decide
def e2422364362678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e2422364362678 : Closed e2422364362678 ∧ code e2422364362678 = 11218457384886 := by decide
theorem cert_e2422364362678 : check e2422364362678 [[],[]] .smaller = true := by decide
def e2422364362682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e2422364362682 : Closed e2422364362682 ∧ code e2422364362682 = 11218457384890 := by decide
theorem cert_e2422364362682 : check e2422364362682 [[],[]] .smaller = true := by decide
def e2422364362710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 0)) (.var 1))))))))
theorem wire_e2422364362710 : Closed e2422364362710 ∧ code e2422364362710 = 11218457384918 := by decide
theorem cert_e2422364362710 : check e2422364362710 [[],[]] .three = true := by decide
def e2422364362714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 1)) (.var 0))))))))
theorem wire_e2422364362714 : Closed e2422364362714 ∧ code e2422364362714 = 11218457384922 := by decide
theorem cert_e2422364362714 : check e2422364362714 [[],[]] .three = true := by decide
def e2422364362926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422364362926 : Closed e2422364362926 ∧ code e2422364362926 = 11218457385134 := by decide
theorem cert_e2422364362926 : check e2422364362926 [[],[]] .smaller = true := by decide
def e2422364362938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422364362938 : Closed e2422364362938 ∧ code e2422364362938 = 11218457385146 := by decide
theorem cert_e2422364362938 : check e2422364362938 [[],[]] .smaller = true := by decide
def e2422364363310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422364363310 : Closed e2422364363310 ∧ code e2422364363310 = 11218457385518 := by decide
theorem cert_e2422364363310 : check e2422364363310 [[],[]] .smaller = true := by decide
def e2422364363454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 4))))))))
theorem wire_e2422364363454 : Closed e2422364363454 ∧ code e2422364363454 = 11218457385662 := by decide
theorem cert_e2422364363454 : check e2422364363454 [[],[]] .three = true := by decide
def e2422364363486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2422364363486 : Closed e2422364363486 ∧ code e2422364363486 = 11218457385694 := by decide
theorem cert_e2422364363486 : check e2422364363486 [[],[]] .smaller = true := by decide
def e2422364363490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422364363490 : Closed e2422364363490 ∧ code e2422364363490 = 11218457385698 := by decide
theorem cert_e2422364363490 : check e2422364363490 [[],[]] .smaller = true := by decide
def e2422364363502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e2422364363502 : Closed e2422364363502 ∧ code e2422364363502 = 11218457385710 := by decide
theorem cert_e2422364363502 : check e2422364363502 [[],[]] .smaller = true := by decide
def e2422364363510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2422364363510 : Closed e2422364363510 ∧ code e2422364363510 = 11218457385718 := by decide
theorem cert_e2422364363510 : check e2422364363510 [[],[]] .smaller = true := by decide
def e2422364363514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 4)) (.var 0))))))))
theorem wire_e2422364363514 : Closed e2422364363514 ∧ code e2422364363514 = 11218457385722 := by decide
theorem cert_e2422364363514 : check e2422364363514 [[],[]] .three = true := by decide
def e2422364363614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2422364363614 : Closed e2422364363614 ∧ code e2422364363614 = 11218457385822 := by decide
theorem cert_e2422364363614 : check e2422364363614 [[],[]] .smaller = true := by decide
def e2422364363630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e2422364363630 : Closed e2422364363630 ∧ code e2422364363630 = 11218457385838 := by decide
theorem cert_e2422364363630 : check e2422364363630 [[],[]] .smaller = true := by decide
def e2422364363638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e2422364363638 : Closed e2422364363638 ∧ code e2422364363638 = 11218457385846 := by decide
theorem cert_e2422364363638 : check e2422364363638 [[],[]] .smaller = true := by decide
def e2422364363642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2422364363642 : Closed e2422364363642 ∧ code e2422364363642 = 11218457385850 := by decide
theorem cert_e2422364363642 : check e2422364363642 [[],[]] .smaller = true := by decide
def e2422364363658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364363658 : Closed e2422364363658 ∧ code e2422364363658 = 11218457385866 := by decide
theorem cert_e2422364363658 : check e2422364363658 [[],[]] .smaller = true := by decide
def e2422364363682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364363682 : Closed e2422364363682 ∧ code e2422364363682 = 11218457385890 := by decide
theorem cert_e2422364363682 : check e2422364363682 [[],[]] .smaller = true := by decide
def e2422364363694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e2422364363694 : Closed e2422364363694 ∧ code e2422364363694 = 11218457385902 := by decide
theorem cert_e2422364363694 : check e2422364363694 [[],[]] .smaller = true := by decide
def e2422364363702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e2422364363702 : Closed e2422364363702 ∧ code e2422364363702 = 11218457385910 := by decide
theorem cert_e2422364363702 : check e2422364363702 [[],[]] .smaller = true := by decide
def e2422364363706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e2422364363706 : Closed e2422364363706 ∧ code e2422364363706 = 11218457385914 := by decide
theorem cert_e2422364363706 : check e2422364363706 [[],[]] .smaller = true := by decide
def e2422364363734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2422364363734 : Closed e2422364363734 ∧ code e2422364363734 = 11218457385942 := by decide
theorem cert_e2422364363734 : check e2422364363734 [[],[]] .smaller = true := by decide
def e2422364363738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2422364363738 : Closed e2422364363738 ∧ code e2422364363738 = 11218457385946 := by decide
theorem cert_e2422364363738 : check e2422364363738 [[],[]] .smaller = true := by decide
def e2422364363754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 0)) (.var 0))))))))
theorem wire_e2422364363754 : Closed e2422364363754 ∧ code e2422364363754 = 11218457385962 := by decide
theorem cert_e2422364363754 : check e2422364363754 [[],[]] .three = true := by decide
def e2422364363862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422364363862 : Closed e2422364363862 ∧ code e2422364363862 = 11218457386070 := by decide
theorem cert_e2422364363862 : check e2422364363862 [[],[]] .smaller = true := by decide
def e2422364363866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422364363866 : Closed e2422364363866 ∧ code e2422364363866 = 11218457386074 := by decide
theorem cert_e2422364363866 : check e2422364363866 [[],[]] .smaller = true := by decide
def e2422364364054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422364364054 : Closed e2422364364054 ∧ code e2422364364054 = 11218457386262 := by decide
theorem cert_e2422364364054 : check e2422364364054 [[],[]] .smaller = true := by decide
def e2422364364126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2422364364126 : Closed e2422364364126 ∧ code e2422364364126 = 11218457386334 := by decide
theorem cert_e2422364364126 : check e2422364364126 [[],[]] .smaller = true := by decide
def e2422364364130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422364364130 : Closed e2422364364130 ∧ code e2422364364130 = 11218457386338 := by decide
theorem cert_e2422364364130 : check e2422364364130 [[],[]] .smaller = true := by decide
def e2422364364142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422364364142 : Closed e2422364364142 ∧ code e2422364364142 = 11218457386350 := by decide
theorem cert_e2422364364142 : check e2422364364142 [[],[]] .smaller = true := by decide
def e2422364364150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422364364150 : Closed e2422364364150 ∧ code e2422364364150 = 11218457386358 := by decide
theorem cert_e2422364364150 : check e2422364364150 [[],[]] .smaller = true := by decide
def e2422364364154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2422364364154 : Closed e2422364364154 ∧ code e2422364364154 = 11218457386362 := by decide
theorem cert_e2422364364154 : check e2422364364154 [[],[]] .smaller = true := by decide
def e2422364364170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364364170 : Closed e2422364364170 ∧ code e2422364364170 = 11218457386378 := by decide
theorem cert_e2422364364170 : check e2422364364170 [[],[]] .smaller = true := by decide
def e2422364364194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364364194 : Closed e2422364364194 ∧ code e2422364364194 = 11218457386402 := by decide
theorem cert_e2422364364194 : check e2422364364194 [[],[]] .smaller = true := by decide
def e2422364364206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422364364206 : Closed e2422364364206 ∧ code e2422364364206 = 11218457386414 := by decide
theorem cert_e2422364364206 : check e2422364364206 [[],[]] .smaller = true := by decide
def e2422364364214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 1))))))))
theorem wire_e2422364364214 : Closed e2422364364214 ∧ code e2422364364214 = 11218457386422 := by decide
theorem cert_e2422364364214 : check e2422364364214 [[],[]] .smaller = true := by decide
def e2422364364218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422364364218 : Closed e2422364364218 ∧ code e2422364364218 = 11218457386426 := by decide
theorem cert_e2422364364218 : check e2422364364218 [[],[]] .smaller = true := by decide
def e2422364364246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422364364246 : Closed e2422364364246 ∧ code e2422364364246 = 11218457386454 := by decide
theorem cert_e2422364364246 : check e2422364364246 [[],[]] .smaller = true := by decide
def e2422364364250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422364364250 : Closed e2422364364250 ∧ code e2422364364250 = 11218457386458 := by decide
theorem cert_e2422364364250 : check e2422364364250 [[],[]] .smaller = true := by decide
def e2422364364266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2422364364266 : Closed e2422364364266 ∧ code e2422364364266 = 11218457386474 := by decide
theorem cert_e2422364364266 : check e2422364364266 [[],[]] .smaller = true := by decide
def e2422364364462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422364364462 : Closed e2422364364462 ∧ code e2422364364462 = 11218457386670 := by decide
theorem cert_e2422364364462 : check e2422364364462 [[],[]] .smaller = true := by decide
end Blc.Floor43
