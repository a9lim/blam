import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373923458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373923458 : Closed e2422373923458 ∧ code e2422373923458 = 11218466945666 := by decide
theorem cert_e2422373923458 : check e2422373923458 [[],[]] .smaller = true := by decide
def e2422373923470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373923470 : Closed e2422373923470 ∧ code e2422373923470 = 11218466945678 := by decide
theorem cert_e2422373923470 : check e2422373923470 [[],[]] .smaller = true := by decide
def e2422373923482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373923482 : Closed e2422373923482 ∧ code e2422373923482 = 11218466945690 := by decide
theorem cert_e2422373923482 : check e2422373923482 [[],[]] .smaller = true := by decide
def e2422373923526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373923526 : Closed e2422373923526 ∧ code e2422373923526 = 11218466945734 := by decide
theorem cert_e2422373923526 : check e2422373923526 [[],[]] .smaller = true := by decide
def e2422373923550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e2422373923550 : Closed e2422373923550 ∧ code e2422373923550 = 11218466945758 := by decide
theorem cert_e2422373923550 : check e2422373923550 [[],[]] .three = true := by decide
def e2422373923554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373923554 : Closed e2422373923554 ∧ code e2422373923554 = 11218466945762 := by decide
theorem cert_e2422373923554 : check e2422373923554 [[],[]] .smaller = true := by decide
def e2422373923566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2)))))))
theorem wire_e2422373923566 : Closed e2422373923566 ∧ code e2422373923566 = 11218466945774 := by decide
theorem cert_e2422373923566 : check e2422373923566 [[],[]] .smaller = true := by decide
def e2422373923574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e2422373923574 : Closed e2422373923574 ∧ code e2422373923574 = 11218466945782 := by decide
theorem cert_e2422373923574 : check e2422373923574 [[],[]] .three = true := by decide
def e2422373923610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373923610 : Closed e2422373923610 ∧ code e2422373923610 = 11218466945818 := by decide
theorem cert_e2422373923610 : check e2422373923610 [[],[]] .smaller = true := by decide
def e2422373923654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373923654 : Closed e2422373923654 ∧ code e2422373923654 = 11218466945862 := by decide
theorem cert_e2422373923654 : check e2422373923654 [[],[]] .smaller = true := by decide
def e2422373923678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e2422373923678 : Closed e2422373923678 ∧ code e2422373923678 = 11218466945886 := by decide
theorem cert_e2422373923678 : check e2422373923678 [[],[]] .three = true := by decide
def e2422373923706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e2422373923706 : Closed e2422373923706 ∧ code e2422373923706 = 11218466945914 := by decide
theorem cert_e2422373923706 : check e2422373923706 [[],[]] .three = true := by decide
def e2422373923722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373923722 : Closed e2422373923722 ∧ code e2422373923722 = 11218466945930 := by decide
theorem cert_e2422373923722 : check e2422373923722 [[],[]] .smaller = true := by decide
def e2422373923746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373923746 : Closed e2422373923746 ∧ code e2422373923746 = 11218466945954 := by decide
theorem cert_e2422373923746 : check e2422373923746 [[],[]] .smaller = true := by decide
def e2422373923758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2)))))))
theorem wire_e2422373923758 : Closed e2422373923758 ∧ code e2422373923758 = 11218466945966 := by decide
theorem cert_e2422373923758 : check e2422373923758 [[],[]] .smaller = true := by decide
def e2422373923770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0)))))))
theorem wire_e2422373923770 : Closed e2422373923770 ∧ code e2422373923770 = 11218466945978 := by decide
theorem cert_e2422373923770 : check e2422373923770 [[],[]] .smaller = true := by decide
def e2422373923798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e2422373923798 : Closed e2422373923798 ∧ code e2422373923798 = 11218466946006 := by decide
theorem cert_e2422373923798 : check e2422373923798 [[],[]] .three = true := by decide
def e2422373923802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e2422373923802 : Closed e2422373923802 ∧ code e2422373923802 = 11218466946010 := by decide
theorem cert_e2422373923802 : check e2422373923802 [[],[]] .three = true := by decide
def e2422373923926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e2422373923926 : Closed e2422373923926 ∧ code e2422373923926 = 11218466946134 := by decide
theorem cert_e2422373923926 : check e2422373923926 [[],[]] .smaller = true := by decide
def e2422373923930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e2422373923930 : Closed e2422373923930 ∧ code e2422373923930 = 11218466946138 := by decide
theorem cert_e2422373923930 : check e2422373923930 [[],[]] .smaller = true := by decide
def e2422373924118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373924118 : Closed e2422373924118 ∧ code e2422373924118 = 11218466946326 := by decide
theorem cert_e2422373924118 : check e2422373924118 [[],[]] .smaller = true := by decide
def e2422373924190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e2422373924190 : Closed e2422373924190 ∧ code e2422373924190 = 11218466946398 := by decide
theorem cert_e2422373924190 : check e2422373924190 [[],[]] .three = true := by decide
def e2422373924194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373924194 : Closed e2422373924194 ∧ code e2422373924194 = 11218466946402 := by decide
theorem cert_e2422373924194 : check e2422373924194 [[],[]] .smaller = true := by decide
def e2422373924206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2422373924206 : Closed e2422373924206 ∧ code e2422373924206 = 11218466946414 := by decide
theorem cert_e2422373924206 : check e2422373924206 [[],[]] .smaller = true := by decide
def e2422373924214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2422373924214 : Closed e2422373924214 ∧ code e2422373924214 = 11218466946422 := by decide
theorem cert_e2422373924214 : check e2422373924214 [[],[]] .smaller = true := by decide
def e2422373924218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e2422373924218 : Closed e2422373924218 ∧ code e2422373924218 = 11218466946426 := by decide
theorem cert_e2422373924218 : check e2422373924218 [[],[]] .three = true := by decide
def e2422373924234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373924234 : Closed e2422373924234 ∧ code e2422373924234 = 11218466946442 := by decide
theorem cert_e2422373924234 : check e2422373924234 [[],[]] .smaller = true := by decide
def e2422373924258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373924258 : Closed e2422373924258 ∧ code e2422373924258 = 11218466946466 := by decide
theorem cert_e2422373924258 : check e2422373924258 [[],[]] .smaller = true := by decide
def e2422373924270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2422373924270 : Closed e2422373924270 ∧ code e2422373924270 = 11218466946478 := by decide
theorem cert_e2422373924270 : check e2422373924270 [[],[]] .smaller = true := by decide
def e2422373924282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2422373924282 : Closed e2422373924282 ∧ code e2422373924282 = 11218466946490 := by decide
theorem cert_e2422373924282 : check e2422373924282 [[],[]] .smaller = true := by decide
def e2422373924310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2422373924310 : Closed e2422373924310 ∧ code e2422373924310 = 11218466946518 := by decide
theorem cert_e2422373924310 : check e2422373924310 [[],[]] .smaller = true := by decide
def e2422373924314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2422373924314 : Closed e2422373924314 ∧ code e2422373924314 = 11218466946522 := by decide
theorem cert_e2422373924314 : check e2422373924314 [[],[]] .smaller = true := by decide
def e2422373924330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e2422373924330 : Closed e2422373924330 ∧ code e2422373924330 = 11218466946538 := by decide
theorem cert_e2422373924330 : check e2422373924330 [[],[]] .three = true := by decide
def e2422373924394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e2422373924394 : Closed e2422373924394 ∧ code e2422373924394 = 11218466946602 := by decide
theorem cert_e2422373924394 : check e2422373924394 [[],[]] .three = true := by decide
def e2422373924490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373924490 : Closed e2422373924490 ∧ code e2422373924490 = 11218466946698 := by decide
theorem cert_e2422373924490 : check e2422373924490 [[],[]] .three = true := by decide
def e2422373924514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373924514 : Closed e2422373924514 ∧ code e2422373924514 = 11218466946722 := by decide
theorem cert_e2422373924514 : check e2422373924514 [[],[]] .three = true := by decide
def e2422373924526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2422373924526 : Closed e2422373924526 ∧ code e2422373924526 = 11218466946734 := by decide
theorem cert_e2422373924526 : check e2422373924526 [[],[]] .three = true := by decide
def e2422373924534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e2422373924534 : Closed e2422373924534 ∧ code e2422373924534 = 11218466946742 := by decide
theorem cert_e2422373924534 : check e2422373924534 [[],[]] .three = true := by decide
def e2422373924538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2422373924538 : Closed e2422373924538 ∧ code e2422373924538 = 11218466946746 := by decide
theorem cert_e2422373924538 : check e2422373924538 [[],[]] .three = true := by decide
def e2422373924566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e2422373924566 : Closed e2422373924566 ∧ code e2422373924566 = 11218466946774 := by decide
theorem cert_e2422373924566 : check e2422373924566 [[],[]] .three = true := by decide
def e2422373924570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e2422373924570 : Closed e2422373924570 ∧ code e2422373924570 = 11218466946778 := by decide
theorem cert_e2422373924570 : check e2422373924570 [[],[]] .three = true := by decide
def e2422373924586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2422373924586 : Closed e2422373924586 ∧ code e2422373924586 = 11218466946794 := by decide
theorem cert_e2422373924586 : check e2422373924586 [[],[]] .three = true := by decide
def e2422373925078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 1)))))))
theorem wire_e2422373925078 : Closed e2422373925078 ∧ code e2422373925078 = 11218466947286 := by decide
theorem cert_e2422373925078 : check e2422373925078 [[],[]] .smaller = true := by decide
def e2422373925174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373925174 : Closed e2422373925174 ∧ code e2422373925174 = 11218466947382 := by decide
theorem cert_e2422373925174 : check e2422373925174 [[],[]] .smaller = true := by decide
def e2422373925178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373925178 : Closed e2422373925178 ∧ code e2422373925178 = 11218466947386 := by decide
theorem cert_e2422373925178 : check e2422373925178 [[],[]] .smaller = true := by decide
def e2422373925342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 3)))))))
theorem wire_e2422373925342 : Closed e2422373925342 ∧ code e2422373925342 = 11218466947550 := by decide
theorem cert_e2422373925342 : check e2422373925342 [[],[]] .three = true := by decide
def e2422373925358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2)))))))
theorem wire_e2422373925358 : Closed e2422373925358 ∧ code e2422373925358 = 11218466947566 := by decide
theorem cert_e2422373925358 : check e2422373925358 [[],[]] .smaller = true := by decide
def e2422373925366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1)))))))
theorem wire_e2422373925366 : Closed e2422373925366 ∧ code e2422373925366 = 11218466947574 := by decide
theorem cert_e2422373925366 : check e2422373925366 [[],[]] .smaller = true := by decide
def e2422373925370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 5))))) (.var 0)))))))
theorem wire_e2422373925370 : Closed e2422373925370 ∧ code e2422373925370 = 11218466947578 := by decide
theorem cert_e2422373925370 : check e2422373925370 [[],[]] .three = true := by decide
def e2422373925726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 3)))))))
theorem wire_e2422373925726 : Closed e2422373925726 ∧ code e2422373925726 = 11218466947934 := by decide
theorem cert_e2422373925726 : check e2422373925726 [[],[]] .three = true := by decide
def e2422373925750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 1)))))))
theorem wire_e2422373925750 : Closed e2422373925750 ∧ code e2422373925750 = 11218466947958 := by decide
theorem cert_e2422373925750 : check e2422373925750 [[],[]] .smaller = true := by decide
def e2422373925814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.var 1)))))))
theorem wire_e2422373925814 : Closed e2422373925814 ∧ code e2422373925814 = 11218466948022 := by decide
theorem cert_e2422373925814 : check e2422373925814 [[],[]] .smaller = true := by decide
def e2422373925818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))) (.var 0)))))))
theorem wire_e2422373925818 : Closed e2422373925818 ∧ code e2422373925818 = 11218466948026 := by decide
theorem cert_e2422373925818 : check e2422373925818 [[],[]] .smaller = true := by decide
def e2422373925846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 1)))))))
theorem wire_e2422373925846 : Closed e2422373925846 ∧ code e2422373925846 = 11218466948054 := by decide
theorem cert_e2422373925846 : check e2422373925846 [[],[]] .smaller = true := by decide
def e2422373925850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))) (.var 0)))))))
theorem wire_e2422373925850 : Closed e2422373925850 ∧ code e2422373925850 = 11218466948058 := by decide
theorem cert_e2422373925850 : check e2422373925850 [[],[]] .smaller = true := by decide
def e2422373926110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373926110 : Closed e2422373926110 ∧ code e2422373926110 = 11218466948318 := by decide
theorem cert_e2422373926110 : check e2422373926110 [[],[]] .three = true := by decide
def e2422373926126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373926126 : Closed e2422373926126 ∧ code e2422373926126 = 11218466948334 := by decide
theorem cert_e2422373926126 : check e2422373926126 [[],[]] .smaller = true := by decide
def e2422373926134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373926134 : Closed e2422373926134 ∧ code e2422373926134 = 11218466948342 := by decide
theorem cert_e2422373926134 : check e2422373926134 [[],[]] .smaller = true := by decide
def e2422373926138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373926138 : Closed e2422373926138 ∧ code e2422373926138 = 11218466948346 := by decide
theorem cert_e2422373926138 : check e2422373926138 [[],[]] .three = true := by decide
def e2422373926462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 4))))))))
theorem wire_e2422373926462 : Closed e2422373926462 ∧ code e2422373926462 = 11218466948670 := by decide
theorem cert_e2422373926462 : check e2422373926462 [[],[]] .three = true := by decide
def e2422373926518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373926518 : Closed e2422373926518 ∧ code e2422373926518 = 11218466948726 := by decide
theorem cert_e2422373926518 : check e2422373926518 [[],[]] .smaller = true := by decide
def e2422373926686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3))))))))
theorem wire_e2422373926686 : Closed e2422373926686 ∧ code e2422373926686 = 11218466948894 := by decide
theorem cert_e2422373926686 : check e2422373926686 [[],[]] .smaller = true := by decide
def e2422373926710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373926710 : Closed e2422373926710 ∧ code e2422373926710 = 11218466948918 := by decide
theorem cert_e2422373926710 : check e2422373926710 [[],[]] .smaller = true := by decide
def e2422373926714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373926714 : Closed e2422373926714 ∧ code e2422373926714 = 11218466948922 := by decide
theorem cert_e2422373926714 : check e2422373926714 [[],[]] .smaller = true := by decide
def e2422373926798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2))))))))
theorem wire_e2422373926798 : Closed e2422373926798 ∧ code e2422373926798 = 11218466949006 := by decide
theorem cert_e2422373926798 : check e2422373926798 [[],[]] .smaller = true := by decide
def e2422373926854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 4)))) (.lam (.var 1))))))))
theorem wire_e2422373926854 : Closed e2422373926854 ∧ code e2422373926854 = 11218466949062 := by decide
theorem cert_e2422373926854 : check e2422373926854 [[],[]] .three = true := by decide
def e2422373926878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 4)))) (.var 3)))))))
theorem wire_e2422373926878 : Closed e2422373926878 ∧ code e2422373926878 = 11218466949086 := by decide
theorem cert_e2422373926878 : check e2422373926878 [[],[]] .three = true := by decide
def e2422373927766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373927766 : Closed e2422373927766 ∧ code e2422373927766 = 11218466949974 := by decide
theorem cert_e2422373927766 : check e2422373927766 [[],[]] .smaller = true := by decide
def e2422373927770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373927770 : Closed e2422373927770 ∧ code e2422373927770 = 11218466949978 := by decide
theorem cert_e2422373927770 : check e2422373927770 [[],[]] .smaller = true := by decide
def e2422373927786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373927786 : Closed e2422373927786 ∧ code e2422373927786 = 11218466949994 := by decide
theorem cert_e2422373927786 : check e2422373927786 [[],[]] .smaller = true := by decide
def e2422373927850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373927850 : Closed e2422373927850 ∧ code e2422373927850 = 11218466950058 := by decide
theorem cert_e2422373927850 : check e2422373927850 [[],[]] .smaller = true := by decide
def e2422373927958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 1)))))))
theorem wire_e2422373927958 : Closed e2422373927958 ∧ code e2422373927958 = 11218466950166 := by decide
theorem cert_e2422373927958 : check e2422373927958 [[],[]] .smaller = true := by decide
def e2422373928030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 3)))))))
theorem wire_e2422373928030 : Closed e2422373928030 ∧ code e2422373928030 = 11218466950238 := by decide
theorem cert_e2422373928030 : check e2422373928030 [[],[]] .three = true := by decide
def e2422373928054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422373928054 : Closed e2422373928054 ∧ code e2422373928054 = 11218466950262 := by decide
theorem cert_e2422373928054 : check e2422373928054 [[],[]] .smaller = true := by decide
def e2422373928150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e2422373928150 : Closed e2422373928150 ∧ code e2422373928150 = 11218466950358 := by decide
theorem cert_e2422373928150 : check e2422373928150 [[],[]] .smaller = true := by decide
def e2422373928154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e2422373928154 : Closed e2422373928154 ∧ code e2422373928154 = 11218466950362 := by decide
theorem cert_e2422373928154 : check e2422373928154 [[],[]] .smaller = true := by decide
def e2422373928170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e2422373928170 : Closed e2422373928170 ∧ code e2422373928170 = 11218466950378 := by decide
theorem cert_e2422373928170 : check e2422373928170 [[],[]] .smaller = true := by decide
def e2422373928246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373928246 : Closed e2422373928246 ∧ code e2422373928246 = 11218466950454 := by decide
theorem cert_e2422373928246 : check e2422373928246 [[],[]] .smaller = true := by decide
def e2422373928250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373928250 : Closed e2422373928250 ∧ code e2422373928250 = 11218466950458 := by decide
theorem cert_e2422373928250 : check e2422373928250 [[],[]] .smaller = true := by decide
def e2422373928322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373928322 : Closed e2422373928322 ∧ code e2422373928322 = 11218466950530 := by decide
theorem cert_e2422373928322 : check e2422373928322 [[],[]] .smaller = true := by decide
def e2422373928334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422373928334 : Closed e2422373928334 ∧ code e2422373928334 = 11218466950542 := by decide
theorem cert_e2422373928334 : check e2422373928334 [[],[]] .smaller = true := by decide
def e2422373928346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373928346 : Closed e2422373928346 ∧ code e2422373928346 = 11218466950554 := by decide
theorem cert_e2422373928346 : check e2422373928346 [[],[]] .smaller = true := by decide
def e2422373928414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e2422373928414 : Closed e2422373928414 ∧ code e2422373928414 = 11218466950622 := by decide
theorem cert_e2422373928414 : check e2422373928414 [[],[]] .three = true := by decide
def e2422373928418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))) (.lam (.var 0))))))))
theorem wire_e2422373928418 : Closed e2422373928418 ∧ code e2422373928418 = 11218466950626 := by decide
theorem cert_e2422373928418 : check e2422373928418 [[],[]] .three = true := by decide
def e2422373928430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e2422373928430 : Closed e2422373928430 ∧ code e2422373928430 = 11218466950638 := by decide
theorem cert_e2422373928430 : check e2422373928430 [[],[]] .three = true := by decide
def e2422373928458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0)))))))
theorem wire_e2422373928458 : Closed e2422373928458 ∧ code e2422373928458 = 11218466950666 := by decide
theorem cert_e2422373928458 : check e2422373928458 [[],[]] .smaller = true := by decide
def e2422373928494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373928494 : Closed e2422373928494 ∧ code e2422373928494 = 11218466950702 := by decide
theorem cert_e2422373928494 : check e2422373928494 [[],[]] .smaller = true := by decide
def e2422373928502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e2422373928502 : Closed e2422373928502 ∧ code e2422373928502 = 11218466950710 := by decide
theorem cert_e2422373928502 : check e2422373928502 [[],[]] .smaller = true := by decide
def e2422373928506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373928506 : Closed e2422373928506 ∧ code e2422373928506 = 11218466950714 := by decide
theorem cert_e2422373928506 : check e2422373928506 [[],[]] .smaller = true := by decide
def e2422373928554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373928554 : Closed e2422373928554 ∧ code e2422373928554 = 11218466950762 := by decide
theorem cert_e2422373928554 : check e2422373928554 [[],[]] .smaller = true := by decide
def e2422373928578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373928578 : Closed e2422373928578 ∧ code e2422373928578 = 11218466950786 := by decide
theorem cert_e2422373928578 : check e2422373928578 [[],[]] .smaller = true := by decide
def e2422373928590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e2422373928590 : Closed e2422373928590 ∧ code e2422373928590 = 11218466950798 := by decide
theorem cert_e2422373928590 : check e2422373928590 [[],[]] .smaller = true := by decide
def e2422373928602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373928602 : Closed e2422373928602 ∧ code e2422373928602 = 11218466950810 := by decide
theorem cert_e2422373928602 : check e2422373928602 [[],[]] .smaller = true := by decide
def e2422373928646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373928646 : Closed e2422373928646 ∧ code e2422373928646 = 11218466950854 := by decide
theorem cert_e2422373928646 : check e2422373928646 [[],[]] .smaller = true := by decide
def e2422373928670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e2422373928670 : Closed e2422373928670 ∧ code e2422373928670 = 11218466950878 := by decide
theorem cert_e2422373928670 : check e2422373928670 [[],[]] .three = true := by decide
def e2422373928674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373928674 : Closed e2422373928674 ∧ code e2422373928674 = 11218466950882 := by decide
theorem cert_e2422373928674 : check e2422373928674 [[],[]] .smaller = true := by decide
def e2422373928686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e2422373928686 : Closed e2422373928686 ∧ code e2422373928686 = 11218466950894 := by decide
theorem cert_e2422373928686 : check e2422373928686 [[],[]] .smaller = true := by decide
def e2422373928694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e2422373928694 : Closed e2422373928694 ∧ code e2422373928694 = 11218466950902 := by decide
theorem cert_e2422373928694 : check e2422373928694 [[],[]] .three = true := by decide
def e2422373928726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373928726 : Closed e2422373928726 ∧ code e2422373928726 = 11218466950934 := by decide
theorem cert_e2422373928726 : check e2422373928726 [[],[]] .smaller = true := by decide
def e2422373928798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e2422373928798 : Closed e2422373928798 ∧ code e2422373928798 = 11218466951006 := by decide
theorem cert_e2422373928798 : check e2422373928798 [[],[]] .three = true := by decide
def e2422373928802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422373928802 : Closed e2422373928802 ∧ code e2422373928802 = 11218466951010 := by decide
theorem cert_e2422373928802 : check e2422373928802 [[],[]] .smaller = true := by decide
def e2422373928814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e2422373928814 : Closed e2422373928814 ∧ code e2422373928814 = 11218466951022 := by decide
theorem cert_e2422373928814 : check e2422373928814 [[],[]] .smaller = true := by decide
def e2422373928822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1)))))))
theorem wire_e2422373928822 : Closed e2422373928822 ∧ code e2422373928822 = 11218466951030 := by decide
theorem cert_e2422373928822 : check e2422373928822 [[],[]] .smaller = true := by decide
def e2422373928826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e2422373928826 : Closed e2422373928826 ∧ code e2422373928826 = 11218466951034 := by decide
theorem cert_e2422373928826 : check e2422373928826 [[],[]] .three = true := by decide
def e2422373928842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373928842 : Closed e2422373928842 ∧ code e2422373928842 = 11218466951050 := by decide
theorem cert_e2422373928842 : check e2422373928842 [[],[]] .three = true := by decide
def e2422373928866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373928866 : Closed e2422373928866 ∧ code e2422373928866 = 11218466951074 := by decide
theorem cert_e2422373928866 : check e2422373928866 [[],[]] .three = true := by decide
def e2422373928878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e2422373928878 : Closed e2422373928878 ∧ code e2422373928878 = 11218466951086 := by decide
theorem cert_e2422373928878 : check e2422373928878 [[],[]] .three = true := by decide
def e2422373928886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e2422373928886 : Closed e2422373928886 ∧ code e2422373928886 = 11218466951094 := by decide
theorem cert_e2422373928886 : check e2422373928886 [[],[]] .three = true := by decide
def e2422373928890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e2422373928890 : Closed e2422373928890 ∧ code e2422373928890 = 11218466951098 := by decide
theorem cert_e2422373928890 : check e2422373928890 [[],[]] .three = true := by decide
def e2422373929086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 5)))))))))
theorem wire_e2422373929086 : Closed e2422373929086 ∧ code e2422373929086 = 11218466951294 := by decide
theorem cert_e2422373929086 : check e2422373929086 [[],[]] .three = true := by decide
def e2422373929198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373929198 : Closed e2422373929198 ∧ code e2422373929198 = 11218466951406 := by decide
theorem cert_e2422373929198 : check e2422373929198 [[],[]] .smaller = true := by decide
def e2422373929206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373929206 : Closed e2422373929206 ∧ code e2422373929206 = 11218466951414 := by decide
theorem cert_e2422373929206 : check e2422373929206 [[],[]] .smaller = true := by decide
def e2422373929686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422373929686 : Closed e2422373929686 ∧ code e2422373929686 = 11218466951894 := by decide
theorem cert_e2422373929686 : check e2422373929686 [[],[]] .smaller = true := by decide
def e2422373929690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422373929690 : Closed e2422373929690 ∧ code e2422373929690 = 11218466951898 := by decide
theorem cert_e2422373929690 : check e2422373929690 [[],[]] .smaller = true := by decide
def e2422373929706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422373929706 : Closed e2422373929706 ∧ code e2422373929706 = 11218466951914 := by decide
theorem cert_e2422373929706 : check e2422373929706 [[],[]] .smaller = true := by decide
def e2422373929782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373929782 : Closed e2422373929782 ∧ code e2422373929782 = 11218466951990 := by decide
theorem cert_e2422373929782 : check e2422373929782 [[],[]] .smaller = true := by decide
def e2422373929786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373929786 : Closed e2422373929786 ∧ code e2422373929786 = 11218466951994 := by decide
theorem cert_e2422373929786 : check e2422373929786 [[],[]] .smaller = true := by decide
def e2422373929858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373929858 : Closed e2422373929858 ∧ code e2422373929858 = 11218466952066 := by decide
theorem cert_e2422373929858 : check e2422373929858 [[],[]] .smaller = true := by decide
def e2422373929870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2422373929870 : Closed e2422373929870 ∧ code e2422373929870 = 11218466952078 := by decide
theorem cert_e2422373929870 : check e2422373929870 [[],[]] .smaller = true := by decide
def e2422373929882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373929882 : Closed e2422373929882 ∧ code e2422373929882 = 11218466952090 := by decide
theorem cert_e2422373929882 : check e2422373929882 [[],[]] .smaller = true := by decide
def e2422373929950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373929950 : Closed e2422373929950 ∧ code e2422373929950 = 11218466952158 := by decide
theorem cert_e2422373929950 : check e2422373929950 [[],[]] .three = true := by decide
def e2422373929954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422373929954 : Closed e2422373929954 ∧ code e2422373929954 = 11218466952162 := by decide
theorem cert_e2422373929954 : check e2422373929954 [[],[]] .three = true := by decide
def e2422373929966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373929966 : Closed e2422373929966 ∧ code e2422373929966 = 11218466952174 := by decide
theorem cert_e2422373929966 : check e2422373929966 [[],[]] .three = true := by decide
def e2422373931034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373931034 : Closed e2422373931034 ∧ code e2422373931034 = 11218466953242 := by decide
theorem cert_e2422373931034 : check e2422373931034 [[],[]] .smaller = true := by decide
def e2422373931070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373931070 : Closed e2422373931070 ∧ code e2422373931070 = 11218466953278 := by decide
theorem cert_e2422373931070 : check e2422373931070 [[],[]] .smaller = true := by decide
def e2422373931118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373931118 : Closed e2422373931118 ∧ code e2422373931118 = 11218466953326 := by decide
theorem cert_e2422373931118 : check e2422373931118 [[],[]] .smaller = true := by decide
def e2422373931126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373931126 : Closed e2422373931126 ∧ code e2422373931126 = 11218466953334 := by decide
theorem cert_e2422373931126 : check e2422373931126 [[],[]] .smaller = true := by decide
def e2422373931130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373931130 : Closed e2422373931130 ∧ code e2422373931130 = 11218466953338 := by decide
theorem cert_e2422373931130 : check e2422373931130 [[],[]] .smaller = true := by decide
def e2422373931370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373931370 : Closed e2422373931370 ∧ code e2422373931370 = 11218466953578 := by decide
theorem cert_e2422373931370 : check e2422373931370 [[],[]] .smaller = true := by decide
def e2422373931394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373931394 : Closed e2422373931394 ∧ code e2422373931394 = 11218466953602 := by decide
theorem cert_e2422373931394 : check e2422373931394 [[],[]] .smaller = true := by decide
def e2422373931406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373931406 : Closed e2422373931406 ∧ code e2422373931406 = 11218466953614 := by decide
theorem cert_e2422373931406 : check e2422373931406 [[],[]] .smaller = true := by decide
def e2422373931418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373931418 : Closed e2422373931418 ∧ code e2422373931418 = 11218466953626 := by decide
theorem cert_e2422373931418 : check e2422373931418 [[],[]] .smaller = true := by decide
def e2422373931462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373931462 : Closed e2422373931462 ∧ code e2422373931462 = 11218466953670 := by decide
theorem cert_e2422373931462 : check e2422373931462 [[],[]] .smaller = true := by decide
def e2422373931486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373931486 : Closed e2422373931486 ∧ code e2422373931486 = 11218466953694 := by decide
theorem cert_e2422373931486 : check e2422373931486 [[],[]] .three = true := by decide
def e2422373931490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373931490 : Closed e2422373931490 ∧ code e2422373931490 = 11218466953698 := by decide
theorem cert_e2422373931490 : check e2422373931490 [[],[]] .smaller = true := by decide
def e2422373931502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373931502 : Closed e2422373931502 ∧ code e2422373931502 = 11218466953710 := by decide
theorem cert_e2422373931502 : check e2422373931502 [[],[]] .smaller = true := by decide
def e2422373931510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373931510 : Closed e2422373931510 ∧ code e2422373931510 = 11218466953718 := by decide
theorem cert_e2422373931510 : check e2422373931510 [[],[]] .three = true := by decide
def e2422373932062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373932062 : Closed e2422373932062 ∧ code e2422373932062 = 11218466954270 := by decide
theorem cert_e2422373932062 : check e2422373932062 [[],[]] .smaller = true := by decide
def e2422373932254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373932254 : Closed e2422373932254 ∧ code e2422373932254 = 11218466954462 := by decide
theorem cert_e2422373932254 : check e2422373932254 [[],[]] .three = true := by decide
def e2422373932258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373932258 : Closed e2422373932258 ∧ code e2422373932258 = 11218466954466 := by decide
theorem cert_e2422373932258 : check e2422373932258 [[],[]] .smaller = true := by decide
def e2422373932270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373932270 : Closed e2422373932270 ∧ code e2422373932270 = 11218466954478 := by decide
theorem cert_e2422373932270 : check e2422373932270 [[],[]] .smaller = true := by decide
def e2422373932278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373932278 : Closed e2422373932278 ∧ code e2422373932278 = 11218466954486 := by decide
theorem cert_e2422373932278 : check e2422373932278 [[],[]] .smaller = true := by decide
def e2422373932282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373932282 : Closed e2422373932282 ∧ code e2422373932282 = 11218466954490 := by decide
theorem cert_e2422373932282 : check e2422373932282 [[],[]] .three = true := by decide
def e2422373932558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373932558 : Closed e2422373932558 ∧ code e2422373932558 = 11218466954766 := by decide
theorem cert_e2422373932558 : check e2422373932558 [[],[]] .three = true := by decide
def e2422373932570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373932570 : Closed e2422373932570 ∧ code e2422373932570 = 11218466954778 := by decide
theorem cert_e2422373932570 : check e2422373932570 [[],[]] .three = true := by decide
def e2422373932606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.lam (.var 4))))))))
theorem wire_e2422373932606 : Closed e2422373932606 ∧ code e2422373932606 = 11218466954814 := by decide
theorem cert_e2422373932606 : check e2422373932606 [[],[]] .three = true := by decide
def e2422373932642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373932642 : Closed e2422373932642 ∧ code e2422373932642 = 11218466954850 := by decide
theorem cert_e2422373932642 : check e2422373932642 [[],[]] .three = true := by decide
def e2422373932654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373932654 : Closed e2422373932654 ∧ code e2422373932654 = 11218466954862 := by decide
theorem cert_e2422373932654 : check e2422373932654 [[],[]] .three = true := by decide
def e2422373932662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373932662 : Closed e2422373932662 ∧ code e2422373932662 = 11218466954870 := by decide
theorem cert_e2422373932662 : check e2422373932662 [[],[]] .three = true := by decide
def e2422373932666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373932666 : Closed e2422373932666 ∧ code e2422373932666 = 11218466954874 := by decide
theorem cert_e2422373932666 : check e2422373932666 [[],[]] .three = true := by decide
def e2422373933162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))))))
theorem wire_e2422373933162 : Closed e2422373933162 ∧ code e2422373933162 = 11218466955370 := by decide
theorem cert_e2422373933162 : check e2422373933162 [[],[]] .smaller = true := by decide
def e2422373933210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373933210 : Closed e2422373933210 ∧ code e2422373933210 = 11218466955418 := by decide
theorem cert_e2422373933210 : check e2422373933210 [[],[]] .smaller = true := by decide
def e2422373933294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2)))))))
theorem wire_e2422373933294 : Closed e2422373933294 ∧ code e2422373933294 = 11218466955502 := by decide
theorem cert_e2422373933294 : check e2422373933294 [[],[]] .smaller = true := by decide
def e2422373933306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e2422373933306 : Closed e2422373933306 ∧ code e2422373933306 = 11218466955514 := by decide
theorem cert_e2422373933306 : check e2422373933306 [[],[]] .smaller = true := by decide
def e2422373933494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e2422373933494 : Closed e2422373933494 ∧ code e2422373933494 = 11218466955702 := by decide
theorem cert_e2422373933494 : check e2422373933494 [[],[]] .smaller = true := by decide
def e2422373933498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422373933498 : Closed e2422373933498 ∧ code e2422373933498 = 11218466955706 := by decide
theorem cert_e2422373933498 : check e2422373933498 [[],[]] .smaller = true := by decide
def e2422373933526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e2422373933526 : Closed e2422373933526 ∧ code e2422373933526 = 11218466955734 := by decide
theorem cert_e2422373933526 : check e2422373933526 [[],[]] .smaller = true := by decide
def e2422373933530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))) (.var 0)))))))
theorem wire_e2422373933530 : Closed e2422373933530 ∧ code e2422373933530 = 11218466955738 := by decide
theorem cert_e2422373933530 : check e2422373933530 [[],[]] .smaller = true := by decide
def e2422373933546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422373933546 : Closed e2422373933546 ∧ code e2422373933546 = 11218466955754 := by decide
theorem cert_e2422373933546 : check e2422373933546 [[],[]] .smaller = true := by decide
def e2422373933678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373933678 : Closed e2422373933678 ∧ code e2422373933678 = 11218466955886 := by decide
theorem cert_e2422373933678 : check e2422373933678 [[],[]] .smaller = true := by decide
end Blc.Floor43
