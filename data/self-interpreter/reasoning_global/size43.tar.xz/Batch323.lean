import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2417076779438 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2417076779438 : Closed e2417076779438 ∧ code e2417076779438 = 11213169801646 := by decide
theorem cert_e2417076779438 : checkPay e2417076779438 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2417076779450 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2417076779450 : Closed e2417076779450 ∧ code e2417076779450 = 11213169801658 := by decide
theorem cert_e2417076779450 : checkPay e2417076779450 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[]] = true := by decide
def e2417076779498 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2417076779498 : Closed e2417076779498 ∧ code e2417076779498 = 11213169801706 := by decide
theorem cert_e2417076779498 : checkPay e2417076779498 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] = true := by decide
def e2417076779630 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2417076779630 : Closed e2417076779630 ∧ code e2417076779630 = 11213169801838 := by decide
theorem cert_e2417076779630 : checkPay e2417076779630 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2417076779642 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2417076779642 : Closed e2417076779642 ∧ code e2417076779642 = 11213169801850 := by decide
theorem cert_e2417076779642 : checkPay e2417076779642 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2417076779930 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2417076779930 : Closed e2417076779930 ∧ code e2417076779930 = 11213169802138 := by decide
theorem cert_e2417076779930 : checkPay e2417076779930 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e2417076780246 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2417076780246 : Closed e2417076780246 ∧ code e2417076780246 = 11213169802454 := by decide
theorem cert_e2417076780246 : check e2417076780246 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2417076780250 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2417076780250 : Closed e2417076780250 ∧ code e2417076780250 = 11213169802458 := by decide
theorem cert_e2417076780250 : check e2417076780250 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2417076780266 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2417076780266 : Closed e2417076780266 ∧ code e2417076780266 = 11213169802474 := by decide
theorem cert_e2417076780266 : check e2417076780266 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2417076780342 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2417076780342 : Closed e2417076780342 ∧ code e2417076780342 = 11213169802550 := by decide
theorem cert_e2417076780342 : check e2417076780342 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2417076780346 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2417076780346 : Closed e2417076780346 ∧ code e2417076780346 = 11213169802554 := by decide
theorem cert_e2417076780346 : check e2417076780346 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2417076780442 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2417076780442 : Closed e2417076780442 ∧ code e2417076780442 = 11213169802650 := by decide
theorem cert_e2417076780442 : check e2417076780442 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2417076783982 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2417076783982 : Closed e2417076783982 ∧ code e2417076783982 = 11213169806190 := by decide
theorem cert_e2417076783982 : check e2417076783982 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2417076783990 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2417076783990 : Closed e2417076783990 ∧ code e2417076783990 = 11213169806198 := by decide
theorem cert_e2417076783990 : checkPay e2417076783990 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2417076784046 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2417076784046 : Closed e2417076784046 ∧ code e2417076784046 = 11213169806254 := by decide
theorem cert_e2417076784046 : check e2417076784046 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417076784058 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2417076784058 : Closed e2417076784058 ∧ code e2417076784058 = 11213169806266 := by decide
theorem cert_e2417076784058 : check e2417076784058 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417076784086 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2417076784086 : Closed e2417076784086 ∧ code e2417076784086 = 11213169806294 := by decide
theorem cert_e2417076784086 : check e2417076784086 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2417076784090 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2417076784090 : Closed e2417076784090 ∧ code e2417076784090 = 11213169806298 := by decide
theorem cert_e2417076784090 : check e2417076784090 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417076784366 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2417076784366 : Closed e2417076784366 ∧ code e2417076784366 = 11213169806574 := by decide
theorem cert_e2417076784366 : check e2417076784366 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2417076784374 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2417076784374 : Closed e2417076784374 ∧ code e2417076784374 = 11213169806582 := by decide
theorem cert_e2417076784374 : check e2417076784374 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2417076784750 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2417076784750 : Closed e2417076784750 ∧ code e2417076784750 = 11213169806958 := by decide
theorem cert_e2417076784750 : check e2417076784750 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417076784762 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2417076784762 : Closed e2417076784762 ∧ code e2417076784762 = 11213169806970 := by decide
theorem cert_e2417076784762 : check e2417076784762 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417076784950 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2417076784950 : Closed e2417076784950 ∧ code e2417076784950 = 11213169807158 := by decide
theorem cert_e2417076784950 : check e2417076784950 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417076784954 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2417076784954 : Closed e2417076784954 ∧ code e2417076784954 = 11213169807162 := by decide
theorem cert_e2417076784954 : check e2417076784954 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2417076790702 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2417076790702 : Closed e2417076790702 ∧ code e2417076790702 = 11213169812910 := by decide
theorem cert_e2417076790702 : check e2417076790702 [[],[]] .sourceHead = true := by decide
def e2417076790714 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2417076790714 : Closed e2417076790714 ∧ code e2417076790714 = 11213169812922 := by decide
theorem cert_e2417076790714 : check e2417076790714 [[],[]] .sourceHead = true := by decide
def e2417076790762 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2417076790762 : Closed e2417076790762 ∧ code e2417076790762 = 11213169812970 := by decide
theorem cert_e2417076790762 : check e2417076790762 [[],[]] .sourceHead = true := by decide
def e2417076790894 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2417076790894 : Closed e2417076790894 ∧ code e2417076790894 = 11213169813102 := by decide
theorem cert_e2417076790894 : check e2417076790894 [[],[]] .sourceHead = true := by decide
def e2417076790906 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2417076790906 : Closed e2417076790906 ∧ code e2417076790906 = 11213169813114 := by decide
theorem cert_e2417076790906 : check e2417076790906 [[],[]] .sourceHead = true := by decide
def e2417076791194 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2417076791194 : Closed e2417076791194 ∧ code e2417076791194 = 11213169813402 := by decide
theorem cert_e2417076791194 : check e2417076791194 [[],[]] .sourceHead = true := by decide
def e2417076794070 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2417076794070 : Closed e2417076794070 ∧ code e2417076794070 = 11213169816278 := by decide
theorem cert_e2417076794070 : check e2417076794070 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2417076794074 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2417076794074 : Closed e2417076794074 ∧ code e2417076794074 = 11213169816282 := by decide
theorem cert_e2417076794074 : check e2417076794074 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2417076794090 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2417076794090 : Closed e2417076794090 ∧ code e2417076794090 = 11213169816298 := by decide
theorem cert_e2417076794090 : check e2417076794090 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2417076794166 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2417076794166 : Closed e2417076794166 ∧ code e2417076794166 = 11213169816374 := by decide
theorem cert_e2417076794166 : check e2417076794166 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2417076794170 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2417076794170 : Closed e2417076794170 ∧ code e2417076794170 = 11213169816378 := by decide
theorem cert_e2417076794170 : check e2417076794170 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2417076794266 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2417076794266 : Closed e2417076794266 ∧ code e2417076794266 = 11213169816474 := by decide
theorem cert_e2417076794266 : check e2417076794266 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2417076931438 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2417076931438 : Closed e2417076931438 ∧ code e2417076931438 = 11213169953646 := by decide
theorem cert_e2417076931438 : check e2417076931438 [[],[]] .sourceHead = true := by decide
def e2417076931446 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2417076931446 : Closed e2417076931446 ∧ code e2417076931446 = 11213169953654 := by decide
theorem cert_e2417076931446 : check e2417076931446 [[],[]] .sourceHead = true := by decide
def e2417076931502 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2417076931502 : Closed e2417076931502 ∧ code e2417076931502 = 11213169953710 := by decide
theorem cert_e2417076931502 : check e2417076931502 [[],[]] .sourceHead = true := by decide
def e2417076931514 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2417076931514 : Closed e2417076931514 ∧ code e2417076931514 = 11213169953722 := by decide
theorem cert_e2417076931514 : check e2417076931514 [[],[]] .sourceHead = true := by decide
def e2417076931542 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2417076931542 : Closed e2417076931542 ∧ code e2417076931542 = 11213169953750 := by decide
theorem cert_e2417076931542 : check e2417076931542 [[],[]] .sourceHead = true := by decide
def e2417076931546 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2417076931546 : Closed e2417076931546 ∧ code e2417076931546 = 11213169953754 := by decide
theorem cert_e2417076931546 : check e2417076931546 [[],[]] .sourceHead = true := by decide
def e2417076931822 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2417076931822 : Closed e2417076931822 ∧ code e2417076931822 = 11213169954030 := by decide
theorem cert_e2417076931822 : check e2417076931822 [[],[]] .sourceHead = true := by decide
def e2417076931830 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2417076931830 : Closed e2417076931830 ∧ code e2417076931830 = 11213169954038 := by decide
theorem cert_e2417076931830 : check e2417076931830 [[],[]] .sourceHead = true := by decide
def e2417076932206 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2417076932206 : Closed e2417076932206 ∧ code e2417076932206 = 11213169954414 := by decide
theorem cert_e2417076932206 : check e2417076932206 [[],[]] .sourceHead = true := by decide
def e2417076932218 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2417076932218 : Closed e2417076932218 ∧ code e2417076932218 = 11213169954426 := by decide
theorem cert_e2417076932218 : check e2417076932218 [[],[]] .sourceHead = true := by decide
def e2417076932406 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2417076932406 : Closed e2417076932406 ∧ code e2417076932406 = 11213169954614 := by decide
theorem cert_e2417076932406 : check e2417076932406 [[],[]] .sourceHead = true := by decide
def e2417076932410 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2417076932410 : Closed e2417076932410 ∧ code e2417076932410 = 11213169954618 := by decide
theorem cert_e2417076932410 : check e2417076932410 [[],[]] .sourceHead = true := by decide
def e2417077521262 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2417077521262 : Closed e2417077521262 ∧ code e2417077521262 = 11213170543470 := by decide
def e2417077521270 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2417077521270 : Closed e2417077521270 ∧ code e2417077521270 = 11213170543478 := by decide
def e2417077521326 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2417077521326 : Closed e2417077521326 ∧ code e2417077521326 = 11213170543534 := by decide
def e2417077521338 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2417077521338 : Closed e2417077521338 ∧ code e2417077521338 = 11213170543546 := by decide
theorem cert_e2417077521338 : check e2417077521338 [[],[],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2417077521366 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2417077521366 : Closed e2417077521366 ∧ code e2417077521366 = 11213170543574 := by decide
theorem cert_e2417077521366 : check e2417077521366 [[],[],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2417077521370 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2417077521370 : Closed e2417077521370 ∧ code e2417077521370 = 11213170543578 := by decide
def e2417077521646 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2417077521646 : Closed e2417077521646 ∧ code e2417077521646 = 11213170543854 := by decide
theorem cert_e2417077521646 : check e2417077521646 [[],[],[.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2417077521654 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2417077521654 : Closed e2417077521654 ∧ code e2417077521654 = 11213170543862 := by decide
theorem cert_e2417077521654 : check e2417077521654 [[],[],[.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2417077522030 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2417077522030 : Closed e2417077522030 ∧ code e2417077522030 = 11213170544238 := by decide
theorem cert_e2417077522030 : check e2417077522030 [[],[],[.left,.left],[.left,.left],[.left],[],[],[.left],[],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2417077522042 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2417077522042 : Closed e2417077522042 ∧ code e2417077522042 = 11213170544250 := by decide
theorem cert_e2417077522042 : checkPay e2417077522042 [[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left]] 0 [[.under,.under,.right,.left]] = true := by decide
def e2417077522230 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2417077522230 : Closed e2417077522230 ∧ code e2417077522230 = 11213170544438 := by decide
theorem cert_e2417077522230 : check e2417077522230 [[],[],[.left,.left],[.left,.left],[.left],[],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2417077522234 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2417077522234 : Closed e2417077522234 ∧ code e2417077522234 = 11213170544442 := by decide
theorem cert_e2417077522234 : check e2417077522234 [[],[],[.left,.left],[.left,.left],[.left],[],[],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2417262030362 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262030362 : Closed e2417262030362 ∧ code e2417262030362 = 11213355052570 := by decide
private def t_e2417262030362 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262030362 : ¬ IsSelfInterpreter e2417262030362 :=
  wSource (t := t_e2417262030362) (replay_sound (ps := []) (t := e2417262030362) (by decide)) (by decide)
def e2417262032410 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262032410 : Closed e2417262032410 ∧ code e2417262032410 = 11213355054618 := by decide
private def t_e2417262032410 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262032410 : ¬ IsSelfInterpreter e2417262032410 :=
  wSource (t := t_e2417262032410) (replay_sound (ps := []) (t := e2417262032410) (by decide)) (by decide)
def e2417262046746 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262046746 : Closed e2417262046746 ∧ code e2417262046746 = 11213355068954 := by decide
private def t_e2417262046746 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262046746 : ¬ IsSelfInterpreter e2417262046746 :=
  wSource (t := t_e2417262046746) (replay_sound (ps := []) (t := e2417262046746) (by decide)) (by decide)
def e2417262049818 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262049818 : Closed e2417262049818 ∧ code e2417262049818 = 11213355072026 := by decide
private def t_e2417262049818 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262049818 : ¬ IsSelfInterpreter e2417262049818 :=
  wSource (t := t_e2417262049818) (replay_sound (ps := []) (t := e2417262049818) (by decide)) (by decide)
def e2417262056986 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262056986 : Closed e2417262056986 ∧ code e2417262056986 = 11213355079194 := by decide
private def t_e2417262056986 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262056986 : ¬ IsSelfInterpreter e2417262056986 :=
  wSource (t := t_e2417262056986) (replay_sound (ps := []) (t := e2417262056986) (by decide)) (by decide)
def e2417262058010 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262058010 : Closed e2417262058010 ∧ code e2417262058010 = 11213355080218 := by decide
private def t_e2417262058010 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262058010 : ¬ IsSelfInterpreter e2417262058010 :=
  wSource (t := t_e2417262058010) (replay_sound (ps := []) (t := e2417262058010) (by decide)) (by decide)
def e2417262128666 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262128666 : Closed e2417262128666 ∧ code e2417262128666 = 11213355150874 := by decide
private def t_e2417262128666 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262128666 : ¬ IsSelfInterpreter e2417262128666 :=
  wSource (t := t_e2417262128666) (replay_sound (ps := []) (t := e2417262128666) (by decide)) (by decide)
def e2417262130714 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262130714 : Closed e2417262130714 ∧ code e2417262130714 = 11213355152922 := by decide
private def t_e2417262130714 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262130714 : ¬ IsSelfInterpreter e2417262130714 :=
  wSource (t := t_e2417262130714) (replay_sound (ps := []) (t := e2417262130714) (by decide)) (by decide)
def e2417262226970 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262226970 : Closed e2417262226970 ∧ code e2417262226970 = 11213355249178 := by decide
private def t_e2417262226970 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262226970 : ¬ IsSelfInterpreter e2417262226970 :=
  wSource (t := t_e2417262226970) (replay_sound (ps := []) (t := e2417262226970) (by decide)) (by decide)
def e2417262230042 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262230042 : Closed e2417262230042 ∧ code e2417262230042 = 11213355252250 := by decide
private def t_e2417262230042 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262230042 : ¬ IsSelfInterpreter e2417262230042 :=
  wSource (t := t_e2417262230042) (replay_sound (ps := []) (t := e2417262230042) (by decide)) (by decide)
def e2417262278170 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262278170 : Closed e2417262278170 ∧ code e2417262278170 = 11213355300378 := by decide
private def t_e2417262278170 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262278170 : ¬ IsSelfInterpreter e2417262278170 :=
  wSource (t := t_e2417262278170) (replay_sound (ps := []) (t := e2417262278170) (by decide)) (by decide)
def e2417262279194 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2417262279194 : Closed e2417262279194 ∧ code e2417262279194 = 11213355301402 := by decide
private def t_e2417262279194 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2417262279194 : ¬ IsSelfInterpreter e2417262279194 :=
  wSource (t := t_e2417262279194) (replay_sound (ps := []) (t := e2417262279194) (by decide)) (by decide)
def e2417264277530 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417264277530 : Closed e2417264277530 ∧ code e2417264277530 = 11213357299738 := by decide
theorem cert_e2417264277530 : check e2417264277530 [[]] .width = true := by decide
def e2417264285722 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417264285722 : Closed e2417264285722 ∧ code e2417264285722 = 11213357307930 := by decide
theorem cert_e2417264285722 : check e2417264285722 [[]] .width = true := by decide
def e2417264343066 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417264343066 : Closed e2417264343066 ∧ code e2417264343066 = 11213357365274 := by decide
theorem cert_e2417264343066 : check e2417264343066 [[]] .width = true := by decide
def e2417264355354 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417264355354 : Closed e2417264355354 ∧ code e2417264355354 = 11213357377562 := by decide
theorem cert_e2417264355354 : check e2417264355354 [[]] .width = true := by decide
def e2417264384026 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417264384026 : Closed e2417264384026 ∧ code e2417264384026 = 11213357406234 := by decide
theorem cert_e2417264384026 : check e2417264384026 [[]] .width = true := by decide
def e2417264388122 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417264388122 : Closed e2417264388122 ∧ code e2417264388122 = 11213357410330 := by decide
theorem cert_e2417264388122 : check e2417264388122 [[]] .width = true := by decide
def e2417264670746 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417264670746 : Closed e2417264670746 ∧ code e2417264670746 = 11213357692954 := by decide
theorem cert_e2417264670746 : check e2417264670746 [[]] .width = true := by decide
def e2417264678938 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417264678938 : Closed e2417264678938 ∧ code e2417264678938 = 11213357701146 := by decide
theorem cert_e2417264678938 : check e2417264678938 [[]] .width = true := by decide
def e2417265063962 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417265063962 : Closed e2417265063962 ∧ code e2417265063962 = 11213358086170 := by decide
theorem cert_e2417265063962 : check e2417265063962 [[]] .width = true := by decide
def e2417265076250 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417265076250 : Closed e2417265076250 ∧ code e2417265076250 = 11213358098458 := by decide
theorem cert_e2417265076250 : check e2417265076250 [[]] .width = true := by decide
def e2417265268762 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417265268762 : Closed e2417265268762 ∧ code e2417265268762 = 11213358290970 := by decide
theorem cert_e2417265268762 : check e2417265268762 [[]] .width = true := by decide
def e2417265272858 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2417265272858 : Closed e2417265272858 ∧ code e2417265272858 = 11213358295066 := by decide
theorem cert_e2417265272858 : check e2417265272858 [[]] .width = true := by decide
def e2417278102894 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2417278102894 : Closed e2417278102894 ∧ code e2417278102894 = 11213371125102 := by decide
theorem cert_e2417278102894 : check e2417278102894 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417278102902 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2417278102902 : Closed e2417278102902 ∧ code e2417278102902 = 11213371125110 := by decide
theorem cert_e2417278102902 : checkPay e2417278102902 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2417278102958 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2417278102958 : Closed e2417278102958 ∧ code e2417278102958 = 11213371125166 := by decide
theorem cert_e2417278102958 : check e2417278102958 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2417278102970 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2417278102970 : Closed e2417278102970 ∧ code e2417278102970 = 11213371125178 := by decide
theorem cert_e2417278102970 : check e2417278102970 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2417278102998 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2417278102998 : Closed e2417278102998 ∧ code e2417278102998 = 11213371125206 := by decide
theorem cert_e2417278102998 : check e2417278102998 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417278103002 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2417278103002 : Closed e2417278103002 ∧ code e2417278103002 = 11213371125210 := by decide
theorem cert_e2417278103002 : check e2417278103002 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2417278103214 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2417278103214 : Closed e2417278103214 ∧ code e2417278103214 = 11213371125422 := by decide
theorem cert_e2417278103214 : check e2417278103214 [[],[]] .sourceHead = true := by decide
def e2417278103226 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2417278103226 : Closed e2417278103226 ∧ code e2417278103226 = 11213371125434 := by decide
theorem cert_e2417278103226 : check e2417278103226 [[],[]] .sourceHead = true := by decide
def e2417278103274 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2417278103274 : Closed e2417278103274 ∧ code e2417278103274 = 11213371125482 := by decide
theorem cert_e2417278103274 : check e2417278103274 [[],[]] .sourceHead = true := by decide
def e2417278103382 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2417278103382 : Closed e2417278103382 ∧ code e2417278103382 = 11213371125590 := by decide
theorem cert_e2417278103382 : check e2417278103382 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2417278103386 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2417278103386 : Closed e2417278103386 ∧ code e2417278103386 = 11213371125594 := by decide
theorem cert_e2417278103386 : check e2417278103386 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2417278103402 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2417278103402 : Closed e2417278103402 ∧ code e2417278103402 = 11213371125610 := by decide
theorem cert_e2417278103402 : check e2417278103402 [[],[],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2417278104430 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2417278104430 : Closed e2417278104430 ∧ code e2417278104430 = 11213371126638 := by decide
theorem cert_e2417278104430 : check e2417278104430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417278104438 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2417278104438 : Closed e2417278104438 ∧ code e2417278104438 = 11213371126646 := by decide
theorem cert_e2417278104438 : checkPay e2417278104438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2417278104494 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2417278104494 : Closed e2417278104494 ∧ code e2417278104494 = 11213371126702 := by decide
theorem cert_e2417278104494 : check e2417278104494 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417278104506 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2417278104506 : Closed e2417278104506 ∧ code e2417278104506 = 11213371126714 := by decide
theorem cert_e2417278104506 : check e2417278104506 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417278104534 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2417278104534 : Closed e2417278104534 ∧ code e2417278104534 = 11213371126742 := by decide
theorem cert_e2417278104534 : checkPay e2417278104534 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2417278104538 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2417278104538 : Closed e2417278104538 ∧ code e2417278104538 = 11213371126746 := by decide
theorem cert_e2417278104538 : check e2417278104538 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417278104814 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2417278104814 : Closed e2417278104814 ∧ code e2417278104814 = 11213371127022 := by decide
theorem cert_e2417278104814 : check e2417278104814 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417278104822 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2417278104822 : Closed e2417278104822 ∧ code e2417278104822 = 11213371127030 := by decide
theorem cert_e2417278104822 : check e2417278104822 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417278105198 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2417278105198 : Closed e2417278105198 ∧ code e2417278105198 = 11213371127406 := by decide
theorem cert_e2417278105198 : check e2417278105198 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417278105210 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2417278105210 : Closed e2417278105210 ∧ code e2417278105210 = 11213371127418 := by decide
theorem cert_e2417278105210 : check e2417278105210 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417278105398 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2417278105398 : Closed e2417278105398 ∧ code e2417278105398 = 11213371127606 := by decide
theorem cert_e2417278105398 : check e2417278105398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417278105402 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2417278105402 : Closed e2417278105402 ∧ code e2417278105402 = 11213371127610 := by decide
theorem cert_e2417278105402 : check e2417278105402 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417278106030 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2417278106030 : Closed e2417278106030 ∧ code e2417278106030 = 11213371128238 := by decide
theorem cert_e2417278106030 : checkPay e2417278106030 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2417278106042 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2417278106042 : Closed e2417278106042 ∧ code e2417278106042 = 11213371128250 := by decide
theorem cert_e2417278106042 : checkPay e2417278106042 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2417278106090 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2417278106090 : Closed e2417278106090 ∧ code e2417278106090 = 11213371128298 := by decide
theorem cert_e2417278106090 : checkPay e2417278106090 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[.left],[],[.under,.left],[.under,.left,.left,.left]] = true := by decide
def e2417278106222 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2417278106222 : Closed e2417278106222 ∧ code e2417278106222 = 11213371128430 := by decide
theorem cert_e2417278106222 : checkPay e2417278106222 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2417278106234 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2417278106234 : Closed e2417278106234 ∧ code e2417278106234 = 11213371128442 := by decide
theorem cert_e2417278106234 : checkPay e2417278106234 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2417278106522 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2417278106522 : Closed e2417278106522 ∧ code e2417278106522 = 11213371128730 := by decide
theorem cert_e2417278106522 : checkPay e2417278106522 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e2417278106838 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2417278106838 : Closed e2417278106838 ∧ code e2417278106838 = 11213371129046 := by decide
theorem cert_e2417278106838 : check e2417278106838 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2417278106842 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2417278106842 : Closed e2417278106842 ∧ code e2417278106842 = 11213371129050 := by decide
theorem cert_e2417278106842 : check e2417278106842 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2417278106858 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2417278106858 : Closed e2417278106858 ∧ code e2417278106858 = 11213371129066 := by decide
theorem cert_e2417278106858 : check e2417278106858 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2417278106934 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2417278106934 : Closed e2417278106934 ∧ code e2417278106934 = 11213371129142 := by decide
theorem cert_e2417278106934 : check e2417278106934 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2417278106938 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2417278106938 : Closed e2417278106938 ∧ code e2417278106938 = 11213371129146 := by decide
theorem cert_e2417278106938 : check e2417278106938 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2417278107034 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2417278107034 : Closed e2417278107034 ∧ code e2417278107034 = 11213371129242 := by decide
theorem cert_e2417278107034 : check e2417278107034 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2417278110574 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2417278110574 : Closed e2417278110574 ∧ code e2417278110574 = 11213371132782 := by decide
theorem cert_e2417278110574 : check e2417278110574 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2417278110582 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2417278110582 : Closed e2417278110582 ∧ code e2417278110582 = 11213371132790 := by decide
theorem cert_e2417278110582 : check e2417278110582 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2417278110638 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2417278110638 : Closed e2417278110638 ∧ code e2417278110638 = 11213371132846 := by decide
theorem cert_e2417278110638 : check e2417278110638 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417278110650 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2417278110650 : Closed e2417278110650 ∧ code e2417278110650 = 11213371132858 := by decide
theorem cert_e2417278110650 : check e2417278110650 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417278110678 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2417278110678 : Closed e2417278110678 ∧ code e2417278110678 = 11213371132886 := by decide
theorem cert_e2417278110678 : check e2417278110678 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417278110682 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2417278110682 : Closed e2417278110682 ∧ code e2417278110682 = 11213371132890 := by decide
theorem cert_e2417278110682 : check e2417278110682 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417278110958 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2417278110958 : Closed e2417278110958 ∧ code e2417278110958 = 11213371133166 := by decide
theorem cert_e2417278110958 : check e2417278110958 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2417278110966 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2417278110966 : Closed e2417278110966 ∧ code e2417278110966 = 11213371133174 := by decide
theorem cert_e2417278110966 : check e2417278110966 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2417278111342 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2417278111342 : Closed e2417278111342 ∧ code e2417278111342 = 11213371133550 := by decide
theorem cert_e2417278111342 : check e2417278111342 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417278111354 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2417278111354 : Closed e2417278111354 ∧ code e2417278111354 = 11213371133562 := by decide
theorem cert_e2417278111354 : check e2417278111354 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417278111542 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2417278111542 : Closed e2417278111542 ∧ code e2417278111542 = 11213371133750 := by decide
theorem cert_e2417278111542 : check e2417278111542 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417278111546 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2417278111546 : Closed e2417278111546 ∧ code e2417278111546 = 11213371133754 := by decide
theorem cert_e2417278111546 : check e2417278111546 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2417278117294 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2417278117294 : Closed e2417278117294 ∧ code e2417278117294 = 11213371139502 := by decide
theorem cert_e2417278117294 : check e2417278117294 [[],[]] .sourceHead = true := by decide
def e2417278117306 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2417278117306 : Closed e2417278117306 ∧ code e2417278117306 = 11213371139514 := by decide
theorem cert_e2417278117306 : check e2417278117306 [[],[]] .sourceHead = true := by decide
def e2417278117354 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2417278117354 : Closed e2417278117354 ∧ code e2417278117354 = 11213371139562 := by decide
theorem cert_e2417278117354 : check e2417278117354 [[],[]] .sourceHead = true := by decide
def e2417278117486 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2417278117486 : Closed e2417278117486 ∧ code e2417278117486 = 11213371139694 := by decide
theorem cert_e2417278117486 : check e2417278117486 [[],[]] .sourceHead = true := by decide
def e2417278117498 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2417278117498 : Closed e2417278117498 ∧ code e2417278117498 = 11213371139706 := by decide
theorem cert_e2417278117498 : check e2417278117498 [[],[]] .sourceHead = true := by decide
def e2417278117786 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2417278117786 : Closed e2417278117786 ∧ code e2417278117786 = 11213371139994 := by decide
theorem cert_e2417278117786 : check e2417278117786 [[],[]] .sourceHead = true := by decide
def e2417278120662 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2417278120662 : Closed e2417278120662 ∧ code e2417278120662 = 11213371142870 := by decide
theorem cert_e2417278120662 : check e2417278120662 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2417278120666 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2417278120666 : Closed e2417278120666 ∧ code e2417278120666 = 11213371142874 := by decide
theorem cert_e2417278120666 : check e2417278120666 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2417278120682 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2417278120682 : Closed e2417278120682 ∧ code e2417278120682 = 11213371142890 := by decide
theorem cert_e2417278120682 : check e2417278120682 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2417278120758 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2417278120758 : Closed e2417278120758 ∧ code e2417278120758 = 11213371142966 := by decide
theorem cert_e2417278120758 : check e2417278120758 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2417278120762 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2417278120762 : Closed e2417278120762 ∧ code e2417278120762 = 11213371142970 := by decide
theorem cert_e2417278120762 : check e2417278120762 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2417278120858 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2417278120858 : Closed e2417278120858 ∧ code e2417278120858 = 11213371143066 := by decide
theorem cert_e2417278120858 : check e2417278120858 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2417278258030 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2417278258030 : Closed e2417278258030 ∧ code e2417278258030 = 11213371280238 := by decide
theorem cert_e2417278258030 : check e2417278258030 [[],[]] .sourceHead = true := by decide
def e2417278258038 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2417278258038 : Closed e2417278258038 ∧ code e2417278258038 = 11213371280246 := by decide
theorem cert_e2417278258038 : check e2417278258038 [[],[]] .sourceHead = true := by decide
def e2417278258094 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2417278258094 : Closed e2417278258094 ∧ code e2417278258094 = 11213371280302 := by decide
theorem cert_e2417278258094 : check e2417278258094 [[],[]] .sourceHead = true := by decide
def e2417278258106 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2417278258106 : Closed e2417278258106 ∧ code e2417278258106 = 11213371280314 := by decide
theorem cert_e2417278258106 : check e2417278258106 [[],[]] .sourceHead = true := by decide
def e2417278258134 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2417278258134 : Closed e2417278258134 ∧ code e2417278258134 = 11213371280342 := by decide
theorem cert_e2417278258134 : check e2417278258134 [[],[]] .sourceHead = true := by decide
def e2417278258138 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2417278258138 : Closed e2417278258138 ∧ code e2417278258138 = 11213371280346 := by decide
theorem cert_e2417278258138 : check e2417278258138 [[],[]] .sourceHead = true := by decide
def e2417278258414 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2417278258414 : Closed e2417278258414 ∧ code e2417278258414 = 11213371280622 := by decide
theorem cert_e2417278258414 : check e2417278258414 [[],[]] .sourceHead = true := by decide
def e2417278258422 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2417278258422 : Closed e2417278258422 ∧ code e2417278258422 = 11213371280630 := by decide
theorem cert_e2417278258422 : check e2417278258422 [[],[]] .sourceHead = true := by decide
def e2417278258798 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2417278258798 : Closed e2417278258798 ∧ code e2417278258798 = 11213371281006 := by decide
theorem cert_e2417278258798 : check e2417278258798 [[],[]] .sourceHead = true := by decide
def e2417278258810 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2417278258810 : Closed e2417278258810 ∧ code e2417278258810 = 11213371281018 := by decide
theorem cert_e2417278258810 : check e2417278258810 [[],[]] .sourceHead = true := by decide
def e2417278258998 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2417278258998 : Closed e2417278258998 ∧ code e2417278258998 = 11213371281206 := by decide
theorem cert_e2417278258998 : check e2417278258998 [[],[]] .sourceHead = true := by decide
def e2417278259002 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2417278259002 : Closed e2417278259002 ∧ code e2417278259002 = 11213371281210 := by decide
theorem cert_e2417278259002 : check e2417278259002 [[],[]] .sourceHead = true := by decide
def e2417278847854 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2417278847854 : Closed e2417278847854 ∧ code e2417278847854 = 11213371870062 := by decide
def e2417278847862 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2417278847862 : Closed e2417278847862 ∧ code e2417278847862 = 11213371870070 := by decide
def e2417278847918 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2417278847918 : Closed e2417278847918 ∧ code e2417278847918 = 11213371870126 := by decide
def e2417278847930 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2417278847930 : Closed e2417278847930 ∧ code e2417278847930 = 11213371870138 := by decide
private def t_e2417278847930 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2417278847930 : ¬ IsSelfInterpreter e2417278847930 :=
  wSource (t := t_e2417278847930) (replay_sound (ps := []) (t := e2417278847930) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2417262030362
#print axioms Blc.Floor43.cert_e2417262032410
#print axioms Blc.Floor43.cert_e2417262046746
#print axioms Blc.Floor43.cert_e2417262049818
#print axioms Blc.Floor43.cert_e2417262056986
#print axioms Blc.Floor43.cert_e2417262058010
#print axioms Blc.Floor43.cert_e2417262128666
#print axioms Blc.Floor43.cert_e2417262130714
#print axioms Blc.Floor43.cert_e2417262226970
#print axioms Blc.Floor43.cert_e2417262230042
#print axioms Blc.Floor43.cert_e2417262278170
#print axioms Blc.Floor43.cert_e2417262279194
#print axioms Blc.Floor43.cert_e2417278847930
