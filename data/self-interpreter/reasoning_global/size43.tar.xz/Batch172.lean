import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262376893718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2262376893718 : Closed e2262376893718 ∧ code e2262376893718 = 11058469915926 := by decide
theorem cert_e2262376893718 : check e2262376893718 [[],[.under]] .three = true := by decide
def e2262376893794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2262376893794 : Closed e2262376893794 ∧ code e2262376893794 = 11058469916002 := by decide
theorem cert_e2262376893794 : check e2262376893794 [[],[.under]] .three = true := by decide
def e2262376893806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2262376893806 : Closed e2262376893806 ∧ code e2262376893806 = 11058469916014 := by decide
theorem cert_e2262376893806 : check e2262376893806 [[],[.under]] .three = true := by decide
def e2262376893814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2262376893814 : Closed e2262376893814 ∧ code e2262376893814 = 11058469916022 := by decide
theorem cert_e2262376893814 : check e2262376893814 [[],[.under]] .three = true := by decide
def e2262376893834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376893834 : Closed e2262376893834 ∧ code e2262376893834 = 11058469916042 := by decide
theorem cert_e2262376893834 : check e2262376893834 [[],[.under]] .three = true := by decide
def e2262376893858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376893858 : Closed e2262376893858 ∧ code e2262376893858 = 11058469916066 := by decide
theorem cert_e2262376893858 : check e2262376893858 [[],[.under]] .three = true := by decide
def e2262376893870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2262376893870 : Closed e2262376893870 ∧ code e2262376893870 = 11058469916078 := by decide
theorem cert_e2262376893870 : check e2262376893870 [[],[.under]] .three = true := by decide
def e2262376893878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2262376893878 : Closed e2262376893878 ∧ code e2262376893878 = 11058469916086 := by decide
theorem cert_e2262376893878 : check e2262376893878 [[],[.under]] .three = true := by decide
def e2262376893882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2262376893882 : Closed e2262376893882 ∧ code e2262376893882 = 11058469916090 := by decide
theorem cert_e2262376893882 : check e2262376893882 [[],[.under]] .three = true := by decide
def e2262376893910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2262376893910 : Closed e2262376893910 ∧ code e2262376893910 = 11058469916118 := by decide
theorem cert_e2262376893910 : check e2262376893910 [[],[.under]] .three = true := by decide
def e2262376893914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2262376893914 : Closed e2262376893914 ∧ code e2262376893914 = 11058469916122 := by decide
theorem cert_e2262376893914 : check e2262376893914 [[],[.under]] .three = true := by decide
def e2262376893994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2262376893994 : Closed e2262376893994 ∧ code e2262376893994 = 11058469916202 := by decide
theorem cert_e2262376893994 : check e2262376893994 [[],[.under]] .three = true := by decide
def e2262376894090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376894090 : Closed e2262376894090 ∧ code e2262376894090 = 11058469916298 := by decide
theorem cert_e2262376894090 : check e2262376894090 [[],[.under]] .three = true := by decide
def e2262376894114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376894114 : Closed e2262376894114 ∧ code e2262376894114 = 11058469916322 := by decide
theorem cert_e2262376894114 : check e2262376894114 [[],[.under]] .three = true := by decide
def e2262376894126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2262376894126 : Closed e2262376894126 ∧ code e2262376894126 = 11058469916334 := by decide
theorem cert_e2262376894126 : check e2262376894126 [[],[.under]] .three = true := by decide
def e2262376894134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2262376894134 : Closed e2262376894134 ∧ code e2262376894134 = 11058469916342 := by decide
theorem cert_e2262376894134 : check e2262376894134 [[],[.under]] .three = true := by decide
def e2262376894138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2262376894138 : Closed e2262376894138 ∧ code e2262376894138 = 11058469916346 := by decide
theorem cert_e2262376894138 : check e2262376894138 [[],[.under]] .three = true := by decide
def e2262376894166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2262376894166 : Closed e2262376894166 ∧ code e2262376894166 = 11058469916374 := by decide
theorem cert_e2262376894166 : check e2262376894166 [[],[.under]] .three = true := by decide
def e2262376894170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2262376894170 : Closed e2262376894170 ∧ code e2262376894170 = 11058469916378 := by decide
theorem cert_e2262376894170 : check e2262376894170 [[],[.under]] .three = true := by decide
def e2262376894186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2262376894186 : Closed e2262376894186 ∧ code e2262376894186 = 11058469916394 := by decide
theorem cert_e2262376894186 : check e2262376894186 [[],[.under]] .three = true := by decide
def e2262376894294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2262376894294 : Closed e2262376894294 ∧ code e2262376894294 = 11058469916502 := by decide
theorem cert_e2262376894294 : check e2262376894294 [[],[.under]] .three = true := by decide
def e2262376894298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2262376894298 : Closed e2262376894298 ∧ code e2262376894298 = 11058469916506 := by decide
theorem cert_e2262376894298 : check e2262376894298 [[],[.under]] .three = true := by decide
def e2262376894314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2262376894314 : Closed e2262376894314 ∧ code e2262376894314 = 11058469916522 := by decide
theorem cert_e2262376894314 : check e2262376894314 [[],[.under]] .three = true := by decide
def e2262376894582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2262376894582 : Closed e2262376894582 ∧ code e2262376894582 = 11058469916790 := by decide
theorem cert_e2262376894582 : check e2262376894582 [[],[.under]] .three = true := by decide
def e2262376894586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2262376894586 : Closed e2262376894586 ∧ code e2262376894586 = 11058469916794 := by decide
theorem cert_e2262376894586 : check e2262376894586 [[],[.under]] .three = true := by decide
def e2262376894678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2262376894678 : Closed e2262376894678 ∧ code e2262376894678 = 11058469916886 := by decide
theorem cert_e2262376894678 : check e2262376894678 [[],[.under]] .three = true := by decide
def e2262376894774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376894774 : Closed e2262376894774 ∧ code e2262376894774 = 11058469916982 := by decide
theorem cert_e2262376894774 : check e2262376894774 [[],[.under]] .three = true := by decide
def e2262376894778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376894778 : Closed e2262376894778 ∧ code e2262376894778 = 11058469916986 := by decide
theorem cert_e2262376894778 : check e2262376894778 [[],[.under]] .three = true := by decide
def e2262376894862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2262376894862 : Closed e2262376894862 ∧ code e2262376894862 = 11058469917070 := by decide
theorem cert_e2262376894862 : check e2262376894862 [[],[.under]] .three = true := by decide
def e2262376894918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2262376894918 : Closed e2262376894918 ∧ code e2262376894918 = 11058469917126 := by decide
theorem cert_e2262376894918 : check e2262376894918 [[],[.under]] .three = true := by decide
def e2262376895254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2262376895254 : Closed e2262376895254 ∧ code e2262376895254 = 11058469917462 := by decide
theorem cert_e2262376895254 : check e2262376895254 [[],[.under]] .three = true := by decide
def e2262376895330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2262376895330 : Closed e2262376895330 ∧ code e2262376895330 = 11058469917538 := by decide
theorem cert_e2262376895330 : check e2262376895330 [[],[.under]] .three = true := by decide
def e2262376895342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2262376895342 : Closed e2262376895342 ∧ code e2262376895342 = 11058469917550 := by decide
theorem cert_e2262376895342 : check e2262376895342 [[],[.under]] .three = true := by decide
def e2262376895350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2262376895350 : Closed e2262376895350 ∧ code e2262376895350 = 11058469917558 := by decide
theorem cert_e2262376895350 : check e2262376895350 [[],[.under]] .three = true := by decide
def e2262376895370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262376895370 : Closed e2262376895370 ∧ code e2262376895370 = 11058469917578 := by decide
theorem cert_e2262376895370 : check e2262376895370 [[],[.under]] .three = true := by decide
def e2262376895394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262376895394 : Closed e2262376895394 ∧ code e2262376895394 = 11058469917602 := by decide
theorem cert_e2262376895394 : check e2262376895394 [[],[.under]] .three = true := by decide
def e2262376895406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2262376895406 : Closed e2262376895406 ∧ code e2262376895406 = 11058469917614 := by decide
theorem cert_e2262376895406 : check e2262376895406 [[],[.under]] .three = true := by decide
def e2262376895414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2262376895414 : Closed e2262376895414 ∧ code e2262376895414 = 11058469917622 := by decide
theorem cert_e2262376895414 : check e2262376895414 [[],[.under]] .three = true := by decide
def e2262376895418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2262376895418 : Closed e2262376895418 ∧ code e2262376895418 = 11058469917626 := by decide
theorem cert_e2262376895418 : check e2262376895418 [[],[.under]] .three = true := by decide
def e2262376895446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2262376895446 : Closed e2262376895446 ∧ code e2262376895446 = 11058469917654 := by decide
theorem cert_e2262376895446 : check e2262376895446 [[],[.under]] .three = true := by decide
def e2262376895450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2262376895450 : Closed e2262376895450 ∧ code e2262376895450 = 11058469917658 := by decide
theorem cert_e2262376895450 : check e2262376895450 [[],[.under]] .three = true := by decide
def e2262376895518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2262376895518 : Closed e2262376895518 ∧ code e2262376895518 = 11058469917726 := by decide
theorem cert_e2262376895518 : check e2262376895518 [[],[.under]] .three = true := by decide
def e2262376895714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2262376895714 : Closed e2262376895714 ∧ code e2262376895714 = 11058469917922 := by decide
theorem cert_e2262376895714 : check e2262376895714 [[],[.under]] .three = true := by decide
def e2262376895726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376895726 : Closed e2262376895726 ∧ code e2262376895726 = 11058469917934 := by decide
theorem cert_e2262376895726 : check e2262376895726 [[],[.under]] .three = true := by decide
def e2262376895734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376895734 : Closed e2262376895734 ∧ code e2262376895734 = 11058469917942 := by decide
theorem cert_e2262376895734 : check e2262376895734 [[],[.under]] .three = true := by decide
def e2262376896014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2262376896014 : Closed e2262376896014 ∧ code e2262376896014 = 11058469918222 := by decide
theorem cert_e2262376896014 : check e2262376896014 [[],[.under]] .three = true := by decide
def e2262376896026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262376896026 : Closed e2262376896026 ∧ code e2262376896026 = 11058469918234 := by decide
theorem cert_e2262376896026 : check e2262376896026 [[],[.under]] .three = true := by decide
def e2262376896098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262376896098 : Closed e2262376896098 ∧ code e2262376896098 = 11058469918306 := by decide
theorem cert_e2262376896098 : check e2262376896098 [[],[.under]] .three = true := by decide
def e2262376896110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376896110 : Closed e2262376896110 ∧ code e2262376896110 = 11058469918318 := by decide
theorem cert_e2262376896110 : check e2262376896110 [[],[.under]] .three = true := by decide
def e2262376896118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2262376896118 : Closed e2262376896118 ∧ code e2262376896118 = 11058469918326 := by decide
theorem cert_e2262376896118 : check e2262376896118 [[],[.under]] .three = true := by decide
def e2262376896122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376896122 : Closed e2262376896122 ∧ code e2262376896122 = 11058469918330 := by decide
theorem cert_e2262376896122 : check e2262376896122 [[],[.under]] .three = true := by decide
def e2262376896310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376896310 : Closed e2262376896310 ∧ code e2262376896310 = 11058469918518 := by decide
theorem cert_e2262376896310 : check e2262376896310 [[],[.under]] .three = true := by decide
def e2262376896314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376896314 : Closed e2262376896314 ∧ code e2262376896314 = 11058469918522 := by decide
theorem cert_e2262376896314 : check e2262376896314 [[],[.under]] .three = true := by decide
def e2262376896570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2262376896570 : Closed e2262376896570 ∧ code e2262376896570 = 11058469918778 := by decide
theorem cert_e2262376896570 : check e2262376896570 [[],[.under]] .three = true := by decide
def e2262376896618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2262376896618 : Closed e2262376896618 ∧ code e2262376896618 = 11058469918826 := by decide
theorem cert_e2262376896618 : check e2262376896618 [[],[.under]] .three = true := by decide
def e2262376896666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2262376896666 : Closed e2262376896666 ∧ code e2262376896666 = 11058469918874 := by decide
theorem cert_e2262376896666 : check e2262376896666 [[],[.under]] .three = true := by decide
def e2262376896710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2262376896710 : Closed e2262376896710 ∧ code e2262376896710 = 11058469918918 := by decide
theorem cert_e2262376896710 : check e2262376896710 [[],[.under]] .three = true := by decide
def e2262376896906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262376896906 : Closed e2262376896906 ∧ code e2262376896906 = 11058469919114 := by decide
theorem cert_e2262376896906 : check e2262376896906 [[],[.under]] .three = true := by decide
def e2262376896930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262376896930 : Closed e2262376896930 ∧ code e2262376896930 = 11058469919138 := by decide
theorem cert_e2262376896930 : check e2262376896930 [[],[.under]] .three = true := by decide
def e2262376896942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2262376896942 : Closed e2262376896942 ∧ code e2262376896942 = 11058469919150 := by decide
theorem cert_e2262376896942 : check e2262376896942 [[],[.under]] .three = true := by decide
def e2262376896950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2262376896950 : Closed e2262376896950 ∧ code e2262376896950 = 11058469919158 := by decide
theorem cert_e2262376896950 : check e2262376896950 [[],[.under]] .three = true := by decide
def e2262376896954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2262376896954 : Closed e2262376896954 ∧ code e2262376896954 = 11058469919162 := by decide
theorem cert_e2262376896954 : check e2262376896954 [[],[.under]] .three = true := by decide
def e2262376896982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2262376896982 : Closed e2262376896982 ∧ code e2262376896982 = 11058469919190 := by decide
theorem cert_e2262376896982 : check e2262376896982 [[],[.under]] .three = true := by decide
def e2262376896986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2262376896986 : Closed e2262376896986 ∧ code e2262376896986 = 11058469919194 := by decide
theorem cert_e2262376896986 : check e2262376896986 [[],[.under]] .three = true := by decide
def e2262376897002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2262376897002 : Closed e2262376897002 ∧ code e2262376897002 = 11058469919210 := by decide
theorem cert_e2262376897002 : check e2262376897002 [[],[.under]] .three = true := by decide
def e2262376897038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2262376897038 : Closed e2262376897038 ∧ code e2262376897038 = 11058469919246 := by decide
theorem cert_e2262376897038 : check e2262376897038 [[],[.under]] .three = true := by decide
def e2262376897050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262376897050 : Closed e2262376897050 ∧ code e2262376897050 = 11058469919258 := by decide
theorem cert_e2262376897050 : check e2262376897050 [[],[.under]] .three = true := by decide
def e2262376897122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262376897122 : Closed e2262376897122 ∧ code e2262376897122 = 11058469919330 := by decide
theorem cert_e2262376897122 : check e2262376897122 [[],[.under]] .three = true := by decide
def e2262376897134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376897134 : Closed e2262376897134 ∧ code e2262376897134 = 11058469919342 := by decide
theorem cert_e2262376897134 : check e2262376897134 [[],[.under]] .three = true := by decide
def e2262376897142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2262376897142 : Closed e2262376897142 ∧ code e2262376897142 = 11058469919350 := by decide
theorem cert_e2262376897142 : check e2262376897142 [[],[.under]] .three = true := by decide
def e2262376897146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376897146 : Closed e2262376897146 ∧ code e2262376897146 = 11058469919354 := by decide
theorem cert_e2262376897146 : check e2262376897146 [[],[.under]] .three = true := by decide
def e2262376897334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376897334 : Closed e2262376897334 ∧ code e2262376897334 = 11058469919542 := by decide
theorem cert_e2262376897334 : check e2262376897334 [[],[.under]] .three = true := by decide
def e2262376897338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376897338 : Closed e2262376897338 ∧ code e2262376897338 = 11058469919546 := by decide
theorem cert_e2262376897338 : check e2262376897338 [[],[.under]] .three = true := by decide
def e2262376897434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2262376897434 : Closed e2262376897434 ∧ code e2262376897434 = 11058469919642 := by decide
theorem cert_e2262376897434 : check e2262376897434 [[],[.under]] .three = true := by decide
def e2262376897750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2262376897750 : Closed e2262376897750 ∧ code e2262376897750 = 11058469919958 := by decide
private def t_e2262376897750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem cert_e2262376897750 : ¬ IsSelfInterpreter e2262376897750 :=
  wSource (t := t_e2262376897750) (replay_sound (ps := []) (t := e2262376897750) (by decide)) (by decide)
def e2262376897754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2262376897754 : Closed e2262376897754 ∧ code e2262376897754 = 11058469919962 := by decide
private def t_e2262376897754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem cert_e2262376897754 : ¬ IsSelfInterpreter e2262376897754 :=
  wSource (t := t_e2262376897754) (replay_sound (ps := []) (t := e2262376897754) (by decide)) (by decide)
def e2262376897770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2262376897770 : Closed e2262376897770 ∧ code e2262376897770 = 11058469919978 := by decide
private def t_e2262376897770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem cert_e2262376897770 : ¬ IsSelfInterpreter e2262376897770 :=
  wSource (t := t_e2262376897770) (replay_sound (ps := []) (t := e2262376897770) (by decide)) (by decide)
def e2262376897846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376897846 : Closed e2262376897846 ∧ code e2262376897846 = 11058469920054 := by decide
private def t_e2262376897846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem cert_e2262376897846 : ¬ IsSelfInterpreter e2262376897846 :=
  wSource (t := t_e2262376897846) (replay_sound (ps := []) (t := e2262376897846) (by decide)) (by decide)
def e2262376897850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376897850 : Closed e2262376897850 ∧ code e2262376897850 = 11058469920058 := by decide
private def t_e2262376897850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem cert_e2262376897850 : ¬ IsSelfInterpreter e2262376897850 :=
  wSource (t := t_e2262376897850) (replay_sound (ps := []) (t := e2262376897850) (by decide)) (by decide)
def e2262376897946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2262376897946 : Closed e2262376897946 ∧ code e2262376897946 = 11058469920154 := by decide
private def t_e2262376897946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem cert_e2262376897946 : ¬ IsSelfInterpreter e2262376897946 :=
  wSource (t := t_e2262376897946) (replay_sound (ps := []) (t := e2262376897946) (by decide)) (by decide)
def e2262376914158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376914158 : Closed e2262376914158 ∧ code e2262376914158 = 11058469936366 := by decide
theorem cert_e2262376914158 : check e2262376914158 [[],[.under]] .three = true := by decide
def e2262376914166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376914166 : Closed e2262376914166 ∧ code e2262376914166 = 11058469936374 := by decide
theorem cert_e2262376914166 : check e2262376914166 [[],[.under]] .three = true := by decide
def e2262376914542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262376914542 : Closed e2262376914542 ∧ code e2262376914542 = 11058469936750 := by decide
theorem cert_e2262376914542 : check e2262376914542 [[],[.under]] .three = true := by decide
def e2262376914554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262376914554 : Closed e2262376914554 ∧ code e2262376914554 = 11058469936762 := by decide
theorem cert_e2262376914554 : check e2262376914554 [[],[.under]] .three = true := by decide
def e2262376914742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262376914742 : Closed e2262376914742 ∧ code e2262376914742 = 11058469936950 := by decide
theorem cert_e2262376914742 : check e2262376914742 [[],[.under]] .three = true := by decide
def e2262376914746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262376914746 : Closed e2262376914746 ∧ code e2262376914746 = 11058469936954 := by decide
theorem cert_e2262376914746 : check e2262376914746 [[],[.under]] .three = true := by decide
def e2262376918458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e2262376918458 : Closed e2262376918458 ∧ code e2262376918458 = 11058469940666 := by decide
theorem cert_e2262376918458 : check e2262376918458 [[],[.under]] .smaller = true := by decide
def e2262376918490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e2262376918490 : Closed e2262376918490 ∧ code e2262376918490 = 11058469940698 := by decide
theorem cert_e2262376918490 : check e2262376918490 [[],[.under]] .smaller = true := by decide
def e2262376918714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2262376918714 : Closed e2262376918714 ∧ code e2262376918714 = 11058469940922 := by decide
theorem cert_e2262376918714 : check e2262376918714 [[],[.under]] .smaller = true := by decide
def e2262376918762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2262376918762 : Closed e2262376918762 ∧ code e2262376918762 = 11058469940970 := by decide
theorem cert_e2262376918762 : check e2262376918762 [[],[.under]] .smaller = true := by decide
def e2262376918874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e2262376918874 : Closed e2262376918874 ∧ code e2262376918874 = 11058469941082 := by decide
theorem cert_e2262376918874 : check e2262376918874 [[],[.under]] .smaller = true := by decide
def e2262376918890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e2262376918890 : Closed e2262376918890 ∧ code e2262376918890 = 11058469941098 := by decide
theorem cert_e2262376918890 : check e2262376918890 [[],[.under]] .smaller = true := by decide
def e2262376919994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e2262376919994 : Closed e2262376919994 ∧ code e2262376919994 = 11058469942202 := by decide
theorem cert_e2262376919994 : check e2262376919994 [[],[.under]] .smaller = true := by decide
def e2262376920026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e2262376920026 : Closed e2262376920026 ∧ code e2262376920026 = 11058469942234 := by decide
theorem cert_e2262376920026 : check e2262376920026 [[],[.under]] .smaller = true := by decide
def e2262376920302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376920302 : Closed e2262376920302 ∧ code e2262376920302 = 11058469942510 := by decide
theorem cert_e2262376920302 : check e2262376920302 [[],[.under]] .three = true := by decide
def e2262376920310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376920310 : Closed e2262376920310 ∧ code e2262376920310 = 11058469942518 := by decide
theorem cert_e2262376920310 : check e2262376920310 [[],[.under]] .three = true := by decide
def e2262376921530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2262376921530 : Closed e2262376921530 ∧ code e2262376921530 = 11058469943738 := by decide
theorem cert_e2262376921530 : check e2262376921530 [[],[.under]] .smaller = true := by decide
def e2262376921578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2262376921578 : Closed e2262376921578 ∧ code e2262376921578 = 11058469943786 := by decide
theorem cert_e2262376921578 : check e2262376921578 [[],[.under]] .smaller = true := by decide
def e2262376922330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2262376922330 : Closed e2262376922330 ∧ code e2262376922330 = 11058469944538 := by decide
theorem cert_e2262376922330 : check e2262376922330 [[],[.under]] .smaller = true := by decide
def e2262376922346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2262376922346 : Closed e2262376922346 ∧ code e2262376922346 = 11058469944554 := by decide
theorem cert_e2262376922346 : check e2262376922346 [[],[.under]] .smaller = true := by decide
def e2262376922606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 2))))))
theorem wire_e2262376922606 : Closed e2262376922606 ∧ code e2262376922606 = 11058469944814 := by decide
theorem cert_e2262376922606 : check e2262376922606 [[],[.under]] .three = true := by decide
def e2262376922862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 2))))))
theorem wire_e2262376922862 : Closed e2262376922862 ∧ code e2262376922862 = 11058469945070 := by decide
theorem cert_e2262376922862 : check e2262376922862 [[],[.under]] .three = true := by decide
def e2262376922870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 1))))))
theorem wire_e2262376922870 : Closed e2262376922870 ∧ code e2262376922870 = 11058469945078 := by decide
theorem cert_e2262376922870 : check e2262376922870 [[],[.under]] .three = true := by decide
def e2262376926062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262376926062 : Closed e2262376926062 ∧ code e2262376926062 = 11058469948270 := by decide
theorem cert_e2262376926062 : check e2262376926062 [[],[.under]] .three = true := by decide
def e2262376926070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262376926070 : Closed e2262376926070 ∧ code e2262376926070 = 11058469948278 := by decide
theorem cert_e2262376926070 : check e2262376926070 [[],[.under]] .three = true := by decide
def e2262376926126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262376926126 : Closed e2262376926126 ∧ code e2262376926126 = 11058469948334 := by decide
theorem cert_e2262376926126 : check e2262376926126 [[],[.under]] .three = true := by decide
def e2262376926138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262376926138 : Closed e2262376926138 ∧ code e2262376926138 = 11058469948346 := by decide
theorem cert_e2262376926138 : check e2262376926138 [[],[.under]] .three = true := by decide
def e2262376926166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262376926166 : Closed e2262376926166 ∧ code e2262376926166 = 11058469948374 := by decide
theorem cert_e2262376926166 : check e2262376926166 [[],[.under]] .three = true := by decide
def e2262376926170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262376926170 : Closed e2262376926170 ∧ code e2262376926170 = 11058469948378 := by decide
theorem cert_e2262376926170 : check e2262376926170 [[],[.under]] .three = true := by decide
def e2262376926446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262376926446 : Closed e2262376926446 ∧ code e2262376926446 = 11058469948654 := by decide
theorem cert_e2262376926446 : check e2262376926446 [[],[.under]] .three = true := by decide
def e2262376926454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262376926454 : Closed e2262376926454 ∧ code e2262376926454 = 11058469948662 := by decide
theorem cert_e2262376926454 : check e2262376926454 [[],[.under]] .three = true := by decide
def e2262376926830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262376926830 : Closed e2262376926830 ∧ code e2262376926830 = 11058469949038 := by decide
theorem cert_e2262376926830 : check e2262376926830 [[],[.under]] .three = true := by decide
def e2262376926842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262376926842 : Closed e2262376926842 ∧ code e2262376926842 = 11058469949050 := by decide
theorem cert_e2262376926842 : check e2262376926842 [[],[.under]] .three = true := by decide
def e2262376927030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262376927030 : Closed e2262376927030 ∧ code e2262376927030 = 11058469949238 := by decide
theorem cert_e2262376927030 : check e2262376927030 [[],[.under]] .three = true := by decide
def e2262376927034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262376927034 : Closed e2262376927034 ∧ code e2262376927034 = 11058469949242 := by decide
theorem cert_e2262376927034 : check e2262376927034 [[],[.under]] .three = true := by decide
def e2262376933150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2262376933150 : Closed e2262376933150 ∧ code e2262376933150 = 11058469955358 := by decide
theorem cert_e2262376933150 : check e2262376933150 [[],[.under]] .three = true := by decide
def e2262376933262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2262376933262 : Closed e2262376933262 ∧ code e2262376933262 = 11058469955470 := by decide
theorem cert_e2262376933262 : check e2262376933262 [[],[.under]] .three = true := by decide
def e2262376936222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2262376936222 : Closed e2262376936222 ∧ code e2262376936222 = 11058469958430 := by decide
theorem cert_e2262376936222 : check e2262376936222 [[],[.under]] .three = true := by decide
def e2262376936390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2262376936390 : Closed e2262376936390 ∧ code e2262376936390 = 11058469958598 := by decide
theorem cert_e2262376936390 : check e2262376936390 [[],[.under]] .three = true := by decide
def e2262376937870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2262376937870 : Closed e2262376937870 ∧ code e2262376937870 = 11058469960078 := by decide
theorem cert_e2262376937870 : check e2262376937870 [[],[.under]] .three = true := by decide
def e2262376937926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2262376937926 : Closed e2262376937926 ∧ code e2262376937926 = 11058469960134 := by decide
theorem cert_e2262376937926 : check e2262376937926 [[],[.under]] .three = true := by decide
def e2262376952174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2262376952174 : Closed e2262376952174 ∧ code e2262376952174 = 11058469974382 := by decide
theorem cert_e2262376952174 : check e2262376952174 [[],[.under]] .three = true := by decide
def e2262376952182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2262376952182 : Closed e2262376952182 ∧ code e2262376952182 = 11058469974390 := by decide
theorem cert_e2262376952182 : check e2262376952182 [[],[.under]] .three = true := by decide
def e2262376953390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2262376953390 : Closed e2262376953390 ∧ code e2262376953390 = 11058469975598 := by decide
theorem cert_e2262376953390 : check e2262376953390 [[],[.under]] .three = true := by decide
def e2262376953570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2262376953570 : Closed e2262376953570 ∧ code e2262376953570 = 11058469975778 := by decide
theorem cert_e2262376953570 : check e2262376953570 [[],[.under]] .three = true := by decide
def e2262376953582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e2262376953582 : Closed e2262376953582 ∧ code e2262376953582 = 11058469975790 := by decide
theorem cert_e2262376953582 : check e2262376953582 [[],[.under]] .three = true := by decide
def e2262376953622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2262376953622 : Closed e2262376953622 ∧ code e2262376953622 = 11058469975830 := by decide
theorem cert_e2262376953622 : check e2262376953622 [[],[.under]] .three = true := by decide
def e2262376953698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2262376953698 : Closed e2262376953698 ∧ code e2262376953698 = 11058469975906 := by decide
theorem cert_e2262376953698 : check e2262376953698 [[],[.under]] .three = true := by decide
def e2262376953710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e2262376953710 : Closed e2262376953710 ∧ code e2262376953710 = 11058469975918 := by decide
theorem cert_e2262376953710 : check e2262376953710 [[],[.under]] .three = true := by decide
def e2262376953718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e2262376953718 : Closed e2262376953718 ∧ code e2262376953718 = 11058469975926 := by decide
theorem cert_e2262376953718 : check e2262376953718 [[],[.under]] .three = true := by decide
def e2262376954030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2262376954030 : Closed e2262376954030 ∧ code e2262376954030 = 11058469976238 := by decide
theorem cert_e2262376954030 : check e2262376954030 [[],[.under]] .three = true := by decide
def e2262376954042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2262376954042 : Closed e2262376954042 ∧ code e2262376954042 = 11058469976250 := by decide
theorem cert_e2262376954042 : check e2262376954042 [[],[.under]] .three = true := by decide
def e2262376954414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2262376954414 : Closed e2262376954414 ∧ code e2262376954414 = 11058469976622 := by decide
theorem cert_e2262376954414 : check e2262376954414 [[],[.under]] .three = true := by decide
def e2262376954594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2262376954594 : Closed e2262376954594 ∧ code e2262376954594 = 11058469976802 := by decide
theorem cert_e2262376954594 : check e2262376954594 [[],[.under]] .three = true := by decide
def e2262376954606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2262376954606 : Closed e2262376954606 ∧ code e2262376954606 = 11058469976814 := by decide
theorem cert_e2262376954606 : check e2262376954606 [[],[.under]] .three = true := by decide
def e2262376954734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2262376954734 : Closed e2262376954734 ∧ code e2262376954734 = 11058469976942 := by decide
theorem cert_e2262376954734 : check e2262376954734 [[],[.under]] .three = true := by decide
def e2262376954742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2262376954742 : Closed e2262376954742 ∧ code e2262376954742 = 11058469976950 := by decide
theorem cert_e2262376954742 : check e2262376954742 [[],[.under]] .three = true := by decide
def e2262376954762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262376954762 : Closed e2262376954762 ∧ code e2262376954762 = 11058469976970 := by decide
theorem cert_e2262376954762 : check e2262376954762 [[],[.under]] .three = true := by decide
def e2262376954786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262376954786 : Closed e2262376954786 ∧ code e2262376954786 = 11058469976994 := by decide
theorem cert_e2262376954786 : check e2262376954786 [[],[.under]] .three = true := by decide
def e2262376954798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2262376954798 : Closed e2262376954798 ∧ code e2262376954798 = 11058469977006 := by decide
theorem cert_e2262376954798 : check e2262376954798 [[],[.under]] .three = true := by decide
def e2262376954806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2262376954806 : Closed e2262376954806 ∧ code e2262376954806 = 11058469977014 := by decide
theorem cert_e2262376954806 : check e2262376954806 [[],[.under]] .three = true := by decide
def e2262376954810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2262376954810 : Closed e2262376954810 ∧ code e2262376954810 = 11058469977018 := by decide
theorem cert_e2262376954810 : check e2262376954810 [[],[.under]] .three = true := by decide
def e2262376954966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2262376954966 : Closed e2262376954966 ∧ code e2262376954966 = 11058469977174 := by decide
theorem cert_e2262376954966 : check e2262376954966 [[],[.under]] .three = true := by decide
def e2262376954970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2262376954970 : Closed e2262376954970 ∧ code e2262376954970 = 11058469977178 := by decide
theorem cert_e2262376954970 : check e2262376954970 [[],[.under]] .three = true := by decide
def e2262376955158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2262376955158 : Closed e2262376955158 ∧ code e2262376955158 = 11058469977366 := by decide
theorem cert_e2262376955158 : check e2262376955158 [[],[.under]] .three = true := by decide
def e2262376955234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2262376955234 : Closed e2262376955234 ∧ code e2262376955234 = 11058469977442 := by decide
theorem cert_e2262376955234 : check e2262376955234 [[],[.under]] .three = true := by decide
def e2262376955246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2262376955246 : Closed e2262376955246 ∧ code e2262376955246 = 11058469977454 := by decide
theorem cert_e2262376955246 : check e2262376955246 [[],[.under]] .three = true := by decide
def e2262376955254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2262376955254 : Closed e2262376955254 ∧ code e2262376955254 = 11058469977462 := by decide
theorem cert_e2262376955254 : check e2262376955254 [[],[.under]] .three = true := by decide
def e2262376955274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262376955274 : Closed e2262376955274 ∧ code e2262376955274 = 11058469977482 := by decide
theorem cert_e2262376955274 : check e2262376955274 [[],[.under]] .three = true := by decide
def e2262376955298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262376955298 : Closed e2262376955298 ∧ code e2262376955298 = 11058469977506 := by decide
theorem cert_e2262376955298 : check e2262376955298 [[],[.under]] .three = true := by decide
def e2262376955310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2262376955310 : Closed e2262376955310 ∧ code e2262376955310 = 11058469977518 := by decide
theorem cert_e2262376955310 : check e2262376955310 [[],[.under]] .three = true := by decide
def e2262376955318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2262376955318 : Closed e2262376955318 ∧ code e2262376955318 = 11058469977526 := by decide
theorem cert_e2262376955318 : check e2262376955318 [[],[.under]] .three = true := by decide
def e2262376955322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2262376955322 : Closed e2262376955322 ∧ code e2262376955322 = 11058469977530 := by decide
theorem cert_e2262376955322 : check e2262376955322 [[],[.under]] .three = true := by decide
def e2262376955350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2262376955350 : Closed e2262376955350 ∧ code e2262376955350 = 11058469977558 := by decide
theorem cert_e2262376955350 : check e2262376955350 [[],[.under]] .three = true := by decide
def e2262376955354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2262376955354 : Closed e2262376955354 ∧ code e2262376955354 = 11058469977562 := by decide
theorem cert_e2262376955354 : check e2262376955354 [[],[.under]] .three = true := by decide
def e2262376956398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e2262376956398 : Closed e2262376956398 ∧ code e2262376956398 = 11058469978606 := by decide
theorem cert_e2262376956398 : check e2262376956398 [[],[.under]] .three = true := by decide
def e2262376956406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e2262376956406 : Closed e2262376956406 ∧ code e2262376956406 = 11058469978614 := by decide
theorem cert_e2262376956406 : check e2262376956406 [[],[.under]] .three = true := by decide
def e2262376957166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262376957166 : Closed e2262376957166 ∧ code e2262376957166 = 11058469979374 := by decide
theorem cert_e2262376957166 : check e2262376957166 [[],[.under]] .three = true := by decide
def e2262376957174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262376957174 : Closed e2262376957174 ∧ code e2262376957174 = 11058469979382 := by decide
theorem cert_e2262376957174 : check e2262376957174 [[],[.under]] .three = true := by decide
def e2262376957726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2262376957726 : Closed e2262376957726 ∧ code e2262376957726 = 11058469979934 := by decide
theorem cert_e2262376957726 : check e2262376957726 [[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262376897750
#print axioms Blc.Floor43.cert_e2262376897754
#print axioms Blc.Floor43.cert_e2262376897770
#print axioms Blc.Floor43.cert_e2262376897846
#print axioms Blc.Floor43.cert_e2262376897850
#print axioms Blc.Floor43.cert_e2262376897946
