import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422376652566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422376652566 : Closed e2422376652566 ∧ code e2422376652566 = 11218469674774 := by decide
theorem cert_e2422376652566 : check e2422376652566 [[],[]] .three = true := by decide
def e2422376652570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422376652570 : Closed e2422376652570 ∧ code e2422376652570 = 11218469674778 := by decide
theorem cert_e2422376652570 : check e2422376652570 [[],[]] .three = true := by decide
def e2422376652614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422376652614 : Closed e2422376652614 ∧ code e2422376652614 = 11218469674822 := by decide
theorem cert_e2422376652614 : check e2422376652614 [[],[]] .three = true := by decide
def e2422376652638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 3)))))))))
theorem wire_e2422376652638 : Closed e2422376652638 ∧ code e2422376652638 = 11218469674846 := by decide
theorem cert_e2422376652638 : check e2422376652638 [[],[]] .three = true := by decide
def e2422376652642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422376652642 : Closed e2422376652642 ∧ code e2422376652642 = 11218469674850 := by decide
theorem cert_e2422376652642 : check e2422376652642 [[],[]] .three = true := by decide
def e2422376652654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e2422376652654 : Closed e2422376652654 ∧ code e2422376652654 = 11218469674862 := by decide
theorem cert_e2422376652654 : check e2422376652654 [[],[]] .three = true := by decide
def e2422376652662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e2422376652662 : Closed e2422376652662 ∧ code e2422376652662 = 11218469674870 := by decide
theorem cert_e2422376652662 : check e2422376652662 [[],[]] .three = true := by decide
def e2422376652666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 0)))))))))
theorem wire_e2422376652666 : Closed e2422376652666 ∧ code e2422376652666 = 11218469674874 := by decide
theorem cert_e2422376652666 : check e2422376652666 [[],[]] .three = true := by decide
def e2422376653246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422376653246 : Closed e2422376653246 ∧ code e2422376653246 = 11218469675454 := by decide
theorem cert_e2422376653246 : check e2422376653246 [[],[]] .three = true := by decide
def e2422376653278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422376653278 : Closed e2422376653278 ∧ code e2422376653278 = 11218469675486 := by decide
theorem cert_e2422376653278 : check e2422376653278 [[],[]] .smaller = true := by decide
def e2422376653302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422376653302 : Closed e2422376653302 ∧ code e2422376653302 = 11218469675510 := by decide
theorem cert_e2422376653302 : check e2422376653302 [[],[]] .smaller = true := by decide
def e2422376653306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422376653306 : Closed e2422376653306 ∧ code e2422376653306 = 11218469675514 := by decide
theorem cert_e2422376653306 : check e2422376653306 [[],[]] .three = true := by decide
def e2422376654254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422376654254 : Closed e2422376654254 ∧ code e2422376654254 = 11218469676462 := by decide
theorem cert_e2422376654254 : check e2422376654254 [[],[]] .smaller = true := by decide
def e2422376654266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422376654266 : Closed e2422376654266 ∧ code e2422376654266 = 11218469676474 := by decide
theorem cert_e2422376654266 : check e2422376654266 [[],[]] .smaller = true := by decide
def e2422376654314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422376654314 : Closed e2422376654314 ∧ code e2422376654314 = 11218469676522 := by decide
theorem cert_e2422376654314 : check e2422376654314 [[],[]] .smaller = true := by decide
def e2422376654398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e2422376654398 : Closed e2422376654398 ∧ code e2422376654398 = 11218469676606 := by decide
theorem cert_e2422376654398 : check e2422376654398 [[],[]] .three = true := by decide
def e2422376654446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422376654446 : Closed e2422376654446 ∧ code e2422376654446 = 11218469676654 := by decide
theorem cert_e2422376654446 : check e2422376654446 [[],[]] .smaller = true := by decide
def e2422376654458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422376654458 : Closed e2422376654458 ∧ code e2422376654458 = 11218469676666 := by decide
theorem cert_e2422376654458 : check e2422376654458 [[],[]] .smaller = true := by decide
def e2422376654622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422376654622 : Closed e2422376654622 ∧ code e2422376654622 = 11218469676830 := by decide
theorem cert_e2422376654622 : check e2422376654622 [[],[]] .smaller = true := by decide
def e2422376654722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422376654722 : Closed e2422376654722 ∧ code e2422376654722 = 11218469676930 := by decide
theorem cert_e2422376654722 : check e2422376654722 [[],[]] .smaller = true := by decide
def e2422376654734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422376654734 : Closed e2422376654734 ∧ code e2422376654734 = 11218469676942 := by decide
theorem cert_e2422376654734 : check e2422376654734 [[],[]] .smaller = true := by decide
def e2422376654746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422376654746 : Closed e2422376654746 ∧ code e2422376654746 = 11218469676954 := by decide
theorem cert_e2422376654746 : check e2422376654746 [[],[]] .smaller = true := by decide
def e2422376654790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e2422376654790 : Closed e2422376654790 ∧ code e2422376654790 = 11218469676998 := by decide
theorem cert_e2422376654790 : check e2422376654790 [[],[]] .three = true := by decide
def e2422376654814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 3))))))))))
theorem wire_e2422376654814 : Closed e2422376654814 ∧ code e2422376654814 = 11218469677022 := by decide
theorem cert_e2422376654814 : check e2422376654814 [[],[]] .three = true := by decide
def e2422376657022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 5)))))))))))
theorem wire_e2422376657022 : Closed e2422376657022 ∧ code e2422376657022 = 11218469679230 := by decide
theorem cert_e2422376657022 : check e2422376657022 [[],[]] .three = true := by decide
def e2422376657118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422376657118 : Closed e2422376657118 ∧ code e2422376657118 = 11218469679326 := by decide
theorem cert_e2422376657118 : check e2422376657118 [[],[]] .smaller = true := by decide
def e2422376657146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422376657146 : Closed e2422376657146 ∧ code e2422376657146 = 11218469679354 := by decide
theorem cert_e2422376657146 : check e2422376657146 [[],[]] .smaller = true := by decide
def e2422376657694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2422376657694 : Closed e2422376657694 ∧ code e2422376657694 = 11218469679902 := by decide
theorem cert_e2422376657694 : check e2422376657694 [[],[]] .smaller = true := by decide
def e2422376657862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2422376657862 : Closed e2422376657862 ∧ code e2422376657862 = 11218469680070 := by decide
theorem cert_e2422376657862 : check e2422376657862 [[],[]] .smaller = true := by decide
def e2422376657886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422376657886 : Closed e2422376657886 ∧ code e2422376657886 = 11218469680094 := by decide
theorem cert_e2422376657886 : check e2422376657886 [[],[]] .three = true := by decide
def e2422376657890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e2422376657890 : Closed e2422376657890 ∧ code e2422376657890 = 11218469680098 := by decide
theorem cert_e2422376657890 : check e2422376657890 [[],[]] .three = true := by decide
def e2422376657902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422376657902 : Closed e2422376657902 ∧ code e2422376657902 = 11218469680110 := by decide
theorem cert_e2422376657902 : check e2422376657902 [[],[]] .three = true := by decide
def e2422376658970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422376658970 : Closed e2422376658970 ∧ code e2422376658970 = 11218469681178 := by decide
theorem cert_e2422376658970 : check e2422376658970 [[],[]] .smaller = true := by decide
def e2422376659006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422376659006 : Closed e2422376659006 ∧ code e2422376659006 = 11218469681214 := by decide
theorem cert_e2422376659006 : check e2422376659006 [[],[]] .smaller = true := by decide
def e2422376659054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422376659054 : Closed e2422376659054 ∧ code e2422376659054 = 11218469681262 := by decide
theorem cert_e2422376659054 : check e2422376659054 [[],[]] .smaller = true := by decide
def e2422376659062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422376659062 : Closed e2422376659062 ∧ code e2422376659062 = 11218469681270 := by decide
theorem cert_e2422376659062 : check e2422376659062 [[],[]] .smaller = true := by decide
def e2422376659066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422376659066 : Closed e2422376659066 ∧ code e2422376659066 = 11218469681274 := by decide
theorem cert_e2422376659066 : check e2422376659066 [[],[]] .smaller = true := by decide
def e2422376659306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422376659306 : Closed e2422376659306 ∧ code e2422376659306 = 11218469681514 := by decide
theorem cert_e2422376659306 : check e2422376659306 [[],[]] .smaller = true := by decide
def e2422376659330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422376659330 : Closed e2422376659330 ∧ code e2422376659330 = 11218469681538 := by decide
theorem cert_e2422376659330 : check e2422376659330 [[],[]] .smaller = true := by decide
def e2422376659342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422376659342 : Closed e2422376659342 ∧ code e2422376659342 = 11218469681550 := by decide
theorem cert_e2422376659342 : check e2422376659342 [[],[]] .smaller = true := by decide
def e2422376659354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422376659354 : Closed e2422376659354 ∧ code e2422376659354 = 11218469681562 := by decide
theorem cert_e2422376659354 : check e2422376659354 [[],[]] .smaller = true := by decide
def e2422376659398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422376659398 : Closed e2422376659398 ∧ code e2422376659398 = 11218469681606 := by decide
theorem cert_e2422376659398 : check e2422376659398 [[],[]] .smaller = true := by decide
def e2422376659422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422376659422 : Closed e2422376659422 ∧ code e2422376659422 = 11218469681630 := by decide
theorem cert_e2422376659422 : check e2422376659422 [[],[]] .three = true := by decide
def e2422376659426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422376659426 : Closed e2422376659426 ∧ code e2422376659426 = 11218469681634 := by decide
theorem cert_e2422376659426 : check e2422376659426 [[],[]] .smaller = true := by decide
def e2422376659438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422376659438 : Closed e2422376659438 ∧ code e2422376659438 = 11218469681646 := by decide
theorem cert_e2422376659438 : check e2422376659438 [[],[]] .smaller = true := by decide
def e2422376659446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422376659446 : Closed e2422376659446 ∧ code e2422376659446 = 11218469681654 := by decide
theorem cert_e2422376659446 : check e2422376659446 [[],[]] .three = true := by decide
def e2422376659998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422376659998 : Closed e2422376659998 ∧ code e2422376659998 = 11218469682206 := by decide
theorem cert_e2422376659998 : check e2422376659998 [[],[]] .three = true := by decide
def e2422376660022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376660022 : Closed e2422376660022 ∧ code e2422376660022 = 11218469682230 := by decide
theorem cert_e2422376660022 : check e2422376660022 [[],[]] .three = true := by decide
def e2422376660026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376660026 : Closed e2422376660026 ∧ code e2422376660026 = 11218469682234 := by decide
theorem cert_e2422376660026 : check e2422376660026 [[],[]] .three = true := by decide
def e2422376660166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422376660166 : Closed e2422376660166 ∧ code e2422376660166 = 11218469682374 := by decide
theorem cert_e2422376660166 : check e2422376660166 [[],[]] .three = true := by decide
def e2422376660190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422376660190 : Closed e2422376660190 ∧ code e2422376660190 = 11218469682398 := by decide
theorem cert_e2422376660190 : check e2422376660190 [[],[]] .three = true := by decide
def e2422376660194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422376660194 : Closed e2422376660194 ∧ code e2422376660194 = 11218469682402 := by decide
theorem cert_e2422376660194 : check e2422376660194 [[],[]] .three = true := by decide
def e2422376660206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422376660206 : Closed e2422376660206 ∧ code e2422376660206 = 11218469682414 := by decide
theorem cert_e2422376660206 : check e2422376660206 [[],[]] .three = true := by decide
def e2422376660214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422376660214 : Closed e2422376660214 ∧ code e2422376660214 = 11218469682422 := by decide
theorem cert_e2422376660214 : check e2422376660214 [[],[]] .three = true := by decide
def e2422376660218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422376660218 : Closed e2422376660218 ∧ code e2422376660218 = 11218469682426 := by decide
theorem cert_e2422376660218 : check e2422376660218 [[],[]] .three = true := by decide
def e2422376696686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422376696686 : Closed e2422376696686 ∧ code e2422376696686 = 11218469718894 := by decide
theorem cert_e2422376696686 : check e2422376696686 [[],[]] .smaller = true := by decide
def e2422376696694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422376696694 : Closed e2422376696694 ∧ code e2422376696694 = 11218469718902 := by decide
theorem cert_e2422376696694 : check e2422376696694 [[],[]] .smaller = true := by decide
def e2422376696750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422376696750 : Closed e2422376696750 ∧ code e2422376696750 = 11218469718958 := by decide
theorem cert_e2422376696750 : check e2422376696750 [[],[]] .smaller = true := by decide
def e2422376696762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422376696762 : Closed e2422376696762 ∧ code e2422376696762 = 11218469718970 := by decide
theorem cert_e2422376696762 : check e2422376696762 [[],[]] .smaller = true := by decide
def e2422376696790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422376696790 : Closed e2422376696790 ∧ code e2422376696790 = 11218469718998 := by decide
theorem cert_e2422376696790 : check e2422376696790 [[],[]] .smaller = true := by decide
def e2422376696794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422376696794 : Closed e2422376696794 ∧ code e2422376696794 = 11218469719002 := by decide
theorem cert_e2422376696794 : check e2422376696794 [[],[]] .smaller = true := by decide
def e2422376697070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422376697070 : Closed e2422376697070 ∧ code e2422376697070 = 11218469719278 := by decide
theorem cert_e2422376697070 : check e2422376697070 [[],[]] .smaller = true := by decide
def e2422376697078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422376697078 : Closed e2422376697078 ∧ code e2422376697078 = 11218469719286 := by decide
theorem cert_e2422376697078 : check e2422376697078 [[],[]] .smaller = true := by decide
def e2422376697406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e2422376697406 : Closed e2422376697406 ∧ code e2422376697406 = 11218469719614 := by decide
theorem cert_e2422376697406 : check e2422376697406 [[],[]] .smaller = true := by decide
def e2422376697454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422376697454 : Closed e2422376697454 ∧ code e2422376697454 = 11218469719662 := by decide
theorem cert_e2422376697454 : check e2422376697454 [[],[]] .smaller = true := by decide
def e2422376697466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422376697466 : Closed e2422376697466 ∧ code e2422376697466 = 11218469719674 := by decide
theorem cert_e2422376697466 : check e2422376697466 [[],[]] .smaller = true := by decide
def e2422376697654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376697654 : Closed e2422376697654 ∧ code e2422376697654 = 11218469719862 := by decide
theorem cert_e2422376697654 : check e2422376697654 [[],[]] .smaller = true := by decide
def e2422376697658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376697658 : Closed e2422376697658 ∧ code e2422376697658 = 11218469719866 := by decide
theorem cert_e2422376697658 : check e2422376697658 [[],[]] .smaller = true := by decide
def e2422376697742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e2422376697742 : Closed e2422376697742 ∧ code e2422376697742 = 11218469719950 := by decide
theorem cert_e2422376697742 : check e2422376697742 [[],[]] .smaller = true := by decide
def e2422376697790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e2422376697790 : Closed e2422376697790 ∧ code e2422376697790 = 11218469719998 := by decide
theorem cert_e2422376697790 : check e2422376697790 [[],[]] .three = true := by decide
def e2422376697822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e2422376697822 : Closed e2422376697822 ∧ code e2422376697822 = 11218469720030 := by decide
theorem cert_e2422376697822 : check e2422376697822 [[],[]] .three = true := by decide
def e2422376705118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e2422376705118 : Closed e2422376705118 ∧ code e2422376705118 = 11218469727326 := by decide
theorem cert_e2422376705118 : check e2422376705118 [[],[]] .three = true := by decide
def e2422376705134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2422376705134 : Closed e2422376705134 ∧ code e2422376705134 = 11218469727342 := by decide
theorem cert_e2422376705134 : check e2422376705134 [[],[]] .smaller = true := by decide
def e2422376705146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2422376705146 : Closed e2422376705146 ∧ code e2422376705146 = 11218469727354 := by decide
theorem cert_e2422376705146 : check e2422376705146 [[],[]] .smaller = true := by decide
def e2422376705310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2422376705310 : Closed e2422376705310 ∧ code e2422376705310 = 11218469727518 := by decide
theorem cert_e2422376705310 : check e2422376705310 [[],[]] .smaller = true := by decide
def e2422376705478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2422376705478 : Closed e2422376705478 ∧ code e2422376705478 = 11218469727686 := by decide
theorem cert_e2422376705478 : check e2422376705478 [[],[]] .smaller = true := by decide
def e2422376705502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2422376705502 : Closed e2422376705502 ∧ code e2422376705502 = 11218469727710 := by decide
theorem cert_e2422376705502 : check e2422376705502 [[],[]] .three = true := by decide
def e2422376705506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e2422376705506 : Closed e2422376705506 ∧ code e2422376705506 = 11218469727714 := by decide
theorem cert_e2422376705506 : check e2422376705506 [[],[]] .three = true := by decide
def e2422376705518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2422376705518 : Closed e2422376705518 ∧ code e2422376705518 = 11218469727726 := by decide
theorem cert_e2422376705518 : check e2422376705518 [[],[]] .three = true := by decide
def e2422376705818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422376705818 : Closed e2422376705818 ∧ code e2422376705818 = 11218469728026 := by decide
theorem cert_e2422376705818 : check e2422376705818 [[],[]] .smaller = true := by decide
def e2422376705862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422376705862 : Closed e2422376705862 ∧ code e2422376705862 = 11218469728070 := by decide
theorem cert_e2422376705862 : check e2422376705862 [[],[]] .smaller = true := by decide
def e2422376705886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2422376705886 : Closed e2422376705886 ∧ code e2422376705886 = 11218469728094 := by decide
theorem cert_e2422376705886 : check e2422376705886 [[],[]] .three = true := by decide
def e2422376705914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2422376705914 : Closed e2422376705914 ∧ code e2422376705914 = 11218469728122 := by decide
theorem cert_e2422376705914 : check e2422376705914 [[],[]] .three = true := by decide
def e2422376705930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422376705930 : Closed e2422376705930 ∧ code e2422376705930 = 11218469728138 := by decide
theorem cert_e2422376705930 : check e2422376705930 [[],[]] .three = true := by decide
def e2422376705954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422376705954 : Closed e2422376705954 ∧ code e2422376705954 = 11218469728162 := by decide
theorem cert_e2422376705954 : check e2422376705954 [[],[]] .three = true := by decide
def e2422376705966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2422376705966 : Closed e2422376705966 ∧ code e2422376705966 = 11218469728174 := by decide
theorem cert_e2422376705966 : check e2422376705966 [[],[]] .three = true := by decide
def e2422376705978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2422376705978 : Closed e2422376705978 ∧ code e2422376705978 = 11218469728186 := by decide
theorem cert_e2422376705978 : check e2422376705978 [[],[]] .three = true := by decide
def e2422376706174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 5)))))))))))
theorem wire_e2422376706174 : Closed e2422376706174 ∧ code e2422376706174 = 11218469728382 := by decide
theorem cert_e2422376706174 : check e2422376706174 [[],[]] .three = true := by decide
def e2422376706270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422376706270 : Closed e2422376706270 ∧ code e2422376706270 = 11218469728478 := by decide
theorem cert_e2422376706270 : check e2422376706270 [[],[]] .smaller = true := by decide
def e2422376706298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422376706298 : Closed e2422376706298 ∧ code e2422376706298 = 11218469728506 := by decide
theorem cert_e2422376706298 : check e2422376706298 [[],[]] .smaller = true := by decide
def e2422376706846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2422376706846 : Closed e2422376706846 ∧ code e2422376706846 = 11218469729054 := by decide
theorem cert_e2422376706846 : check e2422376706846 [[],[]] .smaller = true := by decide
def e2422376707014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2422376707014 : Closed e2422376707014 ∧ code e2422376707014 = 11218469729222 := by decide
theorem cert_e2422376707014 : check e2422376707014 [[],[]] .smaller = true := by decide
def e2422376707038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422376707038 : Closed e2422376707038 ∧ code e2422376707038 = 11218469729246 := by decide
theorem cert_e2422376707038 : check e2422376707038 [[],[]] .three = true := by decide
def e2422376707042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e2422376707042 : Closed e2422376707042 ∧ code e2422376707042 = 11218469729250 := by decide
theorem cert_e2422376707042 : check e2422376707042 [[],[]] .three = true := by decide
def e2422376707054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422376707054 : Closed e2422376707054 ∧ code e2422376707054 = 11218469729262 := by decide
theorem cert_e2422376707054 : check e2422376707054 [[],[]] .three = true := by decide
def e2422376709174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376709174 : Closed e2422376709174 ∧ code e2422376709174 = 11218469731382 := by decide
theorem cert_e2422376709174 : check e2422376709174 [[],[]] .smaller = true := by decide
def e2422376709178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376709178 : Closed e2422376709178 ∧ code e2422376709178 = 11218469731386 := by decide
theorem cert_e2422376709178 : check e2422376709178 [[],[]] .smaller = true := by decide
def e2422376709318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422376709318 : Closed e2422376709318 ∧ code e2422376709318 = 11218469731526 := by decide
theorem cert_e2422376709318 : check e2422376709318 [[],[]] .smaller = true := by decide
def e2422376709342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422376709342 : Closed e2422376709342 ∧ code e2422376709342 = 11218469731550 := by decide
theorem cert_e2422376709342 : check e2422376709342 [[],[]] .three = true := by decide
def e2422376709370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422376709370 : Closed e2422376709370 ∧ code e2422376709370 = 11218469731578 := by decide
theorem cert_e2422376709370 : check e2422376709370 [[],[]] .three = true := by decide
def e2422376709646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422376709646 : Closed e2422376709646 ∧ code e2422376709646 = 11218469731854 := by decide
theorem cert_e2422376709646 : check e2422376709646 [[],[]] .three = true := by decide
def e2422376709730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422376709730 : Closed e2422376709730 ∧ code e2422376709730 = 11218469731938 := by decide
theorem cert_e2422376709730 : check e2422376709730 [[],[]] .three = true := by decide
def e2422376709742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422376709742 : Closed e2422376709742 ∧ code e2422376709742 = 11218469731950 := by decide
theorem cert_e2422376709742 : check e2422376709742 [[],[]] .three = true := by decide
def e2422376709754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422376709754 : Closed e2422376709754 ∧ code e2422376709754 = 11218469731962 := by decide
theorem cert_e2422376709754 : check e2422376709754 [[],[]] .three = true := by decide
def e2422376727022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422376727022 : Closed e2422376727022 ∧ code e2422376727022 = 11218469749230 := by decide
theorem cert_e2422376727022 : check e2422376727022 [[],[]] .smaller = true := by decide
def e2422376727990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2422376727990 : Closed e2422376727990 ∧ code e2422376727990 = 11218469750198 := by decide
theorem cert_e2422376727990 : check e2422376727990 [[],[]] .smaller = true := by decide
def e2422376728022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2422376728022 : Closed e2422376728022 ∧ code e2422376728022 = 11218469750230 := by decide
theorem cert_e2422376728022 : check e2422376728022 [[],[]] .smaller = true := by decide
def e2422376728026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2422376728026 : Closed e2422376728026 ∧ code e2422376728026 = 11218469750234 := by decide
theorem cert_e2422376728026 : check e2422376728026 [[],[]] .smaller = true := by decide
def e2422376728182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422376728182 : Closed e2422376728182 ∧ code e2422376728182 = 11218469750390 := by decide
theorem cert_e2422376728182 : check e2422376728182 [[],[]] .smaller = true := by decide
def e2422376728350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422376728350 : Closed e2422376728350 ∧ code e2422376728350 = 11218469750558 := by decide
theorem cert_e2422376728350 : check e2422376728350 [[],[]] .smaller = true := by decide
def e2422376728374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376728374 : Closed e2422376728374 ∧ code e2422376728374 = 11218469750582 := by decide
theorem cert_e2422376728374 : check e2422376728374 [[],[]] .smaller = true := by decide
def e2422376728378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376728378 : Closed e2422376728378 ∧ code e2422376728378 = 11218469750586 := by decide
theorem cert_e2422376728378 : check e2422376728378 [[],[]] .smaller = true := by decide
def e2422376728462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422376728462 : Closed e2422376728462 ∧ code e2422376728462 = 11218469750670 := by decide
theorem cert_e2422376728462 : check e2422376728462 [[],[]] .smaller = true := by decide
def e2422376728510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2422376728510 : Closed e2422376728510 ∧ code e2422376728510 = 11218469750718 := by decide
theorem cert_e2422376728510 : check e2422376728510 [[],[]] .three = true := by decide
def e2422376728558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2422376728558 : Closed e2422376728558 ∧ code e2422376728558 = 11218469750766 := by decide
theorem cert_e2422376728558 : check e2422376728558 [[],[]] .three = true := by decide
def e2422376732074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422376732074 : Closed e2422376732074 ∧ code e2422376732074 = 11218469754282 := by decide
theorem cert_e2422376732074 : check e2422376732074 [[],[]] .smaller = true := by decide
def e2422376732170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422376732170 : Closed e2422376732170 ∧ code e2422376732170 = 11218469754378 := by decide
theorem cert_e2422376732170 : check e2422376732170 [[],[]] .smaller = true := by decide
def e2422376732206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422376732206 : Closed e2422376732206 ∧ code e2422376732206 = 11218469754414 := by decide
theorem cert_e2422376732206 : check e2422376732206 [[],[]] .smaller = true := by decide
def e2422376732214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422376732214 : Closed e2422376732214 ∧ code e2422376732214 = 11218469754422 := by decide
theorem cert_e2422376732214 : check e2422376732214 [[],[]] .smaller = true := by decide
def e2422376732218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422376732218 : Closed e2422376732218 ∧ code e2422376732218 = 11218469754426 := by decide
theorem cert_e2422376732218 : check e2422376732218 [[],[]] .smaller = true := by decide
def e2422376732266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422376732266 : Closed e2422376732266 ∧ code e2422376732266 = 11218469754474 := by decide
theorem cert_e2422376732266 : check e2422376732266 [[],[]] .smaller = true := by decide
def e2422376732290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422376732290 : Closed e2422376732290 ∧ code e2422376732290 = 11218469754498 := by decide
theorem cert_e2422376732290 : check e2422376732290 [[],[]] .smaller = true := by decide
def e2422376732302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422376732302 : Closed e2422376732302 ∧ code e2422376732302 = 11218469754510 := by decide
theorem cert_e2422376732302 : check e2422376732302 [[],[]] .smaller = true := by decide
def e2422376732314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422376732314 : Closed e2422376732314 ∧ code e2422376732314 = 11218469754522 := by decide
theorem cert_e2422376732314 : check e2422376732314 [[],[]] .smaller = true := by decide
def e2422376732358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422376732358 : Closed e2422376732358 ∧ code e2422376732358 = 11218469754566 := by decide
theorem cert_e2422376732358 : check e2422376732358 [[],[]] .smaller = true := by decide
def e2422376732382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2422376732382 : Closed e2422376732382 ∧ code e2422376732382 = 11218469754590 := by decide
theorem cert_e2422376732382 : check e2422376732382 [[],[]] .three = true := by decide
def e2422376732386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422376732386 : Closed e2422376732386 ∧ code e2422376732386 = 11218469754594 := by decide
theorem cert_e2422376732386 : check e2422376732386 [[],[]] .smaller = true := by decide
def e2422376732398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e2422376732398 : Closed e2422376732398 ∧ code e2422376732398 = 11218469754606 := by decide
theorem cert_e2422376732398 : check e2422376732398 [[],[]] .smaller = true := by decide
def e2422376732406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2422376732406 : Closed e2422376732406 ∧ code e2422376732406 = 11218469754614 := by decide
theorem cert_e2422376732406 : check e2422376732406 [[],[]] .three = true := by decide
def e2422376732442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422376732442 : Closed e2422376732442 ∧ code e2422376732442 = 11218469754650 := by decide
theorem cert_e2422376732442 : check e2422376732442 [[],[]] .smaller = true := by decide
def e2422376732486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422376732486 : Closed e2422376732486 ∧ code e2422376732486 = 11218469754694 := by decide
theorem cert_e2422376732486 : check e2422376732486 [[],[]] .smaller = true := by decide
def e2422376732510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2422376732510 : Closed e2422376732510 ∧ code e2422376732510 = 11218469754718 := by decide
theorem cert_e2422376732510 : check e2422376732510 [[],[]] .three = true := by decide
def e2422376732538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2422376732538 : Closed e2422376732538 ∧ code e2422376732538 = 11218469754746 := by decide
theorem cert_e2422376732538 : check e2422376732538 [[],[]] .three = true := by decide
def e2422376732554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422376732554 : Closed e2422376732554 ∧ code e2422376732554 = 11218469754762 := by decide
theorem cert_e2422376732554 : check e2422376732554 [[],[]] .smaller = true := by decide
def e2422376732578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422376732578 : Closed e2422376732578 ∧ code e2422376732578 = 11218469754786 := by decide
theorem cert_e2422376732578 : check e2422376732578 [[],[]] .smaller = true := by decide
def e2422376732590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e2422376732590 : Closed e2422376732590 ∧ code e2422376732590 = 11218469754798 := by decide
theorem cert_e2422376732590 : check e2422376732590 [[],[]] .smaller = true := by decide
def e2422376732602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e2422376732602 : Closed e2422376732602 ∧ code e2422376732602 = 11218469754810 := by decide
theorem cert_e2422376732602 : check e2422376732602 [[],[]] .smaller = true := by decide
def e2422376732630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2422376732630 : Closed e2422376732630 ∧ code e2422376732630 = 11218469754838 := by decide
theorem cert_e2422376732630 : check e2422376732630 [[],[]] .three = true := by decide
def e2422376732634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2422376732634 : Closed e2422376732634 ∧ code e2422376732634 = 11218469754842 := by decide
theorem cert_e2422376732634 : check e2422376732634 [[],[]] .three = true := by decide
def e2422376732698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422376732698 : Closed e2422376732698 ∧ code e2422376732698 = 11218469754906 := by decide
theorem cert_e2422376732698 : check e2422376732698 [[],[]] .smaller = true := by decide
def e2422376732734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422376732734 : Closed e2422376732734 ∧ code e2422376732734 = 11218469754942 := by decide
theorem cert_e2422376732734 : check e2422376732734 [[],[]] .smaller = true := by decide
def e2422376732782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422376732782 : Closed e2422376732782 ∧ code e2422376732782 = 11218469754990 := by decide
theorem cert_e2422376732782 : check e2422376732782 [[],[]] .smaller = true := by decide
def e2422376732790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422376732790 : Closed e2422376732790 ∧ code e2422376732790 = 11218469754998 := by decide
theorem cert_e2422376732790 : check e2422376732790 [[],[]] .smaller = true := by decide
def e2422376732794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422376732794 : Closed e2422376732794 ∧ code e2422376732794 = 11218469755002 := by decide
theorem cert_e2422376732794 : check e2422376732794 [[],[]] .smaller = true := by decide
def e2422376733034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422376733034 : Closed e2422376733034 ∧ code e2422376733034 = 11218469755242 := by decide
theorem cert_e2422376733034 : check e2422376733034 [[],[]] .smaller = true := by decide
def e2422376733058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422376733058 : Closed e2422376733058 ∧ code e2422376733058 = 11218469755266 := by decide
theorem cert_e2422376733058 : check e2422376733058 [[],[]] .smaller = true := by decide
def e2422376733070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422376733070 : Closed e2422376733070 ∧ code e2422376733070 = 11218469755278 := by decide
theorem cert_e2422376733070 : check e2422376733070 [[],[]] .smaller = true := by decide
def e2422376733082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422376733082 : Closed e2422376733082 ∧ code e2422376733082 = 11218469755290 := by decide
theorem cert_e2422376733082 : check e2422376733082 [[],[]] .smaller = true := by decide
def e2422376733126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422376733126 : Closed e2422376733126 ∧ code e2422376733126 = 11218469755334 := by decide
theorem cert_e2422376733126 : check e2422376733126 [[],[]] .smaller = true := by decide
def e2422376733150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422376733150 : Closed e2422376733150 ∧ code e2422376733150 = 11218469755358 := by decide
theorem cert_e2422376733150 : check e2422376733150 [[],[]] .three = true := by decide
def e2422376733154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422376733154 : Closed e2422376733154 ∧ code e2422376733154 = 11218469755362 := by decide
theorem cert_e2422376733154 : check e2422376733154 [[],[]] .smaller = true := by decide
def e2422376733166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422376733166 : Closed e2422376733166 ∧ code e2422376733166 = 11218469755374 := by decide
theorem cert_e2422376733166 : check e2422376733166 [[],[]] .smaller = true := by decide
def e2422376733174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422376733174 : Closed e2422376733174 ∧ code e2422376733174 = 11218469755382 := by decide
theorem cert_e2422376733174 : check e2422376733174 [[],[]] .three = true := by decide
def e2422376733750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376733750 : Closed e2422376733750 ∧ code e2422376733750 = 11218469755958 := by decide
theorem cert_e2422376733750 : check e2422376733750 [[],[]] .smaller = true := by decide
def e2422376733754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376733754 : Closed e2422376733754 ∧ code e2422376733754 = 11218469755962 := by decide
theorem cert_e2422376733754 : check e2422376733754 [[],[]] .smaller = true := by decide
def e2422376733894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422376733894 : Closed e2422376733894 ∧ code e2422376733894 = 11218469756102 := by decide
theorem cert_e2422376733894 : check e2422376733894 [[],[]] .smaller = true := by decide
def e2422376733918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422376733918 : Closed e2422376733918 ∧ code e2422376733918 = 11218469756126 := by decide
theorem cert_e2422376733918 : check e2422376733918 [[],[]] .three = true := by decide
def e2422376733946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422376733946 : Closed e2422376733946 ∧ code e2422376733946 = 11218469756154 := by decide
theorem cert_e2422376733946 : check e2422376733946 [[],[]] .three = true := by decide
def e2422376734222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422376734222 : Closed e2422376734222 ∧ code e2422376734222 = 11218469756430 := by decide
theorem cert_e2422376734222 : check e2422376734222 [[],[]] .smaller = true := by decide
def e2422376734270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2422376734270 : Closed e2422376734270 ∧ code e2422376734270 = 11218469756478 := by decide
theorem cert_e2422376734270 : check e2422376734270 [[],[]] .three = true := by decide
end Blc.Floor43
