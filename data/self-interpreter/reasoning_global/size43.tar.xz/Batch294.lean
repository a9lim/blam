import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411625658590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2411625658590 : Closed e2411625658590 ∧ code e2411625658590 = 11207718680798 := by decide
theorem cert_e2411625658590 : check e2411625658590 [[],[]] .three = true := by decide
def e2411625658618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2411625658618 : Closed e2411625658618 ∧ code e2411625658618 = 11207718680826 := by decide
theorem cert_e2411625658618 : check e2411625658618 [[],[]] .three = true := by decide
def e2411625658798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2411625658798 : Closed e2411625658798 ∧ code e2411625658798 = 11207718681006 := by decide
theorem cert_e2411625658798 : check e2411625658798 [[],[]] .smaller = true := by decide
def e2411625658810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2411625658810 : Closed e2411625658810 ∧ code e2411625658810 = 11207718681018 := by decide
theorem cert_e2411625658810 : check e2411625658810 [[],[]] .smaller = true := by decide
def e2411625658858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2411625658858 : Closed e2411625658858 ∧ code e2411625658858 = 11207718681066 := by decide
theorem cert_e2411625658858 : check e2411625658858 [[],[]] .smaller = true := by decide
def e2411625658942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2411625658942 : Closed e2411625658942 ∧ code e2411625658942 = 11207718681150 := by decide
theorem cert_e2411625658942 : check e2411625658942 [[],[]] .three = true := by decide
def e2411625658990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625658990 : Closed e2411625658990 ∧ code e2411625658990 = 11207718681198 := by decide
theorem cert_e2411625658990 : check e2411625658990 [[],[]] .smaller = true := by decide
def e2411625659002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625659002 : Closed e2411625659002 ∧ code e2411625659002 = 11207718681210 := by decide
theorem cert_e2411625659002 : check e2411625659002 [[],[]] .smaller = true := by decide
def e2411625659290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625659290 : Closed e2411625659290 ∧ code e2411625659290 = 11207718681498 := by decide
theorem cert_e2411625659290 : check e2411625659290 [[],[]] .smaller = true := by decide
def e2411625659334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2411625659334 : Closed e2411625659334 ∧ code e2411625659334 = 11207718681542 := by decide
theorem cert_e2411625659334 : check e2411625659334 [[],[]] .three = true := by decide
def e2411625659502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411625659502 : Closed e2411625659502 ∧ code e2411625659502 = 11207718681710 := by decide
theorem cert_e2411625659502 : check e2411625659502 [[],[]] .smaller = true := by decide
def e2411625659514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411625659514 : Closed e2411625659514 ∧ code e2411625659514 = 11207718681722 := by decide
theorem cert_e2411625659514 : check e2411625659514 [[],[]] .smaller = true := by decide
def e2411625659606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2411625659606 : Closed e2411625659606 ∧ code e2411625659606 = 11207718681814 := by decide
theorem cert_e2411625659606 : check e2411625659606 [[],[]] .smaller = true := by decide
def e2411625659610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2411625659610 : Closed e2411625659610 ∧ code e2411625659610 = 11207718681818 := by decide
theorem cert_e2411625659610 : check e2411625659610 [[],[]] .smaller = true := by decide
def e2411625659626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2411625659626 : Closed e2411625659626 ∧ code e2411625659626 = 11207718681834 := by decide
theorem cert_e2411625659626 : check e2411625659626 [[],[]] .smaller = true := by decide
def e2411625659678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411625659678 : Closed e2411625659678 ∧ code e2411625659678 = 11207718681886 := by decide
theorem cert_e2411625659678 : check e2411625659678 [[],[]] .smaller = true := by decide
def e2411625659702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625659702 : Closed e2411625659702 ∧ code e2411625659702 = 11207718681910 := by decide
theorem cert_e2411625659702 : check e2411625659702 [[],[]] .smaller = true := by decide
def e2411625659706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625659706 : Closed e2411625659706 ∧ code e2411625659706 = 11207718681914 := by decide
theorem cert_e2411625659706 : check e2411625659706 [[],[]] .smaller = true := by decide
def e2411625659802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625659802 : Closed e2411625659802 ∧ code e2411625659802 = 11207718682010 := by decide
theorem cert_e2411625659802 : check e2411625659802 [[],[]] .smaller = true := by decide
def e2411625659846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411625659846 : Closed e2411625659846 ∧ code e2411625659846 = 11207718682054 := by decide
theorem cert_e2411625659846 : check e2411625659846 [[],[]] .smaller = true := by decide
def e2411625659870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 3)))))))
theorem wire_e2411625659870 : Closed e2411625659870 ∧ code e2411625659870 = 11207718682078 := by decide
theorem cert_e2411625659870 : check e2411625659870 [[],[]] .three = true := by decide
def e2411625659886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 2)))))))
theorem wire_e2411625659886 : Closed e2411625659886 ∧ code e2411625659886 = 11207718682094 := by decide
theorem cert_e2411625659886 : check e2411625659886 [[],[]] .three = true := by decide
def e2411625659958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411625659958 : Closed e2411625659958 ∧ code e2411625659958 = 11207718682166 := by decide
theorem cert_e2411625659958 : check e2411625659958 [[],[]] .three = true := by decide
def e2411625659962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411625659962 : Closed e2411625659962 ∧ code e2411625659962 = 11207718682170 := by decide
theorem cert_e2411625659962 : check e2411625659962 [[],[]] .three = true := by decide
def e2411625660010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2411625660010 : Closed e2411625660010 ∧ code e2411625660010 = 11207718682218 := by decide
theorem cert_e2411625660010 : check e2411625660010 [[],[]] .three = true := by decide
def e2411625660046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411625660046 : Closed e2411625660046 ∧ code e2411625660046 = 11207718682254 := by decide
theorem cert_e2411625660046 : check e2411625660046 [[],[]] .three = true := by decide
def e2411625660058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625660058 : Closed e2411625660058 ∧ code e2411625660058 = 11207718682266 := by decide
theorem cert_e2411625660058 : check e2411625660058 [[],[]] .three = true := by decide
def e2411625660102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411625660102 : Closed e2411625660102 ∧ code e2411625660102 = 11207718682310 := by decide
theorem cert_e2411625660102 : check e2411625660102 [[],[]] .three = true := by decide
def e2411625660142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 2)))))))
theorem wire_e2411625660142 : Closed e2411625660142 ∧ code e2411625660142 = 11207718682350 := by decide
theorem cert_e2411625660142 : check e2411625660142 [[],[]] .three = true := by decide
def e2411625661374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e2411625661374 : Closed e2411625661374 ∧ code e2411625661374 = 11207718683582 := by decide
theorem cert_e2411625661374 : check e2411625661374 [[],[]] .three = true := by decide
def e2411625661406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2411625661406 : Closed e2411625661406 ∧ code e2411625661406 = 11207718683614 := by decide
theorem cert_e2411625661406 : check e2411625661406 [[],[]] .smaller = true := by decide
def e2411625661422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2411625661422 : Closed e2411625661422 ∧ code e2411625661422 = 11207718683630 := by decide
theorem cert_e2411625661422 : check e2411625661422 [[],[]] .smaller = true := by decide
def e2411625661430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e2411625661430 : Closed e2411625661430 ∧ code e2411625661430 = 11207718683638 := by decide
theorem cert_e2411625661430 : check e2411625661430 [[],[]] .three = true := by decide
def e2411625663326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2411625663326 : Closed e2411625663326 ∧ code e2411625663326 = 11207718685534 := by decide
theorem cert_e2411625663326 : check e2411625663326 [[],[]] .three = true := by decide
def e2411625663342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2411625663342 : Closed e2411625663342 ∧ code e2411625663342 = 11207718685550 := by decide
theorem cert_e2411625663342 : check e2411625663342 [[],[]] .smaller = true := by decide
def e2411625663350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2411625663350 : Closed e2411625663350 ∧ code e2411625663350 = 11207718685558 := by decide
theorem cert_e2411625663350 : check e2411625663350 [[],[]] .smaller = true := by decide
def e2411625663354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2411625663354 : Closed e2411625663354 ∧ code e2411625663354 = 11207718685562 := by decide
theorem cert_e2411625663354 : check e2411625663354 [[],[]] .three = true := by decide
def e2411625663406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2411625663406 : Closed e2411625663406 ∧ code e2411625663406 = 11207718685614 := by decide
theorem cert_e2411625663406 : check e2411625663406 [[],[]] .smaller = true := by decide
def e2411625663418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2411625663418 : Closed e2411625663418 ∧ code e2411625663418 = 11207718685626 := by decide
theorem cert_e2411625663418 : check e2411625663418 [[],[]] .smaller = true := by decide
def e2411625663446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2411625663446 : Closed e2411625663446 ∧ code e2411625663446 = 11207718685654 := by decide
theorem cert_e2411625663446 : check e2411625663446 [[],[]] .smaller = true := by decide
def e2411625663450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2411625663450 : Closed e2411625663450 ∧ code e2411625663450 = 11207718685658 := by decide
theorem cert_e2411625663450 : check e2411625663450 [[],[]] .smaller = true := by decide
def e2411625663466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2411625663466 : Closed e2411625663466 ∧ code e2411625663466 = 11207718685674 := by decide
theorem cert_e2411625663466 : check e2411625663466 [[],[]] .three = true := by decide
def e2411625663710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411625663710 : Closed e2411625663710 ∧ code e2411625663710 = 11207718685918 := by decide
theorem cert_e2411625663710 : check e2411625663710 [[],[]] .three = true := by decide
def e2411625663726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411625663726 : Closed e2411625663726 ∧ code e2411625663726 = 11207718685934 := by decide
theorem cert_e2411625663726 : check e2411625663726 [[],[]] .smaller = true := by decide
def e2411625663734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411625663734 : Closed e2411625663734 ∧ code e2411625663734 = 11207718685942 := by decide
theorem cert_e2411625663734 : check e2411625663734 [[],[]] .smaller = true := by decide
def e2411625663738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411625663738 : Closed e2411625663738 ∧ code e2411625663738 = 11207718685946 := by decide
theorem cert_e2411625663738 : check e2411625663738 [[],[]] .three = true := by decide
def e2411625664062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2411625664062 : Closed e2411625664062 ∧ code e2411625664062 = 11207718686270 := by decide
theorem cert_e2411625664062 : check e2411625664062 [[],[]] .three = true := by decide
def e2411625664110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411625664110 : Closed e2411625664110 ∧ code e2411625664110 = 11207718686318 := by decide
theorem cert_e2411625664110 : check e2411625664110 [[],[]] .smaller = true := by decide
def e2411625664122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411625664122 : Closed e2411625664122 ∧ code e2411625664122 = 11207718686330 := by decide
theorem cert_e2411625664122 : check e2411625664122 [[],[]] .smaller = true := by decide
def e2411625664286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e2411625664286 : Closed e2411625664286 ∧ code e2411625664286 = 11207718686494 := by decide
theorem cert_e2411625664286 : check e2411625664286 [[],[]] .smaller = true := by decide
def e2411625664310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625664310 : Closed e2411625664310 ∧ code e2411625664310 = 11207718686518 := by decide
theorem cert_e2411625664310 : check e2411625664310 [[],[]] .smaller = true := by decide
def e2411625664314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625664314 : Closed e2411625664314 ∧ code e2411625664314 = 11207718686522 := by decide
theorem cert_e2411625664314 : check e2411625664314 [[],[]] .smaller = true := by decide
def e2411625664398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2411625664398 : Closed e2411625664398 ∧ code e2411625664398 = 11207718686606 := by decide
theorem cert_e2411625664398 : check e2411625664398 [[],[]] .three = true := by decide
def e2411625664410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625664410 : Closed e2411625664410 ∧ code e2411625664410 = 11207718686618 := by decide
theorem cert_e2411625664410 : check e2411625664410 [[],[]] .three = true := by decide
def e2411625669086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2411625669086 : Closed e2411625669086 ∧ code e2411625669086 = 11207718691294 := by decide
theorem cert_e2411625669086 : check e2411625669086 [[],[]] .smaller = true := by decide
def e2411625669110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2411625669110 : Closed e2411625669110 ∧ code e2411625669110 = 11207718691318 := by decide
theorem cert_e2411625669110 : check e2411625669110 [[],[]] .smaller = true := by decide
def e2411625670062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2411625670062 : Closed e2411625670062 ∧ code e2411625670062 = 11207718692270 := by decide
theorem cert_e2411625670062 : check e2411625670062 [[],[]] .smaller = true := by decide
def e2411625670074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2411625670074 : Closed e2411625670074 ∧ code e2411625670074 = 11207718692282 := by decide
theorem cert_e2411625670074 : check e2411625670074 [[],[]] .smaller = true := by decide
def e2411625670122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2411625670122 : Closed e2411625670122 ∧ code e2411625670122 = 11207718692330 := by decide
theorem cert_e2411625670122 : check e2411625670122 [[],[]] .smaller = true := by decide
def e2411625670206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2411625670206 : Closed e2411625670206 ∧ code e2411625670206 = 11207718692414 := by decide
theorem cert_e2411625670206 : check e2411625670206 [[],[]] .three = true := by decide
def e2411625670254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411625670254 : Closed e2411625670254 ∧ code e2411625670254 = 11207718692462 := by decide
theorem cert_e2411625670254 : check e2411625670254 [[],[]] .smaller = true := by decide
def e2411625670266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411625670266 : Closed e2411625670266 ∧ code e2411625670266 = 11207718692474 := by decide
theorem cert_e2411625670266 : check e2411625670266 [[],[]] .smaller = true := by decide
def e2411625670554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625670554 : Closed e2411625670554 ∧ code e2411625670554 = 11207718692762 := by decide
theorem cert_e2411625670554 : check e2411625670554 [[],[]] .smaller = true := by decide
def e2411625670598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2411625670598 : Closed e2411625670598 ∧ code e2411625670598 = 11207718692806 := by decide
theorem cert_e2411625670598 : check e2411625670598 [[],[]] .three = true := by decide
def e2411625672942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2411625672942 : Closed e2411625672942 ∧ code e2411625672942 = 11207718695150 := by decide
theorem cert_e2411625672942 : check e2411625672942 [[],[]] .smaller = true := by decide
def e2411625672950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2411625672950 : Closed e2411625672950 ∧ code e2411625672950 = 11207718695158 := by decide
theorem cert_e2411625672950 : check e2411625672950 [[],[]] .smaller = true := by decide
def e2411625673430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2411625673430 : Closed e2411625673430 ∧ code e2411625673430 = 11207718695638 := by decide
theorem cert_e2411625673430 : check e2411625673430 [[],[]] .smaller = true := by decide
def e2411625673434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2411625673434 : Closed e2411625673434 ∧ code e2411625673434 = 11207718695642 := by decide
theorem cert_e2411625673434 : check e2411625673434 [[],[]] .smaller = true := by decide
def e2411625673450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2411625673450 : Closed e2411625673450 ∧ code e2411625673450 = 11207718695658 := by decide
theorem cert_e2411625673450 : check e2411625673450 [[],[]] .smaller = true := by decide
def e2411625673502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411625673502 : Closed e2411625673502 ∧ code e2411625673502 = 11207718695710 := by decide
theorem cert_e2411625673502 : check e2411625673502 [[],[]] .smaller = true := by decide
def e2411625673526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625673526 : Closed e2411625673526 ∧ code e2411625673526 = 11207718695734 := by decide
theorem cert_e2411625673526 : check e2411625673526 [[],[]] .smaller = true := by decide
def e2411625673530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625673530 : Closed e2411625673530 ∧ code e2411625673530 = 11207718695738 := by decide
theorem cert_e2411625673530 : check e2411625673530 [[],[]] .smaller = true := by decide
def e2411625673626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625673626 : Closed e2411625673626 ∧ code e2411625673626 = 11207718695834 := by decide
theorem cert_e2411625673626 : check e2411625673626 [[],[]] .smaller = true := by decide
def e2411625673670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411625673670 : Closed e2411625673670 ∧ code e2411625673670 = 11207718695878 := by decide
theorem cert_e2411625673670 : check e2411625673670 [[],[]] .smaller = true := by decide
def e2411625673694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 3))))))))
theorem wire_e2411625673694 : Closed e2411625673694 ∧ code e2411625673694 = 11207718695902 := by decide
theorem cert_e2411625673694 : check e2411625673694 [[],[]] .three = true := by decide
def e2411625673710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 2))))))))
theorem wire_e2411625673710 : Closed e2411625673710 ∧ code e2411625673710 = 11207718695918 := by decide
theorem cert_e2411625673710 : check e2411625673710 [[],[]] .three = true := by decide
def e2411625674870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2411625674870 : Closed e2411625674870 ∧ code e2411625674870 = 11207718697078 := by decide
theorem cert_e2411625674870 : check e2411625674870 [[],[]] .three = true := by decide
def e2411625675114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2411625675114 : Closed e2411625675114 ∧ code e2411625675114 = 11207718697322 := by decide
theorem cert_e2411625675114 : check e2411625675114 [[],[]] .three = true := by decide
def e2411625675150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411625675150 : Closed e2411625675150 ∧ code e2411625675150 = 11207718697358 := by decide
theorem cert_e2411625675150 : check e2411625675150 [[],[]] .three = true := by decide
def e2411625675162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625675162 : Closed e2411625675162 ∧ code e2411625675162 = 11207718697370 := by decide
theorem cert_e2411625675162 : check e2411625675162 [[],[]] .three = true := by decide
def e2411625675206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411625675206 : Closed e2411625675206 ∧ code e2411625675206 = 11207718697414 := by decide
theorem cert_e2411625675206 : check e2411625675206 [[],[]] .three = true := by decide
def e2411625675246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 2))))))))
theorem wire_e2411625675246 : Closed e2411625675246 ∧ code e2411625675246 = 11207718697454 := by decide
theorem cert_e2411625675246 : check e2411625675246 [[],[]] .three = true := by decide
def e2411625678710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e2411625678710 : Closed e2411625678710 ∧ code e2411625678710 = 11207718700918 := by decide
theorem cert_e2411625678710 : check e2411625678710 [[],[]] .smaller = true := by decide
def e2411625678774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e2411625678774 : Closed e2411625678774 ∧ code e2411625678774 = 11207718700982 := by decide
theorem cert_e2411625678774 : check e2411625678774 [[],[]] .smaller = true := by decide
def e2411625678778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e2411625678778 : Closed e2411625678778 ∧ code e2411625678778 = 11207718700986 := by decide
theorem cert_e2411625678778 : check e2411625678778 [[],[]] .smaller = true := by decide
def e2411625680094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625680094 : Closed e2411625680094 ∧ code e2411625680094 = 11207718702302 := by decide
theorem cert_e2411625680094 : check e2411625680094 [[],[]] .three = true := by decide
def e2411625680110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625680110 : Closed e2411625680110 ∧ code e2411625680110 = 11207718702318 := by decide
theorem cert_e2411625680110 : check e2411625680110 [[],[]] .smaller = true := by decide
def e2411625680118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625680118 : Closed e2411625680118 ∧ code e2411625680118 = 11207718702326 := by decide
theorem cert_e2411625680118 : check e2411625680118 [[],[]] .smaller = true := by decide
def e2411625680122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625680122 : Closed e2411625680122 ∧ code e2411625680122 = 11207718702330 := by decide
theorem cert_e2411625680122 : check e2411625680122 [[],[]] .three = true := by decide
def e2411625680494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625680494 : Closed e2411625680494 ∧ code e2411625680494 = 11207718702702 := by decide
theorem cert_e2411625680494 : check e2411625680494 [[],[]] .smaller = true := by decide
def e2411625680506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625680506 : Closed e2411625680506 ∧ code e2411625680506 = 11207718702714 := by decide
theorem cert_e2411625680506 : check e2411625680506 [[],[]] .smaller = true := by decide
def e2411625680694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625680694 : Closed e2411625680694 ∧ code e2411625680694 = 11207718702902 := by decide
theorem cert_e2411625680694 : check e2411625680694 [[],[]] .smaller = true := by decide
def e2411625680698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625680698 : Closed e2411625680698 ∧ code e2411625680698 = 11207718702906 := by decide
theorem cert_e2411625680698 : check e2411625680698 [[],[]] .smaller = true := by decide
def e2411625680794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625680794 : Closed e2411625680794 ∧ code e2411625680794 = 11207718703002 := by decide
theorem cert_e2411625680794 : check e2411625680794 [[],[]] .three = true := by decide
def e2411625682614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e2411625682614 : Closed e2411625682614 ∧ code e2411625682614 = 11207718704822 := by decide
theorem cert_e2411625682614 : check e2411625682614 [[],[]] .smaller = true := by decide
def e2411625682646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e2411625682646 : Closed e2411625682646 ∧ code e2411625682646 = 11207718704854 := by decide
theorem cert_e2411625682646 : check e2411625682646 [[],[]] .smaller = true := by decide
def e2411625682650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e2411625682650 : Closed e2411625682650 ∧ code e2411625682650 = 11207718704858 := by decide
theorem cert_e2411625682650 : check e2411625682650 [[],[]] .smaller = true := by decide
def e2411625682774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2411625682774 : Closed e2411625682774 ∧ code e2411625682774 = 11207718704982 := by decide
theorem cert_e2411625682774 : check e2411625682774 [[],[]] .smaller = true := by decide
def e2411625682778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2411625682778 : Closed e2411625682778 ∧ code e2411625682778 = 11207718704986 := by decide
theorem cert_e2411625682778 : check e2411625682778 [[],[]] .smaller = true := by decide
def e2411625682794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2411625682794 : Closed e2411625682794 ∧ code e2411625682794 = 11207718705002 := by decide
theorem cert_e2411625682794 : check e2411625682794 [[],[]] .smaller = true := by decide
def e2411625683166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2411625683166 : Closed e2411625683166 ∧ code e2411625683166 = 11207718705374 := by decide
theorem cert_e2411625683166 : check e2411625683166 [[],[]] .three = true := by decide
def e2411625683182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2411625683182 : Closed e2411625683182 ∧ code e2411625683182 = 11207718705390 := by decide
theorem cert_e2411625683182 : check e2411625683182 [[],[]] .smaller = true := by decide
def e2411625683190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2411625683190 : Closed e2411625683190 ∧ code e2411625683190 = 11207718705398 := by decide
theorem cert_e2411625683190 : check e2411625683190 [[],[]] .smaller = true := by decide
def e2411625683194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2411625683194 : Closed e2411625683194 ∧ code e2411625683194 = 11207718705402 := by decide
theorem cert_e2411625683194 : check e2411625683194 [[],[]] .three = true := by decide
def e2411625683382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2411625683382 : Closed e2411625683382 ∧ code e2411625683382 = 11207718705590 := by decide
theorem cert_e2411625683382 : check e2411625683382 [[],[]] .smaller = true := by decide
def e2411625683414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2411625683414 : Closed e2411625683414 ∧ code e2411625683414 = 11207718705622 := by decide
theorem cert_e2411625683414 : check e2411625683414 [[],[]] .smaller = true := by decide
def e2411625683418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e2411625683418 : Closed e2411625683418 ∧ code e2411625683418 = 11207718705626 := by decide
theorem cert_e2411625683418 : check e2411625683418 [[],[]] .smaller = true := by decide
def e2411625683518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2411625683518 : Closed e2411625683518 ∧ code e2411625683518 = 11207718705726 := by decide
theorem cert_e2411625683518 : check e2411625683518 [[],[]] .three = true := by decide
def e2411625683574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e2411625683574 : Closed e2411625683574 ∧ code e2411625683574 = 11207718705782 := by decide
theorem cert_e2411625683574 : check e2411625683574 [[],[]] .smaller = true := by decide
def e2411625683742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2411625683742 : Closed e2411625683742 ∧ code e2411625683742 = 11207718705950 := by decide
theorem cert_e2411625683742 : check e2411625683742 [[],[]] .smaller = true := by decide
def e2411625683766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625683766 : Closed e2411625683766 ∧ code e2411625683766 = 11207718705974 := by decide
theorem cert_e2411625683766 : check e2411625683766 [[],[]] .smaller = true := by decide
def e2411625683770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625683770 : Closed e2411625683770 ∧ code e2411625683770 = 11207718705978 := by decide
theorem cert_e2411625683770 : check e2411625683770 [[],[]] .smaller = true := by decide
def e2411625683854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2411625683854 : Closed e2411625683854 ∧ code e2411625683854 = 11207718706062 := by decide
theorem cert_e2411625683854 : check e2411625683854 [[],[]] .smaller = true := by decide
def e2411625683910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2411625683910 : Closed e2411625683910 ∧ code e2411625683910 = 11207718706118 := by decide
theorem cert_e2411625683910 : check e2411625683910 [[],[]] .three = true := by decide
def e2411625683934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 3)))))))
theorem wire_e2411625683934 : Closed e2411625683934 ∧ code e2411625683934 = 11207718706142 := by decide
theorem cert_e2411625683934 : check e2411625683934 [[],[]] .three = true := by decide
def e2411625684078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411625684078 : Closed e2411625684078 ∧ code e2411625684078 = 11207718706286 := by decide
theorem cert_e2411625684078 : check e2411625684078 [[],[]] .smaller = true := by decide
def e2411625684090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411625684090 : Closed e2411625684090 ∧ code e2411625684090 = 11207718706298 := by decide
theorem cert_e2411625684090 : check e2411625684090 [[],[]] .smaller = true := by decide
def e2411625684182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2411625684182 : Closed e2411625684182 ∧ code e2411625684182 = 11207718706390 := by decide
theorem cert_e2411625684182 : check e2411625684182 [[],[]] .smaller = true := by decide
def e2411625684186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2411625684186 : Closed e2411625684186 ∧ code e2411625684186 = 11207718706394 := by decide
theorem cert_e2411625684186 : check e2411625684186 [[],[]] .smaller = true := by decide
def e2411625684202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2411625684202 : Closed e2411625684202 ∧ code e2411625684202 = 11207718706410 := by decide
theorem cert_e2411625684202 : check e2411625684202 [[],[]] .smaller = true := by decide
def e2411625684254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411625684254 : Closed e2411625684254 ∧ code e2411625684254 = 11207718706462 := by decide
theorem cert_e2411625684254 : check e2411625684254 [[],[]] .smaller = true := by decide
def e2411625684278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625684278 : Closed e2411625684278 ∧ code e2411625684278 = 11207718706486 := by decide
theorem cert_e2411625684278 : check e2411625684278 [[],[]] .smaller = true := by decide
def e2411625684282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625684282 : Closed e2411625684282 ∧ code e2411625684282 = 11207718706490 := by decide
theorem cert_e2411625684282 : check e2411625684282 [[],[]] .smaller = true := by decide
def e2411625684378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625684378 : Closed e2411625684378 ∧ code e2411625684378 = 11207718706586 := by decide
theorem cert_e2411625684378 : check e2411625684378 [[],[]] .smaller = true := by decide
def e2411625684422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411625684422 : Closed e2411625684422 ∧ code e2411625684422 = 11207718706630 := by decide
theorem cert_e2411625684422 : check e2411625684422 [[],[]] .smaller = true := by decide
def e2411625684446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e2411625684446 : Closed e2411625684446 ∧ code e2411625684446 = 11207718706654 := by decide
theorem cert_e2411625684446 : check e2411625684446 [[],[]] .three = true := by decide
def e2411625684462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e2411625684462 : Closed e2411625684462 ∧ code e2411625684462 = 11207718706670 := by decide
theorem cert_e2411625684462 : check e2411625684462 [[],[]] .three = true := by decide
def e2411625684534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411625684534 : Closed e2411625684534 ∧ code e2411625684534 = 11207718706742 := by decide
theorem cert_e2411625684534 : check e2411625684534 [[],[]] .smaller = true := by decide
def e2411625684538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411625684538 : Closed e2411625684538 ∧ code e2411625684538 = 11207718706746 := by decide
theorem cert_e2411625684538 : check e2411625684538 [[],[]] .smaller = true := by decide
def e2411625684622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411625684622 : Closed e2411625684622 ∧ code e2411625684622 = 11207718706830 := by decide
theorem cert_e2411625684622 : check e2411625684622 [[],[]] .smaller = true := by decide
def e2411625684678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411625684678 : Closed e2411625684678 ∧ code e2411625684678 = 11207718706886 := by decide
theorem cert_e2411625684678 : check e2411625684678 [[],[]] .smaller = true := by decide
def e2411625684702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e2411625684702 : Closed e2411625684702 ∧ code e2411625684702 = 11207718706910 := by decide
theorem cert_e2411625684702 : check e2411625684702 [[],[]] .three = true := by decide
def e2411625684726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e2411625684726 : Closed e2411625684726 ∧ code e2411625684726 = 11207718706934 := by decide
theorem cert_e2411625684726 : check e2411625684726 [[],[]] .three = true := by decide
def e2411625684762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411625684762 : Closed e2411625684762 ∧ code e2411625684762 = 11207718706970 := by decide
theorem cert_e2411625684762 : check e2411625684762 [[],[]] .three = true := by decide
def e2411625684806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411625684806 : Closed e2411625684806 ∧ code e2411625684806 = 11207718707014 := by decide
theorem cert_e2411625684806 : check e2411625684806 [[],[]] .three = true := by decide
def e2411625684830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 3)))))))
theorem wire_e2411625684830 : Closed e2411625684830 ∧ code e2411625684830 = 11207718707038 := by decide
theorem cert_e2411625684830 : check e2411625684830 [[],[]] .three = true := by decide
def e2411625684846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e2411625684846 : Closed e2411625684846 ∧ code e2411625684846 = 11207718707054 := by decide
theorem cert_e2411625684846 : check e2411625684846 [[],[]] .three = true := by decide
def e2411625684854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e2411625684854 : Closed e2411625684854 ∧ code e2411625684854 = 11207718707062 := by decide
theorem cert_e2411625684854 : check e2411625684854 [[],[]] .three = true := by decide
def e2411625684858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 3))) (.var 0)))))))
theorem wire_e2411625684858 : Closed e2411625684858 ∧ code e2411625684858 = 11207718707066 := by decide
theorem cert_e2411625684858 : check e2411625684858 [[],[]] .three = true := by decide
def e2411625685486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e2411625685486 : Closed e2411625685486 ∧ code e2411625685486 = 11207718707694 := by decide
theorem cert_e2411625685486 : check e2411625685486 [[],[]] .smaller = true := by decide
def e2411625686454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2411625686454 : Closed e2411625686454 ∧ code e2411625686454 = 11207718708662 := by decide
theorem cert_e2411625686454 : check e2411625686454 [[],[]] .smaller = true := by decide
def e2411625686486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2411625686486 : Closed e2411625686486 ∧ code e2411625686486 = 11207718708694 := by decide
theorem cert_e2411625686486 : check e2411625686486 [[],[]] .smaller = true := by decide
def e2411625686490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2411625686490 : Closed e2411625686490 ∧ code e2411625686490 = 11207718708698 := by decide
theorem cert_e2411625686490 : check e2411625686490 [[],[]] .smaller = true := by decide
def e2411625686590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2411625686590 : Closed e2411625686590 ∧ code e2411625686590 = 11207718708798 := by decide
theorem cert_e2411625686590 : check e2411625686590 [[],[]] .three = true := by decide
def e2411625686646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411625686646 : Closed e2411625686646 ∧ code e2411625686646 = 11207718708854 := by decide
theorem cert_e2411625686646 : check e2411625686646 [[],[]] .smaller = true := by decide
def e2411625686814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411625686814 : Closed e2411625686814 ∧ code e2411625686814 = 11207718709022 := by decide
theorem cert_e2411625686814 : check e2411625686814 [[],[]] .smaller = true := by decide
def e2411625686838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625686838 : Closed e2411625686838 ∧ code e2411625686838 = 11207718709046 := by decide
theorem cert_e2411625686838 : check e2411625686838 [[],[]] .smaller = true := by decide
def e2411625686842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625686842 : Closed e2411625686842 ∧ code e2411625686842 = 11207718709050 := by decide
theorem cert_e2411625686842 : check e2411625686842 [[],[]] .smaller = true := by decide
def e2411625686926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411625686926 : Closed e2411625686926 ∧ code e2411625686926 = 11207718709134 := by decide
theorem cert_e2411625686926 : check e2411625686926 [[],[]] .smaller = true := by decide
def e2411625686982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2411625686982 : Closed e2411625686982 ∧ code e2411625686982 = 11207718709190 := by decide
theorem cert_e2411625686982 : check e2411625686982 [[],[]] .three = true := by decide
def e2411625687006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 3))))))))
theorem wire_e2411625687006 : Closed e2411625687006 ∧ code e2411625687006 = 11207718709214 := by decide
theorem cert_e2411625687006 : check e2411625687006 [[],[]] .three = true := by decide
def e2411625689326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2411625689326 : Closed e2411625689326 ∧ code e2411625689326 = 11207718711534 := by decide
theorem cert_e2411625689326 : check e2411625689326 [[],[]] .smaller = true := by decide
def e2411625689334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2411625689334 : Closed e2411625689334 ∧ code e2411625689334 = 11207718711542 := by decide
theorem cert_e2411625689334 : check e2411625689334 [[],[]] .smaller = true := by decide
def e2411625689814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2411625689814 : Closed e2411625689814 ∧ code e2411625689814 = 11207718712022 := by decide
theorem cert_e2411625689814 : check e2411625689814 [[],[]] .smaller = true := by decide
def e2411625689818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2411625689818 : Closed e2411625689818 ∧ code e2411625689818 = 11207718712026 := by decide
theorem cert_e2411625689818 : check e2411625689818 [[],[]] .smaller = true := by decide
def e2411625689834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2411625689834 : Closed e2411625689834 ∧ code e2411625689834 = 11207718712042 := by decide
theorem cert_e2411625689834 : check e2411625689834 [[],[]] .smaller = true := by decide
def e2411625689886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411625689886 : Closed e2411625689886 ∧ code e2411625689886 = 11207718712094 := by decide
theorem cert_e2411625689886 : check e2411625689886 [[],[]] .smaller = true := by decide
def e2411625689910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625689910 : Closed e2411625689910 ∧ code e2411625689910 = 11207718712118 := by decide
theorem cert_e2411625689910 : check e2411625689910 [[],[]] .smaller = true := by decide
def e2411625689914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625689914 : Closed e2411625689914 ∧ code e2411625689914 = 11207718712122 := by decide
theorem cert_e2411625689914 : check e2411625689914 [[],[]] .smaller = true := by decide
def e2411625690010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625690010 : Closed e2411625690010 ∧ code e2411625690010 = 11207718712218 := by decide
theorem cert_e2411625690010 : check e2411625690010 [[],[]] .smaller = true := by decide
end Blc.Floor43
