import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e601538303770 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601538303770 : Closed e601538303770 ∧ code e601538303770 = 9397631325978 := by decide
theorem cert_e601538303770 : check e601538303770 [[.under]] .width = true := by decide
def e601538303814 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601538303814 : Closed e601538303814 ∧ code e601538303814 = 9397631326022 := by decide
theorem cert_e601538303814 : check e601538303814 [[.under]] .width = true := by decide
def e601538304398 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601538304398 : Closed e601538304398 ∧ code e601538304398 = 9397631326606 := by decide
theorem cert_e601538304398 : check e601538304398 [[.under]] .width = true := by decide
def e601538304454 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601538304454 : Closed e601538304454 ∧ code e601538304454 = 9397631326662 := by decide
theorem cert_e601538304454 : check e601538304454 [[.under]] .width = true := by decide
def e601538305222 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601538305222 : Closed e601538305222 ∧ code e601538305222 = 9397631327430 := by decide
theorem cert_e601538305222 : check e601538305222 [[.under]] .width = true := by decide
def e601538320490 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601538320490 : Closed e601538320490 ∧ code e601538320490 = 9397631342698 := by decide
theorem cert_e601538320490 : check e601538320490 [[.under]] .width = true := by decide
def e601538320922 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601538320922 : Closed e601538320922 ∧ code e601538320922 = 9397631343130 := by decide
theorem cert_e601538320922 : check e601538320922 [[.under]] .width = true := by decide
def e601538322458 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601538322458 : Closed e601538322458 ∧ code e601538322458 = 9397631344666 := by decide
theorem cert_e601538322458 : check e601538322458 [[.under]] .width = true := by decide
def e601538322550 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601538322550 : Closed e601538322550 ∧ code e601538322550 = 9397631344758 := by decide
theorem cert_e601538322550 : check e601538322550 [[.under]] .width = true := by decide
def e601538322794 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601538322794 : Closed e601538322794 ∧ code e601538322794 = 9397631345002 := by decide
theorem cert_e601538322794 : check e601538322794 [[.under]] .width = true := by decide
def e601538322842 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601538322842 : Closed e601538322842 ∧ code e601538322842 = 9397631345050 := by decide
theorem cert_e601538322842 : check e601538322842 [[.under]] .width = true := by decide
def e601538323994 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601538323994 : Closed e601538323994 ∧ code e601538323994 = 9397631346202 := by decide
theorem cert_e601538323994 : check e601538323994 [[.under]] .width = true := by decide
def e601548056090 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601548056090 : Closed e601548056090 ∧ code e601548056090 = 9397641078298 := by decide
theorem cert_e601548056090 : check e601548056090 [[.under]] .width = true := by decide
def e601548088858 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601548088858 : Closed e601548088858 ∧ code e601548088858 = 9397641111066 := by decide
theorem cert_e601548088858 : check e601548088858 [[.under]] .width = true := by decide
def e601550054938 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550054938 : Closed e601550054938 ∧ code e601550054938 = 9397643077146 := by decide
theorem cert_e601550054938 : check e601550054938 [[.under]] .width = true := by decide
def e601550071322 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550071322 : Closed e601550071322 ∧ code e601550071322 = 9397643093530 := by decide
theorem cert_e601550071322 : check e601550071322 [[.under]] .width = true := by decide
def e601550136858 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550136858 : Closed e601550136858 ∧ code e601550136858 = 9397643159066 := by decide
theorem cert_e601550136858 : check e601550136858 [[.under]] .width = true := by decide
def e601550340822 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601550340822 : Closed e601550340822 ∧ code e601550340822 = 9397643363030 := by decide
theorem cert_e601550340822 : check e601550340822 [[.under]] .width = true := by decide
def e601550340826 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601550340826 : Closed e601550340826 ∧ code e601550340826 = 9397643363034 := by decide
theorem cert_e601550340826 : check e601550340826 [[.under]] .width = true := by decide
def e601550340842 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601550340842 : Closed e601550340842 ∧ code e601550340842 = 9397643363050 := by decide
theorem cert_e601550340842 : check e601550340842 [[.under]] .width = true := by decide
def e601550340918 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601550340918 : Closed e601550340918 ∧ code e601550340918 = 9397643363126 := by decide
theorem cert_e601550340918 : check e601550340918 [[.under]] .width = true := by decide
def e601550340922 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601550340922 : Closed e601550340922 ∧ code e601550340922 = 9397643363130 := by decide
theorem cert_e601550340922 : check e601550340922 [[.under]] .width = true := by decide
def e601550341018 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601550341018 : Closed e601550341018 ∧ code e601550341018 = 9397643363226 := by decide
theorem cert_e601550341018 : check e601550341018 [[.under]] .width = true := by decide
def e601550448154 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550448154 : Closed e601550448154 ∧ code e601550448154 = 9397643470362 := by decide
theorem cert_e601550448154 : check e601550448154 [[.under]] .width = true := by decide
def e601550464538 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550464538 : Closed e601550464538 ∧ code e601550464538 = 9397643486746 := by decide
theorem cert_e601550464538 : check e601550464538 [[.under]] .width = true := by decide
def e601550620078 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601550620078 : Closed e601550620078 ∧ code e601550620078 = 9397643642286 := by decide
theorem cert_e601550620078 : check e601550620078 [[.under]] .width = true := by decide
def e601550620090 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601550620090 : Closed e601550620090 ∧ code e601550620090 = 9397643642298 := by decide
theorem cert_e601550620090 : check e601550620090 [[.under]] .width = true := by decide
def e601550620138 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601550620138 : Closed e601550620138 ∧ code e601550620138 = 9397643642346 := by decide
theorem cert_e601550620138 : check e601550620138 [[.under]] .width = true := by decide
def e601550620270 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601550620270 : Closed e601550620270 ∧ code e601550620270 = 9397643642478 := by decide
theorem cert_e601550620270 : check e601550620270 [[.under]] .width = true := by decide
def e601550620282 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601550620282 : Closed e601550620282 ∧ code e601550620282 = 9397643642490 := by decide
theorem cert_e601550620282 : check e601550620282 [[.under]] .width = true := by decide
def e601550620570 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601550620570 : Closed e601550620570 ∧ code e601550620570 = 9397643642778 := by decide
theorem cert_e601550620570 : check e601550620570 [[.under]] .width = true := by decide
def e601550624310 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601550624310 : Closed e601550624310 ∧ code e601550624310 = 9397643646518 := by decide
theorem cert_e601550624310 : check e601550624310 [[.under]] .width = true := by decide
def e601550624314 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601550624314 : Closed e601550624314 ∧ code e601550624314 = 9397643646522 := by decide
theorem cert_e601550624314 : check e601550624314 [[.under]] .width = true := by decide
def e601550624398 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601550624398 : Closed e601550624398 ∧ code e601550624398 = 9397643646606 := by decide
theorem cert_e601550624398 : check e601550624398 [[.under]] .width = true := by decide
def e601550624454 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601550624454 : Closed e601550624454 ∧ code e601550624454 = 9397643646662 := by decide
theorem cert_e601550624454 : check e601550624454 [[.under]] .width = true := by decide
def e601550624538 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601550624538 : Closed e601550624538 ∧ code e601550624538 = 9397643646746 := by decide
theorem cert_e601550624538 : check e601550624538 [[.under]] .width = true := by decide
def e601550624582 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601550624582 : Closed e601550624582 ∧ code e601550624582 = 9397643646790 := by decide
theorem cert_e601550624582 : check e601550624582 [[.under]] .width = true := by decide
def e601550625166 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601550625166 : Closed e601550625166 ∧ code e601550625166 = 9397643647374 := by decide
theorem cert_e601550625166 : check e601550625166 [[.under]] .width = true := by decide
def e601550625222 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601550625222 : Closed e601550625222 ∧ code e601550625222 = 9397643647430 := by decide
theorem cert_e601550625222 : check e601550625222 [[.under]] .width = true := by decide
def e601550625990 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601550625990 : Closed e601550625990 ∧ code e601550625990 = 9397643648198 := by decide
theorem cert_e601550625990 : check e601550625990 [[.under]] .width = true := by decide
def e601550641258 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601550641258 : Closed e601550641258 ∧ code e601550641258 = 9397643663466 := by decide
theorem cert_e601550641258 : check e601550641258 [[.under]] .width = true := by decide
def e601550641690 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550641690 : Closed e601550641690 ∧ code e601550641690 = 9397643663898 := by decide
theorem cert_e601550641690 : check e601550641690 [[.under]] .width = true := by decide
def e601550643226 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601550643226 : Closed e601550643226 ∧ code e601550643226 = 9397643665434 := by decide
theorem cert_e601550643226 : check e601550643226 [[.under]] .width = true := by decide
def e601550643318 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601550643318 : Closed e601550643318 ∧ code e601550643318 = 9397643665526 := by decide
theorem cert_e601550643318 : check e601550643318 [[.under]] .width = true := by decide
def e601550643562 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601550643562 : Closed e601550643562 ∧ code e601550643562 = 9397643665770 := by decide
theorem cert_e601550643562 : check e601550643562 [[.under]] .width = true := by decide
def e601550643610 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601550643610 : Closed e601550643610 ∧ code e601550643610 = 9397643665818 := by decide
theorem cert_e601550643610 : check e601550643610 [[.under]] .width = true := by decide
def e601550644762 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601550644762 : Closed e601550644762 ∧ code e601550644762 = 9397643666970 := by decide
theorem cert_e601550644762 : check e601550644762 [[.under]] .width = true := by decide
def e601550799574 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601550799574 : Closed e601550799574 ∧ code e601550799574 = 9397643821782 := by decide
theorem cert_e601550799574 : check e601550799574 [[.under]] .width = true := by decide
def e601550799578 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601550799578 : Closed e601550799578 ∧ code e601550799578 = 9397643821786 := by decide
theorem cert_e601550799578 : check e601550799578 [[.under]] .width = true := by decide
def e601550799594 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601550799594 : Closed e601550799594 ∧ code e601550799594 = 9397643821802 := by decide
theorem cert_e601550799594 : check e601550799594 [[.under]] .width = true := by decide
def e601550799670 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601550799670 : Closed e601550799670 ∧ code e601550799670 = 9397643821878 := by decide
theorem cert_e601550799670 : check e601550799670 [[.under]] .width = true := by decide
def e601550799674 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601550799674 : Closed e601550799674 ∧ code e601550799674 = 9397643821882 := by decide
theorem cert_e601550799674 : check e601550799674 [[.under]] .width = true := by decide
def e601550799770 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601550799770 : Closed e601550799770 ∧ code e601550799770 = 9397643821978 := by decide
theorem cert_e601550799770 : check e601550799770 [[.under]] .width = true := by decide
def e601550857754 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550857754 : Closed e601550857754 ∧ code e601550857754 = 9397643879962 := by decide
theorem cert_e601550857754 : check e601550857754 [[.under]] .width = true := by decide
def e601550882222 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601550882222 : Closed e601550882222 ∧ code e601550882222 = 9397643904430 := by decide
theorem cert_e601550882222 : check e601550882222 [[.under]] .width = true := by decide
def e601550882234 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601550882234 : Closed e601550882234 ∧ code e601550882234 = 9397643904442 := by decide
theorem cert_e601550882234 : check e601550882234 [[.under]] .width = true := by decide
def e601550882282 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601550882282 : Closed e601550882282 ∧ code e601550882282 = 9397643904490 := by decide
theorem cert_e601550882282 : check e601550882282 [[.under]] .width = true := by decide
def e601550882414 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601550882414 : Closed e601550882414 ∧ code e601550882414 = 9397643904622 := by decide
theorem cert_e601550882414 : check e601550882414 [[.under]] .width = true := by decide
def e601550882426 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601550882426 : Closed e601550882426 ∧ code e601550882426 = 9397643904634 := by decide
theorem cert_e601550882426 : check e601550882426 [[.under]] .width = true := by decide
def e601550882714 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601550882714 : Closed e601550882714 ∧ code e601550882714 = 9397643904922 := by decide
theorem cert_e601550882714 : check e601550882714 [[.under]] .width = true := by decide
def e601550886454 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601550886454 : Closed e601550886454 ∧ code e601550886454 = 9397643908662 := by decide
theorem cert_e601550886454 : check e601550886454 [[.under]] .width = true := by decide
def e601550886458 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601550886458 : Closed e601550886458 ∧ code e601550886458 = 9397643908666 := by decide
theorem cert_e601550886458 : check e601550886458 [[.under]] .width = true := by decide
def e601550886542 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601550886542 : Closed e601550886542 ∧ code e601550886542 = 9397643908750 := by decide
theorem cert_e601550886542 : check e601550886542 [[.under]] .width = true := by decide
def e601550886598 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601550886598 : Closed e601550886598 ∧ code e601550886598 = 9397643908806 := by decide
theorem cert_e601550886598 : check e601550886598 [[.under]] .width = true := by decide
def e601550886682 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601550886682 : Closed e601550886682 ∧ code e601550886682 = 9397643908890 := by decide
theorem cert_e601550886682 : check e601550886682 [[.under]] .width = true := by decide
def e601550886726 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601550886726 : Closed e601550886726 ∧ code e601550886726 = 9397643908934 := by decide
theorem cert_e601550886726 : check e601550886726 [[.under]] .width = true := by decide
def e601550887310 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601550887310 : Closed e601550887310 ∧ code e601550887310 = 9397643909518 := by decide
theorem cert_e601550887310 : check e601550887310 [[.under]] .width = true := by decide
def e601550887366 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601550887366 : Closed e601550887366 ∧ code e601550887366 = 9397643909574 := by decide
theorem cert_e601550887366 : check e601550887366 [[.under]] .width = true := by decide
def e601550888134 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601550888134 : Closed e601550888134 ∧ code e601550888134 = 9397643910342 := by decide
theorem cert_e601550888134 : check e601550888134 [[.under]] .width = true := by decide
def e601550903402 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601550903402 : Closed e601550903402 ∧ code e601550903402 = 9397643925610 := by decide
theorem cert_e601550903402 : check e601550903402 [[.under]] .width = true := by decide
def e601550903834 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601550903834 : Closed e601550903834 ∧ code e601550903834 = 9397643926042 := by decide
theorem cert_e601550903834 : check e601550903834 [[.under]] .width = true := by decide
def e601550905370 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601550905370 : Closed e601550905370 ∧ code e601550905370 = 9397643927578 := by decide
theorem cert_e601550905370 : check e601550905370 [[.under]] .width = true := by decide
def e601550905462 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601550905462 : Closed e601550905462 ∧ code e601550905462 = 9397643927670 := by decide
theorem cert_e601550905462 : check e601550905462 [[.under]] .width = true := by decide
def e601550905706 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601550905706 : Closed e601550905706 ∧ code e601550905706 = 9397643927914 := by decide
theorem cert_e601550905706 : check e601550905706 [[.under]] .width = true := by decide
def e601550905754 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601550905754 : Closed e601550905754 ∧ code e601550905754 = 9397643927962 := by decide
theorem cert_e601550905754 : check e601550905754 [[.under]] .width = true := by decide
def e601550906906 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601550906906 : Closed e601550906906 ∧ code e601550906906 = 9397643929114 := by decide
theorem cert_e601550906906 : check e601550906906 [[.under]] .width = true := by decide
def e602112714266 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602112714266 : Closed e602112714266 ∧ code e602112714266 = 9398205736474 := by decide
theorem cert_e602112714266 : check e602112714266 [[.under]] .width = true := by decide
def e602112747034 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602112747034 : Closed e602112747034 ∧ code e602112747034 = 9398205769242 := by decide
theorem cert_e602112747034 : check e602112747034 [[.under]] .width = true := by decide
def e602112976410 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602112976410 : Closed e602112976410 ∧ code e602112976410 = 9398205998618 := by decide
theorem cert_e602112976410 : check e602112976410 [[.under]] .width = true := by decide
def e602113025562 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602113025562 : Closed e602113025562 ∧ code e602113025562 = 9398206047770 := by decide
theorem cert_e602113025562 : check e602113025562 [[.under]] .width = true := by decide
def e602113140250 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602113140250 : Closed e602113140250 ∧ code e602113140250 = 9398206162458 := by decide
theorem cert_e602113140250 : check e602113140250 [[.under]] .width = true := by decide
def e602113156634 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602113156634 : Closed e602113156634 ∧ code e602113156634 = 9398206178842 := by decide
theorem cert_e602113156634 : check e602113156634 [[.under]] .width = true := by decide
def e602114287130 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602114287130 : Closed e602114287130 ∧ code e602114287130 = 9398207309338 := by decide
theorem cert_e602114287130 : check e602114287130 [[.under]] .width = true := by decide
def e602114319898 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602114319898 : Closed e602114319898 ∧ code e602114319898 = 9398207342106 := by decide
theorem cert_e602114319898 : check e602114319898 [[.under]] .width = true := by decide
def e602115859994 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602115859994 : Closed e602115859994 ∧ code e602115859994 = 9398208882202 := by decide
theorem cert_e602115859994 : check e602115859994 [[.under]] .width = true := by decide
def e602115909146 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602115909146 : Closed e602115909146 ∧ code e602115909146 = 9398208931354 := by decide
theorem cert_e602115909146 : check e602115909146 [[.under]] .width = true := by decide
def e602116679194 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602116679194 : Closed e602116679194 ∧ code e602116679194 = 9398209701402 := by decide
theorem cert_e602116679194 : check e602116679194 [[.under]] .width = true := by decide
def e602116695578 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e602116695578 : Closed e602116695578 ∧ code e602116695578 = 9398209717786 := by decide
theorem cert_e602116695578 : check e602116695578 [[.under]] .width = true := by decide
def e602929126262 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))))
theorem wire_e602929126262 : Closed e602929126262 ∧ code e602929126262 = 9399022148470 := by decide
theorem cert_e602929126262 : check e602929126262 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929126326 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))))
theorem wire_e602929126326 : Closed e602929126326 ∧ code e602929126326 = 9399022148534 := by decide
theorem cert_e602929126326 : check e602929126326 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929126774 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))))
theorem wire_e602929126774 : Closed e602929126774 ∧ code e602929126774 = 9399022148982 := by decide
theorem cert_e602929126774 : check e602929126774 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929126870 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))))
theorem wire_e602929126870 : Closed e602929126870 ∧ code e602929126870 = 9399022149078 := by decide
theorem cert_e602929126870 : check e602929126870 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929127094 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e602929127094 : Closed e602929127094 ∧ code e602929127094 = 9399022149302 := by decide
theorem cert_e602929127094 : check e602929127094 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929127126 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e602929127126 : Closed e602929127126 ∧ code e602929127126 = 9399022149334 := by decide
theorem cert_e602929127126 : check e602929127126 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929129334 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))))
theorem wire_e602929129334 : Closed e602929129334 ∧ code e602929129334 = 9399022151542 := by decide
theorem cert_e602929129334 : check e602929129334 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929129398 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))))
theorem wire_e602929129398 : Closed e602929129398 ∧ code e602929129398 = 9399022151606 := by decide
theorem cert_e602929129398 : check e602929129398 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929132406 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))))
theorem wire_e602929132406 : Closed e602929132406 ∧ code e602929132406 = 9399022154614 := by decide
theorem cert_e602929132406 : check e602929132406 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929132502 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))))
theorem wire_e602929132502 : Closed e602929132502 ∧ code e602929132502 = 9399022154710 := by decide
theorem cert_e602929132502 : check e602929132502 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929134006 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e602929134006 : Closed e602929134006 ∧ code e602929134006 = 9399022156214 := by decide
theorem cert_e602929134006 : check e602929134006 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929134038 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e602929134038 : Closed e602929134038 ∧ code e602929134038 = 9399022156246 := by decide
theorem cert_e602929134038 : check e602929134038 [[.under],[.under],[.under,.left]] .smaller = true := by decide
def e602929892206 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602929892206 : Closed e602929892206 ∧ code e602929892206 = 9399022914414 := by decide
def e602929892214 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602929892214 : Closed e602929892214 ∧ code e602929892214 = 9399022914422 := by decide
theorem cert_e602929892214 : check e602929892214 [[.under],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e602929892270 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602929892270 : Closed e602929892270 ∧ code e602929892270 = 9399022914478 := by decide
theorem cert_e602929892270 : check e602929892270 [[.under],[.under],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e602929892282 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602929892282 : Closed e602929892282 ∧ code e602929892282 = 9399022914490 := by decide
theorem cert_e602929892282 : check e602929892282 [[.under],[.under],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e602929892310 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602929892310 : Closed e602929892310 ∧ code e602929892310 = 9399022914518 := by decide
theorem cert_e602929892310 : check e602929892310 [[.under],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e602929892314 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602929892314 : Closed e602929892314 ∧ code e602929892314 = 9399022914522 := by decide
def e602929892590 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602929892590 : Closed e602929892590 ∧ code e602929892590 = 9399022914798 := by decide
theorem cert_e602929892590 : check e602929892590 [[.left],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e602929892598 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602929892598 : Closed e602929892598 ∧ code e602929892598 = 9399022914806 := by decide
theorem cert_e602929892598 : check e602929892598 [[.left],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e602929892974 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602929892974 : Closed e602929892974 ∧ code e602929892974 = 9399022915182 := by decide
theorem cert_e602929892974 : check e602929892974 [[.under],[.under],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e602929892986 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602929892986 : Closed e602929892986 ∧ code e602929892986 = 9399022915194 := by decide
theorem cert_e602929892986 : check e602929892986 [[.under],[.under],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e602929893174 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602929893174 : Closed e602929893174 ∧ code e602929893174 = 9399022915382 := by decide
theorem cert_e602929893174 : check e602929893174 [[.under],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e602929893178 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602929893178 : Closed e602929893178 ∧ code e602929893178 = 9399022915386 := by decide
theorem cert_e602929893178 : check e602929893178 [[.under],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e602930163130 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e602930163130 : Closed e602930163130 ∧ code e602930163130 = 9399023185338 := by decide
theorem cert_e602930163130 : check e602930163130 [[.under],[.under]] .sourceHead = true := by decide
def e602930163162 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e602930163162 : Closed e602930163162 ∧ code e602930163162 = 9399023185370 := by decide
theorem cert_e602930163162 : check e602930163162 [[.under],[.under]] .sourceHead = true := by decide
def e602930163386 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e602930163386 : Closed e602930163386 ∧ code e602930163386 = 9399023185594 := by decide
theorem cert_e602930163386 : check e602930163386 [[.under],[.under]] .sourceHead = true := by decide
def e602930163434 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e602930163434 : Closed e602930163434 ∧ code e602930163434 = 9399023185642 := by decide
theorem cert_e602930163434 : check e602930163434 [[.under],[.under]] .sourceHead = true := by decide
def e602930163546 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e602930163546 : Closed e602930163546 ∧ code e602930163546 = 9399023185754 := by decide
theorem cert_e602930163546 : check e602930163546 [[.under],[.under]] .sourceHead = true := by decide
def e602930163562 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e602930163562 : Closed e602930163562 ∧ code e602930163562 = 9399023185770 := by decide
theorem cert_e602930163562 : check e602930163562 [[.under],[.under]] .sourceHead = true := by decide
def e602930164666 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e602930164666 : Closed e602930164666 ∧ code e602930164666 = 9399023186874 := by decide
theorem cert_e602930164666 : check e602930164666 [[.under],[.under]] .sourceHead = true := by decide
def e602930164698 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e602930164698 : Closed e602930164698 ∧ code e602930164698 = 9399023186906 := by decide
theorem cert_e602930164698 : check e602930164698 [[.under],[.under]] .sourceHead = true := by decide
def e602930166202 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e602930166202 : Closed e602930166202 ∧ code e602930166202 = 9399023188410 := by decide
theorem cert_e602930166202 : check e602930166202 [[.under],[.under]] .sourceHead = true := by decide
def e602930166250 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e602930166250 : Closed e602930166250 ∧ code e602930166250 = 9399023188458 := by decide
theorem cert_e602930166250 : check e602930166250 [[.under],[.under]] .sourceHead = true := by decide
def e602930167002 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e602930167002 : Closed e602930167002 ∧ code e602930167002 = 9399023189210 := by decide
theorem cert_e602930167002 : check e602930167002 [[.under],[.under]] .sourceHead = true := by decide
def e602930167018 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e602930167018 : Closed e602930167018 ∧ code e602930167018 = 9399023189226 := by decide
theorem cert_e602930167018 : check e602930167018 [[.under],[.under]] .sourceHead = true := by decide
def e602930416494 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e602930416494 : Closed e602930416494 ∧ code e602930416494 = 9399023438702 := by decide
theorem cert_e602930416494 : check e602930416494 [[.under],[.under]] .sourceHead = true := by decide
def e602930416502 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e602930416502 : Closed e602930416502 ∧ code e602930416502 = 9399023438710 := by decide
theorem cert_e602930416502 : check e602930416502 [[.under],[.under]] .sourceHead = true := by decide
def e602930416558 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e602930416558 : Closed e602930416558 ∧ code e602930416558 = 9399023438766 := by decide
theorem cert_e602930416558 : check e602930416558 [[.under],[.under]] .sourceHead = true := by decide
def e602930416570 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e602930416570 : Closed e602930416570 ∧ code e602930416570 = 9399023438778 := by decide
theorem cert_e602930416570 : check e602930416570 [[.under],[.under]] .sourceHead = true := by decide
def e602930416598 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e602930416598 : Closed e602930416598 ∧ code e602930416598 = 9399023438806 := by decide
theorem cert_e602930416598 : check e602930416598 [[.under],[.under]] .sourceHead = true := by decide
def e602930416602 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e602930416602 : Closed e602930416602 ∧ code e602930416602 = 9399023438810 := by decide
theorem cert_e602930416602 : check e602930416602 [[.under],[.under]] .sourceHead = true := by decide
def e602930416878 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e602930416878 : Closed e602930416878 ∧ code e602930416878 = 9399023439086 := by decide
theorem cert_e602930416878 : check e602930416878 [[.under],[.under]] .sourceHead = true := by decide
def e602930416886 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e602930416886 : Closed e602930416886 ∧ code e602930416886 = 9399023439094 := by decide
theorem cert_e602930416886 : check e602930416886 [[.under],[.under]] .sourceHead = true := by decide
def e602930417262 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e602930417262 : Closed e602930417262 ∧ code e602930417262 = 9399023439470 := by decide
theorem cert_e602930417262 : check e602930417262 [[.under],[.under]] .sourceHead = true := by decide
def e602930417274 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e602930417274 : Closed e602930417274 ∧ code e602930417274 = 9399023439482 := by decide
theorem cert_e602930417274 : check e602930417274 [[.under],[.under]] .sourceHead = true := by decide
def e602930417462 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e602930417462 : Closed e602930417462 ∧ code e602930417462 = 9399023439670 := by decide
theorem cert_e602930417462 : check e602930417462 [[.under],[.under]] .sourceHead = true := by decide
def e602930417466 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e602930417466 : Closed e602930417466 ∧ code e602930417466 = 9399023439674 := by decide
theorem cert_e602930417466 : check e602930417466 [[.under],[.under]] .sourceHead = true := by decide
def e602933037934 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e602933037934 : Closed e602933037934 ∧ code e602933037934 = 9399026060142 := by decide
theorem cert_e602933037934 : check e602933037934 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933037942 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e602933037942 : Closed e602933037942 ∧ code e602933037942 = 9399026060150 := by decide
theorem cert_e602933037942 : check e602933037942 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933037998 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e602933037998 : Closed e602933037998 ∧ code e602933037998 = 9399026060206 := by decide
theorem cert_e602933037998 : check e602933037998 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933038010 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e602933038010 : Closed e602933038010 ∧ code e602933038010 = 9399026060218 := by decide
theorem cert_e602933038010 : check e602933038010 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933038038 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e602933038038 : Closed e602933038038 ∧ code e602933038038 = 9399026060246 := by decide
theorem cert_e602933038038 : check e602933038038 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933038042 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e602933038042 : Closed e602933038042 ∧ code e602933038042 = 9399026060250 := by decide
theorem cert_e602933038042 : check e602933038042 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933038318 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e602933038318 : Closed e602933038318 ∧ code e602933038318 = 9399026060526 := by decide
theorem cert_e602933038318 : check e602933038318 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933038326 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e602933038326 : Closed e602933038326 ∧ code e602933038326 = 9399026060534 := by decide
theorem cert_e602933038326 : check e602933038326 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933038702 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e602933038702 : Closed e602933038702 ∧ code e602933038702 = 9399026060910 := by decide
theorem cert_e602933038702 : check e602933038702 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933038714 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e602933038714 : Closed e602933038714 ∧ code e602933038714 = 9399026060922 := by decide
theorem cert_e602933038714 : check e602933038714 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933038902 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e602933038902 : Closed e602933038902 ∧ code e602933038902 = 9399026061110 := by decide
theorem cert_e602933038902 : check e602933038902 [[.under],[.under],[.under]] .smaller = true := by decide
def e602933038906 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e602933038906 : Closed e602933038906 ∧ code e602933038906 = 9399026061114 := by decide
theorem cert_e602933038906 : check e602933038906 [[.under],[.under],[.under]] .smaller = true := by decide
def e602935438702 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e602935438702 : Closed e602935438702 ∧ code e602935438702 = 9399028460910 := by decide
theorem cert_e602935438702 : check e602935438702 [[.under],[.under]] .chain = true := by decide
def e602935438710 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e602935438710 : Closed e602935438710 ∧ code e602935438710 = 9399028460918 := by decide
theorem cert_e602935438710 : check e602935438710 [[.under],[.under]] .chain = true := by decide
def e602935438766 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e602935438766 : Closed e602935438766 ∧ code e602935438766 = 9399028460974 := by decide
theorem cert_e602935438766 : check e602935438766 [[.under],[.under]] .chain = true := by decide
def e602935438778 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e602935438778 : Closed e602935438778 ∧ code e602935438778 = 9399028460986 := by decide
theorem cert_e602935438778 : check e602935438778 [[.under],[.under]] .chain = true := by decide
def e602935438806 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e602935438806 : Closed e602935438806 ∧ code e602935438806 = 9399028461014 := by decide
theorem cert_e602935438806 : check e602935438806 [[.under],[.under]] .chain = true := by decide
def e602935438810 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e602935438810 : Closed e602935438810 ∧ code e602935438810 = 9399028461018 := by decide
theorem cert_e602935438810 : check e602935438810 [[.under],[.under]] .chain = true := by decide
def e602935439022 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e602935439022 : Closed e602935439022 ∧ code e602935439022 = 9399028461230 := by decide
theorem cert_e602935439022 : check e602935439022 [[.under],[.under]] .chain = true := by decide
def e602935439034 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e602935439034 : Closed e602935439034 ∧ code e602935439034 = 9399028461242 := by decide
theorem cert_e602935439034 : check e602935439034 [[.under],[.under]] .chain = true := by decide
def e602935439082 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e602935439082 : Closed e602935439082 ∧ code e602935439082 = 9399028461290 := by decide
theorem cert_e602935439082 : check e602935439082 [[.under],[.under]] .chain = true := by decide
def e602935439190 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e602935439190 : Closed e602935439190 ∧ code e602935439190 = 9399028461398 := by decide
theorem cert_e602935439190 : check e602935439190 [[.under],[.under]] .chain = true := by decide
def e602935439194 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e602935439194 : Closed e602935439194 ∧ code e602935439194 = 9399028461402 := by decide
theorem cert_e602935439194 : check e602935439194 [[.under],[.under]] .chain = true := by decide
def e602935439210 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e602935439210 : Closed e602935439210 ∧ code e602935439210 = 9399028461418 := by decide
theorem cert_e602935439210 : check e602935439210 [[.under],[.under]] .chain = true := by decide
end Blc.Floor43
