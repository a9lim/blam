import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411629868062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2411629868062 : Closed e2411629868062 ∧ code e2411629868062 = 11207722890270 := by decide
theorem cert_e2411629868062 : check e2411629868062 [[],[]] .chain = true := by decide
def e2411629868086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411629868086 : Closed e2411629868086 ∧ code e2411629868086 = 11207722890294 := by decide
theorem cert_e2411629868086 : check e2411629868086 [[],[]] .chain = true := by decide
def e2411629868090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411629868090 : Closed e2411629868090 ∧ code e2411629868090 = 11207722890298 := by decide
theorem cert_e2411629868090 : check e2411629868090 [[],[]] .chain = true := by decide
def e2411629868230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411629868230 : Closed e2411629868230 ∧ code e2411629868230 = 11207722890438 := by decide
theorem cert_e2411629868230 : check e2411629868230 [[],[]] .chain = true := by decide
def e2411629868258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411629868258 : Closed e2411629868258 ∧ code e2411629868258 = 11207722890466 := by decide
theorem cert_e2411629868258 : check e2411629868258 [[],[]] .chain = true := by decide
def e2411629868270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629868270 : Closed e2411629868270 ∧ code e2411629868270 = 11207722890478 := by decide
theorem cert_e2411629868270 : check e2411629868270 [[],[]] .sourceHead = true := by decide
def e2411629868278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629868278 : Closed e2411629868278 ∧ code e2411629868278 = 11207722890486 := by decide
theorem cert_e2411629868278 : check e2411629868278 [[],[]] .sourceHead = true := by decide
def e2411629868558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2411629868558 : Closed e2411629868558 ∧ code e2411629868558 = 11207722890766 := by decide
theorem cert_e2411629868558 : check e2411629868558 [[],[]] .chain = true := by decide
def e2411629868642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2411629868642 : Closed e2411629868642 ∧ code e2411629868642 = 11207722890850 := by decide
theorem cert_e2411629868642 : check e2411629868642 [[],[]] .chain = true := by decide
def e2411629868654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629868654 : Closed e2411629868654 ∧ code e2411629868654 = 11207722890862 := by decide
theorem cert_e2411629868654 : check e2411629868654 [[],[]] .sourceHead = true := by decide
def e2411629868666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629868666 : Closed e2411629868666 ∧ code e2411629868666 = 11207722890874 := by decide
theorem cert_e2411629868666 : check e2411629868666 [[],[]] .sourceHead = true := by decide
def e2411629868854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629868854 : Closed e2411629868854 ∧ code e2411629868854 = 11207722891062 := by decide
theorem cert_e2411629868854 : check e2411629868854 [[],[]] .sourceHead = true := by decide
def e2411629868858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629868858 : Closed e2411629868858 ∧ code e2411629868858 = 11207722891066 := by decide
theorem cert_e2411629868858 : check e2411629868858 [[],[]] .sourceHead = true := by decide
def e2411629872054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e2411629872054 : Closed e2411629872054 ∧ code e2411629872054 = 11207722894262 := by decide
theorem cert_e2411629872054 : check e2411629872054 [[],[]] .chain = true := by decide
def e2411629872086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e2411629872086 : Closed e2411629872086 ∧ code e2411629872086 = 11207722894294 := by decide
theorem cert_e2411629872086 : check e2411629872086 [[],[]] .chain = true := by decide
def e2411629872090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e2411629872090 : Closed e2411629872090 ∧ code e2411629872090 = 11207722894298 := by decide
theorem cert_e2411629872090 : check e2411629872090 [[],[]] .chain = true := by decide
def e2411629872854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2411629872854 : Closed e2411629872854 ∧ code e2411629872854 = 11207722895062 := by decide
theorem cert_e2411629872854 : check e2411629872854 [[],[]] .chain = true := by decide
def e2411629872858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2411629872858 : Closed e2411629872858 ∧ code e2411629872858 = 11207722895066 := by decide
theorem cert_e2411629872858 : check e2411629872858 [[],[]] .chain = true := by decide
def e2411629872874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2411629872874 : Closed e2411629872874 ∧ code e2411629872874 = 11207722895082 := by decide
theorem cert_e2411629872874 : check e2411629872874 [[],[]] .chain = true := by decide
def e2411629872982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2411629872982 : Closed e2411629872982 ∧ code e2411629872982 = 11207722895190 := by decide
theorem cert_e2411629872982 : check e2411629872982 [[],[]] .chain = true := by decide
def e2411629872986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2411629872986 : Closed e2411629872986 ∧ code e2411629872986 = 11207722895194 := by decide
theorem cert_e2411629872986 : check e2411629872986 [[],[]] .chain = true := by decide
def e2411629873066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2411629873066 : Closed e2411629873066 ∧ code e2411629873066 = 11207722895274 := by decide
theorem cert_e2411629873066 : check e2411629873066 [[],[]] .chain = true := by decide
def e2411629873590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2411629873590 : Closed e2411629873590 ∧ code e2411629873590 = 11207722895798 := by decide
theorem cert_e2411629873590 : check e2411629873590 [[],[]] .chain = true := by decide
def e2411629873622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2411629873622 : Closed e2411629873622 ∧ code e2411629873622 = 11207722895830 := by decide
theorem cert_e2411629873622 : check e2411629873622 [[],[]] .chain = true := by decide
def e2411629873626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2411629873626 : Closed e2411629873626 ∧ code e2411629873626 = 11207722895834 := by decide
theorem cert_e2411629873626 : check e2411629873626 [[],[]] .chain = true := by decide
def e2411629873782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2411629873782 : Closed e2411629873782 ∧ code e2411629873782 = 11207722895990 := by decide
theorem cert_e2411629873782 : check e2411629873782 [[],[]] .chain = true := by decide
def e2411629873974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629873974 : Closed e2411629873974 ∧ code e2411629873974 = 11207722896182 := by decide
theorem cert_e2411629873974 : check e2411629873974 [[],[]] .chain = true := by decide
def e2411629873978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629873978 : Closed e2411629873978 ∧ code e2411629873978 = 11207722896186 := by decide
theorem cert_e2411629873978 : check e2411629873978 [[],[]] .chain = true := by decide
def e2411629874294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2411629874294 : Closed e2411629874294 ∧ code e2411629874294 = 11207722896502 := by decide
theorem cert_e2411629874294 : check e2411629874294 [[],[]] .chain = true := by decide
def e2411629874390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2411629874390 : Closed e2411629874390 ∧ code e2411629874390 = 11207722896598 := by decide
theorem cert_e2411629874390 : check e2411629874390 [[],[]] .chain = true := by decide
def e2411629874394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2411629874394 : Closed e2411629874394 ∧ code e2411629874394 = 11207722896602 := by decide
theorem cert_e2411629874394 : check e2411629874394 [[],[]] .chain = true := by decide
def e2411629874410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2411629874410 : Closed e2411629874410 ∧ code e2411629874410 = 11207722896618 := by decide
theorem cert_e2411629874410 : check e2411629874410 [[],[]] .chain = true := by decide
def e2411629874486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629874486 : Closed e2411629874486 ∧ code e2411629874486 = 11207722896694 := by decide
theorem cert_e2411629874486 : check e2411629874486 [[],[]] .chain = true := by decide
def e2411629874490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629874490 : Closed e2411629874490 ∧ code e2411629874490 = 11207722896698 := by decide
theorem cert_e2411629874490 : check e2411629874490 [[],[]] .chain = true := by decide
def e2411629874574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2411629874574 : Closed e2411629874574 ∧ code e2411629874574 = 11207722896782 := by decide
theorem cert_e2411629874574 : check e2411629874574 [[],[]] .chain = true := by decide
def e2411629874586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629874586 : Closed e2411629874586 ∧ code e2411629874586 = 11207722896794 := by decide
theorem cert_e2411629874586 : check e2411629874586 [[],[]] .chain = true := by decide
def e2411629874742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2411629874742 : Closed e2411629874742 ∧ code e2411629874742 = 11207722896950 := by decide
theorem cert_e2411629874742 : check e2411629874742 [[],[]] .chain = true := by decide
def e2411629874746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2411629874746 : Closed e2411629874746 ∧ code e2411629874746 = 11207722896954 := by decide
theorem cert_e2411629874746 : check e2411629874746 [[],[]] .chain = true := by decide
def e2411629874794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2411629874794 : Closed e2411629874794 ∧ code e2411629874794 = 11207722897002 := by decide
theorem cert_e2411629874794 : check e2411629874794 [[],[]] .chain = true := by decide
def e2411629874830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2411629874830 : Closed e2411629874830 ∧ code e2411629874830 = 11207722897038 := by decide
theorem cert_e2411629874830 : check e2411629874830 [[],[]] .chain = true := by decide
def e2411629874842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629874842 : Closed e2411629874842 ∧ code e2411629874842 = 11207722897050 := by decide
theorem cert_e2411629874842 : check e2411629874842 [[],[]] .chain = true := by decide
def e2411629874886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2411629874886 : Closed e2411629874886 ∧ code e2411629874886 = 11207722897094 := by decide
theorem cert_e2411629874886 : check e2411629874886 [[],[]] .chain = true := by decide
def e2411629877430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e2411629877430 : Closed e2411629877430 ∧ code e2411629877430 = 11207722899638 := by decide
theorem cert_e2411629877430 : check e2411629877430 [[],[]] .chain = true := by decide
def e2411629877462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2411629877462 : Closed e2411629877462 ∧ code e2411629877462 = 11207722899670 := by decide
theorem cert_e2411629877462 : check e2411629877462 [[],[]] .chain = true := by decide
def e2411629877466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2411629877466 : Closed e2411629877466 ∧ code e2411629877466 = 11207722899674 := by decide
theorem cert_e2411629877466 : check e2411629877466 [[],[]] .chain = true := by decide
def e2411629877482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2411629877482 : Closed e2411629877482 ∧ code e2411629877482 = 11207722899690 := by decide
theorem cert_e2411629877482 : check e2411629877482 [[],[]] .chain = true := by decide
def e2411629877814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2411629877814 : Closed e2411629877814 ∧ code e2411629877814 = 11207722900022 := by decide
theorem cert_e2411629877814 : check e2411629877814 [[],[]] .chain = true := by decide
def e2411629877818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2411629877818 : Closed e2411629877818 ∧ code e2411629877818 = 11207722900026 := by decide
theorem cert_e2411629877818 : check e2411629877818 [[],[]] .chain = true := by decide
def e2411629877902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2411629877902 : Closed e2411629877902 ∧ code e2411629877902 = 11207722900110 := by decide
theorem cert_e2411629877902 : check e2411629877902 [[],[]] .chain = true := by decide
def e2411629877958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2411629877958 : Closed e2411629877958 ∧ code e2411629877958 = 11207722900166 := by decide
theorem cert_e2411629877958 : check e2411629877958 [[],[]] .chain = true := by decide
def e2411629878038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629878038 : Closed e2411629878038 ∧ code e2411629878038 = 11207722900246 := by decide
theorem cert_e2411629878038 : check e2411629878038 [[],[]] .chain = true := by decide
def e2411629878042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629878042 : Closed e2411629878042 ∧ code e2411629878042 = 11207722900250 := by decide
theorem cert_e2411629878042 : check e2411629878042 [[],[]] .chain = true := by decide
def e2411629878086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629878086 : Closed e2411629878086 ∧ code e2411629878086 = 11207722900294 := by decide
theorem cert_e2411629878086 : check e2411629878086 [[],[]] .chain = true := by decide
def e2411629878114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629878114 : Closed e2411629878114 ∧ code e2411629878114 = 11207722900322 := by decide
theorem cert_e2411629878114 : check e2411629878114 [[],[]] .chain = true := by decide
def e2411629878126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2411629878126 : Closed e2411629878126 ∧ code e2411629878126 = 11207722900334 := by decide
theorem cert_e2411629878126 : check e2411629878126 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629878134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2411629878134 : Closed e2411629878134 ∧ code e2411629878134 = 11207722900342 := by decide
theorem cert_e2411629878134 : check e2411629878134 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629878198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2411629878198 : Closed e2411629878198 ∧ code e2411629878198 = 11207722900406 := by decide
theorem cert_e2411629878198 : check e2411629878198 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629878358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2411629878358 : Closed e2411629878358 ∧ code e2411629878358 = 11207722900566 := by decide
theorem cert_e2411629878358 : check e2411629878358 [[],[]] .chain = true := by decide
def e2411629878362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2411629878362 : Closed e2411629878362 ∧ code e2411629878362 = 11207722900570 := by decide
theorem cert_e2411629878362 : check e2411629878362 [[],[]] .chain = true := by decide
def e2411629878378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2411629878378 : Closed e2411629878378 ∧ code e2411629878378 = 11207722900586 := by decide
theorem cert_e2411629878378 : check e2411629878378 [[],[]] .chain = true := by decide
def e2411629878550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629878550 : Closed e2411629878550 ∧ code e2411629878550 = 11207722900758 := by decide
theorem cert_e2411629878550 : check e2411629878550 [[],[]] .chain = true := by decide
def e2411629878554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629878554 : Closed e2411629878554 ∧ code e2411629878554 = 11207722900762 := by decide
theorem cert_e2411629878554 : check e2411629878554 [[],[]] .chain = true := by decide
def e2411629878598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629878598 : Closed e2411629878598 ∧ code e2411629878598 = 11207722900806 := by decide
theorem cert_e2411629878598 : check e2411629878598 [[],[]] .chain = true := by decide
def e2411629878626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629878626 : Closed e2411629878626 ∧ code e2411629878626 = 11207722900834 := by decide
theorem cert_e2411629878626 : check e2411629878626 [[],[]] .chain = true := by decide
def e2411629878638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2411629878638 : Closed e2411629878638 ∧ code e2411629878638 = 11207722900846 := by decide
theorem cert_e2411629878638 : check e2411629878638 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629878646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2411629878646 : Closed e2411629878646 ∧ code e2411629878646 = 11207722900854 := by decide
theorem cert_e2411629878646 : check e2411629878646 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629878666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2411629878666 : Closed e2411629878666 ∧ code e2411629878666 = 11207722900874 := by decide
theorem cert_e2411629878666 : check e2411629878666 [[],[]] .chain = true := by decide
def e2411629878690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2411629878690 : Closed e2411629878690 ∧ code e2411629878690 = 11207722900898 := by decide
theorem cert_e2411629878690 : check e2411629878690 [[],[]] .chain = true := by decide
def e2411629878702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2411629878702 : Closed e2411629878702 ∧ code e2411629878702 = 11207722900910 := by decide
theorem cert_e2411629878702 : check e2411629878702 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629878714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2411629878714 : Closed e2411629878714 ∧ code e2411629878714 = 11207722900922 := by decide
theorem cert_e2411629878714 : check e2411629878714 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629878742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2411629878742 : Closed e2411629878742 ∧ code e2411629878742 = 11207722900950 := by decide
theorem cert_e2411629878742 : check e2411629878742 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629878746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2411629878746 : Closed e2411629878746 ∧ code e2411629878746 = 11207722900954 := by decide
theorem cert_e2411629878746 : check e2411629878746 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629878966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2411629878966 : Closed e2411629878966 ∧ code e2411629878966 = 11207722901174 := by decide
theorem cert_e2411629878966 : check e2411629878966 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629878998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2411629878998 : Closed e2411629878998 ∧ code e2411629878998 = 11207722901206 := by decide
theorem cert_e2411629878998 : check e2411629878998 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629879002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2411629879002 : Closed e2411629879002 ∧ code e2411629879002 = 11207722901210 := by decide
theorem cert_e2411629879002 : check e2411629879002 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629879542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 1))))))
theorem wire_e2411629879542 : Closed e2411629879542 ∧ code e2411629879542 = 11207722901750 := by decide
theorem cert_e2411629879542 : check e2411629879542 [[],[]] .chain = true := by decide
def e2411629879734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2411629879734 : Closed e2411629879734 ∧ code e2411629879734 = 11207722901942 := by decide
theorem cert_e2411629879734 : check e2411629879734 [[],[]] .chain = true := by decide
def e2411629879738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2411629879738 : Closed e2411629879738 ∧ code e2411629879738 = 11207722901946 := by decide
theorem cert_e2411629879738 : check e2411629879738 [[],[]] .chain = true := by decide
def e2411629879766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2411629879766 : Closed e2411629879766 ∧ code e2411629879766 = 11207722901974 := by decide
theorem cert_e2411629879766 : check e2411629879766 [[],[]] .chain = true := by decide
def e2411629879786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2411629879786 : Closed e2411629879786 ∧ code e2411629879786 = 11207722901994 := by decide
theorem cert_e2411629879786 : check e2411629879786 [[],[]] .chain = true := by decide
def e2411629879926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2411629879926 : Closed e2411629879926 ∧ code e2411629879926 = 11207722902134 := by decide
theorem cert_e2411629879926 : check e2411629879926 [[],[]] .chain = true := by decide
def e2411629880118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629880118 : Closed e2411629880118 ∧ code e2411629880118 = 11207722902326 := by decide
theorem cert_e2411629880118 : check e2411629880118 [[],[]] .chain = true := by decide
def e2411629880122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629880122 : Closed e2411629880122 ∧ code e2411629880122 = 11207722902330 := by decide
theorem cert_e2411629880122 : check e2411629880122 [[],[]] .chain = true := by decide
def e2411629880206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 2)))))))
theorem wire_e2411629880206 : Closed e2411629880206 ∧ code e2411629880206 = 11207722902414 := by decide
theorem cert_e2411629880206 : check e2411629880206 [[],[]] .chain = true := by decide
def e2411629880218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629880218 : Closed e2411629880218 ∧ code e2411629880218 = 11207722902426 := by decide
theorem cert_e2411629880218 : check e2411629880218 [[],[]] .chain = true := by decide
def e2411629880886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2411629880886 : Closed e2411629880886 ∧ code e2411629880886 = 11207722903094 := by decide
theorem cert_e2411629880886 : check e2411629880886 [[],[]] .chain = true := by decide
def e2411629880890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2411629880890 : Closed e2411629880890 ∧ code e2411629880890 = 11207722903098 := by decide
theorem cert_e2411629880890 : check e2411629880890 [[],[]] .chain = true := by decide
def e2411629880974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2411629880974 : Closed e2411629880974 ∧ code e2411629880974 = 11207722903182 := by decide
theorem cert_e2411629880974 : check e2411629880974 [[],[]] .chain = true := by decide
def e2411629881030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2411629881030 : Closed e2411629881030 ∧ code e2411629881030 = 11207722903238 := by decide
theorem cert_e2411629881030 : check e2411629881030 [[],[]] .chain = true := by decide
def e2411629881110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411629881110 : Closed e2411629881110 ∧ code e2411629881110 = 11207722903318 := by decide
theorem cert_e2411629881110 : check e2411629881110 [[],[]] .chain = true := by decide
def e2411629881114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411629881114 : Closed e2411629881114 ∧ code e2411629881114 = 11207722903322 := by decide
theorem cert_e2411629881114 : check e2411629881114 [[],[]] .chain = true := by decide
def e2411629881158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411629881158 : Closed e2411629881158 ∧ code e2411629881158 = 11207722903366 := by decide
theorem cert_e2411629881158 : check e2411629881158 [[],[]] .chain = true := by decide
def e2411629881186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411629881186 : Closed e2411629881186 ∧ code e2411629881186 = 11207722903394 := by decide
theorem cert_e2411629881186 : check e2411629881186 [[],[]] .chain = true := by decide
def e2411629881198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2411629881198 : Closed e2411629881198 ∧ code e2411629881198 = 11207722903406 := by decide
theorem cert_e2411629881198 : check e2411629881198 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629881206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2411629881206 : Closed e2411629881206 ∧ code e2411629881206 = 11207722903414 := by decide
theorem cert_e2411629881206 : check e2411629881206 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629881270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2411629881270 : Closed e2411629881270 ∧ code e2411629881270 = 11207722903478 := by decide
theorem cert_e2411629881270 : check e2411629881270 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629881454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2411629881454 : Closed e2411629881454 ∧ code e2411629881454 = 11207722903662 := by decide
theorem cert_e2411629881454 : check e2411629881454 [[],[]] .chain = true := by decide
def e2411629881466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2411629881466 : Closed e2411629881466 ∧ code e2411629881466 = 11207722903674 := by decide
theorem cert_e2411629881466 : check e2411629881466 [[],[]] .chain = true := by decide
def e2411629881742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2411629881742 : Closed e2411629881742 ∧ code e2411629881742 = 11207722903950 := by decide
theorem cert_e2411629881742 : check e2411629881742 [[],[]] .chain = true := by decide
def e2411629881798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2411629881798 : Closed e2411629881798 ∧ code e2411629881798 = 11207722904006 := by decide
theorem cert_e2411629881798 : check e2411629881798 [[],[]] .chain = true := by decide
def e2411629882398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 3))))))))
theorem wire_e2411629882398 : Closed e2411629882398 ∧ code e2411629882398 = 11207722904606 := by decide
theorem cert_e2411629882398 : check e2411629882398 [[],[]] .chain = true := by decide
def e2411629882422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411629882422 : Closed e2411629882422 ∧ code e2411629882422 = 11207722904630 := by decide
theorem cert_e2411629882422 : check e2411629882422 [[],[]] .chain = true := by decide
def e2411629882426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411629882426 : Closed e2411629882426 ∧ code e2411629882426 = 11207722904634 := by decide
theorem cert_e2411629882426 : check e2411629882426 [[],[]] .chain = true := by decide
def e2411629882566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411629882566 : Closed e2411629882566 ∧ code e2411629882566 = 11207722904774 := by decide
theorem cert_e2411629882566 : check e2411629882566 [[],[]] .chain = true := by decide
def e2411629882594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411629882594 : Closed e2411629882594 ∧ code e2411629882594 = 11207722904802 := by decide
theorem cert_e2411629882594 : check e2411629882594 [[],[]] .chain = true := by decide
def e2411629882606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629882606 : Closed e2411629882606 ∧ code e2411629882606 = 11207722904814 := by decide
theorem cert_e2411629882606 : check e2411629882606 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629882614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629882614 : Closed e2411629882614 ∧ code e2411629882614 = 11207722904822 := by decide
theorem cert_e2411629882614 : check e2411629882614 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629882998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2411629882998 : Closed e2411629882998 ∧ code e2411629882998 = 11207722905206 := by decide
theorem cert_e2411629882998 : check e2411629882998 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629883510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2411629883510 : Closed e2411629883510 ∧ code e2411629883510 = 11207722905718 := by decide
theorem cert_e2411629883510 : check e2411629883510 [[],[]] .chain = true := by decide
def e2411629883514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2411629883514 : Closed e2411629883514 ∧ code e2411629883514 = 11207722905722 := by decide
theorem cert_e2411629883514 : check e2411629883514 [[],[]] .chain = true := by decide
def e2411629883610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2411629883610 : Closed e2411629883610 ∧ code e2411629883610 = 11207722905818 := by decide
theorem cert_e2411629883610 : check e2411629883610 [[],[]] .chain = true := by decide
def e2411629883626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2411629883626 : Closed e2411629883626 ∧ code e2411629883626 = 11207722905834 := by decide
theorem cert_e2411629883626 : check e2411629883626 [[],[]] .chain = true := by decide
def e2411629883702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629883702 : Closed e2411629883702 ∧ code e2411629883702 = 11207722905910 := by decide
theorem cert_e2411629883702 : check e2411629883702 [[],[]] .chain = true := by decide
def e2411629883706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629883706 : Closed e2411629883706 ∧ code e2411629883706 = 11207722905914 := by decide
theorem cert_e2411629883706 : check e2411629883706 [[],[]] .chain = true := by decide
def e2411629883790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2411629883790 : Closed e2411629883790 ∧ code e2411629883790 = 11207722905998 := by decide
theorem cert_e2411629883790 : check e2411629883790 [[],[]] .chain = true := by decide
def e2411629883802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629883802 : Closed e2411629883802 ∧ code e2411629883802 = 11207722906010 := by decide
theorem cert_e2411629883802 : check e2411629883802 [[],[]] .chain = true := by decide
def e2411629883846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2411629883846 : Closed e2411629883846 ∧ code e2411629883846 = 11207722906054 := by decide
theorem cert_e2411629883846 : check e2411629883846 [[],[]] .chain = true := by decide
def e2411629884182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411629884182 : Closed e2411629884182 ∧ code e2411629884182 = 11207722906390 := by decide
theorem cert_e2411629884182 : check e2411629884182 [[],[]] .chain = true := by decide
def e2411629884186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411629884186 : Closed e2411629884186 ∧ code e2411629884186 = 11207722906394 := by decide
theorem cert_e2411629884186 : check e2411629884186 [[],[]] .chain = true := by decide
def e2411629884230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411629884230 : Closed e2411629884230 ∧ code e2411629884230 = 11207722906438 := by decide
theorem cert_e2411629884230 : check e2411629884230 [[],[]] .chain = true := by decide
def e2411629884258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411629884258 : Closed e2411629884258 ∧ code e2411629884258 = 11207722906466 := by decide
theorem cert_e2411629884258 : check e2411629884258 [[],[]] .chain = true := by decide
def e2411629884270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2411629884270 : Closed e2411629884270 ∧ code e2411629884270 = 11207722906478 := by decide
theorem cert_e2411629884270 : check e2411629884270 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629884278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2411629884278 : Closed e2411629884278 ∧ code e2411629884278 = 11207722906486 := by decide
theorem cert_e2411629884278 : check e2411629884278 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629884298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2411629884298 : Closed e2411629884298 ∧ code e2411629884298 = 11207722906506 := by decide
theorem cert_e2411629884298 : check e2411629884298 [[],[]] .chain = true := by decide
def e2411629884322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2411629884322 : Closed e2411629884322 ∧ code e2411629884322 = 11207722906530 := by decide
theorem cert_e2411629884322 : check e2411629884322 [[],[]] .chain = true := by decide
def e2411629884334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2411629884334 : Closed e2411629884334 ∧ code e2411629884334 = 11207722906542 := by decide
theorem cert_e2411629884334 : check e2411629884334 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629884346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2411629884346 : Closed e2411629884346 ∧ code e2411629884346 = 11207722906554 := by decide
theorem cert_e2411629884346 : check e2411629884346 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629884374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2411629884374 : Closed e2411629884374 ∧ code e2411629884374 = 11207722906582 := by decide
theorem cert_e2411629884374 : check e2411629884374 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629884378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2411629884378 : Closed e2411629884378 ∧ code e2411629884378 = 11207722906586 := by decide
theorem cert_e2411629884378 : check e2411629884378 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629884446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2411629884446 : Closed e2411629884446 ∧ code e2411629884446 = 11207722906654 := by decide
theorem cert_e2411629884446 : check e2411629884446 [[],[]] .chain = true := by decide
def e2411629884470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411629884470 : Closed e2411629884470 ∧ code e2411629884470 = 11207722906678 := by decide
theorem cert_e2411629884470 : check e2411629884470 [[],[]] .chain = true := by decide
def e2411629884474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411629884474 : Closed e2411629884474 ∧ code e2411629884474 = 11207722906682 := by decide
theorem cert_e2411629884474 : check e2411629884474 [[],[]] .chain = true := by decide
def e2411629884614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411629884614 : Closed e2411629884614 ∧ code e2411629884614 = 11207722906822 := by decide
theorem cert_e2411629884614 : check e2411629884614 [[],[]] .chain = true := by decide
def e2411629884642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411629884642 : Closed e2411629884642 ∧ code e2411629884642 = 11207722906850 := by decide
theorem cert_e2411629884642 : check e2411629884642 [[],[]] .chain = true := by decide
def e2411629884654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629884654 : Closed e2411629884654 ∧ code e2411629884654 = 11207722906862 := by decide
theorem cert_e2411629884654 : check e2411629884654 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629884662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629884662 : Closed e2411629884662 ∧ code e2411629884662 = 11207722906870 := by decide
theorem cert_e2411629884662 : check e2411629884662 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629884942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2411629884942 : Closed e2411629884942 ∧ code e2411629884942 = 11207722907150 := by decide
theorem cert_e2411629884942 : check e2411629884942 [[],[]] .chain = true := by decide
def e2411629885026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2411629885026 : Closed e2411629885026 ∧ code e2411629885026 = 11207722907234 := by decide
theorem cert_e2411629885026 : check e2411629885026 [[],[]] .chain = true := by decide
def e2411629885038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629885038 : Closed e2411629885038 ∧ code e2411629885038 = 11207722907246 := by decide
theorem cert_e2411629885038 : check e2411629885038 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629885050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629885050 : Closed e2411629885050 ∧ code e2411629885050 = 11207722907258 := by decide
theorem cert_e2411629885050 : check e2411629885050 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629885238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629885238 : Closed e2411629885238 ∧ code e2411629885238 = 11207722907446 := by decide
theorem cert_e2411629885238 : check e2411629885238 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629885242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629885242 : Closed e2411629885242 ∧ code e2411629885242 = 11207722907450 := by decide
theorem cert_e2411629885242 : check e2411629885242 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411629885878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2411629885878 : Closed e2411629885878 ∧ code e2411629885878 = 11207722908086 := by decide
theorem cert_e2411629885878 : check e2411629885878 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629885910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2411629885910 : Closed e2411629885910 ∧ code e2411629885910 = 11207722908118 := by decide
theorem cert_e2411629885910 : check e2411629885910 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629885914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2411629885914 : Closed e2411629885914 ∧ code e2411629885914 = 11207722908122 := by decide
theorem cert_e2411629885914 : check e2411629885914 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629886070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2411629886070 : Closed e2411629886070 ∧ code e2411629886070 = 11207722908278 := by decide
theorem cert_e2411629886070 : check e2411629886070 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629886262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629886262 : Closed e2411629886262 ∧ code e2411629886262 = 11207722908470 := by decide
theorem cert_e2411629886262 : check e2411629886262 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629886266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629886266 : Closed e2411629886266 ∧ code e2411629886266 = 11207722908474 := by decide
theorem cert_e2411629886266 : check e2411629886266 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2411629919470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629919470 : Closed e2411629919470 ∧ code e2411629919470 = 11207722941678 := by decide
theorem cert_e2411629919470 : check e2411629919470 [[],[]] .chain = true := by decide
def e2411629919478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629919478 : Closed e2411629919478 ∧ code e2411629919478 = 11207722941686 := by decide
theorem cert_e2411629919478 : check e2411629919478 [[],[]] .chain = true := by decide
def e2411629919862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2411629919862 : Closed e2411629919862 ∧ code e2411629919862 = 11207722942070 := by decide
theorem cert_e2411629919862 : check e2411629919862 [[],[]] .chain = true := by decide
def e2411629927150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e2411629927150 : Closed e2411629927150 ∧ code e2411629927150 = 11207722949358 := by decide
theorem cert_e2411629927150 : check e2411629927150 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411629927158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))) (.var 1))))))
theorem wire_e2411629927158 : Closed e2411629927158 ∧ code e2411629927158 = 11207722949366 := by decide
theorem cert_e2411629927158 : check e2411629927158 [[],[]] .chain = true := by decide
def e2411629927286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e2411629927286 : Closed e2411629927286 ∧ code e2411629927286 = 11207722949494 := by decide
theorem cert_e2411629927286 : check e2411629927286 [[],[]] .smaller = true := by decide
def e2411629927290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 0))))))
theorem wire_e2411629927290 : Closed e2411629927290 ∧ code e2411629927290 = 11207722949498 := by decide
theorem cert_e2411629927290 : check e2411629927290 [[],[]] .chain = true := by decide
def e2411629927342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e2411629927342 : Closed e2411629927342 ∧ code e2411629927342 = 11207722949550 := by decide
theorem cert_e2411629927342 : checkPay e2411629927342 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2411629927350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e2411629927350 : Closed e2411629927350 ∧ code e2411629927350 = 11207722949558 := by decide
theorem cert_e2411629927350 : check e2411629927350 [[],[]] .smaller = true := by decide
def e2411629927382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))) (.var 1))))))
theorem wire_e2411629927382 : Closed e2411629927382 ∧ code e2411629927382 = 11207722949590 := by decide
theorem cert_e2411629927382 : check e2411629927382 [[],[]] .chain = true := by decide
def e2411629927386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 0))))))
theorem wire_e2411629927386 : Closed e2411629927386 ∧ code e2411629927386 = 11207722949594 := by decide
theorem cert_e2411629927386 : check e2411629927386 [[],[]] .chain = true := by decide
def e2411629927798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e2411629927798 : Closed e2411629927798 ∧ code e2411629927798 = 11207722950006 := by decide
theorem cert_e2411629927798 : check e2411629927798 [[],[]] .smaller = true := by decide
end Blc.Floor43
