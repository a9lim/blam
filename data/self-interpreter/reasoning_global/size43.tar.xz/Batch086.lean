import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e826999355190 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e826999355190 : Closed e826999355190 ∧ code e826999355190 = 9623092377398 := by decide
theorem cert_e826999355190 : check e826999355190 [] .sourceHead = true := by decide
def e826999355194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e826999355194 : Closed e826999355194 ∧ code e826999355194 = 9623092377402 := by decide
theorem cert_e826999355194 : check e826999355194 [] .sourceHead = true := by decide
def e826999355822 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e826999355822 : Closed e826999355822 ∧ code e826999355822 = 9623092378030 := by decide
theorem cert_e826999355822 : check e826999355822 [] .sourceHead = true := by decide
def e826999355834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e826999355834 : Closed e826999355834 ∧ code e826999355834 = 9623092378042 := by decide
theorem cert_e826999355834 : check e826999355834 [] .sourceHead = true := by decide
def e826999355882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e826999355882 : Closed e826999355882 ∧ code e826999355882 = 9623092378090 := by decide
theorem cert_e826999355882 : check e826999355882 [] .sourceHead = true := by decide
def e826999356014 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e826999356014 : Closed e826999356014 ∧ code e826999356014 = 9623092378222 := by decide
theorem cert_e826999356014 : check e826999356014 [] .sourceHead = true := by decide
def e826999356026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e826999356026 : Closed e826999356026 ∧ code e826999356026 = 9623092378234 := by decide
theorem cert_e826999356026 : check e826999356026 [] .sourceHead = true := by decide
def e826999356314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e826999356314 : Closed e826999356314 ∧ code e826999356314 = 9623092378522 := by decide
theorem cert_e826999356314 : check e826999356314 [] .sourceHead = true := by decide
def e826999356630 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e826999356630 : Closed e826999356630 ∧ code e826999356630 = 9623092378838 := by decide
theorem cert_e826999356630 : check e826999356630 [] .sourceHead = true := by decide
def e826999356634 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e826999356634 : Closed e826999356634 ∧ code e826999356634 = 9623092378842 := by decide
theorem cert_e826999356634 : check e826999356634 [] .sourceHead = true := by decide
def e826999356650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e826999356650 : Closed e826999356650 ∧ code e826999356650 = 9623092378858 := by decide
theorem cert_e826999356650 : check e826999356650 [] .sourceHead = true := by decide
def e826999356726 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e826999356726 : Closed e826999356726 ∧ code e826999356726 = 9623092378934 := by decide
theorem cert_e826999356726 : check e826999356726 [] .sourceHead = true := by decide
def e826999356730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e826999356730 : Closed e826999356730 ∧ code e826999356730 = 9623092378938 := by decide
theorem cert_e826999356730 : check e826999356730 [] .sourceHead = true := by decide
def e826999356826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e826999356826 : Closed e826999356826 ∧ code e826999356826 = 9623092379034 := by decide
theorem cert_e826999356826 : check e826999356826 [] .sourceHead = true := by decide
def e826999360366 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e826999360366 : Closed e826999360366 ∧ code e826999360366 = 9623092382574 := by decide
theorem cert_e826999360366 : check e826999360366 [] .sourceHead = true := by decide
def e826999360374 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e826999360374 : Closed e826999360374 ∧ code e826999360374 = 9623092382582 := by decide
theorem cert_e826999360374 : check e826999360374 [] .sourceHead = true := by decide
def e826999360430 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e826999360430 : Closed e826999360430 ∧ code e826999360430 = 9623092382638 := by decide
theorem cert_e826999360430 : check e826999360430 [] .sourceHead = true := by decide
def e826999360442 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e826999360442 : Closed e826999360442 ∧ code e826999360442 = 9623092382650 := by decide
theorem cert_e826999360442 : check e826999360442 [] .sourceHead = true := by decide
def e826999360470 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e826999360470 : Closed e826999360470 ∧ code e826999360470 = 9623092382678 := by decide
theorem cert_e826999360470 : check e826999360470 [] .sourceHead = true := by decide
def e826999360474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e826999360474 : Closed e826999360474 ∧ code e826999360474 = 9623092382682 := by decide
theorem cert_e826999360474 : check e826999360474 [] .sourceHead = true := by decide
def e826999360750 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e826999360750 : Closed e826999360750 ∧ code e826999360750 = 9623092382958 := by decide
theorem cert_e826999360750 : check e826999360750 [] .sourceHead = true := by decide
def e826999360758 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e826999360758 : Closed e826999360758 ∧ code e826999360758 = 9623092382966 := by decide
theorem cert_e826999360758 : check e826999360758 [] .sourceHead = true := by decide
def e826999361134 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e826999361134 : Closed e826999361134 ∧ code e826999361134 = 9623092383342 := by decide
theorem cert_e826999361134 : check e826999361134 [] .sourceHead = true := by decide
def e826999361146 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e826999361146 : Closed e826999361146 ∧ code e826999361146 = 9623092383354 := by decide
theorem cert_e826999361146 : check e826999361146 [] .sourceHead = true := by decide
def e826999361334 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e826999361334 : Closed e826999361334 ∧ code e826999361334 = 9623092383542 := by decide
theorem cert_e826999361334 : check e826999361334 [] .sourceHead = true := by decide
def e826999361338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e826999361338 : Closed e826999361338 ∧ code e826999361338 = 9623092383546 := by decide
theorem cert_e826999361338 : check e826999361338 [] .sourceHead = true := by decide
def e826999367086 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e826999367086 : Closed e826999367086 ∧ code e826999367086 = 9623092389294 := by decide
theorem cert_e826999367086 : check e826999367086 [] .sourceHead = true := by decide
def e826999367098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e826999367098 : Closed e826999367098 ∧ code e826999367098 = 9623092389306 := by decide
theorem cert_e826999367098 : check e826999367098 [] .sourceHead = true := by decide
def e826999367146 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e826999367146 : Closed e826999367146 ∧ code e826999367146 = 9623092389354 := by decide
theorem cert_e826999367146 : check e826999367146 [] .sourceHead = true := by decide
def e826999367278 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e826999367278 : Closed e826999367278 ∧ code e826999367278 = 9623092389486 := by decide
theorem cert_e826999367278 : check e826999367278 [] .sourceHead = true := by decide
def e826999367290 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e826999367290 : Closed e826999367290 ∧ code e826999367290 = 9623092389498 := by decide
theorem cert_e826999367290 : check e826999367290 [] .sourceHead = true := by decide
def e826999367578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e826999367578 : Closed e826999367578 ∧ code e826999367578 = 9623092389786 := by decide
theorem cert_e826999367578 : check e826999367578 [] .sourceHead = true := by decide
def e826999370454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e826999370454 : Closed e826999370454 ∧ code e826999370454 = 9623092392662 := by decide
theorem cert_e826999370454 : check e826999370454 [] .sourceHead = true := by decide
def e826999370458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e826999370458 : Closed e826999370458 ∧ code e826999370458 = 9623092392666 := by decide
theorem cert_e826999370458 : check e826999370458 [] .sourceHead = true := by decide
def e826999370474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e826999370474 : Closed e826999370474 ∧ code e826999370474 = 9623092392682 := by decide
theorem cert_e826999370474 : check e826999370474 [] .sourceHead = true := by decide
def e826999370550 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e826999370550 : Closed e826999370550 ∧ code e826999370550 = 9623092392758 := by decide
theorem cert_e826999370550 : check e826999370550 [] .sourceHead = true := by decide
def e826999370554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e826999370554 : Closed e826999370554 ∧ code e826999370554 = 9623092392762 := by decide
theorem cert_e826999370554 : check e826999370554 [] .sourceHead = true := by decide
def e826999370650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e826999370650 : Closed e826999370650 ∧ code e826999370650 = 9623092392858 := by decide
theorem cert_e826999370650 : check e826999370650 [] .sourceHead = true := by decide
def e826999485918 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))))
theorem wire_e826999485918 : Closed e826999485918 ∧ code e826999485918 = 9623092508126 := by decide
theorem cert_e826999485918 : check e826999485918 [] .sourceHead = true := by decide
def e826999485934 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))))
theorem wire_e826999485934 : Closed e826999485934 ∧ code e826999485934 = 9623092508142 := by decide
theorem cert_e826999485934 : check e826999485934 [] .sourceHead = true := by decide
def e826999486174 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))))
theorem wire_e826999486174 : Closed e826999486174 ∧ code e826999486174 = 9623092508382 := by decide
theorem cert_e826999486174 : check e826999486174 [] .sourceHead = true := by decide
def e826999486198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))))
theorem wire_e826999486198 : Closed e826999486198 ∧ code e826999486198 = 9623092508406 := by decide
theorem cert_e826999486198 : check e826999486198 [] .sourceHead = true := by decide
def e826999486302 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))))
theorem wire_e826999486302 : Closed e826999486302 ∧ code e826999486302 = 9623092508510 := by decide
theorem cert_e826999486302 : check e826999486302 [] .sourceHead = true := by decide
def e826999486330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))))
theorem wire_e826999486330 : Closed e826999486330 ∧ code e826999486330 = 9623092508538 := by decide
theorem cert_e826999486330 : check e826999486330 [] .sourceHead = true := by decide
def e826999486382 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))))
theorem wire_e826999486382 : Closed e826999486382 ∧ code e826999486382 = 9623092508590 := by decide
theorem cert_e826999486382 : check e826999486382 [] .sourceHead = true := by decide
def e826999486390 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))))
theorem wire_e826999486390 : Closed e826999486390 ∧ code e826999486390 = 9623092508598 := by decide
theorem cert_e826999486390 : check e826999486390 [] .sourceHead = true := by decide
def e826999486394 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))))
theorem wire_e826999486394 : Closed e826999486394 ∧ code e826999486394 = 9623092508602 := by decide
theorem cert_e826999486394 : check e826999486394 [] .sourceHead = true := by decide
def e826999487198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e826999487198 : Closed e826999487198 ∧ code e826999487198 = 9623092509406 := by decide
theorem cert_e826999487198 : check e826999487198 [] .sourceHead = true := by decide
def e826999487222 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e826999487222 : Closed e826999487222 ∧ code e826999487222 = 9623092509430 := by decide
theorem cert_e826999487222 : check e826999487222 [] .sourceHead = true := by decide
def e826999487326 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e826999487326 : Closed e826999487326 ∧ code e826999487326 = 9623092509534 := by decide
theorem cert_e826999487326 : check e826999487326 [] .sourceHead = true := by decide
def e826999487354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e826999487354 : Closed e826999487354 ∧ code e826999487354 = 9623092509562 := by decide
theorem cert_e826999487354 : check e826999487354 [] .sourceHead = true := by decide
def e826999487446 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e826999487446 : Closed e826999487446 ∧ code e826999487446 = 9623092509654 := by decide
theorem cert_e826999487446 : check e826999487446 [] .sourceHead = true := by decide
def e826999487450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e826999487450 : Closed e826999487450 ∧ code e826999487450 = 9623092509658 := by decide
theorem cert_e826999487450 : check e826999487450 [] .sourceHead = true := by decide
def e826999487838 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e826999487838 : Closed e826999487838 ∧ code e826999487838 = 9623092510046 := by decide
theorem cert_e826999487838 : check e826999487838 [] .sourceHead = true := by decide
def e826999487866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e826999487866 : Closed e826999487866 ∧ code e826999487866 = 9623092510074 := by decide
theorem cert_e826999487866 : check e826999487866 [] .sourceHead = true := by decide
def e826999487978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e826999487978 : Closed e826999487978 ∧ code e826999487978 = 9623092510186 := by decide
theorem cert_e826999487978 : check e826999487978 [] .sourceHead = true := by decide
def e826999488174 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e826999488174 : Closed e826999488174 ∧ code e826999488174 = 9623092510382 := by decide
theorem cert_e826999488174 : check e826999488174 [] .sourceHead = true := by decide
def e826999488182 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e826999488182 : Closed e826999488182 ∧ code e826999488182 = 9623092510390 := by decide
theorem cert_e826999488182 : check e826999488182 [] .sourceHead = true := by decide
def e826999488186 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e826999488186 : Closed e826999488186 ∧ code e826999488186 = 9623092510394 := by decide
theorem cert_e826999488186 : check e826999488186 [] .sourceHead = true := by decide
def e826999488214 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e826999488214 : Closed e826999488214 ∧ code e826999488214 = 9623092510422 := by decide
theorem cert_e826999488214 : check e826999488214 [] .sourceHead = true := by decide
def e826999488218 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e826999488218 : Closed e826999488218 ∧ code e826999488218 = 9623092510426 := by decide
theorem cert_e826999488218 : check e826999488218 [] .sourceHead = true := by decide
def e826999488234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e826999488234 : Closed e826999488234 ∧ code e826999488234 = 9623092510442 := by decide
theorem cert_e826999488234 : check e826999488234 [] .sourceHead = true := by decide
def e826999492062 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))))
theorem wire_e826999492062 : Closed e826999492062 ∧ code e826999492062 = 9623092514270 := by decide
theorem cert_e826999492062 : check e826999492062 [] .sourceHead = true := by decide
def e826999492078 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))))
theorem wire_e826999492078 : Closed e826999492078 ∧ code e826999492078 = 9623092514286 := by decide
theorem cert_e826999492078 : check e826999492078 [] .sourceHead = true := by decide
def e826999492318 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))))
theorem wire_e826999492318 : Closed e826999492318 ∧ code e826999492318 = 9623092514526 := by decide
theorem cert_e826999492318 : check e826999492318 [] .sourceHead = true := by decide
def e826999492342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))))
theorem wire_e826999492342 : Closed e826999492342 ∧ code e826999492342 = 9623092514550 := by decide
theorem cert_e826999492342 : check e826999492342 [] .sourceHead = true := by decide
def e826999492446 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))))
theorem wire_e826999492446 : Closed e826999492446 ∧ code e826999492446 = 9623092514654 := by decide
theorem cert_e826999492446 : check e826999492446 [] .sourceHead = true := by decide
def e826999492474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))))
theorem wire_e826999492474 : Closed e826999492474 ∧ code e826999492474 = 9623092514682 := by decide
theorem cert_e826999492474 : check e826999492474 [] .sourceHead = true := by decide
def e826999492526 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))))
theorem wire_e826999492526 : Closed e826999492526 ∧ code e826999492526 = 9623092514734 := by decide
theorem cert_e826999492526 : check e826999492526 [] .sourceHead = true := by decide
def e826999492534 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))))
theorem wire_e826999492534 : Closed e826999492534 ∧ code e826999492534 = 9623092514742 := by decide
theorem cert_e826999492534 : check e826999492534 [] .sourceHead = true := by decide
def e826999492538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))))
theorem wire_e826999492538 : Closed e826999492538 ∧ code e826999492538 = 9623092514746 := by decide
theorem cert_e826999492538 : check e826999492538 [] .sourceHead = true := by decide
def e826999493598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))))
theorem wire_e826999493598 : Closed e826999493598 ∧ code e826999493598 = 9623092515806 := by decide
theorem cert_e826999493598 : check e826999493598 [] .sourceHead = true := by decide
def e826999493614 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))))
theorem wire_e826999493614 : Closed e826999493614 ∧ code e826999493614 = 9623092515822 := by decide
theorem cert_e826999493614 : check e826999493614 [] .sourceHead = true := by decide
def e826999495134 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))))
theorem wire_e826999495134 : Closed e826999495134 ∧ code e826999495134 = 9623092517342 := by decide
theorem cert_e826999495134 : check e826999495134 [] .sourceHead = true := by decide
def e826999495158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))))
theorem wire_e826999495158 : Closed e826999495158 ∧ code e826999495158 = 9623092517366 := by decide
theorem cert_e826999495158 : check e826999495158 [] .sourceHead = true := by decide
def e826999495902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))))
theorem wire_e826999495902 : Closed e826999495902 ∧ code e826999495902 = 9623092518110 := by decide
theorem cert_e826999495902 : check e826999495902 [] .sourceHead = true := by decide
def e826999495930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))))
theorem wire_e826999495930 : Closed e826999495930 ∧ code e826999495930 = 9623092518138 := by decide
theorem cert_e826999495930 : check e826999495930 [] .sourceHead = true := by decide
def e826999496302 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))))
theorem wire_e826999496302 : Closed e826999496302 ∧ code e826999496302 = 9623092518510 := by decide
theorem cert_e826999496302 : check e826999496302 [] .sourceHead = true := by decide
def e826999496310 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))))
theorem wire_e826999496310 : Closed e826999496310 ∧ code e826999496310 = 9623092518518 := by decide
theorem cert_e826999496310 : check e826999496310 [] .sourceHead = true := by decide
def e826999496314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))))
theorem wire_e826999496314 : Closed e826999496314 ∧ code e826999496314 = 9623092518522 := by decide
theorem cert_e826999496314 : check e826999496314 [] .sourceHead = true := by decide
def e826999498462 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e826999498462 : Closed e826999498462 ∧ code e826999498462 = 9623092520670 := by decide
theorem cert_e826999498462 : check e826999498462 [] .sourceHead = true := by decide
def e826999498486 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e826999498486 : Closed e826999498486 ∧ code e826999498486 = 9623092520694 := by decide
theorem cert_e826999498486 : check e826999498486 [] .sourceHead = true := by decide
def e826999498590 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e826999498590 : Closed e826999498590 ∧ code e826999498590 = 9623092520798 := by decide
theorem cert_e826999498590 : check e826999498590 [] .sourceHead = true := by decide
def e826999498618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e826999498618 : Closed e826999498618 ∧ code e826999498618 = 9623092520826 := by decide
theorem cert_e826999498618 : check e826999498618 [] .sourceHead = true := by decide
def e826999498710 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e826999498710 : Closed e826999498710 ∧ code e826999498710 = 9623092520918 := by decide
theorem cert_e826999498710 : check e826999498710 [] .sourceHead = true := by decide
def e826999498714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e826999498714 : Closed e826999498714 ∧ code e826999498714 = 9623092520922 := by decide
theorem cert_e826999498714 : check e826999498714 [] .sourceHead = true := by decide
def e826999499230 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e826999499230 : Closed e826999499230 ∧ code e826999499230 = 9623092521438 := by decide
theorem cert_e826999499230 : check e826999499230 [] .sourceHead = true := by decide
def e826999499254 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e826999499254 : Closed e826999499254 ∧ code e826999499254 = 9623092521462 := by decide
theorem cert_e826999499254 : check e826999499254 [] .sourceHead = true := by decide
def e826999499998 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e826999499998 : Closed e826999499998 ∧ code e826999499998 = 9623092522206 := by decide
theorem cert_e826999499998 : check e826999499998 [] .sourceHead = true := by decide
def e826999500026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e826999500026 : Closed e826999500026 ∧ code e826999500026 = 9623092522234 := by decide
theorem cert_e826999500026 : check e826999500026 [] .sourceHead = true := by decide
def e826999500598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e826999500598 : Closed e826999500598 ∧ code e826999500598 = 9623092522806 := by decide
theorem cert_e826999500598 : check e826999500598 [] .sourceHead = true := by decide
def e826999500602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e826999500602 : Closed e826999500602 ∧ code e826999500602 = 9623092522810 := by decide
theorem cert_e826999500602 : check e826999500602 [] .sourceHead = true := by decide
def e826999501662 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e826999501662 : Closed e826999501662 ∧ code e826999501662 = 9623092523870 := by decide
theorem cert_e826999501662 : check e826999501662 [] .sourceHead = true := by decide
def e826999501690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e826999501690 : Closed e826999501690 ∧ code e826999501690 = 9623092523898 := by decide
theorem cert_e826999501690 : check e826999501690 [] .sourceHead = true := by decide
def e826999501802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e826999501802 : Closed e826999501802 ∧ code e826999501802 = 9623092524010 := by decide
theorem cert_e826999501802 : check e826999501802 [] .sourceHead = true := by decide
def e826999502046 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e826999502046 : Closed e826999502046 ∧ code e826999502046 = 9623092524254 := by decide
theorem cert_e826999502046 : check e826999502046 [] .sourceHead = true := by decide
def e826999502074 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e826999502074 : Closed e826999502074 ∧ code e826999502074 = 9623092524282 := by decide
theorem cert_e826999502074 : check e826999502074 [] .sourceHead = true := by decide
def e826999502746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e826999502746 : Closed e826999502746 ∧ code e826999502746 = 9623092524954 := by decide
theorem cert_e826999502746 : check e826999502746 [] .sourceHead = true := by decide
def e826999503278 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e826999503278 : Closed e826999503278 ∧ code e826999503278 = 9623092525486 := by decide
theorem cert_e826999503278 : check e826999503278 [] .sourceHead = true := by decide
def e826999503286 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e826999503286 : Closed e826999503286 ∧ code e826999503286 = 9623092525494 := by decide
theorem cert_e826999503286 : check e826999503286 [] .sourceHead = true := by decide
def e826999503290 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e826999503290 : Closed e826999503290 ∧ code e826999503290 = 9623092525498 := by decide
theorem cert_e826999503290 : check e826999503290 [] .sourceHead = true := by decide
def e826999503318 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e826999503318 : Closed e826999503318 ∧ code e826999503318 = 9623092525526 := by decide
theorem cert_e826999503318 : check e826999503318 [] .sourceHead = true := by decide
def e826999503322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e826999503322 : Closed e826999503322 ∧ code e826999503322 = 9623092525530 := by decide
theorem cert_e826999503322 : check e826999503322 [] .sourceHead = true := by decide
def e826999503338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e826999503338 : Closed e826999503338 ∧ code e826999503338 = 9623092525546 := by decide
theorem cert_e826999503338 : check e826999503338 [] .sourceHead = true := by decide
def e826999503470 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e826999503470 : Closed e826999503470 ∧ code e826999503470 = 9623092525678 := by decide
theorem cert_e826999503470 : check e826999503470 [] .sourceHead = true := by decide
def e826999503478 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e826999503478 : Closed e826999503478 ∧ code e826999503478 = 9623092525686 := by decide
theorem cert_e826999503478 : check e826999503478 [] .sourceHead = true := by decide
def e826999503482 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e826999503482 : Closed e826999503482 ∧ code e826999503482 = 9623092525690 := by decide
theorem cert_e826999503482 : check e826999503482 [] .sourceHead = true := by decide
def e826999503670 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e826999503670 : Closed e826999503670 ∧ code e826999503670 = 9623092525878 := by decide
theorem cert_e826999503670 : check e826999503670 [] .sourceHead = true := by decide
def e826999503674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e826999503674 : Closed e826999503674 ∧ code e826999503674 = 9623092525882 := by decide
theorem cert_e826999503674 : check e826999503674 [] .sourceHead = true := by decide
def e826999503770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e826999503770 : Closed e826999503770 ∧ code e826999503770 = 9623092525978 := by decide
theorem cert_e826999503770 : check e826999503770 [] .sourceHead = true := by decide
def e826999507822 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e826999507822 : Closed e826999507822 ∧ code e826999507822 = 9623092530030 := by decide
theorem cert_e826999507822 : check e826999507822 [] .sourceHead = true := by decide
def e826999507830 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e826999507830 : Closed e826999507830 ∧ code e826999507830 = 9623092530038 := by decide
theorem cert_e826999507830 : check e826999507830 [] .sourceHead = true := by decide
def e826999507886 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e826999507886 : Closed e826999507886 ∧ code e826999507886 = 9623092530094 := by decide
theorem cert_e826999507886 : check e826999507886 [] .sourceHead = true := by decide
def e826999507898 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e826999507898 : Closed e826999507898 ∧ code e826999507898 = 9623092530106 := by decide
theorem cert_e826999507898 : check e826999507898 [] .sourceHead = true := by decide
def e826999507926 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e826999507926 : Closed e826999507926 ∧ code e826999507926 = 9623092530134 := by decide
theorem cert_e826999507926 : check e826999507926 [] .sourceHead = true := by decide
def e826999507930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e826999507930 : Closed e826999507930 ∧ code e826999507930 = 9623092530138 := by decide
theorem cert_e826999507930 : check e826999507930 [] .sourceHead = true := by decide
def e826999508206 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e826999508206 : Closed e826999508206 ∧ code e826999508206 = 9623092530414 := by decide
theorem cert_e826999508206 : check e826999508206 [] .sourceHead = true := by decide
def e826999508214 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e826999508214 : Closed e826999508214 ∧ code e826999508214 = 9623092530422 := by decide
theorem cert_e826999508214 : check e826999508214 [] .sourceHead = true := by decide
def e826999508590 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e826999508590 : Closed e826999508590 ∧ code e826999508590 = 9623092530798 := by decide
theorem cert_e826999508590 : check e826999508590 [] .sourceHead = true := by decide
def e826999508602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e826999508602 : Closed e826999508602 ∧ code e826999508602 = 9623092530810 := by decide
theorem cert_e826999508602 : check e826999508602 [] .sourceHead = true := by decide
def e826999508790 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e826999508790 : Closed e826999508790 ∧ code e826999508790 = 9623092530998 := by decide
theorem cert_e826999508790 : check e826999508790 [] .sourceHead = true := by decide
def e826999508794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e826999508794 : Closed e826999508794 ∧ code e826999508794 = 9623092531002 := by decide
theorem cert_e826999508794 : check e826999508794 [] .sourceHead = true := by decide
def e826999516638 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e826999516638 : Closed e826999516638 ∧ code e826999516638 = 9623092538846 := by decide
theorem cert_e826999516638 : check e826999516638 [] .sourceHead = true := by decide
def e826999516654 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e826999516654 : Closed e826999516654 ∧ code e826999516654 = 9623092538862 := by decide
theorem cert_e826999516654 : check e826999516654 [] .sourceHead = true := by decide
def e826999516894 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))))
theorem wire_e826999516894 : Closed e826999516894 ∧ code e826999516894 = 9623092539102 := by decide
theorem cert_e826999516894 : check e826999516894 [] .sourceHead = true := by decide
def e826999516918 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))))
theorem wire_e826999516918 : Closed e826999516918 ∧ code e826999516918 = 9623092539126 := by decide
theorem cert_e826999516918 : check e826999516918 [] .sourceHead = true := by decide
def e826999517022 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e826999517022 : Closed e826999517022 ∧ code e826999517022 = 9623092539230 := by decide
theorem cert_e826999517022 : check e826999517022 [] .sourceHead = true := by decide
def e826999517050 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e826999517050 : Closed e826999517050 ∧ code e826999517050 = 9623092539258 := by decide
theorem cert_e826999517050 : check e826999517050 [] .sourceHead = true := by decide
def e826999517102 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e826999517102 : Closed e826999517102 ∧ code e826999517102 = 9623092539310 := by decide
theorem cert_e826999517102 : check e826999517102 [] .sourceHead = true := by decide
def e826999517110 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))))
theorem wire_e826999517110 : Closed e826999517110 ∧ code e826999517110 = 9623092539318 := by decide
theorem cert_e826999517110 : check e826999517110 [] .sourceHead = true := by decide
def e826999517114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e826999517114 : Closed e826999517114 ∧ code e826999517114 = 9623092539322 := by decide
theorem cert_e826999517114 : check e826999517114 [] .sourceHead = true := by decide
def e826999518174 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e826999518174 : Closed e826999518174 ∧ code e826999518174 = 9623092540382 := by decide
theorem cert_e826999518174 : check e826999518174 [] .sourceHead = true := by decide
def e826999518190 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e826999518190 : Closed e826999518190 ∧ code e826999518190 = 9623092540398 := by decide
theorem cert_e826999518190 : check e826999518190 [] .sourceHead = true := by decide
def e826999519710 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))))
theorem wire_e826999519710 : Closed e826999519710 ∧ code e826999519710 = 9623092541918 := by decide
theorem cert_e826999519710 : check e826999519710 [] .sourceHead = true := by decide
def e826999519734 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))))
theorem wire_e826999519734 : Closed e826999519734 ∧ code e826999519734 = 9623092541942 := by decide
theorem cert_e826999519734 : check e826999519734 [] .sourceHead = true := by decide
def e826999520478 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e826999520478 : Closed e826999520478 ∧ code e826999520478 = 9623092542686 := by decide
theorem cert_e826999520478 : check e826999520478 [] .sourceHead = true := by decide
def e826999520506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e826999520506 : Closed e826999520506 ∧ code e826999520506 = 9623092542714 := by decide
theorem cert_e826999520506 : check e826999520506 [] .sourceHead = true := by decide
def e826999520878 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e826999520878 : Closed e826999520878 ∧ code e826999520878 = 9623092543086 := by decide
theorem cert_e826999520878 : check e826999520878 [] .sourceHead = true := by decide
def e826999520886 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))))
theorem wire_e826999520886 : Closed e826999520886 ∧ code e826999520886 = 9623092543094 := by decide
theorem cert_e826999520886 : check e826999520886 [] .sourceHead = true := by decide
def e826999520890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e826999520890 : Closed e826999520890 ∧ code e826999520890 = 9623092543098 := by decide
theorem cert_e826999520890 : check e826999520890 [] .sourceHead = true := by decide
def e826999543518 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e826999543518 : Closed e826999543518 ∧ code e826999543518 = 9623092565726 := by decide
theorem cert_e826999543518 : check e826999543518 [] .sourceHead = true := by decide
def e826999543542 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e826999543542 : Closed e826999543542 ∧ code e826999543542 = 9623092565750 := by decide
theorem cert_e826999543542 : check e826999543542 [] .sourceHead = true := by decide
def e826999543646 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e826999543646 : Closed e826999543646 ∧ code e826999543646 = 9623092565854 := by decide
theorem cert_e826999543646 : check e826999543646 [] .sourceHead = true := by decide
def e826999543674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e826999543674 : Closed e826999543674 ∧ code e826999543674 = 9623092565882 := by decide
theorem cert_e826999543674 : check e826999543674 [] .sourceHead = true := by decide
def e826999543766 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e826999543766 : Closed e826999543766 ∧ code e826999543766 = 9623092565974 := by decide
theorem cert_e826999543766 : check e826999543766 [] .sourceHead = true := by decide
def e826999543770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e826999543770 : Closed e826999543770 ∧ code e826999543770 = 9623092565978 := by decide
theorem cert_e826999543770 : check e826999543770 [] .sourceHead = true := by decide
def e826999544286 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e826999544286 : Closed e826999544286 ∧ code e826999544286 = 9623092566494 := by decide
theorem cert_e826999544286 : check e826999544286 [] .sourceHead = true := by decide
def e826999544310 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e826999544310 : Closed e826999544310 ∧ code e826999544310 = 9623092566518 := by decide
theorem cert_e826999544310 : check e826999544310 [] .sourceHead = true := by decide
def e826999545054 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e826999545054 : Closed e826999545054 ∧ code e826999545054 = 9623092567262 := by decide
theorem cert_e826999545054 : check e826999545054 [] .sourceHead = true := by decide
def e826999545082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e826999545082 : Closed e826999545082 ∧ code e826999545082 = 9623092567290 := by decide
theorem cert_e826999545082 : check e826999545082 [] .sourceHead = true := by decide
def e826999545654 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e826999545654 : Closed e826999545654 ∧ code e826999545654 = 9623092567862 := by decide
theorem cert_e826999545654 : check e826999545654 [] .sourceHead = true := by decide
def e826999545658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e826999545658 : Closed e826999545658 ∧ code e826999545658 = 9623092567866 := by decide
theorem cert_e826999545658 : check e826999545658 [] .sourceHead = true := by decide
def e826999556958 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e826999556958 : Closed e826999556958 ∧ code e826999556958 = 9623092579166 := by decide
theorem cert_e826999556958 : check e826999556958 [] .sourceHead = true := by decide
def e826999556986 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e826999556986 : Closed e826999556986 ∧ code e826999556986 = 9623092579194 := by decide
theorem cert_e826999556986 : check e826999556986 [] .sourceHead = true := by decide
def e826999557098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e826999557098 : Closed e826999557098 ∧ code e826999557098 = 9623092579306 := by decide
theorem cert_e826999557098 : check e826999557098 [] .sourceHead = true := by decide
def e826999557342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e826999557342 : Closed e826999557342 ∧ code e826999557342 = 9623092579550 := by decide
theorem cert_e826999557342 : check e826999557342 [] .sourceHead = true := by decide
def e826999557370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e826999557370 : Closed e826999557370 ∧ code e826999557370 = 9623092579578 := by decide
theorem cert_e826999557370 : check e826999557370 [] .sourceHead = true := by decide
def e826999558042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e826999558042 : Closed e826999558042 ∧ code e826999558042 = 9623092580250 := by decide
theorem cert_e826999558042 : check e826999558042 [] .sourceHead = true := by decide
def e826999563694 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e826999563694 : Closed e826999563694 ∧ code e826999563694 = 9623092585902 := by decide
theorem cert_e826999563694 : check e826999563694 [] .sourceHead = true := by decide
def e826999563702 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e826999563702 : Closed e826999563702 ∧ code e826999563702 = 9623092585910 := by decide
theorem cert_e826999563702 : check e826999563702 [] .sourceHead = true := by decide
end Blc.Floor43
