import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419143663854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2419143663854 : Closed e2419143663854 ∧ code e2419143663854 = 11215236686062 := by decide
theorem cert_e2419143663854 : check e2419143663854 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143663866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2419143663866 : Closed e2419143663866 ∧ code e2419143663866 = 11215236686074 := by decide
theorem cert_e2419143663866 : check e2419143663866 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143664046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2419143664046 : Closed e2419143664046 ∧ code e2419143664046 = 11215236686254 := by decide
theorem cert_e2419143664046 : check e2419143664046 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143664238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143664238 : Closed e2419143664238 ∧ code e2419143664238 = 11215236686446 := by decide
theorem cert_e2419143664238 : check e2419143664238 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143664250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143664250 : Closed e2419143664250 ∧ code e2419143664250 = 11215236686458 := by decide
theorem cert_e2419143664250 : check e2419143664250 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143664414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2419143664414 : Closed e2419143664414 ∧ code e2419143664414 = 11215236686622 := by decide
theorem cert_e2419143664414 : check e2419143664414 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143664582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2419143664582 : Closed e2419143664582 ∧ code e2419143664582 = 11215236686790 := by decide
theorem cert_e2419143664582 : check e2419143664582 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2419143665198 : Closed e2419143665198 ∧ code e2419143665198 = 11215236687406 := by decide
theorem cert_e2419143665198 : check e2419143665198 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2419143665378 : Closed e2419143665378 ∧ code e2419143665378 = 11215236687586 := by decide
theorem cert_e2419143665378 : check e2419143665378 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2419143665390 : Closed e2419143665390 ∧ code e2419143665390 = 11215236687598 := by decide
theorem cert_e2419143665390 : check e2419143665390 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2419143665518 : Closed e2419143665518 ∧ code e2419143665518 = 11215236687726 := by decide
theorem cert_e2419143665518 : check e2419143665518 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2419143665526 : Closed e2419143665526 ∧ code e2419143665526 = 11215236687734 := by decide
theorem cert_e2419143665526 : check e2419143665526 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419143665546 : Closed e2419143665546 ∧ code e2419143665546 = 11215236687754 := by decide
theorem cert_e2419143665546 : check e2419143665546 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419143665570 : Closed e2419143665570 ∧ code e2419143665570 = 11215236687778 := by decide
theorem cert_e2419143665570 : check e2419143665570 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2419143665582 : Closed e2419143665582 ∧ code e2419143665582 = 11215236687790 := by decide
theorem cert_e2419143665582 : check e2419143665582 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2419143665590 : Closed e2419143665590 ∧ code e2419143665590 = 11215236687798 := by decide
theorem cert_e2419143665590 : check e2419143665590 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2419143665594 : Closed e2419143665594 ∧ code e2419143665594 = 11215236687802 := by decide
theorem cert_e2419143665594 : check e2419143665594 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143665726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2419143665726 : Closed e2419143665726 ∧ code e2419143665726 = 11215236687934 := by decide
theorem cert_e2419143665726 : check e2419143665726 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143666146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419143666146 : Closed e2419143666146 ∧ code e2419143666146 = 11215236688354 := by decide
theorem cert_e2419143666146 : check e2419143666146 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143666158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2419143666158 : Closed e2419143666158 ∧ code e2419143666158 = 11215236688366 := by decide
theorem cert_e2419143666158 : check e2419143666158 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143666926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143666926 : Closed e2419143666926 ∧ code e2419143666926 = 11215236689134 := by decide
theorem cert_e2419143666926 : check e2419143666926 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143666934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143666934 : Closed e2419143666934 ∧ code e2419143666934 = 11215236689142 := by decide
theorem cert_e2419143666934 : check e2419143666934 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143667214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419143667214 : Closed e2419143667214 ∧ code e2419143667214 = 11215236689422 := by decide
theorem cert_e2419143667214 : check e2419143667214 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143667226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143667226 : Closed e2419143667226 ∧ code e2419143667226 = 11215236689434 := by decide
theorem cert_e2419143667226 : check e2419143667226 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143667298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419143667298 : Closed e2419143667298 ∧ code e2419143667298 = 11215236689506 := by decide
theorem cert_e2419143667298 : check e2419143667298 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143667310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143667310 : Closed e2419143667310 ∧ code e2419143667310 = 11215236689518 := by decide
theorem cert_e2419143667310 : check e2419143667310 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143667318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419143667318 : Closed e2419143667318 ∧ code e2419143667318 = 11215236689526 := by decide
theorem cert_e2419143667318 : check e2419143667318 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143667322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143667322 : Closed e2419143667322 ∧ code e2419143667322 = 11215236689530 := by decide
theorem cert_e2419143667322 : check e2419143667322 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143667830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2419143667830 : Closed e2419143667830 ∧ code e2419143667830 = 11215236690038 := by decide
theorem cert_e2419143667830 : check e2419143667830 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143667834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2419143667834 : Closed e2419143667834 ∧ code e2419143667834 = 11215236690042 := by decide
theorem cert_e2419143667834 : check e2419143667834 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143667926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2419143667926 : Closed e2419143667926 ∧ code e2419143667926 = 11215236690134 := by decide
theorem cert_e2419143667926 : check e2419143667926 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143668022 : Closed e2419143668022 ∧ code e2419143668022 = 11215236690230 := by decide
theorem cert_e2419143668022 : check e2419143668022 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143668026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143668026 : Closed e2419143668026 ∧ code e2419143668026 = 11215236690234 := by decide
theorem cert_e2419143668026 : check e2419143668026 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2419143668110 : Closed e2419143668110 ∧ code e2419143668110 = 11215236690318 := by decide
theorem cert_e2419143668110 : checkPay e2419143668110 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e2419143668166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2419143668166 : Closed e2419143668166 ∧ code e2419143668166 = 11215236690374 := by decide
theorem cert_e2419143668166 : check e2419143668166 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143668502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2419143668502 : Closed e2419143668502 ∧ code e2419143668502 = 11215236690710 := by decide
theorem cert_e2419143668502 : check e2419143668502 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2419143668578 : Closed e2419143668578 ∧ code e2419143668578 = 11215236690786 := by decide
theorem cert_e2419143668578 : check e2419143668578 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2419143668590 : Closed e2419143668590 ∧ code e2419143668590 = 11215236690798 := by decide
theorem cert_e2419143668590 : check e2419143668590 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143668598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2419143668598 : Closed e2419143668598 ∧ code e2419143668598 = 11215236690806 := by decide
theorem cert_e2419143668598 : check e2419143668598 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419143668618 : Closed e2419143668618 ∧ code e2419143668618 = 11215236690826 := by decide
theorem cert_e2419143668618 : check e2419143668618 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419143668642 : Closed e2419143668642 ∧ code e2419143668642 = 11215236690850 := by decide
theorem cert_e2419143668642 : check e2419143668642 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143668654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2419143668654 : Closed e2419143668654 ∧ code e2419143668654 = 11215236690862 := by decide
theorem cert_e2419143668654 : check e2419143668654 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143668662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e2419143668662 : Closed e2419143668662 ∧ code e2419143668662 = 11215236690870 := by decide
theorem cert_e2419143668662 : check e2419143668662 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2419143668666 : Closed e2419143668666 ∧ code e2419143668666 = 11215236690874 := by decide
theorem cert_e2419143668666 : check e2419143668666 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2419143668694 : Closed e2419143668694 ∧ code e2419143668694 = 11215236690902 := by decide
theorem cert_e2419143668694 : check e2419143668694 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2419143668698 : Closed e2419143668698 ∧ code e2419143668698 = 11215236690906 := by decide
def e2419143668766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2419143668766 : Closed e2419143668766 ∧ code e2419143668766 = 11215236690974 := by decide
theorem cert_e2419143668766 : check e2419143668766 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143668962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419143668962 : Closed e2419143668962 ∧ code e2419143668962 = 11215236691170 := by decide
theorem cert_e2419143668962 : check e2419143668962 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143668974 : Closed e2419143668974 ∧ code e2419143668974 = 11215236691182 := by decide
theorem cert_e2419143668974 : check e2419143668974 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143668982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143668982 : Closed e2419143668982 ∧ code e2419143668982 = 11215236691190 := by decide
def e2419143669262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419143669262 : Closed e2419143669262 ∧ code e2419143669262 = 11215236691470 := by decide
theorem cert_e2419143669262 : check e2419143669262 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143669274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143669274 : Closed e2419143669274 ∧ code e2419143669274 = 11215236691482 := by decide
theorem cert_e2419143669274 : check e2419143669274 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143669346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419143669346 : Closed e2419143669346 ∧ code e2419143669346 = 11215236691554 := by decide
theorem cert_e2419143669346 : check e2419143669346 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143669358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143669358 : Closed e2419143669358 ∧ code e2419143669358 = 11215236691566 := by decide
def e2419143669366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419143669366 : Closed e2419143669366 ∧ code e2419143669366 = 11215236691574 := by decide
theorem cert_e2419143669366 : check e2419143669366 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143669370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143669370 : Closed e2419143669370 ∧ code e2419143669370 = 11215236691578 := by decide
def e2419143669558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143669558 : Closed e2419143669558 ∧ code e2419143669558 = 11215236691766 := by decide
theorem cert_e2419143669558 : check e2419143669558 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143669562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143669562 : Closed e2419143669562 ∧ code e2419143669562 = 11215236691770 := by decide
theorem cert_e2419143669562 : check e2419143669562 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143674734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419143674734 : Closed e2419143674734 ∧ code e2419143674734 = 11215236696942 := by decide
theorem cert_e2419143674734 : check e2419143674734 [[],[]] .smaller = true := by decide
def e2419143674742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419143674742 : Closed e2419143674742 ∧ code e2419143674742 = 11215236696950 := by decide
theorem cert_e2419143674742 : check e2419143674742 [[],[]] .smaller = true := by decide
def e2419143674798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419143674798 : Closed e2419143674798 ∧ code e2419143674798 = 11215236697006 := by decide
theorem cert_e2419143674798 : check e2419143674798 [[],[]] .smaller = true := by decide
def e2419143674810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419143674810 : Closed e2419143674810 ∧ code e2419143674810 = 11215236697018 := by decide
theorem cert_e2419143674810 : check e2419143674810 [[],[]] .smaller = true := by decide
def e2419143674838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419143674838 : Closed e2419143674838 ∧ code e2419143674838 = 11215236697046 := by decide
theorem cert_e2419143674838 : check e2419143674838 [[],[]] .smaller = true := by decide
def e2419143674842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419143674842 : Closed e2419143674842 ∧ code e2419143674842 = 11215236697050 := by decide
theorem cert_e2419143674842 : check e2419143674842 [[],[]] .smaller = true := by decide
def e2419143675118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419143675118 : Closed e2419143675118 ∧ code e2419143675118 = 11215236697326 := by decide
theorem cert_e2419143675118 : check e2419143675118 [[],[]] .smaller = true := by decide
def e2419143675126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419143675126 : Closed e2419143675126 ∧ code e2419143675126 = 11215236697334 := by decide
theorem cert_e2419143675126 : check e2419143675126 [[],[]] .smaller = true := by decide
def e2419143675502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419143675502 : Closed e2419143675502 ∧ code e2419143675502 = 11215236697710 := by decide
theorem cert_e2419143675502 : check e2419143675502 [[],[]] .smaller = true := by decide
def e2419143675514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419143675514 : Closed e2419143675514 ∧ code e2419143675514 = 11215236697722 := by decide
theorem cert_e2419143675514 : check e2419143675514 [[],[]] .smaller = true := by decide
def e2419143675702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419143675702 : Closed e2419143675702 ∧ code e2419143675702 = 11215236697910 := by decide
theorem cert_e2419143675702 : check e2419143675702 [[],[]] .smaller = true := by decide
def e2419143675706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419143675706 : Closed e2419143675706 ∧ code e2419143675706 = 11215236697914 := by decide
theorem cert_e2419143675706 : check e2419143675706 [[],[]] .smaller = true := by decide
def e2419143683630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2419143683630 : Closed e2419143683630 ∧ code e2419143683630 = 11215236705838 := by decide
theorem cert_e2419143683630 : check e2419143683630 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2419143683810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2419143683810 : Closed e2419143683810 ∧ code e2419143683810 = 11215236706018 := by decide
theorem cert_e2419143683810 : check e2419143683810 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2419143683822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2419143683822 : Closed e2419143683822 ∧ code e2419143683822 = 11215236706030 := by decide
theorem cert_e2419143683822 : check e2419143683822 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2419143683862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2419143683862 : Closed e2419143683862 ∧ code e2419143683862 = 11215236706070 := by decide
theorem cert_e2419143683862 : check e2419143683862 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143683938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2419143683938 : Closed e2419143683938 ∧ code e2419143683938 = 11215236706146 := by decide
theorem cert_e2419143683938 : check e2419143683938 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143683950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2419143683950 : Closed e2419143683950 ∧ code e2419143683950 = 11215236706158 := by decide
def e2419143683958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2419143683958 : Closed e2419143683958 ∧ code e2419143683958 = 11215236706166 := by decide
theorem cert_e2419143683958 : check e2419143683958 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143686206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2419143686206 : Closed e2419143686206 ∧ code e2419143686206 = 11215236708414 := by decide
theorem cert_e2419143686206 : check e2419143686206 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2419143686626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2419143686626 : Closed e2419143686626 ∧ code e2419143686626 = 11215236708834 := by decide
theorem cert_e2419143686626 : check e2419143686626 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2419143686638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419143686638 : Closed e2419143686638 ∧ code e2419143686638 = 11215236708846 := by decide
theorem cert_e2419143686638 : check e2419143686638 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2419143687198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2419143687198 : Closed e2419143687198 ∧ code e2419143687198 = 11215236709406 := by decide
theorem cert_e2419143687198 : check e2419143687198 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143687394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2419143687394 : Closed e2419143687394 ∧ code e2419143687394 = 11215236709602 := by decide
theorem cert_e2419143687394 : check e2419143687394 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143687406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419143687406 : Closed e2419143687406 ∧ code e2419143687406 = 11215236709614 := by decide
theorem cert_e2419143687406 : check e2419143687406 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143687414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419143687414 : Closed e2419143687414 ∧ code e2419143687414 = 11215236709622 := by decide
theorem cert_e2419143687414 : check e2419143687414 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143706590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e2419143706590 : Closed e2419143706590 ∧ code e2419143706590 = 11215236728798 := by decide
theorem cert_e2419143706590 : check e2419143706590 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2419143710254 : Closed e2419143710254 ∧ code e2419143710254 = 11215236732462 := by decide
theorem cert_e2419143710254 : check e2419143710254 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2419143710434 : Closed e2419143710434 ∧ code e2419143710434 = 11215236732642 := by decide
theorem cert_e2419143710434 : check e2419143710434 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2419143710446 : Closed e2419143710446 ∧ code e2419143710446 = 11215236732654 := by decide
theorem cert_e2419143710446 : check e2419143710446 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2419143710574 : Closed e2419143710574 ∧ code e2419143710574 = 11215236732782 := by decide
theorem cert_e2419143710574 : check e2419143710574 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2419143710582 : Closed e2419143710582 ∧ code e2419143710582 = 11215236732790 := by decide
theorem cert_e2419143710582 : check e2419143710582 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419143710602 : Closed e2419143710602 ∧ code e2419143710602 = 11215236732810 := by decide
theorem cert_e2419143710602 : check e2419143710602 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419143710626 : Closed e2419143710626 ∧ code e2419143710626 = 11215236732834 := by decide
theorem cert_e2419143710626 : check e2419143710626 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2419143710638 : Closed e2419143710638 ∧ code e2419143710638 = 11215236732846 := by decide
theorem cert_e2419143710638 : check e2419143710638 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2419143710646 : Closed e2419143710646 ∧ code e2419143710646 = 11215236732854 := by decide
theorem cert_e2419143710646 : check e2419143710646 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2419143710650 : Closed e2419143710650 ∧ code e2419143710650 = 11215236732858 := by decide
theorem cert_e2419143710650 : check e2419143710650 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143710782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2419143710782 : Closed e2419143710782 ∧ code e2419143710782 = 11215236732990 := by decide
theorem cert_e2419143710782 : check e2419143710782 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143711202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2419143711202 : Closed e2419143711202 ∧ code e2419143711202 = 11215236733410 := by decide
theorem cert_e2419143711202 : check e2419143711202 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143711214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419143711214 : Closed e2419143711214 ∧ code e2419143711214 = 11215236733422 := by decide
theorem cert_e2419143711214 : check e2419143711214 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143711982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419143711982 : Closed e2419143711982 ∧ code e2419143711982 = 11215236734190 := by decide
theorem cert_e2419143711982 : check e2419143711982 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143711990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419143711990 : Closed e2419143711990 ∧ code e2419143711990 = 11215236734198 := by decide
theorem cert_e2419143711990 : check e2419143711990 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143712270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2419143712270 : Closed e2419143712270 ∧ code e2419143712270 = 11215236734478 := by decide
theorem cert_e2419143712270 : check e2419143712270 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143712282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2419143712282 : Closed e2419143712282 ∧ code e2419143712282 = 11215236734490 := by decide
theorem cert_e2419143712282 : check e2419143712282 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143712354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419143712354 : Closed e2419143712354 ∧ code e2419143712354 = 11215236734562 := by decide
theorem cert_e2419143712354 : check e2419143712354 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143712366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419143712366 : Closed e2419143712366 ∧ code e2419143712366 = 11215236734574 := by decide
theorem cert_e2419143712366 : check e2419143712366 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143712374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419143712374 : Closed e2419143712374 ∧ code e2419143712374 = 11215236734582 := by decide
theorem cert_e2419143712374 : check e2419143712374 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143712378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419143712378 : Closed e2419143712378 ∧ code e2419143712378 = 11215236734586 := by decide
theorem cert_e2419143712378 : check e2419143712378 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143721950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2419143721950 : Closed e2419143721950 ∧ code e2419143721950 = 11215236744158 := by decide
theorem cert_e2419143721950 : check e2419143721950 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143721966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2419143721966 : Closed e2419143721966 ∧ code e2419143721966 = 11215236744174 := by decide
theorem cert_e2419143721966 : check e2419143721966 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2419143723798 : Closed e2419143723798 ∧ code e2419143723798 = 11215236746006 := by decide
theorem cert_e2419143723798 : check e2419143723798 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2419143723874 : Closed e2419143723874 ∧ code e2419143723874 = 11215236746082 := by decide
theorem cert_e2419143723874 : check e2419143723874 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419143723886 : Closed e2419143723886 ∧ code e2419143723886 = 11215236746094 := by decide
theorem cert_e2419143723886 : check e2419143723886 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419143723894 : Closed e2419143723894 ∧ code e2419143723894 = 11215236746102 := by decide
theorem cert_e2419143723894 : check e2419143723894 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419143723914 : Closed e2419143723914 ∧ code e2419143723914 = 11215236746122 := by decide
theorem cert_e2419143723914 : check e2419143723914 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419143723938 : Closed e2419143723938 ∧ code e2419143723938 = 11215236746146 := by decide
theorem cert_e2419143723938 : check e2419143723938 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419143723950 : Closed e2419143723950 ∧ code e2419143723950 = 11215236746158 := by decide
theorem cert_e2419143723950 : check e2419143723950 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e2419143723958 : Closed e2419143723958 ∧ code e2419143723958 = 11215236746166 := by decide
theorem cert_e2419143723958 : check e2419143723958 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419143723962 : Closed e2419143723962 ∧ code e2419143723962 = 11215236746170 := by decide
theorem cert_e2419143723962 : check e2419143723962 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419143723990 : Closed e2419143723990 ∧ code e2419143723990 = 11215236746198 := by decide
theorem cert_e2419143723990 : check e2419143723990 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143723994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419143723994 : Closed e2419143723994 ∧ code e2419143723994 = 11215236746202 := by decide
theorem cert_e2419143723994 : check e2419143723994 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2419143724062 : Closed e2419143724062 ∧ code e2419143724062 = 11215236746270 := by decide
theorem cert_e2419143724062 : check e2419143724062 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2419143724258 : Closed e2419143724258 ∧ code e2419143724258 = 11215236746466 := by decide
theorem cert_e2419143724258 : check e2419143724258 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419143724270 : Closed e2419143724270 ∧ code e2419143724270 = 11215236746478 := by decide
theorem cert_e2419143724270 : check e2419143724270 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419143724278 : Closed e2419143724278 ∧ code e2419143724278 = 11215236746486 := by decide
theorem cert_e2419143724278 : check e2419143724278 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2419143724558 : Closed e2419143724558 ∧ code e2419143724558 = 11215236746766 := by decide
theorem cert_e2419143724558 : check e2419143724558 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2419143724570 : Closed e2419143724570 ∧ code e2419143724570 = 11215236746778 := by decide
theorem cert_e2419143724570 : check e2419143724570 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419143724642 : Closed e2419143724642 ∧ code e2419143724642 = 11215236746850 := by decide
theorem cert_e2419143724642 : check e2419143724642 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419143724654 : Closed e2419143724654 ∧ code e2419143724654 = 11215236746862 := by decide
theorem cert_e2419143724654 : check e2419143724654 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419143724662 : Closed e2419143724662 ∧ code e2419143724662 = 11215236746870 := by decide
theorem cert_e2419143724662 : check e2419143724662 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419143724666 : Closed e2419143724666 ∧ code e2419143724666 = 11215236746874 := by decide
theorem cert_e2419143724666 : check e2419143724666 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419143724854 : Closed e2419143724854 ∧ code e2419143724854 = 11215236747062 := by decide
theorem cert_e2419143724854 : check e2419143724854 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419143724858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419143724858 : Closed e2419143724858 ∧ code e2419143724858 = 11215236747066 := by decide
theorem cert_e2419143724858 : check e2419143724858 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2419144005342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2419144005342 : Closed e2419144005342 ∧ code e2419144005342 = 11215237027550 := by decide
theorem cert_e2419144005342 : check e2419144005342 [[],[]] .smaller = true := by decide
def e2419144005366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2419144005366 : Closed e2419144005366 ∧ code e2419144005366 = 11215237027574 := by decide
theorem cert_e2419144005366 : check e2419144005366 [[],[]] .smaller = true := by decide
def e2419144005470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2419144005470 : Closed e2419144005470 ∧ code e2419144005470 = 11215237027678 := by decide
theorem cert_e2419144005470 : check e2419144005470 [[],[]] .smaller = true := by decide
def e2419144005498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2419144005498 : Closed e2419144005498 ∧ code e2419144005498 = 11215237027706 := by decide
theorem cert_e2419144005498 : check e2419144005498 [[],[]] .smaller = true := by decide
def e2419144005590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2419144005590 : Closed e2419144005590 ∧ code e2419144005590 = 11215237027798 := by decide
theorem cert_e2419144005590 : check e2419144005590 [[],[]] .smaller = true := by decide
def e2419144005594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2419144005594 : Closed e2419144005594 ∧ code e2419144005594 = 11215237027802 := by decide
theorem cert_e2419144005594 : check e2419144005594 [[],[]] .smaller = true := by decide
def e2419144006110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2419144006110 : Closed e2419144006110 ∧ code e2419144006110 = 11215237028318 := by decide
theorem cert_e2419144006110 : check e2419144006110 [[],[]] .smaller = true := by decide
def e2419144006134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2419144006134 : Closed e2419144006134 ∧ code e2419144006134 = 11215237028342 := by decide
theorem cert_e2419144006134 : check e2419144006134 [[],[]] .smaller = true := by decide
def e2419144006878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2419144006878 : Closed e2419144006878 ∧ code e2419144006878 = 11215237029086 := by decide
theorem cert_e2419144006878 : check e2419144006878 [[],[]] .smaller = true := by decide
def e2419144006906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2419144006906 : Closed e2419144006906 ∧ code e2419144006906 = 11215237029114 := by decide
theorem cert_e2419144006906 : check e2419144006906 [[],[]] .smaller = true := by decide
def e2419144007478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419144007478 : Closed e2419144007478 ∧ code e2419144007478 = 11215237029686 := by decide
theorem cert_e2419144007478 : check e2419144007478 [[],[]] .smaller = true := by decide
def e2419144007482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419144007482 : Closed e2419144007482 ∧ code e2419144007482 = 11215237029690 := by decide
theorem cert_e2419144007482 : check e2419144007482 [[],[]] .smaller = true := by decide
def e2419144022254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2419144022254 : Closed e2419144022254 ∧ code e2419144022254 = 11215237044462 := by decide
theorem cert_e2419144022254 : check e2419144022254 [[],[]] .smaller = true := by decide
def e2419144022262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2419144022262 : Closed e2419144022262 ∧ code e2419144022262 = 11215237044470 := by decide
theorem cert_e2419144022262 : check e2419144022262 [[],[]] .smaller = true := by decide
def e2419144022814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2419144022814 : Closed e2419144022814 ∧ code e2419144022814 = 11215237045022 := by decide
theorem cert_e2419144022814 : check e2419144022814 [[],[]] .smaller = true := by decide
def e2419144022926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2419144022926 : Closed e2419144022926 ∧ code e2419144022926 = 11215237045134 := by decide
theorem cert_e2419144022926 : check e2419144022926 [[],[]] .smaller = true := by decide
def e2419144023150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2419144023150 : Closed e2419144023150 ∧ code e2419144023150 = 11215237045358 := by decide
theorem cert_e2419144023150 : check e2419144023150 [[],[]] .smaller = true := by decide
def e2419144023162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2419144023162 : Closed e2419144023162 ∧ code e2419144023162 = 11215237045370 := by decide
theorem cert_e2419144023162 : check e2419144023162 [[],[]] .smaller = true := by decide
def e2419144023326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2419144023326 : Closed e2419144023326 ∧ code e2419144023326 = 11215237045534 := by decide
theorem cert_e2419144023326 : check e2419144023326 [[],[]] .smaller = true := by decide
def e2419144023494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2419144023494 : Closed e2419144023494 ∧ code e2419144023494 = 11215237045702 := by decide
theorem cert_e2419144023494 : check e2419144023494 [[],[]] .smaller = true := by decide
def e2419144023518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2419144023518 : Closed e2419144023518 ∧ code e2419144023518 = 11215237045726 := by decide
theorem cert_e2419144023518 : check e2419144023518 [[],[]] .sourceHead = true := by decide
def e2419144023534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2419144023534 : Closed e2419144023534 ∧ code e2419144023534 = 11215237045742 := by decide
theorem cert_e2419144023534 : check e2419144023534 [[],[]] .sourceHead = true := by decide
def e2419144023606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2419144023606 : Closed e2419144023606 ∧ code e2419144023606 = 11215237045814 := by decide
theorem cert_e2419144023606 : check e2419144023606 [[],[]] .smaller = true := by decide
def e2419144023610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2419144023610 : Closed e2419144023610 ∧ code e2419144023610 = 11215237045818 := by decide
theorem cert_e2419144023610 : check e2419144023610 [[],[]] .smaller = true := by decide
def e2419144023694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2419144023694 : Closed e2419144023694 ∧ code e2419144023694 = 11215237045902 := by decide
theorem cert_e2419144023694 : check e2419144023694 [[],[]] .smaller = true := by decide
def e2419144023750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2419144023750 : Closed e2419144023750 ∧ code e2419144023750 = 11215237045958 := by decide
theorem cert_e2419144023750 : check e2419144023750 [[],[]] .smaller = true := by decide
def e2419144023774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2419144023774 : Closed e2419144023774 ∧ code e2419144023774 = 11215237045982 := by decide
theorem cert_e2419144023774 : check e2419144023774 [[],[]] .sourceHead = true := by decide
def e2419144023798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2419144023798 : Closed e2419144023798 ∧ code e2419144023798 = 11215237046006 := by decide
theorem cert_e2419144023798 : check e2419144023798 [[],[]] .sourceHead = true := by decide
def e2419144023918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2419144023918 : Closed e2419144023918 ∧ code e2419144023918 = 11215237046126 := by decide
theorem cert_e2419144023918 : check e2419144023918 [[],[]] .sourceHead = true := by decide
end Blc.Floor43
