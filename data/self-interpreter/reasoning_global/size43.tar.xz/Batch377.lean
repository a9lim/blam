import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364495098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364495098 : Closed e2422364495098 ∧ code e2422364495098 = 11218457517306 := by decide
theorem cert_e2422364495098 : check e2422364495098 [[],[]] .smaller = true := by decide
def e2422364495470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364495470 : Closed e2422364495470 ∧ code e2422364495470 = 11218457517678 := by decide
theorem cert_e2422364495470 : check e2422364495470 [[],[]] .smaller = true := by decide
def e2422364495478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364495478 : Closed e2422364495478 ∧ code e2422364495478 = 11218457517686 := by decide
theorem cert_e2422364495478 : check e2422364495478 [[],[]] .smaller = true := by decide
def e2422364495482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364495482 : Closed e2422364495482 ∧ code e2422364495482 = 11218457517690 := by decide
theorem cert_e2422364495482 : check e2422364495482 [[],[]] .smaller = true := by decide
def e2422364495646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.lam (.var 3)))))))))
theorem wire_e2422364495646 : Closed e2422364495646 ∧ code e2422364495646 = 11218457517854 := by decide
theorem cert_e2422364495646 : check e2422364495646 [[],[]] .three = true := by decide
def e2422364495670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364495670 : Closed e2422364495670 ∧ code e2422364495670 = 11218457517878 := by decide
theorem cert_e2422364495670 : check e2422364495670 [[],[]] .three = true := by decide
def e2422364495674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364495674 : Closed e2422364495674 ∧ code e2422364495674 = 11218457517882 := by decide
theorem cert_e2422364495674 : check e2422364495674 [[],[]] .three = true := by decide
def e2422364496110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2))))))))
theorem wire_e2422364496110 : Closed e2422364496110 ∧ code e2422364496110 = 11218457518318 := by decide
theorem cert_e2422364496110 : check e2422364496110 [[],[]] .smaller = true := by decide
def e2422364496122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))))))
theorem wire_e2422364496122 : Closed e2422364496122 ∧ code e2422364496122 = 11218457518330 := by decide
theorem cert_e2422364496122 : check e2422364496122 [[],[]] .smaller = true := by decide
def e2422364496302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))))
theorem wire_e2422364496302 : Closed e2422364496302 ∧ code e2422364496302 = 11218457518510 := by decide
theorem cert_e2422364496302 : check e2422364496302 [[],[]] .smaller = true := by decide
def e2422364496494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364496494 : Closed e2422364496494 ∧ code e2422364496494 = 11218457518702 := by decide
theorem cert_e2422364496494 : check e2422364496494 [[],[]] .smaller = true := by decide
def e2422364496506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364496506 : Closed e2422364496506 ∧ code e2422364496506 = 11218457518714 := by decide
theorem cert_e2422364496506 : check e2422364496506 [[],[]] .smaller = true := by decide
def e2422364496670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3)))))))))
theorem wire_e2422364496670 : Closed e2422364496670 ∧ code e2422364496670 = 11218457518878 := by decide
theorem cert_e2422364496670 : check e2422364496670 [[],[]] .smaller = true := by decide
def e2422364496830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 4))))))))
theorem wire_e2422364496830 : Closed e2422364496830 ∧ code e2422364496830 = 11218457519038 := by decide
theorem cert_e2422364496830 : check e2422364496830 [[],[]] .three = true := by decide
def e2422364496838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1)))))))))
theorem wire_e2422364496838 : Closed e2422364496838 ∧ code e2422364496838 = 11218457519046 := by decide
theorem cert_e2422364496838 : check e2422364496838 [[],[]] .smaller = true := by decide
def e2422364496886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 5)))) (.var 1))))))))
theorem wire_e2422364496886 : Closed e2422364496886 ∧ code e2422364496886 = 11218457519094 := by decide
theorem cert_e2422364496886 : check e2422364496886 [[],[]] .three = true := by decide
def e2422364497454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))))
theorem wire_e2422364497454 : Closed e2422364497454 ∧ code e2422364497454 = 11218457519662 := by decide
theorem cert_e2422364497454 : check e2422364497454 [[],[]] .smaller = true := by decide
def e2422364497598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 4))))))))
theorem wire_e2422364497598 : Closed e2422364497598 ∧ code e2422364497598 = 11218457519806 := by decide
theorem cert_e2422364497598 : check e2422364497598 [[],[]] .three = true := by decide
def e2422364497630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 3))))))))
theorem wire_e2422364497630 : Closed e2422364497630 ∧ code e2422364497630 = 11218457519838 := by decide
theorem cert_e2422364497630 : check e2422364497630 [[],[]] .smaller = true := by decide
def e2422364497634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))))
theorem wire_e2422364497634 : Closed e2422364497634 ∧ code e2422364497634 = 11218457519842 := by decide
theorem cert_e2422364497634 : check e2422364497634 [[],[]] .smaller = true := by decide
def e2422364497646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))))))
theorem wire_e2422364497646 : Closed e2422364497646 ∧ code e2422364497646 = 11218457519854 := by decide
theorem cert_e2422364497646 : check e2422364497646 [[],[]] .smaller = true := by decide
def e2422364497654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 1))))))))
theorem wire_e2422364497654 : Closed e2422364497654 ∧ code e2422364497654 = 11218457519862 := by decide
theorem cert_e2422364497654 : check e2422364497654 [[],[]] .smaller = true := by decide
def e2422364497658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 4)))) (.var 0))))))))
theorem wire_e2422364497658 : Closed e2422364497658 ∧ code e2422364497658 = 11218457519866 := by decide
theorem cert_e2422364497658 : check e2422364497658 [[],[]] .three = true := by decide
def e2422364497758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 3))))))))
theorem wire_e2422364497758 : Closed e2422364497758 ∧ code e2422364497758 = 11218457519966 := by decide
theorem cert_e2422364497758 : check e2422364497758 [[],[]] .smaller = true := by decide
def e2422364497774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e2422364497774 : Closed e2422364497774 ∧ code e2422364497774 = 11218457519982 := by decide
theorem cert_e2422364497774 : check e2422364497774 [[],[]] .smaller = true := by decide
def e2422364497782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 1))))))))
theorem wire_e2422364497782 : Closed e2422364497782 ∧ code e2422364497782 = 11218457519990 := by decide
theorem cert_e2422364497782 : check e2422364497782 [[],[]] .smaller = true := by decide
def e2422364497786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e2422364497786 : Closed e2422364497786 ∧ code e2422364497786 = 11218457519994 := by decide
theorem cert_e2422364497786 : check e2422364497786 [[],[]] .smaller = true := by decide
def e2422364497802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422364497802 : Closed e2422364497802 ∧ code e2422364497802 = 11218457520010 := by decide
theorem cert_e2422364497802 : check e2422364497802 [[],[]] .smaller = true := by decide
def e2422364497826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))))
theorem wire_e2422364497826 : Closed e2422364497826 ∧ code e2422364497826 = 11218457520034 := by decide
theorem cert_e2422364497826 : check e2422364497826 [[],[]] .smaller = true := by decide
def e2422364497838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))))))
theorem wire_e2422364497838 : Closed e2422364497838 ∧ code e2422364497838 = 11218457520046 := by decide
theorem cert_e2422364497838 : check e2422364497838 [[],[]] .smaller = true := by decide
def e2422364497846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 1))))))))
theorem wire_e2422364497846 : Closed e2422364497846 ∧ code e2422364497846 = 11218457520054 := by decide
theorem cert_e2422364497846 : check e2422364497846 [[],[]] .smaller = true := by decide
def e2422364497850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))))))
theorem wire_e2422364497850 : Closed e2422364497850 ∧ code e2422364497850 = 11218457520058 := by decide
theorem cert_e2422364497850 : check e2422364497850 [[],[]] .smaller = true := by decide
def e2422364497878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 1))))))))
theorem wire_e2422364497878 : Closed e2422364497878 ∧ code e2422364497878 = 11218457520086 := by decide
theorem cert_e2422364497878 : check e2422364497878 [[],[]] .smaller = true := by decide
def e2422364497882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e2422364497882 : Closed e2422364497882 ∧ code e2422364497882 = 11218457520090 := by decide
theorem cert_e2422364497882 : check e2422364497882 [[],[]] .smaller = true := by decide
def e2422364497898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 0)))) (.var 0))))))))
theorem wire_e2422364497898 : Closed e2422364497898 ∧ code e2422364497898 = 11218457520106 := by decide
theorem cert_e2422364497898 : check e2422364497898 [[],[]] .three = true := by decide
def e2422364497982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4))))))))))
theorem wire_e2422364497982 : Closed e2422364497982 ∧ code e2422364497982 = 11218457520190 := by decide
theorem cert_e2422364497982 : check e2422364497982 [[],[]] .smaller = true := by decide
def e2422364498366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364498366 : Closed e2422364498366 ∧ code e2422364498366 = 11218457520574 := by decide
theorem cert_e2422364498366 : check e2422364498366 [[],[]] .three = true := by decide
def e2422364498398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364498398 : Closed e2422364498398 ∧ code e2422364498398 = 11218457520606 := by decide
theorem cert_e2422364498398 : check e2422364498398 [[],[]] .smaller = true := by decide
def e2422364498402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422364498402 : Closed e2422364498402 ∧ code e2422364498402 = 11218457520610 := by decide
theorem cert_e2422364498402 : check e2422364498402 [[],[]] .smaller = true := by decide
def e2422364498414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422364498414 : Closed e2422364498414 ∧ code e2422364498414 = 11218457520622 := by decide
theorem cert_e2422364498414 : check e2422364498414 [[],[]] .smaller = true := by decide
def e2422364498422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364498422 : Closed e2422364498422 ∧ code e2422364498422 = 11218457520630 := by decide
theorem cert_e2422364498422 : check e2422364498422 [[],[]] .smaller = true := by decide
def e2422364498426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364498426 : Closed e2422364498426 ∧ code e2422364498426 = 11218457520634 := by decide
theorem cert_e2422364498426 : check e2422364498426 [[],[]] .three = true := by decide
def e2422364499070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 5)))))))))
theorem wire_e2422364499070 : Closed e2422364499070 ∧ code e2422364499070 = 11218457521278 := by decide
theorem cert_e2422364499070 : check e2422364499070 [[],[]] .three = true := by decide
def e2422364499166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364499166 : Closed e2422364499166 ∧ code e2422364499166 = 11218457521374 := by decide
theorem cert_e2422364499166 : check e2422364499166 [[],[]] .smaller = true := by decide
def e2422364499182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364499182 : Closed e2422364499182 ∧ code e2422364499182 = 11218457521390 := by decide
theorem cert_e2422364499182 : check e2422364499182 [[],[]] .smaller = true := by decide
def e2422364499190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364499190 : Closed e2422364499190 ∧ code e2422364499190 = 11218457521398 := by decide
theorem cert_e2422364499190 : check e2422364499190 [[],[]] .smaller = true := by decide
def e2422364499194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364499194 : Closed e2422364499194 ∧ code e2422364499194 = 11218457521402 := by decide
theorem cert_e2422364499194 : check e2422364499194 [[],[]] .smaller = true := by decide
def e2422364499470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364499470 : Closed e2422364499470 ∧ code e2422364499470 = 11218457521678 := by decide
theorem cert_e2422364499470 : check e2422364499470 [[],[]] .smaller = true := by decide
def e2422364499482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364499482 : Closed e2422364499482 ∧ code e2422364499482 = 11218457521690 := by decide
theorem cert_e2422364499482 : check e2422364499482 [[],[]] .smaller = true := by decide
def e2422364499554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364499554 : Closed e2422364499554 ∧ code e2422364499554 = 11218457521762 := by decide
theorem cert_e2422364499554 : check e2422364499554 [[],[]] .smaller = true := by decide
def e2422364499566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364499566 : Closed e2422364499566 ∧ code e2422364499566 = 11218457521774 := by decide
theorem cert_e2422364499566 : check e2422364499566 [[],[]] .smaller = true := by decide
def e2422364499574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364499574 : Closed e2422364499574 ∧ code e2422364499574 = 11218457521782 := by decide
theorem cert_e2422364499574 : check e2422364499574 [[],[]] .smaller = true := by decide
def e2422364499578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364499578 : Closed e2422364499578 ∧ code e2422364499578 = 11218457521786 := by decide
theorem cert_e2422364499578 : check e2422364499578 [[],[]] .smaller = true := by decide
def e2422364499766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364499766 : Closed e2422364499766 ∧ code e2422364499766 = 11218457521974 := by decide
theorem cert_e2422364499766 : check e2422364499766 [[],[]] .smaller = true := by decide
def e2422364499770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364499770 : Closed e2422364499770 ∧ code e2422364499770 = 11218457521978 := by decide
theorem cert_e2422364499770 : check e2422364499770 [[],[]] .smaller = true := by decide
def e2422364499854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.lam (.var 2)))))))))
theorem wire_e2422364499854 : Closed e2422364499854 ∧ code e2422364499854 = 11218457522062 := by decide
theorem cert_e2422364499854 : check e2422364499854 [[],[]] .three = true := by decide
def e2422364499866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364499866 : Closed e2422364499866 ∧ code e2422364499866 = 11218457522074 := by decide
theorem cert_e2422364499866 : check e2422364499866 [[],[]] .three = true := by decide
def e2422364499902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 4))))))))
theorem wire_e2422364499902 : Closed e2422364499902 ∧ code e2422364499902 = 11218457522110 := by decide
theorem cert_e2422364499902 : check e2422364499902 [[],[]] .three = true := by decide
def e2422364500086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1))))))))
theorem wire_e2422364500086 : Closed e2422364500086 ∧ code e2422364500086 = 11218457522294 := by decide
theorem cert_e2422364500086 : check e2422364500086 [[],[]] .smaller = true := by decide
def e2422364500090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))))))
theorem wire_e2422364500090 : Closed e2422364500090 ∧ code e2422364500090 = 11218457522298 := by decide
theorem cert_e2422364500090 : check e2422364500090 [[],[]] .smaller = true := by decide
def e2422364500182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))))
theorem wire_e2422364500182 : Closed e2422364500182 ∧ code e2422364500182 = 11218457522390 := by decide
theorem cert_e2422364500182 : check e2422364500182 [[],[]] .smaller = true := by decide
def e2422364500278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364500278 : Closed e2422364500278 ∧ code e2422364500278 = 11218457522486 := by decide
theorem cert_e2422364500278 : check e2422364500278 [[],[]] .smaller = true := by decide
def e2422364500282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364500282 : Closed e2422364500282 ∧ code e2422364500282 = 11218457522490 := by decide
theorem cert_e2422364500282 : check e2422364500282 [[],[]] .smaller = true := by decide
def e2422364500366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2)))))))))
theorem wire_e2422364500366 : Closed e2422364500366 ∧ code e2422364500366 = 11218457522574 := by decide
theorem cert_e2422364500366 : check e2422364500366 [[],[]] .smaller = true := by decide
def e2422364500414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 4))))))))
theorem wire_e2422364500414 : Closed e2422364500414 ∧ code e2422364500414 = 11218457522622 := by decide
theorem cert_e2422364500414 : check e2422364500414 [[],[]] .three = true := by decide
def e2422364500422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1)))))))))
theorem wire_e2422364500422 : Closed e2422364500422 ∧ code e2422364500422 = 11218457522630 := by decide
theorem cert_e2422364500422 : check e2422364500422 [[],[]] .smaller = true := by decide
def e2422364500474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 5)))) (.var 0))))))))
theorem wire_e2422364500474 : Closed e2422364500474 ∧ code e2422364500474 = 11218457522682 := by decide
theorem cert_e2422364500474 : check e2422364500474 [[],[]] .three = true := by decide
def e2422364500758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))))
theorem wire_e2422364500758 : Closed e2422364500758 ∧ code e2422364500758 = 11218457522966 := by decide
theorem cert_e2422364500758 : check e2422364500758 [[],[]] .smaller = true := by decide
def e2422364500830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 3))))))))
theorem wire_e2422364500830 : Closed e2422364500830 ∧ code e2422364500830 = 11218457523038 := by decide
theorem cert_e2422364500830 : check e2422364500830 [[],[]] .smaller = true := by decide
def e2422364500834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))))
theorem wire_e2422364500834 : Closed e2422364500834 ∧ code e2422364500834 = 11218457523042 := by decide
theorem cert_e2422364500834 : check e2422364500834 [[],[]] .smaller = true := by decide
def e2422364500846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e2422364500846 : Closed e2422364500846 ∧ code e2422364500846 = 11218457523054 := by decide
theorem cert_e2422364500846 : check e2422364500846 [[],[]] .smaller = true := by decide
def e2422364500854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e2422364500854 : Closed e2422364500854 ∧ code e2422364500854 = 11218457523062 := by decide
theorem cert_e2422364500854 : check e2422364500854 [[],[]] .smaller = true := by decide
def e2422364500858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e2422364500858 : Closed e2422364500858 ∧ code e2422364500858 = 11218457523066 := by decide
theorem cert_e2422364500858 : check e2422364500858 [[],[]] .smaller = true := by decide
def e2422364500874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422364500874 : Closed e2422364500874 ∧ code e2422364500874 = 11218457523082 := by decide
theorem cert_e2422364500874 : check e2422364500874 [[],[]] .smaller = true := by decide
def e2422364500898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))))
theorem wire_e2422364500898 : Closed e2422364500898 ∧ code e2422364500898 = 11218457523106 := by decide
theorem cert_e2422364500898 : check e2422364500898 [[],[]] .smaller = true := by decide
def e2422364500910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e2422364500910 : Closed e2422364500910 ∧ code e2422364500910 = 11218457523118 := by decide
theorem cert_e2422364500910 : check e2422364500910 [[],[]] .smaller = true := by decide
def e2422364500918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e2422364500918 : Closed e2422364500918 ∧ code e2422364500918 = 11218457523126 := by decide
theorem cert_e2422364500918 : check e2422364500918 [[],[]] .smaller = true := by decide
def e2422364500922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e2422364500922 : Closed e2422364500922 ∧ code e2422364500922 = 11218457523130 := by decide
theorem cert_e2422364500922 : check e2422364500922 [[],[]] .smaller = true := by decide
def e2422364500950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e2422364500950 : Closed e2422364500950 ∧ code e2422364500950 = 11218457523158 := by decide
theorem cert_e2422364500950 : check e2422364500950 [[],[]] .smaller = true := by decide
def e2422364500954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e2422364500954 : Closed e2422364500954 ∧ code e2422364500954 = 11218457523162 := by decide
theorem cert_e2422364500954 : check e2422364500954 [[],[]] .smaller = true := by decide
def e2422364500970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e2422364500970 : Closed e2422364500970 ∧ code e2422364500970 = 11218457523178 := by decide
theorem cert_e2422364500970 : check e2422364500970 [[],[]] .smaller = true := by decide
def e2422364501022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3))))))))))
theorem wire_e2422364501022 : Closed e2422364501022 ∧ code e2422364501022 = 11218457523230 := by decide
theorem cert_e2422364501022 : check e2422364501022 [[],[]] .smaller = true := by decide
def e2422364501118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 5)))))))))
theorem wire_e2422364501118 : Closed e2422364501118 ∧ code e2422364501118 = 11218457523326 := by decide
theorem cert_e2422364501118 : check e2422364501118 [[],[]] .three = true := by decide
def e2422364501214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364501214 : Closed e2422364501214 ∧ code e2422364501214 = 11218457523422 := by decide
theorem cert_e2422364501214 : check e2422364501214 [[],[]] .smaller = true := by decide
def e2422364501218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422364501218 : Closed e2422364501218 ∧ code e2422364501218 = 11218457523426 := by decide
theorem cert_e2422364501218 : check e2422364501218 [[],[]] .smaller = true := by decide
def e2422364501230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364501230 : Closed e2422364501230 ∧ code e2422364501230 = 11218457523438 := by decide
theorem cert_e2422364501230 : check e2422364501230 [[],[]] .smaller = true := by decide
def e2422364501238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364501238 : Closed e2422364501238 ∧ code e2422364501238 = 11218457523446 := by decide
theorem cert_e2422364501238 : check e2422364501238 [[],[]] .smaller = true := by decide
def e2422364501242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364501242 : Closed e2422364501242 ∧ code e2422364501242 = 11218457523450 := by decide
theorem cert_e2422364501242 : check e2422364501242 [[],[]] .smaller = true := by decide
def e2422364501518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364501518 : Closed e2422364501518 ∧ code e2422364501518 = 11218457523726 := by decide
theorem cert_e2422364501518 : check e2422364501518 [[],[]] .smaller = true := by decide
def e2422364501530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364501530 : Closed e2422364501530 ∧ code e2422364501530 = 11218457523738 := by decide
theorem cert_e2422364501530 : check e2422364501530 [[],[]] .smaller = true := by decide
def e2422364501602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364501602 : Closed e2422364501602 ∧ code e2422364501602 = 11218457523810 := by decide
theorem cert_e2422364501602 : check e2422364501602 [[],[]] .smaller = true := by decide
def e2422364501614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364501614 : Closed e2422364501614 ∧ code e2422364501614 = 11218457523822 := by decide
theorem cert_e2422364501614 : check e2422364501614 [[],[]] .smaller = true := by decide
def e2422364501622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364501622 : Closed e2422364501622 ∧ code e2422364501622 = 11218457523830 := by decide
theorem cert_e2422364501622 : check e2422364501622 [[],[]] .smaller = true := by decide
def e2422364501626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364501626 : Closed e2422364501626 ∧ code e2422364501626 = 11218457523834 := by decide
theorem cert_e2422364501626 : check e2422364501626 [[],[]] .smaller = true := by decide
def e2422364501814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364501814 : Closed e2422364501814 ∧ code e2422364501814 = 11218457524022 := by decide
theorem cert_e2422364501814 : check e2422364501814 [[],[]] .smaller = true := by decide
def e2422364501818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364501818 : Closed e2422364501818 ∧ code e2422364501818 = 11218457524026 := by decide
theorem cert_e2422364501818 : check e2422364501818 [[],[]] .smaller = true := by decide
def e2422364501914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364501914 : Closed e2422364501914 ∧ code e2422364501914 = 11218457524122 := by decide
theorem cert_e2422364501914 : check e2422364501914 [[],[]] .smaller = true := by decide
def e2422364501958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 4))) (.lam (.var 1)))))))))
theorem wire_e2422364501958 : Closed e2422364501958 ∧ code e2422364501958 = 11218457524166 := by decide
theorem cert_e2422364501958 : check e2422364501958 [[],[]] .three = true := by decide
def e2422364502446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422364502446 : Closed e2422364502446 ∧ code e2422364502446 = 11218457524654 := by decide
theorem cert_e2422364502446 : check e2422364502446 [[],[]] .smaller = true := by decide
def e2422364502454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e2422364502454 : Closed e2422364502454 ∧ code e2422364502454 = 11218457524662 := by decide
theorem cert_e2422364502454 : check e2422364502454 [[],[]] .smaller = true := by decide
def e2422364502458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422364502458 : Closed e2422364502458 ∧ code e2422364502458 = 11218457524666 := by decide
theorem cert_e2422364502458 : check e2422364502458 [[],[]] .smaller = true := by decide
def e2422364502486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e2422364502486 : Closed e2422364502486 ∧ code e2422364502486 = 11218457524694 := by decide
theorem cert_e2422364502486 : check e2422364502486 [[],[]] .smaller = true := by decide
def e2422364502490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))) (.var 0))))))))
theorem wire_e2422364502490 : Closed e2422364502490 ∧ code e2422364502490 = 11218457524698 := by decide
theorem cert_e2422364502490 : check e2422364502490 [[],[]] .smaller = true := by decide
def e2422364502506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422364502506 : Closed e2422364502506 ∧ code e2422364502506 = 11218457524714 := by decide
theorem cert_e2422364502506 : check e2422364502506 [[],[]] .smaller = true := by decide
def e2422364502638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364502638 : Closed e2422364502638 ∧ code e2422364502638 = 11218457524846 := by decide
theorem cert_e2422364502638 : check e2422364502638 [[],[]] .smaller = true := by decide
def e2422364502646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364502646 : Closed e2422364502646 ∧ code e2422364502646 = 11218457524854 := by decide
theorem cert_e2422364502646 : check e2422364502646 [[],[]] .smaller = true := by decide
def e2422364502650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364502650 : Closed e2422364502650 ∧ code e2422364502650 = 11218457524858 := by decide
theorem cert_e2422364502650 : check e2422364502650 [[],[]] .smaller = true := by decide
def e2422364502838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364502838 : Closed e2422364502838 ∧ code e2422364502838 = 11218457525046 := by decide
theorem cert_e2422364502838 : check e2422364502838 [[],[]] .smaller = true := by decide
def e2422364502842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364502842 : Closed e2422364502842 ∧ code e2422364502842 = 11218457525050 := by decide
theorem cert_e2422364502842 : check e2422364502842 [[],[]] .smaller = true := by decide
def e2422364502938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364502938 : Closed e2422364502938 ∧ code e2422364502938 = 11218457525146 := by decide
theorem cert_e2422364502938 : check e2422364502938 [[],[]] .smaller = true := by decide
def e2422364503150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e2422364503150 : Closed e2422364503150 ∧ code e2422364503150 = 11218457525358 := by decide
theorem cert_e2422364503150 : check e2422364503150 [[],[]] .three = true := by decide
def e2422364503158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422364503158 : Closed e2422364503158 ∧ code e2422364503158 = 11218457525366 := by decide
theorem cert_e2422364503158 : check e2422364503158 [[],[]] .three = true := by decide
def e2422364503162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422364503162 : Closed e2422364503162 ∧ code e2422364503162 = 11218457525370 := by decide
theorem cert_e2422364503162 : check e2422364503162 [[],[]] .three = true := by decide
def e2422364503254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422364503254 : Closed e2422364503254 ∧ code e2422364503254 = 11218457525462 := by decide
theorem cert_e2422364503254 : check e2422364503254 [[],[]] .three = true := by decide
def e2422364503258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422364503258 : Closed e2422364503258 ∧ code e2422364503258 = 11218457525466 := by decide
theorem cert_e2422364503258 : check e2422364503258 [[],[]] .three = true := by decide
def e2422364503274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422364503274 : Closed e2422364503274 ∧ code e2422364503274 = 11218457525482 := by decide
theorem cert_e2422364503274 : check e2422364503274 [[],[]] .three = true := by decide
def e2422364503326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e2422364503326 : Closed e2422364503326 ∧ code e2422364503326 = 11218457525534 := by decide
theorem cert_e2422364503326 : check e2422364503326 [[],[]] .three = true := by decide
def e2422364503350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364503350 : Closed e2422364503350 ∧ code e2422364503350 = 11218457525558 := by decide
theorem cert_e2422364503350 : check e2422364503350 [[],[]] .three = true := by decide
def e2422364503354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364503354 : Closed e2422364503354 ∧ code e2422364503354 = 11218457525562 := by decide
theorem cert_e2422364503354 : check e2422364503354 [[],[]] .three = true := by decide
def e2422364503438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422364503438 : Closed e2422364503438 ∧ code e2422364503438 = 11218457525646 := by decide
theorem cert_e2422364503438 : check e2422364503438 [[],[]] .three = true := by decide
def e2422364503450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364503450 : Closed e2422364503450 ∧ code e2422364503450 = 11218457525658 := by decide
theorem cert_e2422364503450 : check e2422364503450 [[],[]] .three = true := by decide
def e2422364503486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 4))))))))
theorem wire_e2422364503486 : Closed e2422364503486 ∧ code e2422364503486 = 11218457525694 := by decide
theorem cert_e2422364503486 : check e2422364503486 [[],[]] .three = true := by decide
def e2422364503494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422364503494 : Closed e2422364503494 ∧ code e2422364503494 = 11218457525702 := by decide
theorem cert_e2422364503494 : check e2422364503494 [[],[]] .three = true := by decide
def e2422364503542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 4))) (.var 1))))))))
theorem wire_e2422364503542 : Closed e2422364503542 ∧ code e2422364503542 = 11218457525750 := by decide
theorem cert_e2422364503542 : check e2422364503542 [[],[]] .three = true := by decide
def e2422364506990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422364506990 : Closed e2422364506990 ∧ code e2422364506990 = 11218457529198 := by decide
theorem cert_e2422364506990 : check e2422364506990 [[],[]] .smaller = true := by decide
def e2422364506998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422364506998 : Closed e2422364506998 ∧ code e2422364506998 = 11218457529206 := by decide
theorem cert_e2422364506998 : check e2422364506998 [[],[]] .smaller = true := by decide
def e2422364507054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422364507054 : Closed e2422364507054 ∧ code e2422364507054 = 11218457529262 := by decide
theorem cert_e2422364507054 : check e2422364507054 [[],[]] .smaller = true := by decide
def e2422364507066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422364507066 : Closed e2422364507066 ∧ code e2422364507066 = 11218457529274 := by decide
theorem cert_e2422364507066 : check e2422364507066 [[],[]] .smaller = true := by decide
def e2422364507094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422364507094 : Closed e2422364507094 ∧ code e2422364507094 = 11218457529302 := by decide
theorem cert_e2422364507094 : check e2422364507094 [[],[]] .smaller = true := by decide
def e2422364507098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422364507098 : Closed e2422364507098 ∧ code e2422364507098 = 11218457529306 := by decide
theorem cert_e2422364507098 : check e2422364507098 [[],[]] .smaller = true := by decide
def e2422364507374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422364507374 : Closed e2422364507374 ∧ code e2422364507374 = 11218457529582 := by decide
theorem cert_e2422364507374 : check e2422364507374 [[],[]] .smaller = true := by decide
def e2422364507382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422364507382 : Closed e2422364507382 ∧ code e2422364507382 = 11218457529590 := by decide
theorem cert_e2422364507382 : check e2422364507382 [[],[]] .smaller = true := by decide
def e2422364507758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422364507758 : Closed e2422364507758 ∧ code e2422364507758 = 11218457529966 := by decide
theorem cert_e2422364507758 : check e2422364507758 [[],[]] .smaller = true := by decide
def e2422364507770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422364507770 : Closed e2422364507770 ∧ code e2422364507770 = 11218457529978 := by decide
theorem cert_e2422364507770 : check e2422364507770 [[],[]] .smaller = true := by decide
def e2422364507958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422364507958 : Closed e2422364507958 ∧ code e2422364507958 = 11218457530166 := by decide
theorem cert_e2422364507958 : check e2422364507958 [[],[]] .smaller = true := by decide
def e2422364507962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422364507962 : Closed e2422364507962 ∧ code e2422364507962 = 11218457530170 := by decide
theorem cert_e2422364507962 : check e2422364507962 [[],[]] .smaller = true := by decide
def e2422364508030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 5))))))))))
theorem wire_e2422364508030 : Closed e2422364508030 ∧ code e2422364508030 = 11218457530238 := by decide
theorem cert_e2422364508030 : check e2422364508030 [[],[]] .three = true := by decide
def e2422364508094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e2422364508094 : Closed e2422364508094 ∧ code e2422364508094 = 11218457530302 := by decide
theorem cert_e2422364508094 : check e2422364508094 [[],[]] .smaller = true := by decide
def e2422364508126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e2422364508126 : Closed e2422364508126 ∧ code e2422364508126 = 11218457530334 := by decide
theorem cert_e2422364508126 : check e2422364508126 [[],[]] .smaller = true := by decide
def e2422364508142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 5) (.var 2))))))))))
theorem wire_e2422364508142 : Closed e2422364508142 ∧ code e2422364508142 = 11218457530350 := by decide
theorem cert_e2422364508142 : check e2422364508142 [[],[]] .three = true := by decide
def e2422364515774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2422364515774 : Closed e2422364515774 ∧ code e2422364515774 = 11218457537982 := by decide
theorem cert_e2422364515774 : check e2422364515774 [[],[]] .three = true := by decide
def e2422364515806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2422364515806 : Closed e2422364515806 ∧ code e2422364515806 = 11218457538014 := by decide
theorem cert_e2422364515806 : check e2422364515806 [[],[]] .smaller = true := by decide
def e2422364515822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2422364515822 : Closed e2422364515822 ∧ code e2422364515822 = 11218457538030 := by decide
theorem cert_e2422364515822 : check e2422364515822 [[],[]] .smaller = true := by decide
def e2422364515830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2422364515830 : Closed e2422364515830 ∧ code e2422364515830 = 11218457538038 := by decide
theorem cert_e2422364515830 : check e2422364515830 [[],[]] .three = true := by decide
def e2422364515886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422364515886 : Closed e2422364515886 ∧ code e2422364515886 = 11218457538094 := by decide
theorem cert_e2422364515886 : check e2422364515886 [[],[]] .smaller = true := by decide
def e2422364516030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2422364516030 : Closed e2422364516030 ∧ code e2422364516030 = 11218457538238 := by decide
theorem cert_e2422364516030 : check e2422364516030 [[],[]] .three = true := by decide
def e2422364516062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e2422364516062 : Closed e2422364516062 ∧ code e2422364516062 = 11218457538270 := by decide
theorem cert_e2422364516062 : check e2422364516062 [[],[]] .smaller = true := by decide
def e2422364516066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422364516066 : Closed e2422364516066 ∧ code e2422364516066 = 11218457538274 := by decide
theorem cert_e2422364516066 : check e2422364516066 [[],[]] .smaller = true := by decide
def e2422364516078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e2422364516078 : Closed e2422364516078 ∧ code e2422364516078 = 11218457538286 := by decide
theorem cert_e2422364516078 : check e2422364516078 [[],[]] .smaller = true := by decide
def e2422364516086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e2422364516086 : Closed e2422364516086 ∧ code e2422364516086 = 11218457538294 := by decide
theorem cert_e2422364516086 : check e2422364516086 [[],[]] .smaller = true := by decide
def e2422364516090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2422364516090 : Closed e2422364516090 ∧ code e2422364516090 = 11218457538298 := by decide
theorem cert_e2422364516090 : check e2422364516090 [[],[]] .three = true := by decide
def e2422364516118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422364516118 : Closed e2422364516118 ∧ code e2422364516118 = 11218457538326 := by decide
theorem cert_e2422364516118 : check e2422364516118 [[],[]] .smaller = true := by decide
def e2422364516190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2422364516190 : Closed e2422364516190 ∧ code e2422364516190 = 11218457538398 := by decide
theorem cert_e2422364516190 : check e2422364516190 [[],[]] .smaller = true := by decide
def e2422364516194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422364516194 : Closed e2422364516194 ∧ code e2422364516194 = 11218457538402 := by decide
theorem cert_e2422364516194 : check e2422364516194 [[],[]] .smaller = true := by decide
def e2422364516206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e2422364516206 : Closed e2422364516206 ∧ code e2422364516206 = 11218457538414 := by decide
theorem cert_e2422364516206 : check e2422364516206 [[],[]] .smaller = true := by decide
def e2422364516214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e2422364516214 : Closed e2422364516214 ∧ code e2422364516214 = 11218457538422 := by decide
theorem cert_e2422364516214 : check e2422364516214 [[],[]] .smaller = true := by decide
def e2422364516218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2422364516218 : Closed e2422364516218 ∧ code e2422364516218 = 11218457538426 := by decide
theorem cert_e2422364516218 : check e2422364516218 [[],[]] .smaller = true := by decide
def e2422364516270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2422364516270 : Closed e2422364516270 ∧ code e2422364516270 = 11218457538478 := by decide
theorem cert_e2422364516270 : check e2422364516270 [[],[]] .smaller = true := by decide
def e2422364516278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e2422364516278 : Closed e2422364516278 ∧ code e2422364516278 = 11218457538486 := by decide
theorem cert_e2422364516278 : check e2422364516278 [[],[]] .smaller = true := by decide
def e2422364516282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2422364516282 : Closed e2422364516282 ∧ code e2422364516282 = 11218457538490 := by decide
theorem cert_e2422364516282 : check e2422364516282 [[],[]] .smaller = true := by decide
end Blc.Floor43
