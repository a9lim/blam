import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e827036229658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827036229658 : Closed e827036229658 ∧ code e827036229658 = 9623129251866 := by decide
theorem cert_e827036229658 : check e827036229658 [] .sourceHead = true := by decide
def e827036229750 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827036229750 : Closed e827036229750 ∧ code e827036229750 = 9623129251958 := by decide
theorem cert_e827036229750 : check e827036229750 [] .sourceHead = true := by decide
def e827036229994 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827036229994 : Closed e827036229994 ∧ code e827036229994 = 9623129252202 := by decide
theorem cert_e827036229994 : check e827036229994 [] .sourceHead = true := by decide
def e827036230042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827036230042 : Closed e827036230042 ∧ code e827036230042 = 9623129252250 := by decide
theorem cert_e827036230042 : check e827036230042 [] .sourceHead = true := by decide
def e827036231194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827036231194 : Closed e827036231194 ∧ code e827036231194 = 9623129253402 := by decide
theorem cert_e827036231194 : check e827036231194 [] .sourceHead = true := by decide
def e827036244506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827036244506 : Closed e827036244506 ∧ code e827036244506 = 9623129266714 := by decide
theorem cert_e827036244506 : check e827036244506 [] .sourceHead = true := by decide
def e827036246042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827036246042 : Closed e827036246042 ∧ code e827036246042 = 9623129268250 := by decide
theorem cert_e827036246042 : check e827036246042 [] .sourceHead = true := by decide
def e827036246134 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827036246134 : Closed e827036246134 ∧ code e827036246134 = 9623129268342 := by decide
theorem cert_e827036246134 : check e827036246134 [] .sourceHead = true := by decide
def e827036246378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827036246378 : Closed e827036246378 ∧ code e827036246378 = 9623129268586 := by decide
theorem cert_e827036246378 : check e827036246378 [] .sourceHead = true := by decide
def e827036246426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827036246426 : Closed e827036246426 ∧ code e827036246426 = 9623129268634 := by decide
theorem cert_e827036246426 : check e827036246426 [] .sourceHead = true := by decide
def e827036247578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827036247578 : Closed e827036247578 ∧ code e827036247578 = 9623129269786 := by decide
theorem cert_e827036247578 : check e827036247578 [] .sourceHead = true := by decide
def e827036625434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827036625434 : Closed e827036625434 ∧ code e827036625434 = 9623129647642 := by decide
theorem cert_e827036625434 : check e827036625434 [] .sourceHead = true := by decide
def e827036637722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827036637722 : Closed e827036637722 ∧ code e827036637722 = 9623129659930 := by decide
theorem cert_e827036637722 : check e827036637722 [] .sourceHead = true := by decide
def e827036639258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827036639258 : Closed e827036639258 ∧ code e827036639258 = 9623129661466 := by decide
theorem cert_e827036639258 : check e827036639258 [] .sourceHead = true := by decide
def e827036639350 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827036639350 : Closed e827036639350 ∧ code e827036639350 = 9623129661558 := by decide
theorem cert_e827036639350 : check e827036639350 [] .sourceHead = true := by decide
def e827036639594 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827036639594 : Closed e827036639594 ∧ code e827036639594 = 9623129661802 := by decide
theorem cert_e827036639594 : check e827036639594 [] .sourceHead = true := by decide
def e827036639642 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827036639642 : Closed e827036639642 ∧ code e827036639642 = 9623129661850 := by decide
theorem cert_e827036639642 : check e827036639642 [] .sourceHead = true := by decide
def e827036640794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827036640794 : Closed e827036640794 ∧ code e827036640794 = 9623129663002 := by decide
theorem cert_e827036640794 : check e827036640794 [] .sourceHead = true := by decide
def e827372778938 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e827372778938 : Closed e827372778938 ∧ code e827372778938 = 9623465801146 := by decide
theorem cert_e827372778938 : check e827372778938 [] .sourceHead = true := by decide
def e827372778970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e827372778970 : Closed e827372778970 ∧ code e827372778970 = 9623465801178 := by decide
theorem cert_e827372778970 : check e827372778970 [] .sourceHead = true := by decide
def e827372779194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e827372779194 : Closed e827372779194 ∧ code e827372779194 = 9623465801402 := by decide
theorem cert_e827372779194 : check e827372779194 [] .sourceHead = true := by decide
def e827372779242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e827372779242 : Closed e827372779242 ∧ code e827372779242 = 9623465801450 := by decide
theorem cert_e827372779242 : check e827372779242 [] .sourceHead = true := by decide
def e827372779354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e827372779354 : Closed e827372779354 ∧ code e827372779354 = 9623465801562 := by decide
theorem cert_e827372779354 : check e827372779354 [] .sourceHead = true := by decide
def e827372779370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e827372779370 : Closed e827372779370 ∧ code e827372779370 = 9623465801578 := by decide
theorem cert_e827372779370 : check e827372779370 [] .sourceHead = true := by decide
def e827372780218 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e827372780218 : Closed e827372780218 ∧ code e827372780218 = 9623465802426 := by decide
theorem cert_e827372780218 : check e827372780218 [] .sourceHead = true := by decide
def e827372780266 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e827372780266 : Closed e827372780266 ∧ code e827372780266 = 9623465802474 := by decide
theorem cert_e827372780266 : check e827372780266 [] .sourceHead = true := by decide
def e827372780458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e827372780458 : Closed e827372780458 ∧ code e827372780458 = 9623465802666 := by decide
theorem cert_e827372780458 : check e827372780458 [] .sourceHead = true := by decide
def e827372780890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e827372780890 : Closed e827372780890 ∧ code e827372780890 = 9623465803098 := by decide
theorem cert_e827372780890 : check e827372780890 [] .sourceHead = true := by decide
def e827372780906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e827372780906 : Closed e827372780906 ∧ code e827372780906 = 9623465803114 := by decide
theorem cert_e827372780906 : check e827372780906 [] .sourceHead = true := by decide
def e827372780970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e827372780970 : Closed e827372780970 ∧ code e827372780970 = 9623465803178 := by decide
theorem cert_e827372780970 : check e827372780970 [] .sourceHead = true := by decide
def e827372785082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))) (.var 0))))))
theorem wire_e827372785082 : Closed e827372785082 ∧ code e827372785082 = 9623465807290 := by decide
theorem cert_e827372785082 : check e827372785082 [] .sourceHead = true := by decide
def e827372785114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0))))))
theorem wire_e827372785114 : Closed e827372785114 ∧ code e827372785114 = 9623465807322 := by decide
theorem cert_e827372785114 : check e827372785114 [] .sourceHead = true := by decide
def e827372785338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))) (.var 0))))))
theorem wire_e827372785338 : Closed e827372785338 ∧ code e827372785338 = 9623465807546 := by decide
theorem cert_e827372785338 : check e827372785338 [] .sourceHead = true := by decide
def e827372785386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))) (.var 0))))))
theorem wire_e827372785386 : Closed e827372785386 ∧ code e827372785386 = 9623465807594 := by decide
theorem cert_e827372785386 : check e827372785386 [] .sourceHead = true := by decide
def e827372785498 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.var 0))))))
theorem wire_e827372785498 : Closed e827372785498 ∧ code e827372785498 = 9623465807706 := by decide
theorem cert_e827372785498 : check e827372785498 [] .sourceHead = true := by decide
def e827372785514 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))) (.var 0))))))
theorem wire_e827372785514 : Closed e827372785514 ∧ code e827372785514 = 9623465807722 := by decide
theorem cert_e827372785514 : check e827372785514 [] .sourceHead = true := by decide
def e827372786618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e827372786618 : Closed e827372786618 ∧ code e827372786618 = 9623465808826 := by decide
theorem cert_e827372786618 : check e827372786618 [] .sourceHead = true := by decide
def e827372786650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e827372786650 : Closed e827372786650 ∧ code e827372786650 = 9623465808858 := by decide
theorem cert_e827372786650 : check e827372786650 [] .sourceHead = true := by decide
def e827372788154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e827372788154 : Closed e827372788154 ∧ code e827372788154 = 9623465810362 := by decide
theorem cert_e827372788154 : check e827372788154 [] .sourceHead = true := by decide
def e827372788202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e827372788202 : Closed e827372788202 ∧ code e827372788202 = 9623465810410 := by decide
theorem cert_e827372788202 : check e827372788202 [] .sourceHead = true := by decide
def e827372788954 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e827372788954 : Closed e827372788954 ∧ code e827372788954 = 9623465811162 := by decide
theorem cert_e827372788954 : check e827372788954 [] .sourceHead = true := by decide
def e827372788970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e827372788970 : Closed e827372788970 ∧ code e827372788970 = 9623465811178 := by decide
theorem cert_e827372788970 : check e827372788970 [] .sourceHead = true := by decide
def e827372791482 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))) (.var 0))))))
theorem wire_e827372791482 : Closed e827372791482 ∧ code e827372791482 = 9623465813690 := by decide
theorem cert_e827372791482 : check e827372791482 [] .sourceHead = true := by decide
def e827372791530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))) (.var 0))))))
theorem wire_e827372791530 : Closed e827372791530 ∧ code e827372791530 = 9623465813738 := by decide
theorem cert_e827372791530 : check e827372791530 [] .sourceHead = true := by decide
def e827372791722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))) (.var 0))))))
theorem wire_e827372791722 : Closed e827372791722 ∧ code e827372791722 = 9623465813930 := by decide
theorem cert_e827372791722 : check e827372791722 [] .sourceHead = true := by decide
def e827372792250 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e827372792250 : Closed e827372792250 ∧ code e827372792250 = 9623465814458 := by decide
theorem cert_e827372792250 : check e827372792250 [] .sourceHead = true := by decide
def e827372792298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e827372792298 : Closed e827372792298 ∧ code e827372792298 = 9623465814506 := by decide
theorem cert_e827372792298 : check e827372792298 [] .sourceHead = true := by decide
def e827372793450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e827372793450 : Closed e827372793450 ∧ code e827372793450 = 9623465815658 := by decide
theorem cert_e827372793450 : check e827372793450 [] .sourceHead = true := by decide
def e827372794714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.var 0))))))
theorem wire_e827372794714 : Closed e827372794714 ∧ code e827372794714 = 9623465816922 := by decide
theorem cert_e827372794714 : check e827372794714 [] .sourceHead = true := by decide
def e827372794730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))) (.var 0))))))
theorem wire_e827372794730 : Closed e827372794730 ∧ code e827372794730 = 9623465816938 := by decide
theorem cert_e827372794730 : check e827372794730 [] .sourceHead = true := by decide
def e827372794794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))) (.var 0))))))
theorem wire_e827372794794 : Closed e827372794794 ∧ code e827372794794 = 9623465817002 := by decide
theorem cert_e827372794794 : check e827372794794 [] .sourceHead = true := by decide
def e827372795098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e827372795098 : Closed e827372795098 ∧ code e827372795098 = 9623465817306 := by decide
theorem cert_e827372795098 : check e827372795098 [] .sourceHead = true := by decide
def e827372795114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e827372795114 : Closed e827372795114 ∧ code e827372795114 = 9623465817322 := by decide
theorem cert_e827372795114 : check e827372795114 [] .sourceHead = true := by decide
def e827372795498 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e827372795498 : Closed e827372795498 ∧ code e827372795498 = 9623465817706 := by decide
theorem cert_e827372795498 : check e827372795498 [] .sourceHead = true := by decide
def e827372809658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))))
theorem wire_e827372809658 : Closed e827372809658 ∧ code e827372809658 = 9623465831866 := by decide
theorem cert_e827372809658 : check e827372809658 [] .sourceHead = true := by decide
def e827372809690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))))
theorem wire_e827372809690 : Closed e827372809690 ∧ code e827372809690 = 9623465831898 := by decide
theorem cert_e827372809690 : check e827372809690 [] .sourceHead = true := by decide
def e827372809914 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e827372809914 : Closed e827372809914 ∧ code e827372809914 = 9623465832122 := by decide
theorem cert_e827372809914 : check e827372809914 [] .sourceHead = true := by decide
def e827372809962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e827372809962 : Closed e827372809962 ∧ code e827372809962 = 9623465832170 := by decide
theorem cert_e827372809962 : check e827372809962 [] .sourceHead = true := by decide
def e827372810074 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e827372810074 : Closed e827372810074 ∧ code e827372810074 = 9623465832282 := by decide
theorem cert_e827372810074 : check e827372810074 [] .sourceHead = true := by decide
def e827372810090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e827372810090 : Closed e827372810090 ∧ code e827372810090 = 9623465832298 := by decide
theorem cert_e827372810090 : check e827372810090 [] .sourceHead = true := by decide
def e827372811194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))))
theorem wire_e827372811194 : Closed e827372811194 ∧ code e827372811194 = 9623465833402 := by decide
theorem cert_e827372811194 : check e827372811194 [] .sourceHead = true := by decide
def e827372811226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))))
theorem wire_e827372811226 : Closed e827372811226 ∧ code e827372811226 = 9623465833434 := by decide
theorem cert_e827372811226 : check e827372811226 [] .sourceHead = true := by decide
def e827372812730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e827372812730 : Closed e827372812730 ∧ code e827372812730 = 9623465834938 := by decide
theorem cert_e827372812730 : check e827372812730 [] .sourceHead = true := by decide
def e827372812778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e827372812778 : Closed e827372812778 ∧ code e827372812778 = 9623465834986 := by decide
theorem cert_e827372812778 : check e827372812778 [] .sourceHead = true := by decide
def e827372813530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e827372813530 : Closed e827372813530 ∧ code e827372813530 = 9623465835738 := by decide
theorem cert_e827372813530 : check e827372813530 [] .sourceHead = true := by decide
def e827372813546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e827372813546 : Closed e827372813546 ∧ code e827372813546 = 9623465835754 := by decide
theorem cert_e827372813546 : check e827372813546 [] .sourceHead = true := by decide
def e827372836538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e827372836538 : Closed e827372836538 ∧ code e827372836538 = 9623465858746 := by decide
theorem cert_e827372836538 : check e827372836538 [] .sourceHead = true := by decide
def e827372836586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e827372836586 : Closed e827372836586 ∧ code e827372836586 = 9623465858794 := by decide
theorem cert_e827372836586 : check e827372836586 [] .sourceHead = true := by decide
def e827372836778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))) (.var 0))))))
theorem wire_e827372836778 : Closed e827372836778 ∧ code e827372836778 = 9623465858986 := by decide
theorem cert_e827372836778 : check e827372836778 [] .sourceHead = true := by decide
def e827372837306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e827372837306 : Closed e827372837306 ∧ code e827372837306 = 9623465859514 := by decide
theorem cert_e827372837306 : check e827372837306 [] .sourceHead = true := by decide
def e827372837354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e827372837354 : Closed e827372837354 ∧ code e827372837354 = 9623465859562 := by decide
theorem cert_e827372837354 : check e827372837354 [] .sourceHead = true := by decide
def e827372838506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e827372838506 : Closed e827372838506 ∧ code e827372838506 = 9623465860714 := by decide
theorem cert_e827372838506 : check e827372838506 [] .sourceHead = true := by decide
def e827372850010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e827372850010 : Closed e827372850010 ∧ code e827372850010 = 9623465872218 := by decide
theorem cert_e827372850010 : check e827372850010 [] .sourceHead = true := by decide
def e827372850026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e827372850026 : Closed e827372850026 ∧ code e827372850026 = 9623465872234 := by decide
theorem cert_e827372850026 : check e827372850026 [] .sourceHead = true := by decide
def e827372850090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))) (.var 0))))))
theorem wire_e827372850090 : Closed e827372850090 ∧ code e827372850090 = 9623465872298 := by decide
theorem cert_e827372850090 : check e827372850090 [] .sourceHead = true := by decide
def e827372850394 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e827372850394 : Closed e827372850394 ∧ code e827372850394 = 9623465872602 := by decide
theorem cert_e827372850394 : check e827372850394 [] .sourceHead = true := by decide
def e827372850410 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e827372850410 : Closed e827372850410 ∧ code e827372850410 = 9623465872618 := by decide
theorem cert_e827372850410 : check e827372850410 [] .sourceHead = true := by decide
def e827372850794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e827372850794 : Closed e827372850794 ∧ code e827372850794 = 9623465873002 := by decide
theorem cert_e827372850794 : check e827372850794 [] .sourceHead = true := by decide
def e827597876762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827597876762 : Closed e827597876762 ∧ code e827597876762 = 9623690898970 := by decide
theorem cert_e827597876762 : check e827597876762 [] .sourceHead = true := by decide
def e827597878810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827597878810 : Closed e827597878810 ∧ code e827597878810 = 9623690901018 := by decide
theorem cert_e827597878810 : check e827597878810 [] .sourceHead = true := by decide
def e827597893146 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827597893146 : Closed e827597893146 ∧ code e827597893146 = 9623690915354 := by decide
theorem cert_e827597893146 : check e827597893146 [] .sourceHead = true := by decide
def e827597896218 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827597896218 : Closed e827597896218 ∧ code e827597896218 = 9623690918426 := by decide
theorem cert_e827597896218 : check e827597896218 [] .sourceHead = true := by decide
def e827597903386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827597903386 : Closed e827597903386 ∧ code e827597903386 = 9623690925594 := by decide
theorem cert_e827597903386 : check e827597903386 [] .sourceHead = true := by decide
def e827597904410 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827597904410 : Closed e827597904410 ∧ code e827597904410 = 9623690926618 := by decide
theorem cert_e827597904410 : check e827597904410 [] .sourceHead = true := by decide
def e827597958682 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827597958682 : Closed e827597958682 ∧ code e827597958682 = 9623690980890 := by decide
theorem cert_e827597958682 : check e827597958682 [] .sourceHead = true := by decide
def e827597961754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827597961754 : Closed e827597961754 ∧ code e827597961754 = 9623690983962 := by decide
theorem cert_e827597961754 : check e827597961754 [] .sourceHead = true := by decide
def e827597974042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827597974042 : Closed e827597974042 ∧ code e827597974042 = 9623690996250 := by decide
theorem cert_e827597974042 : check e827597974042 [] .sourceHead = true := by decide
def e827598001690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598001690 : Closed e827598001690 ∧ code e827598001690 = 9623691023898 := by decide
theorem cert_e827598001690 : check e827598001690 [] .sourceHead = true := by decide
def e827598002714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598002714 : Closed e827598002714 ∧ code e827598002714 = 9623691024922 := by decide
theorem cert_e827598002714 : check e827598002714 [] .sourceHead = true := by decide
def e827598006810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598006810 : Closed e827598006810 ∧ code e827598006810 = 9623691029018 := by decide
theorem cert_e827598006810 : check e827598006810 [] .sourceHead = true := by decide
def e827598269978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598269978 : Closed e827598269978 ∧ code e827598269978 = 9623691292186 := by decide
theorem cert_e827598269978 : check e827598269978 [] .sourceHead = true := by decide
def e827598272026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598272026 : Closed e827598272026 ∧ code e827598272026 = 9623691294234 := by decide
theorem cert_e827598272026 : check e827598272026 [] .sourceHead = true := by decide
def e827598286362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598286362 : Closed e827598286362 ∧ code e827598286362 = 9623691308570 := by decide
theorem cert_e827598286362 : check e827598286362 [] .sourceHead = true := by decide
def e827598289434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598289434 : Closed e827598289434 ∧ code e827598289434 = 9623691311642 := by decide
theorem cert_e827598289434 : check e827598289434 [] .sourceHead = true := by decide
def e827598296602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598296602 : Closed e827598296602 ∧ code e827598296602 = 9623691318810 := by decide
theorem cert_e827598296602 : check e827598296602 [] .sourceHead = true := by decide
def e827598297626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598297626 : Closed e827598297626 ∧ code e827598297626 = 9623691319834 := by decide
theorem cert_e827598297626 : check e827598297626 [] .sourceHead = true := by decide
def e827598368282 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598368282 : Closed e827598368282 ∧ code e827598368282 = 9623691390490 := by decide
theorem cert_e827598368282 : check e827598368282 [] .sourceHead = true := by decide
def e827598370330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598370330 : Closed e827598370330 ∧ code e827598370330 = 9623691392538 := by decide
theorem cert_e827598370330 : check e827598370330 [] .sourceHead = true := by decide
def e827598466586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598466586 : Closed e827598466586 ∧ code e827598466586 = 9623691488794 := by decide
theorem cert_e827598466586 : check e827598466586 [] .sourceHead = true := by decide
def e827598469658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598469658 : Closed e827598469658 ∧ code e827598469658 = 9623691491866 := by decide
theorem cert_e827598469658 : check e827598469658 [] .sourceHead = true := by decide
def e827598517786 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598517786 : Closed e827598517786 ∧ code e827598517786 = 9623691539994 := by decide
theorem cert_e827598517786 : check e827598517786 [] .sourceHead = true := by decide
def e827598518810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598518810 : Closed e827598518810 ∧ code e827598518810 = 9623691541018 := by decide
theorem cert_e827598518810 : check e827598518810 [] .sourceHead = true := by decide
def e827598679578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598679578 : Closed e827598679578 ∧ code e827598679578 = 9623691701786 := by decide
theorem cert_e827598679578 : check e827598679578 [] .sourceHead = true := by decide
def e827598682650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598682650 : Closed e827598682650 ∧ code e827598682650 = 9623691704858 := by decide
theorem cert_e827598682650 : check e827598682650 [] .sourceHead = true := by decide
def e827598694938 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598694938 : Closed e827598694938 ∧ code e827598694938 = 9623691717146 := by decide
theorem cert_e827598694938 : check e827598694938 [] .sourceHead = true := by decide
def e827598728730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598728730 : Closed e827598728730 ∧ code e827598728730 = 9623691750938 := by decide
theorem cert_e827598728730 : check e827598728730 [] .sourceHead = true := by decide
def e827598731802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598731802 : Closed e827598731802 ∧ code e827598731802 = 9623691754010 := by decide
theorem cert_e827598731802 : check e827598731802 [] .sourceHead = true := by decide
def e827598805530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598805530 : Closed e827598805530 ∧ code e827598805530 = 9623691827738 := by decide
theorem cert_e827598805530 : check e827598805530 [] .sourceHead = true := by decide
def e827598886426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598886426 : Closed e827598886426 ∧ code e827598886426 = 9623691908634 := by decide
theorem cert_e827598886426 : check e827598886426 [] .sourceHead = true := by decide
def e827598887450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598887450 : Closed e827598887450 ∧ code e827598887450 = 9623691909658 := by decide
theorem cert_e827598887450 : check e827598887450 [] .sourceHead = true := by decide
def e827598891546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598891546 : Closed e827598891546 ∧ code e827598891546 = 9623691913754 := by decide
theorem cert_e827598891546 : check e827598891546 [] .sourceHead = true := by decide
def e827598911002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598911002 : Closed e827598911002 ∧ code e827598911002 = 9623691933210 := by decide
theorem cert_e827598911002 : check e827598911002 [] .sourceHead = true := by decide
def e827598912026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598912026 : Closed e827598912026 ∧ code e827598912026 = 9623691934234 := by decide
theorem cert_e827598912026 : check e827598912026 [] .sourceHead = true := by decide
def e827598936602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827598936602 : Closed e827598936602 ∧ code e827598936602 = 9623691958810 := by decide
theorem cert_e827598936602 : check e827598936602 [] .sourceHead = true := by decide
def e827599842842 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827599842842 : Closed e827599842842 ∧ code e827599842842 = 9623692865050 := by decide
theorem cert_e827599842842 : check e827599842842 [] .sourceHead = true := by decide
def e827599844890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827599844890 : Closed e827599844890 ∧ code e827599844890 = 9623692867098 := by decide
theorem cert_e827599844890 : check e827599844890 [] .sourceHead = true := by decide
def e827599859226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827599859226 : Closed e827599859226 ∧ code e827599859226 = 9623692881434 := by decide
theorem cert_e827599859226 : check e827599859226 [] .sourceHead = true := by decide
def e827599862298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827599862298 : Closed e827599862298 ∧ code e827599862298 = 9623692884506 := by decide
theorem cert_e827599862298 : check e827599862298 [] .sourceHead = true := by decide
def e827599869466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827599869466 : Closed e827599869466 ∧ code e827599869466 = 9623692891674 := by decide
theorem cert_e827599869466 : check e827599869466 [] .sourceHead = true := by decide
def e827599870490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827599870490 : Closed e827599870490 ∧ code e827599870490 = 9623692892698 := by decide
theorem cert_e827599870490 : check e827599870490 [] .sourceHead = true := by decide
def e827599941146 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827599941146 : Closed e827599941146 ∧ code e827599941146 = 9623692963354 := by decide
theorem cert_e827599941146 : check e827599941146 [] .sourceHead = true := by decide
def e827599943194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827599943194 : Closed e827599943194 ∧ code e827599943194 = 9623692965402 := by decide
theorem cert_e827599943194 : check e827599943194 [] .sourceHead = true := by decide
def e827600039450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827600039450 : Closed e827600039450 ∧ code e827600039450 = 9623693061658 := by decide
theorem cert_e827600039450 : check e827600039450 [] .sourceHead = true := by decide
def e827600042522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827600042522 : Closed e827600042522 ∧ code e827600042522 = 9623693064730 := by decide
theorem cert_e827600042522 : check e827600042522 [] .sourceHead = true := by decide
def e827600090650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827600090650 : Closed e827600090650 ∧ code e827600090650 = 9623693112858 := by decide
theorem cert_e827600090650 : check e827600090650 [] .sourceHead = true := by decide
def e827600091674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827600091674 : Closed e827600091674 ∧ code e827600091674 = 9623693113882 := by decide
theorem cert_e827600091674 : check e827600091674 [] .sourceHead = true := by decide
def e827600186734 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e827600186734 : Closed e827600186734 ∧ code e827600186734 = 9623693208942 := by decide
theorem cert_e827600186734 : check e827600186734 [] .sourceHead = true := by decide
def e827600186742 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e827600186742 : Closed e827600186742 ∧ code e827600186742 = 9623693208950 := by decide
theorem cert_e827600186742 : check e827600186742 [] .sourceHead = true := by decide
def e827600186798 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e827600186798 : Closed e827600186798 ∧ code e827600186798 = 9623693209006 := by decide
theorem cert_e827600186798 : check e827600186798 [] .sourceHead = true := by decide
def e827600186810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e827600186810 : Closed e827600186810 ∧ code e827600186810 = 9623693209018 := by decide
theorem cert_e827600186810 : check e827600186810 [] .sourceHead = true := by decide
def e827600186838 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e827600186838 : Closed e827600186838 ∧ code e827600186838 = 9623693209046 := by decide
theorem cert_e827600186838 : check e827600186838 [] .sourceHead = true := by decide
def e827600186842 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e827600186842 : Closed e827600186842 ∧ code e827600186842 = 9623693209050 := by decide
theorem cert_e827600186842 : check e827600186842 [] .sourceHead = true := by decide
def e827600187054 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e827600187054 : Closed e827600187054 ∧ code e827600187054 = 9623693209262 := by decide
theorem cert_e827600187054 : check e827600187054 [] .sourceHead = true := by decide
def e827600187066 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e827600187066 : Closed e827600187066 ∧ code e827600187066 = 9623693209274 := by decide
theorem cert_e827600187066 : check e827600187066 [] .sourceHead = true := by decide
def e827600187114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e827600187114 : Closed e827600187114 ∧ code e827600187114 = 9623693209322 := by decide
theorem cert_e827600187114 : check e827600187114 [] .sourceHead = true := by decide
def e827600187222 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e827600187222 : Closed e827600187222 ∧ code e827600187222 = 9623693209430 := by decide
theorem cert_e827600187222 : check e827600187222 [] .sourceHead = true := by decide
def e827600187226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e827600187226 : Closed e827600187226 ∧ code e827600187226 = 9623693209434 := by decide
theorem cert_e827600187226 : check e827600187226 [] .sourceHead = true := by decide
def e827600187242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e827600187242 : Closed e827600187242 ∧ code e827600187242 = 9623693209450 := by decide
theorem cert_e827600187242 : check e827600187242 [] .sourceHead = true := by decide
def e827600188270 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e827600188270 : Closed e827600188270 ∧ code e827600188270 = 9623693210478 := by decide
theorem cert_e827600188270 : check e827600188270 [] .sourceHead = true := by decide
def e827600188278 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e827600188278 : Closed e827600188278 ∧ code e827600188278 = 9623693210486 := by decide
theorem cert_e827600188278 : check e827600188278 [] .sourceHead = true := by decide
def e827600188334 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e827600188334 : Closed e827600188334 ∧ code e827600188334 = 9623693210542 := by decide
theorem cert_e827600188334 : check e827600188334 [] .sourceHead = true := by decide
def e827600188346 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e827600188346 : Closed e827600188346 ∧ code e827600188346 = 9623693210554 := by decide
theorem cert_e827600188346 : check e827600188346 [] .sourceHead = true := by decide
def e827600188374 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e827600188374 : Closed e827600188374 ∧ code e827600188374 = 9623693210582 := by decide
theorem cert_e827600188374 : check e827600188374 [] .sourceHead = true := by decide
def e827600188378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e827600188378 : Closed e827600188378 ∧ code e827600188378 = 9623693210586 := by decide
theorem cert_e827600188378 : check e827600188378 [] .sourceHead = true := by decide
def e827600188654 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e827600188654 : Closed e827600188654 ∧ code e827600188654 = 9623693210862 := by decide
theorem cert_e827600188654 : check e827600188654 [] .sourceHead = true := by decide
def e827600188662 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e827600188662 : Closed e827600188662 ∧ code e827600188662 = 9623693210870 := by decide
theorem cert_e827600188662 : check e827600188662 [] .sourceHead = true := by decide
def e827600189038 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e827600189038 : Closed e827600189038 ∧ code e827600189038 = 9623693211246 := by decide
theorem cert_e827600189038 : check e827600189038 [] .sourceHead = true := by decide
def e827600189050 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e827600189050 : Closed e827600189050 ∧ code e827600189050 = 9623693211258 := by decide
theorem cert_e827600189050 : check e827600189050 [] .sourceHead = true := by decide
def e827600189238 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e827600189238 : Closed e827600189238 ∧ code e827600189238 = 9623693211446 := by decide
theorem cert_e827600189238 : check e827600189238 [] .sourceHead = true := by decide
def e827600189242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e827600189242 : Closed e827600189242 ∧ code e827600189242 = 9623693211450 := by decide
theorem cert_e827600189242 : check e827600189242 [] .sourceHead = true := by decide
def e827600189870 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e827600189870 : Closed e827600189870 ∧ code e827600189870 = 9623693212078 := by decide
theorem cert_e827600189870 : check e827600189870 [] .sourceHead = true := by decide
def e827600189882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e827600189882 : Closed e827600189882 ∧ code e827600189882 = 9623693212090 := by decide
theorem cert_e827600189882 : check e827600189882 [] .sourceHead = true := by decide
def e827600189930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e827600189930 : Closed e827600189930 ∧ code e827600189930 = 9623693212138 := by decide
theorem cert_e827600189930 : check e827600189930 [] .sourceHead = true := by decide
def e827600190062 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e827600190062 : Closed e827600190062 ∧ code e827600190062 = 9623693212270 := by decide
theorem cert_e827600190062 : check e827600190062 [] .sourceHead = true := by decide
def e827600190074 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e827600190074 : Closed e827600190074 ∧ code e827600190074 = 9623693212282 := by decide
theorem cert_e827600190074 : check e827600190074 [] .sourceHead = true := by decide
def e827600190362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e827600190362 : Closed e827600190362 ∧ code e827600190362 = 9623693212570 := by decide
theorem cert_e827600190362 : check e827600190362 [] .sourceHead = true := by decide
def e827600190678 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e827600190678 : Closed e827600190678 ∧ code e827600190678 = 9623693212886 := by decide
theorem cert_e827600190678 : check e827600190678 [] .sourceHead = true := by decide
def e827600190682 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e827600190682 : Closed e827600190682 ∧ code e827600190682 = 9623693212890 := by decide
theorem cert_e827600190682 : check e827600190682 [] .sourceHead = true := by decide
def e827600190698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e827600190698 : Closed e827600190698 ∧ code e827600190698 = 9623693212906 := by decide
theorem cert_e827600190698 : check e827600190698 [] .sourceHead = true := by decide
def e827600190774 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e827600190774 : Closed e827600190774 ∧ code e827600190774 = 9623693212982 := by decide
theorem cert_e827600190774 : check e827600190774 [] .sourceHead = true := by decide
end Blc.Floor43
