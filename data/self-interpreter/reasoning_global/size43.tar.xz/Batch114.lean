import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e878538964282 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e878538964282 : Closed e878538964282 ∧ code e878538964282 = 9674631986490 := by decide
theorem cert_e878538964282 : check e878538964282 [] .sourceHead = true := by decide
def e878538964378 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e878538964378 : Closed e878538964378 ∧ code e878538964378 = 9674631986586 := by decide
theorem cert_e878538964378 : check e878538964378 [] .sourceHead = true := by decide
def e878538967918 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e878538967918 : Closed e878538967918 ∧ code e878538967918 = 9674631990126 := by decide
theorem cert_e878538967918 : check e878538967918 [] .sourceHead = true := by decide
def e878538967926 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e878538967926 : Closed e878538967926 ∧ code e878538967926 = 9674631990134 := by decide
theorem cert_e878538967926 : check e878538967926 [] .sourceHead = true := by decide
def e878538967982 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e878538967982 : Closed e878538967982 ∧ code e878538967982 = 9674631990190 := by decide
theorem cert_e878538967982 : check e878538967982 [] .sourceHead = true := by decide
def e878538967994 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e878538967994 : Closed e878538967994 ∧ code e878538967994 = 9674631990202 := by decide
theorem cert_e878538967994 : check e878538967994 [] .sourceHead = true := by decide
def e878538968022 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e878538968022 : Closed e878538968022 ∧ code e878538968022 = 9674631990230 := by decide
theorem cert_e878538968022 : check e878538968022 [] .sourceHead = true := by decide
def e878538968026 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e878538968026 : Closed e878538968026 ∧ code e878538968026 = 9674631990234 := by decide
theorem cert_e878538968026 : check e878538968026 [] .sourceHead = true := by decide
def e878538968302 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e878538968302 : Closed e878538968302 ∧ code e878538968302 = 9674631990510 := by decide
theorem cert_e878538968302 : check e878538968302 [] .sourceHead = true := by decide
def e878538968310 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e878538968310 : Closed e878538968310 ∧ code e878538968310 = 9674631990518 := by decide
theorem cert_e878538968310 : check e878538968310 [] .sourceHead = true := by decide
def e878538968686 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e878538968686 : Closed e878538968686 ∧ code e878538968686 = 9674631990894 := by decide
theorem cert_e878538968686 : check e878538968686 [] .sourceHead = true := by decide
def e878538968698 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e878538968698 : Closed e878538968698 ∧ code e878538968698 = 9674631990906 := by decide
theorem cert_e878538968698 : check e878538968698 [] .sourceHead = true := by decide
def e878538968886 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e878538968886 : Closed e878538968886 ∧ code e878538968886 = 9674631991094 := by decide
theorem cert_e878538968886 : check e878538968886 [] .sourceHead = true := by decide
def e878538968890 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e878538968890 : Closed e878538968890 ∧ code e878538968890 = 9674631991098 := by decide
theorem cert_e878538968890 : check e878538968890 [] .sourceHead = true := by decide
def e878538974638 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e878538974638 : Closed e878538974638 ∧ code e878538974638 = 9674631996846 := by decide
theorem cert_e878538974638 : check e878538974638 [] .sourceHead = true := by decide
def e878538974650 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e878538974650 : Closed e878538974650 ∧ code e878538974650 = 9674631996858 := by decide
theorem cert_e878538974650 : check e878538974650 [] .sourceHead = true := by decide
def e878538974698 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e878538974698 : Closed e878538974698 ∧ code e878538974698 = 9674631996906 := by decide
theorem cert_e878538974698 : check e878538974698 [] .sourceHead = true := by decide
def e878538974830 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e878538974830 : Closed e878538974830 ∧ code e878538974830 = 9674631997038 := by decide
theorem cert_e878538974830 : check e878538974830 [] .sourceHead = true := by decide
def e878538974842 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e878538974842 : Closed e878538974842 ∧ code e878538974842 = 9674631997050 := by decide
theorem cert_e878538974842 : check e878538974842 [] .sourceHead = true := by decide
def e878538975130 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e878538975130 : Closed e878538975130 ∧ code e878538975130 = 9674631997338 := by decide
theorem cert_e878538975130 : check e878538975130 [] .sourceHead = true := by decide
def e878538978006 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e878538978006 : Closed e878538978006 ∧ code e878538978006 = 9674632000214 := by decide
theorem cert_e878538978006 : check e878538978006 [] .sourceHead = true := by decide
def e878538978010 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e878538978010 : Closed e878538978010 ∧ code e878538978010 = 9674632000218 := by decide
theorem cert_e878538978010 : check e878538978010 [] .sourceHead = true := by decide
def e878538978026 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e878538978026 : Closed e878538978026 ∧ code e878538978026 = 9674632000234 := by decide
theorem cert_e878538978026 : check e878538978026 [] .sourceHead = true := by decide
def e878538978102 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e878538978102 : Closed e878538978102 ∧ code e878538978102 = 9674632000310 := by decide
theorem cert_e878538978102 : check e878538978102 [] .sourceHead = true := by decide
def e878538978106 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e878538978106 : Closed e878538978106 ∧ code e878538978106 = 9674632000314 := by decide
theorem cert_e878538978106 : check e878538978106 [] .sourceHead = true := by decide
def e878538978202 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e878538978202 : Closed e878538978202 ∧ code e878538978202 = 9674632000410 := by decide
theorem cert_e878538978202 : check e878538978202 [] .sourceHead = true := by decide
def e878539115374 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e878539115374 : Closed e878539115374 ∧ code e878539115374 = 9674632137582 := by decide
theorem cert_e878539115374 : check e878539115374 [] .sourceHead = true := by decide
def e878539115382 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e878539115382 : Closed e878539115382 ∧ code e878539115382 = 9674632137590 := by decide
theorem cert_e878539115382 : check e878539115382 [] .sourceHead = true := by decide
def e878539115438 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e878539115438 : Closed e878539115438 ∧ code e878539115438 = 9674632137646 := by decide
theorem cert_e878539115438 : check e878539115438 [] .sourceHead = true := by decide
def e878539115450 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e878539115450 : Closed e878539115450 ∧ code e878539115450 = 9674632137658 := by decide
theorem cert_e878539115450 : check e878539115450 [] .sourceHead = true := by decide
def e878539115478 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e878539115478 : Closed e878539115478 ∧ code e878539115478 = 9674632137686 := by decide
theorem cert_e878539115478 : check e878539115478 [] .sourceHead = true := by decide
def e878539115482 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e878539115482 : Closed e878539115482 ∧ code e878539115482 = 9674632137690 := by decide
theorem cert_e878539115482 : check e878539115482 [] .sourceHead = true := by decide
def e878539115758 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e878539115758 : Closed e878539115758 ∧ code e878539115758 = 9674632137966 := by decide
theorem cert_e878539115758 : check e878539115758 [] .sourceHead = true := by decide
def e878539115766 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e878539115766 : Closed e878539115766 ∧ code e878539115766 = 9674632137974 := by decide
theorem cert_e878539115766 : check e878539115766 [] .sourceHead = true := by decide
def e878539116142 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e878539116142 : Closed e878539116142 ∧ code e878539116142 = 9674632138350 := by decide
theorem cert_e878539116142 : check e878539116142 [] .sourceHead = true := by decide
def e878539116154 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e878539116154 : Closed e878539116154 ∧ code e878539116154 = 9674632138362 := by decide
theorem cert_e878539116154 : check e878539116154 [] .sourceHead = true := by decide
def e878539116342 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e878539116342 : Closed e878539116342 ∧ code e878539116342 = 9674632138550 := by decide
theorem cert_e878539116342 : check e878539116342 [] .sourceHead = true := by decide
def e878539116346 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e878539116346 : Closed e878539116346 ∧ code e878539116346 = 9674632138554 := by decide
theorem cert_e878539116346 : check e878539116346 [] .sourceHead = true := by decide
def e878539705198 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e878539705198 : Closed e878539705198 ∧ code e878539705198 = 9674632727406 := by decide
theorem cert_e878539705198 : check e878539705198 [] .sourceHead = true := by decide
def e878539705206 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e878539705206 : Closed e878539705206 ∧ code e878539705206 = 9674632727414 := by decide
theorem cert_e878539705206 : check e878539705206 [] .sourceHead = true := by decide
def e878539705262 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e878539705262 : Closed e878539705262 ∧ code e878539705262 = 9674632727470 := by decide
theorem cert_e878539705262 : check e878539705262 [] .sourceHead = true := by decide
def e878539705274 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e878539705274 : Closed e878539705274 ∧ code e878539705274 = 9674632727482 := by decide
theorem cert_e878539705274 : check e878539705274 [] .sourceHead = true := by decide
def e878539705302 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e878539705302 : Closed e878539705302 ∧ code e878539705302 = 9674632727510 := by decide
theorem cert_e878539705302 : check e878539705302 [] .sourceHead = true := by decide
def e878539705306 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e878539705306 : Closed e878539705306 ∧ code e878539705306 = 9674632727514 := by decide
theorem cert_e878539705306 : check e878539705306 [] .sourceHead = true := by decide
def e878539705582 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e878539705582 : Closed e878539705582 ∧ code e878539705582 = 9674632727790 := by decide
theorem cert_e878539705582 : check e878539705582 [] .sourceHead = true := by decide
def e878539705590 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e878539705590 : Closed e878539705590 ∧ code e878539705590 = 9674632727798 := by decide
theorem cert_e878539705590 : check e878539705590 [] .sourceHead = true := by decide
def e878539705966 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e878539705966 : Closed e878539705966 ∧ code e878539705966 = 9674632728174 := by decide
theorem cert_e878539705966 : check e878539705966 [] .sourceHead = true := by decide
def e878539705978 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e878539705978 : Closed e878539705978 ∧ code e878539705978 = 9674632728186 := by decide
theorem cert_e878539705978 : check e878539705978 [] .sourceHead = true := by decide
def e878539706166 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e878539706166 : Closed e878539706166 ∧ code e878539706166 = 9674632728374 := by decide
theorem cert_e878539706166 : check e878539706166 [] .sourceHead = true := by decide
def e878539706170 : Term := (.lam (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e878539706170 : Closed e878539706170 ∧ code e878539706170 = 9674632728378 := by decide
theorem cert_e878539706170 : check e878539706170 [] .sourceHead = true := by decide
def e2210522914842 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210522914842 : Closed e2210522914842 ∧ code e2210522914842 = 11006615937050 := by decide
theorem cert_e2210522914842 : check e2210522914842 [[]] .width = true := by decide
def e2210522914934 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210522914934 : Closed e2210522914934 ∧ code e2210522914934 = 11006615937142 := by decide
theorem cert_e2210522914934 : check e2210522914934 [[]] .width = true := by decide
def e2210522915178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210522915178 : Closed e2210522915178 ∧ code e2210522915178 = 11006615937386 := by decide
theorem cert_e2210522915178 : check e2210522915178 [[]] .width = true := by decide
def e2210522915226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210522915226 : Closed e2210522915226 ∧ code e2210522915226 = 11006615937434 := by decide
theorem cert_e2210522915226 : check e2210522915226 [[]] .width = true := by decide
def e2210523439130 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210523439130 : Closed e2210523439130 ∧ code e2210523439130 = 11006616461338 := by decide
theorem cert_e2210523439130 : check e2210523439130 [[]] .width = true := by decide
def e2210523439222 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210523439222 : Closed e2210523439222 ∧ code e2210523439222 = 11006616461430 := by decide
theorem cert_e2210523439222 : check e2210523439222 [[]] .width = true := by decide
def e2210523439466 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210523439466 : Closed e2210523439466 ∧ code e2210523439466 = 11006616461674 := by decide
theorem cert_e2210523439466 : check e2210523439466 [[]] .width = true := by decide
def e2210523439514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210523439514 : Closed e2210523439514 ∧ code e2210523439514 = 11006616461722 := by decide
theorem cert_e2210523439514 : check e2210523439514 [[]] .width = true := by decide
def e2210523471898 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210523471898 : Closed e2210523471898 ∧ code e2210523471898 = 11006616494106 := by decide
theorem cert_e2210523471898 : check e2210523471898 [[]] .width = true := by decide
def e2210523471990 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210523471990 : Closed e2210523471990 ∧ code e2210523471990 = 11006616494198 := by decide
theorem cert_e2210523471990 : check e2210523471990 [[]] .width = true := by decide
def e2210523472234 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210523472234 : Closed e2210523472234 ∧ code e2210523472234 = 11006616494442 := by decide
theorem cert_e2210523472234 : check e2210523472234 [[]] .width = true := by decide
def e2210523472282 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210523472282 : Closed e2210523472282 ∧ code e2210523472282 = 11006616494490 := by decide
theorem cert_e2210523472282 : check e2210523472282 [[]] .width = true := by decide
def e2210527109146 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210527109146 : Closed e2210527109146 ∧ code e2210527109146 = 11006620131354 := by decide
theorem cert_e2210527109146 : check e2210527109146 [[]] .width = true := by decide
def e2210527109238 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210527109238 : Closed e2210527109238 ∧ code e2210527109238 = 11006620131446 := by decide
theorem cert_e2210527109238 : check e2210527109238 [[]] .width = true := by decide
def e2210527109482 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210527109482 : Closed e2210527109482 ∧ code e2210527109482 = 11006620131690 := by decide
theorem cert_e2210527109482 : check e2210527109482 [[]] .width = true := by decide
def e2210527109530 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210527109530 : Closed e2210527109530 ∧ code e2210527109530 = 11006620131738 := by decide
theorem cert_e2210527109530 : check e2210527109530 [[]] .width = true := by decide
def e2210527895578 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210527895578 : Closed e2210527895578 ∧ code e2210527895578 = 11006620917786 := by decide
theorem cert_e2210527895578 : check e2210527895578 [[]] .width = true := by decide
def e2210527895670 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210527895670 : Closed e2210527895670 ∧ code e2210527895670 = 11006620917878 := by decide
theorem cert_e2210527895670 : check e2210527895670 [[]] .width = true := by decide
def e2210527895914 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210527895914 : Closed e2210527895914 ∧ code e2210527895914 = 11006620918122 := by decide
theorem cert_e2210527895914 : check e2210527895914 [[]] .width = true := by decide
def e2210527895962 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210527895962 : Closed e2210527895962 ∧ code e2210527895962 = 11006620918170 := by decide
theorem cert_e2210527895962 : check e2210527895962 [[]] .width = true := by decide
def e2210527944730 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210527944730 : Closed e2210527944730 ∧ code e2210527944730 = 11006620966938 := by decide
theorem cert_e2210527944730 : check e2210527944730 [[]] .width = true := by decide
def e2210527944822 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210527944822 : Closed e2210527944822 ∧ code e2210527944822 = 11006620967030 := by decide
theorem cert_e2210527944822 : check e2210527944822 [[]] .width = true := by decide
def e2210527945066 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210527945066 : Closed e2210527945066 ∧ code e2210527945066 = 11006620967274 := by decide
theorem cert_e2210527945066 : check e2210527945066 [[]] .width = true := by decide
def e2210527945114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210527945114 : Closed e2210527945114 ∧ code e2210527945114 = 11006620967322 := by decide
theorem cert_e2210527945114 : check e2210527945114 [[]] .width = true := by decide
def e2210527950874 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210527950874 : Closed e2210527950874 ∧ code e2210527950874 = 11006620973082 := by decide
theorem cert_e2210527950874 : check e2210527950874 [[]] .width = true := by decide
def e2210529730586 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210529730586 : Closed e2210529730586 ∧ code e2210529730586 = 11006622752794 := by decide
theorem cert_e2210529730586 : check e2210529730586 [[]] .width = true := by decide
def e2210529730678 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210529730678 : Closed e2210529730678 ∧ code e2210529730678 = 11006622752886 := by decide
theorem cert_e2210529730678 : check e2210529730678 [[]] .width = true := by decide
def e2210529730922 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210529730922 : Closed e2210529730922 ∧ code e2210529730922 = 11006622753130 := by decide
theorem cert_e2210529730922 : check e2210529730922 [[]] .width = true := by decide
def e2210529730970 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210529730970 : Closed e2210529730970 ∧ code e2210529730970 = 11006622753178 := by decide
theorem cert_e2210529730970 : check e2210529730970 [[]] .width = true := by decide
def e2210529763354 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210529763354 : Closed e2210529763354 ∧ code e2210529763354 = 11006622785562 := by decide
theorem cert_e2210529763354 : check e2210529763354 [[]] .width = true := by decide
def e2210529763446 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210529763446 : Closed e2210529763446 ∧ code e2210529763446 = 11006622785654 := by decide
theorem cert_e2210529763446 : check e2210529763446 [[]] .width = true := by decide
def e2210529763690 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210529763690 : Closed e2210529763690 ∧ code e2210529763690 = 11006622785898 := by decide
theorem cert_e2210529763690 : check e2210529763690 [[]] .width = true := by decide
def e2210529763738 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210529763738 : Closed e2210529763738 ∧ code e2210529763738 = 11006622785946 := by decide
theorem cert_e2210529763738 : check e2210529763738 [[]] .width = true := by decide
def e2210529992730 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210529992730 : Closed e2210529992730 ∧ code e2210529992730 = 11006623014938 := by decide
theorem cert_e2210529992730 : check e2210529992730 [[]] .width = true := by decide
def e2210529992822 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210529992822 : Closed e2210529992822 ∧ code e2210529992822 = 11006623015030 := by decide
theorem cert_e2210529992822 : check e2210529992822 [[]] .width = true := by decide
def e2210529993066 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210529993066 : Closed e2210529993066 ∧ code e2210529993066 = 11006623015274 := by decide
theorem cert_e2210529993066 : check e2210529993066 [[]] .width = true := by decide
def e2210529993114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210529993114 : Closed e2210529993114 ∧ code e2210529993114 = 11006623015322 := by decide
theorem cert_e2210529993114 : check e2210529993114 [[]] .width = true := by decide
def e2210530041882 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210530041882 : Closed e2210530041882 ∧ code e2210530041882 = 11006623064090 := by decide
theorem cert_e2210530041882 : check e2210530041882 [[]] .width = true := by decide
def e2210530041974 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210530041974 : Closed e2210530041974 ∧ code e2210530041974 = 11006623064182 := by decide
theorem cert_e2210530041974 : check e2210530041974 [[]] .width = true := by decide
def e2210530042218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210530042218 : Closed e2210530042218 ∧ code e2210530042218 = 11006623064426 := by decide
theorem cert_e2210530042218 : check e2210530042218 [[]] .width = true := by decide
def e2210530042266 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210530042266 : Closed e2210530042266 ∧ code e2210530042266 = 11006623064474 := by decide
theorem cert_e2210530042266 : check e2210530042266 [[]] .width = true := by decide
def e2210530048026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210530048026 : Closed e2210530048026 ∧ code e2210530048026 = 11006623070234 := by decide
theorem cert_e2210530048026 : check e2210530048026 [[]] .width = true := by decide
def e2210530156570 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210530156570 : Closed e2210530156570 ∧ code e2210530156570 = 11006623178778 := by decide
theorem cert_e2210530156570 : check e2210530156570 [[]] .width = true := by decide
def e2210530156662 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210530156662 : Closed e2210530156662 ∧ code e2210530156662 = 11006623178870 := by decide
theorem cert_e2210530156662 : check e2210530156662 [[]] .width = true := by decide
def e2210530156906 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210530156906 : Closed e2210530156906 ∧ code e2210530156906 = 11006623179114 := by decide
theorem cert_e2210530156906 : check e2210530156906 [[]] .width = true := by decide
def e2210530156954 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210530156954 : Closed e2210530156954 ∧ code e2210530156954 = 11006623179162 := by decide
theorem cert_e2210530156954 : check e2210530156954 [[]] .width = true := by decide
def e2210530172954 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210530172954 : Closed e2210530172954 ∧ code e2210530172954 = 11006623195162 := by decide
theorem cert_e2210530172954 : check e2210530172954 [[]] .width = true := by decide
def e2210530173046 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210530173046 : Closed e2210530173046 ∧ code e2210530173046 = 11006623195254 := by decide
theorem cert_e2210530173046 : check e2210530173046 [[]] .width = true := by decide
def e2210530173290 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210530173290 : Closed e2210530173290 ∧ code e2210530173290 = 11006623195498 := by decide
theorem cert_e2210530173290 : check e2210530173290 [[]] .width = true := by decide
def e2210530173338 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210530173338 : Closed e2210530173338 ∧ code e2210530173338 = 11006623195546 := by decide
theorem cert_e2210530173338 : check e2210530173338 [[]] .width = true := by decide
def e2210530179098 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210530179098 : Closed e2210530179098 ∧ code e2210530179098 = 11006623201306 := by decide
theorem cert_e2210530179098 : check e2210530179098 [[]] .width = true := by decide
def e2210530187290 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210530187290 : Closed e2210530187290 ∧ code e2210530187290 = 11006623209498 := by decide
theorem cert_e2210530187290 : check e2210530187290 [[]] .width = true := by decide
def e2210543886362 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210543886362 : Closed e2210543886362 ∧ code e2210543886362 = 11006636908570 := by decide
theorem cert_e2210543886362 : check e2210543886362 [[]] .width = true := by decide
def e2210543886454 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210543886454 : Closed e2210543886454 ∧ code e2210543886454 = 11006636908662 := by decide
theorem cert_e2210543886454 : check e2210543886454 [[]] .width = true := by decide
def e2210543886698 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210543886698 : Closed e2210543886698 ∧ code e2210543886698 = 11006636908906 := by decide
theorem cert_e2210543886698 : check e2210543886698 [[]] .width = true := by decide
def e2210543886746 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210543886746 : Closed e2210543886746 ∧ code e2210543886746 = 11006636908954 := by decide
theorem cert_e2210543886746 : check e2210543886746 [[]] .width = true := by decide
def e2210544672794 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210544672794 : Closed e2210544672794 ∧ code e2210544672794 = 11006637695002 := by decide
theorem cert_e2210544672794 : check e2210544672794 [[]] .width = true := by decide
def e2210544672886 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210544672886 : Closed e2210544672886 ∧ code e2210544672886 = 11006637695094 := by decide
theorem cert_e2210544672886 : check e2210544672886 [[]] .width = true := by decide
def e2210544673130 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210544673130 : Closed e2210544673130 ∧ code e2210544673130 = 11006637695338 := by decide
theorem cert_e2210544673130 : check e2210544673130 [[]] .width = true := by decide
def e2210544673178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210544673178 : Closed e2210544673178 ∧ code e2210544673178 = 11006637695386 := by decide
theorem cert_e2210544673178 : check e2210544673178 [[]] .width = true := by decide
def e2210544721946 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210544721946 : Closed e2210544721946 ∧ code e2210544721946 = 11006637744154 := by decide
theorem cert_e2210544721946 : check e2210544721946 [[]] .width = true := by decide
def e2210544722038 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210544722038 : Closed e2210544722038 ∧ code e2210544722038 = 11006637744246 := by decide
theorem cert_e2210544722038 : check e2210544722038 [[]] .width = true := by decide
def e2210544722282 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210544722282 : Closed e2210544722282 ∧ code e2210544722282 = 11006637744490 := by decide
theorem cert_e2210544722282 : check e2210544722282 [[]] .width = true := by decide
def e2210544722330 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210544722330 : Closed e2210544722330 ∧ code e2210544722330 = 11006637744538 := by decide
theorem cert_e2210544722330 : check e2210544722330 [[]] .width = true := by decide
def e2210544728090 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210544728090 : Closed e2210544728090 ∧ code e2210544728090 = 11006637750298 := by decide
theorem cert_e2210544728090 : check e2210544728090 [[]] .width = true := by decide
def e2210547818522 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210547818522 : Closed e2210547818522 ∧ code e2210547818522 = 11006640840730 := by decide
theorem cert_e2210547818522 : check e2210547818522 [[]] .width = true := by decide
def e2210547818614 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210547818614 : Closed e2210547818614 ∧ code e2210547818614 = 11006640840822 := by decide
theorem cert_e2210547818614 : check e2210547818614 [[]] .width = true := by decide
def e2210547818858 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210547818858 : Closed e2210547818858 ∧ code e2210547818858 = 11006640841066 := by decide
theorem cert_e2210547818858 : check e2210547818858 [[]] .width = true := by decide
def e2210547818906 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210547818906 : Closed e2210547818906 ∧ code e2210547818906 = 11006640841114 := by decide
theorem cert_e2210547818906 : check e2210547818906 [[]] .width = true := by decide
def e2210547867674 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210547867674 : Closed e2210547867674 ∧ code e2210547867674 = 11006640889882 := by decide
theorem cert_e2210547867674 : check e2210547867674 [[]] .width = true := by decide
def e2210547867766 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210547867766 : Closed e2210547867766 ∧ code e2210547867766 = 11006640889974 := by decide
theorem cert_e2210547867766 : check e2210547867766 [[]] .width = true := by decide
def e2210547868010 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210547868010 : Closed e2210547868010 ∧ code e2210547868010 = 11006640890218 := by decide
theorem cert_e2210547868010 : check e2210547868010 [[]] .width = true := by decide
def e2210547868058 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210547868058 : Closed e2210547868058 ∧ code e2210547868058 = 11006640890266 := by decide
theorem cert_e2210547868058 : check e2210547868058 [[]] .width = true := by decide
def e2210547873818 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210547873818 : Closed e2210547873818 ∧ code e2210547873818 = 11006640896026 := by decide
theorem cert_e2210547873818 : check e2210547873818 [[]] .width = true := by decide
def e2210548064282 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210548064282 : Closed e2210548064282 ∧ code e2210548064282 = 11006641086490 := by decide
theorem cert_e2210548064282 : check e2210548064282 [[]] .width = true := by decide
def e2210548064374 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210548064374 : Closed e2210548064374 ∧ code e2210548064374 = 11006641086582 := by decide
theorem cert_e2210548064374 : check e2210548064374 [[]] .width = true := by decide
def e2210548064618 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210548064618 : Closed e2210548064618 ∧ code e2210548064618 = 11006641086826 := by decide
theorem cert_e2210548064618 : check e2210548064618 [[]] .width = true := by decide
def e2210548064666 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210548064666 : Closed e2210548064666 ∧ code e2210548064666 = 11006641086874 := by decide
theorem cert_e2210548064666 : check e2210548064666 [[]] .width = true := by decide
def e2210548070426 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210548070426 : Closed e2210548070426 ∧ code e2210548070426 = 11006641092634 := by decide
theorem cert_e2210548070426 : check e2210548070426 [[]] .width = true := by decide
def e2210548082714 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210548082714 : Closed e2210548082714 ∧ code e2210548082714 = 11006641104922 := by decide
theorem cert_e2210548082714 : check e2210548082714 [[]] .width = true := by decide
def e2210554896410 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210554896410 : Closed e2210554896410 ∧ code e2210554896410 = 11006647918618 := by decide
theorem cert_e2210554896410 : check e2210554896410 [[]] .width = true := by decide
def e2210554896502 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210554896502 : Closed e2210554896502 ∧ code e2210554896502 = 11006647918710 := by decide
theorem cert_e2210554896502 : check e2210554896502 [[]] .width = true := by decide
def e2210554896746 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210554896746 : Closed e2210554896746 ∧ code e2210554896746 = 11006647918954 := by decide
theorem cert_e2210554896746 : check e2210554896746 [[]] .width = true := by decide
def e2210554896794 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210554896794 : Closed e2210554896794 ∧ code e2210554896794 = 11006647919002 := by decide
theorem cert_e2210554896794 : check e2210554896794 [[]] .width = true := by decide
def e2210554929178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210554929178 : Closed e2210554929178 ∧ code e2210554929178 = 11006647951386 := by decide
theorem cert_e2210554929178 : check e2210554929178 [[]] .width = true := by decide
def e2210554929270 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210554929270 : Closed e2210554929270 ∧ code e2210554929270 = 11006647951478 := by decide
theorem cert_e2210554929270 : check e2210554929270 [[]] .width = true := by decide
def e2210554929514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210554929514 : Closed e2210554929514 ∧ code e2210554929514 = 11006647951722 := by decide
theorem cert_e2210554929514 : check e2210554929514 [[]] .width = true := by decide
def e2210554929562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210554929562 : Closed e2210554929562 ∧ code e2210554929562 = 11006647951770 := by decide
theorem cert_e2210554929562 : check e2210554929562 [[]] .width = true := by decide
def e2210555158554 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210555158554 : Closed e2210555158554 ∧ code e2210555158554 = 11006648180762 := by decide
theorem cert_e2210555158554 : check e2210555158554 [[]] .width = true := by decide
def e2210555158646 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210555158646 : Closed e2210555158646 ∧ code e2210555158646 = 11006648180854 := by decide
theorem cert_e2210555158646 : check e2210555158646 [[]] .width = true := by decide
def e2210555158890 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210555158890 : Closed e2210555158890 ∧ code e2210555158890 = 11006648181098 := by decide
theorem cert_e2210555158890 : check e2210555158890 [[]] .width = true := by decide
def e2210555158938 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210555158938 : Closed e2210555158938 ∧ code e2210555158938 = 11006648181146 := by decide
theorem cert_e2210555158938 : check e2210555158938 [[]] .width = true := by decide
def e2210555207706 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210555207706 : Closed e2210555207706 ∧ code e2210555207706 = 11006648229914 := by decide
theorem cert_e2210555207706 : check e2210555207706 [[]] .width = true := by decide
def e2210555207798 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210555207798 : Closed e2210555207798 ∧ code e2210555207798 = 11006648230006 := by decide
theorem cert_e2210555207798 : check e2210555207798 [[]] .width = true := by decide
def e2210555208042 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210555208042 : Closed e2210555208042 ∧ code e2210555208042 = 11006648230250 := by decide
theorem cert_e2210555208042 : check e2210555208042 [[]] .width = true := by decide
def e2210555208090 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210555208090 : Closed e2210555208090 ∧ code e2210555208090 = 11006648230298 := by decide
theorem cert_e2210555208090 : check e2210555208090 [[]] .width = true := by decide
def e2210555213850 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210555213850 : Closed e2210555213850 ∧ code e2210555213850 = 11006648236058 := by decide
theorem cert_e2210555213850 : check e2210555213850 [[]] .width = true := by decide
def e2210555322394 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210555322394 : Closed e2210555322394 ∧ code e2210555322394 = 11006648344602 := by decide
theorem cert_e2210555322394 : check e2210555322394 [[]] .width = true := by decide
def e2210555322486 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210555322486 : Closed e2210555322486 ∧ code e2210555322486 = 11006648344694 := by decide
theorem cert_e2210555322486 : check e2210555322486 [[]] .width = true := by decide
def e2210555322730 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210555322730 : Closed e2210555322730 ∧ code e2210555322730 = 11006648344938 := by decide
theorem cert_e2210555322730 : check e2210555322730 [[]] .width = true := by decide
def e2210555322778 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210555322778 : Closed e2210555322778 ∧ code e2210555322778 = 11006648344986 := by decide
theorem cert_e2210555322778 : check e2210555322778 [[]] .width = true := by decide
def e2210555338778 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210555338778 : Closed e2210555338778 ∧ code e2210555338778 = 11006648360986 := by decide
theorem cert_e2210555338778 : check e2210555338778 [[]] .width = true := by decide
def e2210555338870 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210555338870 : Closed e2210555338870 ∧ code e2210555338870 = 11006648361078 := by decide
theorem cert_e2210555338870 : check e2210555338870 [[]] .width = true := by decide
def e2210555339114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210555339114 : Closed e2210555339114 ∧ code e2210555339114 = 11006648361322 := by decide
theorem cert_e2210555339114 : check e2210555339114 [[]] .width = true := by decide
def e2210555339162 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210555339162 : Closed e2210555339162 ∧ code e2210555339162 = 11006648361370 := by decide
theorem cert_e2210555339162 : check e2210555339162 [[]] .width = true := by decide
def e2210555344922 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210555344922 : Closed e2210555344922 ∧ code e2210555344922 = 11006648367130 := by decide
theorem cert_e2210555344922 : check e2210555344922 [[]] .width = true := by decide
def e2210555353114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210555353114 : Closed e2210555353114 ∧ code e2210555353114 = 11006648375322 := by decide
theorem cert_e2210555353114 : check e2210555353114 [[]] .width = true := by decide
def e2210556207130 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210556207130 : Closed e2210556207130 ∧ code e2210556207130 = 11006649229338 := by decide
theorem cert_e2210556207130 : check e2210556207130 [[]] .width = true := by decide
def e2210556207222 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210556207222 : Closed e2210556207222 ∧ code e2210556207222 = 11006649229430 := by decide
theorem cert_e2210556207222 : check e2210556207222 [[]] .width = true := by decide
def e2210556207466 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210556207466 : Closed e2210556207466 ∧ code e2210556207466 = 11006649229674 := by decide
theorem cert_e2210556207466 : check e2210556207466 [[]] .width = true := by decide
end Blc.Floor43
