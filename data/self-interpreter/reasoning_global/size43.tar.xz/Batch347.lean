import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419141271194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141271194 : Closed e2419141271194 ∧ code e2419141271194 = 11215234293402 := by decide
theorem cert_e2419141271194 : check e2419141271194 [[],[]] .smaller = true := by decide
def e2419141271238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2419141271238 : Closed e2419141271238 ∧ code e2419141271238 = 11215234293446 := by decide
theorem cert_e2419141271238 : check e2419141271238 [[],[]] .smaller = true := by decide
def e2419141271262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2419141271262 : Closed e2419141271262 ∧ code e2419141271262 = 11215234293470 := by decide
theorem cert_e2419141271262 : check e2419141271262 [[],[]] .three = true := by decide
def e2419141271286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2419141271286 : Closed e2419141271286 ∧ code e2419141271286 = 11215234293494 := by decide
theorem cert_e2419141271286 : check e2419141271286 [[],[]] .three = true := by decide
def e2419141271322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2419141271322 : Closed e2419141271322 ∧ code e2419141271322 = 11215234293530 := by decide
theorem cert_e2419141271322 : check e2419141271322 [[],[]] .three = true := by decide
def e2419141271366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2419141271366 : Closed e2419141271366 ∧ code e2419141271366 = 11215234293574 := by decide
theorem cert_e2419141271366 : check e2419141271366 [[],[]] .three = true := by decide
def e2419141271390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 3))))))))
theorem wire_e2419141271390 : Closed e2419141271390 ∧ code e2419141271390 = 11215234293598 := by decide
theorem cert_e2419141271390 : check e2419141271390 [[],[]] .three = true := by decide
def e2419141271406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2419141271406 : Closed e2419141271406 ∧ code e2419141271406 = 11215234293614 := by decide
theorem cert_e2419141271406 : check e2419141271406 [[],[]] .three = true := by decide
def e2419141271414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2419141271414 : Closed e2419141271414 ∧ code e2419141271414 = 11215234293622 := by decide
theorem cert_e2419141271414 : check e2419141271414 [[],[]] .three = true := by decide
def e2419141271418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 0))))))))
theorem wire_e2419141271418 : Closed e2419141271418 ∧ code e2419141271418 = 11215234293626 := by decide
theorem cert_e2419141271418 : check e2419141271418 [[],[]] .three = true := by decide
def e2419141272030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2419141272030 : Closed e2419141272030 ∧ code e2419141272030 = 11215234294238 := by decide
theorem cert_e2419141272030 : check e2419141272030 [[],[]] .smaller = true := by decide
def e2419141272054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2419141272054 : Closed e2419141272054 ∧ code e2419141272054 = 11215234294262 := by decide
theorem cert_e2419141272054 : check e2419141272054 [[],[]] .smaller = true := by decide
def e2419141273006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2419141273006 : Closed e2419141273006 ∧ code e2419141273006 = 11215234295214 := by decide
theorem cert_e2419141273006 : check e2419141273006 [[],[]] .smaller = true := by decide
def e2419141273018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2419141273018 : Closed e2419141273018 ∧ code e2419141273018 = 11215234295226 := by decide
theorem cert_e2419141273018 : check e2419141273018 [[],[]] .smaller = true := by decide
def e2419141273066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2419141273066 : Closed e2419141273066 ∧ code e2419141273066 = 11215234295274 := by decide
theorem cert_e2419141273066 : check e2419141273066 [[],[]] .smaller = true := by decide
def e2419141273150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2419141273150 : Closed e2419141273150 ∧ code e2419141273150 = 11215234295358 := by decide
theorem cert_e2419141273150 : check e2419141273150 [[],[]] .three = true := by decide
def e2419141273198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419141273198 : Closed e2419141273198 ∧ code e2419141273198 = 11215234295406 := by decide
theorem cert_e2419141273198 : check e2419141273198 [[],[]] .smaller = true := by decide
def e2419141273210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419141273210 : Closed e2419141273210 ∧ code e2419141273210 = 11215234295418 := by decide
theorem cert_e2419141273210 : check e2419141273210 [[],[]] .smaller = true := by decide
def e2419141273374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2419141273374 : Closed e2419141273374 ∧ code e2419141273374 = 11215234295582 := by decide
theorem cert_e2419141273374 : check e2419141273374 [[],[]] .smaller = true := by decide
def e2419141273486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2419141273486 : Closed e2419141273486 ∧ code e2419141273486 = 11215234295694 := by decide
theorem cert_e2419141273486 : check e2419141273486 [[],[]] .smaller = true := by decide
def e2419141273498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419141273498 : Closed e2419141273498 ∧ code e2419141273498 = 11215234295706 := by decide
theorem cert_e2419141273498 : check e2419141273498 [[],[]] .smaller = true := by decide
def e2419141273542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2419141273542 : Closed e2419141273542 ∧ code e2419141273542 = 11215234295750 := by decide
theorem cert_e2419141273542 : check e2419141273542 [[],[]] .three = true := by decide
def e2419141273566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 3)))))))))
theorem wire_e2419141273566 : Closed e2419141273566 ∧ code e2419141273566 = 11215234295774 := by decide
theorem cert_e2419141273566 : check e2419141273566 [[],[]] .three = true := by decide
def e2419141276446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2419141276446 : Closed e2419141276446 ∧ code e2419141276446 = 11215234298654 := by decide
theorem cert_e2419141276446 : check e2419141276446 [[],[]] .smaller = true := by decide
def e2419141276614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2419141276614 : Closed e2419141276614 ∧ code e2419141276614 = 11215234298822 := by decide
theorem cert_e2419141276614 : check e2419141276614 [[],[]] .smaller = true := by decide
def e2419141276638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2419141276638 : Closed e2419141276638 ∧ code e2419141276638 = 11215234298846 := by decide
theorem cert_e2419141276638 : check e2419141276638 [[],[]] .three = true := by decide
def e2419141276654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2419141276654 : Closed e2419141276654 ∧ code e2419141276654 = 11215234298862 := by decide
theorem cert_e2419141276654 : check e2419141276654 [[],[]] .three = true := by decide
def e2419141277814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2419141277814 : Closed e2419141277814 ∧ code e2419141277814 = 11215234300022 := by decide
theorem cert_e2419141277814 : check e2419141277814 [[],[]] .smaller = true := by decide
def e2419141278058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2419141278058 : Closed e2419141278058 ∧ code e2419141278058 = 11215234300266 := by decide
theorem cert_e2419141278058 : check e2419141278058 [[],[]] .smaller = true := by decide
def e2419141278094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2419141278094 : Closed e2419141278094 ∧ code e2419141278094 = 11215234300302 := by decide
theorem cert_e2419141278094 : check e2419141278094 [[],[]] .smaller = true := by decide
def e2419141278106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419141278106 : Closed e2419141278106 ∧ code e2419141278106 = 11215234300314 := by decide
theorem cert_e2419141278106 : check e2419141278106 [[],[]] .smaller = true := by decide
def e2419141278150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2419141278150 : Closed e2419141278150 ∧ code e2419141278150 = 11215234300358 := by decide
theorem cert_e2419141278150 : check e2419141278150 [[],[]] .smaller = true := by decide
def e2419141278174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2419141278174 : Closed e2419141278174 ∧ code e2419141278174 = 11215234300382 := by decide
theorem cert_e2419141278174 : check e2419141278174 [[],[]] .three = true := by decide
def e2419141278198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2419141278198 : Closed e2419141278198 ∧ code e2419141278198 = 11215234300406 := by decide
theorem cert_e2419141278198 : check e2419141278198 [[],[]] .three = true := by decide
def e2419141278918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2419141278918 : Closed e2419141278918 ∧ code e2419141278918 = 11215234301126 := by decide
theorem cert_e2419141278918 : check e2419141278918 [[],[]] .three = true := by decide
def e2419141278942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 3)))))))))
theorem wire_e2419141278942 : Closed e2419141278942 ∧ code e2419141278942 = 11215234301150 := by decide
theorem cert_e2419141278942 : check e2419141278942 [[],[]] .three = true := by decide
def e2419141278958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419141278958 : Closed e2419141278958 ∧ code e2419141278958 = 11215234301166 := by decide
theorem cert_e2419141278958 : check e2419141278958 [[],[]] .three = true := by decide
def e2419141278966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419141278966 : Closed e2419141278966 ∧ code e2419141278966 = 11215234301174 := by decide
theorem cert_e2419141278966 : check e2419141278966 [[],[]] .three = true := by decide
def e2419141278970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 0)))))))))
theorem wire_e2419141278970 : Closed e2419141278970 ∧ code e2419141278970 = 11215234301178 := by decide
theorem cert_e2419141278970 : check e2419141278970 [[],[]] .three = true := by decide
def e2419141323606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2419141323606 : Closed e2419141323606 ∧ code e2419141323606 = 11215234345814 := by decide
theorem cert_e2419141323606 : check e2419141323606 [[],[]] .smaller = true := by decide
def e2419141323610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2419141323610 : Closed e2419141323610 ∧ code e2419141323610 = 11215234345818 := by decide
theorem cert_e2419141323610 : check e2419141323610 [[],[]] .smaller = true := by decide
def e2419141323626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2419141323626 : Closed e2419141323626 ∧ code e2419141323626 = 11215234345834 := by decide
theorem cert_e2419141323626 : check e2419141323626 [[],[]] .smaller = true := by decide
def e2419141323690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2419141323690 : Closed e2419141323690 ∧ code e2419141323690 = 11215234345898 := by decide
theorem cert_e2419141323690 : check e2419141323690 [[],[]] .smaller = true := by decide
def e2419141323894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2419141323894 : Closed e2419141323894 ∧ code e2419141323894 = 11215234346102 := by decide
theorem cert_e2419141323894 : check e2419141323894 [[],[]] .smaller = true := by decide
def e2419141323990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2419141323990 : Closed e2419141323990 ∧ code e2419141323990 = 11215234346198 := by decide
theorem cert_e2419141323990 : check e2419141323990 [[],[]] .smaller = true := by decide
def e2419141323994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2419141323994 : Closed e2419141323994 ∧ code e2419141323994 = 11215234346202 := by decide
theorem cert_e2419141323994 : check e2419141323994 [[],[]] .smaller = true := by decide
def e2419141324010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2419141324010 : Closed e2419141324010 ∧ code e2419141324010 = 11215234346218 := by decide
theorem cert_e2419141324010 : check e2419141324010 [[],[]] .smaller = true := by decide
def e2419141324086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419141324086 : Closed e2419141324086 ∧ code e2419141324086 = 11215234346294 := by decide
theorem cert_e2419141324086 : check e2419141324086 [[],[]] .smaller = true := by decide
def e2419141324090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419141324090 : Closed e2419141324090 ∧ code e2419141324090 = 11215234346298 := by decide
theorem cert_e2419141324090 : check e2419141324090 [[],[]] .smaller = true := by decide
def e2419141324174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2419141324174 : Closed e2419141324174 ∧ code e2419141324174 = 11215234346382 := by decide
theorem cert_e2419141324174 : check e2419141324174 [[],[]] .smaller = true := by decide
def e2419141324186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141324186 : Closed e2419141324186 ∧ code e2419141324186 = 11215234346394 := by decide
theorem cert_e2419141324186 : check e2419141324186 [[],[]] .smaller = true := by decide
def e2419141324254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2419141324254 : Closed e2419141324254 ∧ code e2419141324254 = 11215234346462 := by decide
theorem cert_e2419141324254 : check e2419141324254 [[],[]] .three = true := by decide
def e2419141324270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2419141324270 : Closed e2419141324270 ∧ code e2419141324270 = 11215234346478 := by decide
theorem cert_e2419141324270 : check e2419141324270 [[],[]] .three = true := by decide
def e2419141324342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2419141324342 : Closed e2419141324342 ∧ code e2419141324342 = 11215234346550 := by decide
theorem cert_e2419141324342 : check e2419141324342 [[],[]] .smaller = true := by decide
def e2419141324346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2419141324346 : Closed e2419141324346 ∧ code e2419141324346 = 11215234346554 := by decide
theorem cert_e2419141324346 : check e2419141324346 [[],[]] .smaller = true := by decide
def e2419141324394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2419141324394 : Closed e2419141324394 ∧ code e2419141324394 = 11215234346602 := by decide
theorem cert_e2419141324394 : check e2419141324394 [[],[]] .smaller = true := by decide
def e2419141324430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2419141324430 : Closed e2419141324430 ∧ code e2419141324430 = 11215234346638 := by decide
theorem cert_e2419141324430 : check e2419141324430 [[],[]] .smaller = true := by decide
def e2419141324442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419141324442 : Closed e2419141324442 ∧ code e2419141324442 = 11215234346650 := by decide
theorem cert_e2419141324442 : check e2419141324442 [[],[]] .smaller = true := by decide
def e2419141324486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2419141324486 : Closed e2419141324486 ∧ code e2419141324486 = 11215234346694 := by decide
theorem cert_e2419141324486 : check e2419141324486 [[],[]] .smaller = true := by decide
def e2419141324510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2419141324510 : Closed e2419141324510 ∧ code e2419141324510 = 11215234346718 := by decide
theorem cert_e2419141324510 : check e2419141324510 [[],[]] .three = true := by decide
def e2419141324534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2419141324534 : Closed e2419141324534 ∧ code e2419141324534 = 11215234346742 := by decide
theorem cert_e2419141324534 : check e2419141324534 [[],[]] .three = true := by decide
def e2419141324638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2419141324638 : Closed e2419141324638 ∧ code e2419141324638 = 11215234346846 := by decide
theorem cert_e2419141324638 : check e2419141324638 [[],[]] .three = true := by decide
def e2419141324666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2419141324666 : Closed e2419141324666 ∧ code e2419141324666 = 11215234346874 := by decide
theorem cert_e2419141324666 : check e2419141324666 [[],[]] .three = true := by decide
def e2419141324718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2419141324718 : Closed e2419141324718 ∧ code e2419141324718 = 11215234346926 := by decide
theorem cert_e2419141324718 : check e2419141324718 [[],[]] .three = true := by decide
def e2419141324726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2419141324726 : Closed e2419141324726 ∧ code e2419141324726 = 11215234346934 := by decide
theorem cert_e2419141324726 : check e2419141324726 [[],[]] .three = true := by decide
def e2419141324730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2419141324730 : Closed e2419141324730 ∧ code e2419141324730 = 11215234346938 := by decide
theorem cert_e2419141324730 : check e2419141324730 [[],[]] .three = true := by decide
def e2419141325038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2419141325038 : Closed e2419141325038 ∧ code e2419141325038 = 11215234347246 := by decide
theorem cert_e2419141325038 : check e2419141325038 [[],[]] .smaller = true := by decide
def e2419141325046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2419141325046 : Closed e2419141325046 ∧ code e2419141325046 = 11215234347254 := by decide
theorem cert_e2419141325046 : check e2419141325046 [[],[]] .smaller = true := by decide
def e2419141325526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2419141325526 : Closed e2419141325526 ∧ code e2419141325526 = 11215234347734 := by decide
theorem cert_e2419141325526 : check e2419141325526 [[],[]] .smaller = true := by decide
def e2419141325530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2419141325530 : Closed e2419141325530 ∧ code e2419141325530 = 11215234347738 := by decide
theorem cert_e2419141325530 : check e2419141325530 [[],[]] .smaller = true := by decide
def e2419141325546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2419141325546 : Closed e2419141325546 ∧ code e2419141325546 = 11215234347754 := by decide
theorem cert_e2419141325546 : check e2419141325546 [[],[]] .smaller = true := by decide
def e2419141325622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419141325622 : Closed e2419141325622 ∧ code e2419141325622 = 11215234347830 := by decide
theorem cert_e2419141325622 : check e2419141325622 [[],[]] .smaller = true := by decide
def e2419141325626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419141325626 : Closed e2419141325626 ∧ code e2419141325626 = 11215234347834 := by decide
theorem cert_e2419141325626 : check e2419141325626 [[],[]] .smaller = true := by decide
def e2419141325710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2419141325710 : Closed e2419141325710 ∧ code e2419141325710 = 11215234347918 := by decide
theorem cert_e2419141325710 : check e2419141325710 [[],[]] .smaller = true := by decide
def e2419141325722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419141325722 : Closed e2419141325722 ∧ code e2419141325722 = 11215234347930 := by decide
theorem cert_e2419141325722 : check e2419141325722 [[],[]] .smaller = true := by decide
def e2419141325790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2419141325790 : Closed e2419141325790 ∧ code e2419141325790 = 11215234347998 := by decide
theorem cert_e2419141325790 : check e2419141325790 [[],[]] .three = true := by decide
def e2419141325806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2419141325806 : Closed e2419141325806 ∧ code e2419141325806 = 11215234348014 := by decide
theorem cert_e2419141325806 : check e2419141325806 [[],[]] .three = true := by decide
def e2419141326966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2419141326966 : Closed e2419141326966 ∧ code e2419141326966 = 11215234349174 := by decide
theorem cert_e2419141326966 : check e2419141326966 [[],[]] .smaller = true := by decide
def e2419141327210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2419141327210 : Closed e2419141327210 ∧ code e2419141327210 = 11215234349418 := by decide
theorem cert_e2419141327210 : check e2419141327210 [[],[]] .smaller = true := by decide
def e2419141327246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2419141327246 : Closed e2419141327246 ∧ code e2419141327246 = 11215234349454 := by decide
theorem cert_e2419141327246 : check e2419141327246 [[],[]] .smaller = true := by decide
def e2419141327258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419141327258 : Closed e2419141327258 ∧ code e2419141327258 = 11215234349466 := by decide
theorem cert_e2419141327258 : check e2419141327258 [[],[]] .smaller = true := by decide
def e2419141327302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2419141327302 : Closed e2419141327302 ∧ code e2419141327302 = 11215234349510 := by decide
theorem cert_e2419141327302 : check e2419141327302 [[],[]] .smaller = true := by decide
def e2419141327326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2419141327326 : Closed e2419141327326 ∧ code e2419141327326 = 11215234349534 := by decide
theorem cert_e2419141327326 : check e2419141327326 [[],[]] .three = true := by decide
def e2419141327350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2419141327350 : Closed e2419141327350 ∧ code e2419141327350 = 11215234349558 := by decide
theorem cert_e2419141327350 : check e2419141327350 [[],[]] .three = true := by decide
def e2419141328094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2419141328094 : Closed e2419141328094 ∧ code e2419141328094 = 11215234350302 := by decide
theorem cert_e2419141328094 : check e2419141328094 [[],[]] .three = true := by decide
def e2419141328122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2419141328122 : Closed e2419141328122 ∧ code e2419141328122 = 11215234350330 := by decide
theorem cert_e2419141328122 : check e2419141328122 [[],[]] .three = true := by decide
def e2419141328494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419141328494 : Closed e2419141328494 ∧ code e2419141328494 = 11215234350702 := by decide
theorem cert_e2419141328494 : check e2419141328494 [[],[]] .three = true := by decide
def e2419141328502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419141328502 : Closed e2419141328502 ∧ code e2419141328502 = 11215234350710 := by decide
theorem cert_e2419141328502 : check e2419141328502 [[],[]] .three = true := by decide
def e2419141328506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419141328506 : Closed e2419141328506 ∧ code e2419141328506 = 11215234350714 := by decide
theorem cert_e2419141328506 : check e2419141328506 [[],[]] .three = true := by decide
def e2419141350966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2419141350966 : Closed e2419141350966 ∧ code e2419141350966 = 11215234373174 := by decide
theorem cert_e2419141350966 : check e2419141350966 [[],[]] .three = true := by decide
def e2419141350970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2419141350970 : Closed e2419141350970 ∧ code e2419141350970 = 11215234373178 := by decide
theorem cert_e2419141350970 : check e2419141350970 [[],[]] .three = true := by decide
def e2419141351054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2419141351054 : Closed e2419141351054 ∧ code e2419141351054 = 11215234373262 := by decide
theorem cert_e2419141351054 : check e2419141351054 [[],[]] .three = true := by decide
def e2419141351110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2419141351110 : Closed e2419141351110 ∧ code e2419141351110 = 11215234373318 := by decide
theorem cert_e2419141351110 : check e2419141351110 [[],[]] .three = true := by decide
def e2419141351134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2419141351134 : Closed e2419141351134 ∧ code e2419141351134 = 11215234373342 := by decide
theorem cert_e2419141351134 : check e2419141351134 [[],[]] .three = true := by decide
def e2419141351150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2419141351150 : Closed e2419141351150 ∧ code e2419141351150 = 11215234373358 := by decide
theorem cert_e2419141351150 : check e2419141351150 [[],[]] .three = true := by decide
def e2419141351158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2419141351158 : Closed e2419141351158 ∧ code e2419141351158 = 11215234373366 := by decide
theorem cert_e2419141351158 : check e2419141351158 [[],[]] .three = true := by decide
def e2419141351194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2419141351194 : Closed e2419141351194 ∧ code e2419141351194 = 11215234373402 := by decide
theorem cert_e2419141351194 : check e2419141351194 [[],[]] .three = true := by decide
def e2419141351238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2419141351238 : Closed e2419141351238 ∧ code e2419141351238 = 11215234373446 := by decide
theorem cert_e2419141351238 : check e2419141351238 [[],[]] .three = true := by decide
def e2419141351262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2419141351262 : Closed e2419141351262 ∧ code e2419141351262 = 11215234373470 := by decide
theorem cert_e2419141351262 : check e2419141351262 [[],[]] .three = true := by decide
def e2419141351278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2419141351278 : Closed e2419141351278 ∧ code e2419141351278 = 11215234373486 := by decide
theorem cert_e2419141351278 : check e2419141351278 [[],[]] .three = true := by decide
def e2419141351286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2419141351286 : Closed e2419141351286 ∧ code e2419141351286 = 11215234373494 := by decide
theorem cert_e2419141351286 : check e2419141351286 [[],[]] .three = true := by decide
def e2419141351290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2419141351290 : Closed e2419141351290 ∧ code e2419141351290 = 11215234373498 := by decide
theorem cert_e2419141351290 : check e2419141351290 [[],[]] .three = true := by decide
def e2419141351342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2419141351342 : Closed e2419141351342 ∧ code e2419141351342 = 11215234373550 := by decide
theorem cert_e2419141351342 : check e2419141351342 [[],[]] .three = true := by decide
def e2419141351350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2419141351350 : Closed e2419141351350 ∧ code e2419141351350 = 11215234373558 := by decide
theorem cert_e2419141351350 : check e2419141351350 [[],[]] .three = true := by decide
def e2419141351354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2419141351354 : Closed e2419141351354 ∧ code e2419141351354 = 11215234373562 := by decide
theorem cert_e2419141351354 : check e2419141351354 [[],[]] .three = true := by decide
def e2419141351382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2419141351382 : Closed e2419141351382 ∧ code e2419141351382 = 11215234373590 := by decide
theorem cert_e2419141351382 : check e2419141351382 [[],[]] .three = true := by decide
def e2419141351386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2419141351386 : Closed e2419141351386 ∧ code e2419141351386 = 11215234373594 := by decide
theorem cert_e2419141351386 : check e2419141351386 [[],[]] .three = true := by decide
def e2419141351822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2419141351822 : Closed e2419141351822 ∧ code e2419141351822 = 11215234374030 := by decide
theorem cert_e2419141351822 : check e2419141351822 [[],[]] .three = true := by decide
def e2419141351878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2419141351878 : Closed e2419141351878 ∧ code e2419141351878 = 11215234374086 := by decide
theorem cert_e2419141351878 : check e2419141351878 [[],[]] .three = true := by decide
def e2419141351902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2419141351902 : Closed e2419141351902 ∧ code e2419141351902 = 11215234374110 := by decide
theorem cert_e2419141351902 : check e2419141351902 [[],[]] .three = true := by decide
def e2419141351918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419141351918 : Closed e2419141351918 ∧ code e2419141351918 = 11215234374126 := by decide
theorem cert_e2419141351918 : check e2419141351918 [[],[]] .three = true := by decide
def e2419141351926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2419141351926 : Closed e2419141351926 ∧ code e2419141351926 = 11215234374134 := by decide
theorem cert_e2419141351926 : check e2419141351926 [[],[]] .three = true := by decide
def e2419141352646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2419141352646 : Closed e2419141352646 ∧ code e2419141352646 = 11215234374854 := by decide
theorem cert_e2419141352646 : check e2419141352646 [[],[]] .three = true := by decide
def e2419141352670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2419141352670 : Closed e2419141352670 ∧ code e2419141352670 = 11215234374878 := by decide
theorem cert_e2419141352670 : check e2419141352670 [[],[]] .three = true := by decide
def e2419141352686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419141352686 : Closed e2419141352686 ∧ code e2419141352686 = 11215234374894 := by decide
theorem cert_e2419141352686 : check e2419141352686 [[],[]] .three = true := by decide
def e2419141352694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419141352694 : Closed e2419141352694 ∧ code e2419141352694 = 11215234374902 := by decide
theorem cert_e2419141352694 : check e2419141352694 [[],[]] .three = true := by decide
def e2419141352698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2419141352698 : Closed e2419141352698 ∧ code e2419141352698 = 11215234374906 := by decide
theorem cert_e2419141352698 : check e2419141352698 [[],[]] .three = true := by decide
def e2419141353070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419141353070 : Closed e2419141353070 ∧ code e2419141353070 = 11215234375278 := by decide
theorem cert_e2419141353070 : check e2419141353070 [[],[]] .three = true := by decide
def e2419141353078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419141353078 : Closed e2419141353078 ∧ code e2419141353078 = 11215234375286 := by decide
theorem cert_e2419141353078 : check e2419141353078 [[],[]] .three = true := by decide
def e2419141353082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419141353082 : Closed e2419141353082 ∧ code e2419141353082 = 11215234375290 := by decide
theorem cert_e2419141353082 : check e2419141353082 [[],[]] .three = true := by decide
def e2419141353270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419141353270 : Closed e2419141353270 ∧ code e2419141353270 = 11215234375478 := by decide
theorem cert_e2419141353270 : check e2419141353270 [[],[]] .three = true := by decide
def e2419141353274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419141353274 : Closed e2419141353274 ∧ code e2419141353274 = 11215234375482 := by decide
theorem cert_e2419141353274 : check e2419141353274 [[],[]] .three = true := by decide
def e2419142642542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419142642542 : Closed e2419142642542 ∧ code e2419142642542 = 11215235664750 := by decide
theorem cert_e2419142642542 : check e2419142642542 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2419142642550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419142642550 : Closed e2419142642550 ∧ code e2419142642550 = 11215235664758 := by decide
theorem cert_e2419142642550 : check e2419142642550 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419142642606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419142642606 : Closed e2419142642606 ∧ code e2419142642606 = 11215235664814 := by decide
theorem cert_e2419142642606 : check e2419142642606 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2419142642618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419142642618 : Closed e2419142642618 ∧ code e2419142642618 = 11215235664826 := by decide
theorem cert_e2419142642618 : check e2419142642618 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2419142642646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419142642646 : Closed e2419142642646 ∧ code e2419142642646 = 11215235664854 := by decide
theorem cert_e2419142642646 : check e2419142642646 [[],[],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419142642650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419142642650 : Closed e2419142642650 ∧ code e2419142642650 = 11215235664858 := by decide
theorem cert_e2419142642650 : check e2419142642650 [[],[],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2419142642926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419142642926 : Closed e2419142642926 ∧ code e2419142642926 = 11215235665134 := by decide
theorem cert_e2419142642926 : check e2419142642926 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2419142642934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419142642934 : Closed e2419142642934 ∧ code e2419142642934 = 11215235665142 := by decide
theorem cert_e2419142642934 : check e2419142642934 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e2419142643310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419142643310 : Closed e2419142643310 ∧ code e2419142643310 = 11215235665518 := by decide
theorem cert_e2419142643310 : checkPay e2419142643310 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left,.left],[.left],[],[],[.left],[],[],[.left],[],[.under],[.under,.left],[.under,.right]] = true := by decide
def e2419142643322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419142643322 : Closed e2419142643322 ∧ code e2419142643322 = 11215235665530 := by decide
theorem cert_e2419142643322 : checkPay e2419142643322 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.left],[],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.right],[.under,.right,.left,.left],[.under,.right,.left],[.under,.right],[.under,.right],[.under,.right,.left],[.under,.right]] = true := by decide
def e2419142643510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419142643510 : Closed e2419142643510 ∧ code e2419142643510 = 11215235665718 := by decide
theorem cert_e2419142643510 : check e2419142643510 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419142643514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419142643514 : Closed e2419142643514 ∧ code e2419142643514 = 11215235665722 := by decide
theorem cert_e2419142643514 : check e2419142643514 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419143005046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2419143005046 : Closed e2419143005046 ∧ code e2419143005046 = 11215236027254 := by decide
theorem cert_e2419143005046 : check e2419143005046 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143005114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2419143005114 : Closed e2419143005114 ∧ code e2419143005114 = 11215236027322 := by decide
theorem cert_e2419143005114 : check e2419143005114 [[],[],[.under,.under,.left]] .sourceHead = true := by decide
def e2419143005142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2419143005142 : Closed e2419143005142 ∧ code e2419143005142 = 11215236027350 := by decide
def e2419143005146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2419143005146 : Closed e2419143005146 ∧ code e2419143005146 = 11215236027354 := by decide
theorem cert_e2419143005146 : check e2419143005146 [[],[],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2419143132526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2419143132526 : Closed e2419143132526 ∧ code e2419143132526 = 11215236154734 := by decide
theorem cert_e2419143132526 : check e2419143132526 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143132534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2419143132534 : Closed e2419143132534 ∧ code e2419143132534 = 11215236154742 := by decide
theorem cert_e2419143132534 : check e2419143132534 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143132590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2419143132590 : Closed e2419143132590 ∧ code e2419143132590 = 11215236154798 := by decide
theorem cert_e2419143132590 : check e2419143132590 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143132602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2419143132602 : Closed e2419143132602 ∧ code e2419143132602 = 11215236154810 := by decide
theorem cert_e2419143132602 : check e2419143132602 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143132630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2419143132630 : Closed e2419143132630 ∧ code e2419143132630 = 11215236154838 := by decide
theorem cert_e2419143132630 : check e2419143132630 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143132634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2419143132634 : Closed e2419143132634 ∧ code e2419143132634 = 11215236154842 := by decide
theorem cert_e2419143132634 : check e2419143132634 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143135598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2419143135598 : Closed e2419143135598 ∧ code e2419143135598 = 11215236157806 := by decide
theorem cert_e2419143135598 : check e2419143135598 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143135606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2419143135606 : Closed e2419143135606 ∧ code e2419143135606 = 11215236157814 := by decide
theorem cert_e2419143135606 : check e2419143135606 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143136814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2419143136814 : Closed e2419143136814 ∧ code e2419143136814 = 11215236159022 := by decide
theorem cert_e2419143136814 : check e2419143136814 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143136994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2419143136994 : Closed e2419143136994 ∧ code e2419143136994 = 11215236159202 := by decide
theorem cert_e2419143136994 : check e2419143136994 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143137006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2419143137006 : Closed e2419143137006 ∧ code e2419143137006 = 11215236159214 := by decide
theorem cert_e2419143137006 : check e2419143137006 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143137046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2419143137046 : Closed e2419143137046 ∧ code e2419143137046 = 11215236159254 := by decide
theorem cert_e2419143137046 : check e2419143137046 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143137122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2419143137122 : Closed e2419143137122 ∧ code e2419143137122 = 11215236159330 := by decide
theorem cert_e2419143137122 : check e2419143137122 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143137134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2419143137134 : Closed e2419143137134 ∧ code e2419143137134 = 11215236159342 := by decide
theorem cert_e2419143137134 : check e2419143137134 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143137142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2419143137142 : Closed e2419143137142 ∧ code e2419143137142 = 11215236159350 := by decide
theorem cert_e2419143137142 : check e2419143137142 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143137454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2419143137454 : Closed e2419143137454 ∧ code e2419143137454 = 11215236159662 := by decide
theorem cert_e2419143137454 : check e2419143137454 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143137466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2419143137466 : Closed e2419143137466 ∧ code e2419143137466 = 11215236159674 := by decide
theorem cert_e2419143137466 : check e2419143137466 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143137838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2419143137838 : Closed e2419143137838 ∧ code e2419143137838 = 11215236160046 := by decide
theorem cert_e2419143137838 : check e2419143137838 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143138018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2419143138018 : Closed e2419143138018 ∧ code e2419143138018 = 11215236160226 := by decide
theorem cert_e2419143138018 : check e2419143138018 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143138030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2419143138030 : Closed e2419143138030 ∧ code e2419143138030 = 11215236160238 := by decide
theorem cert_e2419143138030 : check e2419143138030 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143138158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2419143138158 : Closed e2419143138158 ∧ code e2419143138158 = 11215236160366 := by decide
theorem cert_e2419143138158 : check e2419143138158 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143138166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2419143138166 : Closed e2419143138166 ∧ code e2419143138166 = 11215236160374 := by decide
theorem cert_e2419143138166 : check e2419143138166 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
end Blc.Floor43
