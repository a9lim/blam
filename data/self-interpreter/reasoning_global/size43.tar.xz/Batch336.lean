import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418338180574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2418338180574 : Closed e2418338180574 ∧ code e2418338180574 = 11214431202782 := by decide
theorem cert_e2418338180574 : check e2418338180574 [[],[]] .chain = true := by decide
def e2418338180590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2418338180590 : Closed e2418338180590 ∧ code e2418338180590 = 11214431202798 := by decide
theorem cert_e2418338180590 : check e2418338180590 [[],[]] .chain = true := by decide
def e2418338180958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2418338180958 : Closed e2418338180958 ∧ code e2418338180958 = 11214431203166 := by decide
theorem cert_e2418338180958 : check e2418338180958 [[],[]] .chain = true := by decide
def e2418338180986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2418338180986 : Closed e2418338180986 ∧ code e2418338180986 = 11214431203194 := by decide
theorem cert_e2418338180986 : check e2418338180986 [[],[]] .chain = true := by decide
def e2418338181038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2418338181038 : Closed e2418338181038 ∧ code e2418338181038 = 11214431203246 := by decide
theorem cert_e2418338181038 : check e2418338181038 [[],[]] .chain = true := by decide
def e2418338181050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2418338181050 : Closed e2418338181050 ∧ code e2418338181050 = 11214431203258 := by decide
theorem cert_e2418338181050 : check e2418338181050 [[],[]] .chain = true := by decide
def e2418338182110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2418338182110 : Closed e2418338182110 ∧ code e2418338182110 = 11214431204318 := by decide
theorem cert_e2418338182110 : check e2418338182110 [[],[]] .chain = true := by decide
def e2418338182126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2418338182126 : Closed e2418338182126 ∧ code e2418338182126 = 11214431204334 := by decide
theorem cert_e2418338182126 : check e2418338182126 [[],[]] .chain = true := by decide
def e2418338184414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418338184414 : Closed e2418338184414 ∧ code e2418338184414 = 11214431206622 := by decide
theorem cert_e2418338184414 : check e2418338184414 [[],[]] .chain = true := by decide
def e2418338184442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418338184442 : Closed e2418338184442 ∧ code e2418338184442 = 11214431206650 := by decide
theorem cert_e2418338184442 : check e2418338184442 [[],[]] .chain = true := by decide
def e2418338184814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418338184814 : Closed e2418338184814 ∧ code e2418338184814 = 11214431207022 := by decide
theorem cert_e2418338184814 : check e2418338184814 [[],[]] .chain = true := by decide
def e2418338184826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418338184826 : Closed e2418338184826 ∧ code e2418338184826 = 11214431207034 := by decide
theorem cert_e2418338184826 : check e2418338184826 [[],[]] .chain = true := by decide
def e2418338213230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2418338213230 : Closed e2418338213230 ∧ code e2418338213230 = 11214431235438 := by decide
theorem cert_e2418338213230 : check e2418338213230 [[],[]] .chain = true := by decide
def e2418338213238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2418338213238 : Closed e2418338213238 ∧ code e2418338213238 = 11214431235446 := by decide
theorem cert_e2418338213238 : check e2418338213238 [[],[]] .chain = true := by decide
def e2418338213294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2418338213294 : Closed e2418338213294 ∧ code e2418338213294 = 11214431235502 := by decide
theorem cert_e2418338213294 : check e2418338213294 [[],[]] .chain = true := by decide
def e2418338213306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2418338213306 : Closed e2418338213306 ∧ code e2418338213306 = 11214431235514 := by decide
theorem cert_e2418338213306 : check e2418338213306 [[],[]] .chain = true := by decide
def e2418338213334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2418338213334 : Closed e2418338213334 ∧ code e2418338213334 = 11214431235542 := by decide
theorem cert_e2418338213334 : check e2418338213334 [[],[]] .chain = true := by decide
def e2418338213338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2418338213338 : Closed e2418338213338 ∧ code e2418338213338 = 11214431235546 := by decide
theorem cert_e2418338213338 : check e2418338213338 [[],[]] .chain = true := by decide
def e2418338213550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2418338213550 : Closed e2418338213550 ∧ code e2418338213550 = 11214431235758 := by decide
theorem cert_e2418338213550 : check e2418338213550 [[],[]] .chain = true := by decide
def e2418338213562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2418338213562 : Closed e2418338213562 ∧ code e2418338213562 = 11214431235770 := by decide
theorem cert_e2418338213562 : check e2418338213562 [[],[]] .chain = true := by decide
def e2418338213610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2418338213610 : Closed e2418338213610 ∧ code e2418338213610 = 11214431235818 := by decide
theorem cert_e2418338213610 : check e2418338213610 [[],[]] .chain = true := by decide
def e2418338213718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2418338213718 : Closed e2418338213718 ∧ code e2418338213718 = 11214431235926 := by decide
theorem cert_e2418338213718 : check e2418338213718 [[],[]] .chain = true := by decide
def e2418338213722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2418338213722 : Closed e2418338213722 ∧ code e2418338213722 = 11214431235930 := by decide
theorem cert_e2418338213722 : check e2418338213722 [[],[]] .chain = true := by decide
def e2418338213738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2418338213738 : Closed e2418338213738 ∧ code e2418338213738 = 11214431235946 := by decide
theorem cert_e2418338213738 : check e2418338213738 [[],[]] .chain = true := by decide
def e2418338214766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2418338214766 : Closed e2418338214766 ∧ code e2418338214766 = 11214431236974 := by decide
theorem cert_e2418338214766 : check e2418338214766 [[],[]] .chain = true := by decide
def e2418338214774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2418338214774 : Closed e2418338214774 ∧ code e2418338214774 = 11214431236982 := by decide
theorem cert_e2418338214774 : check e2418338214774 [[],[]] .chain = true := by decide
def e2418338214830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2418338214830 : Closed e2418338214830 ∧ code e2418338214830 = 11214431237038 := by decide
theorem cert_e2418338214830 : check e2418338214830 [[],[]] .chain = true := by decide
def e2418338214842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2418338214842 : Closed e2418338214842 ∧ code e2418338214842 = 11214431237050 := by decide
theorem cert_e2418338214842 : check e2418338214842 [[],[]] .chain = true := by decide
def e2418338214870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2418338214870 : Closed e2418338214870 ∧ code e2418338214870 = 11214431237078 := by decide
theorem cert_e2418338214870 : check e2418338214870 [[],[]] .chain = true := by decide
def e2418338214874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2418338214874 : Closed e2418338214874 ∧ code e2418338214874 = 11214431237082 := by decide
theorem cert_e2418338214874 : check e2418338214874 [[],[]] .chain = true := by decide
def e2418338215150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2418338215150 : Closed e2418338215150 ∧ code e2418338215150 = 11214431237358 := by decide
theorem cert_e2418338215150 : check e2418338215150 [[],[]] .chain = true := by decide
def e2418338215158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2418338215158 : Closed e2418338215158 ∧ code e2418338215158 = 11214431237366 := by decide
theorem cert_e2418338215158 : check e2418338215158 [[],[]] .chain = true := by decide
def e2418338215534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418338215534 : Closed e2418338215534 ∧ code e2418338215534 = 11214431237742 := by decide
theorem cert_e2418338215534 : check e2418338215534 [[],[]] .chain = true := by decide
def e2418338215546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418338215546 : Closed e2418338215546 ∧ code e2418338215546 = 11214431237754 := by decide
theorem cert_e2418338215546 : check e2418338215546 [[],[]] .chain = true := by decide
def e2418338215734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418338215734 : Closed e2418338215734 ∧ code e2418338215734 = 11214431237942 := by decide
theorem cert_e2418338215734 : check e2418338215734 [[],[]] .chain = true := by decide
def e2418338215738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418338215738 : Closed e2418338215738 ∧ code e2418338215738 = 11214431237946 := by decide
theorem cert_e2418338215738 : check e2418338215738 [[],[]] .chain = true := by decide
def e2418338216366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2418338216366 : Closed e2418338216366 ∧ code e2418338216366 = 11214431238574 := by decide
theorem cert_e2418338216366 : check e2418338216366 [[],[]] .chain = true := by decide
def e2418338216378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2418338216378 : Closed e2418338216378 ∧ code e2418338216378 = 11214431238586 := by decide
theorem cert_e2418338216378 : check e2418338216378 [[],[]] .chain = true := by decide
def e2418338216426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2418338216426 : Closed e2418338216426 ∧ code e2418338216426 = 11214431238634 := by decide
theorem cert_e2418338216426 : check e2418338216426 [[],[]] .chain = true := by decide
def e2418338216558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418338216558 : Closed e2418338216558 ∧ code e2418338216558 = 11214431238766 := by decide
theorem cert_e2418338216558 : check e2418338216558 [[],[]] .chain = true := by decide
def e2418338216570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418338216570 : Closed e2418338216570 ∧ code e2418338216570 = 11214431238778 := by decide
theorem cert_e2418338216570 : check e2418338216570 [[],[]] .chain = true := by decide
def e2418338216858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418338216858 : Closed e2418338216858 ∧ code e2418338216858 = 11214431239066 := by decide
theorem cert_e2418338216858 : check e2418338216858 [[],[]] .chain = true := by decide
def e2418338217174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2418338217174 : Closed e2418338217174 ∧ code e2418338217174 = 11214431239382 := by decide
theorem cert_e2418338217174 : check e2418338217174 [[],[]] .chain = true := by decide
def e2418338217178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2418338217178 : Closed e2418338217178 ∧ code e2418338217178 = 11214431239386 := by decide
theorem cert_e2418338217178 : check e2418338217178 [[],[]] .chain = true := by decide
def e2418338217194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2418338217194 : Closed e2418338217194 ∧ code e2418338217194 = 11214431239402 := by decide
theorem cert_e2418338217194 : check e2418338217194 [[],[]] .chain = true := by decide
def e2418338217270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418338217270 : Closed e2418338217270 ∧ code e2418338217270 = 11214431239478 := by decide
theorem cert_e2418338217270 : check e2418338217270 [[],[]] .chain = true := by decide
def e2418338217274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418338217274 : Closed e2418338217274 ∧ code e2418338217274 = 11214431239482 := by decide
theorem cert_e2418338217274 : check e2418338217274 [[],[]] .chain = true := by decide
def e2418338217370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418338217370 : Closed e2418338217370 ∧ code e2418338217370 = 11214431239578 := by decide
theorem cert_e2418338217370 : check e2418338217370 [[],[]] .chain = true := by decide
def e2418338218974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2418338218974 : Closed e2418338218974 ∧ code e2418338218974 = 11214431241182 := by decide
theorem cert_e2418338218974 : check e2418338218974 [[],[]] .chain = true := by decide
def e2418338218990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2418338218990 : Closed e2418338218990 ∧ code e2418338218990 = 11214431241198 := by decide
theorem cert_e2418338218990 : check e2418338218990 [[],[]] .chain = true := by decide
def e2418338220910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418338220910 : Closed e2418338220910 ∧ code e2418338220910 = 11214431243118 := by decide
theorem cert_e2418338220910 : check e2418338220910 [[],[]] .chain = true := by decide
def e2418338220918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418338220918 : Closed e2418338220918 ∧ code e2418338220918 = 11214431243126 := by decide
theorem cert_e2418338220918 : check e2418338220918 [[],[]] .chain = true := by decide
def e2418338220974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418338220974 : Closed e2418338220974 ∧ code e2418338220974 = 11214431243182 := by decide
theorem cert_e2418338220974 : check e2418338220974 [[],[]] .chain = true := by decide
def e2418338220986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418338220986 : Closed e2418338220986 ∧ code e2418338220986 = 11214431243194 := by decide
theorem cert_e2418338220986 : check e2418338220986 [[],[]] .chain = true := by decide
def e2418338221014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418338221014 : Closed e2418338221014 ∧ code e2418338221014 = 11214431243222 := by decide
theorem cert_e2418338221014 : check e2418338221014 [[],[]] .chain = true := by decide
def e2418338221018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418338221018 : Closed e2418338221018 ∧ code e2418338221018 = 11214431243226 := by decide
theorem cert_e2418338221018 : check e2418338221018 [[],[]] .chain = true := by decide
def e2418338221294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418338221294 : Closed e2418338221294 ∧ code e2418338221294 = 11214431243502 := by decide
theorem cert_e2418338221294 : check e2418338221294 [[],[]] .chain = true := by decide
def e2418338221302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418338221302 : Closed e2418338221302 ∧ code e2418338221302 = 11214431243510 := by decide
theorem cert_e2418338221302 : check e2418338221302 [[],[]] .chain = true := by decide
def e2418338221678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418338221678 : Closed e2418338221678 ∧ code e2418338221678 = 11214431243886 := by decide
theorem cert_e2418338221678 : check e2418338221678 [[],[]] .chain = true := by decide
def e2418338221690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418338221690 : Closed e2418338221690 ∧ code e2418338221690 = 11214431243898 := by decide
theorem cert_e2418338221690 : check e2418338221690 [[],[]] .chain = true := by decide
def e2418338221878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418338221878 : Closed e2418338221878 ∧ code e2418338221878 = 11214431244086 := by decide
theorem cert_e2418338221878 : check e2418338221878 [[],[]] .chain = true := by decide
def e2418338221882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418338221882 : Closed e2418338221882 ∧ code e2418338221882 = 11214431244090 := by decide
theorem cert_e2418338221882 : check e2418338221882 [[],[]] .chain = true := by decide
def e2418338226654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2418338226654 : Closed e2418338226654 ∧ code e2418338226654 = 11214431248862 := by decide
theorem cert_e2418338226654 : check e2418338226654 [[],[]] .chain = true := by decide
def e2418338226678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2418338226678 : Closed e2418338226678 ∧ code e2418338226678 = 11214431248886 := by decide
theorem cert_e2418338226678 : check e2418338226678 [[],[]] .chain = true := by decide
def e2418338227630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2418338227630 : Closed e2418338227630 ∧ code e2418338227630 = 11214431249838 := by decide
theorem cert_e2418338227630 : check e2418338227630 [[],[]] .chain = true := by decide
def e2418338227642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2418338227642 : Closed e2418338227642 ∧ code e2418338227642 = 11214431249850 := by decide
theorem cert_e2418338227642 : check e2418338227642 [[],[]] .chain = true := by decide
def e2418338227690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2418338227690 : Closed e2418338227690 ∧ code e2418338227690 = 11214431249898 := by decide
theorem cert_e2418338227690 : check e2418338227690 [[],[]] .chain = true := by decide
def e2418338227822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418338227822 : Closed e2418338227822 ∧ code e2418338227822 = 11214431250030 := by decide
theorem cert_e2418338227822 : check e2418338227822 [[],[]] .chain = true := by decide
def e2418338227834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418338227834 : Closed e2418338227834 ∧ code e2418338227834 = 11214431250042 := by decide
theorem cert_e2418338227834 : check e2418338227834 [[],[]] .chain = true := by decide
def e2418338228122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418338228122 : Closed e2418338228122 ∧ code e2418338228122 = 11214431250330 := by decide
theorem cert_e2418338228122 : check e2418338228122 [[],[]] .chain = true := by decide
def e2418338230510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2418338230510 : Closed e2418338230510 ∧ code e2418338230510 = 11214431252718 := by decide
theorem cert_e2418338230510 : check e2418338230510 [[],[]] .chain = true := by decide
def e2418338230518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2418338230518 : Closed e2418338230518 ∧ code e2418338230518 = 11214431252726 := by decide
theorem cert_e2418338230518 : check e2418338230518 [[],[]] .chain = true := by decide
def e2418338230998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2418338230998 : Closed e2418338230998 ∧ code e2418338230998 = 11214431253206 := by decide
theorem cert_e2418338230998 : check e2418338230998 [[],[]] .chain = true := by decide
def e2418338231002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2418338231002 : Closed e2418338231002 ∧ code e2418338231002 = 11214431253210 := by decide
theorem cert_e2418338231002 : check e2418338231002 [[],[]] .chain = true := by decide
def e2418338231018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2418338231018 : Closed e2418338231018 ∧ code e2418338231018 = 11214431253226 := by decide
theorem cert_e2418338231018 : check e2418338231018 [[],[]] .chain = true := by decide
def e2418338231094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418338231094 : Closed e2418338231094 ∧ code e2418338231094 = 11214431253302 := by decide
theorem cert_e2418338231094 : check e2418338231094 [[],[]] .chain = true := by decide
def e2418338231098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418338231098 : Closed e2418338231098 ∧ code e2418338231098 = 11214431253306 := by decide
theorem cert_e2418338231098 : check e2418338231098 [[],[]] .chain = true := by decide
def e2418338231194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418338231194 : Closed e2418338231194 ∧ code e2418338231194 = 11214431253402 := by decide
theorem cert_e2418338231194 : check e2418338231194 [[],[]] .chain = true := by decide
def e2418338368366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418338368366 : Closed e2418338368366 ∧ code e2418338368366 = 11214431390574 := by decide
theorem cert_e2418338368366 : check e2418338368366 [[],[]] .chain = true := by decide
def e2418338368374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418338368374 : Closed e2418338368374 ∧ code e2418338368374 = 11214431390582 := by decide
theorem cert_e2418338368374 : check e2418338368374 [[],[]] .chain = true := by decide
def e2418338368430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418338368430 : Closed e2418338368430 ∧ code e2418338368430 = 11214431390638 := by decide
theorem cert_e2418338368430 : check e2418338368430 [[],[]] .chain = true := by decide
def e2418338368442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418338368442 : Closed e2418338368442 ∧ code e2418338368442 = 11214431390650 := by decide
theorem cert_e2418338368442 : check e2418338368442 [[],[]] .chain = true := by decide
def e2418338368470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418338368470 : Closed e2418338368470 ∧ code e2418338368470 = 11214431390678 := by decide
theorem cert_e2418338368470 : check e2418338368470 [[],[]] .chain = true := by decide
def e2418338368474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418338368474 : Closed e2418338368474 ∧ code e2418338368474 = 11214431390682 := by decide
theorem cert_e2418338368474 : check e2418338368474 [[],[]] .chain = true := by decide
def e2418338368750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418338368750 : Closed e2418338368750 ∧ code e2418338368750 = 11214431390958 := by decide
theorem cert_e2418338368750 : check e2418338368750 [[],[]] .chain = true := by decide
def e2418338368758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418338368758 : Closed e2418338368758 ∧ code e2418338368758 = 11214431390966 := by decide
theorem cert_e2418338368758 : check e2418338368758 [[],[]] .chain = true := by decide
def e2418338369134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418338369134 : Closed e2418338369134 ∧ code e2418338369134 = 11214431391342 := by decide
theorem cert_e2418338369134 : check e2418338369134 [[],[]] .chain = true := by decide
def e2418338369146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418338369146 : Closed e2418338369146 ∧ code e2418338369146 = 11214431391354 := by decide
theorem cert_e2418338369146 : check e2418338369146 [[],[]] .chain = true := by decide
def e2418338369334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418338369334 : Closed e2418338369334 ∧ code e2418338369334 = 11214431391542 := by decide
theorem cert_e2418338369334 : check e2418338369334 [[],[]] .chain = true := by decide
def e2418338369338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418338369338 : Closed e2418338369338 ∧ code e2418338369338 = 11214431391546 := by decide
theorem cert_e2418338369338 : check e2418338369338 [[],[]] .chain = true := by decide
def e2418338698974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2418338698974 : Closed e2418338698974 ∧ code e2418338698974 = 11214431721182 := by decide
theorem cert_e2418338698974 : check e2418338698974 [[],[],[.under,.left]] .chain = true := by decide
def e2418338698998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2418338698998 : Closed e2418338698998 ∧ code e2418338698998 = 11214431721206 := by decide
theorem cert_e2418338698998 : check e2418338698998 [[],[],[.under,.left]] .chain = true := by decide
def e2418338699102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2418338699102 : Closed e2418338699102 ∧ code e2418338699102 = 11214431721310 := by decide
theorem cert_e2418338699102 : check e2418338699102 [[],[],[.under,.left]] .chain = true := by decide
def e2418338699130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2418338699130 : Closed e2418338699130 ∧ code e2418338699130 = 11214431721338 := by decide
theorem cert_e2418338699130 : check e2418338699130 [[],[],[.under,.left]] .chain = true := by decide
def e2418338699222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2418338699222 : Closed e2418338699222 ∧ code e2418338699222 = 11214431721430 := by decide
theorem cert_e2418338699222 : check e2418338699222 [[],[],[.under,.left]] .chain = true := by decide
def e2418338699226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2418338699226 : Closed e2418338699226 ∧ code e2418338699226 = 11214431721434 := by decide
theorem cert_e2418338699226 : check e2418338699226 [[],[],[.under,.left]] .chain = true := by decide
def e2418338699742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2418338699742 : Closed e2418338699742 ∧ code e2418338699742 = 11214431721950 := by decide
theorem cert_e2418338699742 : check e2418338699742 [[],[],[.under,.left]] .chain = true := by decide
def e2418338699766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2418338699766 : Closed e2418338699766 ∧ code e2418338699766 = 11214431721974 := by decide
theorem cert_e2418338699766 : check e2418338699766 [[],[],[.under,.left]] .chain = true := by decide
def e2418338700510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418338700510 : Closed e2418338700510 ∧ code e2418338700510 = 11214431722718 := by decide
theorem cert_e2418338700510 : check e2418338700510 [[],[],[.under,.left]] .chain = true := by decide
def e2418338700538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418338700538 : Closed e2418338700538 ∧ code e2418338700538 = 11214431722746 := by decide
theorem cert_e2418338700538 : check e2418338700538 [[],[],[.under,.left]] .chain = true := by decide
def e2418338701110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418338701110 : Closed e2418338701110 ∧ code e2418338701110 = 11214431723318 := by decide
theorem cert_e2418338701110 : check e2418338701110 [[],[],[.under,.left]] .chain = true := by decide
def e2418338701114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418338701114 : Closed e2418338701114 ∧ code e2418338701114 = 11214431723322 := by decide
theorem cert_e2418338701114 : check e2418338701114 [[],[],[.under,.left]] .chain = true := by decide
def e2418338715886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2418338715886 : Closed e2418338715886 ∧ code e2418338715886 = 11214431738094 := by decide
theorem cert_e2418338715886 : check e2418338715886 [[],[],[.under,.left]] .chain = true := by decide
def e2418338715894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2418338715894 : Closed e2418338715894 ∧ code e2418338715894 = 11214431738102 := by decide
theorem cert_e2418338715894 : check e2418338715894 [[],[],[.under,.left]] .chain = true := by decide
def e2418338716446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2418338716446 : Closed e2418338716446 ∧ code e2418338716446 = 11214431738654 := by decide
theorem cert_e2418338716446 : check e2418338716446 [[],[],[.under,.left]] .chain = true := by decide
def e2418338716558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2418338716558 : Closed e2418338716558 ∧ code e2418338716558 = 11214431738766 := by decide
theorem cert_e2418338716558 : check e2418338716558 [[],[],[.under,.left]] .chain = true := by decide
def e2418338716782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2418338716782 : Closed e2418338716782 ∧ code e2418338716782 = 11214431738990 := by decide
theorem cert_e2418338716782 : check e2418338716782 [[],[],[.under,.left]] .chain = true := by decide
def e2418338716794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2418338716794 : Closed e2418338716794 ∧ code e2418338716794 = 11214431739002 := by decide
theorem cert_e2418338716794 : check e2418338716794 [[],[],[.under,.left]] .chain = true := by decide
def e2418338716958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2418338716958 : Closed e2418338716958 ∧ code e2418338716958 = 11214431739166 := by decide
theorem cert_e2418338716958 : check e2418338716958 [[],[],[.under,.left]] .chain = true := by decide
def e2418338717126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2418338717126 : Closed e2418338717126 ∧ code e2418338717126 = 11214431739334 := by decide
theorem cert_e2418338717126 : check e2418338717126 [[],[],[.under,.left]] .chain = true := by decide
def e2418338717238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2418338717238 : Closed e2418338717238 ∧ code e2418338717238 = 11214431739446 := by decide
theorem cert_e2418338717238 : check e2418338717238 [[],[],[.under,.left]] .chain = true := by decide
def e2418338717242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2418338717242 : Closed e2418338717242 ∧ code e2418338717242 = 11214431739450 := by decide
theorem cert_e2418338717242 : check e2418338717242 [[],[],[.under,.left]] .chain = true := by decide
def e2418338717326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2418338717326 : Closed e2418338717326 ∧ code e2418338717326 = 11214431739534 := by decide
theorem cert_e2418338717326 : check e2418338717326 [[],[],[.under,.left]] .chain = true := by decide
def e2418338717382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2418338717382 : Closed e2418338717382 ∧ code e2418338717382 = 11214431739590 := by decide
theorem cert_e2418338717382 : check e2418338717382 [[],[],[.under,.left]] .chain = true := by decide
def e2418338719518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2418338719518 : Closed e2418338719518 ∧ code e2418338719518 = 11214431741726 := by decide
theorem cert_e2418338719518 : check e2418338719518 [[],[],[.under,.left]] .chain = true := by decide
def e2418338719630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2418338719630 : Closed e2418338719630 ∧ code e2418338719630 = 11214431741838 := by decide
theorem cert_e2418338719630 : check e2418338719630 [[],[],[.under,.left]] .chain = true := by decide
def e2418338722590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2418338722590 : Closed e2418338722590 ∧ code e2418338722590 = 11214431744798 := by decide
theorem cert_e2418338722590 : check e2418338722590 [[],[],[.under,.left]] .chain = true := by decide
def e2418338722758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2418338722758 : Closed e2418338722758 ∧ code e2418338722758 = 11214431744966 := by decide
theorem cert_e2418338722758 : check e2418338722758 [[],[],[.under,.left]] .chain = true := by decide
def e2418338724238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2418338724238 : Closed e2418338724238 ∧ code e2418338724238 = 11214431746446 := by decide
theorem cert_e2418338724238 : check e2418338724238 [[],[],[.under,.left]] .chain = true := by decide
def e2418338724294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2418338724294 : Closed e2418338724294 ∧ code e2418338724294 = 11214431746502 := by decide
theorem cert_e2418338724294 : check e2418338724294 [[],[],[.under,.left]] .chain = true := by decide
def e2418346569146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e2418346569146 : Closed e2418346569146 ∧ code e2418346569146 = 11214439591354 := by decide
theorem cert_e2418346569146 : check e2418346569146 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left]] .chain = true := by decide
def e2418346569178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e2418346569178 : Closed e2418346569178 ∧ code e2418346569178 = 11214439591386 := by decide
theorem cert_e2418346569178 : check e2418346569178 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left]] .chain = true := by decide
def e2418346569402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e2418346569402 : Closed e2418346569402 ∧ code e2418346569402 = 11214439591610 := by decide
theorem cert_e2418346569402 : check e2418346569402 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left]] .chain = true := by decide
def e2418346569450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e2418346569450 : Closed e2418346569450 ∧ code e2418346569450 = 11214439591658 := by decide
theorem cert_e2418346569450 : check e2418346569450 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418346569562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e2418346569562 : Closed e2418346569562 ∧ code e2418346569562 = 11214439591770 := by decide
theorem cert_e2418346569562 : check e2418346569562 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2418346569578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e2418346569578 : Closed e2418346569578 ∧ code e2418346569578 = 11214439591786 := by decide
theorem cert_e2418346569578 : check e2418346569578 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418346570682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e2418346570682 : Closed e2418346570682 ∧ code e2418346570682 = 11214439592890 := by decide
theorem cert_e2418346570682 : check e2418346570682 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e2418346570714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e2418346570714 : Closed e2418346570714 ∧ code e2418346570714 = 11214439592922 := by decide
theorem cert_e2418346570714 : check e2418346570714 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e2418346572218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e2418346572218 : Closed e2418346572218 ∧ code e2418346572218 = 11214439594426 := by decide
theorem cert_e2418346572218 : check e2418346572218 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left]] .chain = true := by decide
def e2418346572266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e2418346572266 : Closed e2418346572266 ∧ code e2418346572266 = 11214439594474 := by decide
theorem cert_e2418346572266 : check e2418346572266 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2418346573018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e2418346573018 : Closed e2418346573018 ∧ code e2418346573018 = 11214439595226 := by decide
theorem cert_e2418346573018 : check e2418346573018 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e2418346573034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e2418346573034 : Closed e2418346573034 ∧ code e2418346573034 = 11214439595242 := by decide
theorem cert_e2418346573034 : check e2418346573034 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2418346822510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418346822510 : Closed e2418346822510 ∧ code e2418346822510 = 11214439844718 := by decide
theorem cert_e2418346822510 : check e2418346822510 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left]] .chain = true := by decide
def e2418346822518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418346822518 : Closed e2418346822518 ∧ code e2418346822518 = 11214439844726 := by decide
theorem cert_e2418346822518 : check e2418346822518 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left,.left]] .chain = true := by decide
def e2418346822574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418346822574 : Closed e2418346822574 ∧ code e2418346822574 = 11214439844782 := by decide
theorem cert_e2418346822574 : check e2418346822574 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2418346822586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418346822586 : Closed e2418346822586 ∧ code e2418346822586 = 11214439844794 := by decide
theorem cert_e2418346822586 : check e2418346822586 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2418346822614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418346822614 : Closed e2418346822614 ∧ code e2418346822614 = 11214439844822 := by decide
theorem cert_e2418346822614 : check e2418346822614 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418346822618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418346822618 : Closed e2418346822618 ∧ code e2418346822618 = 11214439844826 := by decide
theorem cert_e2418346822618 : check e2418346822618 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left]] .chain = true := by decide
def e2418346822894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418346822894 : Closed e2418346822894 ∧ code e2418346822894 = 11214439845102 := by decide
theorem cert_e2418346822894 : check e2418346822894 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2418346822902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418346822902 : Closed e2418346822902 ∧ code e2418346822902 = 11214439845110 := by decide
theorem cert_e2418346822902 : check e2418346822902 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2418346823278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418346823278 : Closed e2418346823278 ∧ code e2418346823278 = 11214439845486 := by decide
theorem cert_e2418346823278 : check e2418346823278 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2418346823290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418346823290 : Closed e2418346823290 ∧ code e2418346823290 = 11214439845498 := by decide
theorem cert_e2418346823290 : check e2418346823290 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2418346823478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418346823478 : Closed e2418346823478 ∧ code e2418346823478 = 11214439845686 := by decide
theorem cert_e2418346823478 : check e2418346823478 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[],[.under,.left]] .chain = true := by decide
def e2418346823482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418346823482 : Closed e2418346823482 ∧ code e2418346823482 = 11214439845690 := by decide
theorem cert_e2418346823482 : check e2418346823482 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left]] .chain = true := by decide
def e2418347617758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2418347617758 : Closed e2418347617758 ∧ code e2418347617758 = 11214440639966 := by decide
theorem cert_e2418347617758 : check e2418347617758 [[],[],[.left]] .chain = true := by decide
def e2418347617774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2418347617774 : Closed e2418347617774 ∧ code e2418347617774 = 11214440639982 := by decide
theorem cert_e2418347617774 : check e2418347617774 [[],[],[.left]] .chain = true := by decide
def e2418347618142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2418347618142 : Closed e2418347618142 ∧ code e2418347618142 = 11214440640350 := by decide
theorem cert_e2418347618142 : check e2418347618142 [[],[],[.left]] .chain = true := by decide
def e2418347618170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2418347618170 : Closed e2418347618170 ∧ code e2418347618170 = 11214440640378 := by decide
theorem cert_e2418347618170 : check e2418347618170 [[],[],[.left]] .chain = true := by decide
def e2418347618222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2418347618222 : Closed e2418347618222 ∧ code e2418347618222 = 11214440640430 := by decide
theorem cert_e2418347618222 : check e2418347618222 [[],[],[.left]] .chain = true := by decide
def e2418347618234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2418347618234 : Closed e2418347618234 ∧ code e2418347618234 = 11214440640442 := by decide
theorem cert_e2418347618234 : check e2418347618234 [[],[],[.left]] .chain = true := by decide
def e2418347619294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2418347619294 : Closed e2418347619294 ∧ code e2418347619294 = 11214440641502 := by decide
theorem cert_e2418347619294 : check e2418347619294 [[],[],[.left]] .chain = true := by decide
def e2418347619310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2418347619310 : Closed e2418347619310 ∧ code e2418347619310 = 11214440641518 := by decide
theorem cert_e2418347619310 : check e2418347619310 [[],[],[.left]] .chain = true := by decide
def e2418347621598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418347621598 : Closed e2418347621598 ∧ code e2418347621598 = 11214440643806 := by decide
theorem cert_e2418347621598 : check e2418347621598 [[],[],[.left]] .chain = true := by decide
def e2418347621626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418347621626 : Closed e2418347621626 ∧ code e2418347621626 = 11214440643834 := by decide
theorem cert_e2418347621626 : check e2418347621626 [[],[],[.left]] .chain = true := by decide
def e2418347621998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418347621998 : Closed e2418347621998 ∧ code e2418347621998 = 11214440644206 := by decide
theorem cert_e2418347621998 : check e2418347621998 [[],[],[.left]] .chain = true := by decide
def e2418347622010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418347622010 : Closed e2418347622010 ∧ code e2418347622010 = 11214440644218 := by decide
theorem cert_e2418347622010 : check e2418347622010 [[],[],[.left]] .chain = true := by decide
def e2418347650414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2418347650414 : Closed e2418347650414 ∧ code e2418347650414 = 11214440672622 := by decide
theorem cert_e2418347650414 : check e2418347650414 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2418347650422 : Closed e2418347650422 ∧ code e2418347650422 = 11214440672630 := by decide
theorem cert_e2418347650422 : check e2418347650422 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2418347650478 : Closed e2418347650478 ∧ code e2418347650478 = 11214440672686 := by decide
theorem cert_e2418347650478 : check e2418347650478 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2418347650490 : Closed e2418347650490 ∧ code e2418347650490 = 11214440672698 := by decide
theorem cert_e2418347650490 : check e2418347650490 [[],[],[.left],[.left],[]] .chain = true := by decide
end Blc.Floor43
