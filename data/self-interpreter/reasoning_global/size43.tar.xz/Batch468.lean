import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406880810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422406880810 : Closed e2422406880810 ∧ code e2422406880810 = 11218499903018 := by decide
theorem cert_e2422406880810 : check e2422406880810 [[],[]] .chain = true := by decide
def e2422406880906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406880906 : Closed e2422406880906 ∧ code e2422406880906 = 11218499903114 := by decide
theorem cert_e2422406880906 : check e2422406880906 [[],[]] .chain = true := by decide
def e2422406880930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406880930 : Closed e2422406880930 ∧ code e2422406880930 = 11218499903138 := by decide
theorem cert_e2422406880930 : check e2422406880930 [[],[]] .chain = true := by decide
def e2422406880942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406880942 : Closed e2422406880942 ∧ code e2422406880942 = 11218499903150 := by decide
theorem cert_e2422406880942 : check e2422406880942 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406880950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e2422406880950 : Closed e2422406880950 ∧ code e2422406880950 = 11218499903158 := by decide
theorem cert_e2422406880950 : check e2422406880950 [[],[]] .chain = true := by decide
def e2422406880954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406880954 : Closed e2422406880954 ∧ code e2422406880954 = 11218499903162 := by decide
theorem cert_e2422406880954 : check e2422406880954 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406880982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2422406880982 : Closed e2422406880982 ∧ code e2422406880982 = 11218499903190 := by decide
theorem cert_e2422406880982 : check e2422406880982 [[],[]] .chain = true := by decide
def e2422406880986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2422406880986 : Closed e2422406880986 ∧ code e2422406880986 = 11218499903194 := by decide
theorem cert_e2422406880986 : check e2422406880986 [[],[]] .chain = true := by decide
def e2422406881002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422406881002 : Closed e2422406881002 ∧ code e2422406881002 = 11218499903210 := by decide
theorem cert_e2422406881002 : check e2422406881002 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406881326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422406881326 : Closed e2422406881326 ∧ code e2422406881326 = 11218499903534 := by decide
theorem cert_e2422406881326 : check e2422406881326 [[],[]] .chain = true := by decide
def e2422406881518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422406881518 : Closed e2422406881518 ∧ code e2422406881518 = 11218499903726 := by decide
theorem cert_e2422406881518 : check e2422406881518 [[],[]] .chain = true := by decide
def e2422406881530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2422406881530 : Closed e2422406881530 ∧ code e2422406881530 = 11218499903738 := by decide
theorem cert_e2422406881530 : check e2422406881530 [[],[]] .chain = true := by decide
def e2422406881710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422406881710 : Closed e2422406881710 ∧ code e2422406881710 = 11218499903918 := by decide
theorem cert_e2422406881710 : check e2422406881710 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406881902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406881902 : Closed e2422406881902 ∧ code e2422406881902 = 11218499904110 := by decide
theorem cert_e2422406881902 : check e2422406881902 [[],[]] .chain = true := by decide
def e2422406881914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406881914 : Closed e2422406881914 ∧ code e2422406881914 = 11218499904122 := by decide
theorem cert_e2422406881914 : check e2422406881914 [[],[]] .chain = true := by decide
def e2422406882078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422406882078 : Closed e2422406882078 ∧ code e2422406882078 = 11218499904286 := by decide
theorem cert_e2422406882078 : check e2422406882078 [[],[]] .chain = true := by decide
def e2422406882246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2422406882246 : Closed e2422406882246 ∧ code e2422406882246 = 11218499904454 := by decide
theorem cert_e2422406882246 : check e2422406882246 [[],[]] .chain = true := by decide
def e2422406882862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406882862 : Closed e2422406882862 ∧ code e2422406882862 = 11218499905070 := by decide
theorem cert_e2422406882862 : check e2422406882862 [[],[]] .chain = true := by decide
def e2422406883042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406883042 : Closed e2422406883042 ∧ code e2422406883042 = 11218499905250 := by decide
theorem cert_e2422406883042 : check e2422406883042 [[],[]] .chain = true := by decide
def e2422406883054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2422406883054 : Closed e2422406883054 ∧ code e2422406883054 = 11218499905262 := by decide
theorem cert_e2422406883054 : check e2422406883054 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406883182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2422406883182 : Closed e2422406883182 ∧ code e2422406883182 = 11218499905390 := by decide
theorem cert_e2422406883182 : check e2422406883182 [[],[]] .chain = true := by decide
def e2422406883190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2422406883190 : Closed e2422406883190 ∧ code e2422406883190 = 11218499905398 := by decide
theorem cert_e2422406883190 : check e2422406883190 [[],[]] .chain = true := by decide
def e2422406883210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406883210 : Closed e2422406883210 ∧ code e2422406883210 = 11218499905418 := by decide
theorem cert_e2422406883210 : check e2422406883210 [[],[]] .chain = true := by decide
def e2422406883234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406883234 : Closed e2422406883234 ∧ code e2422406883234 = 11218499905442 := by decide
theorem cert_e2422406883234 : check e2422406883234 [[],[]] .chain = true := by decide
def e2422406883246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2422406883246 : Closed e2422406883246 ∧ code e2422406883246 = 11218499905454 := by decide
theorem cert_e2422406883246 : check e2422406883246 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406883254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2422406883254 : Closed e2422406883254 ∧ code e2422406883254 = 11218499905462 := by decide
theorem cert_e2422406883254 : check e2422406883254 [[],[]] .chain = true := by decide
def e2422406883258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2422406883258 : Closed e2422406883258 ∧ code e2422406883258 = 11218499905466 := by decide
theorem cert_e2422406883258 : check e2422406883258 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406883390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2422406883390 : Closed e2422406883390 ∧ code e2422406883390 = 11218499905598 := by decide
theorem cert_e2422406883390 : check e2422406883390 [[],[]] .chain = true := by decide
def e2422406883810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406883810 : Closed e2422406883810 ∧ code e2422406883810 = 11218499906018 := by decide
theorem cert_e2422406883810 : check e2422406883810 [[],[]] .chain = true := by decide
def e2422406883822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406883822 : Closed e2422406883822 ∧ code e2422406883822 = 11218499906030 := by decide
theorem cert_e2422406883822 : check e2422406883822 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406884590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406884590 : Closed e2422406884590 ∧ code e2422406884590 = 11218499906798 := by decide
theorem cert_e2422406884590 : check e2422406884590 [[],[]] .chain = true := by decide
def e2422406884598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406884598 : Closed e2422406884598 ∧ code e2422406884598 = 11218499906806 := by decide
theorem cert_e2422406884598 : check e2422406884598 [[],[]] .chain = true := by decide
def e2422406884866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406884866 : Closed e2422406884866 ∧ code e2422406884866 = 11218499907074 := by decide
theorem cert_e2422406884866 : check e2422406884866 [[],[]] .chain = true := by decide
def e2422406884878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406884878 : Closed e2422406884878 ∧ code e2422406884878 = 11218499907086 := by decide
theorem cert_e2422406884878 : check e2422406884878 [[],[]] .chain = true := by decide
def e2422406884890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406884890 : Closed e2422406884890 ∧ code e2422406884890 = 11218499907098 := by decide
theorem cert_e2422406884890 : check e2422406884890 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406884962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406884962 : Closed e2422406884962 ∧ code e2422406884962 = 11218499907170 := by decide
theorem cert_e2422406884962 : check e2422406884962 [[],[]] .chain = true := by decide
def e2422406884974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406884974 : Closed e2422406884974 ∧ code e2422406884974 = 11218499907182 := by decide
theorem cert_e2422406884974 : check e2422406884974 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406884982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406884982 : Closed e2422406884982 ∧ code e2422406884982 = 11218499907190 := by decide
theorem cert_e2422406884982 : check e2422406884982 [[],[]] .chain = true := by decide
def e2422406884986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406884986 : Closed e2422406884986 ∧ code e2422406884986 = 11218499907194 := by decide
theorem cert_e2422406884986 : check e2422406884986 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406885486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422406885486 : Closed e2422406885486 ∧ code e2422406885486 = 11218499907694 := by decide
theorem cert_e2422406885486 : check e2422406885486 [[],[]] .chain = true := by decide
def e2422406885662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422406885662 : Closed e2422406885662 ∧ code e2422406885662 = 11218499907870 := by decide
theorem cert_e2422406885662 : check e2422406885662 [[],[]] .chain = true := by decide
def e2422406885858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e2422406885858 : Closed e2422406885858 ∧ code e2422406885858 = 11218499908066 := by decide
theorem cert_e2422406885858 : check e2422406885858 [[],[]] .chain = true := by decide
def e2422406885870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))) (.var 2))))))
theorem wire_e2422406885870 : Closed e2422406885870 ∧ code e2422406885870 = 11218499908078 := by decide
theorem cert_e2422406885870 : check e2422406885870 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406886254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406886254 : Closed e2422406886254 ∧ code e2422406886254 = 11218499908462 := by decide
theorem cert_e2422406886254 : check e2422406886254 [[],[]] .chain = true := by decide
def e2422406886262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406886262 : Closed e2422406886262 ∧ code e2422406886262 = 11218499908470 := by decide
theorem cert_e2422406886262 : check e2422406886262 [[],[]] .chain = true := by decide
def e2422406886318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406886318 : Closed e2422406886318 ∧ code e2422406886318 = 11218499908526 := by decide
theorem cert_e2422406886318 : check e2422406886318 [[],[]] .chain = true := by decide
def e2422406886330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406886330 : Closed e2422406886330 ∧ code e2422406886330 = 11218499908538 := by decide
theorem cert_e2422406886330 : check e2422406886330 [[],[]] .chain = true := by decide
def e2422406886358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406886358 : Closed e2422406886358 ∧ code e2422406886358 = 11218499908566 := by decide
theorem cert_e2422406886358 : check e2422406886358 [[],[]] .chain = true := by decide
def e2422406886362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406886362 : Closed e2422406886362 ∧ code e2422406886362 = 11218499908570 := by decide
theorem cert_e2422406886362 : check e2422406886362 [[],[]] .chain = true := by decide
def e2422406886638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406886638 : Closed e2422406886638 ∧ code e2422406886638 = 11218499908846 := by decide
theorem cert_e2422406886638 : check e2422406886638 [[],[]] .chain = true := by decide
def e2422406886646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406886646 : Closed e2422406886646 ∧ code e2422406886646 = 11218499908854 := by decide
theorem cert_e2422406886646 : check e2422406886646 [[],[]] .chain = true := by decide
def e2422406887022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406887022 : Closed e2422406887022 ∧ code e2422406887022 = 11218499909230 := by decide
theorem cert_e2422406887022 : check e2422406887022 [[],[]] .chain = true := by decide
def e2422406887034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406887034 : Closed e2422406887034 ∧ code e2422406887034 = 11218499909242 := by decide
theorem cert_e2422406887034 : check e2422406887034 [[],[]] .chain = true := by decide
def e2422406887174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406887174 : Closed e2422406887174 ∧ code e2422406887174 = 11218499909382 := by decide
theorem cert_e2422406887174 : check e2422406887174 [[],[]] .chain = true := by decide
def e2422406887198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.var 3)))))))
theorem wire_e2422406887198 : Closed e2422406887198 ∧ code e2422406887198 = 11218499909406 := by decide
theorem cert_e2422406887198 : check e2422406887198 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406887222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406887222 : Closed e2422406887222 ∧ code e2422406887222 = 11218499909430 := by decide
theorem cert_e2422406887222 : check e2422406887222 [[],[]] .chain = true := by decide
def e2422406887226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406887226 : Closed e2422406887226 ∧ code e2422406887226 = 11218499909434 := by decide
theorem cert_e2422406887226 : check e2422406887226 [[],[]] .chain = true := by decide
def e2422406887434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406887434 : Closed e2422406887434 ∧ code e2422406887434 = 11218499909642 := by decide
theorem cert_e2422406887434 : check e2422406887434 [[],[]] .chain = true := by decide
def e2422406887470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406887470 : Closed e2422406887470 ∧ code e2422406887470 = 11218499909678 := by decide
theorem cert_e2422406887470 : check e2422406887470 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406887478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406887478 : Closed e2422406887478 ∧ code e2422406887478 = 11218499909686 := by decide
theorem cert_e2422406887478 : check e2422406887478 [[],[]] .chain = true := by decide
def e2422406887482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406887482 : Closed e2422406887482 ∧ code e2422406887482 = 11218499909690 := by decide
theorem cert_e2422406887482 : check e2422406887482 [[],[]] .chain = true := by decide
def e2422406887530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422406887530 : Closed e2422406887530 ∧ code e2422406887530 = 11218499909738 := by decide
theorem cert_e2422406887530 : check e2422406887530 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406887566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406887566 : Closed e2422406887566 ∧ code e2422406887566 = 11218499909774 := by decide
theorem cert_e2422406887566 : check e2422406887566 [[],[]] .chain = true := by decide
def e2422406887578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406887578 : Closed e2422406887578 ∧ code e2422406887578 = 11218499909786 := by decide
theorem cert_e2422406887578 : check e2422406887578 [[],[]] .chain = true := by decide
def e2422406887622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406887622 : Closed e2422406887622 ∧ code e2422406887622 = 11218499909830 := by decide
theorem cert_e2422406887622 : check e2422406887622 [[],[]] .chain = true := by decide
def e2422406887650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406887650 : Closed e2422406887650 ∧ code e2422406887650 = 11218499909858 := by decide
theorem cert_e2422406887650 : check e2422406887650 [[],[]] .chain = true := by decide
def e2422406887662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406887662 : Closed e2422406887662 ∧ code e2422406887662 = 11218499909870 := by decide
theorem cert_e2422406887662 : check e2422406887662 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406887670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406887670 : Closed e2422406887670 ∧ code e2422406887670 = 11218499909878 := by decide
theorem cert_e2422406887670 : check e2422406887670 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406887818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406887818 : Closed e2422406887818 ∧ code e2422406887818 = 11218499910026 := by decide
theorem cert_e2422406887818 : check e2422406887818 [[],[]] .chain = true := by decide
def e2422406887842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406887842 : Closed e2422406887842 ∧ code e2422406887842 = 11218499910050 := by decide
theorem cert_e2422406887842 : check e2422406887842 [[],[]] .chain = true := by decide
def e2422406887854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406887854 : Closed e2422406887854 ∧ code e2422406887854 = 11218499910062 := by decide
theorem cert_e2422406887854 : check e2422406887854 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406887862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422406887862 : Closed e2422406887862 ∧ code e2422406887862 = 11218499910070 := by decide
theorem cert_e2422406887862 : check e2422406887862 [[],[]] .chain = true := by decide
def e2422406887866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406887866 : Closed e2422406887866 ∧ code e2422406887866 = 11218499910074 := by decide
theorem cert_e2422406887866 : check e2422406887866 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406887894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422406887894 : Closed e2422406887894 ∧ code e2422406887894 = 11218499910102 := by decide
theorem cert_e2422406887894 : check e2422406887894 [[],[]] .chain = true := by decide
def e2422406887898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422406887898 : Closed e2422406887898 ∧ code e2422406887898 = 11218499910106 := by decide
theorem cert_e2422406887898 : check e2422406887898 [[],[]] .chain = true := by decide
def e2422406887914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406887914 : Closed e2422406887914 ∧ code e2422406887914 = 11218499910122 := by decide
theorem cert_e2422406887914 : check e2422406887914 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406887938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406887938 : Closed e2422406887938 ∧ code e2422406887938 = 11218499910146 := by decide
theorem cert_e2422406887938 : check e2422406887938 [[],[]] .chain = true := by decide
def e2422406887950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406887950 : Closed e2422406887950 ∧ code e2422406887950 = 11218499910158 := by decide
theorem cert_e2422406887950 : check e2422406887950 [[],[]] .chain = true := by decide
def e2422406887962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406887962 : Closed e2422406887962 ∧ code e2422406887962 = 11218499910170 := by decide
theorem cert_e2422406887962 : check e2422406887962 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406888034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406888034 : Closed e2422406888034 ∧ code e2422406888034 = 11218499910242 := by decide
theorem cert_e2422406888034 : check e2422406888034 [[],[]] .chain = true := by decide
def e2422406888046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406888046 : Closed e2422406888046 ∧ code e2422406888046 = 11218499910254 := by decide
theorem cert_e2422406888046 : check e2422406888046 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406888054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406888054 : Closed e2422406888054 ∧ code e2422406888054 = 11218499910262 := by decide
theorem cert_e2422406888054 : check e2422406888054 [[],[]] .chain = true := by decide
def e2422406888058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406888058 : Closed e2422406888058 ∧ code e2422406888058 = 11218499910266 := by decide
theorem cert_e2422406888058 : check e2422406888058 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406888198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406888198 : Closed e2422406888198 ∧ code e2422406888198 = 11218499910406 := by decide
theorem cert_e2422406888198 : check e2422406888198 [[],[]] .chain = true := by decide
def e2422406888222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406888222 : Closed e2422406888222 ∧ code e2422406888222 = 11218499910430 := by decide
theorem cert_e2422406888222 : check e2422406888222 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406888246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406888246 : Closed e2422406888246 ∧ code e2422406888246 = 11218499910454 := by decide
theorem cert_e2422406888246 : check e2422406888246 [[],[]] .chain = true := by decide
def e2422406888250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406888250 : Closed e2422406888250 ∧ code e2422406888250 = 11218499910458 := by decide
theorem cert_e2422406888250 : check e2422406888250 [[],[]] .chain = true := by decide
def e2422406888322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406888322 : Closed e2422406888322 ∧ code e2422406888322 = 11218499910530 := by decide
theorem cert_e2422406888322 : check e2422406888322 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406888334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406888334 : Closed e2422406888334 ∧ code e2422406888334 = 11218499910542 := by decide
theorem cert_e2422406888334 : check e2422406888334 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406888346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406888346 : Closed e2422406888346 ∧ code e2422406888346 = 11218499910554 := by decide
theorem cert_e2422406888346 : check e2422406888346 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406889558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 1))))))
theorem wire_e2422406889558 : Closed e2422406889558 ∧ code e2422406889558 = 11218499911766 := by decide
theorem cert_e2422406889558 : check e2422406889558 [[],[]] .chain = true := by decide
def e2422406889562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 0)))))) (.var 1)) (.var 0))))))
theorem wire_e2422406889562 : Closed e2422406889562 ∧ code e2422406889562 = 11218499911770 := by decide
theorem cert_e2422406889562 : check e2422406889562 [[],[]] .chain = true := by decide
def e2422406889838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e2422406889838 : Closed e2422406889838 ∧ code e2422406889838 = 11218499912046 := by decide
theorem cert_e2422406889838 : check e2422406889838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406889846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e2422406889846 : Closed e2422406889846 ∧ code e2422406889846 = 11218499912054 := by decide
theorem cert_e2422406889846 : check e2422406889846 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406889910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 1)) (.var 1))))))
theorem wire_e2422406889910 : Closed e2422406889910 ∧ code e2422406889910 = 11218499912118 := by decide
theorem cert_e2422406889910 : check e2422406889910 [[],[]] .chain = true := by decide
def e2422406889942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0)) (.var 1))))))
theorem wire_e2422406889942 : Closed e2422406889942 ∧ code e2422406889942 = 11218499912150 := by decide
theorem cert_e2422406889942 : check e2422406889942 [[],[]] .chain = true := by decide
def e2422406889946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1)) (.var 0))))))
theorem wire_e2422406889946 : Closed e2422406889946 ∧ code e2422406889946 = 11218499912154 := by decide
theorem cert_e2422406889946 : check e2422406889946 [[],[]] .chain = true := by decide
def e2422406889962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0)) (.var 0))))))
theorem wire_e2422406889962 : Closed e2422406889962 ∧ code e2422406889962 = 11218499912170 := by decide
theorem cert_e2422406889962 : check e2422406889962 [[],[]] .chain = true := by decide
def e2422406890326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422406890326 : Closed e2422406890326 ∧ code e2422406890326 = 11218499912534 := by decide
private def t_e2422406890326 : Term := (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 3)))))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))) (.var 1))
theorem cert_e2422406890326 : ¬ IsSelfInterpreter e2422406890326 :=
  wIdentity (t := t_e2422406890326) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]]) (t := (inv e2422406890326)) (by decide)) (by decide)
def e2422406890330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422406890330 : Closed e2422406890330 ∧ code e2422406890330 = 11218499912538 := by decide
private def t_e2422406890330 : Term := (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 3)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))))))))
theorem cert_e2422406890330 : ¬ IsSelfInterpreter e2422406890330 :=
  wIdentity (t := t_e2422406890330) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]]) (t := (inv e2422406890330)) (by decide)) (by decide)
def e2422406890614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406890614 : Closed e2422406890614 ∧ code e2422406890614 = 11218499912822 := by decide
theorem cert_e2422406890614 : check e2422406890614 [[],[]] .chain = true := by decide
def e2422406890710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406890710 : Closed e2422406890710 ∧ code e2422406890710 = 11218499912918 := by decide
theorem cert_e2422406890710 : check e2422406890710 [[],[]] .chain = true := by decide
def e2422406890714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406890714 : Closed e2422406890714 ∧ code e2422406890714 = 11218499912922 := by decide
theorem cert_e2422406890714 : check e2422406890714 [[],[]] .chain = true := by decide
def e2422406890730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406890730 : Closed e2422406890730 ∧ code e2422406890730 = 11218499912938 := by decide
theorem cert_e2422406890730 : check e2422406890730 [[],[]] .chain = true := by decide
def e2422406890806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406890806 : Closed e2422406890806 ∧ code e2422406890806 = 11218499913014 := by decide
theorem cert_e2422406890806 : check e2422406890806 [[],[]] .chain = true := by decide
def e2422406890810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406890810 : Closed e2422406890810 ∧ code e2422406890810 = 11218499913018 := by decide
theorem cert_e2422406890810 : check e2422406890810 [[],[]] .chain = true := by decide
def e2422406890894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406890894 : Closed e2422406890894 ∧ code e2422406890894 = 11218499913102 := by decide
theorem cert_e2422406890894 : check e2422406890894 [[],[]] .chain = true := by decide
def e2422406890906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406890906 : Closed e2422406890906 ∧ code e2422406890906 = 11218499913114 := by decide
theorem cert_e2422406890906 : check e2422406890906 [[],[]] .chain = true := by decide
def e2422406891062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406891062 : Closed e2422406891062 ∧ code e2422406891062 = 11218499913270 := by decide
theorem cert_e2422406891062 : check e2422406891062 [[],[]] .chain = true := by decide
def e2422406891066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406891066 : Closed e2422406891066 ∧ code e2422406891066 = 11218499913274 := by decide
theorem cert_e2422406891066 : check e2422406891066 [[],[]] .chain = true := by decide
def e2422406891150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406891150 : Closed e2422406891150 ∧ code e2422406891150 = 11218499913358 := by decide
theorem cert_e2422406891150 : check e2422406891150 [[],[]] .chain = true := by decide
def e2422406891206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406891206 : Closed e2422406891206 ∧ code e2422406891206 = 11218499913414 := by decide
theorem cert_e2422406891206 : check e2422406891206 [[],[]] .chain = true := by decide
def e2422406891286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406891286 : Closed e2422406891286 ∧ code e2422406891286 = 11218499913494 := by decide
theorem cert_e2422406891286 : check e2422406891286 [[],[]] .chain = true := by decide
def e2422406891290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406891290 : Closed e2422406891290 ∧ code e2422406891290 = 11218499913498 := by decide
theorem cert_e2422406891290 : check e2422406891290 [[],[]] .chain = true := by decide
def e2422406891334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406891334 : Closed e2422406891334 ∧ code e2422406891334 = 11218499913542 := by decide
theorem cert_e2422406891334 : check e2422406891334 [[],[]] .chain = true := by decide
def e2422406891362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406891362 : Closed e2422406891362 ∧ code e2422406891362 = 11218499913570 := by decide
theorem cert_e2422406891362 : check e2422406891362 [[],[]] .chain = true := by decide
def e2422406891374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e2422406891374 : Closed e2422406891374 ∧ code e2422406891374 = 11218499913582 := by decide
theorem cert_e2422406891374 : check e2422406891374 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406891382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e2422406891382 : Closed e2422406891382 ∧ code e2422406891382 = 11218499913590 := by decide
theorem cert_e2422406891382 : check e2422406891382 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406891446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1)) (.var 1))))))
theorem wire_e2422406891446 : Closed e2422406891446 ∧ code e2422406891446 = 11218499913654 := by decide
theorem cert_e2422406891446 : check e2422406891446 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406892630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422406892630 : Closed e2422406892630 ∧ code e2422406892630 = 11218499914838 := by decide
theorem cert_e2422406892630 : check e2422406892630 [[],[]] .chain = true := by decide
def e2422406892634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422406892634 : Closed e2422406892634 ∧ code e2422406892634 = 11218499914842 := by decide
theorem cert_e2422406892634 : check e2422406892634 [[],[]] .chain = true := by decide
def e2422406892822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406892822 : Closed e2422406892822 ∧ code e2422406892822 = 11218499915030 := by decide
theorem cert_e2422406892822 : check e2422406892822 [[],[]] .chain = true := by decide
def e2422406892898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406892898 : Closed e2422406892898 ∧ code e2422406892898 = 11218499915106 := by decide
theorem cert_e2422406892898 : check e2422406892898 [[],[]] .chain = true := by decide
def e2422406892910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422406892910 : Closed e2422406892910 ∧ code e2422406892910 = 11218499915118 := by decide
theorem cert_e2422406892910 : check e2422406892910 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406892918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422406892918 : Closed e2422406892918 ∧ code e2422406892918 = 11218499915126 := by decide
theorem cert_e2422406892918 : check e2422406892918 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406892938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406892938 : Closed e2422406892938 ∧ code e2422406892938 = 11218499915146 := by decide
theorem cert_e2422406892938 : check e2422406892938 [[],[]] .chain = true := by decide
def e2422406892962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406892962 : Closed e2422406892962 ∧ code e2422406892962 = 11218499915170 := by decide
theorem cert_e2422406892962 : check e2422406892962 [[],[]] .chain = true := by decide
def e2422406892974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2422406892974 : Closed e2422406892974 ∧ code e2422406892974 = 11218499915182 := by decide
theorem cert_e2422406892974 : check e2422406892974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406892982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e2422406892982 : Closed e2422406892982 ∧ code e2422406892982 = 11218499915190 := by decide
theorem cert_e2422406892982 : check e2422406892982 [[],[]] .chain = true := by decide
def e2422406892986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2422406892986 : Closed e2422406892986 ∧ code e2422406892986 = 11218499915194 := by decide
theorem cert_e2422406892986 : check e2422406892986 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406893014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422406893014 : Closed e2422406893014 ∧ code e2422406893014 = 11218499915222 := by decide
def e2422406893018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422406893018 : Closed e2422406893018 ∧ code e2422406893018 = 11218499915226 := by decide
def e2422406893098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422406893098 : Closed e2422406893098 ∧ code e2422406893098 = 11218499915306 := by decide
theorem cert_e2422406893098 : check e2422406893098 [[],[]] .chain = true := by decide
def e2422406893194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406893194 : Closed e2422406893194 ∧ code e2422406893194 = 11218499915402 := by decide
theorem cert_e2422406893194 : check e2422406893194 [[],[]] .chain = true := by decide
def e2422406893218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406893218 : Closed e2422406893218 ∧ code e2422406893218 = 11218499915426 := by decide
theorem cert_e2422406893218 : check e2422406893218 [[],[]] .chain = true := by decide
def e2422406893230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406893230 : Closed e2422406893230 ∧ code e2422406893230 = 11218499915438 := by decide
theorem cert_e2422406893230 : check e2422406893230 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406893238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e2422406893238 : Closed e2422406893238 ∧ code e2422406893238 = 11218499915446 := by decide
theorem cert_e2422406893238 : check e2422406893238 [[],[]] .chain = true := by decide
def e2422406893242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406893242 : Closed e2422406893242 ∧ code e2422406893242 = 11218499915450 := by decide
theorem cert_e2422406893242 : check e2422406893242 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406893270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2422406893270 : Closed e2422406893270 ∧ code e2422406893270 = 11218499915478 := by decide
theorem cert_e2422406893270 : check e2422406893270 [[],[]] .chain = true := by decide
def e2422406893274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2422406893274 : Closed e2422406893274 ∧ code e2422406893274 = 11218499915482 := by decide
theorem cert_e2422406893274 : check e2422406893274 [[],[]] .chain = true := by decide
def e2422406893290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422406893290 : Closed e2422406893290 ∧ code e2422406893290 = 11218499915498 := by decide
theorem cert_e2422406893290 : check e2422406893290 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406893398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422406893398 : Closed e2422406893398 ∧ code e2422406893398 = 11218499915606 := by decide
theorem cert_e2422406893398 : check e2422406893398 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406893402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422406893402 : Closed e2422406893402 ∧ code e2422406893402 = 11218499915610 := by decide
theorem cert_e2422406893402 : check e2422406893402 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406893418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2422406893418 : Closed e2422406893418 ∧ code e2422406893418 = 11218499915626 := by decide
theorem cert_e2422406893418 : check e2422406893418 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406893590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422406893590 : Closed e2422406893590 ∧ code e2422406893590 = 11218499915798 := by decide
theorem cert_e2422406893590 : check e2422406893590 [[],[]] .chain = true := by decide
def e2422406893686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422406893686 : Closed e2422406893686 ∧ code e2422406893686 = 11218499915894 := by decide
theorem cert_e2422406893686 : check e2422406893686 [[],[]] .chain = true := by decide
def e2422406893690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422406893690 : Closed e2422406893690 ∧ code e2422406893690 = 11218499915898 := by decide
theorem cert_e2422406893690 : check e2422406893690 [[],[]] .chain = true := by decide
def e2422406893782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422406893782 : Closed e2422406893782 ∧ code e2422406893782 = 11218499915990 := by decide
theorem cert_e2422406893782 : check e2422406893782 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406893878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406893878 : Closed e2422406893878 ∧ code e2422406893878 = 11218499916086 := by decide
theorem cert_e2422406893878 : check e2422406893878 [[],[]] .chain = true := by decide
def e2422406893882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406893882 : Closed e2422406893882 ∧ code e2422406893882 = 11218499916090 := by decide
theorem cert_e2422406893882 : check e2422406893882 [[],[]] .chain = true := by decide
def e2422406893966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422406893966 : Closed e2422406893966 ∧ code e2422406893966 = 11218499916174 := by decide
theorem cert_e2422406893966 : check e2422406893966 [[],[]] .chain = true := by decide
def e2422406894022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422406894022 : Closed e2422406894022 ∧ code e2422406894022 = 11218499916230 := by decide
theorem cert_e2422406894022 : check e2422406894022 [[],[]] .chain = true := by decide
def e2422406894358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406894358 : Closed e2422406894358 ∧ code e2422406894358 = 11218499916566 := by decide
theorem cert_e2422406894358 : check e2422406894358 [[],[]] .chain = true := by decide
def e2422406894434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406894434 : Closed e2422406894434 ∧ code e2422406894434 = 11218499916642 := by decide
theorem cert_e2422406894434 : check e2422406894434 [[],[]] .chain = true := by decide
def e2422406894446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406894446 : Closed e2422406894446 ∧ code e2422406894446 = 11218499916654 := by decide
theorem cert_e2422406894446 : check e2422406894446 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406894454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406894454 : Closed e2422406894454 ∧ code e2422406894454 = 11218499916662 := by decide
theorem cert_e2422406894454 : check e2422406894454 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406894474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406894474 : Closed e2422406894474 ∧ code e2422406894474 = 11218499916682 := by decide
theorem cert_e2422406894474 : check e2422406894474 [[],[]] .chain = true := by decide
def e2422406894498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406894498 : Closed e2422406894498 ∧ code e2422406894498 = 11218499916706 := by decide
theorem cert_e2422406894498 : check e2422406894498 [[],[]] .chain = true := by decide
def e2422406894510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406894510 : Closed e2422406894510 ∧ code e2422406894510 = 11218499916718 := by decide
theorem cert_e2422406894510 : check e2422406894510 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406894518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2422406894518 : Closed e2422406894518 ∧ code e2422406894518 = 11218499916726 := by decide
theorem cert_e2422406894518 : check e2422406894518 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422406890326
#print axioms Blc.Floor43.cert_e2422406890330
