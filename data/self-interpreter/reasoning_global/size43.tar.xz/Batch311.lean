import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411630898286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411630898286 : Closed e2411630898286 ∧ code e2411630898286 = 11207723920494 := by decide
theorem cert_e2411630898286 : check e2411630898286 [[],[]] .chain = true := by decide
def e2411630898298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411630898298 : Closed e2411630898298 ∧ code e2411630898298 = 11207723920506 := by decide
theorem cert_e2411630898298 : check e2411630898298 [[],[]] .chain = true := by decide
def e2411630898462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411630898462 : Closed e2411630898462 ∧ code e2411630898462 = 11207723920670 := by decide
theorem cert_e2411630898462 : check e2411630898462 [[],[]] .chain = true := by decide
def e2411630898630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411630898630 : Closed e2411630898630 ∧ code e2411630898630 = 11207723920838 := by decide
theorem cert_e2411630898630 : check e2411630898630 [[],[]] .chain = true := by decide
def e2411630898734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2411630898734 : Closed e2411630898734 ∧ code e2411630898734 = 11207723920942 := by decide
theorem cert_e2411630898734 : check e2411630898734 [[],[]] .chain = true := by decide
def e2411630898914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2411630898914 : Closed e2411630898914 ∧ code e2411630898914 = 11207723921122 := by decide
theorem cert_e2411630898914 : check e2411630898914 [[],[]] .chain = true := by decide
def e2411630898926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2411630898926 : Closed e2411630898926 ∧ code e2411630898926 = 11207723921134 := by decide
theorem cert_e2411630898926 : check e2411630898926 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630898966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2411630898966 : Closed e2411630898966 ∧ code e2411630898966 = 11207723921174 := by decide
theorem cert_e2411630898966 : check e2411630898966 [[],[]] .chain = true := by decide
def e2411630898970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411630898970 : Closed e2411630898970 ∧ code e2411630898970 = 11207723921178 := by decide
theorem cert_e2411630898970 : check e2411630898970 [[],[]] .chain = true := by decide
def e2411630899014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411630899014 : Closed e2411630899014 ∧ code e2411630899014 = 11207723921222 := by decide
theorem cert_e2411630899014 : check e2411630899014 [[],[]] .chain = true := by decide
def e2411630899042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2411630899042 : Closed e2411630899042 ∧ code e2411630899042 = 11207723921250 := by decide
theorem cert_e2411630899042 : check e2411630899042 [[],[]] .chain = true := by decide
def e2411630899054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2411630899054 : Closed e2411630899054 ∧ code e2411630899054 = 11207723921262 := by decide
theorem cert_e2411630899054 : check e2411630899054 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630899062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2411630899062 : Closed e2411630899062 ∧ code e2411630899062 = 11207723921270 := by decide
theorem cert_e2411630899062 : check e2411630899062 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630899422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2411630899422 : Closed e2411630899422 ∧ code e2411630899422 = 11207723921630 := by decide
theorem cert_e2411630899422 : check e2411630899422 [[],[]] .chain = true := by decide
def e2411630899450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2411630899450 : Closed e2411630899450 ∧ code e2411630899450 = 11207723921658 := by decide
theorem cert_e2411630899450 : check e2411630899450 [[],[]] .chain = true := by decide
def e2411630899998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411630899998 : Closed e2411630899998 ∧ code e2411630899998 = 11207723922206 := by decide
theorem cert_e2411630899998 : check e2411630899998 [[],[]] .chain = true := by decide
def e2411630900166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411630900166 : Closed e2411630900166 ∧ code e2411630900166 = 11207723922374 := by decide
theorem cert_e2411630900166 : check e2411630900166 [[],[]] .chain = true := by decide
def e2411630901310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2411630901310 : Closed e2411630901310 ∧ code e2411630901310 = 11207723923518 := by decide
theorem cert_e2411630901310 : check e2411630901310 [[],[]] .chain = true := by decide
def e2411630901730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2411630901730 : Closed e2411630901730 ∧ code e2411630901730 = 11207723923938 := by decide
theorem cert_e2411630901730 : check e2411630901730 [[],[]] .chain = true := by decide
def e2411630901742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2411630901742 : Closed e2411630901742 ∧ code e2411630901742 = 11207723923950 := by decide
theorem cert_e2411630901742 : check e2411630901742 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630902302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2411630902302 : Closed e2411630902302 ∧ code e2411630902302 = 11207723924510 := by decide
theorem cert_e2411630902302 : check e2411630902302 [[],[]] .chain = true := by decide
def e2411630902326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411630902326 : Closed e2411630902326 ∧ code e2411630902326 = 11207723924534 := by decide
theorem cert_e2411630902326 : check e2411630902326 [[],[]] .chain = true := by decide
def e2411630902330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411630902330 : Closed e2411630902330 ∧ code e2411630902330 = 11207723924538 := by decide
theorem cert_e2411630902330 : check e2411630902330 [[],[]] .chain = true := by decide
def e2411630902470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411630902470 : Closed e2411630902470 ∧ code e2411630902470 = 11207723924678 := by decide
theorem cert_e2411630902470 : check e2411630902470 [[],[]] .chain = true := by decide
def e2411630902498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2411630902498 : Closed e2411630902498 ∧ code e2411630902498 = 11207723924706 := by decide
theorem cert_e2411630902498 : check e2411630902498 [[],[]] .chain = true := by decide
def e2411630902510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411630902510 : Closed e2411630902510 ∧ code e2411630902510 = 11207723924718 := by decide
theorem cert_e2411630902510 : check e2411630902510 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630902518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411630902518 : Closed e2411630902518 ∧ code e2411630902518 = 11207723924726 := by decide
theorem cert_e2411630902518 : check e2411630902518 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630921134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2411630921134 : Closed e2411630921134 ∧ code e2411630921134 = 11207723943342 := by decide
theorem cert_e2411630921134 : check e2411630921134 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630921146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2411630921146 : Closed e2411630921146 ∧ code e2411630921146 = 11207723943354 := by decide
theorem cert_e2411630921146 : check e2411630921146 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630921194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2411630921194 : Closed e2411630921194 ∧ code e2411630921194 = 11207723943402 := by decide
theorem cert_e2411630921194 : check e2411630921194 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630921326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411630921326 : Closed e2411630921326 ∧ code e2411630921326 = 11207723943534 := by decide
theorem cert_e2411630921326 : check e2411630921326 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630921338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411630921338 : Closed e2411630921338 ∧ code e2411630921338 = 11207723943546 := by decide
theorem cert_e2411630921338 : check e2411630921338 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630921502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411630921502 : Closed e2411630921502 ∧ code e2411630921502 = 11207723943710 := by decide
theorem cert_e2411630921502 : check e2411630921502 [[],[]] .chain = true := by decide
def e2411630921614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411630921614 : Closed e2411630921614 ∧ code e2411630921614 = 11207723943822 := by decide
theorem cert_e2411630921614 : check e2411630921614 [[],[]] .chain = true := by decide
def e2411630921626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411630921626 : Closed e2411630921626 ∧ code e2411630921626 = 11207723943834 := by decide
theorem cert_e2411630921626 : check e2411630921626 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630925366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411630925366 : Closed e2411630925366 ∧ code e2411630925366 = 11207723947574 := by decide
theorem cert_e2411630925366 : check e2411630925366 [[],[]] .chain = true := by decide
def e2411630925370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411630925370 : Closed e2411630925370 ∧ code e2411630925370 = 11207723947578 := by decide
theorem cert_e2411630925370 : check e2411630925370 [[],[]] .chain = true := by decide
def e2411630925454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411630925454 : Closed e2411630925454 ∧ code e2411630925454 = 11207723947662 := by decide
theorem cert_e2411630925454 : check e2411630925454 [[],[]] .chain = true := by decide
def e2411630925510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411630925510 : Closed e2411630925510 ∧ code e2411630925510 = 11207723947718 := by decide
theorem cert_e2411630925510 : check e2411630925510 [[],[]] .chain = true := by decide
def e2411630925590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2411630925590 : Closed e2411630925590 ∧ code e2411630925590 = 11207723947798 := by decide
theorem cert_e2411630925590 : check e2411630925590 [[],[]] .chain = true := by decide
def e2411630925594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411630925594 : Closed e2411630925594 ∧ code e2411630925594 = 11207723947802 := by decide
theorem cert_e2411630925594 : check e2411630925594 [[],[]] .chain = true := by decide
def e2411630925638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411630925638 : Closed e2411630925638 ∧ code e2411630925638 = 11207723947846 := by decide
theorem cert_e2411630925638 : check e2411630925638 [[],[]] .chain = true := by decide
def e2411630925666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2411630925666 : Closed e2411630925666 ∧ code e2411630925666 = 11207723947874 := by decide
theorem cert_e2411630925666 : check e2411630925666 [[],[]] .chain = true := by decide
def e2411630925678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2411630925678 : Closed e2411630925678 ∧ code e2411630925678 = 11207723947886 := by decide
theorem cert_e2411630925678 : check e2411630925678 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630925686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2411630925686 : Closed e2411630925686 ∧ code e2411630925686 = 11207723947894 := by decide
theorem cert_e2411630925686 : check e2411630925686 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630925750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2411630925750 : Closed e2411630925750 ∧ code e2411630925750 = 11207723947958 := by decide
theorem cert_e2411630925750 : check e2411630925750 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630925934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2411630925934 : Closed e2411630925934 ∧ code e2411630925934 = 11207723948142 := by decide
theorem cert_e2411630925934 : check e2411630925934 [[],[]] .chain = true := by decide
def e2411630925946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2411630925946 : Closed e2411630925946 ∧ code e2411630925946 = 11207723948154 := by decide
theorem cert_e2411630925946 : check e2411630925946 [[],[]] .chain = true := by decide
def e2411630926222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411630926222 : Closed e2411630926222 ∧ code e2411630926222 = 11207723948430 := by decide
theorem cert_e2411630926222 : check e2411630926222 [[],[]] .chain = true := by decide
def e2411630926278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411630926278 : Closed e2411630926278 ∧ code e2411630926278 = 11207723948486 := by decide
theorem cert_e2411630926278 : check e2411630926278 [[],[]] .chain = true := by decide
def e2411630926878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 3))))))))))
theorem wire_e2411630926878 : Closed e2411630926878 ∧ code e2411630926878 = 11207723949086 := by decide
theorem cert_e2411630926878 : check e2411630926878 [[],[]] .chain = true := by decide
def e2411630926902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411630926902 : Closed e2411630926902 ∧ code e2411630926902 = 11207723949110 := by decide
theorem cert_e2411630926902 : check e2411630926902 [[],[]] .chain = true := by decide
def e2411630926906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411630926906 : Closed e2411630926906 ∧ code e2411630926906 = 11207723949114 := by decide
theorem cert_e2411630926906 : check e2411630926906 [[],[]] .chain = true := by decide
def e2411630927046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411630927046 : Closed e2411630927046 ∧ code e2411630927046 = 11207723949254 := by decide
theorem cert_e2411630927046 : check e2411630927046 [[],[]] .chain = true := by decide
def e2411630927074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2411630927074 : Closed e2411630927074 ∧ code e2411630927074 = 11207723949282 := by decide
theorem cert_e2411630927074 : check e2411630927074 [[],[]] .chain = true := by decide
def e2411630927086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411630927086 : Closed e2411630927086 ∧ code e2411630927086 = 11207723949294 := by decide
theorem cert_e2411630927086 : check e2411630927086 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630927094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411630927094 : Closed e2411630927094 ∧ code e2411630927094 = 11207723949302 := by decide
theorem cert_e2411630927094 : check e2411630927094 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630927478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411630927478 : Closed e2411630927478 ∧ code e2411630927478 = 11207723949686 := by decide
theorem cert_e2411630927478 : check e2411630927478 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411631488478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2411631488478 : Closed e2411631488478 ∧ code e2411631488478 = 11207724510686 := by decide
theorem cert_e2411631488478 : check e2411631488478 [[],[]] .smaller = true := by decide
def e2411631488494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2411631488494 : Closed e2411631488494 ∧ code e2411631488494 = 11207724510702 := by decide
theorem cert_e2411631488494 : check e2411631488494 [[],[]] .smaller = true := by decide
def e2411631488862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2411631488862 : Closed e2411631488862 ∧ code e2411631488862 = 11207724511070 := by decide
theorem cert_e2411631488862 : check e2411631488862 [[],[]] .smaller = true := by decide
def e2411631488890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2411631488890 : Closed e2411631488890 ∧ code e2411631488890 = 11207724511098 := by decide
theorem cert_e2411631488890 : check e2411631488890 [[],[]] .smaller = true := by decide
def e2411631488942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2411631488942 : Closed e2411631488942 ∧ code e2411631488942 = 11207724511150 := by decide
theorem cert_e2411631488942 : check e2411631488942 [[],[]] .smaller = true := by decide
def e2411631488954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2411631488954 : Closed e2411631488954 ∧ code e2411631488954 = 11207724511162 := by decide
theorem cert_e2411631488954 : check e2411631488954 [[],[]] .smaller = true := by decide
def e2411631490014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2411631490014 : Closed e2411631490014 ∧ code e2411631490014 = 11207724512222 := by decide
theorem cert_e2411631490014 : check e2411631490014 [[],[]] .smaller = true := by decide
def e2411631490030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2411631490030 : Closed e2411631490030 ∧ code e2411631490030 = 11207724512238 := by decide
theorem cert_e2411631490030 : check e2411631490030 [[],[]] .smaller = true := by decide
def e2411631492318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411631492318 : Closed e2411631492318 ∧ code e2411631492318 = 11207724514526 := by decide
theorem cert_e2411631492318 : check e2411631492318 [[],[]] .smaller = true := by decide
def e2411631492346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411631492346 : Closed e2411631492346 ∧ code e2411631492346 = 11207724514554 := by decide
theorem cert_e2411631492346 : check e2411631492346 [[],[]] .smaller = true := by decide
def e2411631492718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411631492718 : Closed e2411631492718 ∧ code e2411631492718 = 11207724514926 := by decide
theorem cert_e2411631492718 : check e2411631492718 [[],[]] .smaller = true := by decide
def e2411631492730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411631492730 : Closed e2411631492730 ∧ code e2411631492730 = 11207724514938 := by decide
theorem cert_e2411631492730 : check e2411631492730 [[],[]] .smaller = true := by decide
def e2411631521134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2411631521134 : Closed e2411631521134 ∧ code e2411631521134 = 11207724543342 := by decide
theorem cert_e2411631521134 : check e2411631521134 [[],[]] .smaller = true := by decide
def e2411631521142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2411631521142 : Closed e2411631521142 ∧ code e2411631521142 = 11207724543350 := by decide
theorem cert_e2411631521142 : check e2411631521142 [[],[]] .smaller = true := by decide
def e2411631521198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2411631521198 : Closed e2411631521198 ∧ code e2411631521198 = 11207724543406 := by decide
theorem cert_e2411631521198 : check e2411631521198 [[],[]] .smaller = true := by decide
def e2411631521210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2411631521210 : Closed e2411631521210 ∧ code e2411631521210 = 11207724543418 := by decide
theorem cert_e2411631521210 : check e2411631521210 [[],[]] .smaller = true := by decide
def e2411631521238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2411631521238 : Closed e2411631521238 ∧ code e2411631521238 = 11207724543446 := by decide
theorem cert_e2411631521238 : check e2411631521238 [[],[]] .smaller = true := by decide
def e2411631521242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2411631521242 : Closed e2411631521242 ∧ code e2411631521242 = 11207724543450 := by decide
theorem cert_e2411631521242 : check e2411631521242 [[],[]] .smaller = true := by decide
def e2411631521454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2411631521454 : Closed e2411631521454 ∧ code e2411631521454 = 11207724543662 := by decide
theorem cert_e2411631521454 : check e2411631521454 [[],[]] .smaller = true := by decide
def e2411631521466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2411631521466 : Closed e2411631521466 ∧ code e2411631521466 = 11207724543674 := by decide
theorem cert_e2411631521466 : check e2411631521466 [[],[]] .smaller = true := by decide
def e2411631521514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2411631521514 : Closed e2411631521514 ∧ code e2411631521514 = 11207724543722 := by decide
theorem cert_e2411631521514 : check e2411631521514 [[],[]] .smaller = true := by decide
def e2411631521622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2411631521622 : Closed e2411631521622 ∧ code e2411631521622 = 11207724543830 := by decide
theorem cert_e2411631521622 : check e2411631521622 [[],[]] .smaller = true := by decide
def e2411631521626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2411631521626 : Closed e2411631521626 ∧ code e2411631521626 = 11207724543834 := by decide
theorem cert_e2411631521626 : check e2411631521626 [[],[]] .smaller = true := by decide
def e2411631521642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2411631521642 : Closed e2411631521642 ∧ code e2411631521642 = 11207724543850 := by decide
theorem cert_e2411631521642 : check e2411631521642 [[],[]] .smaller = true := by decide
def e2411631522670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2411631522670 : Closed e2411631522670 ∧ code e2411631522670 = 11207724544878 := by decide
theorem cert_e2411631522670 : check e2411631522670 [[],[]] .smaller = true := by decide
def e2411631522678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2411631522678 : Closed e2411631522678 ∧ code e2411631522678 = 11207724544886 := by decide
theorem cert_e2411631522678 : check e2411631522678 [[],[]] .smaller = true := by decide
def e2411631522734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2411631522734 : Closed e2411631522734 ∧ code e2411631522734 = 11207724544942 := by decide
theorem cert_e2411631522734 : check e2411631522734 [[],[]] .smaller = true := by decide
def e2411631522746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2411631522746 : Closed e2411631522746 ∧ code e2411631522746 = 11207724544954 := by decide
theorem cert_e2411631522746 : check e2411631522746 [[],[]] .smaller = true := by decide
def e2411631522774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2411631522774 : Closed e2411631522774 ∧ code e2411631522774 = 11207724544982 := by decide
theorem cert_e2411631522774 : check e2411631522774 [[],[]] .smaller = true := by decide
def e2411631522778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2411631522778 : Closed e2411631522778 ∧ code e2411631522778 = 11207724544986 := by decide
theorem cert_e2411631522778 : check e2411631522778 [[],[]] .smaller = true := by decide
def e2411631523054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411631523054 : Closed e2411631523054 ∧ code e2411631523054 = 11207724545262 := by decide
theorem cert_e2411631523054 : check e2411631523054 [[],[]] .smaller = true := by decide
def e2411631523062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411631523062 : Closed e2411631523062 ∧ code e2411631523062 = 11207724545270 := by decide
theorem cert_e2411631523062 : check e2411631523062 [[],[]] .smaller = true := by decide
def e2411631523438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411631523438 : Closed e2411631523438 ∧ code e2411631523438 = 11207724545646 := by decide
theorem cert_e2411631523438 : check e2411631523438 [[],[]] .smaller = true := by decide
def e2411631523450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411631523450 : Closed e2411631523450 ∧ code e2411631523450 = 11207724545658 := by decide
theorem cert_e2411631523450 : check e2411631523450 [[],[]] .smaller = true := by decide
def e2411631523638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411631523638 : Closed e2411631523638 ∧ code e2411631523638 = 11207724545846 := by decide
theorem cert_e2411631523638 : check e2411631523638 [[],[]] .smaller = true := by decide
def e2411631523642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411631523642 : Closed e2411631523642 ∧ code e2411631523642 = 11207724545850 := by decide
theorem cert_e2411631523642 : check e2411631523642 [[],[]] .smaller = true := by decide
def e2411631524270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2411631524270 : Closed e2411631524270 ∧ code e2411631524270 = 11207724546478 := by decide
theorem cert_e2411631524270 : check e2411631524270 [[],[]] .smaller = true := by decide
def e2411631524282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2411631524282 : Closed e2411631524282 ∧ code e2411631524282 = 11207724546490 := by decide
theorem cert_e2411631524282 : check e2411631524282 [[],[]] .smaller = true := by decide
def e2411631524330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2411631524330 : Closed e2411631524330 ∧ code e2411631524330 = 11207724546538 := by decide
theorem cert_e2411631524330 : check e2411631524330 [[],[]] .smaller = true := by decide
def e2411631524462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411631524462 : Closed e2411631524462 ∧ code e2411631524462 = 11207724546670 := by decide
theorem cert_e2411631524462 : check e2411631524462 [[],[]] .smaller = true := by decide
def e2411631524474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411631524474 : Closed e2411631524474 ∧ code e2411631524474 = 11207724546682 := by decide
theorem cert_e2411631524474 : check e2411631524474 [[],[]] .smaller = true := by decide
def e2411631524762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411631524762 : Closed e2411631524762 ∧ code e2411631524762 = 11207724546970 := by decide
theorem cert_e2411631524762 : check e2411631524762 [[],[]] .smaller = true := by decide
def e2411631524830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 3))))))))
theorem wire_e2411631524830 : Closed e2411631524830 ∧ code e2411631524830 = 11207724547038 := by decide
theorem cert_e2411631524830 : check e2411631524830 [[],[]] .sourceHead = true := by decide
def e2411631525078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2411631525078 : Closed e2411631525078 ∧ code e2411631525078 = 11207724547286 := by decide
theorem cert_e2411631525078 : check e2411631525078 [[],[]] .smaller = true := by decide
def e2411631525082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2411631525082 : Closed e2411631525082 ∧ code e2411631525082 = 11207724547290 := by decide
theorem cert_e2411631525082 : check e2411631525082 [[],[]] .smaller = true := by decide
def e2411631525098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2411631525098 : Closed e2411631525098 ∧ code e2411631525098 = 11207724547306 := by decide
theorem cert_e2411631525098 : check e2411631525098 [[],[]] .smaller = true := by decide
def e2411631525174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411631525174 : Closed e2411631525174 ∧ code e2411631525174 = 11207724547382 := by decide
theorem cert_e2411631525174 : check e2411631525174 [[],[]] .smaller = true := by decide
def e2411631525178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411631525178 : Closed e2411631525178 ∧ code e2411631525178 = 11207724547386 := by decide
theorem cert_e2411631525178 : check e2411631525178 [[],[]] .smaller = true := by decide
def e2411631525274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411631525274 : Closed e2411631525274 ∧ code e2411631525274 = 11207724547482 := by decide
theorem cert_e2411631525274 : check e2411631525274 [[],[]] .smaller = true := by decide
def e2411631525598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 3))))))))
theorem wire_e2411631525598 : Closed e2411631525598 ∧ code e2411631525598 = 11207724547806 := by decide
theorem cert_e2411631525598 : check e2411631525598 [[],[]] .sourceHead = true := by decide
def e2411631525622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 3)) (.var 1))))))))
theorem wire_e2411631525622 : Closed e2411631525622 ∧ code e2411631525622 = 11207724547830 := by decide
theorem cert_e2411631525622 : check e2411631525622 [[],[]] .sourceHead = true := by decide
def e2411631526878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2411631526878 : Closed e2411631526878 ∧ code e2411631526878 = 11207724549086 := by decide
theorem cert_e2411631526878 : check e2411631526878 [[],[]] .smaller = true := by decide
def e2411631526894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2411631526894 : Closed e2411631526894 ∧ code e2411631526894 = 11207724549102 := by decide
theorem cert_e2411631526894 : check e2411631526894 [[],[]] .smaller = true := by decide
def e2411631528814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411631528814 : Closed e2411631528814 ∧ code e2411631528814 = 11207724551022 := by decide
theorem cert_e2411631528814 : check e2411631528814 [[],[]] .smaller = true := by decide
def e2411631528822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411631528822 : Closed e2411631528822 ∧ code e2411631528822 = 11207724551030 := by decide
theorem cert_e2411631528822 : check e2411631528822 [[],[]] .smaller = true := by decide
def e2411631528878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411631528878 : Closed e2411631528878 ∧ code e2411631528878 = 11207724551086 := by decide
theorem cert_e2411631528878 : check e2411631528878 [[],[]] .smaller = true := by decide
def e2411631528890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411631528890 : Closed e2411631528890 ∧ code e2411631528890 = 11207724551098 := by decide
theorem cert_e2411631528890 : check e2411631528890 [[],[]] .smaller = true := by decide
def e2411631528918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411631528918 : Closed e2411631528918 ∧ code e2411631528918 = 11207724551126 := by decide
theorem cert_e2411631528918 : check e2411631528918 [[],[]] .smaller = true := by decide
def e2411631528922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411631528922 : Closed e2411631528922 ∧ code e2411631528922 = 11207724551130 := by decide
theorem cert_e2411631528922 : check e2411631528922 [[],[]] .smaller = true := by decide
def e2411631529198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411631529198 : Closed e2411631529198 ∧ code e2411631529198 = 11207724551406 := by decide
theorem cert_e2411631529198 : check e2411631529198 [[],[]] .smaller = true := by decide
def e2411631529206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411631529206 : Closed e2411631529206 ∧ code e2411631529206 = 11207724551414 := by decide
theorem cert_e2411631529206 : check e2411631529206 [[],[]] .smaller = true := by decide
def e2411631529582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411631529582 : Closed e2411631529582 ∧ code e2411631529582 = 11207724551790 := by decide
theorem cert_e2411631529582 : check e2411631529582 [[],[]] .smaller = true := by decide
def e2411631529594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411631529594 : Closed e2411631529594 ∧ code e2411631529594 = 11207724551802 := by decide
theorem cert_e2411631529594 : check e2411631529594 [[],[]] .smaller = true := by decide
def e2411631529782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411631529782 : Closed e2411631529782 ∧ code e2411631529782 = 11207724551990 := by decide
theorem cert_e2411631529782 : check e2411631529782 [[],[]] .smaller = true := by decide
def e2411631529786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411631529786 : Closed e2411631529786 ∧ code e2411631529786 = 11207724551994 := by decide
theorem cert_e2411631529786 : check e2411631529786 [[],[]] .smaller = true := by decide
def e2411631534558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2411631534558 : Closed e2411631534558 ∧ code e2411631534558 = 11207724556766 := by decide
theorem cert_e2411631534558 : check e2411631534558 [[],[]] .smaller = true := by decide
def e2411631534582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2411631534582 : Closed e2411631534582 ∧ code e2411631534582 = 11207724556790 := by decide
theorem cert_e2411631534582 : check e2411631534582 [[],[]] .smaller = true := by decide
def e2411631535534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2411631535534 : Closed e2411631535534 ∧ code e2411631535534 = 11207724557742 := by decide
theorem cert_e2411631535534 : check e2411631535534 [[],[]] .smaller = true := by decide
def e2411631535546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2411631535546 : Closed e2411631535546 ∧ code e2411631535546 = 11207724557754 := by decide
theorem cert_e2411631535546 : check e2411631535546 [[],[]] .smaller = true := by decide
def e2411631535594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2411631535594 : Closed e2411631535594 ∧ code e2411631535594 = 11207724557802 := by decide
theorem cert_e2411631535594 : check e2411631535594 [[],[]] .smaller = true := by decide
def e2411631535726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411631535726 : Closed e2411631535726 ∧ code e2411631535726 = 11207724557934 := by decide
theorem cert_e2411631535726 : check e2411631535726 [[],[]] .smaller = true := by decide
def e2411631535738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411631535738 : Closed e2411631535738 ∧ code e2411631535738 = 11207724557946 := by decide
theorem cert_e2411631535738 : check e2411631535738 [[],[]] .smaller = true := by decide
def e2411631536026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411631536026 : Closed e2411631536026 ∧ code e2411631536026 = 11207724558234 := by decide
theorem cert_e2411631536026 : check e2411631536026 [[],[]] .smaller = true := by decide
def e2411631536094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 3)))))))))
theorem wire_e2411631536094 : Closed e2411631536094 ∧ code e2411631536094 = 11207724558302 := by decide
theorem cert_e2411631536094 : check e2411631536094 [[],[]] .sourceHead = true := by decide
def e2411631538414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2411631538414 : Closed e2411631538414 ∧ code e2411631538414 = 11207724560622 := by decide
theorem cert_e2411631538414 : check e2411631538414 [[],[]] .smaller = true := by decide
def e2411631538422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2411631538422 : Closed e2411631538422 ∧ code e2411631538422 = 11207724560630 := by decide
theorem cert_e2411631538422 : check e2411631538422 [[],[]] .smaller = true := by decide
def e2411631538902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411631538902 : Closed e2411631538902 ∧ code e2411631538902 = 11207724561110 := by decide
theorem cert_e2411631538902 : check e2411631538902 [[],[]] .smaller = true := by decide
def e2411631538906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411631538906 : Closed e2411631538906 ∧ code e2411631538906 = 11207724561114 := by decide
theorem cert_e2411631538906 : check e2411631538906 [[],[]] .smaller = true := by decide
def e2411631538922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411631538922 : Closed e2411631538922 ∧ code e2411631538922 = 11207724561130 := by decide
theorem cert_e2411631538922 : check e2411631538922 [[],[]] .smaller = true := by decide
def e2411631538998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411631538998 : Closed e2411631538998 ∧ code e2411631538998 = 11207724561206 := by decide
theorem cert_e2411631538998 : check e2411631538998 [[],[]] .smaller = true := by decide
def e2411631539002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411631539002 : Closed e2411631539002 ∧ code e2411631539002 = 11207724561210 := by decide
theorem cert_e2411631539002 : check e2411631539002 [[],[]] .smaller = true := by decide
def e2411631539098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411631539098 : Closed e2411631539098 ∧ code e2411631539098 = 11207724561306 := by decide
theorem cert_e2411631539098 : check e2411631539098 [[],[]] .smaller = true := by decide
def e2411631540702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411631540702 : Closed e2411631540702 ∧ code e2411631540702 = 11207724562910 := by decide
theorem cert_e2411631540702 : check e2411631540702 [[],[]] .sourceHead = true := by decide
def e2411631540726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411631540726 : Closed e2411631540726 ∧ code e2411631540726 = 11207724562934 := by decide
theorem cert_e2411631540726 : check e2411631540726 [[],[]] .sourceHead = true := by decide
def e2411631653230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2411631653230 : Closed e2411631653230 ∧ code e2411631653230 = 11207724675438 := by decide
theorem cert_e2411631653230 : check e2411631653230 [[],[]] .chain = true := by decide
def e2411631653238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2411631653238 : Closed e2411631653238 ∧ code e2411631653238 = 11207724675446 := by decide
theorem cert_e2411631653238 : check e2411631653238 [[],[]] .chain = true := by decide
def e2411631653294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2411631653294 : Closed e2411631653294 ∧ code e2411631653294 = 11207724675502 := by decide
theorem cert_e2411631653294 : check e2411631653294 [[],[]] .chain = true := by decide
def e2411631653306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2411631653306 : Closed e2411631653306 ∧ code e2411631653306 = 11207724675514 := by decide
theorem cert_e2411631653306 : check e2411631653306 [[],[]] .chain = true := by decide
def e2411631653354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2411631653354 : Closed e2411631653354 ∧ code e2411631653354 = 11207724675562 := by decide
theorem cert_e2411631653354 : check e2411631653354 [[],[]] .chain = true := by decide
def e2411631653998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411631653998 : Closed e2411631653998 ∧ code e2411631653998 = 11207724676206 := by decide
theorem cert_e2411631653998 : check e2411631653998 [[],[]] .chain = true := by decide
def e2411631654010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411631654010 : Closed e2411631654010 ∧ code e2411631654010 = 11207724676218 := by decide
theorem cert_e2411631654010 : check e2411631654010 [[],[]] .chain = true := by decide
def e2411631654174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411631654174 : Closed e2411631654174 ∧ code e2411631654174 = 11207724676382 := by decide
theorem cert_e2411631654174 : check e2411631654174 [[],[]] .chain = true := by decide
def e2411631654342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411631654342 : Closed e2411631654342 ∧ code e2411631654342 = 11207724676550 := by decide
theorem cert_e2411631654342 : check e2411631654342 [[],[]] .chain = true := by decide
def e2411631654446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2411631654446 : Closed e2411631654446 ∧ code e2411631654446 = 11207724676654 := by decide
theorem cert_e2411631654446 : check e2411631654446 [[],[]] .chain = true := by decide
def e2411631654626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2411631654626 : Closed e2411631654626 ∧ code e2411631654626 = 11207724676834 := by decide
theorem cert_e2411631654626 : check e2411631654626 [[],[]] .chain = true := by decide
def e2411631654638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2411631654638 : Closed e2411631654638 ∧ code e2411631654638 = 11207724676846 := by decide
theorem cert_e2411631654638 : check e2411631654638 [[],[]] .sourceHead = true := by decide
def e2411631654678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411631654678 : Closed e2411631654678 ∧ code e2411631654678 = 11207724676886 := by decide
theorem cert_e2411631654678 : check e2411631654678 [[],[]] .chain = true := by decide
def e2411631654682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411631654682 : Closed e2411631654682 ∧ code e2411631654682 = 11207724676890 := by decide
theorem cert_e2411631654682 : check e2411631654682 [[],[]] .chain = true := by decide
def e2411631654726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411631654726 : Closed e2411631654726 ∧ code e2411631654726 = 11207724676934 := by decide
theorem cert_e2411631654726 : check e2411631654726 [[],[]] .chain = true := by decide
def e2411631654754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411631654754 : Closed e2411631654754 ∧ code e2411631654754 = 11207724676962 := by decide
theorem cert_e2411631654754 : check e2411631654754 [[],[]] .chain = true := by decide
def e2411631654766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2411631654766 : Closed e2411631654766 ∧ code e2411631654766 = 11207724676974 := by decide
theorem cert_e2411631654766 : check e2411631654766 [[],[]] .sourceHead = true := by decide
def e2411631654774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2411631654774 : Closed e2411631654774 ∧ code e2411631654774 = 11207724676982 := by decide
theorem cert_e2411631654774 : check e2411631654774 [[],[]] .sourceHead = true := by decide
end Blc.Floor43
