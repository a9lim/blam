import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262424563554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2262424563554 : Closed e2262424563554 ∧ code e2262424563554 = 11058517585762 := by decide
def e2262424563566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2262424563566 : Closed e2262424563566 ∧ code e2262424563566 = 11058517585774 := by decide
def e2262424563574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2262424563574 : Closed e2262424563574 ∧ code e2262424563574 = 11058517585782 := by decide
def e2262424565822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2262424565822 : Closed e2262424565822 ∧ code e2262424565822 = 11058517588030 := by decide
theorem cert_e2262424565822 : check e2262424565822 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2262424566242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2262424566242 : Closed e2262424566242 ∧ code e2262424566242 = 11058517588450 := by decide
theorem cert_e2262424566242 : check e2262424566242 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2262424566254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262424566254 : Closed e2262424566254 ∧ code e2262424566254 = 11058517588462 := by decide
def e2262424566814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2262424566814 : Closed e2262424566814 ∧ code e2262424566814 = 11058517589022 := by decide
theorem cert_e2262424566814 : check e2262424566814 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424567010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2262424567010 : Closed e2262424567010 ∧ code e2262424567010 = 11058517589218 := by decide
theorem cert_e2262424567010 : check e2262424567010 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left,.left],[.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424567022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262424567022 : Closed e2262424567022 ∧ code e2262424567022 = 11058517589230 := by decide
def e2262424567030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262424567030 : Closed e2262424567030 ∧ code e2262424567030 = 11058517589238 := by decide
def e2262424589870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2262424589870 : Closed e2262424589870 ∧ code e2262424589870 = 11058517612078 := by decide
theorem cert_e2262424589870 : check e2262424589870 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424590050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2262424590050 : Closed e2262424590050 ∧ code e2262424590050 = 11058517612258 := by decide
theorem cert_e2262424590050 : check e2262424590050 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424590062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2262424590062 : Closed e2262424590062 ∧ code e2262424590062 = 11058517612270 := by decide
theorem cert_e2262424590062 : check e2262424590062 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424590218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262424590218 : Closed e2262424590218 ∧ code e2262424590218 = 11058517612426 := by decide
theorem cert_e2262424590218 : check e2262424590218 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424590242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262424590242 : Closed e2262424590242 ∧ code e2262424590242 = 11058517612450 := by decide
theorem cert_e2262424590242 : check e2262424590242 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424590254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2262424590254 : Closed e2262424590254 ∧ code e2262424590254 = 11058517612462 := by decide
theorem cert_e2262424590254 : check e2262424590254 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424590266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2262424590266 : Closed e2262424590266 ∧ code e2262424590266 = 11058517612474 := by decide
private def t_e2262424590266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem cert_e2262424590266 : ¬ IsSelfInterpreter e2262424590266 :=
  wSource (t := t_e2262424590266) (replay_sound (ps := []) (t := e2262424590266) (by decide)) (by decide)
def e2262424590398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2262424590398 : Closed e2262424590398 ∧ code e2262424590398 = 11058517612606 := by decide
theorem cert_e2262424590398 : check e2262424590398 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424590818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2262424590818 : Closed e2262424590818 ∧ code e2262424590818 = 11058517613026 := by decide
theorem cert_e2262424590818 : check e2262424590818 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424590830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262424590830 : Closed e2262424590830 ∧ code e2262424590830 = 11058517613038 := by decide
theorem cert_e2262424590830 : check e2262424590830 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424591886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2262424591886 : Closed e2262424591886 ∧ code e2262424591886 = 11058517614094 := by decide
theorem cert_e2262424591886 : check e2262424591886 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424591970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262424591970 : Closed e2262424591970 ∧ code e2262424591970 = 11058517614178 := by decide
theorem cert_e2262424591970 : check e2262424591970 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424591982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262424591982 : Closed e2262424591982 ∧ code e2262424591982 = 11058517614190 := by decide
theorem cert_e2262424591982 : check e2262424591982 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424591994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262424591994 : Closed e2262424591994 ∧ code e2262424591994 = 11058517614202 := by decide
theorem cert_e2262424591994 : check e2262424591994 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262424603414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2262424603414 : Closed e2262424603414 ∧ code e2262424603414 = 11058517625622 := by decide
theorem cert_e2262424603414 : check e2262424603414 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424603490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2262424603490 : Closed e2262424603490 ∧ code e2262424603490 = 11058517625698 := by decide
theorem cert_e2262424603490 : check e2262424603490 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2262424603502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262424603502 : Closed e2262424603502 ∧ code e2262424603502 = 11058517625710 := by decide
def e2262424603510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262424603510 : Closed e2262424603510 ∧ code e2262424603510 = 11058517625718 := by decide
def e2262424603530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262424603530 : Closed e2262424603530 ∧ code e2262424603530 = 11058517625738 := by decide
theorem cert_e2262424603530 : check e2262424603530 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424603554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262424603554 : Closed e2262424603554 ∧ code e2262424603554 = 11058517625762 := by decide
def e2262424603566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262424603566 : Closed e2262424603566 ∧ code e2262424603566 = 11058517625774 := by decide
def e2262424603578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262424603578 : Closed e2262424603578 ∧ code e2262424603578 = 11058517625786 := by decide
private def t_e2262424603578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e2262424603578 : ¬ IsSelfInterpreter e2262424603578 :=
  wSource (t := t_e2262424603578) (replay_sound (ps := []) (t := e2262424603578) (by decide)) (by decide)
def e2262424603606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262424603606 : Closed e2262424603606 ∧ code e2262424603606 = 11058517625814 := by decide
def e2262424603610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262424603610 : Closed e2262424603610 ∧ code e2262424603610 = 11058517625818 := by decide
private def t_e2262424603610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e2262424603610 : ¬ IsSelfInterpreter e2262424603610 :=
  wSource (t := t_e2262424603610) (replay_sound (ps := []) (t := e2262424603610) (by decide)) (by decide)
def e2262424603678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2262424603678 : Closed e2262424603678 ∧ code e2262424603678 = 11058517625886 := by decide
theorem cert_e2262424603678 : check e2262424603678 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.under],[.under,.under]] .identityHead = true := by decide
def e2262424603874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2262424603874 : Closed e2262424603874 ∧ code e2262424603874 = 11058517626082 := by decide
theorem cert_e2262424603874 : check e2262424603874 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262424603886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262424603886 : Closed e2262424603886 ∧ code e2262424603886 = 11058517626094 := by decide
def e2262424603894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262424603894 : Closed e2262424603894 ∧ code e2262424603894 = 11058517626102 := by decide
def e2262424604174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2262424604174 : Closed e2262424604174 ∧ code e2262424604174 = 11058517626382 := by decide
theorem cert_e2262424604174 : check e2262424604174 [[],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2262424604258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262424604258 : Closed e2262424604258 ∧ code e2262424604258 = 11058517626466 := by decide
theorem cert_e2262424604258 : check e2262424604258 [[],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2262424604270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262424604270 : Closed e2262424604270 ∧ code e2262424604270 = 11058517626478 := by decide
def e2262424604282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262424604282 : Closed e2262424604282 ∧ code e2262424604282 = 11058517626490 := by decide
def e2262424604470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262424604470 : Closed e2262424604470 ∧ code e2262424604470 = 11058517626678 := by decide
def e2262424604474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262424604474 : Closed e2262424604474 ∧ code e2262424604474 = 11058517626682 := by decide
def e2262425144174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262425144174 : Closed e2262425144174 ∧ code e2262425144174 = 11058518166382 := by decide
theorem cert_e2262425144174 : check e2262425144174 [[.left,.left],[.left],[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262425144182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262425144182 : Closed e2262425144182 ∧ code e2262425144182 = 11058518166390 := by decide
theorem cert_e2262425144182 : check e2262425144182 [[.left,.left],[.left],[.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262425144238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262425144238 : Closed e2262425144238 ∧ code e2262425144238 = 11058518166446 := by decide
theorem cert_e2262425144238 : check e2262425144238 [[.left,.left],[.left],[.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2262425144250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262425144250 : Closed e2262425144250 ∧ code e2262425144250 = 11058518166458 := by decide
private def t_e2262425144250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e2262425144250 : ¬ IsSelfInterpreter e2262425144250 :=
  wSource (t := t_e2262425144250) (replay_sound (ps := []) (t := e2262425144250) (by decide)) (by decide)
def e2262425144278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262425144278 : Closed e2262425144278 ∧ code e2262425144278 = 11058518166486 := by decide
theorem cert_e2262425144278 : check e2262425144278 [[],[.under],[.under],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2262425144282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262425144282 : Closed e2262425144282 ∧ code e2262425144282 = 11058518166490 := by decide
private def t_e2262425144282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e2262425144282 : ¬ IsSelfInterpreter e2262425144282 :=
  wSource (t := t_e2262425144282) (replay_sound (ps := []) (t := e2262425144282) (by decide)) (by decide)
def e2262425144558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262425144558 : Closed e2262425144558 ∧ code e2262425144558 = 11058518166766 := by decide
theorem cert_e2262425144558 : check e2262425144558 [[.left,.left],[.left],[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[]] .identityHead = true := by decide
def e2262425144566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262425144566 : Closed e2262425144566 ∧ code e2262425144566 = 11058518166774 := by decide
theorem cert_e2262425144566 : check e2262425144566 [[.left,.left],[.left],[.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2262425144942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262425144942 : Closed e2262425144942 ∧ code e2262425144942 = 11058518167150 := by decide
theorem cert_e2262425144942 : check e2262425144942 [[],[.under],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262425144954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262425144954 : Closed e2262425144954 ∧ code e2262425144954 = 11058518167162 := by decide
theorem cert_e2262425144954 : check e2262425144954 [[],[.under],[.under],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262425145142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262425145142 : Closed e2262425145142 ∧ code e2262425145142 = 11058518167350 := by decide
def e2262425145146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262425145146 : Closed e2262425145146 ∧ code e2262425145146 = 11058518167354 := by decide
theorem cert_e2262425145146 : check e2262425145146 [[],[.under],[.under],[.under],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2262427503470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262427503470 : Closed e2262427503470 ∧ code e2262427503470 = 11058520525678 := by decide
theorem cert_e2262427503470 : check e2262427503470 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427503478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262427503478 : Closed e2262427503478 ∧ code e2262427503478 = 11058520525686 := by decide
theorem cert_e2262427503478 : check e2262427503478 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427503534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262427503534 : Closed e2262427503534 ∧ code e2262427503534 = 11058520525742 := by decide
theorem cert_e2262427503534 : check e2262427503534 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427503546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262427503546 : Closed e2262427503546 ∧ code e2262427503546 = 11058520525754 := by decide
theorem cert_e2262427503546 : check e2262427503546 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427503574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262427503574 : Closed e2262427503574 ∧ code e2262427503574 = 11058520525782 := by decide
theorem cert_e2262427503574 : check e2262427503574 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427503578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262427503578 : Closed e2262427503578 ∧ code e2262427503578 = 11058520525786 := by decide
theorem cert_e2262427503578 : check e2262427503578 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427503854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262427503854 : Closed e2262427503854 ∧ code e2262427503854 = 11058520526062 := by decide
theorem cert_e2262427503854 : check e2262427503854 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427503862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262427503862 : Closed e2262427503862 ∧ code e2262427503862 = 11058520526070 := by decide
theorem cert_e2262427503862 : check e2262427503862 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427504238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262427504238 : Closed e2262427504238 ∧ code e2262427504238 = 11058520526446 := by decide
theorem cert_e2262427504238 : check e2262427504238 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427504250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262427504250 : Closed e2262427504250 ∧ code e2262427504250 = 11058520526458 := by decide
theorem cert_e2262427504250 : check e2262427504250 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427504438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262427504438 : Closed e2262427504438 ∧ code e2262427504438 = 11058520526646 := by decide
theorem cert_e2262427504438 : check e2262427504438 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262427504442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262427504442 : Closed e2262427504442 ∧ code e2262427504442 = 11058520526650 := by decide
theorem cert_e2262427504442 : check e2262427504442 [[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2262521875310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262521875310 : Closed e2262521875310 ∧ code e2262521875310 = 11058614897518 := by decide
theorem cert_e2262521875310 : check e2262521875310 [[],[.under,.left]] .chain = true := by decide
def e2262521875318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262521875318 : Closed e2262521875318 ∧ code e2262521875318 = 11058614897526 := by decide
theorem cert_e2262521875318 : check e2262521875318 [[],[.under,.left]] .chain = true := by decide
def e2262521875374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262521875374 : Closed e2262521875374 ∧ code e2262521875374 = 11058614897582 := by decide
theorem cert_e2262521875374 : check e2262521875374 [[],[.under,.left]] .chain = true := by decide
def e2262521875386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262521875386 : Closed e2262521875386 ∧ code e2262521875386 = 11058614897594 := by decide
theorem cert_e2262521875386 : check e2262521875386 [[],[.under,.left]] .chain = true := by decide
def e2262521875414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262521875414 : Closed e2262521875414 ∧ code e2262521875414 = 11058614897622 := by decide
theorem cert_e2262521875414 : check e2262521875414 [[],[.under,.left]] .chain = true := by decide
def e2262521875418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262521875418 : Closed e2262521875418 ∧ code e2262521875418 = 11058614897626 := by decide
theorem cert_e2262521875418 : check e2262521875418 [[],[.under,.left]] .chain = true := by decide
def e2262521875694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262521875694 : Closed e2262521875694 ∧ code e2262521875694 = 11058614897902 := by decide
theorem cert_e2262521875694 : check e2262521875694 [[],[.under,.left]] .chain = true := by decide
def e2262521875702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262521875702 : Closed e2262521875702 ∧ code e2262521875702 = 11058614897910 := by decide
theorem cert_e2262521875702 : check e2262521875702 [[],[.under,.left]] .chain = true := by decide
def e2262521876078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262521876078 : Closed e2262521876078 ∧ code e2262521876078 = 11058614898286 := by decide
theorem cert_e2262521876078 : check e2262521876078 [[],[.under,.left]] .chain = true := by decide
def e2262521876090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262521876090 : Closed e2262521876090 ∧ code e2262521876090 = 11058614898298 := by decide
theorem cert_e2262521876090 : check e2262521876090 [[],[.under,.left]] .chain = true := by decide
def e2262521876278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262521876278 : Closed e2262521876278 ∧ code e2262521876278 = 11058614898486 := by decide
theorem cert_e2262521876278 : check e2262521876278 [[],[.under,.left]] .chain = true := by decide
def e2262521876282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262521876282 : Closed e2262521876282 ∧ code e2262521876282 = 11058614898490 := by decide
theorem cert_e2262521876282 : check e2262521876282 [[],[.under,.left]] .chain = true := by decide
def e2349395057178 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349395057178 : Closed e2349395057178 ∧ code e2349395057178 = 11145488079386 := by decide
theorem cert_e2349395057178 : check e2349395057178 [[],[]] .width = true := by decide
def e2349395188250 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349395188250 : Closed e2349395188250 ∧ code e2349395188250 = 11145488210458 := by decide
theorem cert_e2349395188250 : check e2349395188250 [[],[]] .width = true := by decide
def e2349396105754 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349396105754 : Closed e2349396105754 ∧ code e2349396105754 = 11145489127962 := by decide
theorem cert_e2349396105754 : check e2349396105754 [[],[]] .width = true := by decide
def e2349396302362 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349396302362 : Closed e2349396302362 ∧ code e2349396302362 = 11145489324570 := by decide
private def t_e2349396302362 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2349396302362 : ¬ IsSelfInterpreter e2349396302362 :=
  wSource (t := t_e2349396302362) (replay_sound (ps := []) (t := e2349396302362) (by decide)) (by decide)
def e2349396761114 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349396761114 : Closed e2349396761114 ∧ code e2349396761114 = 11145489783322 := by decide
theorem cert_e2349396761114 : check e2349396761114 [[],[]] .width = true := by decide
def e2349396826650 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349396826650 : Closed e2349396826650 ∧ code e2349396826650 = 11145489848858 := by decide
private def t_e2349396826650 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2349396826650 : ¬ IsSelfInterpreter e2349396826650 :=
  wSource (t := t_e2349396826650) (replay_sound (ps := []) (t := e2349396826650) (by decide)) (by decide)
def e2349401348634 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349401348634 : Closed e2349401348634 ∧ code e2349401348634 = 11145494370842 := by decide
theorem cert_e2349401348634 : check e2349401348634 [[],[]] .width = true := by decide
def e2349401479706 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349401479706 : Closed e2349401479706 ∧ code e2349401479706 = 11145494501914 := by decide
theorem cert_e2349401479706 : check e2349401479706 [[],[]] .width = true := by decide
def e2349407640090 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349407640090 : Closed e2349407640090 ∧ code e2349407640090 = 11145500662298 := by decide
theorem cert_e2349407640090 : check e2349407640090 [[],[]] .width = true := by decide
def e2349407836698 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349407836698 : Closed e2349407836698 ∧ code e2349407836698 = 11145500858906 := by decide
theorem cert_e2349407836698 : check e2349407836698 [[],[]] .width = true := by decide
def e2349410916890 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349410916890 : Closed e2349410916890 ∧ code e2349410916890 = 11145503939098 := by decide
theorem cert_e2349410916890 : check e2349410916890 [[],[]] .width = true := by decide
def e2349410982426 : Term := (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2349410982426 : Closed e2349410982426 ∧ code e2349410982426 = 11145504004634 := by decide
theorem cert_e2349410982426 : check e2349410982426 [[],[]] .width = true := by decide
def e2383718836762 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383718836762 : Closed e2383718836762 ∧ code e2383718836762 = 11179811858970 := by decide
private def t_e2383718836762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2383718836762 : ¬ IsSelfInterpreter e2383718836762 :=
  wSource (t := t_e2383718836762) (replay_sound (ps := [[],[.left,.left],[.left,.left],[.left]]) (t := e2383718836762) (by decide)) (by decide)
def e2383718869530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383718869530 : Closed e2383718869530 ∧ code e2383718869530 = 11179811891738 := by decide
theorem cert_e2383718869530 : check e2383718869530 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383719098906 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383719098906 : Closed e2383719098906 ∧ code e2383719098906 = 11179812121114 := by decide
private def t_e2383719098906 : Term := (.app (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2383719098906 : ¬ IsSelfInterpreter e2383719098906 :=
  wSource (t := t_e2383719098906) (replay_sound (ps := [[],[.left,.left],[.left,.left],[.left]]) (t := e2383719098906) (by decide)) (by decide)
def e2383719148058 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383719148058 : Closed e2383719148058 ∧ code e2383719148058 = 11179812170266 := by decide
theorem cert_e2383719148058 : check e2383719148058 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383719262746 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383719262746 : Closed e2383719262746 ∧ code e2383719262746 = 11179812284954 := by decide
theorem cert_e2383719262746 : check e2383719262746 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383719279130 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383719279130 : Closed e2383719279130 ∧ code e2383719279130 = 11179812301338 := by decide
theorem cert_e2383719279130 : check e2383719279130 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383720409626 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383720409626 : Closed e2383720409626 ∧ code e2383720409626 = 11179813431834 := by decide
theorem cert_e2383720409626 : check e2383720409626 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383720442394 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383720442394 : Closed e2383720442394 ∧ code e2383720442394 = 11179813464602 := by decide
theorem cert_e2383720442394 : check e2383720442394 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383721982490 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383721982490 : Closed e2383721982490 ∧ code e2383721982490 = 11179815004698 := by decide
theorem cert_e2383721982490 : check e2383721982490 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383722031642 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383722031642 : Closed e2383722031642 ∧ code e2383722031642 = 11179815053850 := by decide
theorem cert_e2383722031642 : check e2383722031642 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383722801690 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383722801690 : Closed e2383722801690 ∧ code e2383722801690 = 11179815823898 := by decide
theorem cert_e2383722801690 : check e2383722801690 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383722818074 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383722818074 : Closed e2383722818074 ∧ code e2383722818074 = 11179815840282 := by decide
theorem cert_e2383722818074 : check e2383722818074 [[],[.left,.left],[.left,.left],[.left],[]] .smaller = true := by decide
def e2383754791450 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383754791450 : Closed e2383754791450 ∧ code e2383754791450 = 11179847813658 := by decide
theorem cert_e2383754791450 : check e2383754791450 [[]] .width = true := by decide
def e2383754797594 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383754797594 : Closed e2383754797594 ∧ code e2383754797594 = 11179847819802 := by decide
theorem cert_e2383754797594 : check e2383754797594 [[]] .width = true := by decide
def e2383754799130 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383754799130 : Closed e2383754799130 ∧ code e2383754799130 = 11179847821338 := by decide
theorem cert_e2383754799130 : check e2383754799130 [[]] .width = true := by decide
def e2383754922522 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383754922522 : Closed e2383754922522 ∧ code e2383754922522 = 11179847944730 := by decide
theorem cert_e2383754922522 : check e2383754922522 [[]] .width = true := by decide
def e2383754928666 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383754928666 : Closed e2383754928666 ∧ code e2383754928666 = 11179847950874 := by decide
theorem cert_e2383754928666 : check e2383754928666 [[]] .width = true := by decide
def e2383754930202 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383754930202 : Closed e2383754930202 ∧ code e2383754930202 = 11179847952410 := by decide
theorem cert_e2383754930202 : check e2383754930202 [[]] .width = true := by decide
def e2383755840026 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383755840026 : Closed e2383755840026 ∧ code e2383755840026 = 11179848862234 := by decide
theorem cert_e2383755840026 : check e2383755840026 [[]] .width = true := by decide
def e2383755846170 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383755846170 : Closed e2383755846170 ∧ code e2383755846170 = 11179848868378 := by decide
theorem cert_e2383755846170 : check e2383755846170 [[]] .width = true := by decide
def e2383755847706 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383755847706 : Closed e2383755847706 ∧ code e2383755847706 = 11179848869914 := by decide
theorem cert_e2383755847706 : check e2383755847706 [[]] .width = true := by decide
def e2383756036634 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383756036634 : Closed e2383756036634 ∧ code e2383756036634 = 11179849058842 := by decide
private def t_e2383756036634 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2383756036634 : ¬ IsSelfInterpreter e2383756036634 :=
  wSource (t := t_e2383756036634) (replay_sound (ps := []) (t := e2383756036634) (by decide)) (by decide)
def e2383756042778 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383756042778 : Closed e2383756042778 ∧ code e2383756042778 = 11179849064986 := by decide
private def t_e2383756042778 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2383756042778 : ¬ IsSelfInterpreter e2383756042778 :=
  wSource (t := t_e2383756042778) (replay_sound (ps := []) (t := e2383756042778) (by decide)) (by decide)
def e2383756044314 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383756044314 : Closed e2383756044314 ∧ code e2383756044314 = 11179849066522 := by decide
theorem cert_e2383756044314 : check e2383756044314 [[]] .width = true := by decide
def e2383756495386 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383756495386 : Closed e2383756495386 ∧ code e2383756495386 = 11179849517594 := by decide
theorem cert_e2383756495386 : check e2383756495386 [[]] .width = true := by decide
def e2383756501530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383756501530 : Closed e2383756501530 ∧ code e2383756501530 = 11179849523738 := by decide
theorem cert_e2383756501530 : check e2383756501530 [[]] .width = true := by decide
def e2383756503066 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383756503066 : Closed e2383756503066 ∧ code e2383756503066 = 11179849525274 := by decide
theorem cert_e2383756503066 : check e2383756503066 [[]] .width = true := by decide
def e2383756560922 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383756560922 : Closed e2383756560922 ∧ code e2383756560922 = 11179849583130 := by decide
private def t_e2383756560922 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2383756560922 : ¬ IsSelfInterpreter e2383756560922 :=
  wSource (t := t_e2383756560922) (replay_sound (ps := []) (t := e2383756560922) (by decide)) (by decide)
def e2383756567066 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383756567066 : Closed e2383756567066 ∧ code e2383756567066 = 11179849589274 := by decide
private def t_e2383756567066 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2383756567066 : ¬ IsSelfInterpreter e2383756567066 :=
  wSource (t := t_e2383756567066) (replay_sound (ps := []) (t := e2383756567066) (by decide)) (by decide)
def e2383756568602 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383756568602 : Closed e2383756568602 ∧ code e2383756568602 = 11179849590810 := by decide
theorem cert_e2383756568602 : check e2383756568602 [[]] .width = true := by decide
def e2383761082906 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383761082906 : Closed e2383761082906 ∧ code e2383761082906 = 11179854105114 := by decide
theorem cert_e2383761082906 : check e2383761082906 [[]] .width = true := by decide
def e2383761089050 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383761089050 : Closed e2383761089050 ∧ code e2383761089050 = 11179854111258 := by decide
theorem cert_e2383761089050 : check e2383761089050 [[]] .width = true := by decide
def e2383761090586 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383761090586 : Closed e2383761090586 ∧ code e2383761090586 = 11179854112794 := by decide
theorem cert_e2383761090586 : check e2383761090586 [[]] .width = true := by decide
def e2383761213978 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383761213978 : Closed e2383761213978 ∧ code e2383761213978 = 11179854236186 := by decide
theorem cert_e2383761213978 : check e2383761213978 [[]] .width = true := by decide
def e2383761220122 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383761220122 : Closed e2383761220122 ∧ code e2383761220122 = 11179854242330 := by decide
theorem cert_e2383761220122 : check e2383761220122 [[]] .width = true := by decide
def e2383761221658 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383761221658 : Closed e2383761221658 ∧ code e2383761221658 = 11179854243866 := by decide
theorem cert_e2383761221658 : check e2383761221658 [[]] .width = true := by decide
def e2383767374362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383767374362 : Closed e2383767374362 ∧ code e2383767374362 = 11179860396570 := by decide
theorem cert_e2383767374362 : check e2383767374362 [[]] .width = true := by decide
def e2383767380506 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383767380506 : Closed e2383767380506 ∧ code e2383767380506 = 11179860402714 := by decide
theorem cert_e2383767380506 : check e2383767380506 [[]] .width = true := by decide
def e2383767382042 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383767382042 : Closed e2383767382042 ∧ code e2383767382042 = 11179860404250 := by decide
theorem cert_e2383767382042 : check e2383767382042 [[]] .width = true := by decide
def e2383767570970 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383767570970 : Closed e2383767570970 ∧ code e2383767570970 = 11179860593178 := by decide
theorem cert_e2383767570970 : check e2383767570970 [[]] .width = true := by decide
def e2383767577114 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383767577114 : Closed e2383767577114 ∧ code e2383767577114 = 11179860599322 := by decide
theorem cert_e2383767577114 : check e2383767577114 [[]] .width = true := by decide
def e2383767578650 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383767578650 : Closed e2383767578650 ∧ code e2383767578650 = 11179860600858 := by decide
theorem cert_e2383767578650 : check e2383767578650 [[]] .width = true := by decide
def e2383770651162 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383770651162 : Closed e2383770651162 ∧ code e2383770651162 = 11179863673370 := by decide
theorem cert_e2383770651162 : check e2383770651162 [[]] .width = true := by decide
def e2383770657306 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383770657306 : Closed e2383770657306 ∧ code e2383770657306 = 11179863679514 := by decide
theorem cert_e2383770657306 : check e2383770657306 [[]] .width = true := by decide
def e2383770658842 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383770658842 : Closed e2383770658842 ∧ code e2383770658842 = 11179863681050 := by decide
theorem cert_e2383770658842 : check e2383770658842 [[]] .width = true := by decide
def e2383770716698 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383770716698 : Closed e2383770716698 ∧ code e2383770716698 = 11179863738906 := by decide
theorem cert_e2383770716698 : check e2383770716698 [[]] .width = true := by decide
def e2383770722842 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383770722842 : Closed e2383770722842 ∧ code e2383770722842 = 11179863745050 := by decide
theorem cert_e2383770722842 : check e2383770722842 [[]] .width = true := by decide
def e2383770724378 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2383770724378 : Closed e2383770724378 ∧ code e2383770724378 = 11179863746586 := by decide
theorem cert_e2383770724378 : check e2383770724378 [[]] .width = true := by decide
def e2383978281498 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383978281498 : Closed e2383978281498 ∧ code e2383978281498 = 11180071303706 := by decide
theorem cert_e2383978281498 : check e2383978281498 [[]] .width = true := by decide
def e2383978289690 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383978289690 : Closed e2383978289690 ∧ code e2383978289690 = 11180071311898 := by decide
theorem cert_e2383978289690 : check e2383978289690 [[]] .width = true := by decide
def e2383978347034 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383978347034 : Closed e2383978347034 ∧ code e2383978347034 = 11180071369242 := by decide
theorem cert_e2383978347034 : check e2383978347034 [[]] .width = true := by decide
def e2383978359322 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383978359322 : Closed e2383978359322 ∧ code e2383978359322 = 11180071381530 := by decide
theorem cert_e2383978359322 : check e2383978359322 [[]] .width = true := by decide
def e2383978387994 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383978387994 : Closed e2383978387994 ∧ code e2383978387994 = 11180071410202 := by decide
theorem cert_e2383978387994 : check e2383978387994 [[]] .width = true := by decide
def e2383978392090 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383978392090 : Closed e2383978392090 ∧ code e2383978392090 = 11180071414298 := by decide
theorem cert_e2383978392090 : check e2383978392090 [[]] .width = true := by decide
def e2383978674714 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383978674714 : Closed e2383978674714 ∧ code e2383978674714 = 11180071696922 := by decide
theorem cert_e2383978674714 : check e2383978674714 [[]] .width = true := by decide
def e2383978682906 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383978682906 : Closed e2383978682906 ∧ code e2383978682906 = 11180071705114 := by decide
theorem cert_e2383978682906 : check e2383978682906 [[]] .width = true := by decide
def e2383979067930 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383979067930 : Closed e2383979067930 ∧ code e2383979067930 = 11180072090138 := by decide
theorem cert_e2383979067930 : check e2383979067930 [[]] .width = true := by decide
def e2383979080218 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383979080218 : Closed e2383979080218 ∧ code e2383979080218 = 11180072102426 := by decide
theorem cert_e2383979080218 : check e2383979080218 [[]] .width = true := by decide
def e2383979272730 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383979272730 : Closed e2383979272730 ∧ code e2383979272730 = 11180072294938 := by decide
theorem cert_e2383979272730 : check e2383979272730 [[]] .width = true := by decide
def e2383979276826 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2383979276826 : Closed e2383979276826 ∧ code e2383979276826 = 11180072299034 := by decide
theorem cert_e2383979276826 : check e2383979276826 [[]] .width = true := by decide
def e2384043142682 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043142682 : Closed e2384043142682 ∧ code e2384043142682 = 11180136164890 := by decide
theorem cert_e2384043142682 : check e2384043142682 [[]] .width = true := by decide
def e2384043144730 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043144730 : Closed e2384043144730 ∧ code e2384043144730 = 11180136166938 := by decide
theorem cert_e2384043144730 : check e2384043144730 [[]] .width = true := by decide
def e2384043159066 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043159066 : Closed e2384043159066 ∧ code e2384043159066 = 11180136181274 := by decide
theorem cert_e2384043159066 : check e2384043159066 [[]] .width = true := by decide
def e2384043162138 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043162138 : Closed e2384043162138 ∧ code e2384043162138 = 11180136184346 := by decide
theorem cert_e2384043162138 : check e2384043162138 [[]] .width = true := by decide
def e2384043169306 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043169306 : Closed e2384043169306 ∧ code e2384043169306 = 11180136191514 := by decide
theorem cert_e2384043169306 : check e2384043169306 [[]] .width = true := by decide
def e2384043170330 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043170330 : Closed e2384043170330 ∧ code e2384043170330 = 11180136192538 := by decide
theorem cert_e2384043170330 : check e2384043170330 [[]] .width = true := by decide
def e2384043240986 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043240986 : Closed e2384043240986 ∧ code e2384043240986 = 11180136263194 := by decide
theorem cert_e2384043240986 : check e2384043240986 [[]] .width = true := by decide
def e2384043243034 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043243034 : Closed e2384043243034 ∧ code e2384043243034 = 11180136265242 := by decide
theorem cert_e2384043243034 : check e2384043243034 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262424590266
#print axioms Blc.Floor43.cert_e2262424603578
#print axioms Blc.Floor43.cert_e2262424603610
#print axioms Blc.Floor43.cert_e2262425144250
#print axioms Blc.Floor43.cert_e2262425144282
#print axioms Blc.Floor43.cert_e2349396302362
#print axioms Blc.Floor43.cert_e2349396826650
#print axioms Blc.Floor43.cert_e2383718836762
#print axioms Blc.Floor43.cert_e2383719098906
#print axioms Blc.Floor43.cert_e2383756036634
#print axioms Blc.Floor43.cert_e2383756042778
#print axioms Blc.Floor43.cert_e2383756560922
#print axioms Blc.Floor43.cert_e2383756567066
