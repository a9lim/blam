import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2260092413914 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2260092413914 : Closed e2260092413914 ∧ code e2260092413914 = 11056185436122 := by decide
theorem cert_e2260092413914 : check e2260092413914 [[],[.under]] .three = true := by decide
def e2260092414430 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2260092414430 : Closed e2260092414430 ∧ code e2260092414430 = 11056185436638 := by decide
theorem cert_e2260092414430 : check e2260092414430 [[],[.under]] .three = true := by decide
def e2260092414454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2260092414454 : Closed e2260092414454 ∧ code e2260092414454 = 11056185436662 := by decide
theorem cert_e2260092414454 : check e2260092414454 [[],[.under]] .three = true := by decide
def e2260092415198 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2260092415198 : Closed e2260092415198 ∧ code e2260092415198 = 11056185437406 := by decide
theorem cert_e2260092415198 : check e2260092415198 [[],[.under]] .three = true := by decide
def e2260092415214 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2260092415214 : Closed e2260092415214 ∧ code e2260092415214 = 11056185437422 := by decide
theorem cert_e2260092415214 : check e2260092415214 [[],[.under]] .smaller = true := by decide
def e2260092415222 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2260092415222 : Closed e2260092415222 ∧ code e2260092415222 = 11056185437430 := by decide
theorem cert_e2260092415222 : check e2260092415222 [[],[.under]] .smaller = true := by decide
def e2260092415226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2260092415226 : Closed e2260092415226 ∧ code e2260092415226 = 11056185437434 := by decide
theorem cert_e2260092415226 : check e2260092415226 [[],[.under]] .three = true := by decide
def e2260092415606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2260092415606 : Closed e2260092415606 ∧ code e2260092415606 = 11056185437814 := by decide
theorem cert_e2260092415606 : check e2260092415606 [[],[.under]] .smaller = true := by decide
def e2260092415798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2260092415798 : Closed e2260092415798 ∧ code e2260092415798 = 11056185438006 := by decide
theorem cert_e2260092415798 : check e2260092415798 [[],[.under]] .three = true := by decide
def e2260092415802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2260092415802 : Closed e2260092415802 ∧ code e2260092415802 = 11056185438010 := by decide
theorem cert_e2260092415802 : check e2260092415802 [[],[.under]] .three = true := by decide
def e2260092416862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2260092416862 : Closed e2260092416862 ∧ code e2260092416862 = 11056185439070 := by decide
theorem cert_e2260092416862 : check e2260092416862 [[],[.under]] .three = true := by decide
def e2260092416878 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2260092416878 : Closed e2260092416878 ∧ code e2260092416878 = 11056185439086 := by decide
theorem cert_e2260092416878 : check e2260092416878 [[],[.under]] .smaller = true := by decide
def e2260092416886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2260092416886 : Closed e2260092416886 ∧ code e2260092416886 = 11056185439094 := by decide
theorem cert_e2260092416886 : check e2260092416886 [[],[.under]] .smaller = true := by decide
def e2260092416890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2260092416890 : Closed e2260092416890 ∧ code e2260092416890 = 11056185439098 := by decide
theorem cert_e2260092416890 : check e2260092416890 [[],[.under]] .three = true := by decide
def e2260092416942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2260092416942 : Closed e2260092416942 ∧ code e2260092416942 = 11056185439150 := by decide
theorem cert_e2260092416942 : check e2260092416942 [[],[.under]] .smaller = true := by decide
def e2260092416954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2260092416954 : Closed e2260092416954 ∧ code e2260092416954 = 11056185439162 := by decide
theorem cert_e2260092416954 : check e2260092416954 [[],[.under]] .smaller = true := by decide
def e2260092416982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2260092416982 : Closed e2260092416982 ∧ code e2260092416982 = 11056185439190 := by decide
theorem cert_e2260092416982 : check e2260092416982 [[],[.under]] .smaller = true := by decide
def e2260092416986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2260092416986 : Closed e2260092416986 ∧ code e2260092416986 = 11056185439194 := by decide
theorem cert_e2260092416986 : check e2260092416986 [[],[.under]] .smaller = true := by decide
def e2260092417002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2260092417002 : Closed e2260092417002 ∧ code e2260092417002 = 11056185439210 := by decide
theorem cert_e2260092417002 : check e2260092417002 [[],[.under]] .three = true := by decide
def e2260092417246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2260092417246 : Closed e2260092417246 ∧ code e2260092417246 = 11056185439454 := by decide
theorem cert_e2260092417246 : check e2260092417246 [[],[.under]] .three = true := by decide
def e2260092417262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2260092417262 : Closed e2260092417262 ∧ code e2260092417262 = 11056185439470 := by decide
theorem cert_e2260092417262 : check e2260092417262 [[],[.under]] .smaller = true := by decide
def e2260092417270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2260092417270 : Closed e2260092417270 ∧ code e2260092417270 = 11056185439478 := by decide
theorem cert_e2260092417270 : check e2260092417270 [[],[.under]] .smaller = true := by decide
def e2260092417274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2260092417274 : Closed e2260092417274 ∧ code e2260092417274 = 11056185439482 := by decide
theorem cert_e2260092417274 : check e2260092417274 [[],[.under]] .three = true := by decide
def e2260092417646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2260092417646 : Closed e2260092417646 ∧ code e2260092417646 = 11056185439854 := by decide
theorem cert_e2260092417646 : check e2260092417646 [[],[.under]] .smaller = true := by decide
def e2260092417658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2260092417658 : Closed e2260092417658 ∧ code e2260092417658 = 11056185439866 := by decide
theorem cert_e2260092417658 : check e2260092417658 [[],[.under]] .smaller = true := by decide
def e2260092417846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2260092417846 : Closed e2260092417846 ∧ code e2260092417846 = 11056185440054 := by decide
theorem cert_e2260092417846 : check e2260092417846 [[],[.under]] .smaller = true := by decide
def e2260092417850 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2260092417850 : Closed e2260092417850 ∧ code e2260092417850 = 11056185440058 := by decide
theorem cert_e2260092417850 : check e2260092417850 [[],[.under]] .smaller = true := by decide
def e2260092417946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2260092417946 : Closed e2260092417946 ∧ code e2260092417946 = 11056185440154 := by decide
theorem cert_e2260092417946 : check e2260092417946 [[],[.under]] .three = true := by decide
def e2260092418486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2260092418486 : Closed e2260092418486 ∧ code e2260092418486 = 11056185440694 := by decide
theorem cert_e2260092418486 : check e2260092418486 [[],[.under]] .smaller = true := by decide
def e2260092418518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2260092418518 : Closed e2260092418518 ∧ code e2260092418518 = 11056185440726 := by decide
theorem cert_e2260092418518 : check e2260092418518 [[],[.under]] .smaller = true := by decide
def e2260092418522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2260092418522 : Closed e2260092418522 ∧ code e2260092418522 = 11056185440730 := by decide
theorem cert_e2260092418522 : check e2260092418522 [[],[.under]] .smaller = true := by decide
def e2260092418678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2260092418678 : Closed e2260092418678 ∧ code e2260092418678 = 11056185440886 := by decide
theorem cert_e2260092418678 : check e2260092418678 [[],[.under]] .smaller = true := by decide
def e2260092418870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2260092418870 : Closed e2260092418870 ∧ code e2260092418870 = 11056185441078 := by decide
theorem cert_e2260092418870 : check e2260092418870 [[],[.under]] .smaller = true := by decide
def e2260092418874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2260092418874 : Closed e2260092418874 ∧ code e2260092418874 = 11056185441082 := by decide
theorem cert_e2260092418874 : check e2260092418874 [[],[.under]] .smaller = true := by decide
def e2260092419286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2260092419286 : Closed e2260092419286 ∧ code e2260092419286 = 11056185441494 := by decide
theorem cert_e2260092419286 : check e2260092419286 [[],[.under]] .three = true := by decide
def e2260092419290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2260092419290 : Closed e2260092419290 ∧ code e2260092419290 = 11056185441498 := by decide
theorem cert_e2260092419290 : check e2260092419290 [[],[.under]] .three = true := by decide
def e2260092419306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2260092419306 : Closed e2260092419306 ∧ code e2260092419306 = 11056185441514 := by decide
theorem cert_e2260092419306 : check e2260092419306 [[],[.under]] .three = true := by decide
def e2260092419382 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2260092419382 : Closed e2260092419382 ∧ code e2260092419382 = 11056185441590 := by decide
theorem cert_e2260092419382 : check e2260092419382 [[],[.under]] .three = true := by decide
def e2260092419386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2260092419386 : Closed e2260092419386 ∧ code e2260092419386 = 11056185441594 := by decide
theorem cert_e2260092419386 : check e2260092419386 [[],[.under]] .three = true := by decide
def e2260092419482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2260092419482 : Closed e2260092419482 ∧ code e2260092419482 = 11056185441690 := by decide
theorem cert_e2260092419482 : check e2260092419482 [[],[.under]] .three = true := by decide
def e2260092425950 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2260092425950 : Closed e2260092425950 ∧ code e2260092425950 = 11056185448158 := by decide
theorem cert_e2260092425950 : check e2260092425950 [[],[.under]] .three = true := by decide
def e2260092425974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2260092425974 : Closed e2260092425974 ∧ code e2260092425974 = 11056185448182 := by decide
theorem cert_e2260092425974 : check e2260092425974 [[],[.under]] .three = true := by decide
def e2260092426078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2260092426078 : Closed e2260092426078 ∧ code e2260092426078 = 11056185448286 := by decide
theorem cert_e2260092426078 : check e2260092426078 [[],[.under]] .three = true := by decide
def e2260092426094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2260092426094 : Closed e2260092426094 ∧ code e2260092426094 = 11056185448302 := by decide
theorem cert_e2260092426094 : check e2260092426094 [[],[.under]] .smaller = true := by decide
def e2260092426102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2260092426102 : Closed e2260092426102 ∧ code e2260092426102 = 11056185448310 := by decide
theorem cert_e2260092426102 : check e2260092426102 [[],[.under]] .smaller = true := by decide
def e2260092426106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2260092426106 : Closed e2260092426106 ∧ code e2260092426106 = 11056185448314 := by decide
theorem cert_e2260092426106 : check e2260092426106 [[],[.under]] .three = true := by decide
def e2260092426166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2260092426166 : Closed e2260092426166 ∧ code e2260092426166 = 11056185448374 := by decide
theorem cert_e2260092426166 : check e2260092426166 [[],[.under]] .smaller = true := by decide
def e2260092426198 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2260092426198 : Closed e2260092426198 ∧ code e2260092426198 = 11056185448406 := by decide
theorem cert_e2260092426198 : check e2260092426198 [[],[.under]] .three = true := by decide
def e2260092426202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2260092426202 : Closed e2260092426202 ∧ code e2260092426202 = 11056185448410 := by decide
theorem cert_e2260092426202 : check e2260092426202 [[],[.under]] .three = true := by decide
def e2260092426718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2260092426718 : Closed e2260092426718 ∧ code e2260092426718 = 11056185448926 := by decide
theorem cert_e2260092426718 : check e2260092426718 [[],[.under]] .three = true := by decide
def e2260092426742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2260092426742 : Closed e2260092426742 ∧ code e2260092426742 = 11056185448950 := by decide
theorem cert_e2260092426742 : check e2260092426742 [[],[.under]] .three = true := by decide
def e2260092427486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2260092427486 : Closed e2260092427486 ∧ code e2260092427486 = 11056185449694 := by decide
theorem cert_e2260092427486 : check e2260092427486 [[],[.under]] .three = true := by decide
def e2260092427502 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2260092427502 : Closed e2260092427502 ∧ code e2260092427502 = 11056185449710 := by decide
theorem cert_e2260092427502 : check e2260092427502 [[],[.under]] .smaller = true := by decide
def e2260092427510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2260092427510 : Closed e2260092427510 ∧ code e2260092427510 = 11056185449718 := by decide
theorem cert_e2260092427510 : check e2260092427510 [[],[.under]] .smaller = true := by decide
def e2260092427514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2260092427514 : Closed e2260092427514 ∧ code e2260092427514 = 11056185449722 := by decide
theorem cert_e2260092427514 : check e2260092427514 [[],[.under]] .three = true := by decide
def e2260092427894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2260092427894 : Closed e2260092427894 ∧ code e2260092427894 = 11056185450102 := by decide
theorem cert_e2260092427894 : check e2260092427894 [[],[.under]] .smaller = true := by decide
def e2260092428086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260092428086 : Closed e2260092428086 ∧ code e2260092428086 = 11056185450294 := by decide
theorem cert_e2260092428086 : check e2260092428086 [[],[.under]] .three = true := by decide
def e2260092428090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260092428090 : Closed e2260092428090 ∧ code e2260092428090 = 11056185450298 := by decide
theorem cert_e2260092428090 : check e2260092428090 [[],[.under]] .three = true := by decide
def e2260092439390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2260092439390 : Closed e2260092439390 ∧ code e2260092439390 = 11056185461598 := by decide
theorem cert_e2260092439390 : check e2260092439390 [[],[.under]] .three = true := by decide
def e2260092439406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2260092439406 : Closed e2260092439406 ∧ code e2260092439406 = 11056185461614 := by decide
theorem cert_e2260092439406 : check e2260092439406 [[],[.under]] .smaller = true := by decide
def e2260092439414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2260092439414 : Closed e2260092439414 ∧ code e2260092439414 = 11056185461622 := by decide
theorem cert_e2260092439414 : check e2260092439414 [[],[.under]] .smaller = true := by decide
def e2260092439418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2260092439418 : Closed e2260092439418 ∧ code e2260092439418 = 11056185461626 := by decide
theorem cert_e2260092439418 : check e2260092439418 [[],[.under]] .three = true := by decide
def e2260092439470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2260092439470 : Closed e2260092439470 ∧ code e2260092439470 = 11056185461678 := by decide
theorem cert_e2260092439470 : check e2260092439470 [[],[.under]] .smaller = true := by decide
def e2260092439482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2260092439482 : Closed e2260092439482 ∧ code e2260092439482 = 11056185461690 := by decide
theorem cert_e2260092439482 : check e2260092439482 [[],[.under]] .smaller = true := by decide
def e2260092439510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2260092439510 : Closed e2260092439510 ∧ code e2260092439510 = 11056185461718 := by decide
theorem cert_e2260092439510 : check e2260092439510 [[],[.under]] .smaller = true := by decide
def e2260092439514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2260092439514 : Closed e2260092439514 ∧ code e2260092439514 = 11056185461722 := by decide
theorem cert_e2260092439514 : check e2260092439514 [[],[.under]] .smaller = true := by decide
def e2260092439530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2260092439530 : Closed e2260092439530 ∧ code e2260092439530 = 11056185461738 := by decide
theorem cert_e2260092439530 : check e2260092439530 [[],[.under]] .three = true := by decide
def e2260092439774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2260092439774 : Closed e2260092439774 ∧ code e2260092439774 = 11056185461982 := by decide
theorem cert_e2260092439774 : check e2260092439774 [[],[.under]] .three = true := by decide
def e2260092439790 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2260092439790 : Closed e2260092439790 ∧ code e2260092439790 = 11056185461998 := by decide
theorem cert_e2260092439790 : check e2260092439790 [[],[.under]] .smaller = true := by decide
def e2260092439798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2260092439798 : Closed e2260092439798 ∧ code e2260092439798 = 11056185462006 := by decide
theorem cert_e2260092439798 : check e2260092439798 [[],[.under]] .smaller = true := by decide
def e2260092439802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2260092439802 : Closed e2260092439802 ∧ code e2260092439802 = 11056185462010 := by decide
theorem cert_e2260092439802 : check e2260092439802 [[],[.under]] .three = true := by decide
def e2260092440174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2260092440174 : Closed e2260092440174 ∧ code e2260092440174 = 11056185462382 := by decide
theorem cert_e2260092440174 : check e2260092440174 [[],[.under]] .smaller = true := by decide
def e2260092440186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2260092440186 : Closed e2260092440186 ∧ code e2260092440186 = 11056185462394 := by decide
theorem cert_e2260092440186 : check e2260092440186 [[],[.under]] .smaller = true := by decide
def e2260092440374 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260092440374 : Closed e2260092440374 ∧ code e2260092440374 = 11056185462582 := by decide
theorem cert_e2260092440374 : check e2260092440374 [[],[.under]] .smaller = true := by decide
def e2260092440378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260092440378 : Closed e2260092440378 ∧ code e2260092440378 = 11056185462586 := by decide
theorem cert_e2260092440378 : check e2260092440378 [[],[.under]] .smaller = true := by decide
def e2260092440474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2260092440474 : Closed e2260092440474 ∧ code e2260092440474 = 11056185462682 := by decide
theorem cert_e2260092440474 : check e2260092440474 [[],[.under]] .three = true := by decide
def e2260092446134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2260092446134 : Closed e2260092446134 ∧ code e2260092446134 = 11056185468342 := by decide
theorem cert_e2260092446134 : check e2260092446134 [[],[.under]] .smaller = true := by decide
def e2260092446166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2260092446166 : Closed e2260092446166 ∧ code e2260092446166 = 11056185468374 := by decide
theorem cert_e2260092446166 : check e2260092446166 [[],[.under]] .smaller = true := by decide
def e2260092446170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2260092446170 : Closed e2260092446170 ∧ code e2260092446170 = 11056185468378 := by decide
theorem cert_e2260092446170 : check e2260092446170 [[],[.under]] .smaller = true := by decide
def e2260092446326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2260092446326 : Closed e2260092446326 ∧ code e2260092446326 = 11056185468534 := by decide
theorem cert_e2260092446326 : check e2260092446326 [[],[.under]] .smaller = true := by decide
def e2260092446518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260092446518 : Closed e2260092446518 ∧ code e2260092446518 = 11056185468726 := by decide
theorem cert_e2260092446518 : check e2260092446518 [[],[.under]] .smaller = true := by decide
def e2260092446522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260092446522 : Closed e2260092446522 ∧ code e2260092446522 = 11056185468730 := by decide
theorem cert_e2260092446522 : check e2260092446522 [[],[.under]] .smaller = true := by decide
def e2260092449494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2260092449494 : Closed e2260092449494 ∧ code e2260092449494 = 11056185471702 := by decide
theorem cert_e2260092449494 : check e2260092449494 [[],[.under]] .three = true := by decide
def e2260092449498 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2260092449498 : Closed e2260092449498 ∧ code e2260092449498 = 11056185471706 := by decide
theorem cert_e2260092449498 : check e2260092449498 [[],[.under]] .three = true := by decide
def e2260092449514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2260092449514 : Closed e2260092449514 ∧ code e2260092449514 = 11056185471722 := by decide
theorem cert_e2260092449514 : check e2260092449514 [[],[.under]] .three = true := by decide
def e2260092449590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260092449590 : Closed e2260092449590 ∧ code e2260092449590 = 11056185471798 := by decide
theorem cert_e2260092449590 : check e2260092449590 [[],[.under]] .three = true := by decide
def e2260092449594 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260092449594 : Closed e2260092449594 ∧ code e2260092449594 = 11056185471802 := by decide
theorem cert_e2260092449594 : check e2260092449594 [[],[.under]] .three = true := by decide
def e2260092449690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2260092449690 : Closed e2260092449690 ∧ code e2260092449690 = 11056185471898 := by decide
theorem cert_e2260092449690 : check e2260092449690 [[],[.under]] .three = true := by decide
def e2260092674926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2260092674926 : Closed e2260092674926 ∧ code e2260092674926 = 11056185697134 := by decide
theorem cert_e2260092674926 : check e2260092674926 [[],[.under]] .three = true := by decide
def e2260092674934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2260092674934 : Closed e2260092674934 ∧ code e2260092674934 = 11056185697142 := by decide
theorem cert_e2260092674934 : check e2260092674934 [[],[.under]] .three = true := by decide
def e2260092674990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2260092674990 : Closed e2260092674990 ∧ code e2260092674990 = 11056185697198 := by decide
theorem cert_e2260092674990 : check e2260092674990 [[],[.under]] .three = true := by decide
def e2260092675002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2260092675002 : Closed e2260092675002 ∧ code e2260092675002 = 11056185697210 := by decide
theorem cert_e2260092675002 : check e2260092675002 [[],[.under]] .three = true := by decide
def e2260092675030 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2260092675030 : Closed e2260092675030 ∧ code e2260092675030 = 11056185697238 := by decide
theorem cert_e2260092675030 : check e2260092675030 [[],[.under]] .three = true := by decide
def e2260092675034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2260092675034 : Closed e2260092675034 ∧ code e2260092675034 = 11056185697242 := by decide
theorem cert_e2260092675034 : check e2260092675034 [[],[.under]] .three = true := by decide
def e2260092676334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2260092676334 : Closed e2260092676334 ∧ code e2260092676334 = 11056185698542 := by decide
theorem cert_e2260092676334 : check e2260092676334 [[],[.under]] .three = true := by decide
def e2260092676342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2260092676342 : Closed e2260092676342 ∧ code e2260092676342 = 11056185698550 := by decide
theorem cert_e2260092676342 : check e2260092676342 [[],[.under]] .three = true := by decide
def e2260092676894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2260092676894 : Closed e2260092676894 ∧ code e2260092676894 = 11056185699102 := by decide
theorem cert_e2260092676894 : check e2260092676894 [[],[.under]] .three = true := by decide
def e2260092677006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2260092677006 : Closed e2260092677006 ∧ code e2260092677006 = 11056185699214 := by decide
theorem cert_e2260092677006 : check e2260092677006 [[],[.under]] .three = true := by decide
def e2260092677230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2260092677230 : Closed e2260092677230 ∧ code e2260092677230 = 11056185699438 := by decide
theorem cert_e2260092677230 : check e2260092677230 [[],[.under]] .three = true := by decide
def e2260092677242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2260092677242 : Closed e2260092677242 ∧ code e2260092677242 = 11056185699450 := by decide
theorem cert_e2260092677242 : check e2260092677242 [[],[.under]] .three = true := by decide
def e2260092677406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2260092677406 : Closed e2260092677406 ∧ code e2260092677406 = 11056185699614 := by decide
theorem cert_e2260092677406 : check e2260092677406 [[],[.under]] .three = true := by decide
def e2260092677574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2260092677574 : Closed e2260092677574 ∧ code e2260092677574 = 11056185699782 := by decide
theorem cert_e2260092677574 : check e2260092677574 [[],[.under]] .three = true := by decide
def e2260092677686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2260092677686 : Closed e2260092677686 ∧ code e2260092677686 = 11056185699894 := by decide
theorem cert_e2260092677686 : check e2260092677686 [[],[.under]] .three = true := by decide
def e2260092677690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2260092677690 : Closed e2260092677690 ∧ code e2260092677690 = 11056185699898 := by decide
theorem cert_e2260092677690 : check e2260092677690 [[],[.under]] .three = true := by decide
def e2260092677774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2260092677774 : Closed e2260092677774 ∧ code e2260092677774 = 11056185699982 := by decide
theorem cert_e2260092677774 : check e2260092677774 [[],[.under]] .three = true := by decide
def e2260092677830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2260092677830 : Closed e2260092677830 ∧ code e2260092677830 = 11056185700038 := by decide
theorem cert_e2260092677830 : check e2260092677830 [[],[.under]] .three = true := by decide
def e2260092678574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2260092678574 : Closed e2260092678574 ∧ code e2260092678574 = 11056185700782 := by decide
theorem cert_e2260092678574 : check e2260092678574 [[],[.under]] .three = true := by decide
def e2260092678586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2260092678586 : Closed e2260092678586 ∧ code e2260092678586 = 11056185700794 := by decide
theorem cert_e2260092678586 : check e2260092678586 [[],[.under]] .three = true := by decide
def e2260092678634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2260092678634 : Closed e2260092678634 ∧ code e2260092678634 = 11056185700842 := by decide
theorem cert_e2260092678634 : check e2260092678634 [[],[.under]] .three = true := by decide
def e2260092679278 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2260092679278 : Closed e2260092679278 ∧ code e2260092679278 = 11056185701486 := by decide
theorem cert_e2260092679278 : check e2260092679278 [[],[.under]] .three = true := by decide
def e2260092679290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2260092679290 : Closed e2260092679290 ∧ code e2260092679290 = 11056185701498 := by decide
theorem cert_e2260092679290 : check e2260092679290 [[],[.under]] .three = true := by decide
def e2260092679454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2260092679454 : Closed e2260092679454 ∧ code e2260092679454 = 11056185701662 := by decide
theorem cert_e2260092679454 : check e2260092679454 [[],[.under]] .three = true := by decide
def e2260092679622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2260092679622 : Closed e2260092679622 ∧ code e2260092679622 = 11056185701830 := by decide
theorem cert_e2260092679622 : check e2260092679622 [[],[.under]] .three = true := by decide
def e2260092679962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2260092679962 : Closed e2260092679962 ∧ code e2260092679962 = 11056185702170 := by decide
theorem cert_e2260092679962 : check e2260092679962 [[],[.under]] .three = true := by decide
def e2260092680006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2260092680006 : Closed e2260092680006 ∧ code e2260092680006 = 11056185702214 := by decide
theorem cert_e2260092680006 : check e2260092680006 [[],[.under]] .three = true := by decide
def e2260092680406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2260092680406 : Closed e2260092680406 ∧ code e2260092680406 = 11056185702614 := by decide
theorem cert_e2260092680406 : check e2260092680406 [[],[.under]] .three = true := by decide
def e2260092680410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2260092680410 : Closed e2260092680410 ∧ code e2260092680410 = 11056185702618 := by decide
theorem cert_e2260092680410 : check e2260092680410 [[],[.under]] .three = true := by decide
def e2260092680426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2260092680426 : Closed e2260092680426 ∧ code e2260092680426 = 11056185702634 := by decide
theorem cert_e2260092680426 : check e2260092680426 [[],[.under]] .three = true := by decide
def e2260092680758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2260092680758 : Closed e2260092680758 ∧ code e2260092680758 = 11056185702966 := by decide
theorem cert_e2260092680758 : check e2260092680758 [[],[.under]] .three = true := by decide
def e2260092680762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2260092680762 : Closed e2260092680762 ∧ code e2260092680762 = 11056185702970 := by decide
theorem cert_e2260092680762 : check e2260092680762 [[],[.under]] .three = true := by decide
def e2260092680846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2260092680846 : Closed e2260092680846 ∧ code e2260092680846 = 11056185703054 := by decide
theorem cert_e2260092680846 : check e2260092680846 [[],[.under]] .three = true := by decide
def e2260092680902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2260092680902 : Closed e2260092680902 ∧ code e2260092680902 = 11056185703110 := by decide
theorem cert_e2260092680902 : check e2260092680902 [[],[.under]] .three = true := by decide
def e2260092680986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2260092680986 : Closed e2260092680986 ∧ code e2260092680986 = 11056185703194 := by decide
theorem cert_e2260092680986 : check e2260092680986 [[],[.under]] .three = true := by decide
def e2260092681030 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2260092681030 : Closed e2260092681030 ∧ code e2260092681030 = 11056185703238 := by decide
theorem cert_e2260092681030 : check e2260092681030 [[],[.under]] .three = true := by decide
def e2260092685550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2260092685550 : Closed e2260092685550 ∧ code e2260092685550 = 11056185707758 := by decide
theorem cert_e2260092685550 : check e2260092685550 [[],[.under]] .three = true := by decide
def e2260092685558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2260092685558 : Closed e2260092685558 ∧ code e2260092685558 = 11056185707766 := by decide
theorem cert_e2260092685558 : check e2260092685558 [[],[.under]] .three = true := by decide
def e2260092685934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2260092685934 : Closed e2260092685934 ∧ code e2260092685934 = 11056185708142 := by decide
theorem cert_e2260092685934 : check e2260092685934 [[],[.under]] .three = true := by decide
def e2260092685946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2260092685946 : Closed e2260092685946 ∧ code e2260092685946 = 11056185708154 := by decide
theorem cert_e2260092685946 : check e2260092685946 [[],[.under]] .three = true := by decide
def e2260092686134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2260092686134 : Closed e2260092686134 ∧ code e2260092686134 = 11056185708342 := by decide
theorem cert_e2260092686134 : check e2260092686134 [[],[.under]] .three = true := by decide
def e2260092686138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2260092686138 : Closed e2260092686138 ∧ code e2260092686138 = 11056185708346 := by decide
theorem cert_e2260092686138 : check e2260092686138 [[],[.under]] .three = true := by decide
def e2260092688622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2260092688622 : Closed e2260092688622 ∧ code e2260092688622 = 11056185710830 := by decide
theorem cert_e2260092688622 : check e2260092688622 [[],[.under]] .three = true := by decide
def e2260092688630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2260092688630 : Closed e2260092688630 ∧ code e2260092688630 = 11056185710838 := by decide
theorem cert_e2260092688630 : check e2260092688630 [[],[.under]] .three = true := by decide
def e2260092689182 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2260092689182 : Closed e2260092689182 ∧ code e2260092689182 = 11056185711390 := by decide
theorem cert_e2260092689182 : check e2260092689182 [[],[.under]] .three = true := by decide
def e2260092689294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2260092689294 : Closed e2260092689294 ∧ code e2260092689294 = 11056185711502 := by decide
theorem cert_e2260092689294 : check e2260092689294 [[],[.under]] .three = true := by decide
def e2260092689518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2260092689518 : Closed e2260092689518 ∧ code e2260092689518 = 11056185711726 := by decide
theorem cert_e2260092689518 : check e2260092689518 [[],[.under]] .three = true := by decide
def e2260092689530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2260092689530 : Closed e2260092689530 ∧ code e2260092689530 = 11056185711738 := by decide
theorem cert_e2260092689530 : check e2260092689530 [[],[.under]] .three = true := by decide
def e2260092689694 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2260092689694 : Closed e2260092689694 ∧ code e2260092689694 = 11056185711902 := by decide
theorem cert_e2260092689694 : check e2260092689694 [[],[.under]] .three = true := by decide
def e2260092689862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2260092689862 : Closed e2260092689862 ∧ code e2260092689862 = 11056185712070 := by decide
theorem cert_e2260092689862 : check e2260092689862 [[],[.under]] .three = true := by decide
def e2260092689974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2260092689974 : Closed e2260092689974 ∧ code e2260092689974 = 11056185712182 := by decide
theorem cert_e2260092689974 : check e2260092689974 [[],[.under]] .three = true := by decide
def e2260092689978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2260092689978 : Closed e2260092689978 ∧ code e2260092689978 = 11056185712186 := by decide
theorem cert_e2260092689978 : check e2260092689978 [[],[.under]] .three = true := by decide
def e2260092690062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2260092690062 : Closed e2260092690062 ∧ code e2260092690062 = 11056185712270 := by decide
theorem cert_e2260092690062 : check e2260092690062 [[],[.under]] .three = true := by decide
def e2260092690118 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2260092690118 : Closed e2260092690118 ∧ code e2260092690118 = 11056185712326 := by decide
theorem cert_e2260092690118 : check e2260092690118 [[],[.under]] .three = true := by decide
def e2260092692254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2260092692254 : Closed e2260092692254 ∧ code e2260092692254 = 11056185714462 := by decide
theorem cert_e2260092692254 : check e2260092692254 [[],[.under]] .three = true := by decide
def e2260092692366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2260092692366 : Closed e2260092692366 ∧ code e2260092692366 = 11056185714574 := by decide
theorem cert_e2260092692366 : check e2260092692366 [[],[.under]] .three = true := by decide
def e2260092695326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2260092695326 : Closed e2260092695326 ∧ code e2260092695326 = 11056185717534 := by decide
theorem cert_e2260092695326 : check e2260092695326 [[],[.under]] .three = true := by decide
def e2260092695494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2260092695494 : Closed e2260092695494 ∧ code e2260092695494 = 11056185717702 := by decide
theorem cert_e2260092695494 : check e2260092695494 [[],[.under]] .three = true := by decide
def e2260092696974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2260092696974 : Closed e2260092696974 ∧ code e2260092696974 = 11056185719182 := by decide
theorem cert_e2260092696974 : check e2260092696974 [[],[.under]] .three = true := by decide
def e2260092697030 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2260092697030 : Closed e2260092697030 ∧ code e2260092697030 = 11056185719238 := by decide
theorem cert_e2260092697030 : check e2260092697030 [[],[.under]] .three = true := by decide
def e2260092700270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2260092700270 : Closed e2260092700270 ∧ code e2260092700270 = 11056185722478 := by decide
theorem cert_e2260092700270 : check e2260092700270 [[],[.under]] .three = true := by decide
def e2260092700282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2260092700282 : Closed e2260092700282 ∧ code e2260092700282 = 11056185722490 := by decide
theorem cert_e2260092700282 : check e2260092700282 [[],[.under]] .three = true := by decide
def e2260092700570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2260092700570 : Closed e2260092700570 ∧ code e2260092700570 = 11056185722778 := by decide
theorem cert_e2260092700570 : check e2260092700570 [[],[.under]] .three = true := by decide
def e2260092701806 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2260092701806 : Closed e2260092701806 ∧ code e2260092701806 = 11056185724014 := by decide
theorem cert_e2260092701806 : check e2260092701806 [[],[.under]] .three = true := by decide
def e2260092701818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2260092701818 : Closed e2260092701818 ∧ code e2260092701818 = 11056185724026 := by decide
theorem cert_e2260092701818 : check e2260092701818 [[],[.under]] .three = true := by decide
def e2260092701982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2260092701982 : Closed e2260092701982 ∧ code e2260092701982 = 11056185724190 := by decide
theorem cert_e2260092701982 : check e2260092701982 [[],[.under]] .three = true := by decide
def e2260092702150 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2260092702150 : Closed e2260092702150 ∧ code e2260092702150 = 11056185724358 := by decide
theorem cert_e2260092702150 : check e2260092702150 [[],[.under]] .three = true := by decide
def e2260092702490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2260092702490 : Closed e2260092702490 ∧ code e2260092702490 = 11056185724698 := by decide
theorem cert_e2260092702490 : check e2260092702490 [[],[.under]] .three = true := by decide
def e2260092702534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2260092702534 : Closed e2260092702534 ∧ code e2260092702534 = 11056185724742 := by decide
theorem cert_e2260092702534 : check e2260092702534 [[],[.under]] .three = true := by decide
def e2260092703518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2260092703518 : Closed e2260092703518 ∧ code e2260092703518 = 11056185725726 := by decide
theorem cert_e2260092703518 : check e2260092703518 [[],[.under]] .three = true := by decide
def e2260092703686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2260092703686 : Closed e2260092703686 ∧ code e2260092703686 = 11056185725894 := by decide
theorem cert_e2260092703686 : check e2260092703686 [[],[.under]] .three = true := by decide
def e2260092705990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2260092705990 : Closed e2260092705990 ∧ code e2260092705990 = 11056185728198 := by decide
theorem cert_e2260092705990 : check e2260092705990 [[],[.under]] .three = true := by decide
end Blc.Floor43
