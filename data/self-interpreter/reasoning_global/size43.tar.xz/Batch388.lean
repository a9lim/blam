import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422365330958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))))))))))
theorem wire_e2422365330958 : Closed e2422365330958 ∧ code e2422365330958 = 11218458353166 := by decide
theorem cert_e2422365330958 : check e2422365330958 [[],[]] .smaller = true := by decide
def e2422365330970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422365330970 : Closed e2422365330970 ∧ code e2422365330970 = 11218458353178 := by decide
theorem cert_e2422365330970 : check e2422365330970 [[],[]] .smaller = true := by decide
def e2422365331042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))))
theorem wire_e2422365331042 : Closed e2422365331042 ∧ code e2422365331042 = 11218458353250 := by decide
theorem cert_e2422365331042 : check e2422365331042 [[],[]] .smaller = true := by decide
def e2422365331054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422365331054 : Closed e2422365331054 ∧ code e2422365331054 = 11218458353262 := by decide
theorem cert_e2422365331054 : check e2422365331054 [[],[]] .smaller = true := by decide
def e2422365331062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365331062 : Closed e2422365331062 ∧ code e2422365331062 = 11218458353270 := by decide
theorem cert_e2422365331062 : check e2422365331062 [[],[]] .smaller = true := by decide
def e2422365331066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422365331066 : Closed e2422365331066 ∧ code e2422365331066 = 11218458353274 := by decide
theorem cert_e2422365331066 : check e2422365331066 [[],[]] .smaller = true := by decide
def e2422365331254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365331254 : Closed e2422365331254 ∧ code e2422365331254 = 11218458353462 := by decide
theorem cert_e2422365331254 : check e2422365331254 [[],[]] .smaller = true := by decide
def e2422365331258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365331258 : Closed e2422365331258 ∧ code e2422365331258 = 11218458353466 := by decide
theorem cert_e2422365331258 : check e2422365331258 [[],[]] .smaller = true := by decide
def e2422365331342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.lam (.var 2)))))))))))
theorem wire_e2422365331342 : Closed e2422365331342 ∧ code e2422365331342 = 11218458353550 := by decide
theorem cert_e2422365331342 : check e2422365331342 [[],[]] .three = true := by decide
def e2422365331354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365331354 : Closed e2422365331354 ∧ code e2422365331354 = 11218458353562 := by decide
theorem cert_e2422365331354 : check e2422365331354 [[],[]] .three = true := by decide
def e2422365331390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 4))))))))))
theorem wire_e2422365331390 : Closed e2422365331390 ∧ code e2422365331390 = 11218458353598 := by decide
theorem cert_e2422365331390 : check e2422365331390 [[],[]] .three = true := by decide
def e2422365340606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422365340606 : Closed e2422365340606 ∧ code e2422365340606 = 11218458362814 := by decide
theorem cert_e2422365340606 : check e2422365340606 [[],[]] .smaller = true := by decide
def e2422365340662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422365340662 : Closed e2422365340662 ∧ code e2422365340662 = 11218458362870 := by decide
theorem cert_e2422365340662 : check e2422365340662 [[],[]] .smaller = true := by decide
def e2422365342558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e2422365342558 : Closed e2422365342558 ∧ code e2422365342558 = 11218458364766 := by decide
theorem cert_e2422365342558 : check e2422365342558 [[],[]] .smaller = true := by decide
def e2422365342574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422365342574 : Closed e2422365342574 ∧ code e2422365342574 = 11218458364782 := by decide
theorem cert_e2422365342574 : check e2422365342574 [[],[]] .smaller = true := by decide
def e2422365342582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422365342582 : Closed e2422365342582 ∧ code e2422365342582 = 11218458364790 := by decide
theorem cert_e2422365342582 : check e2422365342582 [[],[]] .smaller = true := by decide
def e2422365342586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e2422365342586 : Closed e2422365342586 ∧ code e2422365342586 = 11218458364794 := by decide
theorem cert_e2422365342586 : check e2422365342586 [[],[]] .smaller = true := by decide
def e2422365342638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422365342638 : Closed e2422365342638 ∧ code e2422365342638 = 11218458364846 := by decide
theorem cert_e2422365342638 : check e2422365342638 [[],[]] .smaller = true := by decide
def e2422365342650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422365342650 : Closed e2422365342650 ∧ code e2422365342650 = 11218458364858 := by decide
theorem cert_e2422365342650 : check e2422365342650 [[],[]] .smaller = true := by decide
def e2422365342678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422365342678 : Closed e2422365342678 ∧ code e2422365342678 = 11218458364886 := by decide
theorem cert_e2422365342678 : check e2422365342678 [[],[]] .smaller = true := by decide
def e2422365342682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422365342682 : Closed e2422365342682 ∧ code e2422365342682 = 11218458364890 := by decide
theorem cert_e2422365342682 : check e2422365342682 [[],[]] .smaller = true := by decide
def e2422365342698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e2422365342698 : Closed e2422365342698 ∧ code e2422365342698 = 11218458364906 := by decide
theorem cert_e2422365342698 : check e2422365342698 [[],[]] .smaller = true := by decide
def e2422365342846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 5)))))))))))
theorem wire_e2422365342846 : Closed e2422365342846 ∧ code e2422365342846 = 11218458365054 := by decide
theorem cert_e2422365342846 : check e2422365342846 [[],[]] .three = true := by decide
def e2422365342942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422365342942 : Closed e2422365342942 ∧ code e2422365342942 = 11218458365150 := by decide
theorem cert_e2422365342942 : check e2422365342942 [[],[]] .smaller = true := by decide
def e2422365342958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365342958 : Closed e2422365342958 ∧ code e2422365342958 = 11218458365166 := by decide
theorem cert_e2422365342958 : check e2422365342958 [[],[]] .smaller = true := by decide
def e2422365342966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365342966 : Closed e2422365342966 ∧ code e2422365342966 = 11218458365174 := by decide
theorem cert_e2422365342966 : check e2422365342966 [[],[]] .smaller = true := by decide
def e2422365342970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422365342970 : Closed e2422365342970 ∧ code e2422365342970 = 11218458365178 := by decide
theorem cert_e2422365342970 : check e2422365342970 [[],[]] .smaller = true := by decide
def e2422365343342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422365343342 : Closed e2422365343342 ∧ code e2422365343342 = 11218458365550 := by decide
theorem cert_e2422365343342 : check e2422365343342 [[],[]] .smaller = true := by decide
def e2422365343354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422365343354 : Closed e2422365343354 ∧ code e2422365343354 = 11218458365562 := by decide
theorem cert_e2422365343354 : check e2422365343354 [[],[]] .smaller = true := by decide
def e2422365343542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365343542 : Closed e2422365343542 ∧ code e2422365343542 = 11218458365750 := by decide
theorem cert_e2422365343542 : check e2422365343542 [[],[]] .smaller = true := by decide
def e2422365343546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365343546 : Closed e2422365343546 ∧ code e2422365343546 = 11218458365754 := by decide
theorem cert_e2422365343546 : check e2422365343546 [[],[]] .smaller = true := by decide
def e2422365343642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365343642 : Closed e2422365343642 ∧ code e2422365343642 = 11218458365850 := by decide
theorem cert_e2422365343642 : check e2422365343642 [[],[]] .smaller = true := by decide
def e2422365343678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 4))))))))))
theorem wire_e2422365343678 : Closed e2422365343678 ∧ code e2422365343678 = 11218458365886 := by decide
theorem cert_e2422365343678 : check e2422365343678 [[],[]] .three = true := by decide
def e2422365343686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 4) (.lam (.var 1)))))))))))
theorem wire_e2422365343686 : Closed e2422365343686 ∧ code e2422365343686 = 11218458365894 := by decide
theorem cert_e2422365343686 : check e2422365343686 [[],[]] .three = true := by decide
def e2422365343710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 4) (.var 3))))))))))
theorem wire_e2422365343710 : Closed e2422365343710 ∧ code e2422365343710 = 11218458365918 := by decide
theorem cert_e2422365343710 : check e2422365343710 [[],[]] .three = true := by decide
def e2422365348318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422365348318 : Closed e2422365348318 ∧ code e2422365348318 = 11218458370526 := by decide
theorem cert_e2422365348318 : check e2422365348318 [[],[]] .smaller = true := by decide
def e2422365348342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422365348342 : Closed e2422365348342 ∧ code e2422365348342 = 11218458370550 := by decide
theorem cert_e2422365348342 : check e2422365348342 [[],[]] .smaller = true := by decide
def e2422365349258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))))
theorem wire_e2422365349258 : Closed e2422365349258 ∧ code e2422365349258 = 11218458371466 := by decide
theorem cert_e2422365349258 : check e2422365349258 [[],[]] .smaller = true := by decide
def e2422365349282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))))
theorem wire_e2422365349282 : Closed e2422365349282 ∧ code e2422365349282 = 11218458371490 := by decide
theorem cert_e2422365349282 : check e2422365349282 [[],[]] .smaller = true := by decide
def e2422365349294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422365349294 : Closed e2422365349294 ∧ code e2422365349294 = 11218458371502 := by decide
theorem cert_e2422365349294 : check e2422365349294 [[],[]] .smaller = true := by decide
def e2422365349302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2422365349302 : Closed e2422365349302 ∧ code e2422365349302 = 11218458371510 := by decide
theorem cert_e2422365349302 : check e2422365349302 [[],[]] .smaller = true := by decide
def e2422365349306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422365349306 : Closed e2422365349306 ∧ code e2422365349306 = 11218458371514 := by decide
theorem cert_e2422365349306 : check e2422365349306 [[],[]] .smaller = true := by decide
def e2422365349334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2422365349334 : Closed e2422365349334 ∧ code e2422365349334 = 11218458371542 := by decide
theorem cert_e2422365349334 : check e2422365349334 [[],[]] .smaller = true := by decide
def e2422365349338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2422365349338 : Closed e2422365349338 ∧ code e2422365349338 = 11218458371546 := by decide
theorem cert_e2422365349338 : check e2422365349338 [[],[]] .smaller = true := by decide
def e2422365349354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422365349354 : Closed e2422365349354 ∧ code e2422365349354 = 11218458371562 := by decide
theorem cert_e2422365349354 : check e2422365349354 [[],[]] .smaller = true := by decide
def e2422365349390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))))))))))
theorem wire_e2422365349390 : Closed e2422365349390 ∧ code e2422365349390 = 11218458371598 := by decide
theorem cert_e2422365349390 : check e2422365349390 [[],[]] .smaller = true := by decide
def e2422365349402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422365349402 : Closed e2422365349402 ∧ code e2422365349402 = 11218458371610 := by decide
theorem cert_e2422365349402 : check e2422365349402 [[],[]] .smaller = true := by decide
def e2422365349474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))))
theorem wire_e2422365349474 : Closed e2422365349474 ∧ code e2422365349474 = 11218458371682 := by decide
theorem cert_e2422365349474 : check e2422365349474 [[],[]] .smaller = true := by decide
def e2422365349486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422365349486 : Closed e2422365349486 ∧ code e2422365349486 = 11218458371694 := by decide
theorem cert_e2422365349486 : check e2422365349486 [[],[]] .smaller = true := by decide
def e2422365349494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365349494 : Closed e2422365349494 ∧ code e2422365349494 = 11218458371702 := by decide
theorem cert_e2422365349494 : check e2422365349494 [[],[]] .smaller = true := by decide
def e2422365349498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422365349498 : Closed e2422365349498 ∧ code e2422365349498 = 11218458371706 := by decide
theorem cert_e2422365349498 : check e2422365349498 [[],[]] .smaller = true := by decide
def e2422365349686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365349686 : Closed e2422365349686 ∧ code e2422365349686 = 11218458371894 := by decide
theorem cert_e2422365349686 : check e2422365349686 [[],[]] .smaller = true := by decide
def e2422365349690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365349690 : Closed e2422365349690 ∧ code e2422365349690 = 11218458371898 := by decide
theorem cert_e2422365349690 : check e2422365349690 [[],[]] .smaller = true := by decide
def e2422365349786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365349786 : Closed e2422365349786 ∧ code e2422365349786 = 11218458371994 := by decide
theorem cert_e2422365349786 : check e2422365349786 [[],[]] .smaller = true := by decide
def e2422365349822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 4))))))))))
theorem wire_e2422365349822 : Closed e2422365349822 ∧ code e2422365349822 = 11218458372030 := by decide
theorem cert_e2422365349822 : check e2422365349822 [[],[]] .three = true := by decide
def e2422365349854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 3))))))))))
theorem wire_e2422365349854 : Closed e2422365349854 ∧ code e2422365349854 = 11218458372062 := by decide
theorem cert_e2422365349854 : check e2422365349854 [[],[]] .smaller = true := by decide
def e2422365349870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 4) (.var 2))))))))))
theorem wire_e2422365349870 : Closed e2422365349870 ∧ code e2422365349870 = 11218458372078 := by decide
theorem cert_e2422365349870 : check e2422365349870 [[],[]] .three = true := by decide
def e2422365352174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365352174 : Closed e2422365352174 ∧ code e2422365352174 = 11218458374382 := by decide
theorem cert_e2422365352174 : check e2422365352174 [[],[]] .smaller = true := by decide
def e2422365352182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365352182 : Closed e2422365352182 ∧ code e2422365352182 = 11218458374390 := by decide
theorem cert_e2422365352182 : check e2422365352182 [[],[]] .smaller = true := by decide
def e2422365352662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422365352662 : Closed e2422365352662 ∧ code e2422365352662 = 11218458374870 := by decide
theorem cert_e2422365352662 : check e2422365352662 [[],[]] .smaller = true := by decide
def e2422365352666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422365352666 : Closed e2422365352666 ∧ code e2422365352666 = 11218458374874 := by decide
theorem cert_e2422365352666 : check e2422365352666 [[],[]] .smaller = true := by decide
def e2422365352682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422365352682 : Closed e2422365352682 ∧ code e2422365352682 = 11218458374890 := by decide
theorem cert_e2422365352682 : check e2422365352682 [[],[]] .smaller = true := by decide
def e2422365352758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365352758 : Closed e2422365352758 ∧ code e2422365352758 = 11218458374966 := by decide
theorem cert_e2422365352758 : check e2422365352758 [[],[]] .smaller = true := by decide
def e2422365352762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365352762 : Closed e2422365352762 ∧ code e2422365352762 = 11218458374970 := by decide
theorem cert_e2422365352762 : check e2422365352762 [[],[]] .smaller = true := by decide
def e2422365352858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365352858 : Closed e2422365352858 ∧ code e2422365352858 = 11218458375066 := by decide
theorem cert_e2422365352858 : check e2422365352858 [[],[]] .smaller = true := by decide
def e2422365352894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422365352894 : Closed e2422365352894 ∧ code e2422365352894 = 11218458375102 := by decide
theorem cert_e2422365352894 : check e2422365352894 [[],[]] .three = true := by decide
def e2422365352926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422365352926 : Closed e2422365352926 ∧ code e2422365352926 = 11218458375134 := by decide
theorem cert_e2422365352926 : check e2422365352926 [[],[]] .smaller = true := by decide
def e2422365352942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422365352942 : Closed e2422365352942 ∧ code e2422365352942 = 11218458375150 := by decide
theorem cert_e2422365352942 : check e2422365352942 [[],[]] .smaller = true := by decide
def e2422365352950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422365352950 : Closed e2422365352950 ∧ code e2422365352950 = 11218458375158 := by decide
theorem cert_e2422365352950 : check e2422365352950 [[],[]] .three = true := by decide
def e2422365354102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365354102 : Closed e2422365354102 ∧ code e2422365354102 = 11218458376310 := by decide
theorem cert_e2422365354102 : check e2422365354102 [[],[]] .three = true := by decide
def e2422365354346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422365354346 : Closed e2422365354346 ∧ code e2422365354346 = 11218458376554 := by decide
theorem cert_e2422365354346 : check e2422365354346 [[],[]] .three = true := by decide
def e2422365354382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422365354382 : Closed e2422365354382 ∧ code e2422365354382 = 11218458376590 := by decide
theorem cert_e2422365354382 : check e2422365354382 [[],[]] .three = true := by decide
def e2422365354394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365354394 : Closed e2422365354394 ∧ code e2422365354394 = 11218458376602 := by decide
theorem cert_e2422365354394 : check e2422365354394 [[],[]] .three = true := by decide
def e2422365354430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422365354430 : Closed e2422365354430 ∧ code e2422365354430 = 11218458376638 := by decide
theorem cert_e2422365354430 : check e2422365354430 [[],[]] .three = true := by decide
def e2422365354438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422365354438 : Closed e2422365354438 ∧ code e2422365354438 = 11218458376646 := by decide
theorem cert_e2422365354438 : check e2422365354438 [[],[]] .three = true := by decide
def e2422365354462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422365354462 : Closed e2422365354462 ∧ code e2422365354462 = 11218458376670 := by decide
theorem cert_e2422365354462 : check e2422365354462 [[],[]] .three = true := by decide
def e2422365354478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422365354478 : Closed e2422365354478 ∧ code e2422365354478 = 11218458376686 := by decide
theorem cert_e2422365354478 : check e2422365354478 [[],[]] .three = true := by decide
def e2422365354486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422365354486 : Closed e2422365354486 ∧ code e2422365354486 = 11218458376694 := by decide
theorem cert_e2422365354486 : check e2422365354486 [[],[]] .three = true := by decide
def e2422365354490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422365354490 : Closed e2422365354490 ∧ code e2422365354490 = 11218458376698 := by decide
theorem cert_e2422365354490 : check e2422365354490 [[],[]] .three = true := by decide
def e2422365498846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e2422365498846 : Closed e2422365498846 ∧ code e2422365498846 = 11218458521054 := by decide
theorem cert_e2422365498846 : check e2422365498846 [[],[]] .smaller = true := by decide
def e2422365498862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e2422365498862 : Closed e2422365498862 ∧ code e2422365498862 = 11218458521070 := by decide
theorem cert_e2422365498862 : check e2422365498862 [[],[]] .smaller = true := by decide
def e2422365499118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))))))))
theorem wire_e2422365499118 : Closed e2422365499118 ∧ code e2422365499118 = 11218458521326 := by decide
theorem cert_e2422365499118 : check e2422365499118 [[],[]] .smaller = true := by decide
def e2422365499230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e2422365499230 : Closed e2422365499230 ∧ code e2422365499230 = 11218458521438 := by decide
theorem cert_e2422365499230 : check e2422365499230 [[],[]] .smaller = true := by decide
def e2422365499246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))))))))
theorem wire_e2422365499246 : Closed e2422365499246 ∧ code e2422365499246 = 11218458521454 := by decide
theorem cert_e2422365499246 : check e2422365499246 [[],[]] .smaller = true := by decide
def e2422365499254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))))))))
theorem wire_e2422365499254 : Closed e2422365499254 ∧ code e2422365499254 = 11218458521462 := by decide
theorem cert_e2422365499254 : check e2422365499254 [[],[]] .smaller = true := by decide
def e2422365499258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e2422365499258 : Closed e2422365499258 ∧ code e2422365499258 = 11218458521466 := by decide
theorem cert_e2422365499258 : check e2422365499258 [[],[]] .smaller = true := by decide
def e2422365499310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e2422365499310 : Closed e2422365499310 ∧ code e2422365499310 = 11218458521518 := by decide
theorem cert_e2422365499310 : check e2422365499310 [[],[]] .smaller = true := by decide
def e2422365499322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e2422365499322 : Closed e2422365499322 ∧ code e2422365499322 = 11218458521530 := by decide
theorem cert_e2422365499322 : check e2422365499322 [[],[]] .smaller = true := by decide
def e2422365500382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422365500382 : Closed e2422365500382 ∧ code e2422365500382 = 11218458522590 := by decide
theorem cert_e2422365500382 : check e2422365500382 [[],[]] .smaller = true := by decide
def e2422365500398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422365500398 : Closed e2422365500398 ∧ code e2422365500398 = 11218458522606 := by decide
theorem cert_e2422365500398 : check e2422365500398 [[],[]] .smaller = true := by decide
def e2422365501934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422365501934 : Closed e2422365501934 ∧ code e2422365501934 = 11218458524142 := by decide
theorem cert_e2422365501934 : check e2422365501934 [[],[]] .smaller = true := by decide
def e2422365502686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422365502686 : Closed e2422365502686 ∧ code e2422365502686 = 11218458524894 := by decide
theorem cert_e2422365502686 : check e2422365502686 [[],[]] .smaller = true := by decide
def e2422365502702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365502702 : Closed e2422365502702 ∧ code e2422365502702 = 11218458524910 := by decide
theorem cert_e2422365502702 : check e2422365502702 [[],[]] .smaller = true := by decide
def e2422365502710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365502710 : Closed e2422365502710 ∧ code e2422365502710 = 11218458524918 := by decide
theorem cert_e2422365502710 : check e2422365502710 [[],[]] .smaller = true := by decide
def e2422365502714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422365502714 : Closed e2422365502714 ∧ code e2422365502714 = 11218458524922 := by decide
theorem cert_e2422365502714 : check e2422365502714 [[],[]] .smaller = true := by decide
def e2422365503086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422365503086 : Closed e2422365503086 ∧ code e2422365503086 = 11218458525294 := by decide
theorem cert_e2422365503086 : check e2422365503086 [[],[]] .smaller = true := by decide
def e2422365503098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422365503098 : Closed e2422365503098 ∧ code e2422365503098 = 11218458525306 := by decide
theorem cert_e2422365503098 : check e2422365503098 [[],[]] .smaller = true := by decide
def e2422365531222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)))))))))
theorem wire_e2422365531222 : Closed e2422365531222 ∧ code e2422365531222 = 11218458553430 := by decide
theorem cert_e2422365531222 : check e2422365531222 [[],[]] .smaller = true := by decide
def e2422365531226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)))))))))
theorem wire_e2422365531226 : Closed e2422365531226 ∧ code e2422365531226 = 11218458553434 := by decide
theorem cert_e2422365531226 : check e2422365531226 [[],[]] .smaller = true := by decide
def e2422365531414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422365531414 : Closed e2422365531414 ∧ code e2422365531414 = 11218458553622 := by decide
theorem cert_e2422365531414 : check e2422365531414 [[],[]] .smaller = true := by decide
def e2422365531486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e2422365531486 : Closed e2422365531486 ∧ code e2422365531486 = 11218458553694 := by decide
theorem cert_e2422365531486 : check e2422365531486 [[],[]] .smaller = true := by decide
def e2422365531490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422365531490 : Closed e2422365531490 ∧ code e2422365531490 = 11218458553698 := by decide
theorem cert_e2422365531490 : check e2422365531490 [[],[]] .smaller = true := by decide
def e2422365531502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2422365531502 : Closed e2422365531502 ∧ code e2422365531502 = 11218458553710 := by decide
theorem cert_e2422365531502 : check e2422365531502 [[],[]] .smaller = true := by decide
def e2422365531510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2422365531510 : Closed e2422365531510 ∧ code e2422365531510 = 11218458553718 := by decide
theorem cert_e2422365531510 : check e2422365531510 [[],[]] .smaller = true := by decide
def e2422365531514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e2422365531514 : Closed e2422365531514 ∧ code e2422365531514 = 11218458553722 := by decide
theorem cert_e2422365531514 : check e2422365531514 [[],[]] .smaller = true := by decide
def e2422365531530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422365531530 : Closed e2422365531530 ∧ code e2422365531530 = 11218458553738 := by decide
theorem cert_e2422365531530 : check e2422365531530 [[],[]] .smaller = true := by decide
def e2422365531554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422365531554 : Closed e2422365531554 ∧ code e2422365531554 = 11218458553762 := by decide
theorem cert_e2422365531554 : check e2422365531554 [[],[]] .smaller = true := by decide
def e2422365531566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2422365531566 : Closed e2422365531566 ∧ code e2422365531566 = 11218458553774 := by decide
theorem cert_e2422365531566 : check e2422365531566 [[],[]] .smaller = true := by decide
def e2422365531574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)))))))))
theorem wire_e2422365531574 : Closed e2422365531574 ∧ code e2422365531574 = 11218458553782 := by decide
theorem cert_e2422365531574 : check e2422365531574 [[],[]] .smaller = true := by decide
def e2422365531578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2422365531578 : Closed e2422365531578 ∧ code e2422365531578 = 11218458553786 := by decide
theorem cert_e2422365531578 : check e2422365531578 [[],[]] .smaller = true := by decide
def e2422365531606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365531606 : Closed e2422365531606 ∧ code e2422365531606 = 11218458553814 := by decide
theorem cert_e2422365531606 : check e2422365531606 [[],[]] .smaller = true := by decide
def e2422365531610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365531610 : Closed e2422365531610 ∧ code e2422365531610 = 11218458553818 := by decide
theorem cert_e2422365531610 : check e2422365531610 [[],[]] .smaller = true := by decide
def e2422365531626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365531626 : Closed e2422365531626 ∧ code e2422365531626 = 11218458553834 := by decide
theorem cert_e2422365531626 : check e2422365531626 [[],[]] .smaller = true := by decide
def e2422365531690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)))))))))
theorem wire_e2422365531690 : Closed e2422365531690 ∧ code e2422365531690 = 11218458553898 := by decide
theorem cert_e2422365531690 : check e2422365531690 [[],[]] .smaller = true := by decide
def e2422365531786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422365531786 : Closed e2422365531786 ∧ code e2422365531786 = 11218458553994 := by decide
theorem cert_e2422365531786 : check e2422365531786 [[],[]] .smaller = true := by decide
def e2422365531810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422365531810 : Closed e2422365531810 ∧ code e2422365531810 = 11218458554018 := by decide
theorem cert_e2422365531810 : check e2422365531810 [[],[]] .smaller = true := by decide
def e2422365531822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422365531822 : Closed e2422365531822 ∧ code e2422365531822 = 11218458554030 := by decide
theorem cert_e2422365531822 : check e2422365531822 [[],[]] .smaller = true := by decide
def e2422365531830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e2422365531830 : Closed e2422365531830 ∧ code e2422365531830 = 11218458554038 := by decide
theorem cert_e2422365531830 : check e2422365531830 [[],[]] .smaller = true := by decide
def e2422365531834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422365531834 : Closed e2422365531834 ∧ code e2422365531834 = 11218458554042 := by decide
theorem cert_e2422365531834 : check e2422365531834 [[],[]] .smaller = true := by decide
def e2422365531862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365531862 : Closed e2422365531862 ∧ code e2422365531862 = 11218458554070 := by decide
theorem cert_e2422365531862 : check e2422365531862 [[],[]] .smaller = true := by decide
def e2422365531866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365531866 : Closed e2422365531866 ∧ code e2422365531866 = 11218458554074 := by decide
theorem cert_e2422365531866 : check e2422365531866 [[],[]] .smaller = true := by decide
def e2422365531882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365531882 : Closed e2422365531882 ∧ code e2422365531882 = 11218458554090 := by decide
theorem cert_e2422365531882 : check e2422365531882 [[],[]] .smaller = true := by decide
def e2422365531990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365531990 : Closed e2422365531990 ∧ code e2422365531990 = 11218458554198 := by decide
theorem cert_e2422365531990 : check e2422365531990 [[],[]] .smaller = true := by decide
def e2422365531994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365531994 : Closed e2422365531994 ∧ code e2422365531994 = 11218458554202 := by decide
theorem cert_e2422365531994 : check e2422365531994 [[],[]] .smaller = true := by decide
def e2422365532010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365532010 : Closed e2422365532010 ∧ code e2422365532010 = 11218458554218 := by decide
theorem cert_e2422365532010 : check e2422365532010 [[],[]] .smaller = true := by decide
def e2422365532074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365532074 : Closed e2422365532074 ∧ code e2422365532074 = 11218458554282 := by decide
theorem cert_e2422365532074 : check e2422365532074 [[],[]] .smaller = true := by decide
def e2422365532278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)))))))))
theorem wire_e2422365532278 : Closed e2422365532278 ∧ code e2422365532278 = 11218458554486 := by decide
theorem cert_e2422365532278 : check e2422365532278 [[],[]] .smaller = true := by decide
def e2422365532282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)))))))))
theorem wire_e2422365532282 : Closed e2422365532282 ∧ code e2422365532282 = 11218458554490 := by decide
theorem cert_e2422365532282 : check e2422365532282 [[],[]] .smaller = true := by decide
def e2422365532374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))))
theorem wire_e2422365532374 : Closed e2422365532374 ∧ code e2422365532374 = 11218458554582 := by decide
theorem cert_e2422365532374 : check e2422365532374 [[],[]] .smaller = true := by decide
def e2422365532470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365532470 : Closed e2422365532470 ∧ code e2422365532470 = 11218458554678 := by decide
theorem cert_e2422365532470 : check e2422365532470 [[],[]] .smaller = true := by decide
def e2422365532474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365532474 : Closed e2422365532474 ∧ code e2422365532474 = 11218458554682 := by decide
theorem cert_e2422365532474 : check e2422365532474 [[],[]] .smaller = true := by decide
def e2422365532558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))))))))))
theorem wire_e2422365532558 : Closed e2422365532558 ∧ code e2422365532558 = 11218458554766 := by decide
theorem cert_e2422365532558 : check e2422365532558 [[],[]] .smaller = true := by decide
def e2422365532606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 4)))))))))
theorem wire_e2422365532606 : Closed e2422365532606 ∧ code e2422365532606 = 11218458554814 := by decide
theorem cert_e2422365532606 : check e2422365532606 [[],[]] .three = true := by decide
def e2422365532614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))))))))))
theorem wire_e2422365532614 : Closed e2422365532614 ∧ code e2422365532614 = 11218458554822 := by decide
theorem cert_e2422365532614 : check e2422365532614 [[],[]] .smaller = true := by decide
def e2422365532666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 5))) (.var 0)))))))))
theorem wire_e2422365532666 : Closed e2422365532666 ∧ code e2422365532666 = 11218458554874 := by decide
theorem cert_e2422365532666 : check e2422365532666 [[],[]] .three = true := by decide
def e2422365532950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))))
theorem wire_e2422365532950 : Closed e2422365532950 ∧ code e2422365532950 = 11218458555158 := by decide
theorem cert_e2422365532950 : check e2422365532950 [[],[]] .smaller = true := by decide
def e2422365533022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e2422365533022 : Closed e2422365533022 ∧ code e2422365533022 = 11218458555230 := by decide
theorem cert_e2422365533022 : check e2422365533022 [[],[]] .smaller = true := by decide
def e2422365533026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))))
theorem wire_e2422365533026 : Closed e2422365533026 ∧ code e2422365533026 = 11218458555234 := by decide
theorem cert_e2422365533026 : check e2422365533026 [[],[]] .smaller = true := by decide
def e2422365533038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2422365533038 : Closed e2422365533038 ∧ code e2422365533038 = 11218458555246 := by decide
theorem cert_e2422365533038 : check e2422365533038 [[],[]] .smaller = true := by decide
def e2422365533046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2422365533046 : Closed e2422365533046 ∧ code e2422365533046 = 11218458555254 := by decide
theorem cert_e2422365533046 : check e2422365533046 [[],[]] .smaller = true := by decide
def e2422365533050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e2422365533050 : Closed e2422365533050 ∧ code e2422365533050 = 11218458555258 := by decide
theorem cert_e2422365533050 : check e2422365533050 [[],[]] .smaller = true := by decide
def e2422365533066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422365533066 : Closed e2422365533066 ∧ code e2422365533066 = 11218458555274 := by decide
theorem cert_e2422365533066 : check e2422365533066 [[],[]] .smaller = true := by decide
def e2422365533090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))))
theorem wire_e2422365533090 : Closed e2422365533090 ∧ code e2422365533090 = 11218458555298 := by decide
theorem cert_e2422365533090 : check e2422365533090 [[],[]] .smaller = true := by decide
def e2422365533102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2422365533102 : Closed e2422365533102 ∧ code e2422365533102 = 11218458555310 := by decide
theorem cert_e2422365533102 : check e2422365533102 [[],[]] .smaller = true := by decide
def e2422365533110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))))))
theorem wire_e2422365533110 : Closed e2422365533110 ∧ code e2422365533110 = 11218458555318 := by decide
theorem cert_e2422365533110 : check e2422365533110 [[],[]] .smaller = true := by decide
def e2422365533114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2422365533114 : Closed e2422365533114 ∧ code e2422365533114 = 11218458555322 := by decide
theorem cert_e2422365533114 : check e2422365533114 [[],[]] .smaller = true := by decide
def e2422365533142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2422365533142 : Closed e2422365533142 ∧ code e2422365533142 = 11218458555350 := by decide
theorem cert_e2422365533142 : check e2422365533142 [[],[]] .smaller = true := by decide
def e2422365533146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2422365533146 : Closed e2422365533146 ∧ code e2422365533146 = 11218458555354 := by decide
theorem cert_e2422365533146 : check e2422365533146 [[],[]] .smaller = true := by decide
def e2422365533162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e2422365533162 : Closed e2422365533162 ∧ code e2422365533162 = 11218458555370 := by decide
theorem cert_e2422365533162 : check e2422365533162 [[],[]] .smaller = true := by decide
def e2422365533214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422365533214 : Closed e2422365533214 ∧ code e2422365533214 = 11218458555422 := by decide
theorem cert_e2422365533214 : check e2422365533214 [[],[]] .smaller = true := by decide
def e2422365533310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 5))))))))))
theorem wire_e2422365533310 : Closed e2422365533310 ∧ code e2422365533310 = 11218458555518 := by decide
theorem cert_e2422365533310 : check e2422365533310 [[],[]] .three = true := by decide
def e2422365533406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422365533406 : Closed e2422365533406 ∧ code e2422365533406 = 11218458555614 := by decide
theorem cert_e2422365533406 : check e2422365533406 [[],[]] .smaller = true := by decide
def e2422365533410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422365533410 : Closed e2422365533410 ∧ code e2422365533410 = 11218458555618 := by decide
theorem cert_e2422365533410 : check e2422365533410 [[],[]] .smaller = true := by decide
def e2422365533422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422365533422 : Closed e2422365533422 ∧ code e2422365533422 = 11218458555630 := by decide
theorem cert_e2422365533422 : check e2422365533422 [[],[]] .smaller = true := by decide
def e2422365533430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422365533430 : Closed e2422365533430 ∧ code e2422365533430 = 11218458555638 := by decide
theorem cert_e2422365533430 : check e2422365533430 [[],[]] .smaller = true := by decide
def e2422365533434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422365533434 : Closed e2422365533434 ∧ code e2422365533434 = 11218458555642 := by decide
theorem cert_e2422365533434 : check e2422365533434 [[],[]] .smaller = true := by decide
def e2422365533710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422365533710 : Closed e2422365533710 ∧ code e2422365533710 = 11218458555918 := by decide
theorem cert_e2422365533710 : check e2422365533710 [[],[]] .smaller = true := by decide
def e2422365533722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365533722 : Closed e2422365533722 ∧ code e2422365533722 = 11218458555930 := by decide
theorem cert_e2422365533722 : check e2422365533722 [[],[]] .smaller = true := by decide
def e2422365533794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422365533794 : Closed e2422365533794 ∧ code e2422365533794 = 11218458556002 := by decide
theorem cert_e2422365533794 : check e2422365533794 [[],[]] .smaller = true := by decide
def e2422365533806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422365533806 : Closed e2422365533806 ∧ code e2422365533806 = 11218458556014 := by decide
theorem cert_e2422365533806 : check e2422365533806 [[],[]] .smaller = true := by decide
end Blc.Floor43
