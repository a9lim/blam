import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373280890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422373280890 : Closed e2422373280890 ∧ code e2422373280890 = 11218466303098 := by decide
theorem cert_e2422373280890 : check e2422373280890 [[],[]] .smaller = true := by decide
def e2422373281054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2422373281054 : Closed e2422373281054 ∧ code e2422373281054 = 11218466303262 := by decide
theorem cert_e2422373281054 : check e2422373281054 [[],[]] .smaller = true := by decide
def e2422373281222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422373281222 : Closed e2422373281222 ∧ code e2422373281222 = 11218466303430 := by decide
theorem cert_e2422373281222 : check e2422373281222 [[],[]] .smaller = true := by decide
def e2422373281246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 3)))))))
theorem wire_e2422373281246 : Closed e2422373281246 ∧ code e2422373281246 = 11218466303454 := by decide
theorem cert_e2422373281246 : check e2422373281246 [[],[]] .three = true := by decide
def e2422373281250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422373281250 : Closed e2422373281250 ∧ code e2422373281250 = 11218466303458 := by decide
theorem cert_e2422373281250 : check e2422373281250 [[],[]] .three = true := by decide
def e2422373281262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))) (.var 2)))))))
theorem wire_e2422373281262 : Closed e2422373281262 ∧ code e2422373281262 = 11218466303470 := by decide
theorem cert_e2422373281262 : check e2422373281262 [[],[]] .three = true := by decide
def e2422373281290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373281290 : Closed e2422373281290 ∧ code e2422373281290 = 11218466303498 := by decide
theorem cert_e2422373281290 : check e2422373281290 [[],[]] .smaller = true := by decide
def e2422373281326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373281326 : Closed e2422373281326 ∧ code e2422373281326 = 11218466303534 := by decide
theorem cert_e2422373281326 : check e2422373281326 [[],[]] .smaller = true := by decide
def e2422373281334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373281334 : Closed e2422373281334 ∧ code e2422373281334 = 11218466303542 := by decide
theorem cert_e2422373281334 : check e2422373281334 [[],[]] .smaller = true := by decide
def e2422373281338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373281338 : Closed e2422373281338 ∧ code e2422373281338 = 11218466303546 := by decide
theorem cert_e2422373281338 : check e2422373281338 [[],[]] .smaller = true := by decide
def e2422373281386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373281386 : Closed e2422373281386 ∧ code e2422373281386 = 11218466303594 := by decide
theorem cert_e2422373281386 : check e2422373281386 [[],[]] .smaller = true := by decide
def e2422373281410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373281410 : Closed e2422373281410 ∧ code e2422373281410 = 11218466303618 := by decide
theorem cert_e2422373281410 : check e2422373281410 [[],[]] .smaller = true := by decide
def e2422373281422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373281422 : Closed e2422373281422 ∧ code e2422373281422 = 11218466303630 := by decide
theorem cert_e2422373281422 : check e2422373281422 [[],[]] .smaller = true := by decide
def e2422373281434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373281434 : Closed e2422373281434 ∧ code e2422373281434 = 11218466303642 := by decide
theorem cert_e2422373281434 : check e2422373281434 [[],[]] .smaller = true := by decide
def e2422373281478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373281478 : Closed e2422373281478 ∧ code e2422373281478 = 11218466303686 := by decide
theorem cert_e2422373281478 : check e2422373281478 [[],[]] .smaller = true := by decide
def e2422373281502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 3)))))))
theorem wire_e2422373281502 : Closed e2422373281502 ∧ code e2422373281502 = 11218466303710 := by decide
theorem cert_e2422373281502 : check e2422373281502 [[],[]] .three = true := by decide
def e2422373281506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373281506 : Closed e2422373281506 ∧ code e2422373281506 = 11218466303714 := by decide
theorem cert_e2422373281506 : check e2422373281506 [[],[]] .smaller = true := by decide
def e2422373281518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 2)))))))
theorem wire_e2422373281518 : Closed e2422373281518 ∧ code e2422373281518 = 11218466303726 := by decide
theorem cert_e2422373281518 : check e2422373281518 [[],[]] .smaller = true := by decide
def e2422373281526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3))) (.var 1)))))))
theorem wire_e2422373281526 : Closed e2422373281526 ∧ code e2422373281526 = 11218466303734 := by decide
theorem cert_e2422373281526 : check e2422373281526 [[],[]] .three = true := by decide
def e2422373281558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373281558 : Closed e2422373281558 ∧ code e2422373281558 = 11218466303766 := by decide
theorem cert_e2422373281558 : check e2422373281558 [[],[]] .three = true := by decide
def e2422373281562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373281562 : Closed e2422373281562 ∧ code e2422373281562 = 11218466303770 := by decide
theorem cert_e2422373281562 : check e2422373281562 [[],[]] .three = true := by decide
def e2422373281606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373281606 : Closed e2422373281606 ∧ code e2422373281606 = 11218466303814 := by decide
theorem cert_e2422373281606 : check e2422373281606 [[],[]] .three = true := by decide
def e2422373281630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 3)))))))
theorem wire_e2422373281630 : Closed e2422373281630 ∧ code e2422373281630 = 11218466303838 := by decide
theorem cert_e2422373281630 : check e2422373281630 [[],[]] .three = true := by decide
def e2422373281634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373281634 : Closed e2422373281634 ∧ code e2422373281634 = 11218466303842 := by decide
theorem cert_e2422373281634 : check e2422373281634 [[],[]] .three = true := by decide
def e2422373281646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))) (.var 2)))))))
theorem wire_e2422373281646 : Closed e2422373281646 ∧ code e2422373281646 = 11218466303854 := by decide
theorem cert_e2422373281646 : check e2422373281646 [[],[]] .three = true := by decide
def e2422373281654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2))) (.var 1)))))))
theorem wire_e2422373281654 : Closed e2422373281654 ∧ code e2422373281654 = 11218466303862 := by decide
theorem cert_e2422373281654 : check e2422373281654 [[],[]] .three = true := by decide
def e2422373281658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 3))) (.var 0)))))))
theorem wire_e2422373281658 : Closed e2422373281658 ∧ code e2422373281658 = 11218466303866 := by decide
theorem cert_e2422373281658 : check e2422373281658 [[],[]] .three = true := by decide
def e2422373281878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))) (.var 1)))))))
theorem wire_e2422373281878 : Closed e2422373281878 ∧ code e2422373281878 = 11218466304086 := by decide
theorem cert_e2422373281878 : check e2422373281878 [[],[]] .smaller = true := by decide
def e2422373281882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))) (.var 0)))))))
theorem wire_e2422373281882 : Closed e2422373281882 ∧ code e2422373281882 = 11218466304090 := by decide
theorem cert_e2422373281882 : check e2422373281882 [[],[]] .smaller = true := by decide
def e2422373282142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 3)))))))
theorem wire_e2422373282142 : Closed e2422373282142 ∧ code e2422373282142 = 11218466304350 := by decide
theorem cert_e2422373282142 : check e2422373282142 [[],[]] .three = true := by decide
def e2422373282158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 2)))))))
theorem wire_e2422373282158 : Closed e2422373282158 ∧ code e2422373282158 = 11218466304366 := by decide
theorem cert_e2422373282158 : check e2422373282158 [[],[]] .smaller = true := by decide
def e2422373282166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 2))) (.var 1)))))))
theorem wire_e2422373282166 : Closed e2422373282166 ∧ code e2422373282166 = 11218466304374 := by decide
theorem cert_e2422373282166 : check e2422373282166 [[],[]] .smaller = true := by decide
def e2422373282170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 3))) (.var 0)))))))
theorem wire_e2422373282170 : Closed e2422373282170 ∧ code e2422373282170 = 11218466304378 := by decide
theorem cert_e2422373282170 : check e2422373282170 [[],[]] .three = true := by decide
def e2422373282230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 1)))))))
theorem wire_e2422373282230 : Closed e2422373282230 ∧ code e2422373282230 = 11218466304438 := by decide
theorem cert_e2422373282230 : check e2422373282230 [[],[]] .smaller = true := by decide
def e2422373282262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 1)))))))
theorem wire_e2422373282262 : Closed e2422373282262 ∧ code e2422373282262 = 11218466304470 := by decide
theorem cert_e2422373282262 : check e2422373282262 [[],[]] .smaller = true := by decide
def e2422373282266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))) (.var 0)))))))
theorem wire_e2422373282266 : Closed e2422373282266 ∧ code e2422373282266 = 11218466304474 := by decide
theorem cert_e2422373282266 : check e2422373282266 [[],[]] .smaller = true := by decide
def e2422373282646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e2422373282646 : Closed e2422373282646 ∧ code e2422373282646 = 11218466304854 := by decide
theorem cert_e2422373282646 : check e2422373282646 [[],[]] .smaller = true := by decide
def e2422373282650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e2422373282650 : Closed e2422373282650 ∧ code e2422373282650 = 11218466304858 := by decide
theorem cert_e2422373282650 : check e2422373282650 [[],[]] .smaller = true := by decide
def e2422373282666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.var 0)))))))
theorem wire_e2422373282666 : Closed e2422373282666 ∧ code e2422373282666 = 11218466304874 := by decide
theorem cert_e2422373282666 : check e2422373282666 [[],[]] .smaller = true := by decide
def e2422373282730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e2422373282730 : Closed e2422373282730 ∧ code e2422373282730 = 11218466304938 := by decide
theorem cert_e2422373282730 : check e2422373282730 [[],[]] .smaller = true := by decide
def e2422373282838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373282838 : Closed e2422373282838 ∧ code e2422373282838 = 11218466305046 := by decide
theorem cert_e2422373282838 : check e2422373282838 [[],[]] .smaller = true := by decide
def e2422373282910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422373282910 : Closed e2422373282910 ∧ code e2422373282910 = 11218466305118 := by decide
theorem cert_e2422373282910 : check e2422373282910 [[],[]] .three = true := by decide
def e2422373282934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2422373282934 : Closed e2422373282934 ∧ code e2422373282934 = 11218466305142 := by decide
theorem cert_e2422373282934 : check e2422373282934 [[],[]] .smaller = true := by decide
def e2422373283030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2422373283030 : Closed e2422373283030 ∧ code e2422373283030 = 11218466305238 := by decide
theorem cert_e2422373283030 : check e2422373283030 [[],[]] .smaller = true := by decide
def e2422373283034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2422373283034 : Closed e2422373283034 ∧ code e2422373283034 = 11218466305242 := by decide
theorem cert_e2422373283034 : check e2422373283034 [[],[]] .smaller = true := by decide
def e2422373283050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2422373283050 : Closed e2422373283050 ∧ code e2422373283050 = 11218466305258 := by decide
theorem cert_e2422373283050 : check e2422373283050 [[],[]] .smaller = true := by decide
def e2422373283126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373283126 : Closed e2422373283126 ∧ code e2422373283126 = 11218466305334 := by decide
theorem cert_e2422373283126 : check e2422373283126 [[],[]] .smaller = true := by decide
def e2422373283130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373283130 : Closed e2422373283130 ∧ code e2422373283130 = 11218466305338 := by decide
theorem cert_e2422373283130 : check e2422373283130 [[],[]] .smaller = true := by decide
def e2422373283202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373283202 : Closed e2422373283202 ∧ code e2422373283202 = 11218466305410 := by decide
theorem cert_e2422373283202 : check e2422373283202 [[],[]] .smaller = true := by decide
def e2422373283214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2422373283214 : Closed e2422373283214 ∧ code e2422373283214 = 11218466305422 := by decide
theorem cert_e2422373283214 : check e2422373283214 [[],[]] .smaller = true := by decide
def e2422373283226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373283226 : Closed e2422373283226 ∧ code e2422373283226 = 11218466305434 := by decide
theorem cert_e2422373283226 : check e2422373283226 [[],[]] .smaller = true := by decide
def e2422373283294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 3)))))))
theorem wire_e2422373283294 : Closed e2422373283294 ∧ code e2422373283294 = 11218466305502 := by decide
theorem cert_e2422373283294 : check e2422373283294 [[],[]] .three = true := by decide
def e2422373283298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422373283298 : Closed e2422373283298 ∧ code e2422373283298 = 11218466305506 := by decide
theorem cert_e2422373283298 : check e2422373283298 [[],[]] .three = true := by decide
def e2422373283310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 2)))))))
theorem wire_e2422373283310 : Closed e2422373283310 ∧ code e2422373283310 = 11218466305518 := by decide
theorem cert_e2422373283310 : check e2422373283310 [[],[]] .three = true := by decide
def e2422373283338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373283338 : Closed e2422373283338 ∧ code e2422373283338 = 11218466305546 := by decide
theorem cert_e2422373283338 : check e2422373283338 [[],[]] .smaller = true := by decide
def e2422373283374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373283374 : Closed e2422373283374 ∧ code e2422373283374 = 11218466305582 := by decide
theorem cert_e2422373283374 : check e2422373283374 [[],[]] .smaller = true := by decide
def e2422373283382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373283382 : Closed e2422373283382 ∧ code e2422373283382 = 11218466305590 := by decide
theorem cert_e2422373283382 : check e2422373283382 [[],[]] .smaller = true := by decide
def e2422373283386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373283386 : Closed e2422373283386 ∧ code e2422373283386 = 11218466305594 := by decide
theorem cert_e2422373283386 : check e2422373283386 [[],[]] .smaller = true := by decide
def e2422373283434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373283434 : Closed e2422373283434 ∧ code e2422373283434 = 11218466305642 := by decide
theorem cert_e2422373283434 : check e2422373283434 [[],[]] .smaller = true := by decide
def e2422373283458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373283458 : Closed e2422373283458 ∧ code e2422373283458 = 11218466305666 := by decide
theorem cert_e2422373283458 : check e2422373283458 [[],[]] .smaller = true := by decide
def e2422373283470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373283470 : Closed e2422373283470 ∧ code e2422373283470 = 11218466305678 := by decide
theorem cert_e2422373283470 : check e2422373283470 [[],[]] .smaller = true := by decide
def e2422373283482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373283482 : Closed e2422373283482 ∧ code e2422373283482 = 11218466305690 := by decide
theorem cert_e2422373283482 : check e2422373283482 [[],[]] .smaller = true := by decide
def e2422373283526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373283526 : Closed e2422373283526 ∧ code e2422373283526 = 11218466305734 := by decide
theorem cert_e2422373283526 : check e2422373283526 [[],[]] .smaller = true := by decide
def e2422373283550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 3)))))))
theorem wire_e2422373283550 : Closed e2422373283550 ∧ code e2422373283550 = 11218466305758 := by decide
theorem cert_e2422373283550 : check e2422373283550 [[],[]] .three = true := by decide
def e2422373283554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373283554 : Closed e2422373283554 ∧ code e2422373283554 = 11218466305762 := by decide
theorem cert_e2422373283554 : check e2422373283554 [[],[]] .smaller = true := by decide
def e2422373283566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 2)))))))
theorem wire_e2422373283566 : Closed e2422373283566 ∧ code e2422373283566 = 11218466305774 := by decide
theorem cert_e2422373283566 : check e2422373283566 [[],[]] .smaller = true := by decide
def e2422373283574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3))) (.var 1)))))))
theorem wire_e2422373283574 : Closed e2422373283574 ∧ code e2422373283574 = 11218466305782 := by decide
theorem cert_e2422373283574 : check e2422373283574 [[],[]] .three = true := by decide
def e2422373283606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373283606 : Closed e2422373283606 ∧ code e2422373283606 = 11218466305814 := by decide
theorem cert_e2422373283606 : check e2422373283606 [[],[]] .smaller = true := by decide
def e2422373283678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 3)))))))
theorem wire_e2422373283678 : Closed e2422373283678 ∧ code e2422373283678 = 11218466305886 := by decide
theorem cert_e2422373283678 : check e2422373283678 [[],[]] .three = true := by decide
def e2422373283682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373283682 : Closed e2422373283682 ∧ code e2422373283682 = 11218466305890 := by decide
theorem cert_e2422373283682 : check e2422373283682 [[],[]] .smaller = true := by decide
def e2422373283694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 2)))))))
theorem wire_e2422373283694 : Closed e2422373283694 ∧ code e2422373283694 = 11218466305902 := by decide
theorem cert_e2422373283694 : check e2422373283694 [[],[]] .smaller = true := by decide
def e2422373283702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 2))) (.var 1)))))))
theorem wire_e2422373283702 : Closed e2422373283702 ∧ code e2422373283702 = 11218466305910 := by decide
theorem cert_e2422373283702 : check e2422373283702 [[],[]] .smaller = true := by decide
def e2422373283706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 3))) (.var 0)))))))
theorem wire_e2422373283706 : Closed e2422373283706 ∧ code e2422373283706 = 11218466305914 := by decide
theorem cert_e2422373283706 : check e2422373283706 [[],[]] .three = true := by decide
def e2422373283722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373283722 : Closed e2422373283722 ∧ code e2422373283722 = 11218466305930 := by decide
theorem cert_e2422373283722 : check e2422373283722 [[],[]] .three = true := by decide
def e2422373283746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373283746 : Closed e2422373283746 ∧ code e2422373283746 = 11218466305954 := by decide
theorem cert_e2422373283746 : check e2422373283746 [[],[]] .three = true := by decide
def e2422373283758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 2)))))))
theorem wire_e2422373283758 : Closed e2422373283758 ∧ code e2422373283758 = 11218466305966 := by decide
theorem cert_e2422373283758 : check e2422373283758 [[],[]] .three = true := by decide
def e2422373283766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1))) (.var 1)))))))
theorem wire_e2422373283766 : Closed e2422373283766 ∧ code e2422373283766 = 11218466305974 := by decide
theorem cert_e2422373283766 : check e2422373283766 [[],[]] .three = true := by decide
def e2422373283770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 2))) (.var 0)))))))
theorem wire_e2422373283770 : Closed e2422373283770 ∧ code e2422373283770 = 11218466305978 := by decide
theorem cert_e2422373283770 : check e2422373283770 [[],[]] .three = true := by decide
def e2422373284014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e2422373284014 : Closed e2422373284014 ∧ code e2422373284014 = 11218466306222 := by decide
theorem cert_e2422373284014 : check e2422373284014 [[],[]] .three = true := by decide
def e2422373284022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 1))) (.var 1)))))))
theorem wire_e2422373284022 : Closed e2422373284022 ∧ code e2422373284022 = 11218466306230 := by decide
theorem cert_e2422373284022 : check e2422373284022 [[],[]] .three = true := by decide
def e2422373284026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e2422373284026 : Closed e2422373284026 ∧ code e2422373284026 = 11218466306234 := by decide
theorem cert_e2422373284026 : check e2422373284026 [[],[]] .three = true := by decide
def e2422373284054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))) (.var 1)))))))
theorem wire_e2422373284054 : Closed e2422373284054 ∧ code e2422373284054 = 11218466306262 := by decide
theorem cert_e2422373284054 : check e2422373284054 [[],[]] .three = true := by decide
def e2422373284058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))) (.var 0)))))))
theorem wire_e2422373284058 : Closed e2422373284058 ∧ code e2422373284058 = 11218466306266 := by decide
theorem cert_e2422373284058 : check e2422373284058 [[],[]] .three = true := by decide
def e2422373284074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))) (.var 0)))))))
theorem wire_e2422373284074 : Closed e2422373284074 ∧ code e2422373284074 = 11218466306282 := by decide
theorem cert_e2422373284074 : check e2422373284074 [[],[]] .three = true := by decide
def e2422373284398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373284398 : Closed e2422373284398 ∧ code e2422373284398 = 11218466306606 := by decide
theorem cert_e2422373284398 : check e2422373284398 [[],[]] .three = true := by decide
def e2422373284406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373284406 : Closed e2422373284406 ∧ code e2422373284406 = 11218466306614 := by decide
theorem cert_e2422373284406 : check e2422373284406 [[],[]] .three = true := by decide
def e2422373284410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373284410 : Closed e2422373284410 ∧ code e2422373284410 = 11218466306618 := by decide
theorem cert_e2422373284410 : check e2422373284410 [[],[]] .three = true := by decide
def e2422373284494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373284494 : Closed e2422373284494 ∧ code e2422373284494 = 11218466306702 := by decide
theorem cert_e2422373284494 : check e2422373284494 [[],[]] .three = true := by decide
def e2422373284550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373284550 : Closed e2422373284550 ∧ code e2422373284550 = 11218466306758 := by decide
theorem cert_e2422373284550 : check e2422373284550 [[],[]] .three = true := by decide
def e2422373284574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e2422373284574 : Closed e2422373284574 ∧ code e2422373284574 = 11218466306782 := by decide
theorem cert_e2422373284574 : check e2422373284574 [[],[]] .three = true := by decide
def e2422373284578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373284578 : Closed e2422373284578 ∧ code e2422373284578 = 11218466306786 := by decide
theorem cert_e2422373284578 : check e2422373284578 [[],[]] .three = true := by decide
def e2422373284590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 2)))))))
theorem wire_e2422373284590 : Closed e2422373284590 ∧ code e2422373284590 = 11218466306798 := by decide
theorem cert_e2422373284590 : check e2422373284590 [[],[]] .three = true := by decide
def e2422373284598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e2422373284598 : Closed e2422373284598 ∧ code e2422373284598 = 11218466306806 := by decide
theorem cert_e2422373284598 : check e2422373284598 [[],[]] .three = true := by decide
def e2422373284630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373284630 : Closed e2422373284630 ∧ code e2422373284630 = 11218466306838 := by decide
theorem cert_e2422373284630 : check e2422373284630 [[],[]] .three = true := by decide
def e2422373284634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373284634 : Closed e2422373284634 ∧ code e2422373284634 = 11218466306842 := by decide
theorem cert_e2422373284634 : check e2422373284634 [[],[]] .three = true := by decide
def e2422373284678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373284678 : Closed e2422373284678 ∧ code e2422373284678 = 11218466306886 := by decide
theorem cert_e2422373284678 : check e2422373284678 [[],[]] .three = true := by decide
def e2422373284702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e2422373284702 : Closed e2422373284702 ∧ code e2422373284702 = 11218466306910 := by decide
theorem cert_e2422373284702 : check e2422373284702 [[],[]] .three = true := by decide
def e2422373284706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373284706 : Closed e2422373284706 ∧ code e2422373284706 = 11218466306914 := by decide
theorem cert_e2422373284706 : check e2422373284706 [[],[]] .three = true := by decide
def e2422373284718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e2422373284718 : Closed e2422373284718 ∧ code e2422373284718 = 11218466306926 := by decide
theorem cert_e2422373284718 : check e2422373284718 [[],[]] .three = true := by decide
def e2422373284726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e2422373284726 : Closed e2422373284726 ∧ code e2422373284726 = 11218466306934 := by decide
theorem cert_e2422373284726 : check e2422373284726 [[],[]] .three = true := by decide
def e2422373284730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e2422373284730 : Closed e2422373284730 ∧ code e2422373284730 = 11218466306938 := by decide
theorem cert_e2422373284730 : check e2422373284730 [[],[]] .three = true := by decide
def e2422373284746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373284746 : Closed e2422373284746 ∧ code e2422373284746 = 11218466306954 := by decide
theorem cert_e2422373284746 : check e2422373284746 [[],[]] .three = true := by decide
def e2422373284770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373284770 : Closed e2422373284770 ∧ code e2422373284770 = 11218466306978 := by decide
theorem cert_e2422373284770 : check e2422373284770 [[],[]] .three = true := by decide
def e2422373284782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 2)))))))
theorem wire_e2422373284782 : Closed e2422373284782 ∧ code e2422373284782 = 11218466306990 := by decide
theorem cert_e2422373284782 : check e2422373284782 [[],[]] .three = true := by decide
def e2422373284790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e2422373284790 : Closed e2422373284790 ∧ code e2422373284790 = 11218466306998 := by decide
theorem cert_e2422373284790 : check e2422373284790 [[],[]] .three = true := by decide
def e2422373284794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 2))) (.var 0)))))))
theorem wire_e2422373284794 : Closed e2422373284794 ∧ code e2422373284794 = 11218466307002 := by decide
theorem cert_e2422373284794 : check e2422373284794 [[],[]] .three = true := by decide
def e2422373284822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e2422373284822 : Closed e2422373284822 ∧ code e2422373284822 = 11218466307030 := by decide
theorem cert_e2422373284822 : check e2422373284822 [[],[]] .three = true := by decide
def e2422373284826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e2422373284826 : Closed e2422373284826 ∧ code e2422373284826 = 11218466307034 := by decide
theorem cert_e2422373284826 : check e2422373284826 [[],[]] .three = true := by decide
def e2422373287150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373287150 : Closed e2422373287150 ∧ code e2422373287150 = 11218466309358 := by decide
theorem cert_e2422373287150 : check e2422373287150 [[],[]] .smaller = true := by decide
def e2422373287158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373287158 : Closed e2422373287158 ∧ code e2422373287158 = 11218466309366 := by decide
theorem cert_e2422373287158 : check e2422373287158 [[],[]] .smaller = true := by decide
def e2422373287902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 3)))))))
theorem wire_e2422373287902 : Closed e2422373287902 ∧ code e2422373287902 = 11218466310110 := by decide
theorem cert_e2422373287902 : check e2422373287902 [[],[]] .three = true := by decide
def e2422373287918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 5))))) (.var 2)))))))
theorem wire_e2422373287918 : Closed e2422373287918 ∧ code e2422373287918 = 11218466310126 := by decide
theorem cert_e2422373287918 : check e2422373287918 [[],[]] .three = true := by decide
def e2422373289438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 3)))))))
theorem wire_e2422373289438 : Closed e2422373289438 ∧ code e2422373289438 = 11218466311646 := by decide
theorem cert_e2422373289438 : check e2422373289438 [[],[]] .three = true := by decide
def e2422373289462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 4))))) (.var 1)))))))
theorem wire_e2422373289462 : Closed e2422373289462 ∧ code e2422373289462 = 11218466311670 := by decide
theorem cert_e2422373289462 : check e2422373289462 [[],[]] .three = true := by decide
def e2422373289710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))) (.var 2)))))))
theorem wire_e2422373289710 : Closed e2422373289710 ∧ code e2422373289710 = 11218466311918 := by decide
theorem cert_e2422373289710 : check e2422373289710 [[],[]] .smaller = true := by decide
def e2422373289718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))) (.var 1)))))))
theorem wire_e2422373289718 : Closed e2422373289718 ∧ code e2422373289718 = 11218466311926 := by decide
theorem cert_e2422373289718 : check e2422373289718 [[],[]] .smaller = true := by decide
def e2422373289822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 3)))))))
theorem wire_e2422373289822 : Closed e2422373289822 ∧ code e2422373289822 = 11218466312030 := by decide
theorem cert_e2422373289822 : check e2422373289822 [[],[]] .three = true := by decide
def e2422373289838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))) (.var 2)))))))
theorem wire_e2422373289838 : Closed e2422373289838 ∧ code e2422373289838 = 11218466312046 := by decide
theorem cert_e2422373289838 : check e2422373289838 [[],[]] .smaller = true := by decide
def e2422373289850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))) (.var 0)))))))
theorem wire_e2422373289850 : Closed e2422373289850 ∧ code e2422373289850 = 11218466312058 := by decide
theorem cert_e2422373289850 : check e2422373289850 [[],[]] .smaller = true := by decide
def e2422373289910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))) (.var 1)))))))
theorem wire_e2422373289910 : Closed e2422373289910 ∧ code e2422373289910 = 11218466312118 := by decide
theorem cert_e2422373289910 : check e2422373289910 [[],[]] .smaller = true := by decide
def e2422373289914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))) (.var 0)))))))
theorem wire_e2422373289914 : Closed e2422373289914 ∧ code e2422373289914 = 11218466312122 := by decide
theorem cert_e2422373289914 : check e2422373289914 [[],[]] .smaller = true := by decide
def e2422373289942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.var 0))))) (.var 1)))))))
theorem wire_e2422373289942 : Closed e2422373289942 ∧ code e2422373289942 = 11218466312150 := by decide
theorem cert_e2422373289942 : check e2422373289942 [[],[]] .three = true := by decide
def e2422373290974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373290974 : Closed e2422373290974 ∧ code e2422373290974 = 11218466313182 := by decide
theorem cert_e2422373290974 : check e2422373290974 [[],[]] .three = true := by decide
def e2422373290990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373290990 : Closed e2422373290990 ∧ code e2422373290990 = 11218466313198 := by decide
theorem cert_e2422373290990 : check e2422373290990 [[],[]] .three = true := by decide
def e2422373292510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373292510 : Closed e2422373292510 ∧ code e2422373292510 = 11218466314718 := by decide
theorem cert_e2422373292510 : check e2422373292510 [[],[]] .three = true := by decide
def e2422373292534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373292534 : Closed e2422373292534 ∧ code e2422373292534 = 11218466314742 := by decide
theorem cert_e2422373292534 : check e2422373292534 [[],[]] .three = true := by decide
def e2422373293278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373293278 : Closed e2422373293278 ∧ code e2422373293278 = 11218466315486 := by decide
theorem cert_e2422373293278 : check e2422373293278 [[],[]] .three = true := by decide
def e2422373293294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373293294 : Closed e2422373293294 ∧ code e2422373293294 = 11218466315502 := by decide
theorem cert_e2422373293294 : check e2422373293294 [[],[]] .smaller = true := by decide
def e2422373293302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373293302 : Closed e2422373293302 ∧ code e2422373293302 = 11218466315510 := by decide
theorem cert_e2422373293302 : check e2422373293302 [[],[]] .smaller = true := by decide
def e2422373293306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373293306 : Closed e2422373293306 ∧ code e2422373293306 = 11218466315514 := by decide
theorem cert_e2422373293306 : check e2422373293306 [[],[]] .three = true := by decide
def e2422373293630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 4))))))))
theorem wire_e2422373293630 : Closed e2422373293630 ∧ code e2422373293630 = 11218466315838 := by decide
theorem cert_e2422373293630 : check e2422373293630 [[],[]] .three = true := by decide
def e2422373293686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373293686 : Closed e2422373293686 ∧ code e2422373293686 = 11218466315894 := by decide
theorem cert_e2422373293686 : check e2422373293686 [[],[]] .smaller = true := by decide
def e2422373293854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.lam (.var 3))))))))
theorem wire_e2422373293854 : Closed e2422373293854 ∧ code e2422373293854 = 11218466316062 := by decide
theorem cert_e2422373293854 : check e2422373293854 [[],[]] .three = true := by decide
def e2422373293878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373293878 : Closed e2422373293878 ∧ code e2422373293878 = 11218466316086 := by decide
theorem cert_e2422373293878 : check e2422373293878 [[],[]] .three = true := by decide
def e2422373293882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373293882 : Closed e2422373293882 ∧ code e2422373293882 = 11218466316090 := by decide
theorem cert_e2422373293882 : check e2422373293882 [[],[]] .three = true := by decide
def e2422373297518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 2)))))))
theorem wire_e2422373297518 : Closed e2422373297518 ∧ code e2422373297518 = 11218466319726 := by decide
theorem cert_e2422373297518 : check e2422373297518 [[],[]] .smaller = true := by decide
def e2422373297526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 1)))))))
theorem wire_e2422373297526 : Closed e2422373297526 ∧ code e2422373297526 = 11218466319734 := by decide
theorem cert_e2422373297526 : check e2422373297526 [[],[]] .smaller = true := by decide
def e2422373297582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 2)))))))
theorem wire_e2422373297582 : Closed e2422373297582 ∧ code e2422373297582 = 11218466319790 := by decide
theorem cert_e2422373297582 : check e2422373297582 [[],[]] .smaller = true := by decide
def e2422373297594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))))
theorem wire_e2422373297594 : Closed e2422373297594 ∧ code e2422373297594 = 11218466319802 := by decide
theorem cert_e2422373297594 : check e2422373297594 [[],[]] .smaller = true := by decide
def e2422373297622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373297622 : Closed e2422373297622 ∧ code e2422373297622 = 11218466319830 := by decide
theorem cert_e2422373297622 : check e2422373297622 [[],[]] .smaller = true := by decide
def e2422373297626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373297626 : Closed e2422373297626 ∧ code e2422373297626 = 11218466319834 := by decide
theorem cert_e2422373297626 : check e2422373297626 [[],[]] .smaller = true := by decide
def e2422373297838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 2)))))))
theorem wire_e2422373297838 : Closed e2422373297838 ∧ code e2422373297838 = 11218466320046 := by decide
theorem cert_e2422373297838 : check e2422373297838 [[],[]] .smaller = true := by decide
def e2422373297850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e2422373297850 : Closed e2422373297850 ∧ code e2422373297850 = 11218466320058 := by decide
theorem cert_e2422373297850 : check e2422373297850 [[],[]] .smaller = true := by decide
def e2422373297898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373297898 : Closed e2422373297898 ∧ code e2422373297898 = 11218466320106 := by decide
theorem cert_e2422373297898 : check e2422373297898 [[],[]] .smaller = true := by decide
def e2422373298006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373298006 : Closed e2422373298006 ∧ code e2422373298006 = 11218466320214 := by decide
theorem cert_e2422373298006 : check e2422373298006 [[],[]] .smaller = true := by decide
def e2422373298010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373298010 : Closed e2422373298010 ∧ code e2422373298010 = 11218466320218 := by decide
theorem cert_e2422373298010 : check e2422373298010 [[],[]] .smaller = true := by decide
def e2422373298026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373298026 : Closed e2422373298026 ∧ code e2422373298026 = 11218466320234 := by decide
theorem cert_e2422373298026 : check e2422373298026 [[],[]] .smaller = true := by decide
def e2422373298654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 3)))))))
theorem wire_e2422373298654 : Closed e2422373298654 ∧ code e2422373298654 = 11218466320862 := by decide
theorem cert_e2422373298654 : check e2422373298654 [[],[]] .three = true := by decide
def e2422373298678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))) (.var 1)))))))
theorem wire_e2422373298678 : Closed e2422373298678 ∧ code e2422373298678 = 11218466320886 := by decide
theorem cert_e2422373298678 : check e2422373298678 [[],[]] .three = true := by decide
def e2422373299054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 2)))))))
theorem wire_e2422373299054 : Closed e2422373299054 ∧ code e2422373299054 = 11218466321262 := by decide
theorem cert_e2422373299054 : check e2422373299054 [[],[]] .smaller = true := by decide
def e2422373299062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 1)))))))
theorem wire_e2422373299062 : Closed e2422373299062 ∧ code e2422373299062 = 11218466321270 := by decide
theorem cert_e2422373299062 : check e2422373299062 [[],[]] .smaller = true := by decide
def e2422373299118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 2)))))))
theorem wire_e2422373299118 : Closed e2422373299118 ∧ code e2422373299118 = 11218466321326 := by decide
theorem cert_e2422373299118 : check e2422373299118 [[],[]] .smaller = true := by decide
def e2422373299130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))))
theorem wire_e2422373299130 : Closed e2422373299130 ∧ code e2422373299130 = 11218466321338 := by decide
theorem cert_e2422373299130 : check e2422373299130 [[],[]] .smaller = true := by decide
def e2422373299158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 1)))))))
theorem wire_e2422373299158 : Closed e2422373299158 ∧ code e2422373299158 = 11218466321366 := by decide
theorem cert_e2422373299158 : check e2422373299158 [[],[]] .smaller = true := by decide
def e2422373299162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))))
theorem wire_e2422373299162 : Closed e2422373299162 ∧ code e2422373299162 = 11218466321370 := by decide
theorem cert_e2422373299162 : check e2422373299162 [[],[]] .smaller = true := by decide
def e2422373299438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373299438 : Closed e2422373299438 ∧ code e2422373299438 = 11218466321646 := by decide
theorem cert_e2422373299438 : check e2422373299438 [[],[]] .smaller = true := by decide
def e2422373299446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373299446 : Closed e2422373299446 ∧ code e2422373299446 = 11218466321654 := by decide
theorem cert_e2422373299446 : check e2422373299446 [[],[]] .smaller = true := by decide
def e2422373299774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 4))))))))
theorem wire_e2422373299774 : Closed e2422373299774 ∧ code e2422373299774 = 11218466321982 := by decide
theorem cert_e2422373299774 : check e2422373299774 [[],[]] .three = true := by decide
def e2422373299822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373299822 : Closed e2422373299822 ∧ code e2422373299822 = 11218466322030 := by decide
theorem cert_e2422373299822 : check e2422373299822 [[],[]] .smaller = true := by decide
def e2422373299834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373299834 : Closed e2422373299834 ∧ code e2422373299834 = 11218466322042 := by decide
theorem cert_e2422373299834 : check e2422373299834 [[],[]] .smaller = true := by decide
end Blc.Floor43
