import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604634131926 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e604634131926 : Closed e604634131926 ∧ code e604634131926 = 9400727154134 := by decide
theorem cert_e604634131926 : check e604634131926 [[.under],[.under]] .three = true := by decide
def e604634131930 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e604634131930 : Closed e604634131930 ∧ code e604634131930 = 9400727154138 := by decide
theorem cert_e604634131930 : check e604634131930 [[.under],[.under]] .three = true := by decide
def e604634132142 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e604634132142 : Closed e604634132142 ∧ code e604634132142 = 9400727154350 := by decide
theorem cert_e604634132142 : check e604634132142 [[.under],[.under]] .three = true := by decide
def e604634132154 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e604634132154 : Closed e604634132154 ∧ code e604634132154 = 9400727154362 := by decide
theorem cert_e604634132154 : check e604634132154 [[.under],[.under]] .three = true := by decide
def e604634132202 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e604634132202 : Closed e604634132202 ∧ code e604634132202 = 9400727154410 := by decide
theorem cert_e604634132202 : check e604634132202 [[.under],[.under]] .three = true := by decide
def e604634132310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e604634132310 : Closed e604634132310 ∧ code e604634132310 = 9400727154518 := by decide
theorem cert_e604634132310 : check e604634132310 [[.under],[.under]] .three = true := by decide
def e604634132314 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e604634132314 : Closed e604634132314 ∧ code e604634132314 = 9400727154522 := by decide
theorem cert_e604634132314 : check e604634132314 [[.under],[.under]] .three = true := by decide
def e604634132330 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e604634132330 : Closed e604634132330 ∧ code e604634132330 = 9400727154538 := by decide
theorem cert_e604634132330 : check e604634132330 [[.under],[.under]] .three = true := by decide
def e604634133358 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e604634133358 : Closed e604634133358 ∧ code e604634133358 = 9400727155566 := by decide
theorem cert_e604634133358 : check e604634133358 [[.under],[.under]] .three = true := by decide
def e604634133366 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e604634133366 : Closed e604634133366 ∧ code e604634133366 = 9400727155574 := by decide
theorem cert_e604634133366 : check e604634133366 [[.under],[.under]] .three = true := by decide
def e604634133422 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e604634133422 : Closed e604634133422 ∧ code e604634133422 = 9400727155630 := by decide
theorem cert_e604634133422 : check e604634133422 [[.under],[.under]] .three = true := by decide
def e604634133434 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e604634133434 : Closed e604634133434 ∧ code e604634133434 = 9400727155642 := by decide
theorem cert_e604634133434 : check e604634133434 [[.under],[.under]] .three = true := by decide
def e604634133462 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e604634133462 : Closed e604634133462 ∧ code e604634133462 = 9400727155670 := by decide
theorem cert_e604634133462 : check e604634133462 [[.under],[.under]] .three = true := by decide
def e604634133466 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e604634133466 : Closed e604634133466 ∧ code e604634133466 = 9400727155674 := by decide
theorem cert_e604634133466 : check e604634133466 [[.under],[.under]] .three = true := by decide
def e604634133742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e604634133742 : Closed e604634133742 ∧ code e604634133742 = 9400727155950 := by decide
theorem cert_e604634133742 : check e604634133742 [[.under],[.under]] .three = true := by decide
def e604634133750 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e604634133750 : Closed e604634133750 ∧ code e604634133750 = 9400727155958 := by decide
theorem cert_e604634133750 : check e604634133750 [[.under],[.under]] .three = true := by decide
def e604634134126 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e604634134126 : Closed e604634134126 ∧ code e604634134126 = 9400727156334 := by decide
theorem cert_e604634134126 : check e604634134126 [[.under],[.under]] .three = true := by decide
def e604634134138 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e604634134138 : Closed e604634134138 ∧ code e604634134138 = 9400727156346 := by decide
theorem cert_e604634134138 : check e604634134138 [[.under],[.under]] .three = true := by decide
def e604634134326 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e604634134326 : Closed e604634134326 ∧ code e604634134326 = 9400727156534 := by decide
theorem cert_e604634134326 : check e604634134326 [[.under],[.under]] .three = true := by decide
def e604634134330 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e604634134330 : Closed e604634134330 ∧ code e604634134330 = 9400727156538 := by decide
theorem cert_e604634134330 : check e604634134330 [[.under],[.under]] .three = true := by decide
def e604634134958 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e604634134958 : Closed e604634134958 ∧ code e604634134958 = 9400727157166 := by decide
theorem cert_e604634134958 : check e604634134958 [[.under],[.under]] .three = true := by decide
def e604634134970 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e604634134970 : Closed e604634134970 ∧ code e604634134970 = 9400727157178 := by decide
theorem cert_e604634134970 : check e604634134970 [[.under],[.under]] .three = true := by decide
def e604634135018 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e604634135018 : Closed e604634135018 ∧ code e604634135018 = 9400727157226 := by decide
theorem cert_e604634135018 : check e604634135018 [[.under],[.under]] .three = true := by decide
def e604634135150 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e604634135150 : Closed e604634135150 ∧ code e604634135150 = 9400727157358 := by decide
theorem cert_e604634135150 : check e604634135150 [[.under],[.under]] .three = true := by decide
def e604634135162 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e604634135162 : Closed e604634135162 ∧ code e604634135162 = 9400727157370 := by decide
theorem cert_e604634135162 : check e604634135162 [[.under],[.under]] .three = true := by decide
def e604634135450 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e604634135450 : Closed e604634135450 ∧ code e604634135450 = 9400727157658 := by decide
theorem cert_e604634135450 : check e604634135450 [[.under],[.under]] .three = true := by decide
def e604634135766 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e604634135766 : Closed e604634135766 ∧ code e604634135766 = 9400727157974 := by decide
theorem cert_e604634135766 : check e604634135766 [[.under],[.under]] .three = true := by decide
def e604634135770 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e604634135770 : Closed e604634135770 ∧ code e604634135770 = 9400727157978 := by decide
theorem cert_e604634135770 : check e604634135770 [[.under],[.under]] .three = true := by decide
def e604634135786 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e604634135786 : Closed e604634135786 ∧ code e604634135786 = 9400727157994 := by decide
theorem cert_e604634135786 : check e604634135786 [[.under],[.under]] .three = true := by decide
def e604634135862 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e604634135862 : Closed e604634135862 ∧ code e604634135862 = 9400727158070 := by decide
theorem cert_e604634135862 : check e604634135862 [[.under],[.under]] .three = true := by decide
def e604634135866 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e604634135866 : Closed e604634135866 ∧ code e604634135866 = 9400727158074 := by decide
theorem cert_e604634135866 : check e604634135866 [[.under],[.under]] .three = true := by decide
def e604634135962 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e604634135962 : Closed e604634135962 ∧ code e604634135962 = 9400727158170 := by decide
theorem cert_e604634135962 : check e604634135962 [[.under],[.under]] .three = true := by decide
def e604634139502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604634139502 : Closed e604634139502 ∧ code e604634139502 = 9400727161710 := by decide
theorem cert_e604634139502 : check e604634139502 [[.under],[.under]] .three = true := by decide
def e604634139510 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604634139510 : Closed e604634139510 ∧ code e604634139510 = 9400727161718 := by decide
theorem cert_e604634139510 : check e604634139510 [[.under],[.under]] .three = true := by decide
def e604634139566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604634139566 : Closed e604634139566 ∧ code e604634139566 = 9400727161774 := by decide
theorem cert_e604634139566 : check e604634139566 [[.under],[.under]] .three = true := by decide
def e604634139578 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604634139578 : Closed e604634139578 ∧ code e604634139578 = 9400727161786 := by decide
theorem cert_e604634139578 : check e604634139578 [[.under],[.under]] .three = true := by decide
def e604634139606 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604634139606 : Closed e604634139606 ∧ code e604634139606 = 9400727161814 := by decide
theorem cert_e604634139606 : check e604634139606 [[.under],[.under]] .three = true := by decide
def e604634139610 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604634139610 : Closed e604634139610 ∧ code e604634139610 = 9400727161818 := by decide
theorem cert_e604634139610 : check e604634139610 [[.under],[.under]] .three = true := by decide
def e604634139886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604634139886 : Closed e604634139886 ∧ code e604634139886 = 9400727162094 := by decide
theorem cert_e604634139886 : check e604634139886 [[.under],[.under]] .three = true := by decide
def e604634139894 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604634139894 : Closed e604634139894 ∧ code e604634139894 = 9400727162102 := by decide
theorem cert_e604634139894 : check e604634139894 [[.under],[.under]] .three = true := by decide
def e604634140270 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604634140270 : Closed e604634140270 ∧ code e604634140270 = 9400727162478 := by decide
theorem cert_e604634140270 : check e604634140270 [[.under],[.under]] .three = true := by decide
def e604634140282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604634140282 : Closed e604634140282 ∧ code e604634140282 = 9400727162490 := by decide
theorem cert_e604634140282 : check e604634140282 [[.under],[.under]] .three = true := by decide
def e604634140470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604634140470 : Closed e604634140470 ∧ code e604634140470 = 9400727162678 := by decide
theorem cert_e604634140470 : check e604634140470 [[.under],[.under]] .three = true := by decide
def e604634140474 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604634140474 : Closed e604634140474 ∧ code e604634140474 = 9400727162682 := by decide
theorem cert_e604634140474 : check e604634140474 [[.under],[.under]] .three = true := by decide
def e604634146222 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e604634146222 : Closed e604634146222 ∧ code e604634146222 = 9400727168430 := by decide
theorem cert_e604634146222 : check e604634146222 [[.under],[.under]] .three = true := by decide
def e604634146234 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e604634146234 : Closed e604634146234 ∧ code e604634146234 = 9400727168442 := by decide
theorem cert_e604634146234 : check e604634146234 [[.under],[.under]] .three = true := by decide
def e604634146282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e604634146282 : Closed e604634146282 ∧ code e604634146282 = 9400727168490 := by decide
theorem cert_e604634146282 : check e604634146282 [[.under],[.under]] .three = true := by decide
def e604634146414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e604634146414 : Closed e604634146414 ∧ code e604634146414 = 9400727168622 := by decide
theorem cert_e604634146414 : check e604634146414 [[.under],[.under]] .three = true := by decide
def e604634146426 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e604634146426 : Closed e604634146426 ∧ code e604634146426 = 9400727168634 := by decide
theorem cert_e604634146426 : check e604634146426 [[.under],[.under]] .three = true := by decide
def e604634146714 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e604634146714 : Closed e604634146714 ∧ code e604634146714 = 9400727168922 := by decide
theorem cert_e604634146714 : check e604634146714 [[.under],[.under]] .three = true := by decide
def e604634149590 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e604634149590 : Closed e604634149590 ∧ code e604634149590 = 9400727171798 := by decide
theorem cert_e604634149590 : check e604634149590 [[.under],[.under]] .three = true := by decide
def e604634149594 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e604634149594 : Closed e604634149594 ∧ code e604634149594 = 9400727171802 := by decide
theorem cert_e604634149594 : check e604634149594 [[.under],[.under]] .three = true := by decide
def e604634149610 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e604634149610 : Closed e604634149610 ∧ code e604634149610 = 9400727171818 := by decide
theorem cert_e604634149610 : check e604634149610 [[.under],[.under]] .three = true := by decide
def e604634149686 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e604634149686 : Closed e604634149686 ∧ code e604634149686 = 9400727171894 := by decide
theorem cert_e604634149686 : check e604634149686 [[.under],[.under]] .three = true := by decide
def e604634149690 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e604634149690 : Closed e604634149690 ∧ code e604634149690 = 9400727171898 := by decide
theorem cert_e604634149690 : check e604634149690 [[.under],[.under]] .three = true := by decide
def e604634149786 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e604634149786 : Closed e604634149786 ∧ code e604634149786 = 9400727171994 := by decide
theorem cert_e604634149786 : check e604634149786 [[.under],[.under]] .three = true := by decide
def e604634286958 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604634286958 : Closed e604634286958 ∧ code e604634286958 = 9400727309166 := by decide
theorem cert_e604634286958 : check e604634286958 [[.under],[.under]] .chain = true := by decide
def e604634286966 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604634286966 : Closed e604634286966 ∧ code e604634286966 = 9400727309174 := by decide
theorem cert_e604634286966 : check e604634286966 [[.under],[.under]] .chain = true := by decide
def e604634287022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604634287022 : Closed e604634287022 ∧ code e604634287022 = 9400727309230 := by decide
theorem cert_e604634287022 : check e604634287022 [[.under],[.under]] .chain = true := by decide
def e604634287034 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604634287034 : Closed e604634287034 ∧ code e604634287034 = 9400727309242 := by decide
theorem cert_e604634287034 : check e604634287034 [[.under],[.under]] .chain = true := by decide
def e604634287062 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604634287062 : Closed e604634287062 ∧ code e604634287062 = 9400727309270 := by decide
theorem cert_e604634287062 : check e604634287062 [[.under],[.under]] .chain = true := by decide
def e604634287066 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604634287066 : Closed e604634287066 ∧ code e604634287066 = 9400727309274 := by decide
theorem cert_e604634287066 : check e604634287066 [[.under],[.under]] .chain = true := by decide
def e604634287342 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604634287342 : Closed e604634287342 ∧ code e604634287342 = 9400727309550 := by decide
theorem cert_e604634287342 : check e604634287342 [[.under],[.under]] .chain = true := by decide
def e604634287350 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604634287350 : Closed e604634287350 ∧ code e604634287350 = 9400727309558 := by decide
theorem cert_e604634287350 : check e604634287350 [[.under],[.under]] .chain = true := by decide
def e604634287726 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604634287726 : Closed e604634287726 ∧ code e604634287726 = 9400727309934 := by decide
theorem cert_e604634287726 : check e604634287726 [[.under],[.under]] .chain = true := by decide
def e604634287738 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604634287738 : Closed e604634287738 ∧ code e604634287738 = 9400727309946 := by decide
theorem cert_e604634287738 : check e604634287738 [[.under],[.under]] .chain = true := by decide
def e604634287926 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604634287926 : Closed e604634287926 ∧ code e604634287926 = 9400727310134 := by decide
theorem cert_e604634287926 : check e604634287926 [[.under],[.under]] .chain = true := by decide
def e604634287930 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604634287930 : Closed e604634287930 ∧ code e604634287930 = 9400727310138 := by decide
theorem cert_e604634287930 : check e604634287930 [[.under],[.under]] .chain = true := by decide
def e604634876782 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e604634876782 : Closed e604634876782 ∧ code e604634876782 = 9400727898990 := by decide
theorem cert_e604634876782 : check e604634876782 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634876790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e604634876790 : Closed e604634876790 ∧ code e604634876790 = 9400727898998 := by decide
theorem cert_e604634876790 : check e604634876790 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634876846 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e604634876846 : Closed e604634876846 ∧ code e604634876846 = 9400727899054 := by decide
theorem cert_e604634876846 : check e604634876846 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634876858 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e604634876858 : Closed e604634876858 ∧ code e604634876858 = 9400727899066 := by decide
theorem cert_e604634876858 : check e604634876858 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634876886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e604634876886 : Closed e604634876886 ∧ code e604634876886 = 9400727899094 := by decide
theorem cert_e604634876886 : check e604634876886 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634876890 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e604634876890 : Closed e604634876890 ∧ code e604634876890 = 9400727899098 := by decide
theorem cert_e604634876890 : check e604634876890 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634877166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e604634877166 : Closed e604634877166 ∧ code e604634877166 = 9400727899374 := by decide
theorem cert_e604634877166 : check e604634877166 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634877174 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e604634877174 : Closed e604634877174 ∧ code e604634877174 = 9400727899382 := by decide
theorem cert_e604634877174 : check e604634877174 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634877550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e604634877550 : Closed e604634877550 ∧ code e604634877550 = 9400727899758 := by decide
theorem cert_e604634877550 : check e604634877550 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634877562 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e604634877562 : Closed e604634877562 ∧ code e604634877562 = 9400727899770 := by decide
theorem cert_e604634877562 : check e604634877562 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634877750 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e604634877750 : Closed e604634877750 ∧ code e604634877750 = 9400727899958 := by decide
theorem cert_e604634877750 : check e604634877750 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604634877754 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e604634877754 : Closed e604634877754 ∧ code e604634877754 = 9400727899962 := by decide
theorem cert_e604634877754 : check e604634877754 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604835458414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e604835458414 : Closed e604835458414 ∧ code e604835458414 = 9400928480622 := by decide
theorem cert_e604835458414 : check e604835458414 [[.under]] .sourceHead = true := by decide
def e604835458422 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e604835458422 : Closed e604835458422 ∧ code e604835458422 = 9400928480630 := by decide
theorem cert_e604835458422 : check e604835458422 [[.under]] .sourceHead = true := by decide
def e604835458478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e604835458478 : Closed e604835458478 ∧ code e604835458478 = 9400928480686 := by decide
theorem cert_e604835458478 : check e604835458478 [[.under]] .sourceHead = true := by decide
def e604835458490 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e604835458490 : Closed e604835458490 ∧ code e604835458490 = 9400928480698 := by decide
theorem cert_e604835458490 : check e604835458490 [[.under]] .sourceHead = true := by decide
def e604835458518 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e604835458518 : Closed e604835458518 ∧ code e604835458518 = 9400928480726 := by decide
theorem cert_e604835458518 : check e604835458518 [[.under]] .sourceHead = true := by decide
def e604835458522 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e604835458522 : Closed e604835458522 ∧ code e604835458522 = 9400928480730 := by decide
theorem cert_e604835458522 : check e604835458522 [[.under]] .sourceHead = true := by decide
def e604835458734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e604835458734 : Closed e604835458734 ∧ code e604835458734 = 9400928480942 := by decide
theorem cert_e604835458734 : check e604835458734 [[.under]] .sourceHead = true := by decide
def e604835458746 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e604835458746 : Closed e604835458746 ∧ code e604835458746 = 9400928480954 := by decide
theorem cert_e604835458746 : check e604835458746 [[.under]] .sourceHead = true := by decide
def e604835458794 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e604835458794 : Closed e604835458794 ∧ code e604835458794 = 9400928481002 := by decide
theorem cert_e604835458794 : check e604835458794 [[.under]] .sourceHead = true := by decide
def e604835458902 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e604835458902 : Closed e604835458902 ∧ code e604835458902 = 9400928481110 := by decide
theorem cert_e604835458902 : check e604835458902 [[.under]] .sourceHead = true := by decide
def e604835458906 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e604835458906 : Closed e604835458906 ∧ code e604835458906 = 9400928481114 := by decide
theorem cert_e604835458906 : check e604835458906 [[.under]] .sourceHead = true := by decide
def e604835458922 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e604835458922 : Closed e604835458922 ∧ code e604835458922 = 9400928481130 := by decide
theorem cert_e604835458922 : check e604835458922 [[.under]] .sourceHead = true := by decide
def e604835459950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e604835459950 : Closed e604835459950 ∧ code e604835459950 = 9400928482158 := by decide
theorem cert_e604835459950 : check e604835459950 [[.under]] .sourceHead = true := by decide
def e604835459958 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e604835459958 : Closed e604835459958 ∧ code e604835459958 = 9400928482166 := by decide
theorem cert_e604835459958 : check e604835459958 [[.under]] .sourceHead = true := by decide
def e604835460014 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e604835460014 : Closed e604835460014 ∧ code e604835460014 = 9400928482222 := by decide
theorem cert_e604835460014 : check e604835460014 [[.under]] .sourceHead = true := by decide
def e604835460026 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e604835460026 : Closed e604835460026 ∧ code e604835460026 = 9400928482234 := by decide
theorem cert_e604835460026 : check e604835460026 [[.under]] .sourceHead = true := by decide
def e604835460054 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e604835460054 : Closed e604835460054 ∧ code e604835460054 = 9400928482262 := by decide
theorem cert_e604835460054 : check e604835460054 [[.under]] .sourceHead = true := by decide
def e604835460058 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e604835460058 : Closed e604835460058 ∧ code e604835460058 = 9400928482266 := by decide
theorem cert_e604835460058 : check e604835460058 [[.under]] .sourceHead = true := by decide
def e604835460334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e604835460334 : Closed e604835460334 ∧ code e604835460334 = 9400928482542 := by decide
theorem cert_e604835460334 : check e604835460334 [[.under]] .sourceHead = true := by decide
def e604835460342 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e604835460342 : Closed e604835460342 ∧ code e604835460342 = 9400928482550 := by decide
theorem cert_e604835460342 : check e604835460342 [[.under]] .sourceHead = true := by decide
def e604835460718 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e604835460718 : Closed e604835460718 ∧ code e604835460718 = 9400928482926 := by decide
theorem cert_e604835460718 : check e604835460718 [[.under]] .sourceHead = true := by decide
def e604835460730 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e604835460730 : Closed e604835460730 ∧ code e604835460730 = 9400928482938 := by decide
theorem cert_e604835460730 : check e604835460730 [[.under]] .sourceHead = true := by decide
def e604835460918 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e604835460918 : Closed e604835460918 ∧ code e604835460918 = 9400928483126 := by decide
theorem cert_e604835460918 : check e604835460918 [[.under]] .sourceHead = true := by decide
def e604835460922 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e604835460922 : Closed e604835460922 ∧ code e604835460922 = 9400928483130 := by decide
theorem cert_e604835460922 : check e604835460922 [[.under]] .sourceHead = true := by decide
def e604835461550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e604835461550 : Closed e604835461550 ∧ code e604835461550 = 9400928483758 := by decide
theorem cert_e604835461550 : check e604835461550 [[.under]] .sourceHead = true := by decide
def e604835461562 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e604835461562 : Closed e604835461562 ∧ code e604835461562 = 9400928483770 := by decide
theorem cert_e604835461562 : check e604835461562 [[.under]] .sourceHead = true := by decide
def e604835461610 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e604835461610 : Closed e604835461610 ∧ code e604835461610 = 9400928483818 := by decide
theorem cert_e604835461610 : check e604835461610 [[.under]] .sourceHead = true := by decide
def e604835461742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e604835461742 : Closed e604835461742 ∧ code e604835461742 = 9400928483950 := by decide
theorem cert_e604835461742 : check e604835461742 [[.under]] .sourceHead = true := by decide
def e604835461754 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e604835461754 : Closed e604835461754 ∧ code e604835461754 = 9400928483962 := by decide
theorem cert_e604835461754 : check e604835461754 [[.under]] .sourceHead = true := by decide
def e604835462042 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e604835462042 : Closed e604835462042 ∧ code e604835462042 = 9400928484250 := by decide
theorem cert_e604835462042 : check e604835462042 [[.under]] .sourceHead = true := by decide
def e604835462358 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e604835462358 : Closed e604835462358 ∧ code e604835462358 = 9400928484566 := by decide
theorem cert_e604835462358 : check e604835462358 [[.under]] .sourceHead = true := by decide
def e604835462362 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e604835462362 : Closed e604835462362 ∧ code e604835462362 = 9400928484570 := by decide
theorem cert_e604835462362 : check e604835462362 [[.under]] .sourceHead = true := by decide
def e604835462378 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e604835462378 : Closed e604835462378 ∧ code e604835462378 = 9400928484586 := by decide
theorem cert_e604835462378 : check e604835462378 [[.under]] .sourceHead = true := by decide
def e604835462454 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e604835462454 : Closed e604835462454 ∧ code e604835462454 = 9400928484662 := by decide
theorem cert_e604835462454 : check e604835462454 [[.under]] .sourceHead = true := by decide
def e604835462458 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e604835462458 : Closed e604835462458 ∧ code e604835462458 = 9400928484666 := by decide
theorem cert_e604835462458 : check e604835462458 [[.under]] .sourceHead = true := by decide
def e604835462554 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e604835462554 : Closed e604835462554 ∧ code e604835462554 = 9400928484762 := by decide
theorem cert_e604835462554 : check e604835462554 [[.under]] .sourceHead = true := by decide
def e604835466094 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e604835466094 : Closed e604835466094 ∧ code e604835466094 = 9400928488302 := by decide
theorem cert_e604835466094 : check e604835466094 [[.under]] .sourceHead = true := by decide
def e604835466102 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e604835466102 : Closed e604835466102 ∧ code e604835466102 = 9400928488310 := by decide
theorem cert_e604835466102 : check e604835466102 [[.under]] .sourceHead = true := by decide
def e604835466158 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e604835466158 : Closed e604835466158 ∧ code e604835466158 = 9400928488366 := by decide
theorem cert_e604835466158 : check e604835466158 [[.under]] .sourceHead = true := by decide
def e604835466170 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e604835466170 : Closed e604835466170 ∧ code e604835466170 = 9400928488378 := by decide
theorem cert_e604835466170 : check e604835466170 [[.under]] .sourceHead = true := by decide
def e604835466198 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e604835466198 : Closed e604835466198 ∧ code e604835466198 = 9400928488406 := by decide
theorem cert_e604835466198 : check e604835466198 [[.under]] .sourceHead = true := by decide
def e604835466202 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e604835466202 : Closed e604835466202 ∧ code e604835466202 = 9400928488410 := by decide
theorem cert_e604835466202 : check e604835466202 [[.under]] .sourceHead = true := by decide
def e604835466478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e604835466478 : Closed e604835466478 ∧ code e604835466478 = 9400928488686 := by decide
theorem cert_e604835466478 : check e604835466478 [[.under]] .sourceHead = true := by decide
def e604835466486 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e604835466486 : Closed e604835466486 ∧ code e604835466486 = 9400928488694 := by decide
theorem cert_e604835466486 : check e604835466486 [[.under]] .sourceHead = true := by decide
def e604835466862 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e604835466862 : Closed e604835466862 ∧ code e604835466862 = 9400928489070 := by decide
theorem cert_e604835466862 : check e604835466862 [[.under]] .sourceHead = true := by decide
def e604835466874 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e604835466874 : Closed e604835466874 ∧ code e604835466874 = 9400928489082 := by decide
theorem cert_e604835466874 : check e604835466874 [[.under]] .sourceHead = true := by decide
def e604835467062 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e604835467062 : Closed e604835467062 ∧ code e604835467062 = 9400928489270 := by decide
theorem cert_e604835467062 : check e604835467062 [[.under]] .sourceHead = true := by decide
def e604835467066 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e604835467066 : Closed e604835467066 ∧ code e604835467066 = 9400928489274 := by decide
theorem cert_e604835467066 : check e604835467066 [[.under]] .sourceHead = true := by decide
def e604835472814 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e604835472814 : Closed e604835472814 ∧ code e604835472814 = 9400928495022 := by decide
theorem cert_e604835472814 : check e604835472814 [[.under]] .sourceHead = true := by decide
def e604835472826 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e604835472826 : Closed e604835472826 ∧ code e604835472826 = 9400928495034 := by decide
theorem cert_e604835472826 : check e604835472826 [[.under]] .sourceHead = true := by decide
def e604835472874 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e604835472874 : Closed e604835472874 ∧ code e604835472874 = 9400928495082 := by decide
theorem cert_e604835472874 : check e604835472874 [[.under]] .sourceHead = true := by decide
def e604835473006 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e604835473006 : Closed e604835473006 ∧ code e604835473006 = 9400928495214 := by decide
theorem cert_e604835473006 : check e604835473006 [[.under]] .sourceHead = true := by decide
def e604835473018 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e604835473018 : Closed e604835473018 ∧ code e604835473018 = 9400928495226 := by decide
theorem cert_e604835473018 : check e604835473018 [[.under]] .sourceHead = true := by decide
def e604835473306 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e604835473306 : Closed e604835473306 ∧ code e604835473306 = 9400928495514 := by decide
theorem cert_e604835473306 : check e604835473306 [[.under]] .sourceHead = true := by decide
def e604835476182 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e604835476182 : Closed e604835476182 ∧ code e604835476182 = 9400928498390 := by decide
theorem cert_e604835476182 : check e604835476182 [[.under]] .sourceHead = true := by decide
def e604835476186 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e604835476186 : Closed e604835476186 ∧ code e604835476186 = 9400928498394 := by decide
theorem cert_e604835476186 : check e604835476186 [[.under]] .sourceHead = true := by decide
def e604835476202 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e604835476202 : Closed e604835476202 ∧ code e604835476202 = 9400928498410 := by decide
theorem cert_e604835476202 : check e604835476202 [[.under]] .sourceHead = true := by decide
def e604835476278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e604835476278 : Closed e604835476278 ∧ code e604835476278 = 9400928498486 := by decide
theorem cert_e604835476278 : check e604835476278 [[.under]] .sourceHead = true := by decide
def e604835476282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e604835476282 : Closed e604835476282 ∧ code e604835476282 = 9400928498490 := by decide
theorem cert_e604835476282 : check e604835476282 [[.under]] .sourceHead = true := by decide
def e604835476378 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e604835476378 : Closed e604835476378 ∧ code e604835476378 = 9400928498586 := by decide
theorem cert_e604835476378 : check e604835476378 [[.under]] .sourceHead = true := by decide
def e604835613550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e604835613550 : Closed e604835613550 ∧ code e604835613550 = 9400928635758 := by decide
theorem cert_e604835613550 : check e604835613550 [[.under]] .sourceHead = true := by decide
def e604835613558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e604835613558 : Closed e604835613558 ∧ code e604835613558 = 9400928635766 := by decide
theorem cert_e604835613558 : check e604835613558 [[.under]] .sourceHead = true := by decide
def e604835613614 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e604835613614 : Closed e604835613614 ∧ code e604835613614 = 9400928635822 := by decide
theorem cert_e604835613614 : check e604835613614 [[.under]] .sourceHead = true := by decide
def e604835613626 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e604835613626 : Closed e604835613626 ∧ code e604835613626 = 9400928635834 := by decide
theorem cert_e604835613626 : check e604835613626 [[.under]] .sourceHead = true := by decide
def e604835613654 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e604835613654 : Closed e604835613654 ∧ code e604835613654 = 9400928635862 := by decide
theorem cert_e604835613654 : check e604835613654 [[.under]] .sourceHead = true := by decide
def e604835613658 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e604835613658 : Closed e604835613658 ∧ code e604835613658 = 9400928635866 := by decide
theorem cert_e604835613658 : check e604835613658 [[.under]] .sourceHead = true := by decide
def e604835613934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e604835613934 : Closed e604835613934 ∧ code e604835613934 = 9400928636142 := by decide
theorem cert_e604835613934 : check e604835613934 [[.under]] .sourceHead = true := by decide
def e604835613942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e604835613942 : Closed e604835613942 ∧ code e604835613942 = 9400928636150 := by decide
theorem cert_e604835613942 : check e604835613942 [[.under]] .sourceHead = true := by decide
def e604835614318 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e604835614318 : Closed e604835614318 ∧ code e604835614318 = 9400928636526 := by decide
theorem cert_e604835614318 : check e604835614318 [[.under]] .sourceHead = true := by decide
def e604835614330 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e604835614330 : Closed e604835614330 ∧ code e604835614330 = 9400928636538 := by decide
theorem cert_e604835614330 : check e604835614330 [[.under]] .sourceHead = true := by decide
def e604835614518 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e604835614518 : Closed e604835614518 ∧ code e604835614518 = 9400928636726 := by decide
theorem cert_e604835614518 : check e604835614518 [[.under]] .sourceHead = true := by decide
def e604835614522 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e604835614522 : Closed e604835614522 ∧ code e604835614522 = 9400928636730 := by decide
theorem cert_e604835614522 : check e604835614522 [[.under]] .sourceHead = true := by decide
def e604836203374 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e604836203374 : Closed e604836203374 ∧ code e604836203374 = 9400929225582 := by decide
theorem cert_e604836203374 : check e604836203374 [[.under]] .sourceHead = true := by decide
def e604836203382 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e604836203382 : Closed e604836203382 ∧ code e604836203382 = 9400929225590 := by decide
theorem cert_e604836203382 : check e604836203382 [[.under]] .sourceHead = true := by decide
def e604836203438 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e604836203438 : Closed e604836203438 ∧ code e604836203438 = 9400929225646 := by decide
theorem cert_e604836203438 : check e604836203438 [[.under]] .sourceHead = true := by decide
def e604836203450 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e604836203450 : Closed e604836203450 ∧ code e604836203450 = 9400929225658 := by decide
theorem cert_e604836203450 : check e604836203450 [[.under]] .sourceHead = true := by decide
def e604836203478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e604836203478 : Closed e604836203478 ∧ code e604836203478 = 9400929225686 := by decide
theorem cert_e604836203478 : check e604836203478 [[.under]] .sourceHead = true := by decide
def e604836203482 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e604836203482 : Closed e604836203482 ∧ code e604836203482 = 9400929225690 := by decide
theorem cert_e604836203482 : check e604836203482 [[.under]] .sourceHead = true := by decide
def e604836203758 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e604836203758 : Closed e604836203758 ∧ code e604836203758 = 9400929225966 := by decide
theorem cert_e604836203758 : check e604836203758 [[.under]] .sourceHead = true := by decide
def e604836203766 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e604836203766 : Closed e604836203766 ∧ code e604836203766 = 9400929225974 := by decide
theorem cert_e604836203766 : check e604836203766 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
