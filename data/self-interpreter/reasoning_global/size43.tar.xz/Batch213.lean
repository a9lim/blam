import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392364076918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2392364076918 : Closed e2392364076918 ∧ code e2392364076918 = 11188457099126 := by decide
theorem cert_e2392364076918 : check e2392364076918 [[],[.left],[]] .sourceHead = true := by decide
def e2392364079598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2392364079598 : Closed e2392364079598 ∧ code e2392364079598 = 11188457101806 := by decide
theorem cert_e2392364079598 : check e2392364079598 [[],[.left],[]] .sourceHead = true := by decide
def e2392364080366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2392364080366 : Closed e2392364080366 ∧ code e2392364080366 = 11188457102574 := by decide
theorem cert_e2392364080366 : check e2392364080366 [[],[.left],[]] .sourceHead = true := by decide
def e2392364080374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2392364080374 : Closed e2392364080374 ∧ code e2392364080374 = 11188457102582 := by decide
theorem cert_e2392364080374 : check e2392364080374 [[],[.left],[]] .sourceHead = true := by decide
def e2392364082926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2392364082926 : Closed e2392364082926 ∧ code e2392364082926 = 11188457105134 := by decide
theorem cert_e2392364082926 : check e2392364082926 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392364083118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2392364083118 : Closed e2392364083118 ∧ code e2392364083118 = 11188457105326 := by decide
theorem cert_e2392364083118 : check e2392364083118 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392364083130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2392364083130 : Closed e2392364083130 ∧ code e2392364083130 = 11188457105338 := by decide
theorem cert_e2392364083130 : check e2392364083130 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392364083694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2392364083694 : Closed e2392364083694 ∧ code e2392364083694 = 11188457105902 := by decide
theorem cert_e2392364083694 : check e2392364083694 [[],[.left],[],[.under,.left],[.under],[.under]] .three = true := by decide
def e2392364084846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392364084846 : Closed e2392364084846 ∧ code e2392364084846 = 11188457107054 := by decide
theorem cert_e2392364084846 : check e2392364084846 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392364084858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392364084858 : Closed e2392364084858 ∧ code e2392364084858 = 11188457107066 := by decide
theorem cert_e2392364084858 : check e2392364084858 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392364086126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2392364086126 : Closed e2392364086126 ∧ code e2392364086126 = 11188457108334 := by decide
theorem cert_e2392364086126 : check e2392364086126 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392364086134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2392364086134 : Closed e2392364086134 ∧ code e2392364086134 = 11188457108342 := by decide
theorem cert_e2392364086134 : check e2392364086134 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392364086190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2392364086190 : Closed e2392364086190 ∧ code e2392364086190 = 11188457108398 := by decide
theorem cert_e2392364086190 : check e2392364086190 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392364086202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2392364086202 : Closed e2392364086202 ∧ code e2392364086202 = 11188457108410 := by decide
theorem cert_e2392364086202 : check e2392364086202 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2392364086230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2392364086230 : Closed e2392364086230 ∧ code e2392364086230 = 11188457108438 := by decide
theorem cert_e2392364086230 : check e2392364086230 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2392364086234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2392364086234 : Closed e2392364086234 ∧ code e2392364086234 = 11188457108442 := by decide
theorem cert_e2392364086234 : check e2392364086234 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2392364086510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2392364086510 : Closed e2392364086510 ∧ code e2392364086510 = 11188457108718 := by decide
theorem cert_e2392364086510 : check e2392364086510 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392364086518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2392364086518 : Closed e2392364086518 ∧ code e2392364086518 = 11188457108726 := by decide
theorem cert_e2392364086518 : check e2392364086518 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392364086894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392364086894 : Closed e2392364086894 ∧ code e2392364086894 = 11188457109102 := by decide
theorem cert_e2392364086894 : check e2392364086894 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392364086906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392364086906 : Closed e2392364086906 ∧ code e2392364086906 = 11188457109114 := by decide
theorem cert_e2392364086906 : check e2392364086906 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392364087094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392364087094 : Closed e2392364087094 ∧ code e2392364087094 = 11188457109302 := by decide
private def t_e2392364087094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e2392364087094 : ¬ IsSelfInterpreter e2392364087094 :=
  wSource (t := t_e2392364087094) (replay_sound (ps := []) (t := e2392364087094) (by decide)) (by decide)
def e2392364087098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392364087098 : Closed e2392364087098 ∧ code e2392364087098 = 11188457109306 := by decide
private def t_e2392364087098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e2392364087098 : ¬ IsSelfInterpreter e2392364087098 :=
  wSource (t := t_e2392364087098) (replay_sound (ps := []) (t := e2392364087098) (by decide)) (by decide)
def e2392364092270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392364092270 : Closed e2392364092270 ∧ code e2392364092270 = 11188457114478 := by decide
theorem cert_e2392364092270 : check e2392364092270 [[],[.left]] .smaller = true := by decide
def e2392364092278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392364092278 : Closed e2392364092278 ∧ code e2392364092278 = 11188457114486 := by decide
theorem cert_e2392364092278 : check e2392364092278 [[],[.left]] .smaller = true := by decide
def e2392364092334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392364092334 : Closed e2392364092334 ∧ code e2392364092334 = 11188457114542 := by decide
theorem cert_e2392364092334 : check e2392364092334 [[],[.left]] .smaller = true := by decide
def e2392364092346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392364092346 : Closed e2392364092346 ∧ code e2392364092346 = 11188457114554 := by decide
theorem cert_e2392364092346 : check e2392364092346 [[],[.left]] .smaller = true := by decide
def e2392364092374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392364092374 : Closed e2392364092374 ∧ code e2392364092374 = 11188457114582 := by decide
theorem cert_e2392364092374 : check e2392364092374 [[],[.left]] .smaller = true := by decide
def e2392364092378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392364092378 : Closed e2392364092378 ∧ code e2392364092378 = 11188457114586 := by decide
theorem cert_e2392364092378 : check e2392364092378 [[],[.left]] .smaller = true := by decide
def e2392364092654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392364092654 : Closed e2392364092654 ∧ code e2392364092654 = 11188457114862 := by decide
theorem cert_e2392364092654 : check e2392364092654 [[],[.left]] .smaller = true := by decide
def e2392364092662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392364092662 : Closed e2392364092662 ∧ code e2392364092662 = 11188457114870 := by decide
theorem cert_e2392364092662 : check e2392364092662 [[],[.left]] .smaller = true := by decide
def e2392364093038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392364093038 : Closed e2392364093038 ∧ code e2392364093038 = 11188457115246 := by decide
theorem cert_e2392364093038 : check e2392364093038 [[],[.left]] .smaller = true := by decide
def e2392364093050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392364093050 : Closed e2392364093050 ∧ code e2392364093050 = 11188457115258 := by decide
theorem cert_e2392364093050 : check e2392364093050 [[],[.left]] .smaller = true := by decide
def e2392364093238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392364093238 : Closed e2392364093238 ∧ code e2392364093238 = 11188457115446 := by decide
theorem cert_e2392364093238 : check e2392364093238 [[],[.left]] .smaller = true := by decide
def e2392364093242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392364093242 : Closed e2392364093242 ∧ code e2392364093242 = 11188457115450 := by decide
theorem cert_e2392364093242 : check e2392364093242 [[],[.left]] .smaller = true := by decide
def e2392364101358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2392364101358 : Closed e2392364101358 ∧ code e2392364101358 = 11188457123566 := by decide
theorem cert_e2392364101358 : check e2392364101358 [[],[.left],[]] .sourceHead = true := by decide
def e2392364101486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2392364101486 : Closed e2392364101486 ∧ code e2392364101486 = 11188457123694 := by decide
theorem cert_e2392364101486 : check e2392364101486 [[],[.left],[]] .sourceHead = true := by decide
def e2392364101494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2392364101494 : Closed e2392364101494 ∧ code e2392364101494 = 11188457123702 := by decide
theorem cert_e2392364101494 : check e2392364101494 [[],[.left],[]] .sourceHead = true := by decide
def e2392364104174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2392364104174 : Closed e2392364104174 ∧ code e2392364104174 = 11188457126382 := by decide
theorem cert_e2392364104174 : check e2392364104174 [[],[.left],[]] .sourceHead = true := by decide
def e2392364104942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2392364104942 : Closed e2392364104942 ∧ code e2392364104942 = 11188457127150 := by decide
theorem cert_e2392364104942 : check e2392364104942 [[],[.left],[]] .sourceHead = true := by decide
def e2392364104950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2392364104950 : Closed e2392364104950 ∧ code e2392364104950 = 11188457127158 := by decide
theorem cert_e2392364104950 : check e2392364104950 [[],[.left],[]] .sourceHead = true := by decide
def e2392364127982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2392364127982 : Closed e2392364127982 ∧ code e2392364127982 = 11188457150190 := by decide
theorem cert_e2392364127982 : check e2392364127982 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392364128174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2392364128174 : Closed e2392364128174 ∧ code e2392364128174 = 11188457150382 := by decide
theorem cert_e2392364128174 : check e2392364128174 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392364128186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2392364128186 : Closed e2392364128186 ∧ code e2392364128186 = 11188457150394 := by decide
theorem cert_e2392364128186 : check e2392364128186 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392364128750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2392364128750 : Closed e2392364128750 ∧ code e2392364128750 = 11188457150958 := by decide
theorem cert_e2392364128750 : check e2392364128750 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392364129902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2392364129902 : Closed e2392364129902 ∧ code e2392364129902 = 11188457152110 := by decide
theorem cert_e2392364129902 : check e2392364129902 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392364129914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2392364129914 : Closed e2392364129914 ∧ code e2392364129914 = 11188457152122 := by decide
theorem cert_e2392364129914 : check e2392364129914 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392364141422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392364141422 : Closed e2392364141422 ∧ code e2392364141422 = 11188457163630 := by decide
theorem cert_e2392364141422 : check e2392364141422 [[],[.left],[],[.under]] .three = true := by decide
def e2392364141430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392364141430 : Closed e2392364141430 ∧ code e2392364141430 = 11188457163638 := by decide
theorem cert_e2392364141430 : check e2392364141430 [[],[.left],[],[.under]] .three = true := by decide
def e2392364141486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392364141486 : Closed e2392364141486 ∧ code e2392364141486 = 11188457163694 := by decide
theorem cert_e2392364141486 : check e2392364141486 [[],[.left],[],[.under]] .three = true := by decide
def e2392364141498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392364141498 : Closed e2392364141498 ∧ code e2392364141498 = 11188457163706 := by decide
theorem cert_e2392364141498 : check e2392364141498 [[],[.left],[],[.under]] .three = true := by decide
def e2392364141526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392364141526 : Closed e2392364141526 ∧ code e2392364141526 = 11188457163734 := by decide
theorem cert_e2392364141526 : check e2392364141526 [[],[.left],[],[.under]] .three = true := by decide
def e2392364141530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392364141530 : Closed e2392364141530 ∧ code e2392364141530 = 11188457163738 := by decide
theorem cert_e2392364141530 : check e2392364141530 [[],[.left],[],[.under]] .three = true := by decide
def e2392364141806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392364141806 : Closed e2392364141806 ∧ code e2392364141806 = 11188457164014 := by decide
theorem cert_e2392364141806 : check e2392364141806 [[],[.left],[],[.under]] .three = true := by decide
def e2392364141814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392364141814 : Closed e2392364141814 ∧ code e2392364141814 = 11188457164022 := by decide
theorem cert_e2392364141814 : check e2392364141814 [[],[.left],[],[.under]] .three = true := by decide
def e2392364142190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392364142190 : Closed e2392364142190 ∧ code e2392364142190 = 11188457164398 := by decide
theorem cert_e2392364142190 : check e2392364142190 [[],[.left],[],[.under]] .three = true := by decide
def e2392364142202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392364142202 : Closed e2392364142202 ∧ code e2392364142202 = 11188457164410 := by decide
theorem cert_e2392364142202 : check e2392364142202 [[],[.left],[],[.under]] .three = true := by decide
def e2392364142390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392364142390 : Closed e2392364142390 ∧ code e2392364142390 = 11188457164598 := by decide
theorem cert_e2392364142390 : check e2392364142390 [[],[.left],[],[.under]] .three = true := by decide
def e2392364142394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392364142394 : Closed e2392364142394 ∧ code e2392364142394 = 11188457164602 := by decide
theorem cert_e2392364142394 : check e2392364142394 [[],[.left],[],[.under]] .three = true := by decide
def e2392364682094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392364682094 : Closed e2392364682094 ∧ code e2392364682094 = 11188457704302 := by decide
theorem cert_e2392364682094 : check e2392364682094 [[],[.left]] .smaller = true := by decide
def e2392364682102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392364682102 : Closed e2392364682102 ∧ code e2392364682102 = 11188457704310 := by decide
theorem cert_e2392364682102 : check e2392364682102 [[],[.left]] .smaller = true := by decide
def e2392364682158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392364682158 : Closed e2392364682158 ∧ code e2392364682158 = 11188457704366 := by decide
theorem cert_e2392364682158 : check e2392364682158 [[],[.left]] .smaller = true := by decide
def e2392364682170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392364682170 : Closed e2392364682170 ∧ code e2392364682170 = 11188457704378 := by decide
theorem cert_e2392364682170 : check e2392364682170 [[],[.left]] .smaller = true := by decide
def e2392364682198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392364682198 : Closed e2392364682198 ∧ code e2392364682198 = 11188457704406 := by decide
theorem cert_e2392364682198 : check e2392364682198 [[],[.left]] .smaller = true := by decide
def e2392364682202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392364682202 : Closed e2392364682202 ∧ code e2392364682202 = 11188457704410 := by decide
theorem cert_e2392364682202 : check e2392364682202 [[],[.left]] .smaller = true := by decide
def e2392364682478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392364682478 : Closed e2392364682478 ∧ code e2392364682478 = 11188457704686 := by decide
theorem cert_e2392364682478 : check e2392364682478 [[],[.left]] .smaller = true := by decide
def e2392364682486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392364682486 : Closed e2392364682486 ∧ code e2392364682486 = 11188457704694 := by decide
theorem cert_e2392364682486 : check e2392364682486 [[],[.left]] .smaller = true := by decide
def e2392364682862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392364682862 : Closed e2392364682862 ∧ code e2392364682862 = 11188457705070 := by decide
theorem cert_e2392364682862 : check e2392364682862 [[],[.left]] .smaller = true := by decide
def e2392364682874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392364682874 : Closed e2392364682874 ∧ code e2392364682874 = 11188457705082 := by decide
theorem cert_e2392364682874 : check e2392364682874 [[],[.left]] .smaller = true := by decide
def e2392364683062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392364683062 : Closed e2392364683062 ∧ code e2392364683062 = 11188457705270 := by decide
theorem cert_e2392364683062 : check e2392364683062 [[],[.left]] .smaller = true := by decide
def e2392364683066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392364683066 : Closed e2392364683066 ∧ code e2392364683066 = 11188457705274 := by decide
theorem cert_e2392364683066 : check e2392364683066 [[],[.left]] .smaller = true := by decide
def e2392397536110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2392397536110 : Closed e2392397536110 ∧ code e2392397536110 = 11188490558318 := by decide
theorem cert_e2392397536110 : check e2392397536110 [[],[.left]] .chain = true := by decide
def e2392397536118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2392397536118 : Closed e2392397536118 ∧ code e2392397536118 = 11188490558326 := by decide
theorem cert_e2392397536118 : check e2392397536118 [[],[.left]] .chain = true := by decide
def e2392397536182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2392397536182 : Closed e2392397536182 ∧ code e2392397536182 = 11188490558390 := by decide
theorem cert_e2392397536182 : check e2392397536182 [[],[.left]] .chain = true := by decide
def e2392397536622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2392397536622 : Closed e2392397536622 ∧ code e2392397536622 = 11188490558830 := by decide
theorem cert_e2392397536622 : check e2392397536622 [[],[.left]] .chain = true := by decide
def e2392397536630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2392397536630 : Closed e2392397536630 ∧ code e2392397536630 = 11188490558838 := by decide
theorem cert_e2392397536630 : check e2392397536630 [[],[.left]] .chain = true := by decide
def e2392397536686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2392397536686 : Closed e2392397536686 ∧ code e2392397536686 = 11188490558894 := by decide
theorem cert_e2392397536686 : check e2392397536686 [[],[.left]] .chain = true := by decide
def e2392397536698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2392397536698 : Closed e2392397536698 ∧ code e2392397536698 = 11188490558906 := by decide
theorem cert_e2392397536698 : check e2392397536698 [[],[.left]] .chain = true := by decide
def e2392397536726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2392397536726 : Closed e2392397536726 ∧ code e2392397536726 = 11188490558934 := by decide
theorem cert_e2392397536726 : check e2392397536726 [[],[.left]] .chain = true := by decide
def e2392397536730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2392397536730 : Closed e2392397536730 ∧ code e2392397536730 = 11188490558938 := by decide
theorem cert_e2392397536730 : check e2392397536730 [[],[.left]] .chain = true := by decide
def e2392397536950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2392397536950 : Closed e2392397536950 ∧ code e2392397536950 = 11188490559158 := by decide
theorem cert_e2392397536950 : check e2392397536950 [[],[.left]] .chain = true := by decide
def e2392397536982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2392397536982 : Closed e2392397536982 ∧ code e2392397536982 = 11188490559190 := by decide
theorem cert_e2392397536982 : check e2392397536982 [[],[.left]] .chain = true := by decide
def e2392397536986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2392397536986 : Closed e2392397536986 ∧ code e2392397536986 = 11188490559194 := by decide
theorem cert_e2392397536986 : check e2392397536986 [[],[.left]] .chain = true := by decide
def e2392397539182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2392397539182 : Closed e2392397539182 ∧ code e2392397539182 = 11188490561390 := by decide
theorem cert_e2392397539182 : check e2392397539182 [[],[.left]] .chain = true := by decide
def e2392397539190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2392397539190 : Closed e2392397539190 ∧ code e2392397539190 = 11188490561398 := by decide
theorem cert_e2392397539190 : check e2392397539190 [[],[.left]] .chain = true := by decide
def e2392397539254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2392397539254 : Closed e2392397539254 ∧ code e2392397539254 = 11188490561462 := by decide
theorem cert_e2392397539254 : check e2392397539254 [[],[.left]] .chain = true := by decide
def e2392397540590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2392397540590 : Closed e2392397540590 ∧ code e2392397540590 = 11188490562798 := by decide
theorem cert_e2392397540590 : check e2392397540590 [[],[.left]] .chain = true := by decide
def e2392397540598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2392397540598 : Closed e2392397540598 ∧ code e2392397540598 = 11188490562806 := by decide
theorem cert_e2392397540598 : check e2392397540598 [[],[.left]] .chain = true := by decide
def e2392397540982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2392397540982 : Closed e2392397540982 ∧ code e2392397540982 = 11188490563190 := by decide
theorem cert_e2392397540982 : check e2392397540982 [[],[.left]] .chain = true := by decide
def e2392397542254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2392397542254 : Closed e2392397542254 ∧ code e2392397542254 = 11188490564462 := by decide
theorem cert_e2392397542254 : check e2392397542254 [[],[.left]] .chain = true := by decide
def e2392397542262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2392397542262 : Closed e2392397542262 ∧ code e2392397542262 = 11188490564470 := by decide
theorem cert_e2392397542262 : check e2392397542262 [[],[.left]] .chain = true := by decide
def e2392397542318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2392397542318 : Closed e2392397542318 ∧ code e2392397542318 = 11188490564526 := by decide
theorem cert_e2392397542318 : check e2392397542318 [[],[.left]] .chain = true := by decide
def e2392397542330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2392397542330 : Closed e2392397542330 ∧ code e2392397542330 = 11188490564538 := by decide
theorem cert_e2392397542330 : check e2392397542330 [[],[.left]] .chain = true := by decide
def e2392397542358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2392397542358 : Closed e2392397542358 ∧ code e2392397542358 = 11188490564566 := by decide
theorem cert_e2392397542358 : check e2392397542358 [[],[.left]] .chain = true := by decide
def e2392397542362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2392397542362 : Closed e2392397542362 ∧ code e2392397542362 = 11188490564570 := by decide
theorem cert_e2392397542362 : check e2392397542362 [[],[.left]] .chain = true := by decide
def e2392397542638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2392397542638 : Closed e2392397542638 ∧ code e2392397542638 = 11188490564846 := by decide
theorem cert_e2392397542638 : check e2392397542638 [[],[.left]] .chain = true := by decide
def e2392397542646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2392397542646 : Closed e2392397542646 ∧ code e2392397542646 = 11188490564854 := by decide
theorem cert_e2392397542646 : check e2392397542646 [[],[.left]] .chain = true := by decide
def e2392397543022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392397543022 : Closed e2392397543022 ∧ code e2392397543022 = 11188490565230 := by decide
theorem cert_e2392397543022 : check e2392397543022 [[],[.left]] .chain = true := by decide
def e2392397543034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392397543034 : Closed e2392397543034 ∧ code e2392397543034 = 11188490565242 := by decide
theorem cert_e2392397543034 : check e2392397543034 [[],[.left]] .chain = true := by decide
def e2392397543222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392397543222 : Closed e2392397543222 ∧ code e2392397543222 = 11188490565430 := by decide
theorem cert_e2392397543222 : check e2392397543222 [[],[.left]] .chain = true := by decide
def e2392397543226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392397543226 : Closed e2392397543226 ∧ code e2392397543226 = 11188490565434 := by decide
theorem cert_e2392397543226 : check e2392397543226 [[],[.left]] .chain = true := by decide
def e2392397543862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2392397543862 : Closed e2392397543862 ∧ code e2392397543862 = 11188490566070 := by decide
theorem cert_e2392397543862 : check e2392397543862 [[],[.left]] .chain = true := by decide
def e2392397543894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2392397543894 : Closed e2392397543894 ∧ code e2392397543894 = 11188490566102 := by decide
theorem cert_e2392397543894 : check e2392397543894 [[],[.left]] .chain = true := by decide
def e2392397543898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2392397543898 : Closed e2392397543898 ∧ code e2392397543898 = 11188490566106 := by decide
theorem cert_e2392397543898 : check e2392397543898 [[],[.left]] .chain = true := by decide
def e2392397544054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2392397544054 : Closed e2392397544054 ∧ code e2392397544054 = 11188490566262 := by decide
theorem cert_e2392397544054 : check e2392397544054 [[],[.left]] .chain = true := by decide
def e2392397544246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392397544246 : Closed e2392397544246 ∧ code e2392397544246 = 11188490566454 := by decide
theorem cert_e2392397544246 : check e2392397544246 [[],[.left]] .chain = true := by decide
def e2392397544250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392397544250 : Closed e2392397544250 ∧ code e2392397544250 = 11188490566458 := by decide
theorem cert_e2392397544250 : check e2392397544250 [[],[.left]] .chain = true := by decide
def e2392397551470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2392397551470 : Closed e2392397551470 ∧ code e2392397551470 = 11188490573678 := by decide
theorem cert_e2392397551470 : check e2392397551470 [[],[.left]] .chain = true := by decide
def e2392397551478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2392397551478 : Closed e2392397551478 ∧ code e2392397551478 = 11188490573686 := by decide
theorem cert_e2392397551478 : check e2392397551478 [[],[.left]] .chain = true := by decide
def e2392397551542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2392397551542 : Closed e2392397551542 ∧ code e2392397551542 = 11188490573750 := by decide
theorem cert_e2392397551542 : check e2392397551542 [[],[.left]] .chain = true := by decide
def e2392397552878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2392397552878 : Closed e2392397552878 ∧ code e2392397552878 = 11188490575086 := by decide
theorem cert_e2392397552878 : check e2392397552878 [[],[.left]] .chain = true := by decide
def e2392397552886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2392397552886 : Closed e2392397552886 ∧ code e2392397552886 = 11188490575094 := by decide
theorem cert_e2392397552886 : check e2392397552886 [[],[.left]] .chain = true := by decide
def e2392397553270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2392397553270 : Closed e2392397553270 ∧ code e2392397553270 = 11188490575478 := by decide
theorem cert_e2392397553270 : check e2392397553270 [[],[.left]] .chain = true := by decide
def e2392397564782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392397564782 : Closed e2392397564782 ∧ code e2392397564782 = 11188490586990 := by decide
theorem cert_e2392397564782 : check e2392397564782 [[],[.left]] .chain = true := by decide
def e2392397564790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392397564790 : Closed e2392397564790 ∧ code e2392397564790 = 11188490586998 := by decide
theorem cert_e2392397564790 : check e2392397564790 [[],[.left]] .chain = true := by decide
def e2392397564846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392397564846 : Closed e2392397564846 ∧ code e2392397564846 = 11188490587054 := by decide
theorem cert_e2392397564846 : check e2392397564846 [[],[.left]] .chain = true := by decide
def e2392397564858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392397564858 : Closed e2392397564858 ∧ code e2392397564858 = 11188490587066 := by decide
theorem cert_e2392397564858 : check e2392397564858 [[],[.left]] .chain = true := by decide
def e2392397564886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392397564886 : Closed e2392397564886 ∧ code e2392397564886 = 11188490587094 := by decide
theorem cert_e2392397564886 : check e2392397564886 [[],[.left]] .chain = true := by decide
def e2392397564890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392397564890 : Closed e2392397564890 ∧ code e2392397564890 = 11188490587098 := by decide
theorem cert_e2392397564890 : check e2392397564890 [[],[.left]] .chain = true := by decide
def e2392397565166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392397565166 : Closed e2392397565166 ∧ code e2392397565166 = 11188490587374 := by decide
theorem cert_e2392397565166 : check e2392397565166 [[],[.left]] .chain = true := by decide
def e2392397565174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392397565174 : Closed e2392397565174 ∧ code e2392397565174 = 11188490587382 := by decide
theorem cert_e2392397565174 : check e2392397565174 [[],[.left]] .chain = true := by decide
def e2392397565550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392397565550 : Closed e2392397565550 ∧ code e2392397565550 = 11188490587758 := by decide
theorem cert_e2392397565550 : check e2392397565550 [[],[.left]] .chain = true := by decide
def e2392397565562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392397565562 : Closed e2392397565562 ∧ code e2392397565562 = 11188490587770 := by decide
theorem cert_e2392397565562 : check e2392397565562 [[],[.left]] .chain = true := by decide
def e2392397565750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392397565750 : Closed e2392397565750 ∧ code e2392397565750 = 11188490587958 := by decide
theorem cert_e2392397565750 : check e2392397565750 [[],[.left]] .chain = true := by decide
def e2392397565754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392397565754 : Closed e2392397565754 ∧ code e2392397565754 = 11188490587962 := by decide
theorem cert_e2392397565754 : check e2392397565754 [[],[.left]] .chain = true := by decide
def e2392397571510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2392397571510 : Closed e2392397571510 ∧ code e2392397571510 = 11188490593718 := by decide
theorem cert_e2392397571510 : check e2392397571510 [[],[.left]] .chain = true := by decide
def e2392397571542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2392397571542 : Closed e2392397571542 ∧ code e2392397571542 = 11188490593750 := by decide
theorem cert_e2392397571542 : check e2392397571542 [[],[.left]] .chain = true := by decide
def e2392397571546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2392397571546 : Closed e2392397571546 ∧ code e2392397571546 = 11188490593754 := by decide
theorem cert_e2392397571546 : check e2392397571546 [[],[.left]] .chain = true := by decide
def e2392397571702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2392397571702 : Closed e2392397571702 ∧ code e2392397571702 = 11188490593910 := by decide
theorem cert_e2392397571702 : check e2392397571702 [[],[.left]] .chain = true := by decide
def e2392397571894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2392397571894 : Closed e2392397571894 ∧ code e2392397571894 = 11188490594102 := by decide
theorem cert_e2392397571894 : check e2392397571894 [[],[.left]] .chain = true := by decide
def e2392397571898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2392397571898 : Closed e2392397571898 ∧ code e2392397571898 = 11188490594106 := by decide
theorem cert_e2392397571898 : check e2392397571898 [[],[.left]] .chain = true := by decide
def e2392397908846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392397908846 : Closed e2392397908846 ∧ code e2392397908846 = 11188490931054 := by decide
theorem cert_e2392397908846 : check e2392397908846 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e2392397908854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392397908854 : Closed e2392397908854 ∧ code e2392397908854 = 11188490931062 := by decide
private def t_e2392397908854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2392397908854 : ¬ IsSelfInterpreter e2392397908854 :=
  wSource (t := t_e2392397908854) (replay_sound (ps := []) (t := e2392397908854) (by decide)) (by decide)
def e2392397908910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392397908910 : Closed e2392397908910 ∧ code e2392397908910 = 11188490931118 := by decide
theorem cert_e2392397908910 : check e2392397908910 [[],[.left],[],[],[.under],[.under,.left],[.under]] .chain = true := by decide
def e2392397908922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392397908922 : Closed e2392397908922 ∧ code e2392397908922 = 11188490931130 := by decide
theorem cert_e2392397908922 : check e2392397908922 [[],[.left],[],[],[.under],[.under,.left],[.under]] .smaller = true := by decide
def e2392397908950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392397908950 : Closed e2392397908950 ∧ code e2392397908950 = 11188490931158 := by decide
private def t_e2392397908950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2392397908950 : ¬ IsSelfInterpreter e2392397908950 :=
  wSource (t := t_e2392397908950) (replay_sound (ps := []) (t := e2392397908950) (by decide)) (by decide)
def e2392397908954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392397908954 : Closed e2392397908954 ∧ code e2392397908954 = 11188490931162 := by decide
theorem cert_e2392397908954 : check e2392397908954 [[],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e2392397909230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392397909230 : Closed e2392397909230 ∧ code e2392397909230 = 11188490931438 := by decide
theorem cert_e2392397909230 : check e2392397909230 [[],[.left],[],[],[.under],[.under],[.under,.left],[.under]] .smaller = true := by decide
def e2392397909238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392397909238 : Closed e2392397909238 ∧ code e2392397909238 = 11188490931446 := by decide
theorem cert_e2392397909238 : check e2392397909238 [[],[.left],[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2392397909614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392397909614 : Closed e2392397909614 ∧ code e2392397909614 = 11188490931822 := by decide
theorem cert_e2392397909614 : check e2392397909614 [[],[.left],[],[],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e2392397909626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392397909626 : Closed e2392397909626 ∧ code e2392397909626 = 11188490931834 := by decide
theorem cert_e2392397909626 : check e2392397909626 [[],[.left],[],[],[.under],[.under],[.under,.under]] .three = true := by decide
def e2392397909814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392397909814 : Closed e2392397909814 ∧ code e2392397909814 = 11188490932022 := by decide
theorem cert_e2392397909814 : check e2392397909814 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2392397909818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392397909818 : Closed e2392397909818 ∧ code e2392397909818 = 11188490932026 := by decide
theorem cert_e2392397909818 : check e2392397909818 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2392414268782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2392414268782 : Closed e2392414268782 ∧ code e2392414268782 = 11188507290990 := by decide
theorem cert_e2392414268782 : check e2392414268782 [[],[.left],[]] .sourceHead = true := by decide
def e2392414268790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2392414268790 : Closed e2392414268790 ∧ code e2392414268790 = 11188507290998 := by decide
theorem cert_e2392414268790 : check e2392414268790 [[],[.left],[]] .sourceHead = true := by decide
def e2392414268846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2392414268846 : Closed e2392414268846 ∧ code e2392414268846 = 11188507291054 := by decide
theorem cert_e2392414268846 : check e2392414268846 [[],[.left],[]] .sourceHead = true := by decide
def e2392414268858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2392414268858 : Closed e2392414268858 ∧ code e2392414268858 = 11188507291066 := by decide
theorem cert_e2392414268858 : check e2392414268858 [[],[.left],[]] .sourceHead = true := by decide
def e2392414268886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2392414268886 : Closed e2392414268886 ∧ code e2392414268886 = 11188507291094 := by decide
theorem cert_e2392414268886 : check e2392414268886 [[],[.left],[]] .sourceHead = true := by decide
def e2392414268890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2392414268890 : Closed e2392414268890 ∧ code e2392414268890 = 11188507291098 := by decide
theorem cert_e2392414268890 : check e2392414268890 [[],[.left],[]] .sourceHead = true := by decide
def e2392414269102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2392414269102 : Closed e2392414269102 ∧ code e2392414269102 = 11188507291310 := by decide
theorem cert_e2392414269102 : check e2392414269102 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2392414269114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2392414269114 : Closed e2392414269114 ∧ code e2392414269114 = 11188507291322 := by decide
theorem cert_e2392414269114 : check e2392414269114 [[],[.left],[],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e2392414269162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2392414269162 : Closed e2392414269162 ∧ code e2392414269162 = 11188507291370 := by decide
theorem cert_e2392414269162 : check e2392414269162 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392414269270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2392414269270 : Closed e2392414269270 ∧ code e2392414269270 = 11188507291478 := by decide
theorem cert_e2392414269270 : check e2392414269270 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392414269274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2392414269274 : Closed e2392414269274 ∧ code e2392414269274 = 11188507291482 := by decide
theorem cert_e2392414269274 : check e2392414269274 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2392414269290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2392414269290 : Closed e2392414269290 ∧ code e2392414269290 = 11188507291498 := by decide
theorem cert_e2392414269290 : check e2392414269290 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2392414270318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2392414270318 : Closed e2392414270318 ∧ code e2392414270318 = 11188507292526 := by decide
theorem cert_e2392414270318 : check e2392414270318 [[],[.left],[]] .sourceHead = true := by decide
def e2392414270326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2392414270326 : Closed e2392414270326 ∧ code e2392414270326 = 11188507292534 := by decide
theorem cert_e2392414270326 : check e2392414270326 [[],[.left],[]] .sourceHead = true := by decide
def e2392414270382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2392414270382 : Closed e2392414270382 ∧ code e2392414270382 = 11188507292590 := by decide
theorem cert_e2392414270382 : check e2392414270382 [[],[.left],[]] .sourceHead = true := by decide
def e2392414270394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2392414270394 : Closed e2392414270394 ∧ code e2392414270394 = 11188507292602 := by decide
theorem cert_e2392414270394 : check e2392414270394 [[],[.left],[]] .sourceHead = true := by decide
def e2392414270422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2392414270422 : Closed e2392414270422 ∧ code e2392414270422 = 11188507292630 := by decide
theorem cert_e2392414270422 : check e2392414270422 [[],[.left],[]] .sourceHead = true := by decide
def e2392414270426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2392414270426 : Closed e2392414270426 ∧ code e2392414270426 = 11188507292634 := by decide
theorem cert_e2392414270426 : check e2392414270426 [[],[.left],[]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392364087094
#print axioms Blc.Floor43.cert_e2392364087098
#print axioms Blc.Floor43.cert_e2392397908854
#print axioms Blc.Floor43.cert_e2392397908950
