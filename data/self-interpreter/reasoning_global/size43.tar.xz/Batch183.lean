import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262424402350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2262424402350 : Closed e2262424402350 ∧ code e2262424402350 = 11058517424558 := by decide
theorem cert_e2262424402350 : check e2262424402350 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424402362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2262424402362 : Closed e2262424402362 ∧ code e2262424402362 = 11058517424570 := by decide
theorem cert_e2262424402362 : check e2262424402362 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424402410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2262424402410 : Closed e2262424402410 ∧ code e2262424402410 = 11058517424618 := by decide
theorem cert_e2262424402410 : check e2262424402410 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424402494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2262424402494 : Closed e2262424402494 ∧ code e2262424402494 = 11058517424702 := by decide
theorem cert_e2262424402494 : check e2262424402494 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424402542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262424402542 : Closed e2262424402542 ∧ code e2262424402542 = 11058517424750 := by decide
theorem cert_e2262424402542 : check e2262424402542 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424402554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262424402554 : Closed e2262424402554 ∧ code e2262424402554 = 11058517424762 := by decide
theorem cert_e2262424402554 : check e2262424402554 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424402842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262424402842 : Closed e2262424402842 ∧ code e2262424402842 = 11058517425050 := by decide
theorem cert_e2262424402842 : check e2262424402842 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424402886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2262424402886 : Closed e2262424402886 ∧ code e2262424402886 = 11058517425094 := by decide
theorem cert_e2262424402886 : check e2262424402886 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424403158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2262424403158 : Closed e2262424403158 ∧ code e2262424403158 = 11058517425366 := by decide
theorem cert_e2262424403158 : check e2262424403158 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424403162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2262424403162 : Closed e2262424403162 ∧ code e2262424403162 = 11058517425370 := by decide
theorem cert_e2262424403162 : check e2262424403162 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424403178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2262424403178 : Closed e2262424403178 ∧ code e2262424403178 = 11058517425386 := by decide
theorem cert_e2262424403178 : check e2262424403178 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424403254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262424403254 : Closed e2262424403254 ∧ code e2262424403254 = 11058517425462 := by decide
theorem cert_e2262424403254 : check e2262424403254 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424403258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262424403258 : Closed e2262424403258 ∧ code e2262424403258 = 11058517425466 := by decide
theorem cert_e2262424403258 : check e2262424403258 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424403354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262424403354 : Closed e2262424403354 ∧ code e2262424403354 = 11058517425562 := by decide
theorem cert_e2262424403354 : check e2262424403354 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424403510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2262424403510 : Closed e2262424403510 ∧ code e2262424403510 = 11058517425718 := by decide
theorem cert_e2262424403510 : check e2262424403510 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424403514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2262424403514 : Closed e2262424403514 ∧ code e2262424403514 = 11058517425722 := by decide
theorem cert_e2262424403514 : check e2262424403514 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424403598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2262424403598 : Closed e2262424403598 ∧ code e2262424403598 = 11058517425806 := by decide
theorem cert_e2262424403598 : check e2262424403598 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424403654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2262424403654 : Closed e2262424403654 ∧ code e2262424403654 = 11058517425862 := by decide
theorem cert_e2262424403654 : check e2262424403654 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424406894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262424406894 : Closed e2262424406894 ∧ code e2262424406894 = 11058517429102 := by decide
theorem cert_e2262424406894 : check e2262424406894 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424406902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262424406902 : Closed e2262424406902 ∧ code e2262424406902 = 11058517429110 := by decide
theorem cert_e2262424406902 : check e2262424406902 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424406958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262424406958 : Closed e2262424406958 ∧ code e2262424406958 = 11058517429166 := by decide
theorem cert_e2262424406958 : check e2262424406958 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424406970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262424406970 : Closed e2262424406970 ∧ code e2262424406970 = 11058517429178 := by decide
theorem cert_e2262424406970 : check e2262424406970 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424406998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262424406998 : Closed e2262424406998 ∧ code e2262424406998 = 11058517429206 := by decide
theorem cert_e2262424406998 : check e2262424406998 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424407002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262424407002 : Closed e2262424407002 ∧ code e2262424407002 = 11058517429210 := by decide
theorem cert_e2262424407002 : check e2262424407002 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424407278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262424407278 : Closed e2262424407278 ∧ code e2262424407278 = 11058517429486 := by decide
theorem cert_e2262424407278 : check e2262424407278 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424407286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262424407286 : Closed e2262424407286 ∧ code e2262424407286 = 11058517429494 := by decide
theorem cert_e2262424407286 : check e2262424407286 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424407614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2262424407614 : Closed e2262424407614 ∧ code e2262424407614 = 11058517429822 := by decide
theorem cert_e2262424407614 : check e2262424407614 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424407662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262424407662 : Closed e2262424407662 ∧ code e2262424407662 = 11058517429870 := by decide
theorem cert_e2262424407662 : check e2262424407662 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424407674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262424407674 : Closed e2262424407674 ∧ code e2262424407674 = 11058517429882 := by decide
theorem cert_e2262424407674 : check e2262424407674 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424407862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262424407862 : Closed e2262424407862 ∧ code e2262424407862 = 11058517430070 := by decide
theorem cert_e2262424407862 : check e2262424407862 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424407866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262424407866 : Closed e2262424407866 ∧ code e2262424407866 = 11058517430074 := by decide
theorem cert_e2262424407866 : check e2262424407866 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424407950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2262424407950 : Closed e2262424407950 ∧ code e2262424407950 = 11058517430158 := by decide
theorem cert_e2262424407950 : check e2262424407950 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424413614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2262424413614 : Closed e2262424413614 ∧ code e2262424413614 = 11058517435822 := by decide
theorem cert_e2262424413614 : check e2262424413614 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424413626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2262424413626 : Closed e2262424413626 ∧ code e2262424413626 = 11058517435834 := by decide
theorem cert_e2262424413626 : check e2262424413626 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424413674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2262424413674 : Closed e2262424413674 ∧ code e2262424413674 = 11058517435882 := by decide
theorem cert_e2262424413674 : check e2262424413674 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424413758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2262424413758 : Closed e2262424413758 ∧ code e2262424413758 = 11058517435966 := by decide
theorem cert_e2262424413758 : check e2262424413758 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424413806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262424413806 : Closed e2262424413806 ∧ code e2262424413806 = 11058517436014 := by decide
theorem cert_e2262424413806 : check e2262424413806 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424413818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262424413818 : Closed e2262424413818 ∧ code e2262424413818 = 11058517436026 := by decide
theorem cert_e2262424413818 : check e2262424413818 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424414106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262424414106 : Closed e2262424414106 ∧ code e2262424414106 = 11058517436314 := by decide
theorem cert_e2262424414106 : check e2262424414106 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424414150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2262424414150 : Closed e2262424414150 ∧ code e2262424414150 = 11058517436358 := by decide
theorem cert_e2262424414150 : check e2262424414150 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424416982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2262424416982 : Closed e2262424416982 ∧ code e2262424416982 = 11058517439190 := by decide
theorem cert_e2262424416982 : check e2262424416982 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424416986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2262424416986 : Closed e2262424416986 ∧ code e2262424416986 = 11058517439194 := by decide
theorem cert_e2262424416986 : check e2262424416986 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424417002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2262424417002 : Closed e2262424417002 ∧ code e2262424417002 = 11058517439210 := by decide
theorem cert_e2262424417002 : check e2262424417002 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424417078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262424417078 : Closed e2262424417078 ∧ code e2262424417078 = 11058517439286 := by decide
theorem cert_e2262424417078 : check e2262424417078 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424417082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262424417082 : Closed e2262424417082 ∧ code e2262424417082 = 11058517439290 := by decide
theorem cert_e2262424417082 : check e2262424417082 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424417178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262424417178 : Closed e2262424417178 ∧ code e2262424417178 = 11058517439386 := by decide
theorem cert_e2262424417178 : check e2262424417178 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424418702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2262424418702 : Closed e2262424418702 ∧ code e2262424418702 = 11058517440910 := by decide
theorem cert_e2262424418702 : check e2262424418702 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424418758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2262424418758 : Closed e2262424418758 ∧ code e2262424418758 = 11058517440966 := by decide
theorem cert_e2262424418758 : check e2262424418758 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424531310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2262424531310 : Closed e2262424531310 ∧ code e2262424531310 = 11058517553518 := by decide
theorem cert_e2262424531310 : check e2262424531310 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2262424531318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2262424531318 : Closed e2262424531318 ∧ code e2262424531318 = 11058517553526 := by decide
theorem cert_e2262424531318 : check e2262424531318 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424532526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262424532526 : Closed e2262424532526 ∧ code e2262424532526 = 11058517554734 := by decide
theorem cert_e2262424532526 : check e2262424532526 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424532706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262424532706 : Closed e2262424532706 ∧ code e2262424532706 = 11058517554914 := by decide
def e2262424532718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2262424532718 : Closed e2262424532718 ∧ code e2262424532718 = 11058517554926 := by decide
def e2262424532758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262424532758 : Closed e2262424532758 ∧ code e2262424532758 = 11058517554966 := by decide
theorem cert_e2262424532758 : check e2262424532758 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2262424532834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262424532834 : Closed e2262424532834 ∧ code e2262424532834 = 11058517555042 := by decide
theorem cert_e2262424532834 : check e2262424532834 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424532846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2262424532846 : Closed e2262424532846 ∧ code e2262424532846 = 11058517555054 := by decide
theorem cert_e2262424532846 : check e2262424532846 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424532854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2262424532854 : Closed e2262424532854 ∧ code e2262424532854 = 11058517555062 := by decide
def e2262424533166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2262424533166 : Closed e2262424533166 ∧ code e2262424533166 = 11058517555374 := by decide
theorem cert_e2262424533166 : check e2262424533166 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left]] .identityHead = true := by decide
def e2262424533178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2262424533178 : Closed e2262424533178 ∧ code e2262424533178 = 11058517555386 := by decide
theorem cert_e2262424533178 : check e2262424533178 [[],[.under],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2262424533550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262424533550 : Closed e2262424533550 ∧ code e2262424533550 = 11058517555758 := by decide
theorem cert_e2262424533550 : check e2262424533550 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2262424533730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262424533730 : Closed e2262424533730 ∧ code e2262424533730 = 11058517555938 := by decide
theorem cert_e2262424533730 : check e2262424533730 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left,.left]] .identityHead = true := by decide
def e2262424533742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2262424533742 : Closed e2262424533742 ∧ code e2262424533742 = 11058517555950 := by decide
def e2262424533898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262424533898 : Closed e2262424533898 ∧ code e2262424533898 = 11058517556106 := by decide
private def t_e2262424533898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem cert_e2262424533898 : ¬ IsSelfInterpreter e2262424533898 :=
  wSource (t := t_e2262424533898) (replay_sound (ps := []) (t := e2262424533898) (by decide)) (by decide)
def e2262424533922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262424533922 : Closed e2262424533922 ∧ code e2262424533922 = 11058517556130 := by decide
private def t_e2262424533922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem cert_e2262424533922 : ¬ IsSelfInterpreter e2262424533922 :=
  wSource (t := t_e2262424533922) (replay_sound (ps := []) (t := e2262424533922) (by decide)) (by decide)
def e2262424533934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2262424533934 : Closed e2262424533934 ∧ code e2262424533934 = 11058517556142 := by decide
private def t_e2262424533934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem cert_e2262424533934 : ¬ IsSelfInterpreter e2262424533934 :=
  wSource (t := t_e2262424533934) (replay_sound (ps := []) (t := e2262424533934) (by decide)) (by decide)
def e2262424533946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2262424533946 : Closed e2262424533946 ∧ code e2262424533946 = 11058517556154 := by decide
private def t_e2262424533946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem cert_e2262424533946 : ¬ IsSelfInterpreter e2262424533946 :=
  wSource (t := t_e2262424533946) (replay_sound (ps := []) (t := e2262424533946) (by decide)) (by decide)
def e2262424534102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2262424534102 : Closed e2262424534102 ∧ code e2262424534102 = 11058517556310 := by decide
theorem cert_e2262424534102 : check e2262424534102 [[],[.under],[.under],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2262424534106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2262424534106 : Closed e2262424534106 ∧ code e2262424534106 = 11058517556314 := by decide
theorem cert_e2262424534106 : check e2262424534106 [[],[.under],[.under],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2262424534294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262424534294 : Closed e2262424534294 ∧ code e2262424534294 = 11058517556502 := by decide
theorem cert_e2262424534294 : check e2262424534294 [[],[.under],[.under],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2262424534370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262424534370 : Closed e2262424534370 ∧ code e2262424534370 = 11058517556578 := by decide
theorem cert_e2262424534370 : check e2262424534370 [[],[.under],[.under],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2262424534382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2262424534382 : Closed e2262424534382 ∧ code e2262424534382 = 11058517556590 := by decide
theorem cert_e2262424534382 : check e2262424534382 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2262424534390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2262424534390 : Closed e2262424534390 ∧ code e2262424534390 = 11058517556598 := by decide
theorem cert_e2262424534390 : check e2262424534390 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424534410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262424534410 : Closed e2262424534410 ∧ code e2262424534410 = 11058517556618 := by decide
private def t_e2262424534410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem cert_e2262424534410 : ¬ IsSelfInterpreter e2262424534410 :=
  wSource (t := t_e2262424534410) (replay_sound (ps := []) (t := e2262424534410) (by decide)) (by decide)
def e2262424534434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262424534434 : Closed e2262424534434 ∧ code e2262424534434 = 11058517556642 := by decide
private def t_e2262424534434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem cert_e2262424534434 : ¬ IsSelfInterpreter e2262424534434 :=
  wSource (t := t_e2262424534434) (replay_sound (ps := []) (t := e2262424534434) (by decide)) (by decide)
def e2262424534446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2262424534446 : Closed e2262424534446 ∧ code e2262424534446 = 11058517556654 := by decide
private def t_e2262424534446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem cert_e2262424534446 : ¬ IsSelfInterpreter e2262424534446 :=
  wSource (t := t_e2262424534446) (replay_sound (ps := []) (t := e2262424534446) (by decide)) (by decide)
def e2262424534458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2262424534458 : Closed e2262424534458 ∧ code e2262424534458 = 11058517556666 := by decide
private def t_e2262424534458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem cert_e2262424534458 : ¬ IsSelfInterpreter e2262424534458 :=
  wSource (t := t_e2262424534458) (replay_sound (ps := []) (t := e2262424534458) (by decide)) (by decide)
def e2262424534486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2262424534486 : Closed e2262424534486 ∧ code e2262424534486 = 11058517556694 := by decide
private def t_e2262424534486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e2262424534486 : ¬ IsSelfInterpreter e2262424534486 :=
  wSource (t := t_e2262424534486) (replay_sound (ps := []) (t := e2262424534486) (by decide)) (by decide)
def e2262424534490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2262424534490 : Closed e2262424534490 ∧ code e2262424534490 = 11058517556698 := by decide
private def t_e2262424534490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e2262424534490 : ¬ IsSelfInterpreter e2262424534490 :=
  wSource (t := t_e2262424534490) (replay_sound (ps := []) (t := e2262424534490) (by decide)) (by decide)
def e2262424535534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2262424535534 : Closed e2262424535534 ∧ code e2262424535534 = 11058517557742 := by decide
theorem cert_e2262424535534 : check e2262424535534 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424535542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2262424535542 : Closed e2262424535542 ∧ code e2262424535542 = 11058517557750 := by decide
theorem cert_e2262424535542 : check e2262424535542 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2262424536302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2262424536302 : Closed e2262424536302 ∧ code e2262424536302 = 11058517558510 := by decide
theorem cert_e2262424536302 : check e2262424536302 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424536310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2262424536310 : Closed e2262424536310 ∧ code e2262424536310 = 11058517558518 := by decide
theorem cert_e2262424536310 : check e2262424536310 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424536862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2262424536862 : Closed e2262424536862 ∧ code e2262424536862 = 11058517559070 := by decide
theorem cert_e2262424536862 : check e2262424536862 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[],[]] .identityHead = true := by decide
def e2262424536974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2262424536974 : Closed e2262424536974 ∧ code e2262424536974 = 11058517559182 := by decide
theorem cert_e2262424536974 : check e2262424536974 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2262424538670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2262424538670 : Closed e2262424538670 ∧ code e2262424538670 = 11058517560878 := by decide
theorem cert_e2262424538670 : check e2262424538670 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2262424538850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2262424538850 : Closed e2262424538850 ∧ code e2262424538850 = 11058517561058 := by decide
theorem cert_e2262424538850 : check e2262424538850 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262424538862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2262424538862 : Closed e2262424538862 ∧ code e2262424538862 = 11058517561070 := by decide
def e2262424538902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2262424538902 : Closed e2262424538902 ∧ code e2262424538902 = 11058517561110 := by decide
theorem cert_e2262424538902 : check e2262424538902 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2262424538978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2262424538978 : Closed e2262424538978 ∧ code e2262424538978 = 11058517561186 := by decide
theorem cert_e2262424538978 : check e2262424538978 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262424538990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2262424538990 : Closed e2262424538990 ∧ code e2262424538990 = 11058517561198 := by decide
def e2262424538998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2262424538998 : Closed e2262424538998 ∧ code e2262424538998 = 11058517561206 := by decide
def e2262424541246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2262424541246 : Closed e2262424541246 ∧ code e2262424541246 = 11058517563454 := by decide
theorem cert_e2262424541246 : check e2262424541246 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424541666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262424541666 : Closed e2262424541666 ∧ code e2262424541666 = 11058517563874 := by decide
theorem cert_e2262424541666 : check e2262424541666 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2262424541678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2262424541678 : Closed e2262424541678 ∧ code e2262424541678 = 11058517563886 := by decide
theorem cert_e2262424541678 : check e2262424541678 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2262424542238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2262424542238 : Closed e2262424542238 ∧ code e2262424542238 = 11058517564446 := by decide
theorem cert_e2262424542238 : check e2262424542238 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424542434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262424542434 : Closed e2262424542434 ∧ code e2262424542434 = 11058517564642 := by decide
theorem cert_e2262424542434 : check e2262424542434 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424542446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262424542446 : Closed e2262424542446 ∧ code e2262424542446 = 11058517564654 := by decide
theorem cert_e2262424542446 : check e2262424542446 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424542454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262424542454 : Closed e2262424542454 ∧ code e2262424542454 = 11058517564662 := by decide
theorem cert_e2262424542454 : check e2262424542454 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424543470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2262424543470 : Closed e2262424543470 ∧ code e2262424543470 = 11058517565678 := by decide
theorem cert_e2262424543470 : check e2262424543470 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e2262424543482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2262424543482 : Closed e2262424543482 ∧ code e2262424543482 = 11058517565690 := by decide
theorem cert_e2262424543482 : check e2262424543482 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e2262424543854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2262424543854 : Closed e2262424543854 ∧ code e2262424543854 = 11058517566062 := by decide
theorem cert_e2262424543854 : check e2262424543854 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under]] .identityHead = true := by decide
def e2262424543866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2262424543866 : Closed e2262424543866 ∧ code e2262424543866 = 11058517566074 := by decide
theorem cert_e2262424543866 : check e2262424543866 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2262424544030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2262424544030 : Closed e2262424544030 ∧ code e2262424544030 = 11058517566238 := by decide
theorem cert_e2262424544030 : check e2262424544030 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e2262424544198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2262424544198 : Closed e2262424544198 ∧ code e2262424544198 = 11058517566406 := by decide
theorem cert_e2262424544198 : check e2262424544198 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e2262424544814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2262424544814 : Closed e2262424544814 ∧ code e2262424544814 = 11058517567022 := by decide
theorem cert_e2262424544814 : check e2262424544814 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2262424544994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2262424544994 : Closed e2262424544994 ∧ code e2262424544994 = 11058517567202 := by decide
theorem cert_e2262424544994 : check e2262424544994 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2262424545006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2262424545006 : Closed e2262424545006 ∧ code e2262424545006 = 11058517567214 := by decide
def e2262424545162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262424545162 : Closed e2262424545162 ∧ code e2262424545162 = 11058517567370 := by decide
theorem cert_e2262424545162 : check e2262424545162 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2262424545186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262424545186 : Closed e2262424545186 ∧ code e2262424545186 = 11058517567394 := by decide
theorem cert_e2262424545186 : check e2262424545186 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2262424545198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2262424545198 : Closed e2262424545198 ∧ code e2262424545198 = 11058517567406 := by decide
theorem cert_e2262424545198 : check e2262424545198 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[],[],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e2262424545210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2262424545210 : Closed e2262424545210 ∧ code e2262424545210 = 11058517567418 := by decide
private def t_e2262424545210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem cert_e2262424545210 : ¬ IsSelfInterpreter e2262424545210 :=
  wSource (t := t_e2262424545210) (replay_sound (ps := []) (t := e2262424545210) (by decide)) (by decide)
def e2262424545342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2262424545342 : Closed e2262424545342 ∧ code e2262424545342 = 11058517567550 := by decide
theorem cert_e2262424545342 : check e2262424545342 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2262424545762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262424545762 : Closed e2262424545762 ∧ code e2262424545762 = 11058517567970 := by decide
theorem cert_e2262424545762 : check e2262424545762 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[],[],[]] .identityHead = true := by decide
def e2262424545774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2262424545774 : Closed e2262424545774 ∧ code e2262424545774 = 11058517567982 := by decide
def e2262424546830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262424546830 : Closed e2262424546830 ∧ code e2262424546830 = 11058517569038 := by decide
private def t_e2262424546830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem cert_e2262424546830 : ¬ IsSelfInterpreter e2262424546830 :=
  wSource (t := t_e2262424546830) (replay_sound (ps := []) (t := e2262424546830) (by decide)) (by decide)
def e2262424546914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262424546914 : Closed e2262424546914 ∧ code e2262424546914 = 11058517569122 := by decide
private def t_e2262424546914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem cert_e2262424546914 : ¬ IsSelfInterpreter e2262424546914 :=
  wSource (t := t_e2262424546914) (replay_sound (ps := []) (t := e2262424546914) (by decide)) (by decide)
def e2262424546926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262424546926 : Closed e2262424546926 ∧ code e2262424546926 = 11058517569134 := by decide
private def t_e2262424546926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem cert_e2262424546926 : ¬ IsSelfInterpreter e2262424546926 :=
  wSource (t := t_e2262424546926) (replay_sound (ps := []) (t := e2262424546926) (by decide)) (by decide)
def e2262424546938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262424546938 : Closed e2262424546938 ∧ code e2262424546938 = 11058517569146 := by decide
private def t_e2262424546938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem cert_e2262424546938 : ¬ IsSelfInterpreter e2262424546938 :=
  wSource (t := t_e2262424546938) (replay_sound (ps := []) (t := e2262424546938) (by decide)) (by decide)
def e2262424547446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2262424547446 : Closed e2262424547446 ∧ code e2262424547446 = 11058517569654 := by decide
theorem cert_e2262424547446 : check e2262424547446 [[],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2262424547450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2262424547450 : Closed e2262424547450 ∧ code e2262424547450 = 11058517569658 := by decide
theorem cert_e2262424547450 : check e2262424547450 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2262424547638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262424547638 : Closed e2262424547638 ∧ code e2262424547638 = 11058517569846 := by decide
theorem cert_e2262424547638 : check e2262424547638 [[],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2262424547642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262424547642 : Closed e2262424547642 ∧ code e2262424547642 = 11058517569850 := by decide
theorem cert_e2262424547642 : check e2262424547642 [[],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2262424547726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2262424547726 : Closed e2262424547726 ∧ code e2262424547726 = 11058517569934 := by decide
theorem cert_e2262424547726 : check e2262424547726 [[],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2262424547782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2262424547782 : Closed e2262424547782 ∧ code e2262424547782 = 11058517569990 := by decide
theorem cert_e2262424547782 : check e2262424547782 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2262424548118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2262424548118 : Closed e2262424548118 ∧ code e2262424548118 = 11058517570326 := by decide
theorem cert_e2262424548118 : check e2262424548118 [[],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2262424548194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2262424548194 : Closed e2262424548194 ∧ code e2262424548194 = 11058517570402 := by decide
theorem cert_e2262424548194 : check e2262424548194 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .identityHead = true := by decide
def e2262424548206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2262424548206 : Closed e2262424548206 ∧ code e2262424548206 = 11058517570414 := by decide
def e2262424548214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2262424548214 : Closed e2262424548214 ∧ code e2262424548214 = 11058517570422 := by decide
theorem cert_e2262424548214 : check e2262424548214 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2262424548234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262424548234 : Closed e2262424548234 ∧ code e2262424548234 = 11058517570442 := by decide
theorem cert_e2262424548234 : check e2262424548234 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2262424548258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262424548258 : Closed e2262424548258 ∧ code e2262424548258 = 11058517570466 := by decide
def e2262424548270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2262424548270 : Closed e2262424548270 ∧ code e2262424548270 = 11058517570478 := by decide
def e2262424548282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2262424548282 : Closed e2262424548282 ∧ code e2262424548282 = 11058517570490 := by decide
private def t_e2262424548282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem cert_e2262424548282 : ¬ IsSelfInterpreter e2262424548282 :=
  wSource (t := t_e2262424548282) (replay_sound (ps := []) (t := e2262424548282) (by decide)) (by decide)
def e2262424548310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2262424548310 : Closed e2262424548310 ∧ code e2262424548310 = 11058517570518 := by decide
def e2262424548314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2262424548314 : Closed e2262424548314 ∧ code e2262424548314 = 11058517570522 := by decide
private def t_e2262424548314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem cert_e2262424548314 : ¬ IsSelfInterpreter e2262424548314 :=
  wSource (t := t_e2262424548314) (replay_sound (ps := []) (t := e2262424548314) (by decide)) (by decide)
def e2262424548382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2262424548382 : Closed e2262424548382 ∧ code e2262424548382 = 11058517570590 := by decide
theorem cert_e2262424548382 : check e2262424548382 [[],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2262424548578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262424548578 : Closed e2262424548578 ∧ code e2262424548578 = 11058517570786 := by decide
theorem cert_e2262424548578 : check e2262424548578 [[],[.under],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e2262424548590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262424548590 : Closed e2262424548590 ∧ code e2262424548590 = 11058517570798 := by decide
def e2262424548598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262424548598 : Closed e2262424548598 ∧ code e2262424548598 = 11058517570806 := by decide
def e2262424548878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262424548878 : Closed e2262424548878 ∧ code e2262424548878 = 11058517571086 := by decide
private def t_e2262424548878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem cert_e2262424548878 : ¬ IsSelfInterpreter e2262424548878 :=
  wSource (t := t_e2262424548878) (replay_sound (ps := []) (t := e2262424548878) (by decide)) (by decide)
def e2262424548962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262424548962 : Closed e2262424548962 ∧ code e2262424548962 = 11058517571170 := by decide
private def t_e2262424548962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem cert_e2262424548962 : ¬ IsSelfInterpreter e2262424548962 :=
  wSource (t := t_e2262424548962) (replay_sound (ps := []) (t := e2262424548962) (by decide)) (by decide)
def e2262424548974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262424548974 : Closed e2262424548974 ∧ code e2262424548974 = 11058517571182 := by decide
private def t_e2262424548974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem cert_e2262424548974 : ¬ IsSelfInterpreter e2262424548974 :=
  wSource (t := t_e2262424548974) (replay_sound (ps := []) (t := e2262424548974) (by decide)) (by decide)
def e2262424548986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262424548986 : Closed e2262424548986 ∧ code e2262424548986 = 11058517571194 := by decide
private def t_e2262424548986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem cert_e2262424548986 : ¬ IsSelfInterpreter e2262424548986 :=
  wSource (t := t_e2262424548986) (replay_sound (ps := []) (t := e2262424548986) (by decide)) (by decide)
def e2262424549174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262424549174 : Closed e2262424549174 ∧ code e2262424549174 = 11058517571382 := by decide
private def t_e2262424549174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e2262424549174 : ¬ IsSelfInterpreter e2262424549174 :=
  wSource (t := t_e2262424549174) (replay_sound (ps := []) (t := e2262424549174) (by decide)) (by decide)
def e2262424549178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262424549178 : Closed e2262424549178 ∧ code e2262424549178 = 11058517571386 := by decide
private def t_e2262424549178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e2262424549178 : ¬ IsSelfInterpreter e2262424549178 :=
  wSource (t := t_e2262424549178) (replay_sound (ps := []) (t := e2262424549178) (by decide)) (by decide)
def e2262424554350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262424554350 : Closed e2262424554350 ∧ code e2262424554350 = 11058517576558 := by decide
theorem cert_e2262424554350 : check e2262424554350 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424554358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262424554358 : Closed e2262424554358 ∧ code e2262424554358 = 11058517576566 := by decide
theorem cert_e2262424554358 : check e2262424554358 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424554414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262424554414 : Closed e2262424554414 ∧ code e2262424554414 = 11058517576622 := by decide
theorem cert_e2262424554414 : check e2262424554414 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424554426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262424554426 : Closed e2262424554426 ∧ code e2262424554426 = 11058517576634 := by decide
theorem cert_e2262424554426 : check e2262424554426 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424554454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262424554454 : Closed e2262424554454 ∧ code e2262424554454 = 11058517576662 := by decide
theorem cert_e2262424554454 : check e2262424554454 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424554458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262424554458 : Closed e2262424554458 ∧ code e2262424554458 = 11058517576666 := by decide
theorem cert_e2262424554458 : check e2262424554458 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424554734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262424554734 : Closed e2262424554734 ∧ code e2262424554734 = 11058517576942 := by decide
theorem cert_e2262424554734 : check e2262424554734 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424554742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262424554742 : Closed e2262424554742 ∧ code e2262424554742 = 11058517576950 := by decide
theorem cert_e2262424554742 : check e2262424554742 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424555118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262424555118 : Closed e2262424555118 ∧ code e2262424555118 = 11058517577326 := by decide
theorem cert_e2262424555118 : check e2262424555118 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424555130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262424555130 : Closed e2262424555130 ∧ code e2262424555130 = 11058517577338 := by decide
theorem cert_e2262424555130 : check e2262424555130 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424555318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262424555318 : Closed e2262424555318 ∧ code e2262424555318 = 11058517577526 := by decide
theorem cert_e2262424555318 : check e2262424555318 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424555322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262424555322 : Closed e2262424555322 ∧ code e2262424555322 = 11058517577530 := by decide
theorem cert_e2262424555322 : check e2262424555322 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424563246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2262424563246 : Closed e2262424563246 ∧ code e2262424563246 = 11058517585454 := by decide
theorem cert_e2262424563246 : check e2262424563246 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262424563426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2262424563426 : Closed e2262424563426 ∧ code e2262424563426 = 11058517585634 := by decide
def e2262424563438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2262424563438 : Closed e2262424563438 ∧ code e2262424563438 = 11058517585646 := by decide
def e2262424563478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2262424563478 : Closed e2262424563478 ∧ code e2262424563478 = 11058517585686 := by decide
theorem cert_e2262424563478 : check e2262424563478 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262424533898
#print axioms Blc.Floor43.cert_e2262424533922
#print axioms Blc.Floor43.cert_e2262424533934
#print axioms Blc.Floor43.cert_e2262424533946
#print axioms Blc.Floor43.cert_e2262424534410
#print axioms Blc.Floor43.cert_e2262424534434
#print axioms Blc.Floor43.cert_e2262424534446
#print axioms Blc.Floor43.cert_e2262424534458
#print axioms Blc.Floor43.cert_e2262424534486
#print axioms Blc.Floor43.cert_e2262424534490
#print axioms Blc.Floor43.cert_e2262424545210
#print axioms Blc.Floor43.cert_e2262424546830
#print axioms Blc.Floor43.cert_e2262424546914
#print axioms Blc.Floor43.cert_e2262424546926
#print axioms Blc.Floor43.cert_e2262424546938
#print axioms Blc.Floor43.cert_e2262424548282
#print axioms Blc.Floor43.cert_e2262424548314
#print axioms Blc.Floor43.cert_e2262424548878
#print axioms Blc.Floor43.cert_e2262424548962
#print axioms Blc.Floor43.cert_e2262424548974
#print axioms Blc.Floor43.cert_e2262424548986
#print axioms Blc.Floor43.cert_e2262424549174
#print axioms Blc.Floor43.cert_e2262424549178
