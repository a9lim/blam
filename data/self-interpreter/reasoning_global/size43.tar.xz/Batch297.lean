import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411626017654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2411626017654 : Closed e2411626017654 ∧ code e2411626017654 = 11207719039862 := by decide
theorem cert_e2411626017654 : check e2411626017654 [[],[]] .smaller = true := by decide
def e2411626017658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2411626017658 : Closed e2411626017658 ∧ code e2411626017658 = 11207719039866 := by decide
theorem cert_e2411626017658 : check e2411626017658 [[],[]] .three = true := by decide
def e2411626017710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2411626017710 : Closed e2411626017710 ∧ code e2411626017710 = 11207719039918 := by decide
theorem cert_e2411626017710 : check e2411626017710 [[],[]] .smaller = true := by decide
def e2411626017722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2411626017722 : Closed e2411626017722 ∧ code e2411626017722 = 11207719039930 := by decide
theorem cert_e2411626017722 : check e2411626017722 [[],[]] .smaller = true := by decide
def e2411626017750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2411626017750 : Closed e2411626017750 ∧ code e2411626017750 = 11207719039958 := by decide
theorem cert_e2411626017750 : check e2411626017750 [[],[]] .smaller = true := by decide
def e2411626017754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2411626017754 : Closed e2411626017754 ∧ code e2411626017754 = 11207719039962 := by decide
theorem cert_e2411626017754 : check e2411626017754 [[],[]] .smaller = true := by decide
def e2411626017770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2411626017770 : Closed e2411626017770 ∧ code e2411626017770 = 11207719039978 := by decide
theorem cert_e2411626017770 : check e2411626017770 [[],[]] .three = true := by decide
def e2411626018014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411626018014 : Closed e2411626018014 ∧ code e2411626018014 = 11207719040222 := by decide
theorem cert_e2411626018014 : check e2411626018014 [[],[]] .three = true := by decide
def e2411626018030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411626018030 : Closed e2411626018030 ∧ code e2411626018030 = 11207719040238 := by decide
theorem cert_e2411626018030 : check e2411626018030 [[],[]] .smaller = true := by decide
def e2411626018038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411626018038 : Closed e2411626018038 ∧ code e2411626018038 = 11207719040246 := by decide
theorem cert_e2411626018038 : check e2411626018038 [[],[]] .smaller = true := by decide
def e2411626018042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411626018042 : Closed e2411626018042 ∧ code e2411626018042 = 11207719040250 := by decide
theorem cert_e2411626018042 : check e2411626018042 [[],[]] .three = true := by decide
def e2411626018366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2411626018366 : Closed e2411626018366 ∧ code e2411626018366 = 11207719040574 := by decide
theorem cert_e2411626018366 : check e2411626018366 [[],[]] .three = true := by decide
def e2411626018414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411626018414 : Closed e2411626018414 ∧ code e2411626018414 = 11207719040622 := by decide
theorem cert_e2411626018414 : check e2411626018414 [[],[]] .smaller = true := by decide
def e2411626018426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411626018426 : Closed e2411626018426 ∧ code e2411626018426 = 11207719040634 := by decide
theorem cert_e2411626018426 : check e2411626018426 [[],[]] .smaller = true := by decide
def e2411626018590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e2411626018590 : Closed e2411626018590 ∧ code e2411626018590 = 11207719040798 := by decide
theorem cert_e2411626018590 : check e2411626018590 [[],[]] .smaller = true := by decide
def e2411626018614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411626018614 : Closed e2411626018614 ∧ code e2411626018614 = 11207719040822 := by decide
theorem cert_e2411626018614 : check e2411626018614 [[],[]] .smaller = true := by decide
def e2411626018618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411626018618 : Closed e2411626018618 ∧ code e2411626018618 = 11207719040826 := by decide
theorem cert_e2411626018618 : check e2411626018618 [[],[]] .smaller = true := by decide
def e2411626018702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2411626018702 : Closed e2411626018702 ∧ code e2411626018702 = 11207719040910 := by decide
theorem cert_e2411626018702 : check e2411626018702 [[],[]] .three = true := by decide
def e2411626018714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411626018714 : Closed e2411626018714 ∧ code e2411626018714 = 11207719040922 := by decide
theorem cert_e2411626018714 : check e2411626018714 [[],[]] .three = true := by decide
def e2411626019038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2411626019038 : Closed e2411626019038 ∧ code e2411626019038 = 11207719041246 := by decide
theorem cert_e2411626019038 : check e2411626019038 [[],[]] .three = true := by decide
def e2411626019066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2411626019066 : Closed e2411626019066 ∧ code e2411626019066 = 11207719041274 := by decide
theorem cert_e2411626019066 : check e2411626019066 [[],[]] .three = true := by decide
def e2411626019246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2411626019246 : Closed e2411626019246 ∧ code e2411626019246 = 11207719041454 := by decide
theorem cert_e2411626019246 : check e2411626019246 [[],[]] .smaller = true := by decide
def e2411626019258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2411626019258 : Closed e2411626019258 ∧ code e2411626019258 = 11207719041466 := by decide
theorem cert_e2411626019258 : check e2411626019258 [[],[]] .smaller = true := by decide
def e2411626019306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2411626019306 : Closed e2411626019306 ∧ code e2411626019306 = 11207719041514 := by decide
theorem cert_e2411626019306 : check e2411626019306 [[],[]] .smaller = true := by decide
def e2411626019390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2411626019390 : Closed e2411626019390 ∧ code e2411626019390 = 11207719041598 := by decide
theorem cert_e2411626019390 : check e2411626019390 [[],[]] .three = true := by decide
def e2411626019438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411626019438 : Closed e2411626019438 ∧ code e2411626019438 = 11207719041646 := by decide
theorem cert_e2411626019438 : check e2411626019438 [[],[]] .smaller = true := by decide
def e2411626019450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411626019450 : Closed e2411626019450 ∧ code e2411626019450 = 11207719041658 := by decide
theorem cert_e2411626019450 : check e2411626019450 [[],[]] .smaller = true := by decide
def e2411626019738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411626019738 : Closed e2411626019738 ∧ code e2411626019738 = 11207719041946 := by decide
theorem cert_e2411626019738 : check e2411626019738 [[],[]] .smaller = true := by decide
def e2411626019782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2411626019782 : Closed e2411626019782 ∧ code e2411626019782 = 11207719041990 := by decide
theorem cert_e2411626019782 : check e2411626019782 [[],[]] .three = true := by decide
def e2411626019950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411626019950 : Closed e2411626019950 ∧ code e2411626019950 = 11207719042158 := by decide
theorem cert_e2411626019950 : check e2411626019950 [[],[]] .smaller = true := by decide
def e2411626019962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411626019962 : Closed e2411626019962 ∧ code e2411626019962 = 11207719042170 := by decide
theorem cert_e2411626019962 : check e2411626019962 [[],[]] .smaller = true := by decide
def e2411626020054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2411626020054 : Closed e2411626020054 ∧ code e2411626020054 = 11207719042262 := by decide
theorem cert_e2411626020054 : check e2411626020054 [[],[]] .smaller = true := by decide
def e2411626020058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2411626020058 : Closed e2411626020058 ∧ code e2411626020058 = 11207719042266 := by decide
theorem cert_e2411626020058 : check e2411626020058 [[],[]] .smaller = true := by decide
def e2411626020074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2411626020074 : Closed e2411626020074 ∧ code e2411626020074 = 11207719042282 := by decide
theorem cert_e2411626020074 : check e2411626020074 [[],[]] .smaller = true := by decide
def e2411626020126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411626020126 : Closed e2411626020126 ∧ code e2411626020126 = 11207719042334 := by decide
theorem cert_e2411626020126 : check e2411626020126 [[],[]] .smaller = true := by decide
def e2411626020150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411626020150 : Closed e2411626020150 ∧ code e2411626020150 = 11207719042358 := by decide
theorem cert_e2411626020150 : check e2411626020150 [[],[]] .smaller = true := by decide
def e2411626020154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411626020154 : Closed e2411626020154 ∧ code e2411626020154 = 11207719042362 := by decide
theorem cert_e2411626020154 : check e2411626020154 [[],[]] .smaller = true := by decide
def e2411626020250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411626020250 : Closed e2411626020250 ∧ code e2411626020250 = 11207719042458 := by decide
theorem cert_e2411626020250 : check e2411626020250 [[],[]] .smaller = true := by decide
def e2411626020294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411626020294 : Closed e2411626020294 ∧ code e2411626020294 = 11207719042502 := by decide
theorem cert_e2411626020294 : check e2411626020294 [[],[]] .smaller = true := by decide
def e2411626020318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e2411626020318 : Closed e2411626020318 ∧ code e2411626020318 = 11207719042526 := by decide
theorem cert_e2411626020318 : check e2411626020318 [[],[]] .three = true := by decide
def e2411626020334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e2411626020334 : Closed e2411626020334 ∧ code e2411626020334 = 11207719042542 := by decide
theorem cert_e2411626020334 : check e2411626020334 [[],[]] .three = true := by decide
def e2411626020406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411626020406 : Closed e2411626020406 ∧ code e2411626020406 = 11207719042614 := by decide
theorem cert_e2411626020406 : check e2411626020406 [[],[]] .three = true := by decide
def e2411626020410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411626020410 : Closed e2411626020410 ∧ code e2411626020410 = 11207719042618 := by decide
theorem cert_e2411626020410 : check e2411626020410 [[],[]] .three = true := by decide
def e2411626020458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2411626020458 : Closed e2411626020458 ∧ code e2411626020458 = 11207719042666 := by decide
theorem cert_e2411626020458 : check e2411626020458 [[],[]] .three = true := by decide
def e2411626020494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411626020494 : Closed e2411626020494 ∧ code e2411626020494 = 11207719042702 := by decide
theorem cert_e2411626020494 : check e2411626020494 [[],[]] .three = true := by decide
def e2411626020506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411626020506 : Closed e2411626020506 ∧ code e2411626020506 = 11207719042714 := by decide
theorem cert_e2411626020506 : check e2411626020506 [[],[]] .three = true := by decide
def e2411626020550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411626020550 : Closed e2411626020550 ∧ code e2411626020550 = 11207719042758 := by decide
theorem cert_e2411626020550 : check e2411626020550 [[],[]] .three = true := by decide
def e2411626020590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e2411626020590 : Closed e2411626020590 ∧ code e2411626020590 = 11207719042798 := by decide
theorem cert_e2411626020590 : check e2411626020590 [[],[]] .three = true := by decide
def e2411626021822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2411626021822 : Closed e2411626021822 ∧ code e2411626021822 = 11207719044030 := by decide
theorem cert_e2411626021822 : check e2411626021822 [[],[]] .three = true := by decide
def e2411626021854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2411626021854 : Closed e2411626021854 ∧ code e2411626021854 = 11207719044062 := by decide
theorem cert_e2411626021854 : check e2411626021854 [[],[]] .smaller = true := by decide
def e2411626021870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2411626021870 : Closed e2411626021870 ∧ code e2411626021870 = 11207719044078 := by decide
theorem cert_e2411626021870 : check e2411626021870 [[],[]] .smaller = true := by decide
def e2411626021878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2411626021878 : Closed e2411626021878 ∧ code e2411626021878 = 11207719044086 := by decide
theorem cert_e2411626021878 : check e2411626021878 [[],[]] .three = true := by decide
def e2411626023774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2411626023774 : Closed e2411626023774 ∧ code e2411626023774 = 11207719045982 := by decide
theorem cert_e2411626023774 : check e2411626023774 [[],[]] .three = true := by decide
def e2411626023790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411626023790 : Closed e2411626023790 ∧ code e2411626023790 = 11207719045998 := by decide
theorem cert_e2411626023790 : check e2411626023790 [[],[]] .smaller = true := by decide
def e2411626023798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411626023798 : Closed e2411626023798 ∧ code e2411626023798 = 11207719046006 := by decide
theorem cert_e2411626023798 : check e2411626023798 [[],[]] .smaller = true := by decide
def e2411626023802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2411626023802 : Closed e2411626023802 ∧ code e2411626023802 = 11207719046010 := by decide
theorem cert_e2411626023802 : check e2411626023802 [[],[]] .three = true := by decide
def e2411626023854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411626023854 : Closed e2411626023854 ∧ code e2411626023854 = 11207719046062 := by decide
theorem cert_e2411626023854 : check e2411626023854 [[],[]] .smaller = true := by decide
def e2411626023866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411626023866 : Closed e2411626023866 ∧ code e2411626023866 = 11207719046074 := by decide
theorem cert_e2411626023866 : check e2411626023866 [[],[]] .smaller = true := by decide
def e2411626023894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411626023894 : Closed e2411626023894 ∧ code e2411626023894 = 11207719046102 := by decide
theorem cert_e2411626023894 : check e2411626023894 [[],[]] .smaller = true := by decide
def e2411626023898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411626023898 : Closed e2411626023898 ∧ code e2411626023898 = 11207719046106 := by decide
theorem cert_e2411626023898 : check e2411626023898 [[],[]] .smaller = true := by decide
def e2411626023914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2411626023914 : Closed e2411626023914 ∧ code e2411626023914 = 11207719046122 := by decide
theorem cert_e2411626023914 : check e2411626023914 [[],[]] .three = true := by decide
def e2411626024158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411626024158 : Closed e2411626024158 ∧ code e2411626024158 = 11207719046366 := by decide
theorem cert_e2411626024158 : check e2411626024158 [[],[]] .three = true := by decide
def e2411626024174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411626024174 : Closed e2411626024174 ∧ code e2411626024174 = 11207719046382 := by decide
theorem cert_e2411626024174 : check e2411626024174 [[],[]] .smaller = true := by decide
def e2411626024182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411626024182 : Closed e2411626024182 ∧ code e2411626024182 = 11207719046390 := by decide
theorem cert_e2411626024182 : check e2411626024182 [[],[]] .smaller = true := by decide
def e2411626024186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411626024186 : Closed e2411626024186 ∧ code e2411626024186 = 11207719046394 := by decide
theorem cert_e2411626024186 : check e2411626024186 [[],[]] .three = true := by decide
def e2411626024510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2411626024510 : Closed e2411626024510 ∧ code e2411626024510 = 11207719046718 := by decide
theorem cert_e2411626024510 : check e2411626024510 [[],[]] .three = true := by decide
def e2411626024558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411626024558 : Closed e2411626024558 ∧ code e2411626024558 = 11207719046766 := by decide
theorem cert_e2411626024558 : check e2411626024558 [[],[]] .smaller = true := by decide
def e2411626024570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411626024570 : Closed e2411626024570 ∧ code e2411626024570 = 11207719046778 := by decide
theorem cert_e2411626024570 : check e2411626024570 [[],[]] .smaller = true := by decide
def e2411626024734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e2411626024734 : Closed e2411626024734 ∧ code e2411626024734 = 11207719046942 := by decide
theorem cert_e2411626024734 : check e2411626024734 [[],[]] .smaller = true := by decide
def e2411626024758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411626024758 : Closed e2411626024758 ∧ code e2411626024758 = 11207719046966 := by decide
theorem cert_e2411626024758 : check e2411626024758 [[],[]] .smaller = true := by decide
def e2411626024762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411626024762 : Closed e2411626024762 ∧ code e2411626024762 = 11207719046970 := by decide
theorem cert_e2411626024762 : check e2411626024762 [[],[]] .smaller = true := by decide
def e2411626024846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2411626024846 : Closed e2411626024846 ∧ code e2411626024846 = 11207719047054 := by decide
theorem cert_e2411626024846 : check e2411626024846 [[],[]] .three = true := by decide
def e2411626024858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411626024858 : Closed e2411626024858 ∧ code e2411626024858 = 11207719047066 := by decide
theorem cert_e2411626024858 : check e2411626024858 [[],[]] .three = true := by decide
def e2411626029534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2411626029534 : Closed e2411626029534 ∧ code e2411626029534 = 11207719051742 := by decide
theorem cert_e2411626029534 : check e2411626029534 [[],[]] .smaller = true := by decide
def e2411626029558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2411626029558 : Closed e2411626029558 ∧ code e2411626029558 = 11207719051766 := by decide
theorem cert_e2411626029558 : check e2411626029558 [[],[]] .smaller = true := by decide
def e2411626030510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2411626030510 : Closed e2411626030510 ∧ code e2411626030510 = 11207719052718 := by decide
theorem cert_e2411626030510 : check e2411626030510 [[],[]] .smaller = true := by decide
def e2411626030522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2411626030522 : Closed e2411626030522 ∧ code e2411626030522 = 11207719052730 := by decide
theorem cert_e2411626030522 : check e2411626030522 [[],[]] .smaller = true := by decide
def e2411626030570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2411626030570 : Closed e2411626030570 ∧ code e2411626030570 = 11207719052778 := by decide
theorem cert_e2411626030570 : check e2411626030570 [[],[]] .smaller = true := by decide
def e2411626030654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2411626030654 : Closed e2411626030654 ∧ code e2411626030654 = 11207719052862 := by decide
theorem cert_e2411626030654 : check e2411626030654 [[],[]] .three = true := by decide
def e2411626030702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411626030702 : Closed e2411626030702 ∧ code e2411626030702 = 11207719052910 := by decide
theorem cert_e2411626030702 : check e2411626030702 [[],[]] .smaller = true := by decide
def e2411626030714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411626030714 : Closed e2411626030714 ∧ code e2411626030714 = 11207719052922 := by decide
theorem cert_e2411626030714 : check e2411626030714 [[],[]] .smaller = true := by decide
def e2411626031002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411626031002 : Closed e2411626031002 ∧ code e2411626031002 = 11207719053210 := by decide
theorem cert_e2411626031002 : check e2411626031002 [[],[]] .smaller = true := by decide
def e2411626031046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2411626031046 : Closed e2411626031046 ∧ code e2411626031046 = 11207719053254 := by decide
theorem cert_e2411626031046 : check e2411626031046 [[],[]] .three = true := by decide
def e2411626033390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2411626033390 : Closed e2411626033390 ∧ code e2411626033390 = 11207719055598 := by decide
theorem cert_e2411626033390 : check e2411626033390 [[],[]] .smaller = true := by decide
def e2411626033398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2411626033398 : Closed e2411626033398 ∧ code e2411626033398 = 11207719055606 := by decide
theorem cert_e2411626033398 : check e2411626033398 [[],[]] .smaller = true := by decide
def e2411626033878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411626033878 : Closed e2411626033878 ∧ code e2411626033878 = 11207719056086 := by decide
theorem cert_e2411626033878 : check e2411626033878 [[],[]] .smaller = true := by decide
def e2411626033882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411626033882 : Closed e2411626033882 ∧ code e2411626033882 = 11207719056090 := by decide
theorem cert_e2411626033882 : check e2411626033882 [[],[]] .smaller = true := by decide
def e2411626033898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411626033898 : Closed e2411626033898 ∧ code e2411626033898 = 11207719056106 := by decide
theorem cert_e2411626033898 : check e2411626033898 [[],[]] .smaller = true := by decide
def e2411626033950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411626033950 : Closed e2411626033950 ∧ code e2411626033950 = 11207719056158 := by decide
theorem cert_e2411626033950 : check e2411626033950 [[],[]] .smaller = true := by decide
def e2411626033974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411626033974 : Closed e2411626033974 ∧ code e2411626033974 = 11207719056182 := by decide
theorem cert_e2411626033974 : check e2411626033974 [[],[]] .smaller = true := by decide
def e2411626033978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411626033978 : Closed e2411626033978 ∧ code e2411626033978 = 11207719056186 := by decide
theorem cert_e2411626033978 : check e2411626033978 [[],[]] .smaller = true := by decide
def e2411626034074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411626034074 : Closed e2411626034074 ∧ code e2411626034074 = 11207719056282 := by decide
theorem cert_e2411626034074 : check e2411626034074 [[],[]] .smaller = true := by decide
def e2411626034118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411626034118 : Closed e2411626034118 ∧ code e2411626034118 = 11207719056326 := by decide
theorem cert_e2411626034118 : check e2411626034118 [[],[]] .smaller = true := by decide
def e2411626034142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e2411626034142 : Closed e2411626034142 ∧ code e2411626034142 = 11207719056350 := by decide
theorem cert_e2411626034142 : check e2411626034142 [[],[]] .three = true := by decide
def e2411626034158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e2411626034158 : Closed e2411626034158 ∧ code e2411626034158 = 11207719056366 := by decide
theorem cert_e2411626034158 : check e2411626034158 [[],[]] .three = true := by decide
def e2411626035318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2411626035318 : Closed e2411626035318 ∧ code e2411626035318 = 11207719057526 := by decide
theorem cert_e2411626035318 : check e2411626035318 [[],[]] .three = true := by decide
def e2411626035562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2411626035562 : Closed e2411626035562 ∧ code e2411626035562 = 11207719057770 := by decide
theorem cert_e2411626035562 : check e2411626035562 [[],[]] .three = true := by decide
def e2411626035598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411626035598 : Closed e2411626035598 ∧ code e2411626035598 = 11207719057806 := by decide
theorem cert_e2411626035598 : check e2411626035598 [[],[]] .three = true := by decide
def e2411626035610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411626035610 : Closed e2411626035610 ∧ code e2411626035610 = 11207719057818 := by decide
theorem cert_e2411626035610 : check e2411626035610 [[],[]] .three = true := by decide
def e2411626035654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411626035654 : Closed e2411626035654 ∧ code e2411626035654 = 11207719057862 := by decide
theorem cert_e2411626035654 : check e2411626035654 [[],[]] .three = true := by decide
def e2411626035694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e2411626035694 : Closed e2411626035694 ∧ code e2411626035694 = 11207719057902 := by decide
theorem cert_e2411626035694 : check e2411626035694 [[],[]] .three = true := by decide
def e2411626108638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411626108638 : Closed e2411626108638 ∧ code e2411626108638 = 11207719130846 := by decide
theorem cert_e2411626108638 : check e2411626108638 [[],[]] .smaller = true := by decide
def e2411626108662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411626108662 : Closed e2411626108662 ∧ code e2411626108662 = 11207719130870 := by decide
theorem cert_e2411626108662 : check e2411626108662 [[],[]] .smaller = true := by decide
def e2411626108766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411626108766 : Closed e2411626108766 ∧ code e2411626108766 = 11207719130974 := by decide
theorem cert_e2411626108766 : check e2411626108766 [[],[]] .smaller = true := by decide
def e2411626108782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e2411626108782 : Closed e2411626108782 ∧ code e2411626108782 = 11207719130990 := by decide
theorem cert_e2411626108782 : check e2411626108782 [[],[]] .smaller = true := by decide
def e2411626108790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e2411626108790 : Closed e2411626108790 ∧ code e2411626108790 = 11207719130998 := by decide
theorem cert_e2411626108790 : check e2411626108790 [[],[]] .smaller = true := by decide
def e2411626108794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411626108794 : Closed e2411626108794 ∧ code e2411626108794 = 11207719131002 := by decide
theorem cert_e2411626108794 : check e2411626108794 [[],[]] .smaller = true := by decide
def e2411626108854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e2411626108854 : Closed e2411626108854 ∧ code e2411626108854 = 11207719131062 := by decide
theorem cert_e2411626108854 : check e2411626108854 [[],[]] .smaller = true := by decide
def e2411626108886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411626108886 : Closed e2411626108886 ∧ code e2411626108886 = 11207719131094 := by decide
theorem cert_e2411626108886 : check e2411626108886 [[],[]] .smaller = true := by decide
def e2411626108890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411626108890 : Closed e2411626108890 ∧ code e2411626108890 = 11207719131098 := by decide
theorem cert_e2411626108890 : check e2411626108890 [[],[]] .smaller = true := by decide
def e2411626109406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411626109406 : Closed e2411626109406 ∧ code e2411626109406 = 11207719131614 := by decide
theorem cert_e2411626109406 : check e2411626109406 [[],[]] .smaller = true := by decide
def e2411626109430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411626109430 : Closed e2411626109430 ∧ code e2411626109430 = 11207719131638 := by decide
theorem cert_e2411626109430 : check e2411626109430 [[],[]] .smaller = true := by decide
def e2411626110174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411626110174 : Closed e2411626110174 ∧ code e2411626110174 = 11207719132382 := by decide
theorem cert_e2411626110174 : check e2411626110174 [[],[]] .smaller = true := by decide
def e2411626110190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411626110190 : Closed e2411626110190 ∧ code e2411626110190 = 11207719132398 := by decide
theorem cert_e2411626110190 : check e2411626110190 [[],[]] .smaller = true := by decide
def e2411626110198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411626110198 : Closed e2411626110198 ∧ code e2411626110198 = 11207719132406 := by decide
theorem cert_e2411626110198 : check e2411626110198 [[],[]] .smaller = true := by decide
def e2411626110202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411626110202 : Closed e2411626110202 ∧ code e2411626110202 = 11207719132410 := by decide
theorem cert_e2411626110202 : check e2411626110202 [[],[]] .smaller = true := by decide
def e2411626110582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411626110582 : Closed e2411626110582 ∧ code e2411626110582 = 11207719132790 := by decide
theorem cert_e2411626110582 : check e2411626110582 [[],[]] .smaller = true := by decide
def e2411626110774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411626110774 : Closed e2411626110774 ∧ code e2411626110774 = 11207719132982 := by decide
theorem cert_e2411626110774 : check e2411626110774 [[],[]] .smaller = true := by decide
def e2411626110778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411626110778 : Closed e2411626110778 ∧ code e2411626110778 = 11207719132986 := by decide
theorem cert_e2411626110778 : check e2411626110778 [[],[]] .smaller = true := by decide
def e2411626124982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2411626124982 : Closed e2411626124982 ∧ code e2411626124982 = 11207719147190 := by decide
theorem cert_e2411626124982 : check e2411626124982 [[],[]] .smaller = true := by decide
def e2411626125014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2411626125014 : Closed e2411626125014 ∧ code e2411626125014 = 11207719147222 := by decide
theorem cert_e2411626125014 : check e2411626125014 [[],[]] .smaller = true := by decide
def e2411626125018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2411626125018 : Closed e2411626125018 ∧ code e2411626125018 = 11207719147226 := by decide
theorem cert_e2411626125018 : check e2411626125018 [[],[]] .smaller = true := by decide
def e2411626125142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2411626125142 : Closed e2411626125142 ∧ code e2411626125142 = 11207719147350 := by decide
theorem cert_e2411626125142 : check e2411626125142 [[],[]] .smaller = true := by decide
def e2411626125146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2411626125146 : Closed e2411626125146 ∧ code e2411626125146 = 11207719147354 := by decide
theorem cert_e2411626125146 : check e2411626125146 [[],[]] .smaller = true := by decide
def e2411626125162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2411626125162 : Closed e2411626125162 ∧ code e2411626125162 = 11207719147370 := by decide
theorem cert_e2411626125162 : check e2411626125162 [[],[]] .smaller = true := by decide
def e2411626125534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2411626125534 : Closed e2411626125534 ∧ code e2411626125534 = 11207719147742 := by decide
theorem cert_e2411626125534 : check e2411626125534 [[],[]] .three = true := by decide
def e2411626125550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2411626125550 : Closed e2411626125550 ∧ code e2411626125550 = 11207719147758 := by decide
theorem cert_e2411626125550 : check e2411626125550 [[],[]] .smaller = true := by decide
def e2411626125558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2411626125558 : Closed e2411626125558 ∧ code e2411626125558 = 11207719147766 := by decide
theorem cert_e2411626125558 : check e2411626125558 [[],[]] .smaller = true := by decide
def e2411626125562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2411626125562 : Closed e2411626125562 ∧ code e2411626125562 = 11207719147770 := by decide
theorem cert_e2411626125562 : check e2411626125562 [[],[]] .three = true := by decide
def e2411626125750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2411626125750 : Closed e2411626125750 ∧ code e2411626125750 = 11207719147958 := by decide
theorem cert_e2411626125750 : check e2411626125750 [[],[]] .smaller = true := by decide
def e2411626125782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2411626125782 : Closed e2411626125782 ∧ code e2411626125782 = 11207719147990 := by decide
theorem cert_e2411626125782 : check e2411626125782 [[],[]] .smaller = true := by decide
def e2411626125786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2411626125786 : Closed e2411626125786 ∧ code e2411626125786 = 11207719147994 := by decide
theorem cert_e2411626125786 : check e2411626125786 [[],[]] .smaller = true := by decide
def e2411626125886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2411626125886 : Closed e2411626125886 ∧ code e2411626125886 = 11207719148094 := by decide
theorem cert_e2411626125886 : check e2411626125886 [[],[]] .three = true := by decide
def e2411626125942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411626125942 : Closed e2411626125942 ∧ code e2411626125942 = 11207719148150 := by decide
theorem cert_e2411626125942 : check e2411626125942 [[],[]] .smaller = true := by decide
def e2411626126110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2411626126110 : Closed e2411626126110 ∧ code e2411626126110 = 11207719148318 := by decide
theorem cert_e2411626126110 : check e2411626126110 [[],[]] .smaller = true := by decide
def e2411626126134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411626126134 : Closed e2411626126134 ∧ code e2411626126134 = 11207719148342 := by decide
theorem cert_e2411626126134 : check e2411626126134 [[],[]] .smaller = true := by decide
def e2411626126138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411626126138 : Closed e2411626126138 ∧ code e2411626126138 = 11207719148346 := by decide
theorem cert_e2411626126138 : check e2411626126138 [[],[]] .smaller = true := by decide
def e2411626126222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2411626126222 : Closed e2411626126222 ∧ code e2411626126222 = 11207719148430 := by decide
theorem cert_e2411626126222 : check e2411626126222 [[],[]] .smaller = true := by decide
def e2411626126278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2411626126278 : Closed e2411626126278 ∧ code e2411626126278 = 11207719148486 := by decide
theorem cert_e2411626126278 : check e2411626126278 [[],[]] .three = true := by decide
def e2411626126302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 3))))))))
theorem wire_e2411626126302 : Closed e2411626126302 ∧ code e2411626126302 = 11207719148510 := by decide
theorem cert_e2411626126302 : check e2411626126302 [[],[]] .three = true := by decide
def e2411626126446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411626126446 : Closed e2411626126446 ∧ code e2411626126446 = 11207719148654 := by decide
theorem cert_e2411626126446 : check e2411626126446 [[],[]] .smaller = true := by decide
def e2411626126458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411626126458 : Closed e2411626126458 ∧ code e2411626126458 = 11207719148666 := by decide
theorem cert_e2411626126458 : check e2411626126458 [[],[]] .smaller = true := by decide
def e2411626126550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2411626126550 : Closed e2411626126550 ∧ code e2411626126550 = 11207719148758 := by decide
theorem cert_e2411626126550 : check e2411626126550 [[],[]] .smaller = true := by decide
def e2411626126554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2411626126554 : Closed e2411626126554 ∧ code e2411626126554 = 11207719148762 := by decide
theorem cert_e2411626126554 : check e2411626126554 [[],[]] .smaller = true := by decide
def e2411626126570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2411626126570 : Closed e2411626126570 ∧ code e2411626126570 = 11207719148778 := by decide
theorem cert_e2411626126570 : check e2411626126570 [[],[]] .smaller = true := by decide
def e2411626126622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411626126622 : Closed e2411626126622 ∧ code e2411626126622 = 11207719148830 := by decide
theorem cert_e2411626126622 : check e2411626126622 [[],[]] .smaller = true := by decide
def e2411626126646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411626126646 : Closed e2411626126646 ∧ code e2411626126646 = 11207719148854 := by decide
theorem cert_e2411626126646 : check e2411626126646 [[],[]] .smaller = true := by decide
def e2411626126650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411626126650 : Closed e2411626126650 ∧ code e2411626126650 = 11207719148858 := by decide
theorem cert_e2411626126650 : check e2411626126650 [[],[]] .smaller = true := by decide
def e2411626126746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411626126746 : Closed e2411626126746 ∧ code e2411626126746 = 11207719148954 := by decide
theorem cert_e2411626126746 : check e2411626126746 [[],[]] .smaller = true := by decide
def e2411626126790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411626126790 : Closed e2411626126790 ∧ code e2411626126790 = 11207719148998 := by decide
theorem cert_e2411626126790 : check e2411626126790 [[],[]] .smaller = true := by decide
def e2411626126814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2411626126814 : Closed e2411626126814 ∧ code e2411626126814 = 11207719149022 := by decide
theorem cert_e2411626126814 : check e2411626126814 [[],[]] .three = true := by decide
def e2411626126830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2411626126830 : Closed e2411626126830 ∧ code e2411626126830 = 11207719149038 := by decide
theorem cert_e2411626126830 : check e2411626126830 [[],[]] .three = true := by decide
def e2411626126902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411626126902 : Closed e2411626126902 ∧ code e2411626126902 = 11207719149110 := by decide
theorem cert_e2411626126902 : check e2411626126902 [[],[]] .smaller = true := by decide
def e2411626126906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411626126906 : Closed e2411626126906 ∧ code e2411626126906 = 11207719149114 := by decide
theorem cert_e2411626126906 : check e2411626126906 [[],[]] .smaller = true := by decide
def e2411626126990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411626126990 : Closed e2411626126990 ∧ code e2411626126990 = 11207719149198 := by decide
theorem cert_e2411626126990 : check e2411626126990 [[],[]] .smaller = true := by decide
def e2411626127046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411626127046 : Closed e2411626127046 ∧ code e2411626127046 = 11207719149254 := by decide
theorem cert_e2411626127046 : check e2411626127046 [[],[]] .smaller = true := by decide
def e2411626127070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2411626127070 : Closed e2411626127070 ∧ code e2411626127070 = 11207719149278 := by decide
theorem cert_e2411626127070 : check e2411626127070 [[],[]] .three = true := by decide
def e2411626127094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2411626127094 : Closed e2411626127094 ∧ code e2411626127094 = 11207719149302 := by decide
theorem cert_e2411626127094 : check e2411626127094 [[],[]] .three = true := by decide
def e2411626127130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411626127130 : Closed e2411626127130 ∧ code e2411626127130 = 11207719149338 := by decide
theorem cert_e2411626127130 : check e2411626127130 [[],[]] .three = true := by decide
def e2411626127174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411626127174 : Closed e2411626127174 ∧ code e2411626127174 = 11207719149382 := by decide
theorem cert_e2411626127174 : check e2411626127174 [[],[]] .three = true := by decide
end Blc.Floor43
