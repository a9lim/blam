import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2249287843130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2249287843130 : Closed e2249287843130 ∧ code e2249287843130 = 11045380865338 := by decide
theorem cert_e2249287843130 : check e2249287843130 [[],[.under,.left]] .smaller = true := by decide
def e2249287843226 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2249287843226 : Closed e2249287843226 ∧ code e2249287843226 = 11045380865434 := by decide
theorem cert_e2249287843226 : check e2249287843226 [[],[.under,.left]] .smaller = true := by decide
def e2249287846766 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2249287846766 : Closed e2249287846766 ∧ code e2249287846766 = 11045380868974 := by decide
theorem cert_e2249287846766 : check e2249287846766 [[],[.under,.left]] .smaller = true := by decide
def e2249287846774 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2249287846774 : Closed e2249287846774 ∧ code e2249287846774 = 11045380868982 := by decide
theorem cert_e2249287846774 : check e2249287846774 [[],[.under,.left]] .smaller = true := by decide
def e2249287846830 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2249287846830 : Closed e2249287846830 ∧ code e2249287846830 = 11045380869038 := by decide
theorem cert_e2249287846830 : check e2249287846830 [[],[.under,.left]] .smaller = true := by decide
def e2249287846842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2249287846842 : Closed e2249287846842 ∧ code e2249287846842 = 11045380869050 := by decide
theorem cert_e2249287846842 : check e2249287846842 [[],[.under,.left]] .smaller = true := by decide
def e2249287846870 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2249287846870 : Closed e2249287846870 ∧ code e2249287846870 = 11045380869078 := by decide
theorem cert_e2249287846870 : check e2249287846870 [[],[.under,.left]] .smaller = true := by decide
def e2249287846874 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2249287846874 : Closed e2249287846874 ∧ code e2249287846874 = 11045380869082 := by decide
theorem cert_e2249287846874 : check e2249287846874 [[],[.under,.left]] .smaller = true := by decide
def e2249287847150 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2249287847150 : Closed e2249287847150 ∧ code e2249287847150 = 11045380869358 := by decide
theorem cert_e2249287847150 : check e2249287847150 [[],[.under,.left]] .smaller = true := by decide
def e2249287847158 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2249287847158 : Closed e2249287847158 ∧ code e2249287847158 = 11045380869366 := by decide
theorem cert_e2249287847158 : check e2249287847158 [[],[.under,.left]] .smaller = true := by decide
def e2249287847534 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2249287847534 : Closed e2249287847534 ∧ code e2249287847534 = 11045380869742 := by decide
theorem cert_e2249287847534 : check e2249287847534 [[],[.under,.left]] .smaller = true := by decide
def e2249287847546 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2249287847546 : Closed e2249287847546 ∧ code e2249287847546 = 11045380869754 := by decide
theorem cert_e2249287847546 : check e2249287847546 [[],[.under,.left]] .smaller = true := by decide
def e2249287847734 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2249287847734 : Closed e2249287847734 ∧ code e2249287847734 = 11045380869942 := by decide
theorem cert_e2249287847734 : check e2249287847734 [[],[.under,.left]] .smaller = true := by decide
def e2249287847738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2249287847738 : Closed e2249287847738 ∧ code e2249287847738 = 11045380869946 := by decide
theorem cert_e2249287847738 : check e2249287847738 [[],[.under,.left]] .smaller = true := by decide
def e2249287853486 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2249287853486 : Closed e2249287853486 ∧ code e2249287853486 = 11045380875694 := by decide
theorem cert_e2249287853486 : check e2249287853486 [[],[.under,.left]] .smaller = true := by decide
def e2249287853498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2249287853498 : Closed e2249287853498 ∧ code e2249287853498 = 11045380875706 := by decide
theorem cert_e2249287853498 : check e2249287853498 [[],[.under,.left]] .smaller = true := by decide
def e2249287853546 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2249287853546 : Closed e2249287853546 ∧ code e2249287853546 = 11045380875754 := by decide
theorem cert_e2249287853546 : check e2249287853546 [[],[.under,.left]] .smaller = true := by decide
def e2249287853678 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2249287853678 : Closed e2249287853678 ∧ code e2249287853678 = 11045380875886 := by decide
theorem cert_e2249287853678 : check e2249287853678 [[],[.under,.left]] .smaller = true := by decide
def e2249287853690 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2249287853690 : Closed e2249287853690 ∧ code e2249287853690 = 11045380875898 := by decide
theorem cert_e2249287853690 : check e2249287853690 [[],[.under,.left]] .smaller = true := by decide
def e2249287853978 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2249287853978 : Closed e2249287853978 ∧ code e2249287853978 = 11045380876186 := by decide
theorem cert_e2249287853978 : check e2249287853978 [[],[.under,.left]] .smaller = true := by decide
def e2249287856854 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2249287856854 : Closed e2249287856854 ∧ code e2249287856854 = 11045380879062 := by decide
theorem cert_e2249287856854 : check e2249287856854 [[],[.under,.left]] .smaller = true := by decide
def e2249287856858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2249287856858 : Closed e2249287856858 ∧ code e2249287856858 = 11045380879066 := by decide
theorem cert_e2249287856858 : check e2249287856858 [[],[.under,.left]] .smaller = true := by decide
def e2249287856874 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2249287856874 : Closed e2249287856874 ∧ code e2249287856874 = 11045380879082 := by decide
theorem cert_e2249287856874 : check e2249287856874 [[],[.under,.left]] .smaller = true := by decide
def e2249287856950 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2249287856950 : Closed e2249287856950 ∧ code e2249287856950 = 11045380879158 := by decide
theorem cert_e2249287856950 : check e2249287856950 [[],[.under,.left]] .smaller = true := by decide
def e2249287856954 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2249287856954 : Closed e2249287856954 ∧ code e2249287856954 = 11045380879162 := by decide
theorem cert_e2249287856954 : check e2249287856954 [[],[.under,.left]] .smaller = true := by decide
def e2249287857050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2249287857050 : Closed e2249287857050 ∧ code e2249287857050 = 11045380879258 := by decide
theorem cert_e2249287857050 : check e2249287857050 [[],[.under,.left]] .smaller = true := by decide
def e2249287972590 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2249287972590 : Closed e2249287972590 ∧ code e2249287972590 = 11045380994798 := by decide
theorem cert_e2249287972590 : check e2249287972590 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2249287972718 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2249287972718 : Closed e2249287972718 ∧ code e2249287972718 = 11045380994926 := by decide
theorem cert_e2249287972718 : check e2249287972718 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2249287972726 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2249287972726 : Closed e2249287972726 ∧ code e2249287972726 = 11045380994934 := by decide
theorem cert_e2249287972726 : check e2249287972726 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249287973614 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2249287973614 : Closed e2249287973614 ∧ code e2249287973614 = 11045380995822 := by decide
theorem cert_e2249287973614 : check e2249287973614 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2249287973806 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2249287973806 : Closed e2249287973806 ∧ code e2249287973806 = 11045380996014 := by decide
theorem cert_e2249287973806 : check e2249287973806 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2249287973818 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2249287973818 : Closed e2249287973818 ∧ code e2249287973818 = 11045380996026 := by decide
theorem cert_e2249287973818 : check e2249287973818 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2249287974254 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2249287974254 : Closed e2249287974254 ∧ code e2249287974254 = 11045380996462 := by decide
theorem cert_e2249287974254 : check e2249287974254 [[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2249287974262 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2249287974262 : Closed e2249287974262 ∧ code e2249287974262 = 11045380996470 := by decide
theorem cert_e2249287974262 : check e2249287974262 [[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2249287974318 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2249287974318 : Closed e2249287974318 ∧ code e2249287974318 = 11045380996526 := by decide
theorem cert_e2249287974318 : check e2249287974318 [[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2249287974330 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2249287974330 : Closed e2249287974330 ∧ code e2249287974330 = 11045380996538 := by decide
theorem cert_e2249287974330 : check e2249287974330 [[],[.under,.left],[.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2249287974358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2249287974358 : Closed e2249287974358 ∧ code e2249287974358 = 11045380996566 := by decide
private def t_e2249287974358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e2249287974358 : ¬ IsSelfInterpreter e2249287974358 :=
  wSource (t := t_e2249287974358) (replay_sound (ps := []) (t := e2249287974358) (by decide)) (by decide)
def e2249287974362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2249287974362 : Closed e2249287974362 ∧ code e2249287974362 = 11045380996570 := by decide
private def t_e2249287974362 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e2249287974362 : ¬ IsSelfInterpreter e2249287974362 :=
  wSource (t := t_e2249287974362) (replay_sound (ps := []) (t := e2249287974362) (by decide)) (by decide)
def e2249287978734 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2249287978734 : Closed e2249287978734 ∧ code e2249287978734 = 11045381000942 := by decide
theorem cert_e2249287978734 : check e2249287978734 [[.left,.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2249287978862 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2249287978862 : Closed e2249287978862 ∧ code e2249287978862 = 11045381001070 := by decide
theorem cert_e2249287978862 : check e2249287978862 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2249287978870 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2249287978870 : Closed e2249287978870 ∧ code e2249287978870 = 11045381001078 := by decide
theorem cert_e2249287978870 : check e2249287978870 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2249287981550 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2249287981550 : Closed e2249287981550 ∧ code e2249287981550 = 11045381003758 := by decide
theorem cert_e2249287981550 : check e2249287981550 [[.left,.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2249287982318 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2249287982318 : Closed e2249287982318 ∧ code e2249287982318 = 11045381004526 := by decide
theorem cert_e2249287982318 : check e2249287982318 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249287982326 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2249287982326 : Closed e2249287982326 ∧ code e2249287982326 = 11045381004534 := by decide
theorem cert_e2249287982326 : check e2249287982326 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249287984878 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2249287984878 : Closed e2249287984878 ∧ code e2249287984878 = 11045381007086 := by decide
theorem cert_e2249287984878 : checkPay e2249287984878 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.left]] = true := by decide
def e2249287985070 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2249287985070 : Closed e2249287985070 ∧ code e2249287985070 = 11045381007278 := by decide
theorem cert_e2249287985070 : checkPay e2249287985070 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e2249287985082 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2249287985082 : Closed e2249287985082 ∧ code e2249287985082 = 11045381007290 := by decide
theorem cert_e2249287985082 : checkPay e2249287985082 [[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2249287985646 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2249287985646 : Closed e2249287985646 ∧ code e2249287985646 = 11045381007854 := by decide
theorem cert_e2249287985646 : checkPay e2249287985646 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2249287986798 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2249287986798 : Closed e2249287986798 ∧ code e2249287986798 = 11045381009006 := by decide
theorem cert_e2249287986798 : checkPay e2249287986798 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2249287986810 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2249287986810 : Closed e2249287986810 ∧ code e2249287986810 = 11045381009018 := by decide
theorem cert_e2249287986810 : checkPay e2249287986810 [[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2249287988078 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2249287988078 : Closed e2249287988078 ∧ code e2249287988078 = 11045381010286 := by decide
theorem cert_e2249287988078 : check e2249287988078 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e2249287988086 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2249287988086 : Closed e2249287988086 ∧ code e2249287988086 = 11045381010294 := by decide
theorem cert_e2249287988086 : check e2249287988086 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249287988142 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2249287988142 : Closed e2249287988142 ∧ code e2249287988142 = 11045381010350 := by decide
theorem cert_e2249287988142 : check e2249287988142 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e2249287988154 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2249287988154 : Closed e2249287988154 ∧ code e2249287988154 = 11045381010362 := by decide
theorem cert_e2249287988154 : check e2249287988154 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249287988182 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2249287988182 : Closed e2249287988182 ∧ code e2249287988182 = 11045381010390 := by decide
theorem cert_e2249287988182 : check e2249287988182 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249287988186 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2249287988186 : Closed e2249287988186 ∧ code e2249287988186 = 11045381010394 := by decide
theorem cert_e2249287988186 : check e2249287988186 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249287988462 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2249287988462 : Closed e2249287988462 ∧ code e2249287988462 = 11045381010670 := by decide
theorem cert_e2249287988462 : check e2249287988462 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e2249287988470 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2249287988470 : Closed e2249287988470 ∧ code e2249287988470 = 11045381010678 := by decide
theorem cert_e2249287988470 : check e2249287988470 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e2249287988846 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2249287988846 : Closed e2249287988846 ∧ code e2249287988846 = 11045381011054 := by decide
theorem cert_e2249287988846 : check e2249287988846 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e2249287988858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2249287988858 : Closed e2249287988858 ∧ code e2249287988858 = 11045381011066 := by decide
theorem cert_e2249287988858 : check e2249287988858 [[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e2249287989046 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2249287989046 : Closed e2249287989046 ∧ code e2249287989046 = 11045381011254 := by decide
private def t_e2249287989046 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e2249287989046 : ¬ IsSelfInterpreter e2249287989046 :=
  wSource (t := t_e2249287989046) (replay_sound (ps := []) (t := e2249287989046) (by decide)) (by decide)
def e2249287989050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2249287989050 : Closed e2249287989050 ∧ code e2249287989050 = 11045381011258 := by decide
private def t_e2249287989050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e2249287989050 : ¬ IsSelfInterpreter e2249287989050 :=
  wSource (t := t_e2249287989050) (replay_sound (ps := []) (t := e2249287989050) (by decide)) (by decide)
def e2249287994222 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2249287994222 : Closed e2249287994222 ∧ code e2249287994222 = 11045381016430 := by decide
theorem cert_e2249287994222 : check e2249287994222 [[],[.under,.left]] .smaller = true := by decide
def e2249287994230 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2249287994230 : Closed e2249287994230 ∧ code e2249287994230 = 11045381016438 := by decide
theorem cert_e2249287994230 : check e2249287994230 [[],[.under,.left]] .smaller = true := by decide
def e2249287994286 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2249287994286 : Closed e2249287994286 ∧ code e2249287994286 = 11045381016494 := by decide
theorem cert_e2249287994286 : check e2249287994286 [[],[.under,.left]] .smaller = true := by decide
def e2249287994298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2249287994298 : Closed e2249287994298 ∧ code e2249287994298 = 11045381016506 := by decide
theorem cert_e2249287994298 : check e2249287994298 [[],[.under,.left]] .smaller = true := by decide
def e2249287994326 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2249287994326 : Closed e2249287994326 ∧ code e2249287994326 = 11045381016534 := by decide
theorem cert_e2249287994326 : check e2249287994326 [[],[.under,.left]] .smaller = true := by decide
def e2249287994330 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2249287994330 : Closed e2249287994330 ∧ code e2249287994330 = 11045381016538 := by decide
theorem cert_e2249287994330 : check e2249287994330 [[],[.under,.left]] .smaller = true := by decide
def e2249287994606 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2249287994606 : Closed e2249287994606 ∧ code e2249287994606 = 11045381016814 := by decide
theorem cert_e2249287994606 : check e2249287994606 [[],[.under,.left]] .smaller = true := by decide
def e2249287994614 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2249287994614 : Closed e2249287994614 ∧ code e2249287994614 = 11045381016822 := by decide
theorem cert_e2249287994614 : check e2249287994614 [[],[.under,.left]] .smaller = true := by decide
def e2249287994990 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2249287994990 : Closed e2249287994990 ∧ code e2249287994990 = 11045381017198 := by decide
theorem cert_e2249287994990 : check e2249287994990 [[],[.under,.left]] .smaller = true := by decide
def e2249287995002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2249287995002 : Closed e2249287995002 ∧ code e2249287995002 = 11045381017210 := by decide
theorem cert_e2249287995002 : check e2249287995002 [[],[.under,.left]] .smaller = true := by decide
def e2249287995190 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2249287995190 : Closed e2249287995190 ∧ code e2249287995190 = 11045381017398 := by decide
theorem cert_e2249287995190 : check e2249287995190 [[],[.under,.left]] .smaller = true := by decide
def e2249287995194 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2249287995194 : Closed e2249287995194 ∧ code e2249287995194 = 11045381017402 := by decide
theorem cert_e2249287995194 : check e2249287995194 [[],[.under,.left]] .smaller = true := by decide
def e2249288003310 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2249288003310 : Closed e2249288003310 ∧ code e2249288003310 = 11045381025518 := by decide
theorem cert_e2249288003310 : check e2249288003310 [[.left,.left],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2249288003438 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2249288003438 : Closed e2249288003438 ∧ code e2249288003438 = 11045381025646 := by decide
theorem cert_e2249288003438 : checkPay e2249288003438 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e2249288003446 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2249288003446 : Closed e2249288003446 ∧ code e2249288003446 = 11045381025654 := by decide
theorem cert_e2249288003446 : check e2249288003446 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2249288006126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2249288006126 : Closed e2249288006126 ∧ code e2249288006126 = 11045381028334 := by decide
theorem cert_e2249288006126 : check e2249288006126 [[.left,.left],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2249288006894 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2249288006894 : Closed e2249288006894 ∧ code e2249288006894 = 11045381029102 := by decide
theorem cert_e2249288006894 : check e2249288006894 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2249288006902 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2249288006902 : Closed e2249288006902 ∧ code e2249288006902 = 11045381029110 := by decide
theorem cert_e2249288006902 : check e2249288006902 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2249288029934 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2249288029934 : Closed e2249288029934 ∧ code e2249288029934 = 11045381052142 := by decide
theorem cert_e2249288029934 : check e2249288029934 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2249288030126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2249288030126 : Closed e2249288030126 ∧ code e2249288030126 = 11045381052334 := by decide
theorem cert_e2249288030126 : check e2249288030126 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2249288030138 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2249288030138 : Closed e2249288030138 ∧ code e2249288030138 = 11045381052346 := by decide
theorem cert_e2249288030138 : check e2249288030138 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2249288030702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2249288030702 : Closed e2249288030702 ∧ code e2249288030702 = 11045381052910 := by decide
theorem cert_e2249288030702 : check e2249288030702 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2249288031854 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2249288031854 : Closed e2249288031854 ∧ code e2249288031854 = 11045381054062 := by decide
theorem cert_e2249288031854 : check e2249288031854 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2249288031866 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2249288031866 : Closed e2249288031866 ∧ code e2249288031866 = 11045381054074 := by decide
theorem cert_e2249288031866 : check e2249288031866 [[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2249288043374 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2249288043374 : Closed e2249288043374 ∧ code e2249288043374 = 11045381065582 := by decide
theorem cert_e2249288043374 : check e2249288043374 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288043382 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2249288043382 : Closed e2249288043382 ∧ code e2249288043382 = 11045381065590 := by decide
theorem cert_e2249288043382 : check e2249288043382 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288043438 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2249288043438 : Closed e2249288043438 ∧ code e2249288043438 = 11045381065646 := by decide
theorem cert_e2249288043438 : check e2249288043438 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288043450 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2249288043450 : Closed e2249288043450 ∧ code e2249288043450 = 11045381065658 := by decide
theorem cert_e2249288043450 : check e2249288043450 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288043478 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2249288043478 : Closed e2249288043478 ∧ code e2249288043478 = 11045381065686 := by decide
theorem cert_e2249288043478 : check e2249288043478 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288043482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2249288043482 : Closed e2249288043482 ∧ code e2249288043482 = 11045381065690 := by decide
theorem cert_e2249288043482 : check e2249288043482 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288043758 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2249288043758 : Closed e2249288043758 ∧ code e2249288043758 = 11045381065966 := by decide
theorem cert_e2249288043758 : check e2249288043758 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288043766 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2249288043766 : Closed e2249288043766 ∧ code e2249288043766 = 11045381065974 := by decide
theorem cert_e2249288043766 : check e2249288043766 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288044142 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2249288044142 : Closed e2249288044142 ∧ code e2249288044142 = 11045381066350 := by decide
theorem cert_e2249288044142 : check e2249288044142 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288044154 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2249288044154 : Closed e2249288044154 ∧ code e2249288044154 = 11045381066362 := by decide
theorem cert_e2249288044154 : check e2249288044154 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288044342 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2249288044342 : Closed e2249288044342 ∧ code e2249288044342 = 11045381066550 := by decide
theorem cert_e2249288044342 : check e2249288044342 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288044346 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2249288044346 : Closed e2249288044346 ∧ code e2249288044346 = 11045381066554 := by decide
theorem cert_e2249288044346 : check e2249288044346 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249288584046 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2249288584046 : Closed e2249288584046 ∧ code e2249288584046 = 11045381606254 := by decide
theorem cert_e2249288584046 : check e2249288584046 [[],[.under,.left]] .smaller = true := by decide
def e2249288584054 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2249288584054 : Closed e2249288584054 ∧ code e2249288584054 = 11045381606262 := by decide
theorem cert_e2249288584054 : check e2249288584054 [[],[.under,.left]] .smaller = true := by decide
def e2249288584110 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2249288584110 : Closed e2249288584110 ∧ code e2249288584110 = 11045381606318 := by decide
theorem cert_e2249288584110 : check e2249288584110 [[],[.under,.left]] .smaller = true := by decide
def e2249288584122 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2249288584122 : Closed e2249288584122 ∧ code e2249288584122 = 11045381606330 := by decide
theorem cert_e2249288584122 : check e2249288584122 [[],[.under,.left]] .smaller = true := by decide
def e2249288584150 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2249288584150 : Closed e2249288584150 ∧ code e2249288584150 = 11045381606358 := by decide
theorem cert_e2249288584150 : check e2249288584150 [[],[.under,.left]] .smaller = true := by decide
def e2249288584154 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2249288584154 : Closed e2249288584154 ∧ code e2249288584154 = 11045381606362 := by decide
theorem cert_e2249288584154 : check e2249288584154 [[],[.under,.left]] .smaller = true := by decide
def e2249288584430 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2249288584430 : Closed e2249288584430 ∧ code e2249288584430 = 11045381606638 := by decide
theorem cert_e2249288584430 : check e2249288584430 [[],[.under,.left]] .smaller = true := by decide
def e2249288584438 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2249288584438 : Closed e2249288584438 ∧ code e2249288584438 = 11045381606646 := by decide
theorem cert_e2249288584438 : check e2249288584438 [[],[.under,.left]] .smaller = true := by decide
def e2249288584814 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2249288584814 : Closed e2249288584814 ∧ code e2249288584814 = 11045381607022 := by decide
theorem cert_e2249288584814 : check e2249288584814 [[],[.under,.left]] .smaller = true := by decide
def e2249288584826 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2249288584826 : Closed e2249288584826 ∧ code e2249288584826 = 11045381607034 := by decide
theorem cert_e2249288584826 : check e2249288584826 [[],[.under,.left]] .smaller = true := by decide
def e2249288585014 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2249288585014 : Closed e2249288585014 ∧ code e2249288585014 = 11045381607222 := by decide
theorem cert_e2249288585014 : check e2249288585014 [[],[.under,.left]] .smaller = true := by decide
def e2249288585018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2249288585018 : Closed e2249288585018 ∧ code e2249288585018 = 11045381607226 := by decide
theorem cert_e2249288585018 : check e2249288585018 [[],[.under,.left]] .smaller = true := by decide
def e2249321438062 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2249321438062 : Closed e2249321438062 ∧ code e2249321438062 = 11045414460270 := by decide
theorem cert_e2249321438062 : check e2249321438062 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249321438070 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2249321438070 : Closed e2249321438070 ∧ code e2249321438070 = 11045414460278 := by decide
theorem cert_e2249321438070 : check e2249321438070 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2249321438134 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2249321438134 : Closed e2249321438134 ∧ code e2249321438134 = 11045414460342 := by decide
theorem cert_e2249321438134 : check e2249321438134 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2249321438574 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2249321438574 : Closed e2249321438574 ∧ code e2249321438574 = 11045414460782 := by decide
def e2249321438582 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2249321438582 : Closed e2249321438582 ∧ code e2249321438582 = 11045414460790 := by decide
theorem cert_e2249321438582 : check e2249321438582 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2249321438638 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2249321438638 : Closed e2249321438638 ∧ code e2249321438638 = 11045414460846 := by decide
theorem cert_e2249321438638 : check e2249321438638 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .identityHead = true := by decide
def e2249321438650 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2249321438650 : Closed e2249321438650 ∧ code e2249321438650 = 11045414460858 := by decide
def e2249321438678 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2249321438678 : Closed e2249321438678 ∧ code e2249321438678 = 11045414460886 := by decide
theorem cert_e2249321438678 : check e2249321438678 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249321438682 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2249321438682 : Closed e2249321438682 ∧ code e2249321438682 = 11045414460890 := by decide
def e2249321438902 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2249321438902 : Closed e2249321438902 ∧ code e2249321438902 = 11045414461110 := by decide
theorem cert_e2249321438902 : check e2249321438902 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left]] .identityHead = true := by decide
def e2249321438934 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2249321438934 : Closed e2249321438934 ∧ code e2249321438934 = 11045414461142 := by decide
theorem cert_e2249321438934 : check e2249321438934 [[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249321438938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2249321438938 : Closed e2249321438938 ∧ code e2249321438938 = 11045414461146 := by decide
def e2249321441134 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2249321441134 : Closed e2249321441134 ∧ code e2249321441134 = 11045414463342 := by decide
theorem cert_e2249321441134 : check e2249321441134 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2249321441142 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2249321441142 : Closed e2249321441142 ∧ code e2249321441142 = 11045414463350 := by decide
theorem cert_e2249321441142 : check e2249321441142 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2249321441206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2249321441206 : Closed e2249321441206 ∧ code e2249321441206 = 11045414463414 := by decide
theorem cert_e2249321441206 : check e2249321441206 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249321442542 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2249321442542 : Closed e2249321442542 ∧ code e2249321442542 = 11045414464750 := by decide
theorem cert_e2249321442542 : check e2249321442542 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249321442550 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2249321442550 : Closed e2249321442550 ∧ code e2249321442550 = 11045414464758 := by decide
theorem cert_e2249321442550 : check e2249321442550 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249321442934 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2249321442934 : Closed e2249321442934 ∧ code e2249321442934 = 11045414465142 := by decide
theorem cert_e2249321442934 : check e2249321442934 [[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2249321444206 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2249321444206 : Closed e2249321444206 ∧ code e2249321444206 = 11045414466414 := by decide
theorem cert_e2249321444206 : check e2249321444206 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321444214 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2249321444214 : Closed e2249321444214 ∧ code e2249321444214 = 11045414466422 := by decide
theorem cert_e2249321444214 : check e2249321444214 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321444270 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2249321444270 : Closed e2249321444270 ∧ code e2249321444270 = 11045414466478 := by decide
theorem cert_e2249321444270 : check e2249321444270 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321444282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2249321444282 : Closed e2249321444282 ∧ code e2249321444282 = 11045414466490 := by decide
theorem cert_e2249321444282 : check e2249321444282 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321444310 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2249321444310 : Closed e2249321444310 ∧ code e2249321444310 = 11045414466518 := by decide
theorem cert_e2249321444310 : check e2249321444310 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321444314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2249321444314 : Closed e2249321444314 ∧ code e2249321444314 = 11045414466522 := by decide
theorem cert_e2249321444314 : check e2249321444314 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321444590 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2249321444590 : Closed e2249321444590 ∧ code e2249321444590 = 11045414466798 := by decide
theorem cert_e2249321444590 : check e2249321444590 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321444598 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2249321444598 : Closed e2249321444598 ∧ code e2249321444598 = 11045414466806 := by decide
theorem cert_e2249321444598 : check e2249321444598 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321444974 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2249321444974 : Closed e2249321444974 ∧ code e2249321444974 = 11045414467182 := by decide
theorem cert_e2249321444974 : check e2249321444974 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321444986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2249321444986 : Closed e2249321444986 ∧ code e2249321444986 = 11045414467194 := by decide
theorem cert_e2249321444986 : check e2249321444986 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321445174 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2249321445174 : Closed e2249321445174 ∧ code e2249321445174 = 11045414467382 := by decide
theorem cert_e2249321445174 : check e2249321445174 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321445178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2249321445178 : Closed e2249321445178 ∧ code e2249321445178 = 11045414467386 := by decide
theorem cert_e2249321445178 : check e2249321445178 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321445814 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2249321445814 : Closed e2249321445814 ∧ code e2249321445814 = 11045414468022 := by decide
theorem cert_e2249321445814 : check e2249321445814 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321445846 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2249321445846 : Closed e2249321445846 ∧ code e2249321445846 = 11045414468054 := by decide
theorem cert_e2249321445846 : check e2249321445846 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321445850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2249321445850 : Closed e2249321445850 ∧ code e2249321445850 = 11045414468058 := by decide
theorem cert_e2249321445850 : check e2249321445850 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321446006 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2249321446006 : Closed e2249321446006 ∧ code e2249321446006 = 11045414468214 := by decide
theorem cert_e2249321446006 : check e2249321446006 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321446198 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2249321446198 : Closed e2249321446198 ∧ code e2249321446198 = 11045414468406 := by decide
theorem cert_e2249321446198 : check e2249321446198 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321446202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2249321446202 : Closed e2249321446202 ∧ code e2249321446202 = 11045414468410 := by decide
theorem cert_e2249321446202 : check e2249321446202 [[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2249321453422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2249321453422 : Closed e2249321453422 ∧ code e2249321453422 = 11045414475630 := by decide
theorem cert_e2249321453422 : check e2249321453422 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2249321453430 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2249321453430 : Closed e2249321453430 ∧ code e2249321453430 = 11045414475638 := by decide
theorem cert_e2249321453430 : check e2249321453430 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2249321453494 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2249321453494 : Closed e2249321453494 ∧ code e2249321453494 = 11045414475702 := by decide
theorem cert_e2249321453494 : check e2249321453494 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2249321454830 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2249321454830 : Closed e2249321454830 ∧ code e2249321454830 = 11045414477038 := by decide
theorem cert_e2249321454830 : check e2249321454830 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2249321454838 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2249321454838 : Closed e2249321454838 ∧ code e2249321454838 = 11045414477046 := by decide
theorem cert_e2249321454838 : check e2249321454838 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2249321455222 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2249321455222 : Closed e2249321455222 ∧ code e2249321455222 = 11045414477430 := by decide
theorem cert_e2249321455222 : check e2249321455222 [[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2249321466734 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2249321466734 : Closed e2249321466734 ∧ code e2249321466734 = 11045414488942 := by decide
theorem cert_e2249321466734 : check e2249321466734 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321466742 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2249321466742 : Closed e2249321466742 ∧ code e2249321466742 = 11045414488950 := by decide
theorem cert_e2249321466742 : check e2249321466742 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321466798 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2249321466798 : Closed e2249321466798 ∧ code e2249321466798 = 11045414489006 := by decide
theorem cert_e2249321466798 : check e2249321466798 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321466810 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2249321466810 : Closed e2249321466810 ∧ code e2249321466810 = 11045414489018 := by decide
theorem cert_e2249321466810 : check e2249321466810 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321466838 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2249321466838 : Closed e2249321466838 ∧ code e2249321466838 = 11045414489046 := by decide
theorem cert_e2249321466838 : check e2249321466838 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321466842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2249321466842 : Closed e2249321466842 ∧ code e2249321466842 = 11045414489050 := by decide
theorem cert_e2249321466842 : check e2249321466842 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321467118 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2249321467118 : Closed e2249321467118 ∧ code e2249321467118 = 11045414489326 := by decide
theorem cert_e2249321467118 : check e2249321467118 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2249321467126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2249321467126 : Closed e2249321467126 ∧ code e2249321467126 = 11045414489334 := by decide
theorem cert_e2249321467126 : check e2249321467126 [[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2249287974358
#print axioms Blc.Floor43.cert_e2249287974362
#print axioms Blc.Floor43.cert_e2249287989046
#print axioms Blc.Floor43.cert_e2249287989050
