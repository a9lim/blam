import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373024986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422373024986 : Closed e2422373024986 ∧ code e2422373024986 = 11218466047194 := by decide
theorem cert_e2422373024986 : check e2422373024986 [[],[]] .smaller = true := by decide
def e2422373025002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422373025002 : Closed e2422373025002 ∧ code e2422373025002 = 11218466047210 := by decide
theorem cert_e2422373025002 : check e2422373025002 [[],[]] .smaller = true := by decide
def e2422373025078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373025078 : Closed e2422373025078 ∧ code e2422373025078 = 11218466047286 := by decide
theorem cert_e2422373025078 : check e2422373025078 [[],[]] .smaller = true := by decide
def e2422373025082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373025082 : Closed e2422373025082 ∧ code e2422373025082 = 11218466047290 := by decide
theorem cert_e2422373025082 : check e2422373025082 [[],[]] .smaller = true := by decide
def e2422373025178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373025178 : Closed e2422373025178 ∧ code e2422373025178 = 11218466047386 := by decide
theorem cert_e2422373025178 : check e2422373025178 [[],[]] .smaller = true := by decide
def e2422373025630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.var 3)))))))
theorem wire_e2422373025630 : Closed e2422373025630 ∧ code e2422373025630 = 11218466047838 := by decide
theorem cert_e2422373025630 : check e2422373025630 [[],[]] .three = true := by decide
def e2422373025646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 2)))))))
theorem wire_e2422373025646 : Closed e2422373025646 ∧ code e2422373025646 = 11218466047854 := by decide
theorem cert_e2422373025646 : check e2422373025646 [[],[]] .smaller = true := by decide
def e2422373025654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 2)) (.var 1)))))))
theorem wire_e2422373025654 : Closed e2422373025654 ∧ code e2422373025654 = 11218466047862 := by decide
theorem cert_e2422373025654 : check e2422373025654 [[],[]] .smaller = true := by decide
def e2422373025658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 3)) (.var 0)))))))
theorem wire_e2422373025658 : Closed e2422373025658 ∧ code e2422373025658 = 11218466047866 := by decide
theorem cert_e2422373025658 : check e2422373025658 [[],[]] .three = true := by decide
def e2422373025710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 2)))))))
theorem wire_e2422373025710 : Closed e2422373025710 ∧ code e2422373025710 = 11218466047918 := by decide
theorem cert_e2422373025710 : check e2422373025710 [[],[]] .smaller = true := by decide
def e2422373025722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 2)) (.var 0)))))))
theorem wire_e2422373025722 : Closed e2422373025722 ∧ code e2422373025722 = 11218466047930 := by decide
theorem cert_e2422373025722 : check e2422373025722 [[],[]] .smaller = true := by decide
def e2422373025750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373025750 : Closed e2422373025750 ∧ code e2422373025750 = 11218466047958 := by decide
theorem cert_e2422373025750 : check e2422373025750 [[],[]] .smaller = true := by decide
def e2422373025754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373025754 : Closed e2422373025754 ∧ code e2422373025754 = 11218466047962 := by decide
theorem cert_e2422373025754 : check e2422373025754 [[],[]] .smaller = true := by decide
def e2422373025770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 5)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373025770 : Closed e2422373025770 ∧ code e2422373025770 = 11218466047978 := by decide
theorem cert_e2422373025770 : check e2422373025770 [[],[]] .three = true := by decide
def e2422373027166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 3)))))))
theorem wire_e2422373027166 : Closed e2422373027166 ∧ code e2422373027166 = 11218466049374 := by decide
theorem cert_e2422373027166 : check e2422373027166 [[],[]] .three = true := by decide
def e2422373027194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 3)) (.var 0)))))))
theorem wire_e2422373027194 : Closed e2422373027194 ∧ code e2422373027194 = 11218466049402 := by decide
theorem cert_e2422373027194 : check e2422373027194 [[],[]] .three = true := by decide
def e2422373027254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 1)))))))
theorem wire_e2422373027254 : Closed e2422373027254 ∧ code e2422373027254 = 11218466049462 := by decide
theorem cert_e2422373027254 : check e2422373027254 [[],[]] .smaller = true := by decide
def e2422373027286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373027286 : Closed e2422373027286 ∧ code e2422373027286 = 11218466049494 := by decide
theorem cert_e2422373027286 : check e2422373027286 [[],[]] .smaller = true := by decide
def e2422373027290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373027290 : Closed e2422373027290 ∧ code e2422373027290 = 11218466049498 := by decide
theorem cert_e2422373027290 : check e2422373027290 [[],[]] .smaller = true := by decide
def e2422373027510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 1)))))))
theorem wire_e2422373027510 : Closed e2422373027510 ∧ code e2422373027510 = 11218466049718 := by decide
theorem cert_e2422373027510 : check e2422373027510 [[],[]] .smaller = true := by decide
def e2422373027542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373027542 : Closed e2422373027542 ∧ code e2422373027542 = 11218466049750 := by decide
theorem cert_e2422373027542 : check e2422373027542 [[],[]] .smaller = true := by decide
def e2422373027546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373027546 : Closed e2422373027546 ∧ code e2422373027546 = 11218466049754 := by decide
theorem cert_e2422373027546 : check e2422373027546 [[],[]] .smaller = true := by decide
def e2422373027562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373027562 : Closed e2422373027562 ∧ code e2422373027562 = 11218466049770 := by decide
theorem cert_e2422373027562 : check e2422373027562 [[],[]] .smaller = true := by decide
def e2422373027670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373027670 : Closed e2422373027670 ∧ code e2422373027670 = 11218466049878 := by decide
theorem cert_e2422373027670 : check e2422373027670 [[],[]] .smaller = true := by decide
def e2422373027674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373027674 : Closed e2422373027674 ∧ code e2422373027674 = 11218466049882 := by decide
theorem cert_e2422373027674 : check e2422373027674 [[],[]] .smaller = true := by decide
def e2422373027690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373027690 : Closed e2422373027690 ∧ code e2422373027690 = 11218466049898 := by decide
theorem cert_e2422373027690 : check e2422373027690 [[],[]] .smaller = true := by decide
def e2422373028702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2422373028702 : Closed e2422373028702 ∧ code e2422373028702 = 11218466050910 := by decide
theorem cert_e2422373028702 : check e2422373028702 [[],[]] .three = true := by decide
def e2422373028718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422373028718 : Closed e2422373028718 ∧ code e2422373028718 = 11218466050926 := by decide
theorem cert_e2422373028718 : check e2422373028718 [[],[]] .smaller = true := by decide
def e2422373028726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422373028726 : Closed e2422373028726 ∧ code e2422373028726 = 11218466050934 := by decide
theorem cert_e2422373028726 : check e2422373028726 [[],[]] .smaller = true := by decide
def e2422373028730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2422373028730 : Closed e2422373028730 ∧ code e2422373028730 = 11218466050938 := by decide
theorem cert_e2422373028730 : check e2422373028730 [[],[]] .three = true := by decide
def e2422373028782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422373028782 : Closed e2422373028782 ∧ code e2422373028782 = 11218466050990 := by decide
theorem cert_e2422373028782 : check e2422373028782 [[],[]] .smaller = true := by decide
def e2422373028794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422373028794 : Closed e2422373028794 ∧ code e2422373028794 = 11218466051002 := by decide
theorem cert_e2422373028794 : check e2422373028794 [[],[]] .smaller = true := by decide
def e2422373028822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422373028822 : Closed e2422373028822 ∧ code e2422373028822 = 11218466051030 := by decide
theorem cert_e2422373028822 : check e2422373028822 [[],[]] .smaller = true := by decide
def e2422373028826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422373028826 : Closed e2422373028826 ∧ code e2422373028826 = 11218466051034 := by decide
theorem cert_e2422373028826 : check e2422373028826 [[],[]] .smaller = true := by decide
def e2422373028842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2422373028842 : Closed e2422373028842 ∧ code e2422373028842 = 11218466051050 := by decide
theorem cert_e2422373028842 : check e2422373028842 [[],[]] .three = true := by decide
def e2422373029086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373029086 : Closed e2422373029086 ∧ code e2422373029086 = 11218466051294 := by decide
theorem cert_e2422373029086 : check e2422373029086 [[],[]] .three = true := by decide
def e2422373029102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373029102 : Closed e2422373029102 ∧ code e2422373029102 = 11218466051310 := by decide
theorem cert_e2422373029102 : check e2422373029102 [[],[]] .smaller = true := by decide
def e2422373029110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373029110 : Closed e2422373029110 ∧ code e2422373029110 = 11218466051318 := by decide
theorem cert_e2422373029110 : check e2422373029110 [[],[]] .smaller = true := by decide
def e2422373029114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373029114 : Closed e2422373029114 ∧ code e2422373029114 = 11218466051322 := by decide
theorem cert_e2422373029114 : check e2422373029114 [[],[]] .three = true := by decide
def e2422373029486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373029486 : Closed e2422373029486 ∧ code e2422373029486 = 11218466051694 := by decide
theorem cert_e2422373029486 : check e2422373029486 [[],[]] .smaller = true := by decide
def e2422373029498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373029498 : Closed e2422373029498 ∧ code e2422373029498 = 11218466051706 := by decide
theorem cert_e2422373029498 : check e2422373029498 [[],[]] .smaller = true := by decide
def e2422373029686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373029686 : Closed e2422373029686 ∧ code e2422373029686 = 11218466051894 := by decide
theorem cert_e2422373029686 : check e2422373029686 [[],[]] .smaller = true := by decide
def e2422373029690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373029690 : Closed e2422373029690 ∧ code e2422373029690 = 11218466051898 := by decide
theorem cert_e2422373029690 : check e2422373029690 [[],[]] .smaller = true := by decide
def e2422373029786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373029786 : Closed e2422373029786 ∧ code e2422373029786 = 11218466051994 := by decide
theorem cert_e2422373029786 : check e2422373029786 [[],[]] .three = true := by decide
def e2422373030110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422373030110 : Closed e2422373030110 ∧ code e2422373030110 = 11218466052318 := by decide
theorem cert_e2422373030110 : check e2422373030110 [[],[]] .three = true := by decide
def e2422373030126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422373030126 : Closed e2422373030126 ∧ code e2422373030126 = 11218466052334 := by decide
theorem cert_e2422373030126 : check e2422373030126 [[],[]] .smaller = true := by decide
def e2422373030134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422373030134 : Closed e2422373030134 ∧ code e2422373030134 = 11218466052342 := by decide
theorem cert_e2422373030134 : check e2422373030134 [[],[]] .smaller = true := by decide
def e2422373030138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422373030138 : Closed e2422373030138 ∧ code e2422373030138 = 11218466052346 := by decide
theorem cert_e2422373030138 : check e2422373030138 [[],[]] .three = true := by decide
def e2422373030326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2422373030326 : Closed e2422373030326 ∧ code e2422373030326 = 11218466052534 := by decide
theorem cert_e2422373030326 : check e2422373030326 [[],[]] .smaller = true := by decide
def e2422373030358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2422373030358 : Closed e2422373030358 ∧ code e2422373030358 = 11218466052566 := by decide
theorem cert_e2422373030358 : check e2422373030358 [[],[]] .smaller = true := by decide
def e2422373030362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2422373030362 : Closed e2422373030362 ∧ code e2422373030362 = 11218466052570 := by decide
theorem cert_e2422373030362 : check e2422373030362 [[],[]] .smaller = true := by decide
def e2422373030462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422373030462 : Closed e2422373030462 ∧ code e2422373030462 = 11218466052670 := by decide
theorem cert_e2422373030462 : check e2422373030462 [[],[]] .three = true := by decide
def e2422373030518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373030518 : Closed e2422373030518 ∧ code e2422373030518 = 11218466052726 := by decide
theorem cert_e2422373030518 : check e2422373030518 [[],[]] .smaller = true := by decide
def e2422373030686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422373030686 : Closed e2422373030686 ∧ code e2422373030686 = 11218466052894 := by decide
theorem cert_e2422373030686 : check e2422373030686 [[],[]] .smaller = true := by decide
def e2422373030710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373030710 : Closed e2422373030710 ∧ code e2422373030710 = 11218466052918 := by decide
theorem cert_e2422373030710 : check e2422373030710 [[],[]] .smaller = true := by decide
def e2422373030714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373030714 : Closed e2422373030714 ∧ code e2422373030714 = 11218466052922 := by decide
theorem cert_e2422373030714 : check e2422373030714 [[],[]] .smaller = true := by decide
def e2422373030798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422373030798 : Closed e2422373030798 ∧ code e2422373030798 = 11218466053006 := by decide
theorem cert_e2422373030798 : check e2422373030798 [[],[]] .smaller = true := by decide
def e2422373030854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422373030854 : Closed e2422373030854 ∧ code e2422373030854 = 11218466053062 := by decide
theorem cert_e2422373030854 : check e2422373030854 [[],[]] .three = true := by decide
def e2422373030878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 3)) (.var 3)))))))
theorem wire_e2422373030878 : Closed e2422373030878 ∧ code e2422373030878 = 11218466053086 := by decide
theorem cert_e2422373030878 : check e2422373030878 [[],[]] .three = true := by decide
def e2422373031022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422373031022 : Closed e2422373031022 ∧ code e2422373031022 = 11218466053230 := by decide
theorem cert_e2422373031022 : check e2422373031022 [[],[]] .smaller = true := by decide
def e2422373031034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422373031034 : Closed e2422373031034 ∧ code e2422373031034 = 11218466053242 := by decide
theorem cert_e2422373031034 : check e2422373031034 [[],[]] .smaller = true := by decide
def e2422373031126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422373031126 : Closed e2422373031126 ∧ code e2422373031126 = 11218466053334 := by decide
theorem cert_e2422373031126 : check e2422373031126 [[],[]] .smaller = true := by decide
def e2422373031130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422373031130 : Closed e2422373031130 ∧ code e2422373031130 = 11218466053338 := by decide
theorem cert_e2422373031130 : check e2422373031130 [[],[]] .smaller = true := by decide
def e2422373031146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422373031146 : Closed e2422373031146 ∧ code e2422373031146 = 11218466053354 := by decide
theorem cert_e2422373031146 : check e2422373031146 [[],[]] .smaller = true := by decide
def e2422373031198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422373031198 : Closed e2422373031198 ∧ code e2422373031198 = 11218466053406 := by decide
theorem cert_e2422373031198 : check e2422373031198 [[],[]] .smaller = true := by decide
def e2422373031222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373031222 : Closed e2422373031222 ∧ code e2422373031222 = 11218466053430 := by decide
theorem cert_e2422373031222 : check e2422373031222 [[],[]] .smaller = true := by decide
def e2422373031226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373031226 : Closed e2422373031226 ∧ code e2422373031226 = 11218466053434 := by decide
theorem cert_e2422373031226 : check e2422373031226 [[],[]] .smaller = true := by decide
def e2422373031322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373031322 : Closed e2422373031322 ∧ code e2422373031322 = 11218466053530 := by decide
theorem cert_e2422373031322 : check e2422373031322 [[],[]] .smaller = true := by decide
def e2422373031366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422373031366 : Closed e2422373031366 ∧ code e2422373031366 = 11218466053574 := by decide
theorem cert_e2422373031366 : check e2422373031366 [[],[]] .smaller = true := by decide
def e2422373031390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 3)))))))
theorem wire_e2422373031390 : Closed e2422373031390 ∧ code e2422373031390 = 11218466053598 := by decide
theorem cert_e2422373031390 : check e2422373031390 [[],[]] .three = true := by decide
def e2422373031406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 3)) (.var 2)))))))
theorem wire_e2422373031406 : Closed e2422373031406 ∧ code e2422373031406 = 11218466053614 := by decide
theorem cert_e2422373031406 : check e2422373031406 [[],[]] .three = true := by decide
def e2422373031478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422373031478 : Closed e2422373031478 ∧ code e2422373031478 = 11218466053686 := by decide
theorem cert_e2422373031478 : check e2422373031478 [[],[]] .smaller = true := by decide
def e2422373031482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422373031482 : Closed e2422373031482 ∧ code e2422373031482 = 11218466053690 := by decide
theorem cert_e2422373031482 : check e2422373031482 [[],[]] .smaller = true := by decide
def e2422373031566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422373031566 : Closed e2422373031566 ∧ code e2422373031566 = 11218466053774 := by decide
theorem cert_e2422373031566 : check e2422373031566 [[],[]] .smaller = true := by decide
def e2422373031622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422373031622 : Closed e2422373031622 ∧ code e2422373031622 = 11218466053830 := by decide
theorem cert_e2422373031622 : check e2422373031622 [[],[]] .smaller = true := by decide
def e2422373031646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 3)))))))
theorem wire_e2422373031646 : Closed e2422373031646 ∧ code e2422373031646 = 11218466053854 := by decide
theorem cert_e2422373031646 : check e2422373031646 [[],[]] .three = true := by decide
def e2422373031670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 3)) (.var 1)))))))
theorem wire_e2422373031670 : Closed e2422373031670 ∧ code e2422373031670 = 11218466053878 := by decide
theorem cert_e2422373031670 : check e2422373031670 [[],[]] .three = true := by decide
def e2422373031706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422373031706 : Closed e2422373031706 ∧ code e2422373031706 = 11218466053914 := by decide
theorem cert_e2422373031706 : check e2422373031706 [[],[]] .three = true := by decide
def e2422373031750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422373031750 : Closed e2422373031750 ∧ code e2422373031750 = 11218466053958 := by decide
theorem cert_e2422373031750 : check e2422373031750 [[],[]] .three = true := by decide
def e2422373031774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 0)) (.var 3)))))))
theorem wire_e2422373031774 : Closed e2422373031774 ∧ code e2422373031774 = 11218466053982 := by decide
theorem cert_e2422373031774 : check e2422373031774 [[],[]] .three = true := by decide
def e2422373031790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 1)) (.var 2)))))))
theorem wire_e2422373031790 : Closed e2422373031790 ∧ code e2422373031790 = 11218466053998 := by decide
theorem cert_e2422373031790 : check e2422373031790 [[],[]] .three = true := by decide
def e2422373031798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 2)) (.var 1)))))))
theorem wire_e2422373031798 : Closed e2422373031798 ∧ code e2422373031798 = 11218466054006 := by decide
theorem cert_e2422373031798 : check e2422373031798 [[],[]] .three = true := by decide
def e2422373031802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 4))) (.var 3)) (.var 0)))))))
theorem wire_e2422373031802 : Closed e2422373031802 ∧ code e2422373031802 = 11218466054010 := by decide
theorem cert_e2422373031802 : check e2422373031802 [[],[]] .three = true := by decide
def e2422373035350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422373035350 : Closed e2422373035350 ∧ code e2422373035350 = 11218466057558 := by decide
theorem cert_e2422373035350 : check e2422373035350 [[],[]] .smaller = true := by decide
def e2422373035354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422373035354 : Closed e2422373035354 ∧ code e2422373035354 = 11218466057562 := by decide
theorem cert_e2422373035354 : check e2422373035354 [[],[]] .smaller = true := by decide
def e2422373035370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2422373035370 : Closed e2422373035370 ∧ code e2422373035370 = 11218466057578 := by decide
theorem cert_e2422373035370 : check e2422373035370 [[],[]] .smaller = true := by decide
def e2422373035434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422373035434 : Closed e2422373035434 ∧ code e2422373035434 = 11218466057642 := by decide
theorem cert_e2422373035434 : check e2422373035434 [[],[]] .smaller = true := by decide
def e2422373035690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422373035690 : Closed e2422373035690 ∧ code e2422373035690 = 11218466057898 := by decide
theorem cert_e2422373035690 : check e2422373035690 [[],[]] .smaller = true := by decide
def e2422373036118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0)) (.var 1)))))))
theorem wire_e2422373036118 : Closed e2422373036118 ∧ code e2422373036118 = 11218466058326 := by decide
theorem cert_e2422373036118 : check e2422373036118 [[],[]] .smaller = true := by decide
def e2422373036122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)) (.var 0)))))))
theorem wire_e2422373036122 : Closed e2422373036122 ∧ code e2422373036122 = 11218466058330 := by decide
theorem cert_e2422373036122 : check e2422373036122 [[],[]] .smaller = true := by decide
def e2422373036382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 3)))))))
theorem wire_e2422373036382 : Closed e2422373036382 ∧ code e2422373036382 = 11218466058590 := by decide
theorem cert_e2422373036382 : check e2422373036382 [[],[]] .three = true := by decide
def e2422373036398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e2422373036398 : Closed e2422373036398 ∧ code e2422373036398 = 11218466058606 := by decide
theorem cert_e2422373036398 : check e2422373036398 [[],[]] .smaller = true := by decide
def e2422373036406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e2422373036406 : Closed e2422373036406 ∧ code e2422373036406 = 11218466058614 := by decide
theorem cert_e2422373036406 : check e2422373036406 [[],[]] .smaller = true := by decide
def e2422373036410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 3)) (.var 0)))))))
theorem wire_e2422373036410 : Closed e2422373036410 ∧ code e2422373036410 = 11218466058618 := by decide
theorem cert_e2422373036410 : check e2422373036410 [[],[]] .three = true := by decide
def e2422373036470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 1)))))))
theorem wire_e2422373036470 : Closed e2422373036470 ∧ code e2422373036470 = 11218466058678 := by decide
theorem cert_e2422373036470 : check e2422373036470 [[],[]] .smaller = true := by decide
def e2422373036502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373036502 : Closed e2422373036502 ∧ code e2422373036502 = 11218466058710 := by decide
theorem cert_e2422373036502 : check e2422373036502 [[],[]] .smaller = true := by decide
def e2422373036506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373036506 : Closed e2422373036506 ∧ code e2422373036506 = 11218466058714 := by decide
theorem cert_e2422373036506 : check e2422373036506 [[],[]] .smaller = true := by decide
def e2422373036886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373036886 : Closed e2422373036886 ∧ code e2422373036886 = 11218466059094 := by decide
theorem cert_e2422373036886 : check e2422373036886 [[],[]] .smaller = true := by decide
def e2422373036890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373036890 : Closed e2422373036890 ∧ code e2422373036890 = 11218466059098 := by decide
theorem cert_e2422373036890 : check e2422373036890 [[],[]] .smaller = true := by decide
def e2422373036906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373036906 : Closed e2422373036906 ∧ code e2422373036906 = 11218466059114 := by decide
theorem cert_e2422373036906 : check e2422373036906 [[],[]] .smaller = true := by decide
def e2422373036970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373036970 : Closed e2422373036970 ∧ code e2422373036970 = 11218466059178 := by decide
theorem cert_e2422373036970 : check e2422373036970 [[],[]] .smaller = true := by decide
def e2422373037078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373037078 : Closed e2422373037078 ∧ code e2422373037078 = 11218466059286 := by decide
theorem cert_e2422373037078 : check e2422373037078 [[],[]] .smaller = true := by decide
def e2422373037150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422373037150 : Closed e2422373037150 ∧ code e2422373037150 = 11218466059358 := by decide
theorem cert_e2422373037150 : check e2422373037150 [[],[]] .three = true := by decide
def e2422373037174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2422373037174 : Closed e2422373037174 ∧ code e2422373037174 = 11218466059382 := by decide
theorem cert_e2422373037174 : check e2422373037174 [[],[]] .smaller = true := by decide
def e2422373037270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422373037270 : Closed e2422373037270 ∧ code e2422373037270 = 11218466059478 := by decide
theorem cert_e2422373037270 : check e2422373037270 [[],[]] .smaller = true := by decide
def e2422373037274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422373037274 : Closed e2422373037274 ∧ code e2422373037274 = 11218466059482 := by decide
theorem cert_e2422373037274 : check e2422373037274 [[],[]] .smaller = true := by decide
def e2422373037290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422373037290 : Closed e2422373037290 ∧ code e2422373037290 = 11218466059498 := by decide
theorem cert_e2422373037290 : check e2422373037290 [[],[]] .smaller = true := by decide
def e2422373037366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373037366 : Closed e2422373037366 ∧ code e2422373037366 = 11218466059574 := by decide
theorem cert_e2422373037366 : check e2422373037366 [[],[]] .smaller = true := by decide
def e2422373037370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373037370 : Closed e2422373037370 ∧ code e2422373037370 = 11218466059578 := by decide
theorem cert_e2422373037370 : check e2422373037370 [[],[]] .smaller = true := by decide
def e2422373037442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373037442 : Closed e2422373037442 ∧ code e2422373037442 = 11218466059650 := by decide
theorem cert_e2422373037442 : check e2422373037442 [[],[]] .smaller = true := by decide
def e2422373037454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2422373037454 : Closed e2422373037454 ∧ code e2422373037454 = 11218466059662 := by decide
theorem cert_e2422373037454 : check e2422373037454 [[],[]] .smaller = true := by decide
def e2422373037466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373037466 : Closed e2422373037466 ∧ code e2422373037466 = 11218466059674 := by decide
theorem cert_e2422373037466 : check e2422373037466 [[],[]] .smaller = true := by decide
def e2422373037534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e2422373037534 : Closed e2422373037534 ∧ code e2422373037534 = 11218466059742 := by decide
theorem cert_e2422373037534 : check e2422373037534 [[],[]] .three = true := by decide
def e2422373037538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422373037538 : Closed e2422373037538 ∧ code e2422373037538 = 11218466059746 := by decide
theorem cert_e2422373037538 : check e2422373037538 [[],[]] .three = true := by decide
def e2422373037550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e2422373037550 : Closed e2422373037550 ∧ code e2422373037550 = 11218466059758 := by decide
theorem cert_e2422373037550 : check e2422373037550 [[],[]] .three = true := by decide
def e2422373037578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373037578 : Closed e2422373037578 ∧ code e2422373037578 = 11218466059786 := by decide
theorem cert_e2422373037578 : check e2422373037578 [[],[]] .smaller = true := by decide
def e2422373037614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422373037614 : Closed e2422373037614 ∧ code e2422373037614 = 11218466059822 := by decide
theorem cert_e2422373037614 : check e2422373037614 [[],[]] .smaller = true := by decide
def e2422373037622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422373037622 : Closed e2422373037622 ∧ code e2422373037622 = 11218466059830 := by decide
theorem cert_e2422373037622 : check e2422373037622 [[],[]] .smaller = true := by decide
def e2422373037626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422373037626 : Closed e2422373037626 ∧ code e2422373037626 = 11218466059834 := by decide
theorem cert_e2422373037626 : check e2422373037626 [[],[]] .smaller = true := by decide
def e2422373037674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422373037674 : Closed e2422373037674 ∧ code e2422373037674 = 11218466059882 := by decide
theorem cert_e2422373037674 : check e2422373037674 [[],[]] .smaller = true := by decide
def e2422373037698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373037698 : Closed e2422373037698 ∧ code e2422373037698 = 11218466059906 := by decide
theorem cert_e2422373037698 : check e2422373037698 [[],[]] .smaller = true := by decide
def e2422373037710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422373037710 : Closed e2422373037710 ∧ code e2422373037710 = 11218466059918 := by decide
theorem cert_e2422373037710 : check e2422373037710 [[],[]] .smaller = true := by decide
def e2422373037722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373037722 : Closed e2422373037722 ∧ code e2422373037722 = 11218466059930 := by decide
theorem cert_e2422373037722 : check e2422373037722 [[],[]] .smaller = true := by decide
def e2422373037766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422373037766 : Closed e2422373037766 ∧ code e2422373037766 = 11218466059974 := by decide
theorem cert_e2422373037766 : check e2422373037766 [[],[]] .smaller = true := by decide
def e2422373037790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e2422373037790 : Closed e2422373037790 ∧ code e2422373037790 = 11218466059998 := by decide
theorem cert_e2422373037790 : check e2422373037790 [[],[]] .three = true := by decide
def e2422373037794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422373037794 : Closed e2422373037794 ∧ code e2422373037794 = 11218466060002 := by decide
theorem cert_e2422373037794 : check e2422373037794 [[],[]] .smaller = true := by decide
def e2422373037806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e2422373037806 : Closed e2422373037806 ∧ code e2422373037806 = 11218466060014 := by decide
theorem cert_e2422373037806 : check e2422373037806 [[],[]] .smaller = true := by decide
def e2422373037814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e2422373037814 : Closed e2422373037814 ∧ code e2422373037814 = 11218466060022 := by decide
theorem cert_e2422373037814 : check e2422373037814 [[],[]] .three = true := by decide
def e2422373037846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422373037846 : Closed e2422373037846 ∧ code e2422373037846 = 11218466060054 := by decide
theorem cert_e2422373037846 : check e2422373037846 [[],[]] .smaller = true := by decide
def e2422373037918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e2422373037918 : Closed e2422373037918 ∧ code e2422373037918 = 11218466060126 := by decide
theorem cert_e2422373037918 : check e2422373037918 [[],[]] .three = true := by decide
def e2422373037922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422373037922 : Closed e2422373037922 ∧ code e2422373037922 = 11218466060130 := by decide
theorem cert_e2422373037922 : check e2422373037922 [[],[]] .smaller = true := by decide
def e2422373037934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e2422373037934 : Closed e2422373037934 ∧ code e2422373037934 = 11218466060142 := by decide
theorem cert_e2422373037934 : check e2422373037934 [[],[]] .smaller = true := by decide
def e2422373037942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e2422373037942 : Closed e2422373037942 ∧ code e2422373037942 = 11218466060150 := by decide
theorem cert_e2422373037942 : check e2422373037942 [[],[]] .smaller = true := by decide
def e2422373037946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e2422373037946 : Closed e2422373037946 ∧ code e2422373037946 = 11218466060154 := by decide
theorem cert_e2422373037946 : check e2422373037946 [[],[]] .three = true := by decide
def e2422373037962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422373037962 : Closed e2422373037962 ∧ code e2422373037962 = 11218466060170 := by decide
theorem cert_e2422373037962 : check e2422373037962 [[],[]] .three = true := by decide
def e2422373037986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422373037986 : Closed e2422373037986 ∧ code e2422373037986 = 11218466060194 := by decide
theorem cert_e2422373037986 : check e2422373037986 [[],[]] .three = true := by decide
def e2422373037998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e2422373037998 : Closed e2422373037998 ∧ code e2422373037998 = 11218466060206 := by decide
theorem cert_e2422373037998 : check e2422373037998 [[],[]] .three = true := by decide
def e2422373038006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e2422373038006 : Closed e2422373038006 ∧ code e2422373038006 = 11218466060214 := by decide
theorem cert_e2422373038006 : check e2422373038006 [[],[]] .three = true := by decide
def e2422373038010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e2422373038010 : Closed e2422373038010 ∧ code e2422373038010 = 11218466060218 := by decide
theorem cert_e2422373038010 : check e2422373038010 [[],[]] .three = true := by decide
def e2422373038122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)) (.var 0)))))))
theorem wire_e2422373038122 : Closed e2422373038122 ∧ code e2422373038122 = 11218466060330 := by decide
theorem cert_e2422373038122 : check e2422373038122 [[],[]] .smaller = true := by decide
def e2422373038254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422373038254 : Closed e2422373038254 ∧ code e2422373038254 = 11218466060462 := by decide
theorem cert_e2422373038254 : check e2422373038254 [[],[]] .smaller = true := by decide
def e2422373038266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422373038266 : Closed e2422373038266 ∧ code e2422373038266 = 11218466060474 := by decide
theorem cert_e2422373038266 : check e2422373038266 [[],[]] .smaller = true := by decide
def e2422373038294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373038294 : Closed e2422373038294 ∧ code e2422373038294 = 11218466060502 := by decide
theorem cert_e2422373038294 : check e2422373038294 [[],[]] .smaller = true := by decide
def e2422373038298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373038298 : Closed e2422373038298 ∧ code e2422373038298 = 11218466060506 := by decide
theorem cert_e2422373038298 : check e2422373038298 [[],[]] .smaller = true := by decide
def e2422373038314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373038314 : Closed e2422373038314 ∧ code e2422373038314 = 11218466060522 := by decide
theorem cert_e2422373038314 : check e2422373038314 [[],[]] .smaller = true := by decide
def e2422373038506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373038506 : Closed e2422373038506 ∧ code e2422373038506 = 11218466060714 := by decide
theorem cert_e2422373038506 : check e2422373038506 [[],[]] .smaller = true := by decide
def e2422373038602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373038602 : Closed e2422373038602 ∧ code e2422373038602 = 11218466060810 := by decide
theorem cert_e2422373038602 : check e2422373038602 [[],[]] .smaller = true := by decide
def e2422373038638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422373038638 : Closed e2422373038638 ∧ code e2422373038638 = 11218466060846 := by decide
theorem cert_e2422373038638 : check e2422373038638 [[],[]] .smaller = true := by decide
def e2422373038646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422373038646 : Closed e2422373038646 ∧ code e2422373038646 = 11218466060854 := by decide
theorem cert_e2422373038646 : check e2422373038646 [[],[]] .smaller = true := by decide
def e2422373038650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422373038650 : Closed e2422373038650 ∧ code e2422373038650 = 11218466060858 := by decide
theorem cert_e2422373038650 : check e2422373038650 [[],[]] .smaller = true := by decide
def e2422373038698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422373038698 : Closed e2422373038698 ∧ code e2422373038698 = 11218466060906 := by decide
theorem cert_e2422373038698 : check e2422373038698 [[],[]] .smaller = true := by decide
def e2422373038722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373038722 : Closed e2422373038722 ∧ code e2422373038722 = 11218466060930 := by decide
theorem cert_e2422373038722 : check e2422373038722 [[],[]] .smaller = true := by decide
def e2422373038734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422373038734 : Closed e2422373038734 ∧ code e2422373038734 = 11218466060942 := by decide
theorem cert_e2422373038734 : check e2422373038734 [[],[]] .smaller = true := by decide
def e2422373038746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373038746 : Closed e2422373038746 ∧ code e2422373038746 = 11218466060954 := by decide
theorem cert_e2422373038746 : check e2422373038746 [[],[]] .smaller = true := by decide
def e2422373038790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422373038790 : Closed e2422373038790 ∧ code e2422373038790 = 11218466060998 := by decide
theorem cert_e2422373038790 : check e2422373038790 [[],[]] .smaller = true := by decide
def e2422373038814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e2422373038814 : Closed e2422373038814 ∧ code e2422373038814 = 11218466061022 := by decide
theorem cert_e2422373038814 : check e2422373038814 [[],[]] .three = true := by decide
def e2422373038818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422373038818 : Closed e2422373038818 ∧ code e2422373038818 = 11218466061026 := by decide
theorem cert_e2422373038818 : check e2422373038818 [[],[]] .smaller = true := by decide
def e2422373038830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e2422373038830 : Closed e2422373038830 ∧ code e2422373038830 = 11218466061038 := by decide
theorem cert_e2422373038830 : check e2422373038830 [[],[]] .smaller = true := by decide
def e2422373038838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e2422373038838 : Closed e2422373038838 ∧ code e2422373038838 = 11218466061046 := by decide
theorem cert_e2422373038838 : check e2422373038838 [[],[]] .three = true := by decide
def e2422373038874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422373038874 : Closed e2422373038874 ∧ code e2422373038874 = 11218466061082 := by decide
theorem cert_e2422373038874 : check e2422373038874 [[],[]] .smaller = true := by decide
end Blc.Floor43
