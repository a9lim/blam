import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373326382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373326382 : Closed e2422373326382 ∧ code e2422373326382 = 11218466348590 := by decide
theorem cert_e2422373326382 : check e2422373326382 [[],[]] .smaller = true := by decide
def e2422373326390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e2422373326390 : Closed e2422373326390 ∧ code e2422373326390 = 11218466348598 := by decide
theorem cert_e2422373326390 : check e2422373326390 [[],[]] .smaller = true := by decide
def e2422373326394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373326394 : Closed e2422373326394 ∧ code e2422373326394 = 11218466348602 := by decide
theorem cert_e2422373326394 : check e2422373326394 [[],[]] .smaller = true := by decide
def e2422373326442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373326442 : Closed e2422373326442 ∧ code e2422373326442 = 11218466348650 := by decide
theorem cert_e2422373326442 : check e2422373326442 [[],[]] .smaller = true := by decide
def e2422373326466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373326466 : Closed e2422373326466 ∧ code e2422373326466 = 11218466348674 := by decide
theorem cert_e2422373326466 : check e2422373326466 [[],[]] .smaller = true := by decide
def e2422373326478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e2422373326478 : Closed e2422373326478 ∧ code e2422373326478 = 11218466348686 := by decide
theorem cert_e2422373326478 : check e2422373326478 [[],[]] .smaller = true := by decide
def e2422373326490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373326490 : Closed e2422373326490 ∧ code e2422373326490 = 11218466348698 := by decide
theorem cert_e2422373326490 : check e2422373326490 [[],[]] .smaller = true := by decide
def e2422373326534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373326534 : Closed e2422373326534 ∧ code e2422373326534 = 11218466348742 := by decide
theorem cert_e2422373326534 : check e2422373326534 [[],[]] .smaller = true := by decide
def e2422373326558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e2422373326558 : Closed e2422373326558 ∧ code e2422373326558 = 11218466348766 := by decide
theorem cert_e2422373326558 : check e2422373326558 [[],[]] .three = true := by decide
def e2422373326562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373326562 : Closed e2422373326562 ∧ code e2422373326562 = 11218466348770 := by decide
theorem cert_e2422373326562 : check e2422373326562 [[],[]] .smaller = true := by decide
def e2422373326574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 2)))))))
theorem wire_e2422373326574 : Closed e2422373326574 ∧ code e2422373326574 = 11218466348782 := by decide
theorem cert_e2422373326574 : check e2422373326574 [[],[]] .smaller = true := by decide
def e2422373326582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e2422373326582 : Closed e2422373326582 ∧ code e2422373326582 = 11218466348790 := by decide
theorem cert_e2422373326582 : check e2422373326582 [[],[]] .three = true := by decide
def e2422373326614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373326614 : Closed e2422373326614 ∧ code e2422373326614 = 11218466348822 := by decide
theorem cert_e2422373326614 : check e2422373326614 [[],[]] .three = true := by decide
def e2422373326618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e2422373326618 : Closed e2422373326618 ∧ code e2422373326618 = 11218466348826 := by decide
theorem cert_e2422373326618 : check e2422373326618 [[],[]] .three = true := by decide
def e2422373326662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e2422373326662 : Closed e2422373326662 ∧ code e2422373326662 = 11218466348870 := by decide
theorem cert_e2422373326662 : check e2422373326662 [[],[]] .three = true := by decide
def e2422373326686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 3)))))))
theorem wire_e2422373326686 : Closed e2422373326686 ∧ code e2422373326686 = 11218466348894 := by decide
theorem cert_e2422373326686 : check e2422373326686 [[],[]] .three = true := by decide
def e2422373326690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422373326690 : Closed e2422373326690 ∧ code e2422373326690 = 11218466348898 := by decide
theorem cert_e2422373326690 : check e2422373326690 [[],[]] .three = true := by decide
def e2422373326702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))) (.var 2)))))))
theorem wire_e2422373326702 : Closed e2422373326702 ∧ code e2422373326702 = 11218466348910 := by decide
theorem cert_e2422373326702 : check e2422373326702 [[],[]] .three = true := by decide
def e2422373326710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e2422373326710 : Closed e2422373326710 ∧ code e2422373326710 = 11218466348918 := by decide
theorem cert_e2422373326710 : check e2422373326710 [[],[]] .three = true := by decide
def e2422373326714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 3)))) (.var 0)))))))
theorem wire_e2422373326714 : Closed e2422373326714 ∧ code e2422373326714 = 11218466348922 := by decide
theorem cert_e2422373326714 : check e2422373326714 [[],[]] .three = true := by decide
def e2422373327294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422373327294 : Closed e2422373327294 ∧ code e2422373327294 = 11218466349502 := by decide
theorem cert_e2422373327294 : check e2422373327294 [[],[]] .three = true := by decide
def e2422373327326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373327326 : Closed e2422373327326 ∧ code e2422373327326 = 11218466349534 := by decide
theorem cert_e2422373327326 : check e2422373327326 [[],[]] .smaller = true := by decide
def e2422373327350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373327350 : Closed e2422373327350 ∧ code e2422373327350 = 11218466349558 := by decide
theorem cert_e2422373327350 : check e2422373327350 [[],[]] .smaller = true := by decide
def e2422373327354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422373327354 : Closed e2422373327354 ∧ code e2422373327354 = 11218466349562 := by decide
theorem cert_e2422373327354 : check e2422373327354 [[],[]] .three = true := by decide
def e2422373328302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422373328302 : Closed e2422373328302 ∧ code e2422373328302 = 11218466350510 := by decide
theorem cert_e2422373328302 : check e2422373328302 [[],[]] .smaller = true := by decide
def e2422373328314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422373328314 : Closed e2422373328314 ∧ code e2422373328314 = 11218466350522 := by decide
theorem cert_e2422373328314 : check e2422373328314 [[],[]] .smaller = true := by decide
def e2422373328362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422373328362 : Closed e2422373328362 ∧ code e2422373328362 = 11218466350570 := by decide
theorem cert_e2422373328362 : check e2422373328362 [[],[]] .smaller = true := by decide
def e2422373328446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422373328446 : Closed e2422373328446 ∧ code e2422373328446 = 11218466350654 := by decide
theorem cert_e2422373328446 : check e2422373328446 [[],[]] .three = true := by decide
def e2422373328494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373328494 : Closed e2422373328494 ∧ code e2422373328494 = 11218466350702 := by decide
theorem cert_e2422373328494 : check e2422373328494 [[],[]] .smaller = true := by decide
def e2422373328506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373328506 : Closed e2422373328506 ∧ code e2422373328506 = 11218466350714 := by decide
theorem cert_e2422373328506 : check e2422373328506 [[],[]] .smaller = true := by decide
def e2422373328670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422373328670 : Closed e2422373328670 ∧ code e2422373328670 = 11218466350878 := by decide
theorem cert_e2422373328670 : check e2422373328670 [[],[]] .smaller = true := by decide
def e2422373328770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373328770 : Closed e2422373328770 ∧ code e2422373328770 = 11218466350978 := by decide
theorem cert_e2422373328770 : check e2422373328770 [[],[]] .smaller = true := by decide
def e2422373328782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422373328782 : Closed e2422373328782 ∧ code e2422373328782 = 11218466350990 := by decide
theorem cert_e2422373328782 : check e2422373328782 [[],[]] .smaller = true := by decide
def e2422373328794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373328794 : Closed e2422373328794 ∧ code e2422373328794 = 11218466351002 := by decide
theorem cert_e2422373328794 : check e2422373328794 [[],[]] .smaller = true := by decide
def e2422373328838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422373328838 : Closed e2422373328838 ∧ code e2422373328838 = 11218466351046 := by decide
theorem cert_e2422373328838 : check e2422373328838 [[],[]] .three = true := by decide
def e2422373328862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 3))))))))
theorem wire_e2422373328862 : Closed e2422373328862 ∧ code e2422373328862 = 11218466351070 := by decide
theorem cert_e2422373328862 : check e2422373328862 [[],[]] .three = true := by decide
def e2422373331070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.var 5)))))))))
theorem wire_e2422373331070 : Closed e2422373331070 ∧ code e2422373331070 = 11218466353278 := by decide
theorem cert_e2422373331070 : check e2422373331070 [[],[]] .three = true := by decide
def e2422373331166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373331166 : Closed e2422373331166 ∧ code e2422373331166 = 11218466353374 := by decide
theorem cert_e2422373331166 : check e2422373331166 [[],[]] .smaller = true := by decide
def e2422373331194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373331194 : Closed e2422373331194 ∧ code e2422373331194 = 11218466353402 := by decide
theorem cert_e2422373331194 : check e2422373331194 [[],[]] .smaller = true := by decide
def e2422373331742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422373331742 : Closed e2422373331742 ∧ code e2422373331742 = 11218466353950 := by decide
theorem cert_e2422373331742 : check e2422373331742 [[],[]] .smaller = true := by decide
def e2422373331910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422373331910 : Closed e2422373331910 ∧ code e2422373331910 = 11218466354118 := by decide
theorem cert_e2422373331910 : check e2422373331910 [[],[]] .smaller = true := by decide
def e2422373331934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373331934 : Closed e2422373331934 ∧ code e2422373331934 = 11218466354142 := by decide
theorem cert_e2422373331934 : check e2422373331934 [[],[]] .three = true := by decide
def e2422373331938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422373331938 : Closed e2422373331938 ∧ code e2422373331938 = 11218466354146 := by decide
theorem cert_e2422373331938 : check e2422373331938 [[],[]] .three = true := by decide
def e2422373331950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373331950 : Closed e2422373331950 ∧ code e2422373331950 = 11218466354158 := by decide
theorem cert_e2422373331950 : check e2422373331950 [[],[]] .three = true := by decide
def e2422373333018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373333018 : Closed e2422373333018 ∧ code e2422373333018 = 11218466355226 := by decide
theorem cert_e2422373333018 : check e2422373333018 [[],[]] .smaller = true := by decide
def e2422373333054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373333054 : Closed e2422373333054 ∧ code e2422373333054 = 11218466355262 := by decide
theorem cert_e2422373333054 : check e2422373333054 [[],[]] .smaller = true := by decide
def e2422373333102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373333102 : Closed e2422373333102 ∧ code e2422373333102 = 11218466355310 := by decide
theorem cert_e2422373333102 : check e2422373333102 [[],[]] .smaller = true := by decide
def e2422373333110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373333110 : Closed e2422373333110 ∧ code e2422373333110 = 11218466355318 := by decide
theorem cert_e2422373333110 : check e2422373333110 [[],[]] .smaller = true := by decide
def e2422373333114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373333114 : Closed e2422373333114 ∧ code e2422373333114 = 11218466355322 := by decide
theorem cert_e2422373333114 : check e2422373333114 [[],[]] .smaller = true := by decide
def e2422373333354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373333354 : Closed e2422373333354 ∧ code e2422373333354 = 11218466355562 := by decide
theorem cert_e2422373333354 : check e2422373333354 [[],[]] .smaller = true := by decide
def e2422373333378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373333378 : Closed e2422373333378 ∧ code e2422373333378 = 11218466355586 := by decide
theorem cert_e2422373333378 : check e2422373333378 [[],[]] .smaller = true := by decide
def e2422373333390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373333390 : Closed e2422373333390 ∧ code e2422373333390 = 11218466355598 := by decide
theorem cert_e2422373333390 : check e2422373333390 [[],[]] .smaller = true := by decide
def e2422373333402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373333402 : Closed e2422373333402 ∧ code e2422373333402 = 11218466355610 := by decide
theorem cert_e2422373333402 : check e2422373333402 [[],[]] .smaller = true := by decide
def e2422373333446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373333446 : Closed e2422373333446 ∧ code e2422373333446 = 11218466355654 := by decide
theorem cert_e2422373333446 : check e2422373333446 [[],[]] .smaller = true := by decide
def e2422373333470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373333470 : Closed e2422373333470 ∧ code e2422373333470 = 11218466355678 := by decide
theorem cert_e2422373333470 : check e2422373333470 [[],[]] .three = true := by decide
def e2422373333474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373333474 : Closed e2422373333474 ∧ code e2422373333474 = 11218466355682 := by decide
theorem cert_e2422373333474 : check e2422373333474 [[],[]] .smaller = true := by decide
def e2422373333486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373333486 : Closed e2422373333486 ∧ code e2422373333486 = 11218466355694 := by decide
theorem cert_e2422373333486 : check e2422373333486 [[],[]] .smaller = true := by decide
def e2422373333494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373333494 : Closed e2422373333494 ∧ code e2422373333494 = 11218466355702 := by decide
theorem cert_e2422373333494 : check e2422373333494 [[],[]] .three = true := by decide
def e2422373334046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373334046 : Closed e2422373334046 ∧ code e2422373334046 = 11218466356254 := by decide
theorem cert_e2422373334046 : check e2422373334046 [[],[]] .three = true := by decide
def e2422373334070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373334070 : Closed e2422373334070 ∧ code e2422373334070 = 11218466356278 := by decide
theorem cert_e2422373334070 : check e2422373334070 [[],[]] .three = true := by decide
def e2422373334074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373334074 : Closed e2422373334074 ∧ code e2422373334074 = 11218466356282 := by decide
theorem cert_e2422373334074 : check e2422373334074 [[],[]] .three = true := by decide
def e2422373334214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373334214 : Closed e2422373334214 ∧ code e2422373334214 = 11218466356422 := by decide
theorem cert_e2422373334214 : check e2422373334214 [[],[]] .three = true := by decide
def e2422373334238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373334238 : Closed e2422373334238 ∧ code e2422373334238 = 11218466356446 := by decide
theorem cert_e2422373334238 : check e2422373334238 [[],[]] .three = true := by decide
def e2422373334242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373334242 : Closed e2422373334242 ∧ code e2422373334242 = 11218466356450 := by decide
theorem cert_e2422373334242 : check e2422373334242 [[],[]] .three = true := by decide
def e2422373334254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373334254 : Closed e2422373334254 ∧ code e2422373334254 = 11218466356462 := by decide
theorem cert_e2422373334254 : check e2422373334254 [[],[]] .three = true := by decide
def e2422373334262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373334262 : Closed e2422373334262 ∧ code e2422373334262 = 11218466356470 := by decide
theorem cert_e2422373334262 : check e2422373334262 [[],[]] .three = true := by decide
def e2422373334266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373334266 : Closed e2422373334266 ∧ code e2422373334266 = 11218466356474 := by decide
theorem cert_e2422373334266 : check e2422373334266 [[],[]] .three = true := by decide
def e2422373335254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 1)))))))
theorem wire_e2422373335254 : Closed e2422373335254 ∧ code e2422373335254 = 11218466357462 := by decide
theorem cert_e2422373335254 : check e2422373335254 [[],[]] .smaller = true := by decide
def e2422373335350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373335350 : Closed e2422373335350 ∧ code e2422373335350 = 11218466357558 := by decide
theorem cert_e2422373335350 : check e2422373335350 [[],[]] .smaller = true := by decide
def e2422373335354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373335354 : Closed e2422373335354 ∧ code e2422373335354 = 11218466357562 := by decide
theorem cert_e2422373335354 : check e2422373335354 [[],[]] .smaller = true := by decide
def e2422373335518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 3)))))))
theorem wire_e2422373335518 : Closed e2422373335518 ∧ code e2422373335518 = 11218466357726 := by decide
theorem cert_e2422373335518 : check e2422373335518 [[],[]] .three = true := by decide
def e2422373335534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 2)))))))
theorem wire_e2422373335534 : Closed e2422373335534 ∧ code e2422373335534 = 11218466357742 := by decide
theorem cert_e2422373335534 : check e2422373335534 [[],[]] .smaller = true := by decide
def e2422373335542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 4))))) (.var 1)))))))
theorem wire_e2422373335542 : Closed e2422373335542 ∧ code e2422373335542 = 11218466357750 := by decide
theorem cert_e2422373335542 : check e2422373335542 [[],[]] .smaller = true := by decide
def e2422373335546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 5))))) (.var 0)))))))
theorem wire_e2422373335546 : Closed e2422373335546 ∧ code e2422373335546 = 11218466357754 := by decide
theorem cert_e2422373335546 : check e2422373335546 [[],[]] .three = true := by decide
def e2422373335902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 3)))))))
theorem wire_e2422373335902 : Closed e2422373335902 ∧ code e2422373335902 = 11218466358110 := by decide
theorem cert_e2422373335902 : check e2422373335902 [[],[]] .three = true := by decide
def e2422373335926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.var 1)))))))
theorem wire_e2422373335926 : Closed e2422373335926 ∧ code e2422373335926 = 11218466358134 := by decide
theorem cert_e2422373335926 : check e2422373335926 [[],[]] .smaller = true := by decide
def e2422373335990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))) (.var 1)))))))
theorem wire_e2422373335990 : Closed e2422373335990 ∧ code e2422373335990 = 11218466358198 := by decide
theorem cert_e2422373335990 : check e2422373335990 [[],[]] .smaller = true := by decide
def e2422373335994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))) (.var 0)))))))
theorem wire_e2422373335994 : Closed e2422373335994 ∧ code e2422373335994 = 11218466358202 := by decide
theorem cert_e2422373335994 : check e2422373335994 [[],[]] .smaller = true := by decide
def e2422373336022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.var 1)))))))
theorem wire_e2422373336022 : Closed e2422373336022 ∧ code e2422373336022 = 11218466358230 := by decide
theorem cert_e2422373336022 : check e2422373336022 [[],[]] .smaller = true := by decide
def e2422373336026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))) (.var 0)))))))
theorem wire_e2422373336026 : Closed e2422373336026 ∧ code e2422373336026 = 11218466358234 := by decide
theorem cert_e2422373336026 : check e2422373336026 [[],[]] .smaller = true := by decide
def e2422373336286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373336286 : Closed e2422373336286 ∧ code e2422373336286 = 11218466358494 := by decide
theorem cert_e2422373336286 : check e2422373336286 [[],[]] .three = true := by decide
def e2422373336302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373336302 : Closed e2422373336302 ∧ code e2422373336302 = 11218466358510 := by decide
theorem cert_e2422373336302 : check e2422373336302 [[],[]] .smaller = true := by decide
def e2422373336310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373336310 : Closed e2422373336310 ∧ code e2422373336310 = 11218466358518 := by decide
theorem cert_e2422373336310 : check e2422373336310 [[],[]] .smaller = true := by decide
def e2422373336314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373336314 : Closed e2422373336314 ∧ code e2422373336314 = 11218466358522 := by decide
theorem cert_e2422373336314 : check e2422373336314 [[],[]] .three = true := by decide
def e2422373336638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 4))))))))
theorem wire_e2422373336638 : Closed e2422373336638 ∧ code e2422373336638 = 11218466358846 := by decide
theorem cert_e2422373336638 : check e2422373336638 [[],[]] .three = true := by decide
def e2422373336694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373336694 : Closed e2422373336694 ∧ code e2422373336694 = 11218466358902 := by decide
theorem cert_e2422373336694 : check e2422373336694 [[],[]] .smaller = true := by decide
def e2422373336862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 3))))))))
theorem wire_e2422373336862 : Closed e2422373336862 ∧ code e2422373336862 = 11218466359070 := by decide
theorem cert_e2422373336862 : check e2422373336862 [[],[]] .smaller = true := by decide
def e2422373336886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373336886 : Closed e2422373336886 ∧ code e2422373336886 = 11218466359094 := by decide
theorem cert_e2422373336886 : check e2422373336886 [[],[]] .smaller = true := by decide
def e2422373336890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373336890 : Closed e2422373336890 ∧ code e2422373336890 = 11218466359098 := by decide
theorem cert_e2422373336890 : check e2422373336890 [[],[]] .smaller = true := by decide
def e2422373336974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.lam (.var 2))))))))
theorem wire_e2422373336974 : Closed e2422373336974 ∧ code e2422373336974 = 11218466359182 := by decide
theorem cert_e2422373336974 : check e2422373336974 [[],[]] .smaller = true := by decide
def e2422373337030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 4)))) (.lam (.var 1))))))))
theorem wire_e2422373337030 : Closed e2422373337030 ∧ code e2422373337030 = 11218466359238 := by decide
theorem cert_e2422373337030 : check e2422373337030 [[],[]] .three = true := by decide
def e2422373337054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 4)))) (.var 3)))))))
theorem wire_e2422373337054 : Closed e2422373337054 ∧ code e2422373337054 = 11218466359262 := by decide
theorem cert_e2422373337054 : check e2422373337054 [[],[]] .three = true := by decide
def e2422373337942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373337942 : Closed e2422373337942 ∧ code e2422373337942 = 11218466360150 := by decide
theorem cert_e2422373337942 : check e2422373337942 [[],[]] .smaller = true := by decide
def e2422373337946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373337946 : Closed e2422373337946 ∧ code e2422373337946 = 11218466360154 := by decide
theorem cert_e2422373337946 : check e2422373337946 [[],[]] .smaller = true := by decide
def e2422373337962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373337962 : Closed e2422373337962 ∧ code e2422373337962 = 11218466360170 := by decide
theorem cert_e2422373337962 : check e2422373337962 [[],[]] .smaller = true := by decide
def e2422373338026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373338026 : Closed e2422373338026 ∧ code e2422373338026 = 11218466360234 := by decide
theorem cert_e2422373338026 : check e2422373338026 [[],[]] .smaller = true := by decide
def e2422373338134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 1)))))))
theorem wire_e2422373338134 : Closed e2422373338134 ∧ code e2422373338134 = 11218466360342 := by decide
theorem cert_e2422373338134 : check e2422373338134 [[],[]] .smaller = true := by decide
def e2422373338206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 3)))))))
theorem wire_e2422373338206 : Closed e2422373338206 ∧ code e2422373338206 = 11218466360414 := by decide
theorem cert_e2422373338206 : check e2422373338206 [[],[]] .three = true := by decide
def e2422373338230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422373338230 : Closed e2422373338230 ∧ code e2422373338230 = 11218466360438 := by decide
theorem cert_e2422373338230 : check e2422373338230 [[],[]] .smaller = true := by decide
def e2422373338326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e2422373338326 : Closed e2422373338326 ∧ code e2422373338326 = 11218466360534 := by decide
theorem cert_e2422373338326 : check e2422373338326 [[],[]] .smaller = true := by decide
def e2422373338330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e2422373338330 : Closed e2422373338330 ∧ code e2422373338330 = 11218466360538 := by decide
theorem cert_e2422373338330 : check e2422373338330 [[],[]] .smaller = true := by decide
def e2422373338346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e2422373338346 : Closed e2422373338346 ∧ code e2422373338346 = 11218466360554 := by decide
theorem cert_e2422373338346 : check e2422373338346 [[],[]] .smaller = true := by decide
def e2422373338422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373338422 : Closed e2422373338422 ∧ code e2422373338422 = 11218466360630 := by decide
theorem cert_e2422373338422 : check e2422373338422 [[],[]] .smaller = true := by decide
def e2422373338426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373338426 : Closed e2422373338426 ∧ code e2422373338426 = 11218466360634 := by decide
theorem cert_e2422373338426 : check e2422373338426 [[],[]] .smaller = true := by decide
def e2422373338498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373338498 : Closed e2422373338498 ∧ code e2422373338498 = 11218466360706 := by decide
theorem cert_e2422373338498 : check e2422373338498 [[],[]] .smaller = true := by decide
def e2422373338510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422373338510 : Closed e2422373338510 ∧ code e2422373338510 = 11218466360718 := by decide
theorem cert_e2422373338510 : check e2422373338510 [[],[]] .smaller = true := by decide
def e2422373338522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373338522 : Closed e2422373338522 ∧ code e2422373338522 = 11218466360730 := by decide
theorem cert_e2422373338522 : check e2422373338522 [[],[]] .smaller = true := by decide
def e2422373338590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e2422373338590 : Closed e2422373338590 ∧ code e2422373338590 = 11218466360798 := by decide
theorem cert_e2422373338590 : check e2422373338590 [[],[]] .three = true := by decide
def e2422373338594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))) (.lam (.var 0))))))))
theorem wire_e2422373338594 : Closed e2422373338594 ∧ code e2422373338594 = 11218466360802 := by decide
theorem cert_e2422373338594 : check e2422373338594 [[],[]] .three = true := by decide
def e2422373338606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e2422373338606 : Closed e2422373338606 ∧ code e2422373338606 = 11218466360814 := by decide
theorem cert_e2422373338606 : check e2422373338606 [[],[]] .three = true := by decide
def e2422373338634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 0)))))))
theorem wire_e2422373338634 : Closed e2422373338634 ∧ code e2422373338634 = 11218466360842 := by decide
theorem cert_e2422373338634 : check e2422373338634 [[],[]] .smaller = true := by decide
def e2422373338670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373338670 : Closed e2422373338670 ∧ code e2422373338670 = 11218466360878 := by decide
theorem cert_e2422373338670 : check e2422373338670 [[],[]] .smaller = true := by decide
def e2422373338678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e2422373338678 : Closed e2422373338678 ∧ code e2422373338678 = 11218466360886 := by decide
theorem cert_e2422373338678 : check e2422373338678 [[],[]] .smaller = true := by decide
def e2422373338682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373338682 : Closed e2422373338682 ∧ code e2422373338682 = 11218466360890 := by decide
theorem cert_e2422373338682 : check e2422373338682 [[],[]] .smaller = true := by decide
def e2422373338730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373338730 : Closed e2422373338730 ∧ code e2422373338730 = 11218466360938 := by decide
theorem cert_e2422373338730 : check e2422373338730 [[],[]] .smaller = true := by decide
def e2422373338754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373338754 : Closed e2422373338754 ∧ code e2422373338754 = 11218466360962 := by decide
theorem cert_e2422373338754 : check e2422373338754 [[],[]] .smaller = true := by decide
def e2422373338766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e2422373338766 : Closed e2422373338766 ∧ code e2422373338766 = 11218466360974 := by decide
theorem cert_e2422373338766 : check e2422373338766 [[],[]] .smaller = true := by decide
def e2422373338778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373338778 : Closed e2422373338778 ∧ code e2422373338778 = 11218466360986 := by decide
theorem cert_e2422373338778 : check e2422373338778 [[],[]] .smaller = true := by decide
def e2422373338822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373338822 : Closed e2422373338822 ∧ code e2422373338822 = 11218466361030 := by decide
theorem cert_e2422373338822 : check e2422373338822 [[],[]] .smaller = true := by decide
def e2422373338846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e2422373338846 : Closed e2422373338846 ∧ code e2422373338846 = 11218466361054 := by decide
theorem cert_e2422373338846 : check e2422373338846 [[],[]] .three = true := by decide
def e2422373338850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373338850 : Closed e2422373338850 ∧ code e2422373338850 = 11218466361058 := by decide
theorem cert_e2422373338850 : check e2422373338850 [[],[]] .smaller = true := by decide
def e2422373338862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e2422373338862 : Closed e2422373338862 ∧ code e2422373338862 = 11218466361070 := by decide
theorem cert_e2422373338862 : check e2422373338862 [[],[]] .smaller = true := by decide
def e2422373338870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e2422373338870 : Closed e2422373338870 ∧ code e2422373338870 = 11218466361078 := by decide
theorem cert_e2422373338870 : check e2422373338870 [[],[]] .three = true := by decide
def e2422373338902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373338902 : Closed e2422373338902 ∧ code e2422373338902 = 11218466361110 := by decide
theorem cert_e2422373338902 : check e2422373338902 [[],[]] .smaller = true := by decide
def e2422373338974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e2422373338974 : Closed e2422373338974 ∧ code e2422373338974 = 11218466361182 := by decide
theorem cert_e2422373338974 : check e2422373338974 [[],[]] .three = true := by decide
def e2422373338978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422373338978 : Closed e2422373338978 ∧ code e2422373338978 = 11218466361186 := by decide
theorem cert_e2422373338978 : check e2422373338978 [[],[]] .smaller = true := by decide
def e2422373338990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e2422373338990 : Closed e2422373338990 ∧ code e2422373338990 = 11218466361198 := by decide
theorem cert_e2422373338990 : check e2422373338990 [[],[]] .smaller = true := by decide
def e2422373338998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 2)))) (.var 1)))))))
theorem wire_e2422373338998 : Closed e2422373338998 ∧ code e2422373338998 = 11218466361206 := by decide
theorem cert_e2422373338998 : check e2422373338998 [[],[]] .smaller = true := by decide
def e2422373339002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e2422373339002 : Closed e2422373339002 ∧ code e2422373339002 = 11218466361210 := by decide
theorem cert_e2422373339002 : check e2422373339002 [[],[]] .three = true := by decide
def e2422373339018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373339018 : Closed e2422373339018 ∧ code e2422373339018 = 11218466361226 := by decide
theorem cert_e2422373339018 : check e2422373339018 [[],[]] .three = true := by decide
def e2422373339042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373339042 : Closed e2422373339042 ∧ code e2422373339042 = 11218466361250 := by decide
theorem cert_e2422373339042 : check e2422373339042 [[],[]] .three = true := by decide
def e2422373339054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e2422373339054 : Closed e2422373339054 ∧ code e2422373339054 = 11218466361262 := by decide
theorem cert_e2422373339054 : check e2422373339054 [[],[]] .three = true := by decide
def e2422373339062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e2422373339062 : Closed e2422373339062 ∧ code e2422373339062 = 11218466361270 := by decide
theorem cert_e2422373339062 : check e2422373339062 [[],[]] .three = true := by decide
def e2422373339066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e2422373339066 : Closed e2422373339066 ∧ code e2422373339066 = 11218466361274 := by decide
theorem cert_e2422373339066 : check e2422373339066 [[],[]] .three = true := by decide
def e2422373339262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 5)))))))))
theorem wire_e2422373339262 : Closed e2422373339262 ∧ code e2422373339262 = 11218466361470 := by decide
theorem cert_e2422373339262 : check e2422373339262 [[],[]] .three = true := by decide
def e2422373339374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373339374 : Closed e2422373339374 ∧ code e2422373339374 = 11218466361582 := by decide
theorem cert_e2422373339374 : check e2422373339374 [[],[]] .smaller = true := by decide
def e2422373339382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373339382 : Closed e2422373339382 ∧ code e2422373339382 = 11218466361590 := by decide
theorem cert_e2422373339382 : check e2422373339382 [[],[]] .smaller = true := by decide
def e2422373339862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422373339862 : Closed e2422373339862 ∧ code e2422373339862 = 11218466362070 := by decide
theorem cert_e2422373339862 : check e2422373339862 [[],[]] .smaller = true := by decide
def e2422373339866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422373339866 : Closed e2422373339866 ∧ code e2422373339866 = 11218466362074 := by decide
theorem cert_e2422373339866 : check e2422373339866 [[],[]] .smaller = true := by decide
def e2422373339882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422373339882 : Closed e2422373339882 ∧ code e2422373339882 = 11218466362090 := by decide
theorem cert_e2422373339882 : check e2422373339882 [[],[]] .smaller = true := by decide
def e2422373339958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373339958 : Closed e2422373339958 ∧ code e2422373339958 = 11218466362166 := by decide
theorem cert_e2422373339958 : check e2422373339958 [[],[]] .smaller = true := by decide
def e2422373339962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373339962 : Closed e2422373339962 ∧ code e2422373339962 = 11218466362170 := by decide
theorem cert_e2422373339962 : check e2422373339962 [[],[]] .smaller = true := by decide
def e2422373340034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373340034 : Closed e2422373340034 ∧ code e2422373340034 = 11218466362242 := by decide
theorem cert_e2422373340034 : check e2422373340034 [[],[]] .smaller = true := by decide
def e2422373340046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2422373340046 : Closed e2422373340046 ∧ code e2422373340046 = 11218466362254 := by decide
theorem cert_e2422373340046 : check e2422373340046 [[],[]] .smaller = true := by decide
def e2422373340058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373340058 : Closed e2422373340058 ∧ code e2422373340058 = 11218466362266 := by decide
theorem cert_e2422373340058 : check e2422373340058 [[],[]] .smaller = true := by decide
def e2422373340126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373340126 : Closed e2422373340126 ∧ code e2422373340126 = 11218466362334 := by decide
theorem cert_e2422373340126 : check e2422373340126 [[],[]] .three = true := by decide
def e2422373340130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422373340130 : Closed e2422373340130 ∧ code e2422373340130 = 11218466362338 := by decide
theorem cert_e2422373340130 : check e2422373340130 [[],[]] .three = true := by decide
def e2422373340142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373340142 : Closed e2422373340142 ∧ code e2422373340142 = 11218466362350 := by decide
theorem cert_e2422373340142 : check e2422373340142 [[],[]] .three = true := by decide
def e2422373341210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373341210 : Closed e2422373341210 ∧ code e2422373341210 = 11218466363418 := by decide
theorem cert_e2422373341210 : check e2422373341210 [[],[]] .smaller = true := by decide
def e2422373341246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373341246 : Closed e2422373341246 ∧ code e2422373341246 = 11218466363454 := by decide
theorem cert_e2422373341246 : check e2422373341246 [[],[]] .smaller = true := by decide
def e2422373341294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373341294 : Closed e2422373341294 ∧ code e2422373341294 = 11218466363502 := by decide
theorem cert_e2422373341294 : check e2422373341294 [[],[]] .smaller = true := by decide
def e2422373341302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373341302 : Closed e2422373341302 ∧ code e2422373341302 = 11218466363510 := by decide
theorem cert_e2422373341302 : check e2422373341302 [[],[]] .smaller = true := by decide
def e2422373341306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373341306 : Closed e2422373341306 ∧ code e2422373341306 = 11218466363514 := by decide
theorem cert_e2422373341306 : check e2422373341306 [[],[]] .smaller = true := by decide
def e2422373341546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373341546 : Closed e2422373341546 ∧ code e2422373341546 = 11218466363754 := by decide
theorem cert_e2422373341546 : check e2422373341546 [[],[]] .smaller = true := by decide
def e2422373341570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373341570 : Closed e2422373341570 ∧ code e2422373341570 = 11218466363778 := by decide
theorem cert_e2422373341570 : check e2422373341570 [[],[]] .smaller = true := by decide
def e2422373341582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373341582 : Closed e2422373341582 ∧ code e2422373341582 = 11218466363790 := by decide
theorem cert_e2422373341582 : check e2422373341582 [[],[]] .smaller = true := by decide
def e2422373341594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373341594 : Closed e2422373341594 ∧ code e2422373341594 = 11218466363802 := by decide
theorem cert_e2422373341594 : check e2422373341594 [[],[]] .smaller = true := by decide
def e2422373341638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373341638 : Closed e2422373341638 ∧ code e2422373341638 = 11218466363846 := by decide
theorem cert_e2422373341638 : check e2422373341638 [[],[]] .smaller = true := by decide
def e2422373341662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373341662 : Closed e2422373341662 ∧ code e2422373341662 = 11218466363870 := by decide
theorem cert_e2422373341662 : check e2422373341662 [[],[]] .three = true := by decide
def e2422373341666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373341666 : Closed e2422373341666 ∧ code e2422373341666 = 11218466363874 := by decide
theorem cert_e2422373341666 : check e2422373341666 [[],[]] .smaller = true := by decide
end Blc.Floor43
