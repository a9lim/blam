import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393371359854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393371359854 : Closed e2393371359854 ∧ code e2393371359854 = 11189464382062 := by decide
theorem cert_e2393371359854 : check e2393371359854 [[],[.left],[]] .chain = true := by decide
def e2393371359866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393371359866 : Closed e2393371359866 ∧ code e2393371359866 = 11189464382074 := by decide
theorem cert_e2393371359866 : check e2393371359866 [[],[.left],[]] .chain = true := by decide
def e2393371360030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2393371360030 : Closed e2393371360030 ∧ code e2393371360030 = 11189464382238 := by decide
theorem cert_e2393371360030 : check e2393371360030 [[],[.left],[]] .chain = true := by decide
def e2393371360142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2393371360142 : Closed e2393371360142 ∧ code e2393371360142 = 11189464382350 := by decide
theorem cert_e2393371360142 : check e2393371360142 [[],[.left],[]] .chain = true := by decide
def e2393371360154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371360154 : Closed e2393371360154 ∧ code e2393371360154 = 11189464382362 := by decide
theorem cert_e2393371360154 : check e2393371360154 [[],[.left],[]] .chain = true := by decide
def e2393371360198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2393371360198 : Closed e2393371360198 ∧ code e2393371360198 = 11189464382406 := by decide
theorem cert_e2393371360198 : check e2393371360198 [[],[.left],[]] .chain = true := by decide
def e2393371360222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 3))))))))
theorem wire_e2393371360222 : Closed e2393371360222 ∧ code e2393371360222 = 11189464382430 := by decide
theorem cert_e2393371360222 : check e2393371360222 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2393371360374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2393371360374 : Closed e2393371360374 ∧ code e2393371360374 = 11189464382582 := by decide
theorem cert_e2393371360374 : check e2393371360374 [[],[.left],[]] .chain = true := by decide
def e2393371360470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2393371360470 : Closed e2393371360470 ∧ code e2393371360470 = 11189464382678 := by decide
theorem cert_e2393371360470 : check e2393371360470 [[],[.left],[]] .chain = true := by decide
def e2393371360474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2393371360474 : Closed e2393371360474 ∧ code e2393371360474 = 11189464382682 := by decide
theorem cert_e2393371360474 : check e2393371360474 [[],[.left],[]] .chain = true := by decide
def e2393371360490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2393371360490 : Closed e2393371360490 ∧ code e2393371360490 = 11189464382698 := by decide
theorem cert_e2393371360490 : check e2393371360490 [[],[.left],[]] .chain = true := by decide
def e2393371360566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393371360566 : Closed e2393371360566 ∧ code e2393371360566 = 11189464382774 := by decide
theorem cert_e2393371360566 : check e2393371360566 [[],[.left],[]] .chain = true := by decide
def e2393371360570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393371360570 : Closed e2393371360570 ∧ code e2393371360570 = 11189464382778 := by decide
theorem cert_e2393371360570 : check e2393371360570 [[],[.left],[]] .chain = true := by decide
def e2393371360654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2393371360654 : Closed e2393371360654 ∧ code e2393371360654 = 11189464382862 := by decide
theorem cert_e2393371360654 : check e2393371360654 [[],[.left],[]] .chain = true := by decide
def e2393371360666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371360666 : Closed e2393371360666 ∧ code e2393371360666 = 11189464382874 := by decide
theorem cert_e2393371360666 : check e2393371360666 [[],[.left],[]] .chain = true := by decide
def e2393371360734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e2393371360734 : Closed e2393371360734 ∧ code e2393371360734 = 11189464382942 := by decide
theorem cert_e2393371360734 : check e2393371360734 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371360750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e2393371360750 : Closed e2393371360750 ∧ code e2393371360750 = 11189464382958 := by decide
theorem cert_e2393371360750 : check e2393371360750 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371360822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2393371360822 : Closed e2393371360822 ∧ code e2393371360822 = 11189464383030 := by decide
theorem cert_e2393371360822 : check e2393371360822 [[],[.left],[]] .chain = true := by decide
def e2393371360826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2393371360826 : Closed e2393371360826 ∧ code e2393371360826 = 11189464383034 := by decide
theorem cert_e2393371360826 : check e2393371360826 [[],[.left],[]] .chain = true := by decide
def e2393371360910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2393371360910 : Closed e2393371360910 ∧ code e2393371360910 = 11189464383118 := by decide
theorem cert_e2393371360910 : check e2393371360910 [[],[.left],[]] .chain = true := by decide
def e2393371360966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2393371360966 : Closed e2393371360966 ∧ code e2393371360966 = 11189464383174 := by decide
theorem cert_e2393371360966 : check e2393371360966 [[],[.left],[]] .chain = true := by decide
def e2393371360990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 3))))))))
theorem wire_e2393371360990 : Closed e2393371360990 ∧ code e2393371360990 = 11189464383198 := by decide
theorem cert_e2393371360990 : check e2393371360990 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2393371361006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e2393371361006 : Closed e2393371361006 ∧ code e2393371361006 = 11189464383214 := by decide
theorem cert_e2393371361006 : check e2393371361006 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371361014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 1))))))))
theorem wire_e2393371361014 : Closed e2393371361014 ∧ code e2393371361014 = 11189464383222 := by decide
theorem cert_e2393371361014 : check e2393371361014 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371362270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2393371362270 : Closed e2393371362270 ∧ code e2393371362270 = 11189464384478 := by decide
theorem cert_e2393371362270 : check e2393371362270 [[],[.left],[]] .chain = true := by decide
def e2393371362286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2393371362286 : Closed e2393371362286 ∧ code e2393371362286 = 11189464384494 := by decide
theorem cert_e2393371362286 : check e2393371362286 [[],[.left],[]] .chain = true := by decide
def e2393371364206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393371364206 : Closed e2393371364206 ∧ code e2393371364206 = 11189464386414 := by decide
theorem cert_e2393371364206 : check e2393371364206 [[],[.left],[]] .chain = true := by decide
def e2393371364214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393371364214 : Closed e2393371364214 ∧ code e2393371364214 = 11189464386422 := by decide
theorem cert_e2393371364214 : check e2393371364214 [[],[.left],[]] .chain = true := by decide
def e2393371364270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393371364270 : Closed e2393371364270 ∧ code e2393371364270 = 11189464386478 := by decide
theorem cert_e2393371364270 : check e2393371364270 [[],[.left],[]] .chain = true := by decide
def e2393371364282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393371364282 : Closed e2393371364282 ∧ code e2393371364282 = 11189464386490 := by decide
theorem cert_e2393371364282 : check e2393371364282 [[],[.left],[]] .chain = true := by decide
def e2393371364310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393371364310 : Closed e2393371364310 ∧ code e2393371364310 = 11189464386518 := by decide
theorem cert_e2393371364310 : check e2393371364310 [[],[.left],[]] .chain = true := by decide
def e2393371364314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393371364314 : Closed e2393371364314 ∧ code e2393371364314 = 11189464386522 := by decide
theorem cert_e2393371364314 : check e2393371364314 [[],[.left],[]] .chain = true := by decide
def e2393371364590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393371364590 : Closed e2393371364590 ∧ code e2393371364590 = 11189464386798 := by decide
theorem cert_e2393371364590 : check e2393371364590 [[],[.left],[]] .chain = true := by decide
def e2393371364598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393371364598 : Closed e2393371364598 ∧ code e2393371364598 = 11189464386806 := by decide
theorem cert_e2393371364598 : check e2393371364598 [[],[.left],[]] .chain = true := by decide
def e2393371364926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2393371364926 : Closed e2393371364926 ∧ code e2393371364926 = 11189464387134 := by decide
theorem cert_e2393371364926 : check e2393371364926 [[],[.left],[]] .chain = true := by decide
def e2393371364974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393371364974 : Closed e2393371364974 ∧ code e2393371364974 = 11189464387182 := by decide
theorem cert_e2393371364974 : check e2393371364974 [[],[.left],[]] .chain = true := by decide
def e2393371364986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393371364986 : Closed e2393371364986 ∧ code e2393371364986 = 11189464387194 := by decide
theorem cert_e2393371364986 : check e2393371364986 [[],[.left],[]] .chain = true := by decide
def e2393371365174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393371365174 : Closed e2393371365174 ∧ code e2393371365174 = 11189464387382 := by decide
theorem cert_e2393371365174 : check e2393371365174 [[],[.left],[]] .chain = true := by decide
def e2393371365178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393371365178 : Closed e2393371365178 ∧ code e2393371365178 = 11189464387386 := by decide
theorem cert_e2393371365178 : check e2393371365178 [[],[.left],[]] .chain = true := by decide
def e2393371365262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2393371365262 : Closed e2393371365262 ∧ code e2393371365262 = 11189464387470 := by decide
theorem cert_e2393371365262 : check e2393371365262 [[],[.left],[]] .chain = true := by decide
def e2393371369950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2393371369950 : Closed e2393371369950 ∧ code e2393371369950 = 11189464392158 := by decide
theorem cert_e2393371369950 : check e2393371369950 [[],[.left],[]] .chain = true := by decide
def e2393371369974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2393371369974 : Closed e2393371369974 ∧ code e2393371369974 = 11189464392182 := by decide
theorem cert_e2393371369974 : check e2393371369974 [[],[.left],[]] .chain = true := by decide
def e2393371370926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2393371370926 : Closed e2393371370926 ∧ code e2393371370926 = 11189464393134 := by decide
theorem cert_e2393371370926 : check e2393371370926 [[],[.left],[]] .chain = true := by decide
def e2393371370938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2393371370938 : Closed e2393371370938 ∧ code e2393371370938 = 11189464393146 := by decide
theorem cert_e2393371370938 : check e2393371370938 [[],[.left],[]] .chain = true := by decide
def e2393371370986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2393371370986 : Closed e2393371370986 ∧ code e2393371370986 = 11189464393194 := by decide
theorem cert_e2393371370986 : check e2393371370986 [[],[.left],[]] .chain = true := by decide
def e2393371371070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2393371371070 : Closed e2393371371070 ∧ code e2393371371070 = 11189464393278 := by decide
theorem cert_e2393371371070 : check e2393371371070 [[],[.left],[]] .chain = true := by decide
def e2393371371118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393371371118 : Closed e2393371371118 ∧ code e2393371371118 = 11189464393326 := by decide
theorem cert_e2393371371118 : check e2393371371118 [[],[.left],[]] .chain = true := by decide
def e2393371371130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393371371130 : Closed e2393371371130 ∧ code e2393371371130 = 11189464393338 := by decide
theorem cert_e2393371371130 : check e2393371371130 [[],[.left],[]] .chain = true := by decide
def e2393371371294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2393371371294 : Closed e2393371371294 ∧ code e2393371371294 = 11189464393502 := by decide
theorem cert_e2393371371294 : check e2393371371294 [[],[.left],[]] .chain = true := by decide
def e2393371371406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2393371371406 : Closed e2393371371406 ∧ code e2393371371406 = 11189464393614 := by decide
theorem cert_e2393371371406 : check e2393371371406 [[],[.left],[]] .chain = true := by decide
def e2393371371418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393371371418 : Closed e2393371371418 ∧ code e2393371371418 = 11189464393626 := by decide
theorem cert_e2393371371418 : check e2393371371418 [[],[.left],[]] .chain = true := by decide
def e2393371371462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2393371371462 : Closed e2393371371462 ∧ code e2393371371462 = 11189464393670 := by decide
theorem cert_e2393371371462 : check e2393371371462 [[],[.left],[]] .chain = true := by decide
def e2393371371486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 3)))))))))
theorem wire_e2393371371486 : Closed e2393371371486 ∧ code e2393371371486 = 11189464393694 := by decide
theorem cert_e2393371371486 : check e2393371371486 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2393371373806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2393371373806 : Closed e2393371373806 ∧ code e2393371373806 = 11189464396014 := by decide
theorem cert_e2393371373806 : check e2393371373806 [[],[.left],[]] .chain = true := by decide
def e2393371373814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2393371373814 : Closed e2393371373814 ∧ code e2393371373814 = 11189464396022 := by decide
theorem cert_e2393371373814 : check e2393371373814 [[],[.left],[]] .chain = true := by decide
def e2393371374294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2393371374294 : Closed e2393371374294 ∧ code e2393371374294 = 11189464396502 := by decide
theorem cert_e2393371374294 : check e2393371374294 [[],[.left],[]] .chain = true := by decide
def e2393371374298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2393371374298 : Closed e2393371374298 ∧ code e2393371374298 = 11189464396506 := by decide
theorem cert_e2393371374298 : check e2393371374298 [[],[.left],[]] .chain = true := by decide
def e2393371374314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2393371374314 : Closed e2393371374314 ∧ code e2393371374314 = 11189464396522 := by decide
theorem cert_e2393371374314 : check e2393371374314 [[],[.left],[]] .chain = true := by decide
def e2393371374390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393371374390 : Closed e2393371374390 ∧ code e2393371374390 = 11189464396598 := by decide
theorem cert_e2393371374390 : check e2393371374390 [[],[.left],[]] .chain = true := by decide
def e2393371374394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393371374394 : Closed e2393371374394 ∧ code e2393371374394 = 11189464396602 := by decide
theorem cert_e2393371374394 : check e2393371374394 [[],[.left],[]] .chain = true := by decide
def e2393371374478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2393371374478 : Closed e2393371374478 ∧ code e2393371374478 = 11189464396686 := by decide
theorem cert_e2393371374478 : check e2393371374478 [[],[.left],[]] .chain = true := by decide
def e2393371374490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393371374490 : Closed e2393371374490 ∧ code e2393371374490 = 11189464396698 := by decide
theorem cert_e2393371374490 : check e2393371374490 [[],[.left],[]] .chain = true := by decide
def e2393371374558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e2393371374558 : Closed e2393371374558 ∧ code e2393371374558 = 11189464396766 := by decide
theorem cert_e2393371374558 : check e2393371374558 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371374574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e2393371374574 : Closed e2393371374574 ∧ code e2393371374574 = 11189464396782 := by decide
theorem cert_e2393371374574 : check e2393371374574 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371376014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2393371376014 : Closed e2393371376014 ∧ code e2393371376014 = 11189464398222 := by decide
theorem cert_e2393371376014 : check e2393371376014 [[],[.left],[]] .chain = true := by decide
def e2393371376070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2393371376070 : Closed e2393371376070 ∧ code e2393371376070 = 11189464398278 := by decide
theorem cert_e2393371376070 : check e2393371376070 [[],[.left],[]] .chain = true := by decide
def e2393371376094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 3)))))))))
theorem wire_e2393371376094 : Closed e2393371376094 ∧ code e2393371376094 = 11189464398302 := by decide
theorem cert_e2393371376094 : check e2393371376094 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371376110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393371376110 : Closed e2393371376110 ∧ code e2393371376110 = 11189464398318 := by decide
theorem cert_e2393371376110 : check e2393371376110 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371376118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 1)))))))))
theorem wire_e2393371376118 : Closed e2393371376118 ∧ code e2393371376118 = 11189464398326 := by decide
theorem cert_e2393371376118 : check e2393371376118 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371465390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2393371465390 : Closed e2393371465390 ∧ code e2393371465390 = 11189464487598 := by decide
theorem cert_e2393371465390 : check e2393371465390 [[],[.left],[]] .chain = true := by decide
def e2393371465402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2393371465402 : Closed e2393371465402 ∧ code e2393371465402 = 11189464487610 := by decide
theorem cert_e2393371465402 : check e2393371465402 [[],[.left],[]] .chain = true := by decide
def e2393371465450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2393371465450 : Closed e2393371465450 ∧ code e2393371465450 = 11189464487658 := by decide
theorem cert_e2393371465450 : check e2393371465450 [[],[.left],[]] .chain = true := by decide
def e2393371465642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2393371465642 : Closed e2393371465642 ∧ code e2393371465642 = 11189464487850 := by decide
theorem cert_e2393371465642 : check e2393371465642 [[],[.left],[]] .chain = true := by decide
def e2393371465950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2393371465950 : Closed e2393371465950 ∧ code e2393371465950 = 11189464488158 := by decide
theorem cert_e2393371465950 : check e2393371465950 [[],[.left],[]] .chain = true := by decide
def e2393371465966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2393371465966 : Closed e2393371465966 ∧ code e2393371465966 = 11189464488174 := by decide
theorem cert_e2393371465966 : check e2393371465966 [[],[.left],[]] .chain = true := by decide
def e2393371465974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2393371465974 : Closed e2393371465974 ∧ code e2393371465974 = 11189464488182 := by decide
theorem cert_e2393371465974 : check e2393371465974 [[],[.left],[]] .chain = true := by decide
def e2393371465978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2393371465978 : Closed e2393371465978 ∧ code e2393371465978 = 11189464488186 := by decide
theorem cert_e2393371465978 : check e2393371465978 [[],[.left],[]] .chain = true := by decide
def e2393371466158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2393371466158 : Closed e2393371466158 ∧ code e2393371466158 = 11189464488366 := by decide
theorem cert_e2393371466158 : check e2393371466158 [[],[.left],[]] .chain = true := by decide
def e2393371466170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2393371466170 : Closed e2393371466170 ∧ code e2393371466170 = 11189464488378 := by decide
theorem cert_e2393371466170 : check e2393371466170 [[],[.left],[]] .chain = true := by decide
def e2393371466218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2393371466218 : Closed e2393371466218 ∧ code e2393371466218 = 11189464488426 := by decide
theorem cert_e2393371466218 : check e2393371466218 [[],[.left],[]] .chain = true := by decide
def e2393371466302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2393371466302 : Closed e2393371466302 ∧ code e2393371466302 = 11189464488510 := by decide
theorem cert_e2393371466302 : check e2393371466302 [[],[.left],[]] .chain = true := by decide
def e2393371466350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393371466350 : Closed e2393371466350 ∧ code e2393371466350 = 11189464488558 := by decide
theorem cert_e2393371466350 : check e2393371466350 [[],[.left],[]] .chain = true := by decide
def e2393371466362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393371466362 : Closed e2393371466362 ∧ code e2393371466362 = 11189464488570 := by decide
theorem cert_e2393371466362 : check e2393371466362 [[],[.left],[]] .chain = true := by decide
def e2393371466526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2393371466526 : Closed e2393371466526 ∧ code e2393371466526 = 11189464488734 := by decide
theorem cert_e2393371466526 : check e2393371466526 [[],[.left],[]] .chain = true := by decide
def e2393371466638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2393371466638 : Closed e2393371466638 ∧ code e2393371466638 = 11189464488846 := by decide
theorem cert_e2393371466638 : check e2393371466638 [[],[.left],[]] .chain = true := by decide
def e2393371466650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371466650 : Closed e2393371466650 ∧ code e2393371466650 = 11189464488858 := by decide
theorem cert_e2393371466650 : check e2393371466650 [[],[.left],[]] .chain = true := by decide
def e2393371466694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2393371466694 : Closed e2393371466694 ∧ code e2393371466694 = 11189464488902 := by decide
theorem cert_e2393371466694 : check e2393371466694 [[],[.left],[]] .chain = true := by decide
def e2393371466718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 3))))))))
theorem wire_e2393371466718 : Closed e2393371466718 ∧ code e2393371466718 = 11189464488926 := by decide
theorem cert_e2393371466718 : check e2393371466718 [[],[.left],[]] .sourceHead = true := by decide
def e2393371466862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2393371466862 : Closed e2393371466862 ∧ code e2393371466862 = 11189464489070 := by decide
theorem cert_e2393371466862 : check e2393371466862 [[],[.left],[]] .chain = true := by decide
def e2393371466874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2393371466874 : Closed e2393371466874 ∧ code e2393371466874 = 11189464489082 := by decide
theorem cert_e2393371466874 : check e2393371466874 [[],[.left],[]] .chain = true := by decide
def e2393371467038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2393371467038 : Closed e2393371467038 ∧ code e2393371467038 = 11189464489246 := by decide
theorem cert_e2393371467038 : check e2393371467038 [[],[.left],[]] .chain = true := by decide
def e2393371467206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2393371467206 : Closed e2393371467206 ∧ code e2393371467206 = 11189464489414 := by decide
theorem cert_e2393371467206 : check e2393371467206 [[],[.left],[]] .chain = true := by decide
def e2393371467230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2393371467230 : Closed e2393371467230 ∧ code e2393371467230 = 11189464489438 := by decide
theorem cert_e2393371467230 : check e2393371467230 [[],[.left],[]] .sourceHead = true := by decide
def e2393371467246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2393371467246 : Closed e2393371467246 ∧ code e2393371467246 = 11189464489454 := by decide
theorem cert_e2393371467246 : check e2393371467246 [[],[.left],[]] .sourceHead = true := by decide
def e2393371467318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2393371467318 : Closed e2393371467318 ∧ code e2393371467318 = 11189464489526 := by decide
theorem cert_e2393371467318 : check e2393371467318 [[],[.left],[]] .chain = true := by decide
def e2393371467322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2393371467322 : Closed e2393371467322 ∧ code e2393371467322 = 11189464489530 := by decide
theorem cert_e2393371467322 : check e2393371467322 [[],[.left],[]] .chain = true := by decide
def e2393371467370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2393371467370 : Closed e2393371467370 ∧ code e2393371467370 = 11189464489578 := by decide
theorem cert_e2393371467370 : check e2393371467370 [[],[.left],[]] .chain = true := by decide
def e2393371467406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2393371467406 : Closed e2393371467406 ∧ code e2393371467406 = 11189464489614 := by decide
theorem cert_e2393371467406 : check e2393371467406 [[],[.left],[]] .chain = true := by decide
def e2393371467418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371467418 : Closed e2393371467418 ∧ code e2393371467418 = 11189464489626 := by decide
theorem cert_e2393371467418 : check e2393371467418 [[],[.left],[]] .chain = true := by decide
def e2393371467462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2393371467462 : Closed e2393371467462 ∧ code e2393371467462 = 11189464489670 := by decide
theorem cert_e2393371467462 : check e2393371467462 [[],[.left],[]] .chain = true := by decide
def e2393371467486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2393371467486 : Closed e2393371467486 ∧ code e2393371467486 = 11189464489694 := by decide
theorem cert_e2393371467486 : check e2393371467486 [[],[.left],[]] .sourceHead = true := by decide
def e2393371467510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2393371467510 : Closed e2393371467510 ∧ code e2393371467510 = 11189464489718 := by decide
theorem cert_e2393371467510 : check e2393371467510 [[],[.left],[]] .sourceHead = true := by decide
def e2393371467546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2393371467546 : Closed e2393371467546 ∧ code e2393371467546 = 11189464489754 := by decide
theorem cert_e2393371467546 : check e2393371467546 [[],[.left],[]] .chain = true := by decide
def e2393371467590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2393371467590 : Closed e2393371467590 ∧ code e2393371467590 = 11189464489798 := by decide
theorem cert_e2393371467590 : check e2393371467590 [[],[.left],[]] .chain = true := by decide
def e2393371467614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 3))))))))
theorem wire_e2393371467614 : Closed e2393371467614 ∧ code e2393371467614 = 11189464489822 := by decide
theorem cert_e2393371467614 : check e2393371467614 [[],[.left],[]] .sourceHead = true := by decide
def e2393371467630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2393371467630 : Closed e2393371467630 ∧ code e2393371467630 = 11189464489838 := by decide
theorem cert_e2393371467630 : check e2393371467630 [[],[.left],[]] .sourceHead = true := by decide
def e2393371467638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2393371467638 : Closed e2393371467638 ∧ code e2393371467638 = 11189464489846 := by decide
theorem cert_e2393371467638 : check e2393371467638 [[],[.left],[]] .sourceHead = true := by decide
def e2393371467642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 0))))))))
theorem wire_e2393371467642 : Closed e2393371467642 ∧ code e2393371467642 = 11189464489850 := by decide
theorem cert_e2393371467642 : check e2393371467642 [[],[.left],[]] .sourceHead = true := by decide
def e2393371468254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2393371468254 : Closed e2393371468254 ∧ code e2393371468254 = 11189464490462 := by decide
theorem cert_e2393371468254 : check e2393371468254 [[],[.left],[]] .chain = true := by decide
def e2393371468278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2393371468278 : Closed e2393371468278 ∧ code e2393371468278 = 11189464490486 := by decide
theorem cert_e2393371468278 : check e2393371468278 [[],[.left],[]] .chain = true := by decide
def e2393371469230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2393371469230 : Closed e2393371469230 ∧ code e2393371469230 = 11189464491438 := by decide
theorem cert_e2393371469230 : check e2393371469230 [[],[.left],[]] .chain = true := by decide
def e2393371469242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2393371469242 : Closed e2393371469242 ∧ code e2393371469242 = 11189464491450 := by decide
theorem cert_e2393371469242 : check e2393371469242 [[],[.left],[]] .chain = true := by decide
def e2393371469290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2393371469290 : Closed e2393371469290 ∧ code e2393371469290 = 11189464491498 := by decide
theorem cert_e2393371469290 : check e2393371469290 [[],[.left],[]] .chain = true := by decide
def e2393371469374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2393371469374 : Closed e2393371469374 ∧ code e2393371469374 = 11189464491582 := by decide
theorem cert_e2393371469374 : check e2393371469374 [[],[.left],[]] .chain = true := by decide
def e2393371469422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393371469422 : Closed e2393371469422 ∧ code e2393371469422 = 11189464491630 := by decide
theorem cert_e2393371469422 : check e2393371469422 [[],[.left],[]] .chain = true := by decide
def e2393371469434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393371469434 : Closed e2393371469434 ∧ code e2393371469434 = 11189464491642 := by decide
theorem cert_e2393371469434 : check e2393371469434 [[],[.left],[]] .chain = true := by decide
def e2393371469598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2393371469598 : Closed e2393371469598 ∧ code e2393371469598 = 11189464491806 := by decide
theorem cert_e2393371469598 : check e2393371469598 [[],[.left],[]] .chain = true := by decide
def e2393371469710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2393371469710 : Closed e2393371469710 ∧ code e2393371469710 = 11189464491918 := by decide
theorem cert_e2393371469710 : check e2393371469710 [[],[.left],[]] .chain = true := by decide
def e2393371469722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393371469722 : Closed e2393371469722 ∧ code e2393371469722 = 11189464491930 := by decide
theorem cert_e2393371469722 : check e2393371469722 [[],[.left],[]] .chain = true := by decide
def e2393371469766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2393371469766 : Closed e2393371469766 ∧ code e2393371469766 = 11189464491974 := by decide
theorem cert_e2393371469766 : check e2393371469766 [[],[.left],[]] .chain = true := by decide
def e2393371469790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 3)))))))))
theorem wire_e2393371469790 : Closed e2393371469790 ∧ code e2393371469790 = 11189464491998 := by decide
theorem cert_e2393371469790 : check e2393371469790 [[],[.left],[]] .sourceHead = true := by decide
def e2393371472670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2393371472670 : Closed e2393371472670 ∧ code e2393371472670 = 11189464494878 := by decide
theorem cert_e2393371472670 : check e2393371472670 [[],[.left],[]] .chain = true := by decide
def e2393371472838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2393371472838 : Closed e2393371472838 ∧ code e2393371472838 = 11189464495046 := by decide
theorem cert_e2393371472838 : check e2393371472838 [[],[.left],[]] .chain = true := by decide
def e2393371472862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2393371472862 : Closed e2393371472862 ∧ code e2393371472862 = 11189464495070 := by decide
theorem cert_e2393371472862 : check e2393371472862 [[],[.left],[]] .sourceHead = true := by decide
def e2393371472878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2393371472878 : Closed e2393371472878 ∧ code e2393371472878 = 11189464495086 := by decide
theorem cert_e2393371472878 : check e2393371472878 [[],[.left],[]] .sourceHead = true := by decide
def e2393371474038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2393371474038 : Closed e2393371474038 ∧ code e2393371474038 = 11189464496246 := by decide
theorem cert_e2393371474038 : check e2393371474038 [[],[.left],[]] .chain = true := by decide
def e2393371474282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2393371474282 : Closed e2393371474282 ∧ code e2393371474282 = 11189464496490 := by decide
theorem cert_e2393371474282 : check e2393371474282 [[],[.left],[]] .chain = true := by decide
def e2393371474318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2393371474318 : Closed e2393371474318 ∧ code e2393371474318 = 11189464496526 := by decide
theorem cert_e2393371474318 : check e2393371474318 [[],[.left],[]] .chain = true := by decide
def e2393371474330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393371474330 : Closed e2393371474330 ∧ code e2393371474330 = 11189464496538 := by decide
theorem cert_e2393371474330 : check e2393371474330 [[],[.left],[]] .chain = true := by decide
def e2393371474374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2393371474374 : Closed e2393371474374 ∧ code e2393371474374 = 11189464496582 := by decide
theorem cert_e2393371474374 : check e2393371474374 [[],[.left],[]] .chain = true := by decide
def e2393371474398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2393371474398 : Closed e2393371474398 ∧ code e2393371474398 = 11189464496606 := by decide
theorem cert_e2393371474398 : check e2393371474398 [[],[.left],[]] .sourceHead = true := by decide
def e2393371474422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2393371474422 : Closed e2393371474422 ∧ code e2393371474422 = 11189464496630 := by decide
theorem cert_e2393371474422 : check e2393371474422 [[],[.left],[]] .sourceHead = true := by decide
def e2393371475142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2393371475142 : Closed e2393371475142 ∧ code e2393371475142 = 11189464497350 := by decide
theorem cert_e2393371475142 : check e2393371475142 [[],[.left],[]] .chain = true := by decide
def e2393371475166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 3)))))))))
theorem wire_e2393371475166 : Closed e2393371475166 ∧ code e2393371475166 = 11189464497374 := by decide
theorem cert_e2393371475166 : check e2393371475166 [[],[.left],[]] .sourceHead = true := by decide
def e2393371475182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393371475182 : Closed e2393371475182 ∧ code e2393371475182 = 11189464497390 := by decide
theorem cert_e2393371475182 : check e2393371475182 [[],[.left],[]] .sourceHead = true := by decide
def e2393371475190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393371475190 : Closed e2393371475190 ∧ code e2393371475190 = 11189464497398 := by decide
theorem cert_e2393371475190 : check e2393371475190 [[],[.left],[]] .sourceHead = true := by decide
def e2393371475194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 0)))))))))
theorem wire_e2393371475194 : Closed e2393371475194 ∧ code e2393371475194 = 11189464497402 := by decide
theorem cert_e2393371475194 : check e2393371475194 [[],[.left],[]] .sourceHead = true := by decide
def e2393371519830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2393371519830 : Closed e2393371519830 ∧ code e2393371519830 = 11189464542038 := by decide
theorem cert_e2393371519830 : check e2393371519830 [[],[.left],[]] .chain = true := by decide
def e2393371519834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2393371519834 : Closed e2393371519834 ∧ code e2393371519834 = 11189464542042 := by decide
theorem cert_e2393371519834 : check e2393371519834 [[],[.left],[]] .chain = true := by decide
def e2393371519850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2393371519850 : Closed e2393371519850 ∧ code e2393371519850 = 11189464542058 := by decide
theorem cert_e2393371519850 : check e2393371519850 [[],[.left],[]] .chain = true := by decide
def e2393371519914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2393371519914 : Closed e2393371519914 ∧ code e2393371519914 = 11189464542122 := by decide
theorem cert_e2393371519914 : check e2393371519914 [[],[.left],[]] .chain = true := by decide
def e2393371520118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2393371520118 : Closed e2393371520118 ∧ code e2393371520118 = 11189464542326 := by decide
theorem cert_e2393371520118 : check e2393371520118 [[],[.left],[]] .chain = true := by decide
def e2393371520214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2393371520214 : Closed e2393371520214 ∧ code e2393371520214 = 11189464542422 := by decide
theorem cert_e2393371520214 : check e2393371520214 [[],[.left],[]] .chain = true := by decide
def e2393371520218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2393371520218 : Closed e2393371520218 ∧ code e2393371520218 = 11189464542426 := by decide
theorem cert_e2393371520218 : check e2393371520218 [[],[.left],[]] .chain = true := by decide
def e2393371520234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2393371520234 : Closed e2393371520234 ∧ code e2393371520234 = 11189464542442 := by decide
theorem cert_e2393371520234 : check e2393371520234 [[],[.left],[]] .chain = true := by decide
def e2393371520310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393371520310 : Closed e2393371520310 ∧ code e2393371520310 = 11189464542518 := by decide
theorem cert_e2393371520310 : check e2393371520310 [[],[.left],[]] .chain = true := by decide
def e2393371520314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393371520314 : Closed e2393371520314 ∧ code e2393371520314 = 11189464542522 := by decide
theorem cert_e2393371520314 : check e2393371520314 [[],[.left],[]] .chain = true := by decide
def e2393371520398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2393371520398 : Closed e2393371520398 ∧ code e2393371520398 = 11189464542606 := by decide
theorem cert_e2393371520398 : check e2393371520398 [[],[.left],[]] .chain = true := by decide
def e2393371520410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371520410 : Closed e2393371520410 ∧ code e2393371520410 = 11189464542618 := by decide
theorem cert_e2393371520410 : check e2393371520410 [[],[.left],[]] .chain = true := by decide
def e2393371520478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2393371520478 : Closed e2393371520478 ∧ code e2393371520478 = 11189464542686 := by decide
theorem cert_e2393371520478 : check e2393371520478 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371520494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2393371520494 : Closed e2393371520494 ∧ code e2393371520494 = 11189464542702 := by decide
theorem cert_e2393371520494 : check e2393371520494 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371520566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2393371520566 : Closed e2393371520566 ∧ code e2393371520566 = 11189464542774 := by decide
theorem cert_e2393371520566 : check e2393371520566 [[],[.left],[]] .chain = true := by decide
def e2393371520570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2393371520570 : Closed e2393371520570 ∧ code e2393371520570 = 11189464542778 := by decide
theorem cert_e2393371520570 : check e2393371520570 [[],[.left],[]] .chain = true := by decide
def e2393371520618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2393371520618 : Closed e2393371520618 ∧ code e2393371520618 = 11189464542826 := by decide
theorem cert_e2393371520618 : check e2393371520618 [[],[.left],[]] .chain = true := by decide
def e2393371520654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2393371520654 : Closed e2393371520654 ∧ code e2393371520654 = 11189464542862 := by decide
theorem cert_e2393371520654 : check e2393371520654 [[],[.left],[]] .chain = true := by decide
def e2393371520666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371520666 : Closed e2393371520666 ∧ code e2393371520666 = 11189464542874 := by decide
theorem cert_e2393371520666 : check e2393371520666 [[],[.left],[]] .chain = true := by decide
def e2393371520710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2393371520710 : Closed e2393371520710 ∧ code e2393371520710 = 11189464542918 := by decide
theorem cert_e2393371520710 : check e2393371520710 [[],[.left],[]] .chain = true := by decide
def e2393371520734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2393371520734 : Closed e2393371520734 ∧ code e2393371520734 = 11189464542942 := by decide
theorem cert_e2393371520734 : check e2393371520734 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371520758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2393371520758 : Closed e2393371520758 ∧ code e2393371520758 = 11189464542966 := by decide
theorem cert_e2393371520758 : check e2393371520758 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371520862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2393371520862 : Closed e2393371520862 ∧ code e2393371520862 = 11189464543070 := by decide
theorem cert_e2393371520862 : check e2393371520862 [[],[.left],[],[.under,.under]] .three = true := by decide
end Blc.Floor43
