import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411629927802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 0))))))
theorem wire_e2411629927802 : Closed e2411629927802 ∧ code e2411629927802 = 11207722950010 := by decide
theorem cert_e2411629927802 : check e2411629927802 [[],[]] .chain = true := by decide
def e2411629927894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e2411629927894 : Closed e2411629927894 ∧ code e2411629927894 = 11207722950102 := by decide
theorem cert_e2411629927894 : check e2411629927894 [[],[]] .smaller = true := by decide
def e2411629927914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 0))))))
theorem wire_e2411629927914 : Closed e2411629927914 ∧ code e2411629927914 = 11207722950122 := by decide
theorem cert_e2411629927914 : check e2411629927914 [[],[]] .chain = true := by decide
def e2411629928110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e2411629928110 : Closed e2411629928110 ∧ code e2411629928110 = 11207722950318 := by decide
theorem cert_e2411629928110 : check e2411629928110 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2411629928118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e2411629928118 : Closed e2411629928118 ∧ code e2411629928118 = 11207722950326 := by decide
theorem cert_e2411629928118 : check e2411629928118 [[],[]] .smaller = true := by decide
def e2411629928150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e2411629928150 : Closed e2411629928150 ∧ code e2411629928150 = 11207722950358 := by decide
theorem cert_e2411629928150 : check e2411629928150 [[],[]] .smaller = true := by decide
def e2411629928278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e2411629928278 : Closed e2411629928278 ∧ code e2411629928278 = 11207722950486 := by decide
theorem cert_e2411629928278 : check e2411629928278 [[],[]] .chain = true := by decide
def e2411629928282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e2411629928282 : Closed e2411629928282 ∧ code e2411629928282 = 11207722950490 := by decide
theorem cert_e2411629928282 : check e2411629928282 [[],[]] .chain = true := by decide
def e2411629928298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e2411629928298 : Closed e2411629928298 ∧ code e2411629928298 = 11207722950506 := by decide
theorem cert_e2411629928298 : check e2411629928298 [[],[]] .chain = true := by decide
def e2411629930222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e2411629930222 : Closed e2411629930222 ∧ code e2411629930222 = 11207722952430 := by decide
theorem cert_e2411629930222 : check e2411629930222 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2411629930230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e2411629930230 : Closed e2411629930230 ∧ code e2411629930230 = 11207722952438 := by decide
theorem cert_e2411629930230 : check e2411629930230 [[],[]] .chain = true := by decide
def e2411629930358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e2411629930358 : Closed e2411629930358 ∧ code e2411629930358 = 11207722952566 := by decide
theorem cert_e2411629930358 : check e2411629930358 [[],[]] .smaller = true := by decide
def e2411629930362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 0))))))
theorem wire_e2411629930362 : Closed e2411629930362 ∧ code e2411629930362 = 11207722952570 := by decide
theorem cert_e2411629930362 : check e2411629930362 [[],[]] .chain = true := by decide
def e2411629930414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e2411629930414 : Closed e2411629930414 ∧ code e2411629930414 = 11207722952622 := by decide
theorem cert_e2411629930414 : checkPay e2411629930414 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e2411629930422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e2411629930422 : Closed e2411629930422 ∧ code e2411629930422 = 11207722952630 := by decide
theorem cert_e2411629930422 : check e2411629930422 [[],[]] .smaller = true := by decide
def e2411629930454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e2411629930454 : Closed e2411629930454 ∧ code e2411629930454 = 11207722952662 := by decide
theorem cert_e2411629930454 : check e2411629930454 [[],[]] .chain = true := by decide
def e2411629930458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 0))))))
theorem wire_e2411629930458 : Closed e2411629930458 ∧ code e2411629930458 = 11207722952666 := by decide
theorem cert_e2411629930458 : check e2411629930458 [[],[]] .chain = true := by decide
def e2411629931758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629931758 : Closed e2411629931758 ∧ code e2411629931758 = 11207722953966 := by decide
theorem cert_e2411629931758 : check e2411629931758 [[],[]] .chain = true := by decide
def e2411629931766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629931766 : Closed e2411629931766 ∧ code e2411629931766 = 11207722953974 := by decide
theorem cert_e2411629931766 : check e2411629931766 [[],[]] .chain = true := by decide
def e2411629932142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629932142 : Closed e2411629932142 ∧ code e2411629932142 = 11207722954350 := by decide
theorem cert_e2411629932142 : check e2411629932142 [[],[]] .chain = true := by decide
def e2411629932154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629932154 : Closed e2411629932154 ∧ code e2411629932154 = 11207722954362 := by decide
theorem cert_e2411629932154 : check e2411629932154 [[],[]] .chain = true := by decide
def e2411629932342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629932342 : Closed e2411629932342 ∧ code e2411629932342 = 11207722954550 := by decide
theorem cert_e2411629932342 : check e2411629932342 [[],[]] .chain = true := by decide
def e2411629932346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629932346 : Closed e2411629932346 ∧ code e2411629932346 = 11207722954554 := by decide
theorem cert_e2411629932346 : check e2411629932346 [[],[]] .chain = true := by decide
def e2411629933038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 2))))))
theorem wire_e2411629933038 : Closed e2411629933038 ∧ code e2411629933038 = 11207722955246 := by decide
theorem cert_e2411629933038 : check e2411629933038 [[],[]] .chain = true := by decide
def e2411629933046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 1))))))
theorem wire_e2411629933046 : Closed e2411629933046 ∧ code e2411629933046 = 11207722955254 := by decide
theorem cert_e2411629933046 : check e2411629933046 [[],[]] .chain = true := by decide
def e2411629933430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e2411629933430 : Closed e2411629933430 ∧ code e2411629933430 = 11207722955638 := by decide
theorem cert_e2411629933430 : check e2411629933430 [[],[]] .smaller = true := by decide
def e2411629933434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e2411629933434 : Closed e2411629933434 ∧ code e2411629933434 = 11207722955642 := by decide
theorem cert_e2411629933434 : check e2411629933434 [[],[]] .chain = true := by decide
def e2411629933526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e2411629933526 : Closed e2411629933526 ∧ code e2411629933526 = 11207722955734 := by decide
theorem cert_e2411629933526 : check e2411629933526 [[],[]] .smaller = true := by decide
def e2411629933546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e2411629933546 : Closed e2411629933546 ∧ code e2411629933546 = 11207722955754 := by decide
theorem cert_e2411629933546 : check e2411629933546 [[],[]] .chain = true := by decide
def e2411629933806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629933806 : Closed e2411629933806 ∧ code e2411629933806 = 11207722956014 := by decide
theorem cert_e2411629933806 : check e2411629933806 [[],[]] .chain = true := by decide
def e2411629933814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629933814 : Closed e2411629933814 ∧ code e2411629933814 = 11207722956022 := by decide
theorem cert_e2411629933814 : check e2411629933814 [[],[]] .chain = true := by decide
def e2411629934366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2411629934366 : Closed e2411629934366 ∧ code e2411629934366 = 11207722956574 := by decide
theorem cert_e2411629934366 : check e2411629934366 [[],[]] .chain = true := by decide
def e2411629934478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2411629934478 : Closed e2411629934478 ∧ code e2411629934478 = 11207722956686 := by decide
theorem cert_e2411629934478 : check e2411629934478 [[],[]] .chain = true := by decide
def e2411629934830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 2))))))
theorem wire_e2411629934830 : Closed e2411629934830 ∧ code e2411629934830 = 11207722957038 := by decide
theorem cert_e2411629934830 : check e2411629934830 [[],[]] .chain = true := by decide
def e2411629934842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))) (.var 0))))))
theorem wire_e2411629934842 : Closed e2411629934842 ∧ code e2411629934842 = 11207722957050 := by decide
theorem cert_e2411629934842 : check e2411629934842 [[],[]] .chain = true := by decide
def e2411629935022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2411629935022 : Closed e2411629935022 ∧ code e2411629935022 = 11207722957230 := by decide
theorem cert_e2411629935022 : check e2411629935022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2411629935030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e2411629935030 : Closed e2411629935030 ∧ code e2411629935030 = 11207722957238 := by decide
theorem cert_e2411629935030 : check e2411629935030 [[],[]] .smaller = true := by decide
def e2411629935062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e2411629935062 : Closed e2411629935062 ∧ code e2411629935062 = 11207722957270 := by decide
theorem cert_e2411629935062 : check e2411629935062 [[],[]] .smaller = true := by decide
def e2411629935214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629935214 : Closed e2411629935214 ∧ code e2411629935214 = 11207722957422 := by decide
theorem cert_e2411629935214 : check e2411629935214 [[],[]] .chain = true := by decide
def e2411629935226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629935226 : Closed e2411629935226 ∧ code e2411629935226 = 11207722957434 := by decide
theorem cert_e2411629935226 : check e2411629935226 [[],[]] .chain = true := by decide
def e2411629935390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2411629935390 : Closed e2411629935390 ∧ code e2411629935390 = 11207722957598 := by decide
theorem cert_e2411629935390 : check e2411629935390 [[],[]] .chain = true := by decide
def e2411629935558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2411629935558 : Closed e2411629935558 ∧ code e2411629935558 = 11207722957766 := by decide
theorem cert_e2411629935558 : check e2411629935558 [[],[]] .chain = true := by decide
def e2411629935734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 1))))))
theorem wire_e2411629935734 : Closed e2411629935734 ∧ code e2411629935734 = 11207722957942 := by decide
theorem cert_e2411629935734 : check e2411629935734 [[],[]] .chain = true := by decide
def e2411629935738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))) (.var 0))))))
theorem wire_e2411629935738 : Closed e2411629935738 ∧ code e2411629935738 = 11207722957946 := by decide
theorem cert_e2411629935738 : check e2411629935738 [[],[]] .chain = true := by decide
def e2411629935830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2411629935830 : Closed e2411629935830 ∧ code e2411629935830 = 11207722958038 := by decide
theorem cert_e2411629935830 : check e2411629935830 [[],[]] .chain = true := by decide
def e2411629935834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2411629935834 : Closed e2411629935834 ∧ code e2411629935834 = 11207722958042 := by decide
theorem cert_e2411629935834 : check e2411629935834 [[],[]] .chain = true := by decide
def e2411629935850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2411629935850 : Closed e2411629935850 ∧ code e2411629935850 = 11207722958058 := by decide
theorem cert_e2411629935850 : check e2411629935850 [[],[]] .chain = true := by decide
def e2411629935926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629935926 : Closed e2411629935926 ∧ code e2411629935926 = 11207722958134 := by decide
theorem cert_e2411629935926 : check e2411629935926 [[],[]] .chain = true := by decide
def e2411629935930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629935930 : Closed e2411629935930 ∧ code e2411629935930 = 11207722958138 := by decide
theorem cert_e2411629935930 : check e2411629935930 [[],[]] .chain = true := by decide
def e2411629936014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2411629936014 : Closed e2411629936014 ∧ code e2411629936014 = 11207722958222 := by decide
theorem cert_e2411629936014 : check e2411629936014 [[],[]] .chain = true := by decide
def e2411629936070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2411629936070 : Closed e2411629936070 ∧ code e2411629936070 = 11207722958278 := by decide
theorem cert_e2411629936070 : check e2411629936070 [[],[]] .chain = true := by decide
def e2411629942638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2411629942638 : Closed e2411629942638 ∧ code e2411629942638 = 11207722964846 := by decide
theorem cert_e2411629942638 : check e2411629942638 [[],[]] .chain = true := by decide
def e2411629942646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2411629942646 : Closed e2411629942646 ∧ code e2411629942646 = 11207722964854 := by decide
theorem cert_e2411629942646 : check e2411629942646 [[],[]] .chain = true := by decide
def e2411629942710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2411629942710 : Closed e2411629942710 ∧ code e2411629942710 = 11207722964918 := by decide
theorem cert_e2411629942710 : check e2411629942710 [[],[]] .chain = true := by decide
def e2411629944046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2411629944046 : Closed e2411629944046 ∧ code e2411629944046 = 11207722966254 := by decide
theorem cert_e2411629944046 : check e2411629944046 [[],[]] .chain = true := by decide
def e2411629944054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2411629944054 : Closed e2411629944054 ∧ code e2411629944054 = 11207722966262 := by decide
theorem cert_e2411629944054 : check e2411629944054 [[],[]] .chain = true := by decide
def e2411629944438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2411629944438 : Closed e2411629944438 ∧ code e2411629944438 = 11207722966646 := by decide
theorem cert_e2411629944438 : check e2411629944438 [[],[]] .chain = true := by decide
def e2411629954014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2411629954014 : Closed e2411629954014 ∧ code e2411629954014 = 11207722976222 := by decide
theorem cert_e2411629954014 : check e2411629954014 [[],[]] .chain = true := by decide
def e2411629954030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2411629954030 : Closed e2411629954030 ∧ code e2411629954030 = 11207722976238 := by decide
theorem cert_e2411629954030 : check e2411629954030 [[],[]] .chain = true := by decide
def e2411629955950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2411629955950 : Closed e2411629955950 ∧ code e2411629955950 = 11207722978158 := by decide
theorem cert_e2411629955950 : check e2411629955950 [[],[]] .chain = true := by decide
def e2411629955958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2411629955958 : Closed e2411629955958 ∧ code e2411629955958 = 11207722978166 := by decide
theorem cert_e2411629955958 : check e2411629955958 [[],[]] .chain = true := by decide
def e2411629956014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2411629956014 : Closed e2411629956014 ∧ code e2411629956014 = 11207722978222 := by decide
theorem cert_e2411629956014 : check e2411629956014 [[],[]] .chain = true := by decide
def e2411629956026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2411629956026 : Closed e2411629956026 ∧ code e2411629956026 = 11207722978234 := by decide
theorem cert_e2411629956026 : check e2411629956026 [[],[]] .chain = true := by decide
def e2411629956054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2411629956054 : Closed e2411629956054 ∧ code e2411629956054 = 11207722978262 := by decide
theorem cert_e2411629956054 : check e2411629956054 [[],[]] .chain = true := by decide
def e2411629956058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2411629956058 : Closed e2411629956058 ∧ code e2411629956058 = 11207722978266 := by decide
theorem cert_e2411629956058 : check e2411629956058 [[],[]] .chain = true := by decide
def e2411629956334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2411629956334 : Closed e2411629956334 ∧ code e2411629956334 = 11207722978542 := by decide
theorem cert_e2411629956334 : check e2411629956334 [[],[]] .chain = true := by decide
def e2411629956342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2411629956342 : Closed e2411629956342 ∧ code e2411629956342 = 11207722978550 := by decide
theorem cert_e2411629956342 : check e2411629956342 [[],[]] .chain = true := by decide
def e2411629956718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2411629956718 : Closed e2411629956718 ∧ code e2411629956718 = 11207722978926 := by decide
theorem cert_e2411629956718 : check e2411629956718 [[],[]] .chain = true := by decide
def e2411629956730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2411629956730 : Closed e2411629956730 ∧ code e2411629956730 = 11207722978938 := by decide
theorem cert_e2411629956730 : check e2411629956730 [[],[]] .chain = true := by decide
def e2411629956918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2411629956918 : Closed e2411629956918 ∧ code e2411629956918 = 11207722979126 := by decide
theorem cert_e2411629956918 : check e2411629956918 [[],[]] .chain = true := by decide
def e2411629956922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2411629956922 : Closed e2411629956922 ∧ code e2411629956922 = 11207722979130 := by decide
theorem cert_e2411629956922 : check e2411629956922 [[],[]] .chain = true := by decide
def e2411629961694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2411629961694 : Closed e2411629961694 ∧ code e2411629961694 = 11207722983902 := by decide
theorem cert_e2411629961694 : check e2411629961694 [[],[]] .chain = true := by decide
def e2411629961718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2411629961718 : Closed e2411629961718 ∧ code e2411629961718 = 11207722983926 := by decide
theorem cert_e2411629961718 : check e2411629961718 [[],[]] .chain = true := by decide
def e2411629962670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2411629962670 : Closed e2411629962670 ∧ code e2411629962670 = 11207722984878 := by decide
theorem cert_e2411629962670 : check e2411629962670 [[],[]] .chain = true := by decide
def e2411629962682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2411629962682 : Closed e2411629962682 ∧ code e2411629962682 = 11207722984890 := by decide
theorem cert_e2411629962682 : check e2411629962682 [[],[]] .chain = true := by decide
def e2411629962730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2411629962730 : Closed e2411629962730 ∧ code e2411629962730 = 11207722984938 := by decide
theorem cert_e2411629962730 : check e2411629962730 [[],[]] .chain = true := by decide
def e2411629962862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2411629962862 : Closed e2411629962862 ∧ code e2411629962862 = 11207722985070 := by decide
theorem cert_e2411629962862 : check e2411629962862 [[],[]] .chain = true := by decide
def e2411629962874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2411629962874 : Closed e2411629962874 ∧ code e2411629962874 = 11207722985082 := by decide
theorem cert_e2411629962874 : check e2411629962874 [[],[]] .chain = true := by decide
def e2411629963038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2411629963038 : Closed e2411629963038 ∧ code e2411629963038 = 11207722985246 := by decide
theorem cert_e2411629963038 : check e2411629963038 [[],[]] .chain = true := by decide
def e2411629963150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2411629963150 : Closed e2411629963150 ∧ code e2411629963150 = 11207722985358 := by decide
theorem cert_e2411629963150 : check e2411629963150 [[],[]] .chain = true := by decide
def e2411629963162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2411629963162 : Closed e2411629963162 ∧ code e2411629963162 = 11207722985370 := by decide
theorem cert_e2411629963162 : check e2411629963162 [[],[]] .chain = true := by decide
def e2411629965550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2411629965550 : Closed e2411629965550 ∧ code e2411629965550 = 11207722987758 := by decide
theorem cert_e2411629965550 : check e2411629965550 [[],[]] .chain = true := by decide
def e2411629965558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2411629965558 : Closed e2411629965558 ∧ code e2411629965558 = 11207722987766 := by decide
theorem cert_e2411629965558 : check e2411629965558 [[],[]] .chain = true := by decide
def e2411629966038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2411629966038 : Closed e2411629966038 ∧ code e2411629966038 = 11207722988246 := by decide
theorem cert_e2411629966038 : check e2411629966038 [[],[]] .chain = true := by decide
def e2411629966042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2411629966042 : Closed e2411629966042 ∧ code e2411629966042 = 11207722988250 := by decide
theorem cert_e2411629966042 : check e2411629966042 [[],[]] .chain = true := by decide
def e2411629966058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2411629966058 : Closed e2411629966058 ∧ code e2411629966058 = 11207722988266 := by decide
theorem cert_e2411629966058 : check e2411629966058 [[],[]] .chain = true := by decide
def e2411629966134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2411629966134 : Closed e2411629966134 ∧ code e2411629966134 = 11207722988342 := by decide
theorem cert_e2411629966134 : check e2411629966134 [[],[]] .chain = true := by decide
def e2411629966138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2411629966138 : Closed e2411629966138 ∧ code e2411629966138 = 11207722988346 := by decide
theorem cert_e2411629966138 : check e2411629966138 [[],[]] .chain = true := by decide
def e2411629966222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2411629966222 : Closed e2411629966222 ∧ code e2411629966222 = 11207722988430 := by decide
theorem cert_e2411629966222 : check e2411629966222 [[],[]] .chain = true := by decide
def e2411629966234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2411629966234 : Closed e2411629966234 ∧ code e2411629966234 = 11207722988442 := by decide
theorem cert_e2411629966234 : check e2411629966234 [[],[]] .chain = true := by decide
def e2411629994862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 2))))))
theorem wire_e2411629994862 : Closed e2411629994862 ∧ code e2411629994862 = 11207723017070 := by decide
theorem cert_e2411629994862 : check e2411629994862 [[],[]] .chain = true := by decide
def e2411629994870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 1))))))
theorem wire_e2411629994870 : Closed e2411629994870 ∧ code e2411629994870 = 11207723017078 := by decide
theorem cert_e2411629994870 : check e2411629994870 [[],[]] .chain = true := by decide
def e2411629994926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 2))))))
theorem wire_e2411629994926 : Closed e2411629994926 ∧ code e2411629994926 = 11207723017134 := by decide
theorem cert_e2411629994926 : check e2411629994926 [[],[]] .chain = true := by decide
def e2411629994938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 0))))))
theorem wire_e2411629994938 : Closed e2411629994938 ∧ code e2411629994938 = 11207723017146 := by decide
theorem cert_e2411629994938 : check e2411629994938 [[],[]] .chain = true := by decide
def e2411629994966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 1))))))
theorem wire_e2411629994966 : Closed e2411629994966 ∧ code e2411629994966 = 11207723017174 := by decide
theorem cert_e2411629994966 : check e2411629994966 [[],[]] .chain = true := by decide
def e2411629994970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 0))))))
theorem wire_e2411629994970 : Closed e2411629994970 ∧ code e2411629994970 = 11207723017178 := by decide
theorem cert_e2411629994970 : check e2411629994970 [[],[]] .chain = true := by decide
def e2411629996270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2411629996270 : Closed e2411629996270 ∧ code e2411629996270 = 11207723018478 := by decide
theorem cert_e2411629996270 : check e2411629996270 [[],[]] .chain = true := by decide
def e2411629996278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2411629996278 : Closed e2411629996278 ∧ code e2411629996278 = 11207723018486 := by decide
theorem cert_e2411629996278 : check e2411629996278 [[],[]] .chain = true := by decide
def e2411629996830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2411629996830 : Closed e2411629996830 ∧ code e2411629996830 = 11207723019038 := by decide
theorem cert_e2411629996830 : check e2411629996830 [[],[]] .chain = true := by decide
def e2411629996942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2411629996942 : Closed e2411629996942 ∧ code e2411629996942 = 11207723019150 := by decide
theorem cert_e2411629996942 : check e2411629996942 [[],[]] .chain = true := by decide
def e2411629997166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2411629997166 : Closed e2411629997166 ∧ code e2411629997166 = 11207723019374 := by decide
theorem cert_e2411629997166 : check e2411629997166 [[],[]] .chain = true := by decide
def e2411629997178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2411629997178 : Closed e2411629997178 ∧ code e2411629997178 = 11207723019386 := by decide
theorem cert_e2411629997178 : check e2411629997178 [[],[]] .chain = true := by decide
def e2411629997342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2411629997342 : Closed e2411629997342 ∧ code e2411629997342 = 11207723019550 := by decide
theorem cert_e2411629997342 : check e2411629997342 [[],[]] .chain = true := by decide
def e2411629997510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2411629997510 : Closed e2411629997510 ∧ code e2411629997510 = 11207723019718 := by decide
theorem cert_e2411629997510 : check e2411629997510 [[],[]] .chain = true := by decide
def e2411629997622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2411629997622 : Closed e2411629997622 ∧ code e2411629997622 = 11207723019830 := by decide
theorem cert_e2411629997622 : check e2411629997622 [[],[]] .chain = true := by decide
def e2411629997626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2411629997626 : Closed e2411629997626 ∧ code e2411629997626 = 11207723019834 := by decide
theorem cert_e2411629997626 : check e2411629997626 [[],[]] .chain = true := by decide
def e2411629997710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2411629997710 : Closed e2411629997710 ∧ code e2411629997710 = 11207723019918 := by decide
theorem cert_e2411629997710 : check e2411629997710 [[],[]] .chain = true := by decide
def e2411629997766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2411629997766 : Closed e2411629997766 ∧ code e2411629997766 = 11207723019974 := by decide
theorem cert_e2411629997766 : check e2411629997766 [[],[]] .chain = true := by decide
def e2411629998446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2411629998446 : Closed e2411629998446 ∧ code e2411629998446 = 11207723020654 := by decide
theorem cert_e2411629998446 : check e2411629998446 [[],[]] .chain = true := by decide
def e2411629998454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2411629998454 : Closed e2411629998454 ∧ code e2411629998454 = 11207723020662 := by decide
theorem cert_e2411629998454 : check e2411629998454 [[],[]] .chain = true := by decide
def e2411629998510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e2411629998510 : Closed e2411629998510 ∧ code e2411629998510 = 11207723020718 := by decide
theorem cert_e2411629998510 : check e2411629998510 [[],[]] .chain = true := by decide
def e2411629998522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e2411629998522 : Closed e2411629998522 ∧ code e2411629998522 = 11207723020730 := by decide
theorem cert_e2411629998522 : check e2411629998522 [[],[]] .chain = true := by decide
def e2411629998570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 0))))))
theorem wire_e2411629998570 : Closed e2411629998570 ∧ code e2411629998570 = 11207723020778 := by decide
theorem cert_e2411629998570 : check e2411629998570 [[],[]] .chain = true := by decide
def e2411629999214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2411629999214 : Closed e2411629999214 ∧ code e2411629999214 = 11207723021422 := by decide
theorem cert_e2411629999214 : check e2411629999214 [[],[]] .chain = true := by decide
def e2411629999226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2411629999226 : Closed e2411629999226 ∧ code e2411629999226 = 11207723021434 := by decide
theorem cert_e2411629999226 : check e2411629999226 [[],[]] .chain = true := by decide
def e2411629999390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2411629999390 : Closed e2411629999390 ∧ code e2411629999390 = 11207723021598 := by decide
theorem cert_e2411629999390 : check e2411629999390 [[],[]] .chain = true := by decide
def e2411629999558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2411629999558 : Closed e2411629999558 ∧ code e2411629999558 = 11207723021766 := by decide
theorem cert_e2411629999558 : check e2411629999558 [[],[]] .chain = true := by decide
def e2411629999662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2411629999662 : Closed e2411629999662 ∧ code e2411629999662 = 11207723021870 := by decide
theorem cert_e2411629999662 : check e2411629999662 [[],[]] .chain = true := by decide
def e2411629999842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2411629999842 : Closed e2411629999842 ∧ code e2411629999842 = 11207723022050 := by decide
theorem cert_e2411629999842 : check e2411629999842 [[],[]] .chain = true := by decide
def e2411629999854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e2411629999854 : Closed e2411629999854 ∧ code e2411629999854 = 11207723022062 := by decide
theorem cert_e2411629999854 : check e2411629999854 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411629999894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411629999894 : Closed e2411629999894 ∧ code e2411629999894 = 11207723022102 := by decide
theorem cert_e2411629999894 : check e2411629999894 [[],[]] .chain = true := by decide
def e2411629999898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411629999898 : Closed e2411629999898 ∧ code e2411629999898 = 11207723022106 := by decide
theorem cert_e2411629999898 : check e2411629999898 [[],[]] .chain = true := by decide
def e2411629999942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411629999942 : Closed e2411629999942 ∧ code e2411629999942 = 11207723022150 := by decide
theorem cert_e2411629999942 : check e2411629999942 [[],[]] .chain = true := by decide
def e2411629999970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411629999970 : Closed e2411629999970 ∧ code e2411629999970 = 11207723022178 := by decide
theorem cert_e2411629999970 : check e2411629999970 [[],[]] .chain = true := by decide
def e2411629999982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e2411629999982 : Closed e2411629999982 ∧ code e2411629999982 = 11207723022190 := by decide
theorem cert_e2411629999982 : check e2411629999982 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411629999990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e2411629999990 : Closed e2411629999990 ∧ code e2411629999990 = 11207723022198 := by decide
theorem cert_e2411629999990 : check e2411629999990 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630000310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 1))))))
theorem wire_e2411630000310 : Closed e2411630000310 ∧ code e2411630000310 = 11207723022518 := by decide
theorem cert_e2411630000310 : check e2411630000310 [[],[]] .chain = true := by decide
def e2411630000342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e2411630000342 : Closed e2411630000342 ∧ code e2411630000342 = 11207723022550 := by decide
theorem cert_e2411630000342 : check e2411630000342 [[],[]] .chain = true := by decide
def e2411630000346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e2411630000346 : Closed e2411630000346 ∧ code e2411630000346 = 11207723022554 := by decide
theorem cert_e2411630000346 : check e2411630000346 [[],[]] .chain = true := by decide
def e2411630000362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e2411630000362 : Closed e2411630000362 ∧ code e2411630000362 = 11207723022570 := by decide
theorem cert_e2411630000362 : check e2411630000362 [[],[]] .chain = true := by decide
def e2411630000694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2411630000694 : Closed e2411630000694 ∧ code e2411630000694 = 11207723022902 := by decide
theorem cert_e2411630000694 : check e2411630000694 [[],[]] .chain = true := by decide
def e2411630000698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2411630000698 : Closed e2411630000698 ∧ code e2411630000698 = 11207723022906 := by decide
theorem cert_e2411630000698 : check e2411630000698 [[],[]] .chain = true := by decide
def e2411630000782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2411630000782 : Closed e2411630000782 ∧ code e2411630000782 = 11207723022990 := by decide
theorem cert_e2411630000782 : check e2411630000782 [[],[]] .chain = true := by decide
def e2411630000838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2411630000838 : Closed e2411630000838 ∧ code e2411630000838 = 11207723023046 := by decide
theorem cert_e2411630000838 : check e2411630000838 [[],[]] .chain = true := by decide
def e2411630000918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411630000918 : Closed e2411630000918 ∧ code e2411630000918 = 11207723023126 := by decide
theorem cert_e2411630000918 : check e2411630000918 [[],[]] .chain = true := by decide
def e2411630000922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411630000922 : Closed e2411630000922 ∧ code e2411630000922 = 11207723023130 := by decide
theorem cert_e2411630000922 : check e2411630000922 [[],[]] .chain = true := by decide
def e2411630000966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411630000966 : Closed e2411630000966 ∧ code e2411630000966 = 11207723023174 := by decide
theorem cert_e2411630000966 : check e2411630000966 [[],[]] .chain = true := by decide
def e2411630000994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411630000994 : Closed e2411630000994 ∧ code e2411630000994 = 11207723023202 := by decide
theorem cert_e2411630000994 : check e2411630000994 [[],[]] .chain = true := by decide
def e2411630001006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2411630001006 : Closed e2411630001006 ∧ code e2411630001006 = 11207723023214 := by decide
theorem cert_e2411630001006 : check e2411630001006 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2411630001014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2411630001014 : Closed e2411630001014 ∧ code e2411630001014 = 11207723023222 := by decide
theorem cert_e2411630001014 : check e2411630001014 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2411630001078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2411630001078 : Closed e2411630001078 ∧ code e2411630001078 = 11207723023286 := by decide
theorem cert_e2411630001078 : check e2411630001078 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2411630003950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e2411630003950 : Closed e2411630003950 ∧ code e2411630003950 = 11207723026158 := by decide
theorem cert_e2411630003950 : check e2411630003950 [[],[]] .chain = true := by decide
def e2411630003958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.var 1))))))
theorem wire_e2411630003958 : Closed e2411630003958 ∧ code e2411630003958 = 11207723026166 := by decide
theorem cert_e2411630003958 : check e2411630003958 [[],[]] .chain = true := by decide
def e2411630004142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e2411630004142 : Closed e2411630004142 ∧ code e2411630004142 = 11207723026350 := by decide
theorem cert_e2411630004142 : check e2411630004142 [[],[]] .chain = true := by decide
def e2411630004182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.var 1))))))
theorem wire_e2411630004182 : Closed e2411630004182 ∧ code e2411630004182 = 11207723026390 := by decide
theorem cert_e2411630004182 : check e2411630004182 [[],[]] .chain = true := by decide
def e2411630005486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630005486 : Closed e2411630005486 ∧ code e2411630005486 = 11207723027694 := by decide
theorem cert_e2411630005486 : check e2411630005486 [[],[]] .chain = true := by decide
def e2411630005494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630005494 : Closed e2411630005494 ∧ code e2411630005494 = 11207723027702 := by decide
theorem cert_e2411630005494 : check e2411630005494 [[],[]] .chain = true := by decide
def e2411630005870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630005870 : Closed e2411630005870 ∧ code e2411630005870 = 11207723028078 := by decide
theorem cert_e2411630005870 : check e2411630005870 [[],[]] .chain = true := by decide
def e2411630005882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630005882 : Closed e2411630005882 ∧ code e2411630005882 = 11207723028090 := by decide
theorem cert_e2411630005882 : check e2411630005882 [[],[]] .chain = true := by decide
def e2411630006070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630006070 : Closed e2411630006070 ∧ code e2411630006070 = 11207723028278 := by decide
theorem cert_e2411630006070 : check e2411630006070 [[],[]] .chain = true := by decide
def e2411630006074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630006074 : Closed e2411630006074 ∧ code e2411630006074 = 11207723028282 := by decide
theorem cert_e2411630006074 : check e2411630006074 [[],[]] .chain = true := by decide
def e2411630008558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 2))))))
theorem wire_e2411630008558 : Closed e2411630008558 ∧ code e2411630008558 = 11207723030766 := by decide
theorem cert_e2411630008558 : check e2411630008558 [[],[]] .chain = true := by decide
def e2411630008566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 1))))))
theorem wire_e2411630008566 : Closed e2411630008566 ∧ code e2411630008566 = 11207723030774 := by decide
theorem cert_e2411630008566 : check e2411630008566 [[],[]] .chain = true := by decide
def e2411630009118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2411630009118 : Closed e2411630009118 ∧ code e2411630009118 = 11207723031326 := by decide
theorem cert_e2411630009118 : check e2411630009118 [[],[]] .chain = true := by decide
def e2411630009230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e2411630009230 : Closed e2411630009230 ∧ code e2411630009230 = 11207723031438 := by decide
theorem cert_e2411630009230 : check e2411630009230 [[],[]] .chain = true := by decide
def e2411630009454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 2))))))
theorem wire_e2411630009454 : Closed e2411630009454 ∧ code e2411630009454 = 11207723031662 := by decide
theorem cert_e2411630009454 : check e2411630009454 [[],[]] .chain = true := by decide
def e2411630009466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 0))))))
theorem wire_e2411630009466 : Closed e2411630009466 ∧ code e2411630009466 = 11207723031674 := by decide
theorem cert_e2411630009466 : check e2411630009466 [[],[]] .chain = true := by decide
def e2411630009630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2411630009630 : Closed e2411630009630 ∧ code e2411630009630 = 11207723031838 := by decide
theorem cert_e2411630009630 : check e2411630009630 [[],[]] .chain = true := by decide
def e2411630009798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2411630009798 : Closed e2411630009798 ∧ code e2411630009798 = 11207723032006 := by decide
theorem cert_e2411630009798 : check e2411630009798 [[],[]] .chain = true := by decide
def e2411630009910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2411630009910 : Closed e2411630009910 ∧ code e2411630009910 = 11207723032118 := by decide
theorem cert_e2411630009910 : check e2411630009910 [[],[]] .chain = true := by decide
end Blc.Floor43
