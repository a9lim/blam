import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605653349334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e605653349334 : Closed e605653349334 ∧ code e605653349334 = 9401746371542 := by decide
theorem cert_e605653349334 : check e605653349334 [[.under],[.under]] .smaller = true := by decide
def e605653349338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e605653349338 : Closed e605653349338 ∧ code e605653349338 = 9401746371546 := by decide
theorem cert_e605653349338 : check e605653349338 [[.under],[.under]] .smaller = true := by decide
def e605653349614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605653349614 : Closed e605653349614 ∧ code e605653349614 = 9401746371822 := by decide
theorem cert_e605653349614 : check e605653349614 [[.under],[.under]] .smaller = true := by decide
def e605653349622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605653349622 : Closed e605653349622 ∧ code e605653349622 = 9401746371830 := by decide
theorem cert_e605653349622 : check e605653349622 [[.under],[.under]] .smaller = true := by decide
def e605653349998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605653349998 : Closed e605653349998 ∧ code e605653349998 = 9401746372206 := by decide
theorem cert_e605653349998 : check e605653349998 [[.under],[.under]] .smaller = true := by decide
def e605653350010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605653350010 : Closed e605653350010 ∧ code e605653350010 = 9401746372218 := by decide
theorem cert_e605653350010 : check e605653350010 [[.under],[.under]] .smaller = true := by decide
def e605653350198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605653350198 : Closed e605653350198 ∧ code e605653350198 = 9401746372406 := by decide
theorem cert_e605653350198 : check e605653350198 [[.under],[.under]] .smaller = true := by decide
def e605653350202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605653350202 : Closed e605653350202 ∧ code e605653350202 = 9401746372410 := by decide
theorem cert_e605653350202 : check e605653350202 [[.under],[.under]] .smaller = true := by decide
def e605653350830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e605653350830 : Closed e605653350830 ∧ code e605653350830 = 9401746373038 := by decide
theorem cert_e605653350830 : check e605653350830 [[.under],[.under]] .smaller = true := by decide
def e605653350842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e605653350842 : Closed e605653350842 ∧ code e605653350842 = 9401746373050 := by decide
theorem cert_e605653350842 : check e605653350842 [[.under],[.under]] .smaller = true := by decide
def e605653350890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e605653350890 : Closed e605653350890 ∧ code e605653350890 = 9401746373098 := by decide
theorem cert_e605653350890 : check e605653350890 [[.under],[.under]] .smaller = true := by decide
def e605653351022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605653351022 : Closed e605653351022 ∧ code e605653351022 = 9401746373230 := by decide
theorem cert_e605653351022 : check e605653351022 [[.under],[.under]] .smaller = true := by decide
def e605653351034 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605653351034 : Closed e605653351034 ∧ code e605653351034 = 9401746373242 := by decide
theorem cert_e605653351034 : check e605653351034 [[.under],[.under]] .smaller = true := by decide
def e605653351322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605653351322 : Closed e605653351322 ∧ code e605653351322 = 9401746373530 := by decide
theorem cert_e605653351322 : check e605653351322 [[.under],[.under]] .smaller = true := by decide
def e605653351638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e605653351638 : Closed e605653351638 ∧ code e605653351638 = 9401746373846 := by decide
theorem cert_e605653351638 : check e605653351638 [[.under],[.under]] .smaller = true := by decide
def e605653351642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e605653351642 : Closed e605653351642 ∧ code e605653351642 = 9401746373850 := by decide
theorem cert_e605653351642 : check e605653351642 [[.under],[.under]] .smaller = true := by decide
def e605653351658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e605653351658 : Closed e605653351658 ∧ code e605653351658 = 9401746373866 := by decide
theorem cert_e605653351658 : check e605653351658 [[.under],[.under]] .smaller = true := by decide
def e605653351734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605653351734 : Closed e605653351734 ∧ code e605653351734 = 9401746373942 := by decide
theorem cert_e605653351734 : check e605653351734 [[.under],[.under]] .smaller = true := by decide
def e605653351738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605653351738 : Closed e605653351738 ∧ code e605653351738 = 9401746373946 := by decide
theorem cert_e605653351738 : check e605653351738 [[.under],[.under]] .smaller = true := by decide
def e605653351834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605653351834 : Closed e605653351834 ∧ code e605653351834 = 9401746374042 := by decide
theorem cert_e605653351834 : check e605653351834 [[.under],[.under]] .smaller = true := by decide
def e605653355374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605653355374 : Closed e605653355374 ∧ code e605653355374 = 9401746377582 := by decide
theorem cert_e605653355374 : check e605653355374 [[.under],[.under]] .smaller = true := by decide
def e605653355382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605653355382 : Closed e605653355382 ∧ code e605653355382 = 9401746377590 := by decide
theorem cert_e605653355382 : check e605653355382 [[.under],[.under]] .smaller = true := by decide
def e605653355438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605653355438 : Closed e605653355438 ∧ code e605653355438 = 9401746377646 := by decide
theorem cert_e605653355438 : check e605653355438 [[.under],[.under]] .smaller = true := by decide
def e605653355450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605653355450 : Closed e605653355450 ∧ code e605653355450 = 9401746377658 := by decide
theorem cert_e605653355450 : check e605653355450 [[.under],[.under]] .smaller = true := by decide
def e605653355478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605653355478 : Closed e605653355478 ∧ code e605653355478 = 9401746377686 := by decide
theorem cert_e605653355478 : check e605653355478 [[.under],[.under]] .smaller = true := by decide
def e605653355482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605653355482 : Closed e605653355482 ∧ code e605653355482 = 9401746377690 := by decide
theorem cert_e605653355482 : check e605653355482 [[.under],[.under]] .smaller = true := by decide
def e605653355758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605653355758 : Closed e605653355758 ∧ code e605653355758 = 9401746377966 := by decide
theorem cert_e605653355758 : check e605653355758 [[.under],[.under]] .smaller = true := by decide
def e605653355766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605653355766 : Closed e605653355766 ∧ code e605653355766 = 9401746377974 := by decide
theorem cert_e605653355766 : check e605653355766 [[.under],[.under]] .smaller = true := by decide
def e605653356142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605653356142 : Closed e605653356142 ∧ code e605653356142 = 9401746378350 := by decide
theorem cert_e605653356142 : check e605653356142 [[.under],[.under]] .smaller = true := by decide
def e605653356154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605653356154 : Closed e605653356154 ∧ code e605653356154 = 9401746378362 := by decide
theorem cert_e605653356154 : check e605653356154 [[.under],[.under]] .smaller = true := by decide
def e605653356342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605653356342 : Closed e605653356342 ∧ code e605653356342 = 9401746378550 := by decide
theorem cert_e605653356342 : check e605653356342 [[.under],[.under]] .smaller = true := by decide
def e605653356346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605653356346 : Closed e605653356346 ∧ code e605653356346 = 9401746378554 := by decide
theorem cert_e605653356346 : check e605653356346 [[.under],[.under]] .smaller = true := by decide
def e605653362094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e605653362094 : Closed e605653362094 ∧ code e605653362094 = 9401746384302 := by decide
theorem cert_e605653362094 : check e605653362094 [[.under],[.under]] .smaller = true := by decide
def e605653362106 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e605653362106 : Closed e605653362106 ∧ code e605653362106 = 9401746384314 := by decide
theorem cert_e605653362106 : check e605653362106 [[.under],[.under]] .smaller = true := by decide
def e605653362154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e605653362154 : Closed e605653362154 ∧ code e605653362154 = 9401746384362 := by decide
theorem cert_e605653362154 : check e605653362154 [[.under],[.under]] .smaller = true := by decide
def e605653362286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605653362286 : Closed e605653362286 ∧ code e605653362286 = 9401746384494 := by decide
theorem cert_e605653362286 : check e605653362286 [[.under],[.under]] .smaller = true := by decide
def e605653362298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605653362298 : Closed e605653362298 ∧ code e605653362298 = 9401746384506 := by decide
theorem cert_e605653362298 : check e605653362298 [[.under],[.under]] .smaller = true := by decide
def e605653362586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605653362586 : Closed e605653362586 ∧ code e605653362586 = 9401746384794 := by decide
theorem cert_e605653362586 : check e605653362586 [[.under],[.under]] .smaller = true := by decide
def e605653365462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e605653365462 : Closed e605653365462 ∧ code e605653365462 = 9401746387670 := by decide
theorem cert_e605653365462 : check e605653365462 [[.under],[.under]] .smaller = true := by decide
def e605653365466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e605653365466 : Closed e605653365466 ∧ code e605653365466 = 9401746387674 := by decide
theorem cert_e605653365466 : check e605653365466 [[.under],[.under]] .smaller = true := by decide
def e605653365482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e605653365482 : Closed e605653365482 ∧ code e605653365482 = 9401746387690 := by decide
theorem cert_e605653365482 : check e605653365482 [[.under],[.under]] .smaller = true := by decide
def e605653365558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605653365558 : Closed e605653365558 ∧ code e605653365558 = 9401746387766 := by decide
theorem cert_e605653365558 : check e605653365558 [[.under],[.under]] .smaller = true := by decide
def e605653365562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605653365562 : Closed e605653365562 ∧ code e605653365562 = 9401746387770 := by decide
theorem cert_e605653365562 : check e605653365562 [[.under],[.under]] .smaller = true := by decide
def e605653365658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605653365658 : Closed e605653365658 ∧ code e605653365658 = 9401746387866 := by decide
theorem cert_e605653365658 : check e605653365658 [[.under],[.under]] .smaller = true := by decide
def e605653481198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e605653481198 : Closed e605653481198 ∧ code e605653481198 = 9401746503406 := by decide
theorem cert_e605653481198 : check e605653481198 [[.under],[.under]] .sourceHead = true := by decide
def e605653481326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e605653481326 : Closed e605653481326 ∧ code e605653481326 = 9401746503534 := by decide
theorem cert_e605653481326 : check e605653481326 [[.under],[.under]] .sourceHead = true := by decide
def e605653481334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e605653481334 : Closed e605653481334 ∧ code e605653481334 = 9401746503542 := by decide
theorem cert_e605653481334 : check e605653481334 [[.under],[.under]] .sourceHead = true := by decide
def e605653482222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e605653482222 : Closed e605653482222 ∧ code e605653482222 = 9401746504430 := by decide
theorem cert_e605653482222 : check e605653482222 [[.under],[.under]] .sourceHead = true := by decide
def e605653482414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e605653482414 : Closed e605653482414 ∧ code e605653482414 = 9401746504622 := by decide
theorem cert_e605653482414 : check e605653482414 [[.under],[.under]] .sourceHead = true := by decide
def e605653482426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e605653482426 : Closed e605653482426 ∧ code e605653482426 = 9401746504634 := by decide
theorem cert_e605653482426 : check e605653482426 [[.under],[.under]] .sourceHead = true := by decide
def e605653482862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605653482862 : Closed e605653482862 ∧ code e605653482862 = 9401746505070 := by decide
theorem cert_e605653482862 : check e605653482862 [[.under],[.under]] .sourceHead = true := by decide
def e605653482870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605653482870 : Closed e605653482870 ∧ code e605653482870 = 9401746505078 := by decide
theorem cert_e605653482870 : check e605653482870 [[.under],[.under]] .sourceHead = true := by decide
def e605653482926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605653482926 : Closed e605653482926 ∧ code e605653482926 = 9401746505134 := by decide
theorem cert_e605653482926 : check e605653482926 [[.under],[.under]] .sourceHead = true := by decide
def e605653482938 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605653482938 : Closed e605653482938 ∧ code e605653482938 = 9401746505146 := by decide
theorem cert_e605653482938 : check e605653482938 [[.under],[.under]] .sourceHead = true := by decide
def e605653482966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605653482966 : Closed e605653482966 ∧ code e605653482966 = 9401746505174 := by decide
theorem cert_e605653482966 : check e605653482966 [[.under],[.under]] .sourceHead = true := by decide
def e605653482970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605653482970 : Closed e605653482970 ∧ code e605653482970 = 9401746505178 := by decide
theorem cert_e605653482970 : check e605653482970 [[.under],[.under]] .sourceHead = true := by decide
def e605653487342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e605653487342 : Closed e605653487342 ∧ code e605653487342 = 9401746509550 := by decide
theorem cert_e605653487342 : check e605653487342 [[.under],[.under]] .sourceHead = true := by decide
def e605653487470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e605653487470 : Closed e605653487470 ∧ code e605653487470 = 9401746509678 := by decide
theorem cert_e605653487470 : check e605653487470 [[.under],[.under]] .sourceHead = true := by decide
def e605653487478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e605653487478 : Closed e605653487478 ∧ code e605653487478 = 9401746509686 := by decide
theorem cert_e605653487478 : check e605653487478 [[.under],[.under]] .sourceHead = true := by decide
def e605653490158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605653490158 : Closed e605653490158 ∧ code e605653490158 = 9401746512366 := by decide
theorem cert_e605653490158 : check e605653490158 [[.under],[.under]] .sourceHead = true := by decide
def e605653490926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605653490926 : Closed e605653490926 ∧ code e605653490926 = 9401746513134 := by decide
theorem cert_e605653490926 : check e605653490926 [[.under],[.under]] .sourceHead = true := by decide
def e605653490934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605653490934 : Closed e605653490934 ∧ code e605653490934 = 9401746513142 := by decide
theorem cert_e605653490934 : check e605653490934 [[.under],[.under]] .sourceHead = true := by decide
def e605653493486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e605653493486 : Closed e605653493486 ∧ code e605653493486 = 9401746515694 := by decide
theorem cert_e605653493486 : check e605653493486 [[.under],[.under]] .sourceHead = true := by decide
def e605653493678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e605653493678 : Closed e605653493678 ∧ code e605653493678 = 9401746515886 := by decide
theorem cert_e605653493678 : check e605653493678 [[.under],[.under]] .sourceHead = true := by decide
def e605653493690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e605653493690 : Closed e605653493690 ∧ code e605653493690 = 9401746515898 := by decide
theorem cert_e605653493690 : check e605653493690 [[.under],[.under]] .sourceHead = true := by decide
def e605653494254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e605653494254 : Closed e605653494254 ∧ code e605653494254 = 9401746516462 := by decide
theorem cert_e605653494254 : check e605653494254 [[.under],[.under]] .sourceHead = true := by decide
def e605653495406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605653495406 : Closed e605653495406 ∧ code e605653495406 = 9401746517614 := by decide
theorem cert_e605653495406 : check e605653495406 [[.under],[.under]] .sourceHead = true := by decide
def e605653495418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605653495418 : Closed e605653495418 ∧ code e605653495418 = 9401746517626 := by decide
theorem cert_e605653495418 : check e605653495418 [[.under],[.under]] .sourceHead = true := by decide
def e605653496686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605653496686 : Closed e605653496686 ∧ code e605653496686 = 9401746518894 := by decide
theorem cert_e605653496686 : check e605653496686 [[.under],[.under]] .sourceHead = true := by decide
def e605653496694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605653496694 : Closed e605653496694 ∧ code e605653496694 = 9401746518902 := by decide
theorem cert_e605653496694 : check e605653496694 [[.under],[.under]] .sourceHead = true := by decide
def e605653496750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605653496750 : Closed e605653496750 ∧ code e605653496750 = 9401746518958 := by decide
theorem cert_e605653496750 : check e605653496750 [[.under],[.under]] .sourceHead = true := by decide
def e605653496762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605653496762 : Closed e605653496762 ∧ code e605653496762 = 9401746518970 := by decide
theorem cert_e605653496762 : check e605653496762 [[.under],[.under]] .sourceHead = true := by decide
def e605653496790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605653496790 : Closed e605653496790 ∧ code e605653496790 = 9401746518998 := by decide
theorem cert_e605653496790 : check e605653496790 [[.under],[.under]] .sourceHead = true := by decide
def e605653496794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605653496794 : Closed e605653496794 ∧ code e605653496794 = 9401746519002 := by decide
theorem cert_e605653496794 : check e605653496794 [[.under],[.under]] .sourceHead = true := by decide
def e605653497070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605653497070 : Closed e605653497070 ∧ code e605653497070 = 9401746519278 := by decide
theorem cert_e605653497070 : check e605653497070 [[.under],[.under]] .sourceHead = true := by decide
def e605653497078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605653497078 : Closed e605653497078 ∧ code e605653497078 = 9401746519286 := by decide
theorem cert_e605653497078 : check e605653497078 [[.under],[.under]] .sourceHead = true := by decide
def e605653497454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605653497454 : Closed e605653497454 ∧ code e605653497454 = 9401746519662 := by decide
theorem cert_e605653497454 : check e605653497454 [[.under],[.under]] .sourceHead = true := by decide
def e605653497466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605653497466 : Closed e605653497466 ∧ code e605653497466 = 9401746519674 := by decide
theorem cert_e605653497466 : check e605653497466 [[.under],[.under]] .sourceHead = true := by decide
def e605653497654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605653497654 : Closed e605653497654 ∧ code e605653497654 = 9401746519862 := by decide
theorem cert_e605653497654 : check e605653497654 [[.under],[.under]] .sourceHead = true := by decide
def e605653497658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605653497658 : Closed e605653497658 ∧ code e605653497658 = 9401746519866 := by decide
theorem cert_e605653497658 : check e605653497658 [[.under],[.under]] .sourceHead = true := by decide
def e605653502830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605653502830 : Closed e605653502830 ∧ code e605653502830 = 9401746525038 := by decide
theorem cert_e605653502830 : check e605653502830 [[.under],[.under]] .smaller = true := by decide
def e605653502838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605653502838 : Closed e605653502838 ∧ code e605653502838 = 9401746525046 := by decide
theorem cert_e605653502838 : check e605653502838 [[.under],[.under]] .smaller = true := by decide
def e605653502894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605653502894 : Closed e605653502894 ∧ code e605653502894 = 9401746525102 := by decide
theorem cert_e605653502894 : check e605653502894 [[.under],[.under]] .smaller = true := by decide
def e605653502906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605653502906 : Closed e605653502906 ∧ code e605653502906 = 9401746525114 := by decide
theorem cert_e605653502906 : check e605653502906 [[.under],[.under]] .smaller = true := by decide
def e605653502934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605653502934 : Closed e605653502934 ∧ code e605653502934 = 9401746525142 := by decide
theorem cert_e605653502934 : check e605653502934 [[.under],[.under]] .smaller = true := by decide
def e605653502938 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605653502938 : Closed e605653502938 ∧ code e605653502938 = 9401746525146 := by decide
theorem cert_e605653502938 : check e605653502938 [[.under],[.under]] .smaller = true := by decide
def e605653503214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605653503214 : Closed e605653503214 ∧ code e605653503214 = 9401746525422 := by decide
theorem cert_e605653503214 : check e605653503214 [[.under],[.under]] .smaller = true := by decide
def e605653503222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605653503222 : Closed e605653503222 ∧ code e605653503222 = 9401746525430 := by decide
theorem cert_e605653503222 : check e605653503222 [[.under],[.under]] .smaller = true := by decide
def e605653503598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605653503598 : Closed e605653503598 ∧ code e605653503598 = 9401746525806 := by decide
theorem cert_e605653503598 : check e605653503598 [[.under],[.under]] .smaller = true := by decide
def e605653503610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605653503610 : Closed e605653503610 ∧ code e605653503610 = 9401746525818 := by decide
theorem cert_e605653503610 : check e605653503610 [[.under],[.under]] .smaller = true := by decide
def e605653503798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605653503798 : Closed e605653503798 ∧ code e605653503798 = 9401746526006 := by decide
theorem cert_e605653503798 : check e605653503798 [[.under],[.under]] .smaller = true := by decide
def e605653503802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605653503802 : Closed e605653503802 ∧ code e605653503802 = 9401746526010 := by decide
theorem cert_e605653503802 : check e605653503802 [[.under],[.under]] .smaller = true := by decide
def e605653511918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e605653511918 : Closed e605653511918 ∧ code e605653511918 = 9401746534126 := by decide
theorem cert_e605653511918 : check e605653511918 [[.under],[.under]] .sourceHead = true := by decide
def e605653512046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e605653512046 : Closed e605653512046 ∧ code e605653512046 = 9401746534254 := by decide
theorem cert_e605653512046 : check e605653512046 [[.under],[.under]] .sourceHead = true := by decide
def e605653512054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e605653512054 : Closed e605653512054 ∧ code e605653512054 = 9401746534262 := by decide
theorem cert_e605653512054 : check e605653512054 [[.under],[.under]] .sourceHead = true := by decide
def e605653514734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e605653514734 : Closed e605653514734 ∧ code e605653514734 = 9401746536942 := by decide
theorem cert_e605653514734 : check e605653514734 [[.under],[.under]] .sourceHead = true := by decide
def e605653515502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e605653515502 : Closed e605653515502 ∧ code e605653515502 = 9401746537710 := by decide
theorem cert_e605653515502 : check e605653515502 [[.under],[.under]] .sourceHead = true := by decide
def e605653515510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e605653515510 : Closed e605653515510 ∧ code e605653515510 = 9401746537718 := by decide
theorem cert_e605653515510 : check e605653515510 [[.under],[.under]] .sourceHead = true := by decide
def e605653538542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e605653538542 : Closed e605653538542 ∧ code e605653538542 = 9401746560750 := by decide
theorem cert_e605653538542 : check e605653538542 [[.under],[.under]] .sourceHead = true := by decide
def e605653538734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e605653538734 : Closed e605653538734 ∧ code e605653538734 = 9401746560942 := by decide
theorem cert_e605653538734 : check e605653538734 [[.under],[.under]] .sourceHead = true := by decide
def e605653538746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e605653538746 : Closed e605653538746 ∧ code e605653538746 = 9401746560954 := by decide
theorem cert_e605653538746 : check e605653538746 [[.under],[.under]] .sourceHead = true := by decide
def e605653539310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e605653539310 : Closed e605653539310 ∧ code e605653539310 = 9401746561518 := by decide
theorem cert_e605653539310 : check e605653539310 [[.under],[.under]] .sourceHead = true := by decide
def e605653540462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e605653540462 : Closed e605653540462 ∧ code e605653540462 = 9401746562670 := by decide
theorem cert_e605653540462 : check e605653540462 [[.under],[.under]] .sourceHead = true := by decide
def e605653540474 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e605653540474 : Closed e605653540474 ∧ code e605653540474 = 9401746562682 := by decide
theorem cert_e605653540474 : check e605653540474 [[.under],[.under]] .sourceHead = true := by decide
def e605653551982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605653551982 : Closed e605653551982 ∧ code e605653551982 = 9401746574190 := by decide
theorem cert_e605653551982 : check e605653551982 [[.under],[.under]] .sourceHead = true := by decide
def e605653551990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605653551990 : Closed e605653551990 ∧ code e605653551990 = 9401746574198 := by decide
theorem cert_e605653551990 : check e605653551990 [[.under],[.under]] .sourceHead = true := by decide
def e605653552046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605653552046 : Closed e605653552046 ∧ code e605653552046 = 9401746574254 := by decide
theorem cert_e605653552046 : check e605653552046 [[.under],[.under]] .sourceHead = true := by decide
def e605653552058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605653552058 : Closed e605653552058 ∧ code e605653552058 = 9401746574266 := by decide
theorem cert_e605653552058 : check e605653552058 [[.under],[.under]] .sourceHead = true := by decide
def e605653552086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605653552086 : Closed e605653552086 ∧ code e605653552086 = 9401746574294 := by decide
theorem cert_e605653552086 : check e605653552086 [[.under],[.under]] .sourceHead = true := by decide
def e605653552090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605653552090 : Closed e605653552090 ∧ code e605653552090 = 9401746574298 := by decide
theorem cert_e605653552090 : check e605653552090 [[.under],[.under]] .sourceHead = true := by decide
def e605653552366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605653552366 : Closed e605653552366 ∧ code e605653552366 = 9401746574574 := by decide
theorem cert_e605653552366 : check e605653552366 [[.under],[.under]] .sourceHead = true := by decide
def e605653552374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605653552374 : Closed e605653552374 ∧ code e605653552374 = 9401746574582 := by decide
theorem cert_e605653552374 : check e605653552374 [[.under],[.under]] .sourceHead = true := by decide
def e605653552750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605653552750 : Closed e605653552750 ∧ code e605653552750 = 9401746574958 := by decide
theorem cert_e605653552750 : check e605653552750 [[.under],[.under]] .sourceHead = true := by decide
def e605653552762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605653552762 : Closed e605653552762 ∧ code e605653552762 = 9401746574970 := by decide
theorem cert_e605653552762 : check e605653552762 [[.under],[.under]] .sourceHead = true := by decide
def e605653552950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605653552950 : Closed e605653552950 ∧ code e605653552950 = 9401746575158 := by decide
theorem cert_e605653552950 : check e605653552950 [[.under],[.under]] .sourceHead = true := by decide
def e605653552954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605653552954 : Closed e605653552954 ∧ code e605653552954 = 9401746575162 := by decide
theorem cert_e605653552954 : check e605653552954 [[.under],[.under]] .sourceHead = true := by decide
def e605654092654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605654092654 : Closed e605654092654 ∧ code e605654092654 = 9401747114862 := by decide
theorem cert_e605654092654 : check e605654092654 [[.under],[.under]] .smaller = true := by decide
def e605654092662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605654092662 : Closed e605654092662 ∧ code e605654092662 = 9401747114870 := by decide
theorem cert_e605654092662 : check e605654092662 [[.under],[.under]] .smaller = true := by decide
def e605654092718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605654092718 : Closed e605654092718 ∧ code e605654092718 = 9401747114926 := by decide
theorem cert_e605654092718 : check e605654092718 [[.under],[.under]] .smaller = true := by decide
def e605654092730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605654092730 : Closed e605654092730 ∧ code e605654092730 = 9401747114938 := by decide
theorem cert_e605654092730 : check e605654092730 [[.under],[.under]] .smaller = true := by decide
def e605654092758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605654092758 : Closed e605654092758 ∧ code e605654092758 = 9401747114966 := by decide
theorem cert_e605654092758 : check e605654092758 [[.under],[.under]] .smaller = true := by decide
def e605654092762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605654092762 : Closed e605654092762 ∧ code e605654092762 = 9401747114970 := by decide
theorem cert_e605654092762 : check e605654092762 [[.under],[.under]] .smaller = true := by decide
def e605654093038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605654093038 : Closed e605654093038 ∧ code e605654093038 = 9401747115246 := by decide
theorem cert_e605654093038 : check e605654093038 [[.under],[.under]] .smaller = true := by decide
def e605654093046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605654093046 : Closed e605654093046 ∧ code e605654093046 = 9401747115254 := by decide
theorem cert_e605654093046 : check e605654093046 [[.under],[.under]] .smaller = true := by decide
def e605654093422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605654093422 : Closed e605654093422 ∧ code e605654093422 = 9401747115630 := by decide
theorem cert_e605654093422 : check e605654093422 [[.under],[.under]] .smaller = true := by decide
def e605654093434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605654093434 : Closed e605654093434 ∧ code e605654093434 = 9401747115642 := by decide
theorem cert_e605654093434 : check e605654093434 [[.under],[.under]] .smaller = true := by decide
def e605654093622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605654093622 : Closed e605654093622 ∧ code e605654093622 = 9401747115830 := by decide
theorem cert_e605654093622 : check e605654093622 [[.under],[.under]] .smaller = true := by decide
def e605654093626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605654093626 : Closed e605654093626 ∧ code e605654093626 = 9401747115834 := by decide
theorem cert_e605654093626 : check e605654093626 [[.under],[.under]] .smaller = true := by decide
def e605774984950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 1)))))
theorem wire_e605774984950 : Closed e605774984950 ∧ code e605774984950 = 9401868007158 := by decide
theorem cert_e605774984950 : check e605774984950 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605774985142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.var 1)))))
theorem wire_e605774985142 : Closed e605774985142 ∧ code e605774985142 = 9401868007350 := by decide
theorem cert_e605774985142 : check e605774985142 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605774985974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.var 1)))))
theorem wire_e605774985974 : Closed e605774985974 ∧ code e605774985974 = 9401868008182 := by decide
theorem cert_e605774985974 : check e605774985974 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605774986198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.var 1)))))
theorem wire_e605774986198 : Closed e605774986198 ∧ code e605774986198 = 9401868008406 := by decide
theorem cert_e605774986198 : check e605774986198 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605774986934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.var 1)))))
theorem wire_e605774986934 : Closed e605774986934 ∧ code e605774986934 = 9401868009142 := by decide
theorem cert_e605774986934 : check e605774986934 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605774986966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.var 1)))))
theorem wire_e605774986966 : Closed e605774986966 ∧ code e605774986966 = 9401868009174 := by decide
theorem cert_e605774986966 : check e605774986966 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605774991094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.var 1)))))
theorem wire_e605774991094 : Closed e605774991094 ∧ code e605774991094 = 9401868013302 := by decide
theorem cert_e605774991094 : check e605774991094 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605774991286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.var 1)))))
theorem wire_e605774991286 : Closed e605774991286 ∧ code e605774991286 = 9401868013494 := by decide
theorem cert_e605774991286 : check e605774991286 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605774997238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.var 1)))))
theorem wire_e605774997238 : Closed e605774997238 ∧ code e605774997238 = 9401868019446 := by decide
theorem cert_e605774997238 : check e605774997238 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605774997462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.var 1)))))
theorem wire_e605774997462 : Closed e605774997462 ∧ code e605774997462 = 9401868019670 := by decide
theorem cert_e605774997462 : check e605774997462 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775002038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.var 1)))))
theorem wire_e605775002038 : Closed e605775002038 ∧ code e605775002038 = 9401868024246 := by decide
theorem cert_e605775002038 : check e605775002038 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775002070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.var 1)))))
theorem wire_e605775002070 : Closed e605775002070 ∧ code e605775002070 = 9401868024278 := by decide
theorem cert_e605775002070 : check e605775002070 [[.under],[.under],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775120246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.var 1)))))
theorem wire_e605775120246 : Closed e605775120246 ∧ code e605775120246 = 9401868142454 := by decide
theorem cert_e605775120246 : check e605775120246 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605775120310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.var 1)))))
theorem wire_e605775120310 : Closed e605775120310 ∧ code e605775120310 = 9401868142518 := by decide
theorem cert_e605775120310 : check e605775120310 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605775124726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 1)))))
theorem wire_e605775124726 : Closed e605775124726 ∧ code e605775124726 = 9401868146934 := by decide
theorem cert_e605775124726 : check e605775124726 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605775125390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 2))))))
theorem wire_e605775125390 : Closed e605775125390 ∧ code e605775125390 = 9401868147598 := by decide
theorem cert_e605775125390 : check e605775125390 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775125622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.var 1)))))
theorem wire_e605775125622 : Closed e605775125622 ∧ code e605775125622 = 9401868147830 := by decide
theorem cert_e605775125622 : check e605775125622 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605775125902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 2))))))
theorem wire_e605775125902 : Closed e605775125902 ∧ code e605775125902 = 9401868148110 := by decide
theorem cert_e605775125902 : check e605775125902 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775127414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.var 1)))))
theorem wire_e605775127414 : Closed e605775127414 ∧ code e605775127414 = 9401868149622 := by decide
theorem cert_e605775127414 : check e605775127414 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775127510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.var 1)))))
theorem wire_e605775127510 : Closed e605775127510 ∧ code e605775127510 = 9401868149718 := by decide
theorem cert_e605775127510 : check e605775127510 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .smaller = true := by decide
def e605775128822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.var 1)))))
theorem wire_e605775128822 : Closed e605775128822 ∧ code e605775128822 = 9401868151030 := by decide
theorem cert_e605775128822 : check e605775128822 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605775129486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 2))))))
theorem wire_e605775129486 : Closed e605775129486 ∧ code e605775129486 = 9401868151694 := by decide
theorem cert_e605775129486 : check e605775129486 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775130166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 1)))))
theorem wire_e605775130166 : Closed e605775130166 ∧ code e605775130166 = 9401868152374 := by decide
private def t_e605775130166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 1)))))
theorem cert_e605775130166 : ¬ IsSelfInterpreter e605775130166 :=
  wSource (t := t_e605775130166) (replay_sound (ps := []) (t := e605775130166) (by decide)) (by decide)
def e605775130254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 2))))))
theorem wire_e605775130254 : Closed e605775130254 ∧ code e605775130254 = 9401868152462 := by decide
private def t_e605775130254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 2))))))
theorem cert_e605775130254 : ¬ IsSelfInterpreter e605775130254 :=
  wSource (t := t_e605775130254) (replay_sound (ps := []) (t := e605775130254) (by decide)) (by decide)
def e605775131062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.var 1)))))
theorem wire_e605775131062 : Closed e605775131062 ∧ code e605775131062 = 9401868153270 := by decide
theorem cert_e605775131062 : check e605775131062 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775131094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.var 1)))))
theorem wire_e605775131094 : Closed e605775131094 ∧ code e605775131094 = 9401868153302 := by decide
theorem cert_e605775131094 : check e605775131094 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e605775131766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.var 1)))))
theorem wire_e605775131766 : Closed e605775131766 ∧ code e605775131766 = 9401868153974 := by decide
theorem cert_e605775131766 : check e605775131766 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775132046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 2))))))
theorem wire_e605775132046 : Closed e605775132046 ∧ code e605775132046 = 9401868154254 := by decide
theorem cert_e605775132046 : check e605775132046 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e605775132214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 1)))))
theorem wire_e605775132214 : Closed e605775132214 ∧ code e605775132214 = 9401868154422 := by decide
private def t_e605775132214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 1)))))
theorem cert_e605775132214 : ¬ IsSelfInterpreter e605775132214 :=
  wSource (t := t_e605775132214) (replay_sound (ps := []) (t := e605775132214) (by decide)) (by decide)
def e605775132302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 2))))))
theorem wire_e605775132302 : Closed e605775132302 ∧ code e605775132302 = 9401868154510 := by decide
private def t_e605775132302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 2))))))
theorem cert_e605775132302 : ¬ IsSelfInterpreter e605775132302 :=
  wSource (t := t_e605775132302) (replay_sound (ps := []) (t := e605775132302) (by decide)) (by decide)
def e605775149302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.var 1)))))
theorem wire_e605775149302 : Closed e605775149302 ∧ code e605775149302 = 9401868171510 := by decide
theorem cert_e605775149302 : check e605775149302 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e605775149966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 2))))))
theorem wire_e605775149966 : Closed e605775149966 ∧ code e605775149966 = 9401868172174 := by decide
theorem cert_e605775149966 : check e605775149966 [[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e605775130166
#print axioms Blc.Floor43.cert_e605775130254
#print axioms Blc.Floor43.cert_e605775132214
#print axioms Blc.Floor43.cert_e605775132302
