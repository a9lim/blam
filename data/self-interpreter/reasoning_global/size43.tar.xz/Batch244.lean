import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393385324342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393385324342 : Closed e2393385324342 ∧ code e2393385324342 = 11189478346550 := by decide
def e2393385324346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393385324346 : Closed e2393385324346 ∧ code e2393385324346 = 11189478346554 := by decide
def e2393385330102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2393385330102 : Closed e2393385330102 ∧ code e2393385330102 = 11189478352310 := by decide
theorem cert_e2393385330102 : check e2393385330102 [[],[.left],[],[],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e2393385330134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2393385330134 : Closed e2393385330134 ∧ code e2393385330134 = 11189478352342 := by decide
def e2393385330138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2393385330138 : Closed e2393385330138 ∧ code e2393385330138 = 11189478352346 := by decide
def e2393385330294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393385330294 : Closed e2393385330294 ∧ code e2393385330294 = 11189478352502 := by decide
def e2393385330486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393385330486 : Closed e2393385330486 ∧ code e2393385330486 = 11189478352694 := by decide
def e2393385330490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393385330490 : Closed e2393385330490 ∧ code e2393385330490 = 11189478352698 := by decide
def e2393385667438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393385667438 : Closed e2393385667438 ∧ code e2393385667438 = 11189478689646 := by decide
def e2393385667446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393385667446 : Closed e2393385667446 ∧ code e2393385667446 = 11189478689654 := by decide
private def t_e2393385667446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e2393385667446 : ¬ IsSelfInterpreter e2393385667446 :=
  wSource (t := t_e2393385667446) (replay_sound (ps := []) (t := e2393385667446) (by decide)) (by decide)
def e2393385667502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393385667502 : Closed e2393385667502 ∧ code e2393385667502 = 11189478689710 := by decide
def e2393385667514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393385667514 : Closed e2393385667514 ∧ code e2393385667514 = 11189478689722 := by decide
def e2393385667542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393385667542 : Closed e2393385667542 ∧ code e2393385667542 = 11189478689750 := by decide
private def t_e2393385667542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e2393385667542 : ¬ IsSelfInterpreter e2393385667542 :=
  wSource (t := t_e2393385667542) (replay_sound (ps := []) (t := e2393385667542) (by decide)) (by decide)
def e2393385667546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393385667546 : Closed e2393385667546 ∧ code e2393385667546 = 11189478689754 := by decide
def e2393385667822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393385667822 : Closed e2393385667822 ∧ code e2393385667822 = 11189478690030 := by decide
def e2393385667830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393385667830 : Closed e2393385667830 ∧ code e2393385667830 = 11189478690038 := by decide
def e2393385668206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393385668206 : Closed e2393385668206 ∧ code e2393385668206 = 11189478690414 := by decide
def e2393385668218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393385668218 : Closed e2393385668218 ∧ code e2393385668218 = 11189478690426 := by decide
def e2393385668406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393385668406 : Closed e2393385668406 ∧ code e2393385668406 = 11189478690614 := by decide
def e2393385668410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393385668410 : Closed e2393385668410 ∧ code e2393385668410 = 11189478690618 := by decide
def e2393407490926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393407490926 : Closed e2393407490926 ∧ code e2393407490926 = 11189500513134 := by decide
def e2393407490934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393407490934 : Closed e2393407490934 ∧ code e2393407490934 = 11189500513142 := by decide
def e2393407490990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393407490990 : Closed e2393407490990 ∧ code e2393407490990 = 11189500513198 := by decide
def e2393407491002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393407491002 : Closed e2393407491002 ∧ code e2393407491002 = 11189500513210 := by decide
private def t_e2393407491002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2393407491002 : ¬ IsSelfInterpreter e2393407491002 :=
  wSource (t := t_e2393407491002) (replay_sound (ps := []) (t := e2393407491002) (by decide)) (by decide)
def e2393407491030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393407491030 : Closed e2393407491030 ∧ code e2393407491030 = 11189500513238 := by decide
def e2393407491034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393407491034 : Closed e2393407491034 ∧ code e2393407491034 = 11189500513242 := by decide
private def t_e2393407491034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2393407491034 : ¬ IsSelfInterpreter e2393407491034 :=
  wSource (t := t_e2393407491034) (replay_sound (ps := []) (t := e2393407491034) (by decide)) (by decide)
def e2393407491310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393407491310 : Closed e2393407491310 ∧ code e2393407491310 = 11189500513518 := by decide
theorem cert_e2393407491310 : check e2393407491310 [[],[.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2393407491318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393407491318 : Closed e2393407491318 ∧ code e2393407491318 = 11189500513526 := by decide
theorem cert_e2393407491318 : check e2393407491318 [[],[.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2393407491694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393407491694 : Closed e2393407491694 ∧ code e2393407491694 = 11189500513902 := by decide
theorem cert_e2393407491694 : check e2393407491694 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393407491706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393407491706 : Closed e2393407491706 ∧ code e2393407491706 = 11189500513914 := by decide
theorem cert_e2393407491706 : check e2393407491706 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2393407491894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393407491894 : Closed e2393407491894 ∧ code e2393407491894 = 11189500514102 := by decide
theorem cert_e2393407491894 : check e2393407491894 [[],[.left],[.left],[.left],[],[],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2393407491898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393407491898 : Closed e2393407491898 ∧ code e2393407491898 = 11189500514106 := by decide
def e2393416674746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e2393416674746 : Closed e2393416674746 ∧ code e2393416674746 = 11189509696954 := by decide
theorem cert_e2393416674746 : check e2393416674746 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2393416674778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e2393416674778 : Closed e2393416674778 ∧ code e2393416674778 = 11189509696986 := by decide
theorem cert_e2393416674778 : check e2393416674778 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2393416675002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e2393416675002 : Closed e2393416675002 ∧ code e2393416675002 = 11189509697210 := by decide
theorem cert_e2393416675002 : check e2393416675002 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393416675050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e2393416675050 : Closed e2393416675050 ∧ code e2393416675050 = 11189509697258 := by decide
theorem cert_e2393416675050 : check e2393416675050 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2393416675162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e2393416675162 : Closed e2393416675162 ∧ code e2393416675162 = 11189509697370 := by decide
theorem cert_e2393416675162 : check e2393416675162 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left]] .chain = true := by decide
def e2393416675178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e2393416675178 : Closed e2393416675178 ∧ code e2393416675178 = 11189509697386 := by decide
theorem cert_e2393416675178 : check e2393416675178 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2393416676282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e2393416676282 : Closed e2393416676282 ∧ code e2393416676282 = 11189509698490 := by decide
theorem cert_e2393416676282 : check e2393416676282 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left]] .chain = true := by decide
def e2393416676314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e2393416676314 : Closed e2393416676314 ∧ code e2393416676314 = 11189509698522 := by decide
theorem cert_e2393416676314 : check e2393416676314 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left]] .chain = true := by decide
def e2393416677818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e2393416677818 : Closed e2393416677818 ∧ code e2393416677818 = 11189509700026 := by decide
theorem cert_e2393416677818 : check e2393416677818 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2393416677866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e2393416677866 : Closed e2393416677866 ∧ code e2393416677866 = 11189509700074 := by decide
theorem cert_e2393416677866 : check e2393416677866 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393416678618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e2393416678618 : Closed e2393416678618 ∧ code e2393416678618 = 11189509700826 := by decide
theorem cert_e2393416678618 : check e2393416678618 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2393416678634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e2393416678634 : Closed e2393416678634 ∧ code e2393416678634 = 11189509700842 := by decide
theorem cert_e2393416678634 : check e2393416678634 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left],[.under],[.under,.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2393416709858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))))
theorem wire_e2393416709858 : Closed e2393416709858 ∧ code e2393416709858 = 11189509732066 := by decide
def e2393416709986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))))
theorem wire_e2393416709986 : Closed e2393416709986 ∧ code e2393416709986 = 11189509732194 := by decide
def e2393416710882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))))
theorem wire_e2393416710882 : Closed e2393416710882 ∧ code e2393416710882 = 11189509733090 := by decide
def e2393416711074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))))
theorem wire_e2393416711074 : Closed e2393416711074 ∧ code e2393416711074 = 11189509733282 := by decide
private def t_e2393416711074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))))
theorem cert_e2393416711074 : ¬ IsSelfInterpreter e2393416711074 :=
  wSource (t := t_e2393416711074) (replay_sound (ps := []) (t := e2393416711074) (by decide)) (by decide)
def e2393416711522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))))
theorem wire_e2393416711522 : Closed e2393416711522 ∧ code e2393416711522 = 11189509733730 := by decide
theorem cert_e2393416711522 : check e2393416711522 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2393416711586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))))
theorem wire_e2393416711586 : Closed e2393416711586 ∧ code e2393416711586 = 11189509733794 := by decide
private def t_e2393416711586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))))
theorem cert_e2393416711586 : ¬ IsSelfInterpreter e2393416711586 :=
  wSource (t := t_e2393416711586) (replay_sound (ps := []) (t := e2393416711586) (by decide)) (by decide)
def e2393416716002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))))
theorem wire_e2393416716002 : Closed e2393416716002 ∧ code e2393416716002 = 11189509738210 := by decide
def e2393416716130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e2393416716130 : Closed e2393416716130 ∧ code e2393416716130 = 11189509738338 := by decide
def e2393416722146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))))
theorem wire_e2393416722146 : Closed e2393416722146 ∧ code e2393416722146 = 11189509744354 := by decide
def e2393416722338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e2393416722338 : Closed e2393416722338 ∧ code e2393416722338 = 11189509744546 := by decide
theorem cert_e2393416722338 : check e2393416722338 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[],[.left],[.left,.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e2393416725346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e2393416725346 : Closed e2393416725346 ∧ code e2393416725346 = 11189509747554 := by decide
theorem cert_e2393416725346 : check e2393416725346 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2393416725410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e2393416725410 : Closed e2393416725410 ∧ code e2393416725410 = 11189509747618 := by decide
def e2393416928110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393416928110 : Closed e2393416928110 ∧ code e2393416928110 = 11189509950318 := by decide
theorem cert_e2393416928110 : check e2393416928110 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2393416928118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393416928118 : Closed e2393416928118 ∧ code e2393416928118 = 11189509950326 := by decide
theorem cert_e2393416928118 : check e2393416928118 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2393416928174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393416928174 : Closed e2393416928174 ∧ code e2393416928174 = 11189509950382 := by decide
theorem cert_e2393416928174 : check e2393416928174 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e2393416928186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393416928186 : Closed e2393416928186 ∧ code e2393416928186 = 11189509950394 := by decide
theorem cert_e2393416928186 : check e2393416928186 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e2393416928214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393416928214 : Closed e2393416928214 ∧ code e2393416928214 = 11189509950422 := by decide
theorem cert_e2393416928214 : check e2393416928214 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2393416928218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393416928218 : Closed e2393416928218 ∧ code e2393416928218 = 11189509950426 := by decide
theorem cert_e2393416928218 : check e2393416928218 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2393416928494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393416928494 : Closed e2393416928494 ∧ code e2393416928494 = 11189509950702 := by decide
theorem cert_e2393416928494 : check e2393416928494 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2393416928502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393416928502 : Closed e2393416928502 ∧ code e2393416928502 = 11189509950710 := by decide
theorem cert_e2393416928502 : check e2393416928502 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2393416928878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393416928878 : Closed e2393416928878 ∧ code e2393416928878 = 11189509951086 := by decide
theorem cert_e2393416928878 : check e2393416928878 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e2393416928890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393416928890 : Closed e2393416928890 ∧ code e2393416928890 = 11189509951098 := by decide
theorem cert_e2393416928890 : check e2393416928890 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e2393416929078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393416929078 : Closed e2393416929078 ∧ code e2393416929078 = 11189509951286 := by decide
def e2393416929082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393416929082 : Closed e2393416929082 ∧ code e2393416929082 = 11189509951290 := by decide
theorem cert_e2393416929082 : check e2393416929082 [[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[],[.under],[.under,.left,.left]] .chain = true := by decide
def e2393417714542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393417714542 : Closed e2393417714542 ∧ code e2393417714542 = 11189510736750 := by decide
private def t_e2393417714542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e2393417714542 : ¬ IsSelfInterpreter e2393417714542 :=
  wSource (t := t_e2393417714542) (replay_sound (ps := []) (t := e2393417714542) (by decide)) (by decide)
def e2393417714550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393417714550 : Closed e2393417714550 ∧ code e2393417714550 = 11189510736758 := by decide
private def t_e2393417714550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e2393417714550 : ¬ IsSelfInterpreter e2393417714550 :=
  wSource (t := t_e2393417714550) (replay_sound (ps := []) (t := e2393417714550) (by decide)) (by decide)
def e2393417714606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393417714606 : Closed e2393417714606 ∧ code e2393417714606 = 11189510736814 := by decide
private def t_e2393417714606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e2393417714606 : ¬ IsSelfInterpreter e2393417714606 :=
  wSource (t := t_e2393417714606) (replay_sound (ps := []) (t := e2393417714606) (by decide)) (by decide)
def e2393417714618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393417714618 : Closed e2393417714618 ∧ code e2393417714618 = 11189510736826 := by decide
private def t_e2393417714618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e2393417714618 : ¬ IsSelfInterpreter e2393417714618 :=
  wSource (t := t_e2393417714618) (replay_sound (ps := []) (t := e2393417714618) (by decide)) (by decide)
def e2393417714646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393417714646 : Closed e2393417714646 ∧ code e2393417714646 = 11189510736854 := by decide
private def t_e2393417714646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e2393417714646 : ¬ IsSelfInterpreter e2393417714646 :=
  wSource (t := t_e2393417714646) (replay_sound (ps := []) (t := e2393417714646) (by decide)) (by decide)
def e2393417714650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393417714650 : Closed e2393417714650 ∧ code e2393417714650 = 11189510736858 := by decide
private def t_e2393417714650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e2393417714650 : ¬ IsSelfInterpreter e2393417714650 :=
  wSource (t := t_e2393417714650) (replay_sound (ps := []) (t := e2393417714650) (by decide)) (by decide)
def e2393417714926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393417714926 : Closed e2393417714926 ∧ code e2393417714926 = 11189510737134 := by decide
private def t_e2393417714926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e2393417714926 : ¬ IsSelfInterpreter e2393417714926 :=
  wSource (t := t_e2393417714926) (replay_sound (ps := []) (t := e2393417714926) (by decide)) (by decide)
def e2393417714934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393417714934 : Closed e2393417714934 ∧ code e2393417714934 = 11189510737142 := by decide
private def t_e2393417714934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e2393417714934 : ¬ IsSelfInterpreter e2393417714934 :=
  wSource (t := t_e2393417714934) (replay_sound (ps := []) (t := e2393417714934) (by decide)) (by decide)
def e2393417715310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393417715310 : Closed e2393417715310 ∧ code e2393417715310 = 11189510737518 := by decide
private def t_e2393417715310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e2393417715310 : ¬ IsSelfInterpreter e2393417715310 :=
  wSource (t := t_e2393417715310) (replay_sound (ps := []) (t := e2393417715310) (by decide)) (by decide)
def e2393417715322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393417715322 : Closed e2393417715322 ∧ code e2393417715322 = 11189510737530 := by decide
private def t_e2393417715322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e2393417715322 : ¬ IsSelfInterpreter e2393417715322 :=
  wSource (t := t_e2393417715322) (replay_sound (ps := []) (t := e2393417715322) (by decide)) (by decide)
def e2393417715510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393417715510 : Closed e2393417715510 ∧ code e2393417715510 = 11189510737718 := by decide
private def t_e2393417715510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e2393417715510 : ¬ IsSelfInterpreter e2393417715510 :=
  wSource (t := t_e2393417715510) (replay_sound (ps := []) (t := e2393417715510) (by decide)) (by decide)
def e2393417715514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393417715514 : Closed e2393417715514 ∧ code e2393417715514 = 11189510737722 := by decide
private def t_e2393417715514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e2393417715514 : ¬ IsSelfInterpreter e2393417715514 :=
  wSource (t := t_e2393417715514) (replay_sound (ps := []) (t := e2393417715514) (by decide)) (by decide)
def e2393420869054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2393420869054 : Closed e2393420869054 ∧ code e2393420869054 = 11189513891262 := by decide
theorem cert_e2393420869054 : check e2393420869054 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420869110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2393420869110 : Closed e2393420869110 ∧ code e2393420869110 = 11189513891318 := by decide
theorem cert_e2393420869110 : check e2393420869110 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420869310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2393420869310 : Closed e2393420869310 ∧ code e2393420869310 = 11189513891518 := by decide
theorem cert_e2393420869310 : check e2393420869310 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420869370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2393420869370 : Closed e2393420869370 ∧ code e2393420869370 = 11189513891578 := by decide
theorem cert_e2393420869370 : check e2393420869370 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420869590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2393420869590 : Closed e2393420869590 ∧ code e2393420869590 = 11189513891798 := by decide
theorem cert_e2393420869590 : check e2393420869590 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420869594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2393420869594 : Closed e2393420869594 ∧ code e2393420869594 = 11189513891802 := by decide
theorem cert_e2393420869594 : check e2393420869594 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420870590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2393420870590 : Closed e2393420870590 ∧ code e2393420870590 = 11189513892798 := by decide
theorem cert_e2393420870590 : check e2393420870590 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420870646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2393420870646 : Closed e2393420870646 ∧ code e2393420870646 = 11189513892854 := by decide
theorem cert_e2393420870646 : check e2393420870646 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420872126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2393420872126 : Closed e2393420872126 ∧ code e2393420872126 = 11189513894334 := by decide
theorem cert_e2393420872126 : check e2393420872126 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420872186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2393420872186 : Closed e2393420872186 ∧ code e2393420872186 = 11189513894394 := by decide
theorem cert_e2393420872186 : check e2393420872186 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420873526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393420873526 : Closed e2393420873526 ∧ code e2393420873526 = 11189513895734 := by decide
theorem cert_e2393420873526 : check e2393420873526 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420873530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393420873530 : Closed e2393420873530 ∧ code e2393420873530 = 11189513895738 := by decide
theorem cert_e2393420873530 : check e2393420873530 [[],[.left],[.left],[.left],[]] .smaller = true := by decide
def e2393420901742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2393420901742 : Closed e2393420901742 ∧ code e2393420901742 = 11189513923950 := by decide
theorem cert_e2393420901742 : check e2393420901742 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420901750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2393420901750 : Closed e2393420901750 ∧ code e2393420901750 = 11189513923958 := by decide
theorem cert_e2393420901750 : check e2393420901750 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420901806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2393420901806 : Closed e2393420901806 ∧ code e2393420901806 = 11189513924014 := by decide
theorem cert_e2393420901806 : check e2393420901806 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420901818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2393420901818 : Closed e2393420901818 ∧ code e2393420901818 = 11189513924026 := by decide
theorem cert_e2393420901818 : check e2393420901818 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420901846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2393420901846 : Closed e2393420901846 ∧ code e2393420901846 = 11189513924054 := by decide
theorem cert_e2393420901846 : check e2393420901846 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420901850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2393420901850 : Closed e2393420901850 ∧ code e2393420901850 = 11189513924058 := by decide
theorem cert_e2393420901850 : check e2393420901850 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420902062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2393420902062 : Closed e2393420902062 ∧ code e2393420902062 = 11189513924270 := by decide
theorem cert_e2393420902062 : check e2393420902062 [[],[.left],[.left],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2393420902074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2393420902074 : Closed e2393420902074 ∧ code e2393420902074 = 11189513924282 := by decide
theorem cert_e2393420902074 : check e2393420902074 [[],[.left],[.left],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2393420902122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2393420902122 : Closed e2393420902122 ∧ code e2393420902122 = 11189513924330 := by decide
theorem cert_e2393420902122 : check e2393420902122 [[],[.left],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393420902230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2393420902230 : Closed e2393420902230 ∧ code e2393420902230 = 11189513924438 := by decide
theorem cert_e2393420902230 : check e2393420902230 [[],[.left],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393420902234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2393420902234 : Closed e2393420902234 ∧ code e2393420902234 = 11189513924442 := by decide
theorem cert_e2393420902234 : check e2393420902234 [[],[.left],[.left],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393420902250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2393420902250 : Closed e2393420902250 ∧ code e2393420902250 = 11189513924458 := by decide
theorem cert_e2393420902250 : check e2393420902250 [[],[.left],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393420902878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2393420902878 : Closed e2393420902878 ∧ code e2393420902878 = 11189513925086 := by decide
theorem cert_e2393420902878 : check e2393420902878 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420902902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2393420902902 : Closed e2393420902902 ∧ code e2393420902902 = 11189513925110 := by decide
theorem cert_e2393420902902 : check e2393420902902 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420903278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2393420903278 : Closed e2393420903278 ∧ code e2393420903278 = 11189513925486 := by decide
theorem cert_e2393420903278 : check e2393420903278 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420903286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2393420903286 : Closed e2393420903286 ∧ code e2393420903286 = 11189513925494 := by decide
theorem cert_e2393420903286 : check e2393420903286 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420903342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2393420903342 : Closed e2393420903342 ∧ code e2393420903342 = 11189513925550 := by decide
theorem cert_e2393420903342 : check e2393420903342 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420903354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2393420903354 : Closed e2393420903354 ∧ code e2393420903354 = 11189513925562 := by decide
theorem cert_e2393420903354 : check e2393420903354 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420903382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2393420903382 : Closed e2393420903382 ∧ code e2393420903382 = 11189513925590 := by decide
theorem cert_e2393420903382 : check e2393420903382 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420903386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2393420903386 : Closed e2393420903386 ∧ code e2393420903386 = 11189513925594 := by decide
theorem cert_e2393420903386 : check e2393420903386 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420903662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393420903662 : Closed e2393420903662 ∧ code e2393420903662 = 11189513925870 := by decide
theorem cert_e2393420903662 : check e2393420903662 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420903670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393420903670 : Closed e2393420903670 ∧ code e2393420903670 = 11189513925878 := by decide
theorem cert_e2393420903670 : check e2393420903670 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420903998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2393420903998 : Closed e2393420903998 ∧ code e2393420903998 = 11189513926206 := by decide
theorem cert_e2393420903998 : check e2393420903998 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420904046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393420904046 : Closed e2393420904046 ∧ code e2393420904046 = 11189513926254 := by decide
theorem cert_e2393420904046 : check e2393420904046 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420904058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393420904058 : Closed e2393420904058 ∧ code e2393420904058 = 11189513926266 := by decide
theorem cert_e2393420904058 : check e2393420904058 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420904246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393420904246 : Closed e2393420904246 ∧ code e2393420904246 = 11189513926454 := by decide
theorem cert_e2393420904246 : check e2393420904246 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420904250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393420904250 : Closed e2393420904250 ∧ code e2393420904250 = 11189513926458 := by decide
theorem cert_e2393420904250 : check e2393420904250 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420904334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2393420904334 : Closed e2393420904334 ∧ code e2393420904334 = 11189513926542 := by decide
theorem cert_e2393420904334 : check e2393420904334 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420904670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2393420904670 : Closed e2393420904670 ∧ code e2393420904670 = 11189513926878 := by decide
theorem cert_e2393420904670 : check e2393420904670 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2393420904698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2393420904698 : Closed e2393420904698 ∧ code e2393420904698 = 11189513926906 := by decide
theorem cert_e2393420904698 : check e2393420904698 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2393420904878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2393420904878 : Closed e2393420904878 ∧ code e2393420904878 = 11189513927086 := by decide
theorem cert_e2393420904878 : check e2393420904878 [[],[.left],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2393420904890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2393420904890 : Closed e2393420904890 ∧ code e2393420904890 = 11189513927098 := by decide
theorem cert_e2393420904890 : check e2393420904890 [[],[.left],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2393420904938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2393420904938 : Closed e2393420904938 ∧ code e2393420904938 = 11189513927146 := by decide
theorem cert_e2393420904938 : check e2393420904938 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393420905022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2393420905022 : Closed e2393420905022 ∧ code e2393420905022 = 11189513927230 := by decide
theorem cert_e2393420905022 : check e2393420905022 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2393420905070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393420905070 : Closed e2393420905070 ∧ code e2393420905070 = 11189513927278 := by decide
theorem cert_e2393420905070 : check e2393420905070 [[],[.left],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2393420905082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393420905082 : Closed e2393420905082 ∧ code e2393420905082 = 11189513927290 := by decide
theorem cert_e2393420905082 : check e2393420905082 [[],[.left],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2393420905370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393420905370 : Closed e2393420905370 ∧ code e2393420905370 = 11189513927578 := by decide
theorem cert_e2393420905370 : check e2393420905370 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2393420905414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2393420905414 : Closed e2393420905414 ∧ code e2393420905414 = 11189513927622 := by decide
theorem cert_e2393420905414 : check e2393420905414 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e2393420905686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2393420905686 : Closed e2393420905686 ∧ code e2393420905686 = 11189513927894 := by decide
theorem cert_e2393420905686 : check e2393420905686 [[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393420905690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2393420905690 : Closed e2393420905690 ∧ code e2393420905690 = 11189513927898 := by decide
theorem cert_e2393420905690 : check e2393420905690 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2393420905706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2393420905706 : Closed e2393420905706 ∧ code e2393420905706 = 11189513927914 := by decide
theorem cert_e2393420905706 : check e2393420905706 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2393420905782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393420905782 : Closed e2393420905782 ∧ code e2393420905782 = 11189513927990 := by decide
theorem cert_e2393420905782 : check e2393420905782 [[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393420905786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393420905786 : Closed e2393420905786 ∧ code e2393420905786 = 11189513927994 := by decide
theorem cert_e2393420905786 : check e2393420905786 [[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393420905882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393420905882 : Closed e2393420905882 ∧ code e2393420905882 = 11189513928090 := by decide
theorem cert_e2393420905882 : check e2393420905882 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2393420906038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2393420906038 : Closed e2393420906038 ∧ code e2393420906038 = 11189513928246 := by decide
theorem cert_e2393420906038 : check e2393420906038 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2393420906042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2393420906042 : Closed e2393420906042 ∧ code e2393420906042 = 11189513928250 := by decide
theorem cert_e2393420906042 : check e2393420906042 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2393420906126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2393420906126 : Closed e2393420906126 ∧ code e2393420906126 = 11189513928334 := by decide
theorem cert_e2393420906126 : check e2393420906126 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2393420906182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2393420906182 : Closed e2393420906182 ∧ code e2393420906182 = 11189513928390 := by decide
theorem cert_e2393420906182 : check e2393420906182 [[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e2393420909422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393420909422 : Closed e2393420909422 ∧ code e2393420909422 = 11189513931630 := by decide
theorem cert_e2393420909422 : check e2393420909422 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420909430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393420909430 : Closed e2393420909430 ∧ code e2393420909430 = 11189513931638 := by decide
theorem cert_e2393420909430 : check e2393420909430 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420909486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393420909486 : Closed e2393420909486 ∧ code e2393420909486 = 11189513931694 := by decide
theorem cert_e2393420909486 : check e2393420909486 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420909498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393420909498 : Closed e2393420909498 ∧ code e2393420909498 = 11189513931706 := by decide
theorem cert_e2393420909498 : check e2393420909498 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420909526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393420909526 : Closed e2393420909526 ∧ code e2393420909526 = 11189513931734 := by decide
theorem cert_e2393420909526 : check e2393420909526 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420909530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393420909530 : Closed e2393420909530 ∧ code e2393420909530 = 11189513931738 := by decide
theorem cert_e2393420909530 : check e2393420909530 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420909806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393420909806 : Closed e2393420909806 ∧ code e2393420909806 = 11189513932014 := by decide
theorem cert_e2393420909806 : check e2393420909806 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420909814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393420909814 : Closed e2393420909814 ∧ code e2393420909814 = 11189513932022 := by decide
theorem cert_e2393420909814 : check e2393420909814 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420910142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2393420910142 : Closed e2393420910142 ∧ code e2393420910142 = 11189513932350 := by decide
theorem cert_e2393420910142 : check e2393420910142 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420910190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393420910190 : Closed e2393420910190 ∧ code e2393420910190 = 11189513932398 := by decide
theorem cert_e2393420910190 : check e2393420910190 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420910202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393420910202 : Closed e2393420910202 ∧ code e2393420910202 = 11189513932410 := by decide
theorem cert_e2393420910202 : check e2393420910202 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420910390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393420910390 : Closed e2393420910390 ∧ code e2393420910390 = 11189513932598 := by decide
theorem cert_e2393420910390 : check e2393420910390 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420910394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393420910394 : Closed e2393420910394 ∧ code e2393420910394 = 11189513932602 := by decide
theorem cert_e2393420910394 : check e2393420910394 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420910478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2393420910478 : Closed e2393420910478 ∧ code e2393420910478 = 11189513932686 := by decide
theorem cert_e2393420910478 : check e2393420910478 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393420916142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2393420916142 : Closed e2393420916142 ∧ code e2393420916142 = 11189513938350 := by decide
theorem cert_e2393420916142 : check e2393420916142 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2393420916154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2393420916154 : Closed e2393420916154 ∧ code e2393420916154 = 11189513938362 := by decide
theorem cert_e2393420916154 : check e2393420916154 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2393420916202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2393420916202 : Closed e2393420916202 ∧ code e2393420916202 = 11189513938410 := by decide
theorem cert_e2393420916202 : check e2393420916202 [[],[.left],[.left],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393420916286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2393420916286 : Closed e2393420916286 ∧ code e2393420916286 = 11189513938494 := by decide
theorem cert_e2393420916286 : check e2393420916286 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2393420916334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393420916334 : Closed e2393420916334 ∧ code e2393420916334 = 11189513938542 := by decide
theorem cert_e2393420916334 : check e2393420916334 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2393420916346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393420916346 : Closed e2393420916346 ∧ code e2393420916346 = 11189513938554 := by decide
theorem cert_e2393420916346 : check e2393420916346 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393385667446
#print axioms Blc.Floor43.cert_e2393385667542
#print axioms Blc.Floor43.cert_e2393407491002
#print axioms Blc.Floor43.cert_e2393407491034
#print axioms Blc.Floor43.cert_e2393416711074
#print axioms Blc.Floor43.cert_e2393416711586
#print axioms Blc.Floor43.cert_e2393417714542
#print axioms Blc.Floor43.cert_e2393417714550
#print axioms Blc.Floor43.cert_e2393417714606
#print axioms Blc.Floor43.cert_e2393417714618
#print axioms Blc.Floor43.cert_e2393417714646
#print axioms Blc.Floor43.cert_e2393417714650
#print axioms Blc.Floor43.cert_e2393417714926
#print axioms Blc.Floor43.cert_e2393417714934
#print axioms Blc.Floor43.cert_e2393417715310
#print axioms Blc.Floor43.cert_e2393417715322
#print axioms Blc.Floor43.cert_e2393417715510
#print axioms Blc.Floor43.cert_e2393417715514
