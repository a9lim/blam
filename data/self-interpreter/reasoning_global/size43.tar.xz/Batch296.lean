import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411625804654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2411625804654 : Closed e2411625804654 ∧ code e2411625804654 = 11207718826862 := by decide
theorem cert_e2411625804654 : check e2411625804654 [[],[]] .smaller = true := by decide
def e2411625804662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2411625804662 : Closed e2411625804662 ∧ code e2411625804662 = 11207718826870 := by decide
theorem cert_e2411625804662 : check e2411625804662 [[],[]] .smaller = true := by decide
def e2411625804666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2411625804666 : Closed e2411625804666 ∧ code e2411625804666 = 11207718826874 := by decide
theorem cert_e2411625804666 : check e2411625804666 [[],[]] .three = true := by decide
def e2411625804718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2411625804718 : Closed e2411625804718 ∧ code e2411625804718 = 11207718826926 := by decide
theorem cert_e2411625804718 : check e2411625804718 [[],[]] .smaller = true := by decide
def e2411625804730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2411625804730 : Closed e2411625804730 ∧ code e2411625804730 = 11207718826938 := by decide
theorem cert_e2411625804730 : check e2411625804730 [[],[]] .smaller = true := by decide
def e2411625804758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2411625804758 : Closed e2411625804758 ∧ code e2411625804758 = 11207718826966 := by decide
theorem cert_e2411625804758 : check e2411625804758 [[],[]] .smaller = true := by decide
def e2411625804762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2411625804762 : Closed e2411625804762 ∧ code e2411625804762 = 11207718826970 := by decide
theorem cert_e2411625804762 : check e2411625804762 [[],[]] .smaller = true := by decide
def e2411625804778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2411625804778 : Closed e2411625804778 ∧ code e2411625804778 = 11207718826986 := by decide
theorem cert_e2411625804778 : check e2411625804778 [[],[]] .three = true := by decide
def e2411625805022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411625805022 : Closed e2411625805022 ∧ code e2411625805022 = 11207718827230 := by decide
theorem cert_e2411625805022 : check e2411625805022 [[],[]] .three = true := by decide
def e2411625805038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411625805038 : Closed e2411625805038 ∧ code e2411625805038 = 11207718827246 := by decide
theorem cert_e2411625805038 : check e2411625805038 [[],[]] .smaller = true := by decide
def e2411625805046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411625805046 : Closed e2411625805046 ∧ code e2411625805046 = 11207718827254 := by decide
theorem cert_e2411625805046 : check e2411625805046 [[],[]] .smaller = true := by decide
def e2411625805050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411625805050 : Closed e2411625805050 ∧ code e2411625805050 = 11207718827258 := by decide
theorem cert_e2411625805050 : check e2411625805050 [[],[]] .three = true := by decide
def e2411625805374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2411625805374 : Closed e2411625805374 ∧ code e2411625805374 = 11207718827582 := by decide
theorem cert_e2411625805374 : check e2411625805374 [[],[]] .three = true := by decide
def e2411625805422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411625805422 : Closed e2411625805422 ∧ code e2411625805422 = 11207718827630 := by decide
theorem cert_e2411625805422 : check e2411625805422 [[],[]] .smaller = true := by decide
def e2411625805434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411625805434 : Closed e2411625805434 ∧ code e2411625805434 = 11207718827642 := by decide
theorem cert_e2411625805434 : check e2411625805434 [[],[]] .smaller = true := by decide
def e2411625805598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e2411625805598 : Closed e2411625805598 ∧ code e2411625805598 = 11207718827806 := by decide
theorem cert_e2411625805598 : check e2411625805598 [[],[]] .smaller = true := by decide
def e2411625805622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625805622 : Closed e2411625805622 ∧ code e2411625805622 = 11207718827830 := by decide
theorem cert_e2411625805622 : check e2411625805622 [[],[]] .smaller = true := by decide
def e2411625805626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625805626 : Closed e2411625805626 ∧ code e2411625805626 = 11207718827834 := by decide
theorem cert_e2411625805626 : check e2411625805626 [[],[]] .smaller = true := by decide
def e2411625805710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2411625805710 : Closed e2411625805710 ∧ code e2411625805710 = 11207718827918 := by decide
theorem cert_e2411625805710 : check e2411625805710 [[],[]] .three = true := by decide
def e2411625805722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625805722 : Closed e2411625805722 ∧ code e2411625805722 = 11207718827930 := by decide
theorem cert_e2411625805722 : check e2411625805722 [[],[]] .three = true := by decide
def e2411625806046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2411625806046 : Closed e2411625806046 ∧ code e2411625806046 = 11207718828254 := by decide
theorem cert_e2411625806046 : check e2411625806046 [[],[]] .three = true := by decide
def e2411625806062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2411625806062 : Closed e2411625806062 ∧ code e2411625806062 = 11207718828270 := by decide
theorem cert_e2411625806062 : check e2411625806062 [[],[]] .smaller = true := by decide
def e2411625806070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2411625806070 : Closed e2411625806070 ∧ code e2411625806070 = 11207718828278 := by decide
theorem cert_e2411625806070 : check e2411625806070 [[],[]] .smaller = true := by decide
def e2411625806074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2411625806074 : Closed e2411625806074 ∧ code e2411625806074 = 11207718828282 := by decide
theorem cert_e2411625806074 : check e2411625806074 [[],[]] .three = true := by decide
def e2411625806262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2411625806262 : Closed e2411625806262 ∧ code e2411625806262 = 11207718828470 := by decide
theorem cert_e2411625806262 : check e2411625806262 [[],[]] .smaller = true := by decide
def e2411625806294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2411625806294 : Closed e2411625806294 ∧ code e2411625806294 = 11207718828502 := by decide
theorem cert_e2411625806294 : check e2411625806294 [[],[]] .smaller = true := by decide
def e2411625806298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2411625806298 : Closed e2411625806298 ∧ code e2411625806298 = 11207718828506 := by decide
theorem cert_e2411625806298 : check e2411625806298 [[],[]] .smaller = true := by decide
def e2411625806398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2411625806398 : Closed e2411625806398 ∧ code e2411625806398 = 11207718828606 := by decide
theorem cert_e2411625806398 : check e2411625806398 [[],[]] .three = true := by decide
def e2411625806454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411625806454 : Closed e2411625806454 ∧ code e2411625806454 = 11207718828662 := by decide
theorem cert_e2411625806454 : check e2411625806454 [[],[]] .smaller = true := by decide
def e2411625806622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2411625806622 : Closed e2411625806622 ∧ code e2411625806622 = 11207718828830 := by decide
theorem cert_e2411625806622 : check e2411625806622 [[],[]] .smaller = true := by decide
def e2411625806646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625806646 : Closed e2411625806646 ∧ code e2411625806646 = 11207718828854 := by decide
theorem cert_e2411625806646 : check e2411625806646 [[],[]] .smaller = true := by decide
def e2411625806650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625806650 : Closed e2411625806650 ∧ code e2411625806650 = 11207718828858 := by decide
theorem cert_e2411625806650 : check e2411625806650 [[],[]] .smaller = true := by decide
def e2411625806734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2411625806734 : Closed e2411625806734 ∧ code e2411625806734 = 11207718828942 := by decide
theorem cert_e2411625806734 : check e2411625806734 [[],[]] .smaller = true := by decide
def e2411625806790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2411625806790 : Closed e2411625806790 ∧ code e2411625806790 = 11207718828998 := by decide
theorem cert_e2411625806790 : check e2411625806790 [[],[]] .three = true := by decide
def e2411625806814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 3))))))))
theorem wire_e2411625806814 : Closed e2411625806814 ∧ code e2411625806814 = 11207718829022 := by decide
theorem cert_e2411625806814 : check e2411625806814 [[],[]] .three = true := by decide
def e2411625806958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411625806958 : Closed e2411625806958 ∧ code e2411625806958 = 11207718829166 := by decide
theorem cert_e2411625806958 : check e2411625806958 [[],[]] .three = true := by decide
def e2411625806966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2411625806966 : Closed e2411625806966 ∧ code e2411625806966 = 11207718829174 := by decide
theorem cert_e2411625806966 : check e2411625806966 [[],[]] .three = true := by decide
def e2411625806970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411625806970 : Closed e2411625806970 ∧ code e2411625806970 = 11207718829178 := by decide
theorem cert_e2411625806970 : check e2411625806970 [[],[]] .three = true := by decide
def e2411625807062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2411625807062 : Closed e2411625807062 ∧ code e2411625807062 = 11207718829270 := by decide
theorem cert_e2411625807062 : check e2411625807062 [[],[]] .three = true := by decide
def e2411625807066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2411625807066 : Closed e2411625807066 ∧ code e2411625807066 = 11207718829274 := by decide
theorem cert_e2411625807066 : check e2411625807066 [[],[]] .three = true := by decide
def e2411625807082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2411625807082 : Closed e2411625807082 ∧ code e2411625807082 = 11207718829290 := by decide
theorem cert_e2411625807082 : check e2411625807082 [[],[]] .three = true := by decide
def e2411625807134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411625807134 : Closed e2411625807134 ∧ code e2411625807134 = 11207718829342 := by decide
theorem cert_e2411625807134 : check e2411625807134 [[],[]] .three = true := by decide
def e2411625807158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625807158 : Closed e2411625807158 ∧ code e2411625807158 = 11207718829366 := by decide
theorem cert_e2411625807158 : check e2411625807158 [[],[]] .three = true := by decide
def e2411625807162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625807162 : Closed e2411625807162 ∧ code e2411625807162 = 11207718829370 := by decide
theorem cert_e2411625807162 : check e2411625807162 [[],[]] .three = true := by decide
def e2411625807246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2411625807246 : Closed e2411625807246 ∧ code e2411625807246 = 11207718829454 := by decide
theorem cert_e2411625807246 : check e2411625807246 [[],[]] .three = true := by decide
def e2411625807258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625807258 : Closed e2411625807258 ∧ code e2411625807258 = 11207718829466 := by decide
theorem cert_e2411625807258 : check e2411625807258 [[],[]] .three = true := by decide
def e2411625807302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411625807302 : Closed e2411625807302 ∧ code e2411625807302 = 11207718829510 := by decide
theorem cert_e2411625807302 : check e2411625807302 [[],[]] .three = true := by decide
def e2411625807326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 3))))))))
theorem wire_e2411625807326 : Closed e2411625807326 ∧ code e2411625807326 = 11207718829534 := by decide
theorem cert_e2411625807326 : check e2411625807326 [[],[]] .three = true := by decide
def e2411625807342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 2))))))))
theorem wire_e2411625807342 : Closed e2411625807342 ∧ code e2411625807342 = 11207718829550 := by decide
theorem cert_e2411625807342 : check e2411625807342 [[],[]] .three = true := by decide
def e2411625809854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2411625809854 : Closed e2411625809854 ∧ code e2411625809854 = 11207718832062 := by decide
theorem cert_e2411625809854 : check e2411625809854 [[],[]] .three = true := by decide
def e2411625809902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2411625809902 : Closed e2411625809902 ∧ code e2411625809902 = 11207718832110 := by decide
theorem cert_e2411625809902 : check e2411625809902 [[],[]] .three = true := by decide
def e2411625813726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411625813726 : Closed e2411625813726 ∧ code e2411625813726 = 11207718835934 := by decide
theorem cert_e2411625813726 : check e2411625813726 [[],[]] .three = true := by decide
def e2411625813750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411625813750 : Closed e2411625813750 ∧ code e2411625813750 = 11207718835958 := by decide
theorem cert_e2411625813750 : check e2411625813750 [[],[]] .three = true := by decide
def e2411625813854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411625813854 : Closed e2411625813854 ∧ code e2411625813854 = 11207718836062 := by decide
theorem cert_e2411625813854 : check e2411625813854 [[],[]] .three = true := by decide
def e2411625813870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e2411625813870 : Closed e2411625813870 ∧ code e2411625813870 = 11207718836078 := by decide
theorem cert_e2411625813870 : check e2411625813870 [[],[]] .smaller = true := by decide
def e2411625813878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e2411625813878 : Closed e2411625813878 ∧ code e2411625813878 = 11207718836086 := by decide
theorem cert_e2411625813878 : check e2411625813878 [[],[]] .smaller = true := by decide
def e2411625813882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411625813882 : Closed e2411625813882 ∧ code e2411625813882 = 11207718836090 := by decide
theorem cert_e2411625813882 : check e2411625813882 [[],[]] .three = true := by decide
def e2411625813942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e2411625813942 : Closed e2411625813942 ∧ code e2411625813942 = 11207718836150 := by decide
theorem cert_e2411625813942 : check e2411625813942 [[],[]] .smaller = true := by decide
def e2411625813974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411625813974 : Closed e2411625813974 ∧ code e2411625813974 = 11207718836182 := by decide
theorem cert_e2411625813974 : check e2411625813974 [[],[]] .three = true := by decide
def e2411625813978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411625813978 : Closed e2411625813978 ∧ code e2411625813978 = 11207718836186 := by decide
theorem cert_e2411625813978 : check e2411625813978 [[],[]] .three = true := by decide
def e2411625814494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411625814494 : Closed e2411625814494 ∧ code e2411625814494 = 11207718836702 := by decide
theorem cert_e2411625814494 : check e2411625814494 [[],[]] .three = true := by decide
def e2411625814518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411625814518 : Closed e2411625814518 ∧ code e2411625814518 = 11207718836726 := by decide
theorem cert_e2411625814518 : check e2411625814518 [[],[]] .three = true := by decide
def e2411625815262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411625815262 : Closed e2411625815262 ∧ code e2411625815262 = 11207718837470 := by decide
theorem cert_e2411625815262 : check e2411625815262 [[],[]] .three = true := by decide
def e2411625815278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411625815278 : Closed e2411625815278 ∧ code e2411625815278 = 11207718837486 := by decide
theorem cert_e2411625815278 : check e2411625815278 [[],[]] .smaller = true := by decide
def e2411625815286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411625815286 : Closed e2411625815286 ∧ code e2411625815286 = 11207718837494 := by decide
theorem cert_e2411625815286 : check e2411625815286 [[],[]] .smaller = true := by decide
def e2411625815290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411625815290 : Closed e2411625815290 ∧ code e2411625815290 = 11207718837498 := by decide
theorem cert_e2411625815290 : check e2411625815290 [[],[]] .three = true := by decide
def e2411625815614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2411625815614 : Closed e2411625815614 ∧ code e2411625815614 = 11207718837822 := by decide
theorem cert_e2411625815614 : check e2411625815614 [[],[]] .three = true := by decide
def e2411625815670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411625815670 : Closed e2411625815670 ∧ code e2411625815670 = 11207718837878 := by decide
theorem cert_e2411625815670 : check e2411625815670 [[],[]] .smaller = true := by decide
def e2411625815838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2411625815838 : Closed e2411625815838 ∧ code e2411625815838 = 11207718838046 := by decide
theorem cert_e2411625815838 : check e2411625815838 [[],[]] .three = true := by decide
def e2411625815862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411625815862 : Closed e2411625815862 ∧ code e2411625815862 = 11207718838070 := by decide
theorem cert_e2411625815862 : check e2411625815862 [[],[]] .three = true := by decide
def e2411625815866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411625815866 : Closed e2411625815866 ∧ code e2411625815866 = 11207718838074 := by decide
theorem cert_e2411625815866 : check e2411625815866 [[],[]] .three = true := by decide
def e2411625825214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2411625825214 : Closed e2411625825214 ∧ code e2411625825214 = 11207718847422 := by decide
theorem cert_e2411625825214 : check e2411625825214 [[],[]] .three = true := by decide
def e2411625825246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2411625825246 : Closed e2411625825246 ∧ code e2411625825246 = 11207718847454 := by decide
theorem cert_e2411625825246 : check e2411625825246 [[],[]] .smaller = true := by decide
def e2411625825262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2411625825262 : Closed e2411625825262 ∧ code e2411625825262 = 11207718847470 := by decide
theorem cert_e2411625825262 : check e2411625825262 [[],[]] .smaller = true := by decide
def e2411625825270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2411625825270 : Closed e2411625825270 ∧ code e2411625825270 = 11207718847478 := by decide
theorem cert_e2411625825270 : check e2411625825270 [[],[]] .three = true := by decide
def e2411625827166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2411625827166 : Closed e2411625827166 ∧ code e2411625827166 = 11207718849374 := by decide
theorem cert_e2411625827166 : check e2411625827166 [[],[]] .three = true := by decide
def e2411625827182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411625827182 : Closed e2411625827182 ∧ code e2411625827182 = 11207718849390 := by decide
theorem cert_e2411625827182 : check e2411625827182 [[],[]] .smaller = true := by decide
def e2411625827190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411625827190 : Closed e2411625827190 ∧ code e2411625827190 = 11207718849398 := by decide
theorem cert_e2411625827190 : check e2411625827190 [[],[]] .smaller = true := by decide
def e2411625827194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2411625827194 : Closed e2411625827194 ∧ code e2411625827194 = 11207718849402 := by decide
theorem cert_e2411625827194 : check e2411625827194 [[],[]] .three = true := by decide
def e2411625827246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411625827246 : Closed e2411625827246 ∧ code e2411625827246 = 11207718849454 := by decide
theorem cert_e2411625827246 : check e2411625827246 [[],[]] .smaller = true := by decide
def e2411625827258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411625827258 : Closed e2411625827258 ∧ code e2411625827258 = 11207718849466 := by decide
theorem cert_e2411625827258 : check e2411625827258 [[],[]] .smaller = true := by decide
def e2411625827286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411625827286 : Closed e2411625827286 ∧ code e2411625827286 = 11207718849494 := by decide
theorem cert_e2411625827286 : check e2411625827286 [[],[]] .smaller = true := by decide
def e2411625827290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411625827290 : Closed e2411625827290 ∧ code e2411625827290 = 11207718849498 := by decide
theorem cert_e2411625827290 : check e2411625827290 [[],[]] .smaller = true := by decide
def e2411625827306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2411625827306 : Closed e2411625827306 ∧ code e2411625827306 = 11207718849514 := by decide
theorem cert_e2411625827306 : check e2411625827306 [[],[]] .three = true := by decide
def e2411625827550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411625827550 : Closed e2411625827550 ∧ code e2411625827550 = 11207718849758 := by decide
theorem cert_e2411625827550 : check e2411625827550 [[],[]] .three = true := by decide
def e2411625827566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411625827566 : Closed e2411625827566 ∧ code e2411625827566 = 11207718849774 := by decide
theorem cert_e2411625827566 : check e2411625827566 [[],[]] .smaller = true := by decide
def e2411625827574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411625827574 : Closed e2411625827574 ∧ code e2411625827574 = 11207718849782 := by decide
theorem cert_e2411625827574 : check e2411625827574 [[],[]] .smaller = true := by decide
def e2411625827578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411625827578 : Closed e2411625827578 ∧ code e2411625827578 = 11207718849786 := by decide
theorem cert_e2411625827578 : check e2411625827578 [[],[]] .three = true := by decide
def e2411625827902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2411625827902 : Closed e2411625827902 ∧ code e2411625827902 = 11207718850110 := by decide
theorem cert_e2411625827902 : check e2411625827902 [[],[]] .three = true := by decide
def e2411625827950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411625827950 : Closed e2411625827950 ∧ code e2411625827950 = 11207718850158 := by decide
theorem cert_e2411625827950 : check e2411625827950 [[],[]] .smaller = true := by decide
def e2411625827962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411625827962 : Closed e2411625827962 ∧ code e2411625827962 = 11207718850170 := by decide
theorem cert_e2411625827962 : check e2411625827962 [[],[]] .smaller = true := by decide
def e2411625828126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e2411625828126 : Closed e2411625828126 ∧ code e2411625828126 = 11207718850334 := by decide
theorem cert_e2411625828126 : check e2411625828126 [[],[]] .smaller = true := by decide
def e2411625828150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411625828150 : Closed e2411625828150 ∧ code e2411625828150 = 11207718850358 := by decide
theorem cert_e2411625828150 : check e2411625828150 [[],[]] .smaller = true := by decide
def e2411625828154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411625828154 : Closed e2411625828154 ∧ code e2411625828154 = 11207718850362 := by decide
theorem cert_e2411625828154 : check e2411625828154 [[],[]] .smaller = true := by decide
def e2411625828238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2411625828238 : Closed e2411625828238 ∧ code e2411625828238 = 11207718850446 := by decide
theorem cert_e2411625828238 : check e2411625828238 [[],[]] .three = true := by decide
def e2411625828250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411625828250 : Closed e2411625828250 ∧ code e2411625828250 = 11207718850458 := by decide
theorem cert_e2411625828250 : check e2411625828250 [[],[]] .three = true := by decide
def e2411625832942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e2411625832942 : Closed e2411625832942 ∧ code e2411625832942 = 11207718855150 := by decide
theorem cert_e2411625832942 : check e2411625832942 [[],[]] .smaller = true := by decide
def e2411625833910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2411625833910 : Closed e2411625833910 ∧ code e2411625833910 = 11207718856118 := by decide
theorem cert_e2411625833910 : check e2411625833910 [[],[]] .smaller = true := by decide
def e2411625833942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2411625833942 : Closed e2411625833942 ∧ code e2411625833942 = 11207718856150 := by decide
theorem cert_e2411625833942 : check e2411625833942 [[],[]] .smaller = true := by decide
def e2411625833946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2411625833946 : Closed e2411625833946 ∧ code e2411625833946 = 11207718856154 := by decide
theorem cert_e2411625833946 : check e2411625833946 [[],[]] .smaller = true := by decide
def e2411625834046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2411625834046 : Closed e2411625834046 ∧ code e2411625834046 = 11207718856254 := by decide
theorem cert_e2411625834046 : check e2411625834046 [[],[]] .three = true := by decide
def e2411625834102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411625834102 : Closed e2411625834102 ∧ code e2411625834102 = 11207718856310 := by decide
theorem cert_e2411625834102 : check e2411625834102 [[],[]] .smaller = true := by decide
def e2411625834270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411625834270 : Closed e2411625834270 ∧ code e2411625834270 = 11207718856478 := by decide
theorem cert_e2411625834270 : check e2411625834270 [[],[]] .smaller = true := by decide
def e2411625834294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411625834294 : Closed e2411625834294 ∧ code e2411625834294 = 11207718856502 := by decide
theorem cert_e2411625834294 : check e2411625834294 [[],[]] .smaller = true := by decide
def e2411625834298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411625834298 : Closed e2411625834298 ∧ code e2411625834298 = 11207718856506 := by decide
theorem cert_e2411625834298 : check e2411625834298 [[],[]] .smaller = true := by decide
def e2411625834382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411625834382 : Closed e2411625834382 ∧ code e2411625834382 = 11207718856590 := by decide
theorem cert_e2411625834382 : check e2411625834382 [[],[]] .smaller = true := by decide
def e2411625834438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2411625834438 : Closed e2411625834438 ∧ code e2411625834438 = 11207718856646 := by decide
theorem cert_e2411625834438 : check e2411625834438 [[],[]] .three = true := by decide
def e2411625834462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 3)))))))))
theorem wire_e2411625834462 : Closed e2411625834462 ∧ code e2411625834462 = 11207718856670 := by decide
theorem cert_e2411625834462 : check e2411625834462 [[],[]] .three = true := by decide
def e2411625836782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2411625836782 : Closed e2411625836782 ∧ code e2411625836782 = 11207718858990 := by decide
theorem cert_e2411625836782 : check e2411625836782 [[],[]] .three = true := by decide
def e2411625836790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2411625836790 : Closed e2411625836790 ∧ code e2411625836790 = 11207718858998 := by decide
theorem cert_e2411625836790 : check e2411625836790 [[],[]] .three = true := by decide
def e2411625837270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411625837270 : Closed e2411625837270 ∧ code e2411625837270 = 11207718859478 := by decide
theorem cert_e2411625837270 : check e2411625837270 [[],[]] .three = true := by decide
def e2411625837274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411625837274 : Closed e2411625837274 ∧ code e2411625837274 = 11207718859482 := by decide
theorem cert_e2411625837274 : check e2411625837274 [[],[]] .three = true := by decide
def e2411625837290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411625837290 : Closed e2411625837290 ∧ code e2411625837290 = 11207718859498 := by decide
theorem cert_e2411625837290 : check e2411625837290 [[],[]] .three = true := by decide
def e2411625837342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411625837342 : Closed e2411625837342 ∧ code e2411625837342 = 11207718859550 := by decide
theorem cert_e2411625837342 : check e2411625837342 [[],[]] .three = true := by decide
def e2411625837366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411625837366 : Closed e2411625837366 ∧ code e2411625837366 = 11207718859574 := by decide
theorem cert_e2411625837366 : check e2411625837366 [[],[]] .three = true := by decide
def e2411625837370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411625837370 : Closed e2411625837370 ∧ code e2411625837370 = 11207718859578 := by decide
theorem cert_e2411625837370 : check e2411625837370 [[],[]] .three = true := by decide
def e2411625837454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2411625837454 : Closed e2411625837454 ∧ code e2411625837454 = 11207718859662 := by decide
theorem cert_e2411625837454 : check e2411625837454 [[],[]] .three = true := by decide
def e2411625837466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411625837466 : Closed e2411625837466 ∧ code e2411625837466 = 11207718859674 := by decide
theorem cert_e2411625837466 : check e2411625837466 [[],[]] .three = true := by decide
def e2411625837510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411625837510 : Closed e2411625837510 ∧ code e2411625837510 = 11207718859718 := by decide
theorem cert_e2411625837510 : check e2411625837510 [[],[]] .three = true := by decide
def e2411625837534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 3)))))))))
theorem wire_e2411625837534 : Closed e2411625837534 ∧ code e2411625837534 = 11207718859742 := by decide
theorem cert_e2411625837534 : check e2411625837534 [[],[]] .three = true := by decide
def e2411625837550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 2)))))))))
theorem wire_e2411625837550 : Closed e2411625837550 ∧ code e2411625837550 = 11207718859758 := by decide
theorem cert_e2411625837550 : check e2411625837550 [[],[]] .three = true := by decide
def e2411625983454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2411625983454 : Closed e2411625983454 ∧ code e2411625983454 = 11207719005662 := by decide
theorem cert_e2411625983454 : check e2411625983454 [[],[]] .smaller = true := by decide
def e2411625983470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2411625983470 : Closed e2411625983470 ∧ code e2411625983470 = 11207719005678 := by decide
theorem cert_e2411625983470 : check e2411625983470 [[],[]] .smaller = true := by decide
def e2411625983710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e2411625983710 : Closed e2411625983710 ∧ code e2411625983710 = 11207719005918 := by decide
theorem cert_e2411625983710 : check e2411625983710 [[],[]] .smaller = true := by decide
def e2411625983734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e2411625983734 : Closed e2411625983734 ∧ code e2411625983734 = 11207719005942 := by decide
theorem cert_e2411625983734 : check e2411625983734 [[],[]] .smaller = true := by decide
def e2411625983838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2411625983838 : Closed e2411625983838 ∧ code e2411625983838 = 11207719006046 := by decide
theorem cert_e2411625983838 : check e2411625983838 [[],[]] .smaller = true := by decide
def e2411625983866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2411625983866 : Closed e2411625983866 ∧ code e2411625983866 = 11207719006074 := by decide
theorem cert_e2411625983866 : check e2411625983866 [[],[]] .smaller = true := by decide
def e2411625983918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2411625983918 : Closed e2411625983918 ∧ code e2411625983918 = 11207719006126 := by decide
theorem cert_e2411625983918 : check e2411625983918 [[],[]] .smaller = true := by decide
def e2411625983926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e2411625983926 : Closed e2411625983926 ∧ code e2411625983926 = 11207719006134 := by decide
theorem cert_e2411625983926 : check e2411625983926 [[],[]] .smaller = true := by decide
def e2411625983930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2411625983930 : Closed e2411625983930 ∧ code e2411625983930 = 11207719006138 := by decide
theorem cert_e2411625983930 : check e2411625983930 [[],[]] .smaller = true := by decide
def e2411625984990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2411625984990 : Closed e2411625984990 ∧ code e2411625984990 = 11207719007198 := by decide
theorem cert_e2411625984990 : check e2411625984990 [[],[]] .smaller = true := by decide
def e2411625985006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2411625985006 : Closed e2411625985006 ∧ code e2411625985006 = 11207719007214 := by decide
theorem cert_e2411625985006 : check e2411625985006 [[],[]] .smaller = true := by decide
def e2411625986526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411625986526 : Closed e2411625986526 ∧ code e2411625986526 = 11207719008734 := by decide
theorem cert_e2411625986526 : check e2411625986526 [[],[]] .smaller = true := by decide
def e2411625986550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411625986550 : Closed e2411625986550 ∧ code e2411625986550 = 11207719008758 := by decide
theorem cert_e2411625986550 : check e2411625986550 [[],[]] .smaller = true := by decide
def e2411625987294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411625987294 : Closed e2411625987294 ∧ code e2411625987294 = 11207719009502 := by decide
theorem cert_e2411625987294 : check e2411625987294 [[],[]] .smaller = true := by decide
def e2411625987322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411625987322 : Closed e2411625987322 ∧ code e2411625987322 = 11207719009530 := by decide
theorem cert_e2411625987322 : check e2411625987322 [[],[]] .smaller = true := by decide
def e2411625987694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411625987694 : Closed e2411625987694 ∧ code e2411625987694 = 11207719009902 := by decide
theorem cert_e2411625987694 : check e2411625987694 [[],[]] .smaller = true := by decide
def e2411625987702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411625987702 : Closed e2411625987702 ∧ code e2411625987702 = 11207719009910 := by decide
theorem cert_e2411625987702 : check e2411625987702 [[],[]] .smaller = true := by decide
def e2411625987706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411625987706 : Closed e2411625987706 ∧ code e2411625987706 = 11207719009914 := by decide
theorem cert_e2411625987706 : check e2411625987706 [[],[]] .smaller = true := by decide
def e2411626016094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2411626016094 : Closed e2411626016094 ∧ code e2411626016094 = 11207719038302 := by decide
theorem cert_e2411626016094 : check e2411626016094 [[],[]] .three = true := by decide
def e2411626016110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2411626016110 : Closed e2411626016110 ∧ code e2411626016110 = 11207719038318 := by decide
theorem cert_e2411626016110 : check e2411626016110 [[],[]] .smaller = true := by decide
def e2411626016118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2411626016118 : Closed e2411626016118 ∧ code e2411626016118 = 11207719038326 := by decide
theorem cert_e2411626016118 : check e2411626016118 [[],[]] .smaller = true := by decide
def e2411626016122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2411626016122 : Closed e2411626016122 ∧ code e2411626016122 = 11207719038330 := by decide
theorem cert_e2411626016122 : check e2411626016122 [[],[]] .three = true := by decide
def e2411626016174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2411626016174 : Closed e2411626016174 ∧ code e2411626016174 = 11207719038382 := by decide
theorem cert_e2411626016174 : check e2411626016174 [[],[]] .smaller = true := by decide
def e2411626016186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2411626016186 : Closed e2411626016186 ∧ code e2411626016186 = 11207719038394 := by decide
theorem cert_e2411626016186 : check e2411626016186 [[],[]] .smaller = true := by decide
def e2411626016214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2411626016214 : Closed e2411626016214 ∧ code e2411626016214 = 11207719038422 := by decide
theorem cert_e2411626016214 : check e2411626016214 [[],[]] .smaller = true := by decide
def e2411626016218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2411626016218 : Closed e2411626016218 ∧ code e2411626016218 = 11207719038426 := by decide
theorem cert_e2411626016218 : check e2411626016218 [[],[]] .smaller = true := by decide
def e2411626016234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2411626016234 : Closed e2411626016234 ∧ code e2411626016234 = 11207719038442 := by decide
theorem cert_e2411626016234 : check e2411626016234 [[],[]] .three = true := by decide
def e2411626016430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2411626016430 : Closed e2411626016430 ∧ code e2411626016430 = 11207719038638 := by decide
theorem cert_e2411626016430 : check e2411626016430 [[],[]] .smaller = true := by decide
def e2411626016442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2411626016442 : Closed e2411626016442 ∧ code e2411626016442 = 11207719038650 := by decide
theorem cert_e2411626016442 : check e2411626016442 [[],[]] .smaller = true := by decide
def e2411626016490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2411626016490 : Closed e2411626016490 ∧ code e2411626016490 = 11207719038698 := by decide
theorem cert_e2411626016490 : check e2411626016490 [[],[]] .smaller = true := by decide
def e2411626016598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2411626016598 : Closed e2411626016598 ∧ code e2411626016598 = 11207719038806 := by decide
theorem cert_e2411626016598 : check e2411626016598 [[],[]] .smaller = true := by decide
def e2411626016602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2411626016602 : Closed e2411626016602 ∧ code e2411626016602 = 11207719038810 := by decide
theorem cert_e2411626016602 : check e2411626016602 [[],[]] .smaller = true := by decide
def e2411626016618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2411626016618 : Closed e2411626016618 ∧ code e2411626016618 = 11207719038826 := by decide
theorem cert_e2411626016618 : check e2411626016618 [[],[]] .smaller = true := by decide
def e2411626016682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2411626016682 : Closed e2411626016682 ∧ code e2411626016682 = 11207719038890 := by decide
theorem cert_e2411626016682 : check e2411626016682 [[],[]] .three = true := by decide
def e2411626017246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2411626017246 : Closed e2411626017246 ∧ code e2411626017246 = 11207719039454 := by decide
theorem cert_e2411626017246 : check e2411626017246 [[],[]] .three = true := by decide
def e2411626017262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2))))))))
theorem wire_e2411626017262 : Closed e2411626017262 ∧ code e2411626017262 = 11207719039470 := by decide
theorem cert_e2411626017262 : check e2411626017262 [[],[]] .smaller = true := by decide
def e2411626017270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2411626017270 : Closed e2411626017270 ∧ code e2411626017270 = 11207719039478 := by decide
theorem cert_e2411626017270 : check e2411626017270 [[],[]] .three = true := by decide
def e2411626017630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2411626017630 : Closed e2411626017630 ∧ code e2411626017630 = 11207719039838 := by decide
theorem cert_e2411626017630 : check e2411626017630 [[],[]] .three = true := by decide
def e2411626017646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2411626017646 : Closed e2411626017646 ∧ code e2411626017646 = 11207719039854 := by decide
theorem cert_e2411626017646 : check e2411626017646 [[],[]] .smaller = true := by decide
end Blc.Floor43
