import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411725155438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411725155438 : Closed e2411725155438 ∧ code e2411725155438 = 11207818177646 := by decide
theorem cert_e2411725155438 : check e2411725155438 [[],[],[]] .smaller = true := by decide
def e2411725155450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411725155450 : Closed e2411725155450 ∧ code e2411725155450 = 11207818177658 := by decide
theorem cert_e2411725155450 : check e2411725155450 [[],[],[]] .smaller = true := by decide
def e2411725155614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411725155614 : Closed e2411725155614 ∧ code e2411725155614 = 11207818177822 := by decide
theorem cert_e2411725155614 : check e2411725155614 [[],[],[]] .smaller = true := by decide
def e2411725155782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411725155782 : Closed e2411725155782 ∧ code e2411725155782 = 11207818177990 := by decide
theorem cert_e2411725155782 : check e2411725155782 [[],[],[]] .smaller = true := by decide
def e2411725155894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411725155894 : Closed e2411725155894 ∧ code e2411725155894 = 11207818178102 := by decide
theorem cert_e2411725155894 : check e2411725155894 [[],[],[]] .smaller = true := by decide
def e2411725155898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411725155898 : Closed e2411725155898 ∧ code e2411725155898 = 11207818178106 := by decide
theorem cert_e2411725155898 : check e2411725155898 [[],[],[]] .smaller = true := by decide
def e2411725155982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411725155982 : Closed e2411725155982 ∧ code e2411725155982 = 11207818178190 := by decide
theorem cert_e2411725155982 : check e2411725155982 [[],[],[]] .smaller = true := by decide
def e2411725156038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411725156038 : Closed e2411725156038 ∧ code e2411725156038 = 11207818178246 := by decide
theorem cert_e2411725156038 : check e2411725156038 [[],[],[]] .smaller = true := by decide
def e2411725156782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2411725156782 : Closed e2411725156782 ∧ code e2411725156782 = 11207818178990 := by decide
theorem cert_e2411725156782 : check e2411725156782 [[],[],[]] .smaller = true := by decide
def e2411725156794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2411725156794 : Closed e2411725156794 ∧ code e2411725156794 = 11207818179002 := by decide
theorem cert_e2411725156794 : check e2411725156794 [[],[],[]] .smaller = true := by decide
def e2411725156842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2411725156842 : Closed e2411725156842 ∧ code e2411725156842 = 11207818179050 := by decide
theorem cert_e2411725156842 : check e2411725156842 [[],[],[]] .smaller = true := by decide
def e2411725157486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411725157486 : Closed e2411725157486 ∧ code e2411725157486 = 11207818179694 := by decide
theorem cert_e2411725157486 : check e2411725157486 [[],[],[]] .smaller = true := by decide
def e2411725157498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411725157498 : Closed e2411725157498 ∧ code e2411725157498 = 11207818179706 := by decide
theorem cert_e2411725157498 : check e2411725157498 [[],[],[]] .smaller = true := by decide
def e2411725157662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411725157662 : Closed e2411725157662 ∧ code e2411725157662 = 11207818179870 := by decide
theorem cert_e2411725157662 : check e2411725157662 [[],[],[]] .smaller = true := by decide
def e2411725157830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411725157830 : Closed e2411725157830 ∧ code e2411725157830 = 11207818180038 := by decide
theorem cert_e2411725157830 : check e2411725157830 [[],[],[]] .smaller = true := by decide
def e2411725158170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411725158170 : Closed e2411725158170 ∧ code e2411725158170 = 11207818180378 := by decide
theorem cert_e2411725158170 : check e2411725158170 [[],[],[]] .smaller = true := by decide
def e2411725158214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411725158214 : Closed e2411725158214 ∧ code e2411725158214 = 11207818180422 := by decide
theorem cert_e2411725158214 : check e2411725158214 [[],[],[]] .smaller = true := by decide
def e2411725158614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2411725158614 : Closed e2411725158614 ∧ code e2411725158614 = 11207818180822 := by decide
theorem cert_e2411725158614 : check e2411725158614 [[],[],[]] .smaller = true := by decide
def e2411725158618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2411725158618 : Closed e2411725158618 ∧ code e2411725158618 = 11207818180826 := by decide
theorem cert_e2411725158618 : check e2411725158618 [[],[],[]] .smaller = true := by decide
def e2411725158634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2411725158634 : Closed e2411725158634 ∧ code e2411725158634 = 11207818180842 := by decide
theorem cert_e2411725158634 : check e2411725158634 [[],[],[]] .smaller = true := by decide
def e2411725158966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411725158966 : Closed e2411725158966 ∧ code e2411725158966 = 11207818181174 := by decide
theorem cert_e2411725158966 : check e2411725158966 [[],[],[]] .smaller = true := by decide
def e2411725158970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411725158970 : Closed e2411725158970 ∧ code e2411725158970 = 11207818181178 := by decide
theorem cert_e2411725158970 : check e2411725158970 [[],[],[]] .smaller = true := by decide
def e2411725159054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411725159054 : Closed e2411725159054 ∧ code e2411725159054 = 11207818181262 := by decide
theorem cert_e2411725159054 : check e2411725159054 [[],[],[]] .smaller = true := by decide
def e2411725159110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411725159110 : Closed e2411725159110 ∧ code e2411725159110 = 11207818181318 := by decide
theorem cert_e2411725159110 : check e2411725159110 [[],[],[]] .smaller = true := by decide
def e2411725159194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411725159194 : Closed e2411725159194 ∧ code e2411725159194 = 11207818181402 := by decide
theorem cert_e2411725159194 : check e2411725159194 [[],[],[]] .smaller = true := by decide
def e2411725159238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411725159238 : Closed e2411725159238 ∧ code e2411725159238 = 11207818181446 := by decide
theorem cert_e2411725159238 : check e2411725159238 [[],[],[]] .smaller = true := by decide
def e2411725162222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e2411725162222 : Closed e2411725162222 ∧ code e2411725162222 = 11207818184430 := by decide
theorem cert_e2411725162222 : check e2411725162222 [[],[],[]] .smaller = true := by decide
def e2411725162230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2411725162230 : Closed e2411725162230 ∧ code e2411725162230 = 11207818184438 := by decide
theorem cert_e2411725162230 : check e2411725162230 [[],[],[]] .smaller = true := by decide
def e2411725162414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e2411725162414 : Closed e2411725162414 ∧ code e2411725162414 = 11207818184622 := by decide
theorem cert_e2411725162414 : check e2411725162414 [[],[],[]] .smaller = true := by decide
def e2411725162454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2411725162454 : Closed e2411725162454 ∧ code e2411725162454 = 11207818184662 := by decide
theorem cert_e2411725162454 : check e2411725162454 [[],[],[]] .smaller = true := by decide
def e2411725163758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411725163758 : Closed e2411725163758 ∧ code e2411725163758 = 11207818185966 := by decide
theorem cert_e2411725163758 : check e2411725163758 [[],[],[]] .smaller = true := by decide
def e2411725163766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411725163766 : Closed e2411725163766 ∧ code e2411725163766 = 11207818185974 := by decide
theorem cert_e2411725163766 : check e2411725163766 [[],[],[]] .smaller = true := by decide
def e2411725164142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411725164142 : Closed e2411725164142 ∧ code e2411725164142 = 11207818186350 := by decide
theorem cert_e2411725164142 : check e2411725164142 [[],[],[]] .smaller = true := by decide
def e2411725164154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411725164154 : Closed e2411725164154 ∧ code e2411725164154 = 11207818186362 := by decide
theorem cert_e2411725164154 : check e2411725164154 [[],[],[]] .smaller = true := by decide
def e2411725164342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411725164342 : Closed e2411725164342 ∧ code e2411725164342 = 11207818186550 := by decide
theorem cert_e2411725164342 : check e2411725164342 [[],[],[]] .smaller = true := by decide
def e2411725164346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411725164346 : Closed e2411725164346 ∧ code e2411725164346 = 11207818186554 := by decide
theorem cert_e2411725164346 : check e2411725164346 [[],[],[]] .smaller = true := by decide
def e2411725166830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2411725166830 : Closed e2411725166830 ∧ code e2411725166830 = 11207818189038 := by decide
theorem cert_e2411725166830 : check e2411725166830 [[],[],[]] .smaller = true := by decide
def e2411725166838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2411725166838 : Closed e2411725166838 ∧ code e2411725166838 = 11207818189046 := by decide
theorem cert_e2411725166838 : check e2411725166838 [[],[],[]] .smaller = true := by decide
def e2411725167390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2411725167390 : Closed e2411725167390 ∧ code e2411725167390 = 11207818189598 := by decide
theorem cert_e2411725167390 : check e2411725167390 [[],[],[]] .smaller = true := by decide
def e2411725167502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2411725167502 : Closed e2411725167502 ∧ code e2411725167502 = 11207818189710 := by decide
theorem cert_e2411725167502 : check e2411725167502 [[],[],[]] .smaller = true := by decide
def e2411725167726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411725167726 : Closed e2411725167726 ∧ code e2411725167726 = 11207818189934 := by decide
theorem cert_e2411725167726 : check e2411725167726 [[],[],[]] .smaller = true := by decide
def e2411725167738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411725167738 : Closed e2411725167738 ∧ code e2411725167738 = 11207818189946 := by decide
theorem cert_e2411725167738 : check e2411725167738 [[],[],[]] .smaller = true := by decide
def e2411725167902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411725167902 : Closed e2411725167902 ∧ code e2411725167902 = 11207818190110 := by decide
theorem cert_e2411725167902 : check e2411725167902 [[],[],[]] .smaller = true := by decide
def e2411725168070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411725168070 : Closed e2411725168070 ∧ code e2411725168070 = 11207818190278 := by decide
theorem cert_e2411725168070 : check e2411725168070 [[],[],[]] .smaller = true := by decide
def e2411725168182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411725168182 : Closed e2411725168182 ∧ code e2411725168182 = 11207818190390 := by decide
theorem cert_e2411725168182 : check e2411725168182 [[],[],[]] .smaller = true := by decide
def e2411725168186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411725168186 : Closed e2411725168186 ∧ code e2411725168186 = 11207818190394 := by decide
theorem cert_e2411725168186 : check e2411725168186 [[],[],[]] .smaller = true := by decide
def e2411725168270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411725168270 : Closed e2411725168270 ∧ code e2411725168270 = 11207818190478 := by decide
theorem cert_e2411725168270 : check e2411725168270 [[],[],[]] .smaller = true := by decide
def e2411725168326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411725168326 : Closed e2411725168326 ∧ code e2411725168326 = 11207818190534 := by decide
theorem cert_e2411725168326 : check e2411725168326 [[],[],[]] .smaller = true := by decide
def e2411725170462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411725170462 : Closed e2411725170462 ∧ code e2411725170462 = 11207818192670 := by decide
theorem cert_e2411725170462 : check e2411725170462 [[],[],[]] .smaller = true := by decide
def e2411725170574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411725170574 : Closed e2411725170574 ∧ code e2411725170574 = 11207818192782 := by decide
theorem cert_e2411725170574 : check e2411725170574 [[],[],[]] .smaller = true := by decide
def e2411725172958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411725172958 : Closed e2411725172958 ∧ code e2411725172958 = 11207818195166 := by decide
theorem cert_e2411725172958 : check e2411725172958 [[],[],[]] .smaller = true := by decide
def e2411725172986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411725172986 : Closed e2411725172986 ∧ code e2411725172986 = 11207818195194 := by decide
theorem cert_e2411725172986 : check e2411725172986 [[],[],[]] .smaller = true := by decide
def e2411725173534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411725173534 : Closed e2411725173534 ∧ code e2411725173534 = 11207818195742 := by decide
theorem cert_e2411725173534 : check e2411725173534 [[],[],[]] .smaller = true := by decide
def e2411725173702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411725173702 : Closed e2411725173702 ∧ code e2411725173702 = 11207818195910 := by decide
theorem cert_e2411725173702 : check e2411725173702 [[],[],[]] .smaller = true := by decide
def e2411725174894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411725174894 : Closed e2411725174894 ∧ code e2411725174894 = 11207818197102 := by decide
theorem cert_e2411725174894 : check e2411725174894 [[],[],[]] .smaller = true := by decide
def e2411725174906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411725174906 : Closed e2411725174906 ∧ code e2411725174906 = 11207818197114 := by decide
theorem cert_e2411725174906 : check e2411725174906 [[],[],[]] .smaller = true := by decide
def e2411725175182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411725175182 : Closed e2411725175182 ∧ code e2411725175182 = 11207818197390 := by decide
theorem cert_e2411725175182 : check e2411725175182 [[],[],[]] .smaller = true := by decide
def e2411725175238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411725175238 : Closed e2411725175238 ∧ code e2411725175238 = 11207818197446 := by decide
theorem cert_e2411725175238 : check e2411725175238 [[],[],[]] .smaller = true := by decide
def e2411725177710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2411725177710 : Closed e2411725177710 ∧ code e2411725177710 = 11207818199918 := by decide
theorem cert_e2411725177710 : check e2411725177710 [[],[],[]] .smaller = true := by decide
def e2411725177722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2411725177722 : Closed e2411725177722 ∧ code e2411725177722 = 11207818199930 := by decide
theorem cert_e2411725177722 : check e2411725177722 [[],[],[]] .smaller = true := by decide
def e2411725177774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2411725177774 : Closed e2411725177774 ∧ code e2411725177774 = 11207818199982 := by decide
theorem cert_e2411725177774 : check e2411725177774 [[],[],[]] .smaller = true := by decide
def e2411725177834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2411725177834 : Closed e2411725177834 ∧ code e2411725177834 = 11207818200042 := by decide
theorem cert_e2411725177834 : check e2411725177834 [[],[],[]] .smaller = true := by decide
def e2411725178478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411725178478 : Closed e2411725178478 ∧ code e2411725178478 = 11207818200686 := by decide
theorem cert_e2411725178478 : check e2411725178478 [[],[],[]] .smaller = true := by decide
def e2411725178490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411725178490 : Closed e2411725178490 ∧ code e2411725178490 = 11207818200698 := by decide
theorem cert_e2411725178490 : check e2411725178490 [[],[],[]] .smaller = true := by decide
def e2411725178778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411725178778 : Closed e2411725178778 ∧ code e2411725178778 = 11207818200986 := by decide
theorem cert_e2411725178778 : check e2411725178778 [[],[],[]] .smaller = true := by decide
def e2411725180014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411725180014 : Closed e2411725180014 ∧ code e2411725180014 = 11207818202222 := by decide
theorem cert_e2411725180014 : check e2411725180014 [[],[],[]] .smaller = true := by decide
def e2411725180026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411725180026 : Closed e2411725180026 ∧ code e2411725180026 = 11207818202234 := by decide
theorem cert_e2411725180026 : check e2411725180026 [[],[],[]] .smaller = true := by decide
def e2411725180190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411725180190 : Closed e2411725180190 ∧ code e2411725180190 = 11207818202398 := by decide
theorem cert_e2411725180190 : check e2411725180190 [[],[],[]] .smaller = true := by decide
def e2411725180358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411725180358 : Closed e2411725180358 ∧ code e2411725180358 = 11207818202566 := by decide
theorem cert_e2411725180358 : check e2411725180358 [[],[],[]] .smaller = true := by decide
def e2411725180698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411725180698 : Closed e2411725180698 ∧ code e2411725180698 = 11207818202906 := by decide
theorem cert_e2411725180698 : check e2411725180698 [[],[],[]] .smaller = true := by decide
def e2411725180742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411725180742 : Closed e2411725180742 ∧ code e2411725180742 = 11207818202950 := by decide
theorem cert_e2411725180742 : check e2411725180742 [[],[],[]] .smaller = true := by decide
def e2411725181150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411725181150 : Closed e2411725181150 ∧ code e2411725181150 = 11207818203358 := by decide
theorem cert_e2411725181150 : check e2411725181150 [[],[],[]] .smaller = true := by decide
def e2411725181178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411725181178 : Closed e2411725181178 ∧ code e2411725181178 = 11207818203386 := by decide
theorem cert_e2411725181178 : check e2411725181178 [[],[],[]] .smaller = true := by decide
def e2411725181726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411725181726 : Closed e2411725181726 ∧ code e2411725181726 = 11207818203934 := by decide
theorem cert_e2411725181726 : check e2411725181726 [[],[],[]] .smaller = true := by decide
def e2411725181894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411725181894 : Closed e2411725181894 ∧ code e2411725181894 = 11207818204102 := by decide
theorem cert_e2411725181894 : check e2411725181894 [[],[],[]] .smaller = true := by decide
def e2411725184054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411725184054 : Closed e2411725184054 ∧ code e2411725184054 = 11207818206262 := by decide
theorem cert_e2411725184054 : check e2411725184054 [[],[],[]] .smaller = true := by decide
def e2411725184058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411725184058 : Closed e2411725184058 ∧ code e2411725184058 = 11207818206266 := by decide
theorem cert_e2411725184058 : check e2411725184058 [[],[],[]] .smaller = true := by decide
def e2411725184198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411725184198 : Closed e2411725184198 ∧ code e2411725184198 = 11207818206406 := by decide
theorem cert_e2411725184198 : check e2411725184198 [[],[],[]] .smaller = true := by decide
def e2411725185462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2411725185462 : Closed e2411725185462 ∧ code e2411725185462 = 11207818207670 := by decide
theorem cert_e2411725185462 : check e2411725185462 [[],[],[]] .smaller = true := by decide
def e2411725185466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2411725185466 : Closed e2411725185466 ∧ code e2411725185466 = 11207818207674 := by decide
theorem cert_e2411725185466 : check e2411725185466 [[],[],[]] .smaller = true := by decide
def e2411725185494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2411725185494 : Closed e2411725185494 ∧ code e2411725185494 = 11207818207702 := by decide
theorem cert_e2411725185494 : check e2411725185494 [[],[],[]] .smaller = true := by decide
def e2411725185514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2411725185514 : Closed e2411725185514 ∧ code e2411725185514 = 11207818207722 := by decide
theorem cert_e2411725185514 : check e2411725185514 [[],[],[]] .smaller = true := by decide
def e2411725185846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411725185846 : Closed e2411725185846 ∧ code e2411725185846 = 11207818208054 := by decide
theorem cert_e2411725185846 : check e2411725185846 [[],[],[]] .smaller = true := by decide
def e2411725185850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411725185850 : Closed e2411725185850 ∧ code e2411725185850 = 11207818208058 := by decide
theorem cert_e2411725185850 : check e2411725185850 [[],[],[]] .smaller = true := by decide
def e2411725185946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411725185946 : Closed e2411725185946 ∧ code e2411725185946 = 11207818208154 := by decide
theorem cert_e2411725185946 : check e2411725185946 [[],[],[]] .smaller = true := by decide
def e2411725186614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411725186614 : Closed e2411725186614 ∧ code e2411725186614 = 11207818208822 := by decide
theorem cert_e2411725186614 : check e2411725186614 [[],[],[]] .smaller = true := by decide
def e2411725186618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411725186618 : Closed e2411725186618 ∧ code e2411725186618 = 11207818208826 := by decide
theorem cert_e2411725186618 : check e2411725186618 [[],[],[]] .smaller = true := by decide
def e2411725186702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411725186702 : Closed e2411725186702 ∧ code e2411725186702 = 11207818208910 := by decide
theorem cert_e2411725186702 : check e2411725186702 [[],[],[]] .smaller = true := by decide
def e2411725186758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411725186758 : Closed e2411725186758 ∧ code e2411725186758 = 11207818208966 := by decide
theorem cert_e2411725186758 : check e2411725186758 [[],[],[]] .smaller = true := by decide
def e2411725186842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411725186842 : Closed e2411725186842 ∧ code e2411725186842 = 11207818209050 := by decide
theorem cert_e2411725186842 : check e2411725186842 [[],[],[]] .smaller = true := by decide
def e2411725186886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411725186886 : Closed e2411725186886 ∧ code e2411725186886 = 11207818209094 := by decide
theorem cert_e2411725186886 : check e2411725186886 [[],[],[]] .smaller = true := by decide
def e2411725187182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411725187182 : Closed e2411725187182 ∧ code e2411725187182 = 11207818209390 := by decide
theorem cert_e2411725187182 : check e2411725187182 [[],[],[]] .smaller = true := by decide
def e2411725187194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411725187194 : Closed e2411725187194 ∧ code e2411725187194 = 11207818209402 := by decide
theorem cert_e2411725187194 : check e2411725187194 [[],[],[]] .smaller = true := by decide
def e2411725187470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411725187470 : Closed e2411725187470 ∧ code e2411725187470 = 11207818209678 := by decide
theorem cert_e2411725187470 : check e2411725187470 [[],[],[]] .smaller = true := by decide
def e2411725187526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411725187526 : Closed e2411725187526 ∧ code e2411725187526 = 11207818209734 := by decide
theorem cert_e2411725187526 : check e2411725187526 [[],[],[]] .smaller = true := by decide
def e2411725188150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411725188150 : Closed e2411725188150 ∧ code e2411725188150 = 11207818210358 := by decide
theorem cert_e2411725188150 : check e2411725188150 [[],[],[]] .smaller = true := by decide
def e2411725188154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411725188154 : Closed e2411725188154 ∧ code e2411725188154 = 11207818210362 := by decide
theorem cert_e2411725188154 : check e2411725188154 [[],[],[]] .smaller = true := by decide
def e2411725188294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411725188294 : Closed e2411725188294 ∧ code e2411725188294 = 11207818210502 := by decide
theorem cert_e2411725188294 : check e2411725188294 [[],[],[]] .smaller = true := by decide
def e2411725199070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411725199070 : Closed e2411725199070 ∧ code e2411725199070 = 11207818221278 := by decide
theorem cert_e2411725199070 : check e2411725199070 [[],[],[]] .smaller = true := by decide
def e2411725199094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411725199094 : Closed e2411725199094 ∧ code e2411725199094 = 11207818221302 := by decide
theorem cert_e2411725199094 : check e2411725199094 [[],[],[]] .smaller = true := by decide
def e2411725199198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411725199198 : Closed e2411725199198 ∧ code e2411725199198 = 11207818221406 := by decide
theorem cert_e2411725199198 : check e2411725199198 [[],[],[]] .smaller = true := by decide
def e2411725199226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411725199226 : Closed e2411725199226 ∧ code e2411725199226 = 11207818221434 := by decide
theorem cert_e2411725199226 : check e2411725199226 [[],[],[]] .smaller = true := by decide
def e2411725199318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411725199318 : Closed e2411725199318 ∧ code e2411725199318 = 11207818221526 := by decide
theorem cert_e2411725199318 : check e2411725199318 [[],[],[]] .smaller = true := by decide
def e2411725199322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411725199322 : Closed e2411725199322 ∧ code e2411725199322 = 11207818221530 := by decide
theorem cert_e2411725199322 : check e2411725199322 [[],[],[]] .smaller = true := by decide
def e2411725199838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411725199838 : Closed e2411725199838 ∧ code e2411725199838 = 11207818222046 := by decide
theorem cert_e2411725199838 : check e2411725199838 [[],[],[]] .smaller = true := by decide
def e2411725199862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411725199862 : Closed e2411725199862 ∧ code e2411725199862 = 11207818222070 := by decide
theorem cert_e2411725199862 : check e2411725199862 [[],[],[]] .smaller = true := by decide
def e2411725200606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411725200606 : Closed e2411725200606 ∧ code e2411725200606 = 11207818222814 := by decide
theorem cert_e2411725200606 : check e2411725200606 [[],[],[]] .smaller = true := by decide
def e2411725200634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411725200634 : Closed e2411725200634 ∧ code e2411725200634 = 11207818222842 := by decide
theorem cert_e2411725200634 : check e2411725200634 [[],[],[]] .smaller = true := by decide
def e2411725200958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2411725200958 : Closed e2411725200958 ∧ code e2411725200958 = 11207818223166 := by decide
theorem cert_e2411725200958 : check e2411725200958 [[],[],[]] .smaller = true := by decide
def e2411725201182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2411725201182 : Closed e2411725201182 ∧ code e2411725201182 = 11207818223390 := by decide
theorem cert_e2411725201182 : check e2411725201182 [[],[],[]] .smaller = true := by decide
def e2411725201206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411725201206 : Closed e2411725201206 ∧ code e2411725201206 = 11207818223414 := by decide
theorem cert_e2411725201206 : check e2411725201206 [[],[],[]] .smaller = true := by decide
def e2411725201210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411725201210 : Closed e2411725201210 ∧ code e2411725201210 = 11207818223418 := by decide
theorem cert_e2411725201210 : check e2411725201210 [[],[],[]] .smaller = true := by decide
def e2411725215982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2411725215982 : Closed e2411725215982 ∧ code e2411725215982 = 11207818238190 := by decide
theorem cert_e2411725215982 : check e2411725215982 [[],[],[]] .smaller = true := by decide
def e2411725215990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2411725215990 : Closed e2411725215990 ∧ code e2411725215990 = 11207818238198 := by decide
theorem cert_e2411725215990 : check e2411725215990 [[],[],[]] .smaller = true := by decide
def e2411725216542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2411725216542 : Closed e2411725216542 ∧ code e2411725216542 = 11207818238750 := by decide
theorem cert_e2411725216542 : check e2411725216542 [[],[],[]] .smaller = true := by decide
def e2411725216654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2411725216654 : Closed e2411725216654 ∧ code e2411725216654 = 11207818238862 := by decide
theorem cert_e2411725216654 : check e2411725216654 [[],[],[]] .smaller = true := by decide
def e2411725216878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411725216878 : Closed e2411725216878 ∧ code e2411725216878 = 11207818239086 := by decide
theorem cert_e2411725216878 : check e2411725216878 [[],[],[]] .smaller = true := by decide
def e2411725216890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411725216890 : Closed e2411725216890 ∧ code e2411725216890 = 11207818239098 := by decide
theorem cert_e2411725216890 : check e2411725216890 [[],[],[]] .smaller = true := by decide
def e2411725217054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411725217054 : Closed e2411725217054 ∧ code e2411725217054 = 11207818239262 := by decide
theorem cert_e2411725217054 : check e2411725217054 [[],[],[]] .smaller = true := by decide
def e2411725217222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411725217222 : Closed e2411725217222 ∧ code e2411725217222 = 11207818239430 := by decide
theorem cert_e2411725217222 : check e2411725217222 [[],[],[]] .smaller = true := by decide
def e2411725217334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411725217334 : Closed e2411725217334 ∧ code e2411725217334 = 11207818239542 := by decide
theorem cert_e2411725217334 : check e2411725217334 [[],[],[]] .smaller = true := by decide
def e2411725217338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411725217338 : Closed e2411725217338 ∧ code e2411725217338 = 11207818239546 := by decide
theorem cert_e2411725217338 : check e2411725217338 [[],[],[]] .smaller = true := by decide
def e2411725217422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411725217422 : Closed e2411725217422 ∧ code e2411725217422 = 11207818239630 := by decide
theorem cert_e2411725217422 : check e2411725217422 [[],[],[]] .smaller = true := by decide
def e2411725217478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411725217478 : Closed e2411725217478 ∧ code e2411725217478 = 11207818239686 := by decide
theorem cert_e2411725217478 : check e2411725217478 [[],[],[]] .smaller = true := by decide
def e2411725219614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411725219614 : Closed e2411725219614 ∧ code e2411725219614 = 11207818241822 := by decide
theorem cert_e2411725219614 : check e2411725219614 [[],[],[]] .smaller = true := by decide
def e2411725219726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411725219726 : Closed e2411725219726 ∧ code e2411725219726 = 11207818241934 := by decide
theorem cert_e2411725219726 : check e2411725219726 [[],[],[]] .smaller = true := by decide
def e2411725222110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2411725222110 : Closed e2411725222110 ∧ code e2411725222110 = 11207818244318 := by decide
theorem cert_e2411725222110 : check e2411725222110 [[],[],[]] .smaller = true := by decide
def e2411725222138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2411725222138 : Closed e2411725222138 ∧ code e2411725222138 = 11207818244346 := by decide
theorem cert_e2411725222138 : check e2411725222138 [[],[],[]] .smaller = true := by decide
def e2411725222686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411725222686 : Closed e2411725222686 ∧ code e2411725222686 = 11207818244894 := by decide
theorem cert_e2411725222686 : check e2411725222686 [[],[],[]] .smaller = true := by decide
def e2411725222854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411725222854 : Closed e2411725222854 ∧ code e2411725222854 = 11207818245062 := by decide
theorem cert_e2411725222854 : check e2411725222854 [[],[],[]] .smaller = true := by decide
def e2411725224046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2411725224046 : Closed e2411725224046 ∧ code e2411725224046 = 11207818246254 := by decide
theorem cert_e2411725224046 : check e2411725224046 [[],[],[]] .smaller = true := by decide
def e2411725224058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2411725224058 : Closed e2411725224058 ∧ code e2411725224058 = 11207818246266 := by decide
theorem cert_e2411725224058 : check e2411725224058 [[],[],[]] .smaller = true := by decide
def e2411725224334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411725224334 : Closed e2411725224334 ∧ code e2411725224334 = 11207818246542 := by decide
theorem cert_e2411725224334 : check e2411725224334 [[],[],[]] .smaller = true := by decide
def e2411725224390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411725224390 : Closed e2411725224390 ∧ code e2411725224390 = 11207818246598 := by decide
theorem cert_e2411725224390 : check e2411725224390 [[],[],[]] .smaller = true := by decide
def e2411725261678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411725261678 : Closed e2411725261678 ∧ code e2411725261678 = 11207818283886 := by decide
theorem cert_e2411725261678 : check e2411725261678 [[],[],[]] .smaller = true := by decide
def e2411725261686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411725261686 : Closed e2411725261686 ∧ code e2411725261686 = 11207818283894 := by decide
theorem cert_e2411725261686 : check e2411725261686 [[],[],[]] .smaller = true := by decide
def e2411725261742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411725261742 : Closed e2411725261742 ∧ code e2411725261742 = 11207818283950 := by decide
theorem cert_e2411725261742 : check e2411725261742 [[],[],[]] .smaller = true := by decide
def e2411725261754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411725261754 : Closed e2411725261754 ∧ code e2411725261754 = 11207818283962 := by decide
theorem cert_e2411725261754 : check e2411725261754 [[],[],[]] .smaller = true := by decide
def e2411725261782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411725261782 : Closed e2411725261782 ∧ code e2411725261782 = 11207818283990 := by decide
theorem cert_e2411725261782 : check e2411725261782 [[],[],[]] .smaller = true := by decide
def e2411725261786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411725261786 : Closed e2411725261786 ∧ code e2411725261786 = 11207818283994 := by decide
theorem cert_e2411725261786 : check e2411725261786 [[],[],[]] .smaller = true := by decide
def e2411725262062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411725262062 : Closed e2411725262062 ∧ code e2411725262062 = 11207818284270 := by decide
theorem cert_e2411725262062 : check e2411725262062 [[],[],[]] .smaller = true := by decide
def e2411725262070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411725262070 : Closed e2411725262070 ∧ code e2411725262070 = 11207818284278 := by decide
theorem cert_e2411725262070 : check e2411725262070 [[],[],[]] .smaller = true := by decide
def e2411725262398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2411725262398 : Closed e2411725262398 ∧ code e2411725262398 = 11207818284606 := by decide
theorem cert_e2411725262398 : check e2411725262398 [[],[],[]] .smaller = true := by decide
def e2411725262446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411725262446 : Closed e2411725262446 ∧ code e2411725262446 = 11207818284654 := by decide
theorem cert_e2411725262446 : check e2411725262446 [[],[],[]] .smaller = true := by decide
def e2411725262458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411725262458 : Closed e2411725262458 ∧ code e2411725262458 = 11207818284666 := by decide
theorem cert_e2411725262458 : check e2411725262458 [[],[],[]] .smaller = true := by decide
def e2411725262646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411725262646 : Closed e2411725262646 ∧ code e2411725262646 = 11207818284854 := by decide
theorem cert_e2411725262646 : check e2411725262646 [[],[],[]] .smaller = true := by decide
def e2411725262650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411725262650 : Closed e2411725262650 ∧ code e2411725262650 = 11207818284858 := by decide
theorem cert_e2411725262650 : check e2411725262650 [[],[],[]] .smaller = true := by decide
def e2411725262734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2411725262734 : Closed e2411725262734 ∧ code e2411725262734 = 11207818284942 := by decide
theorem cert_e2411725262734 : check e2411725262734 [[],[],[]] .smaller = true := by decide
def e2411725270126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411725270126 : Closed e2411725270126 ∧ code e2411725270126 = 11207818292334 := by decide
theorem cert_e2411725270126 : check e2411725270126 [[],[],[]] .smaller = true := by decide
def e2411725270138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411725270138 : Closed e2411725270138 ∧ code e2411725270138 = 11207818292346 := by decide
theorem cert_e2411725270138 : check e2411725270138 [[],[],[]] .smaller = true := by decide
def e2411725270302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411725270302 : Closed e2411725270302 ∧ code e2411725270302 = 11207818292510 := by decide
theorem cert_e2411725270302 : check e2411725270302 [[],[],[]] .smaller = true := by decide
def e2411725270470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411725270470 : Closed e2411725270470 ∧ code e2411725270470 = 11207818292678 := by decide
theorem cert_e2411725270470 : check e2411725270470 [[],[],[]] .smaller = true := by decide
def e2411725270810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411725270810 : Closed e2411725270810 ∧ code e2411725270810 = 11207818293018 := by decide
theorem cert_e2411725270810 : check e2411725270810 [[],[],[]] .smaller = true := by decide
def e2411725270854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411725270854 : Closed e2411725270854 ∧ code e2411725270854 = 11207818293062 := by decide
theorem cert_e2411725270854 : check e2411725270854 [[],[],[]] .smaller = true := by decide
def e2411725271262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2411725271262 : Closed e2411725271262 ∧ code e2411725271262 = 11207818293470 := by decide
theorem cert_e2411725271262 : check e2411725271262 [[],[],[]] .smaller = true := by decide
def e2411725271290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2411725271290 : Closed e2411725271290 ∧ code e2411725271290 = 11207818293498 := by decide
theorem cert_e2411725271290 : check e2411725271290 [[],[],[]] .smaller = true := by decide
def e2411725271838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411725271838 : Closed e2411725271838 ∧ code e2411725271838 = 11207818294046 := by decide
theorem cert_e2411725271838 : check e2411725271838 [[],[],[]] .smaller = true := by decide
def e2411725272006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411725272006 : Closed e2411725272006 ∧ code e2411725272006 = 11207818294214 := by decide
theorem cert_e2411725272006 : check e2411725272006 [[],[],[]] .smaller = true := by decide
def e2411725274166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411725274166 : Closed e2411725274166 ∧ code e2411725274166 = 11207818296374 := by decide
theorem cert_e2411725274166 : check e2411725274166 [[],[],[]] .smaller = true := by decide
def e2411725274170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411725274170 : Closed e2411725274170 ∧ code e2411725274170 = 11207818296378 := by decide
theorem cert_e2411725274170 : check e2411725274170 [[],[],[]] .smaller = true := by decide
end Blc.Floor43
