import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364401978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364401978 : Closed e2422364401978 ∧ code e2422364401978 = 11218457424186 := by decide
theorem cert_e2422364401978 : check e2422364401978 [[],[]] .smaller = true := by decide
def e2422364402062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422364402062 : Closed e2422364402062 ∧ code e2422364402062 = 11218457424270 := by decide
theorem cert_e2422364402062 : check e2422364402062 [[],[]] .smaller = true := by decide
def e2422364402110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 4))))))))
theorem wire_e2422364402110 : Closed e2422364402110 ∧ code e2422364402110 = 11218457424318 := by decide
theorem cert_e2422364402110 : check e2422364402110 [[],[]] .three = true := by decide
def e2422364402118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422364402118 : Closed e2422364402118 ∧ code e2422364402118 = 11218457424326 := by decide
theorem cert_e2422364402118 : check e2422364402118 [[],[]] .smaller = true := by decide
def e2422364402170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 5))) (.var 0))))))))
theorem wire_e2422364402170 : Closed e2422364402170 ∧ code e2422364402170 = 11218457424378 := by decide
theorem cert_e2422364402170 : check e2422364402170 [[],[]] .three = true := by decide
def e2422364402454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422364402454 : Closed e2422364402454 ∧ code e2422364402454 = 11218457424662 := by decide
theorem cert_e2422364402454 : check e2422364402454 [[],[]] .smaller = true := by decide
def e2422364402526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2422364402526 : Closed e2422364402526 ∧ code e2422364402526 = 11218457424734 := by decide
theorem cert_e2422364402526 : check e2422364402526 [[],[]] .smaller = true := by decide
def e2422364402530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422364402530 : Closed e2422364402530 ∧ code e2422364402530 = 11218457424738 := by decide
theorem cert_e2422364402530 : check e2422364402530 [[],[]] .smaller = true := by decide
def e2422364402542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422364402542 : Closed e2422364402542 ∧ code e2422364402542 = 11218457424750 := by decide
theorem cert_e2422364402542 : check e2422364402542 [[],[]] .smaller = true := by decide
def e2422364402550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422364402550 : Closed e2422364402550 ∧ code e2422364402550 = 11218457424758 := by decide
theorem cert_e2422364402550 : check e2422364402550 [[],[]] .smaller = true := by decide
def e2422364402554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2422364402554 : Closed e2422364402554 ∧ code e2422364402554 = 11218457424762 := by decide
theorem cert_e2422364402554 : check e2422364402554 [[],[]] .smaller = true := by decide
def e2422364402570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364402570 : Closed e2422364402570 ∧ code e2422364402570 = 11218457424778 := by decide
theorem cert_e2422364402570 : check e2422364402570 [[],[]] .smaller = true := by decide
def e2422364402594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364402594 : Closed e2422364402594 ∧ code e2422364402594 = 11218457424802 := by decide
theorem cert_e2422364402594 : check e2422364402594 [[],[]] .smaller = true := by decide
def e2422364402606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422364402606 : Closed e2422364402606 ∧ code e2422364402606 = 11218457424814 := by decide
theorem cert_e2422364402606 : check e2422364402606 [[],[]] .smaller = true := by decide
def e2422364402614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 1))))))))
theorem wire_e2422364402614 : Closed e2422364402614 ∧ code e2422364402614 = 11218457424822 := by decide
theorem cert_e2422364402614 : check e2422364402614 [[],[]] .smaller = true := by decide
def e2422364402618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422364402618 : Closed e2422364402618 ∧ code e2422364402618 = 11218457424826 := by decide
theorem cert_e2422364402618 : check e2422364402618 [[],[]] .smaller = true := by decide
def e2422364402646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422364402646 : Closed e2422364402646 ∧ code e2422364402646 = 11218457424854 := by decide
theorem cert_e2422364402646 : check e2422364402646 [[],[]] .smaller = true := by decide
def e2422364402650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422364402650 : Closed e2422364402650 ∧ code e2422364402650 = 11218457424858 := by decide
theorem cert_e2422364402650 : check e2422364402650 [[],[]] .smaller = true := by decide
def e2422364402666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2422364402666 : Closed e2422364402666 ∧ code e2422364402666 = 11218457424874 := by decide
theorem cert_e2422364402666 : check e2422364402666 [[],[]] .smaller = true := by decide
def e2422364402718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422364402718 : Closed e2422364402718 ∧ code e2422364402718 = 11218457424926 := by decide
theorem cert_e2422364402718 : check e2422364402718 [[],[]] .smaller = true := by decide
def e2422364402814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 5)))))))))
theorem wire_e2422364402814 : Closed e2422364402814 ∧ code e2422364402814 = 11218457425022 := by decide
theorem cert_e2422364402814 : check e2422364402814 [[],[]] .three = true := by decide
def e2422364402910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364402910 : Closed e2422364402910 ∧ code e2422364402910 = 11218457425118 := by decide
theorem cert_e2422364402910 : check e2422364402910 [[],[]] .smaller = true := by decide
def e2422364402914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422364402914 : Closed e2422364402914 ∧ code e2422364402914 = 11218457425122 := by decide
theorem cert_e2422364402914 : check e2422364402914 [[],[]] .smaller = true := by decide
def e2422364402926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364402926 : Closed e2422364402926 ∧ code e2422364402926 = 11218457425134 := by decide
theorem cert_e2422364402926 : check e2422364402926 [[],[]] .smaller = true := by decide
def e2422364402934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364402934 : Closed e2422364402934 ∧ code e2422364402934 = 11218457425142 := by decide
theorem cert_e2422364402934 : check e2422364402934 [[],[]] .smaller = true := by decide
def e2422364402938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364402938 : Closed e2422364402938 ∧ code e2422364402938 = 11218457425146 := by decide
theorem cert_e2422364402938 : check e2422364402938 [[],[]] .smaller = true := by decide
def e2422364403214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364403214 : Closed e2422364403214 ∧ code e2422364403214 = 11218457425422 := by decide
theorem cert_e2422364403214 : check e2422364403214 [[],[]] .smaller = true := by decide
def e2422364403226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364403226 : Closed e2422364403226 ∧ code e2422364403226 = 11218457425434 := by decide
theorem cert_e2422364403226 : check e2422364403226 [[],[]] .smaller = true := by decide
def e2422364403298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364403298 : Closed e2422364403298 ∧ code e2422364403298 = 11218457425506 := by decide
theorem cert_e2422364403298 : check e2422364403298 [[],[]] .smaller = true := by decide
def e2422364403310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364403310 : Closed e2422364403310 ∧ code e2422364403310 = 11218457425518 := by decide
theorem cert_e2422364403310 : check e2422364403310 [[],[]] .smaller = true := by decide
def e2422364403318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364403318 : Closed e2422364403318 ∧ code e2422364403318 = 11218457425526 := by decide
theorem cert_e2422364403318 : check e2422364403318 [[],[]] .smaller = true := by decide
def e2422364403322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364403322 : Closed e2422364403322 ∧ code e2422364403322 = 11218457425530 := by decide
theorem cert_e2422364403322 : check e2422364403322 [[],[]] .smaller = true := by decide
def e2422364403510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364403510 : Closed e2422364403510 ∧ code e2422364403510 = 11218457425718 := by decide
theorem cert_e2422364403510 : check e2422364403510 [[],[]] .smaller = true := by decide
def e2422364403514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364403514 : Closed e2422364403514 ∧ code e2422364403514 = 11218457425722 := by decide
theorem cert_e2422364403514 : check e2422364403514 [[],[]] .smaller = true := by decide
def e2422364403610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364403610 : Closed e2422364403610 ∧ code e2422364403610 = 11218457425818 := by decide
theorem cert_e2422364403610 : check e2422364403610 [[],[]] .smaller = true := by decide
def e2422364403654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 4)) (.lam (.var 1)))))))))
theorem wire_e2422364403654 : Closed e2422364403654 ∧ code e2422364403654 = 11218457425862 := by decide
theorem cert_e2422364403654 : check e2422364403654 [[],[]] .three = true := by decide
def e2422364404142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422364404142 : Closed e2422364404142 ∧ code e2422364404142 = 11218457426350 := by decide
theorem cert_e2422364404142 : check e2422364404142 [[],[]] .smaller = true := by decide
def e2422364404150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2422364404150 : Closed e2422364404150 ∧ code e2422364404150 = 11218457426358 := by decide
theorem cert_e2422364404150 : check e2422364404150 [[],[]] .smaller = true := by decide
def e2422364404154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422364404154 : Closed e2422364404154 ∧ code e2422364404154 = 11218457426362 := by decide
theorem cert_e2422364404154 : check e2422364404154 [[],[]] .smaller = true := by decide
def e2422364404182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2422364404182 : Closed e2422364404182 ∧ code e2422364404182 = 11218457426390 := by decide
theorem cert_e2422364404182 : check e2422364404182 [[],[]] .smaller = true := by decide
def e2422364404186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2422364404186 : Closed e2422364404186 ∧ code e2422364404186 = 11218457426394 := by decide
theorem cert_e2422364404186 : check e2422364404186 [[],[]] .smaller = true := by decide
def e2422364404202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422364404202 : Closed e2422364404202 ∧ code e2422364404202 = 11218457426410 := by decide
theorem cert_e2422364404202 : check e2422364404202 [[],[]] .smaller = true := by decide
def e2422364404334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364404334 : Closed e2422364404334 ∧ code e2422364404334 = 11218457426542 := by decide
theorem cert_e2422364404334 : check e2422364404334 [[],[]] .smaller = true := by decide
def e2422364404342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364404342 : Closed e2422364404342 ∧ code e2422364404342 = 11218457426550 := by decide
theorem cert_e2422364404342 : check e2422364404342 [[],[]] .smaller = true := by decide
def e2422364404346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364404346 : Closed e2422364404346 ∧ code e2422364404346 = 11218457426554 := by decide
theorem cert_e2422364404346 : check e2422364404346 [[],[]] .smaller = true := by decide
def e2422364404534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364404534 : Closed e2422364404534 ∧ code e2422364404534 = 11218457426742 := by decide
theorem cert_e2422364404534 : check e2422364404534 [[],[]] .smaller = true := by decide
def e2422364404538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364404538 : Closed e2422364404538 ∧ code e2422364404538 = 11218457426746 := by decide
theorem cert_e2422364404538 : check e2422364404538 [[],[]] .smaller = true := by decide
def e2422364404634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364404634 : Closed e2422364404634 ∧ code e2422364404634 = 11218457426842 := by decide
theorem cert_e2422364404634 : check e2422364404634 [[],[]] .smaller = true := by decide
def e2422364404846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422364404846 : Closed e2422364404846 ∧ code e2422364404846 = 11218457427054 := by decide
theorem cert_e2422364404846 : check e2422364404846 [[],[]] .three = true := by decide
def e2422364404854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2422364404854 : Closed e2422364404854 ∧ code e2422364404854 = 11218457427062 := by decide
theorem cert_e2422364404854 : check e2422364404854 [[],[]] .three = true := by decide
def e2422364404858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422364404858 : Closed e2422364404858 ∧ code e2422364404858 = 11218457427066 := by decide
theorem cert_e2422364404858 : check e2422364404858 [[],[]] .three = true := by decide
def e2422364404950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422364404950 : Closed e2422364404950 ∧ code e2422364404950 = 11218457427158 := by decide
theorem cert_e2422364404950 : check e2422364404950 [[],[]] .three = true := by decide
def e2422364404954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422364404954 : Closed e2422364404954 ∧ code e2422364404954 = 11218457427162 := by decide
theorem cert_e2422364404954 : check e2422364404954 [[],[]] .three = true := by decide
def e2422364404970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422364404970 : Closed e2422364404970 ∧ code e2422364404970 = 11218457427178 := by decide
theorem cert_e2422364404970 : check e2422364404970 [[],[]] .three = true := by decide
def e2422364405022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422364405022 : Closed e2422364405022 ∧ code e2422364405022 = 11218457427230 := by decide
theorem cert_e2422364405022 : check e2422364405022 [[],[]] .three = true := by decide
def e2422364405046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364405046 : Closed e2422364405046 ∧ code e2422364405046 = 11218457427254 := by decide
theorem cert_e2422364405046 : check e2422364405046 [[],[]] .three = true := by decide
def e2422364405050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364405050 : Closed e2422364405050 ∧ code e2422364405050 = 11218457427258 := by decide
theorem cert_e2422364405050 : check e2422364405050 [[],[]] .three = true := by decide
def e2422364405134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2422364405134 : Closed e2422364405134 ∧ code e2422364405134 = 11218457427342 := by decide
theorem cert_e2422364405134 : check e2422364405134 [[],[]] .three = true := by decide
def e2422364405146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364405146 : Closed e2422364405146 ∧ code e2422364405146 = 11218457427354 := by decide
theorem cert_e2422364405146 : check e2422364405146 [[],[]] .three = true := by decide
def e2422364405182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 4))))))))
theorem wire_e2422364405182 : Closed e2422364405182 ∧ code e2422364405182 = 11218457427390 := by decide
theorem cert_e2422364405182 : check e2422364405182 [[],[]] .three = true := by decide
def e2422364405190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422364405190 : Closed e2422364405190 ∧ code e2422364405190 = 11218457427398 := by decide
theorem cert_e2422364405190 : check e2422364405190 [[],[]] .three = true := by decide
def e2422364405238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 4)) (.var 1))))))))
theorem wire_e2422364405238 : Closed e2422364405238 ∧ code e2422364405238 = 11218457427446 := by decide
theorem cert_e2422364405238 : check e2422364405238 [[],[]] .three = true := by decide
def e2422364406702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.var 2))))))))
theorem wire_e2422364406702 : Closed e2422364406702 ∧ code e2422364406702 = 11218457428910 := by decide
theorem cert_e2422364406702 : check e2422364406702 [[],[]] .smaller = true := by decide
def e2422364406714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 0))))))))
theorem wire_e2422364406714 : Closed e2422364406714 ∧ code e2422364406714 = 11218457428922 := by decide
theorem cert_e2422364406714 : check e2422364406714 [[],[]] .smaller = true := by decide
def e2422364406762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 0))))))))
theorem wire_e2422364406762 : Closed e2422364406762 ∧ code e2422364406762 = 11218457428970 := by decide
theorem cert_e2422364406762 : check e2422364406762 [[],[]] .smaller = true := by decide
def e2422364407470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))))
theorem wire_e2422364407470 : Closed e2422364407470 ∧ code e2422364407470 = 11218457429678 := by decide
theorem cert_e2422364407470 : check e2422364407470 [[],[]] .smaller = true := by decide
def e2422364407482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))))
theorem wire_e2422364407482 : Closed e2422364407482 ∧ code e2422364407482 = 11218457429690 := by decide
theorem cert_e2422364407482 : check e2422364407482 [[],[]] .smaller = true := by decide
def e2422364408238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422364408238 : Closed e2422364408238 ∧ code e2422364408238 = 11218457430446 := by decide
theorem cert_e2422364408238 : check e2422364408238 [[],[]] .smaller = true := by decide
def e2422364408250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422364408250 : Closed e2422364408250 ∧ code e2422364408250 = 11218457430458 := by decide
theorem cert_e2422364408250 : check e2422364408250 [[],[]] .smaller = true := by decide
def e2422364408298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422364408298 : Closed e2422364408298 ∧ code e2422364408298 = 11218457430506 := by decide
theorem cert_e2422364408298 : check e2422364408298 [[],[]] .smaller = true := by decide
def e2422364408430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364408430 : Closed e2422364408430 ∧ code e2422364408430 = 11218457430638 := by decide
theorem cert_e2422364408430 : check e2422364408430 [[],[]] .smaller = true := by decide
def e2422364408442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364408442 : Closed e2422364408442 ∧ code e2422364408442 = 11218457430650 := by decide
theorem cert_e2422364408442 : check e2422364408442 [[],[]] .smaller = true := by decide
def e2422364408730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364408730 : Closed e2422364408730 ∧ code e2422364408730 = 11218457430938 := by decide
theorem cert_e2422364408730 : check e2422364408730 [[],[]] .smaller = true := by decide
def e2422364408942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422364408942 : Closed e2422364408942 ∧ code e2422364408942 = 11218457431150 := by decide
theorem cert_e2422364408942 : check e2422364408942 [[],[]] .smaller = true := by decide
def e2422364408954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422364408954 : Closed e2422364408954 ∧ code e2422364408954 = 11218457431162 := by decide
theorem cert_e2422364408954 : check e2422364408954 [[],[]] .smaller = true := by decide
def e2422364409118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422364409118 : Closed e2422364409118 ∧ code e2422364409118 = 11218457431326 := by decide
theorem cert_e2422364409118 : check e2422364409118 [[],[]] .smaller = true := by decide
def e2422364409278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 4))))))))
theorem wire_e2422364409278 : Closed e2422364409278 ∧ code e2422364409278 = 11218457431486 := by decide
theorem cert_e2422364409278 : check e2422364409278 [[],[]] .three = true := by decide
def e2422364409286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422364409286 : Closed e2422364409286 ∧ code e2422364409286 = 11218457431494 := by decide
theorem cert_e2422364409286 : check e2422364409286 [[],[]] .smaller = true := by decide
def e2422364409334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 4)) (.var 1))))))))
theorem wire_e2422364409334 : Closed e2422364409334 ∧ code e2422364409334 = 11218457431542 := by decide
theorem cert_e2422364409334 : check e2422364409334 [[],[]] .three = true := by decide
def e2422364409534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 4))))))))
theorem wire_e2422364409534 : Closed e2422364409534 ∧ code e2422364409534 = 11218457431742 := by decide
theorem cert_e2422364409534 : check e2422364409534 [[],[]] .three = true := by decide
def e2422364409594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 4)) (.var 0))))))))
theorem wire_e2422364409594 : Closed e2422364409594 ∧ code e2422364409594 = 11218457431802 := by decide
theorem cert_e2422364409594 : check e2422364409594 [[],[]] .three = true := by decide
def e2422364409626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422364409626 : Closed e2422364409626 ∧ code e2422364409626 = 11218457431834 := by decide
theorem cert_e2422364409626 : check e2422364409626 [[],[]] .smaller = true := by decide
def e2422364409670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422364409670 : Closed e2422364409670 ∧ code e2422364409670 = 11218457431878 := by decide
theorem cert_e2422364409670 : check e2422364409670 [[],[]] .smaller = true := by decide
def e2422364409814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 5))) (.var 0)) (.var 1))))))))
theorem wire_e2422364409814 : Closed e2422364409814 ∧ code e2422364409814 = 11218457432022 := by decide
theorem cert_e2422364409814 : check e2422364409814 [[],[]] .three = true := by decide
def e2422364409818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 5))) (.var 1)) (.var 0))))))))
theorem wire_e2422364409818 : Closed e2422364409818 ∧ code e2422364409818 = 11218457432026 := by decide
theorem cert_e2422364409818 : check e2422364409818 [[],[]] .three = true := by decide
def e2422364412078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2))))))))
theorem wire_e2422364412078 : Closed e2422364412078 ∧ code e2422364412078 = 11218457434286 := by decide
theorem cert_e2422364412078 : check e2422364412078 [[],[]] .smaller = true := by decide
def e2422364412090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0))))))))
theorem wire_e2422364412090 : Closed e2422364412090 ∧ code e2422364412090 = 11218457434298 := by decide
theorem cert_e2422364412090 : check e2422364412090 [[],[]] .smaller = true := by decide
def e2422364412462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422364412462 : Closed e2422364412462 ∧ code e2422364412462 = 11218457434670 := by decide
theorem cert_e2422364412462 : check e2422364412462 [[],[]] .smaller = true := by decide
def e2422364412606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 4))))))))
theorem wire_e2422364412606 : Closed e2422364412606 ∧ code e2422364412606 = 11218457434814 := by decide
theorem cert_e2422364412606 : check e2422364412606 [[],[]] .three = true := by decide
def e2422364412638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 3))))))))
theorem wire_e2422364412638 : Closed e2422364412638 ∧ code e2422364412638 = 11218457434846 := by decide
theorem cert_e2422364412638 : check e2422364412638 [[],[]] .smaller = true := by decide
def e2422364412642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422364412642 : Closed e2422364412642 ∧ code e2422364412642 = 11218457434850 := by decide
theorem cert_e2422364412642 : check e2422364412642 [[],[]] .smaller = true := by decide
def e2422364412654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 2))))))))
theorem wire_e2422364412654 : Closed e2422364412654 ∧ code e2422364412654 = 11218457434862 := by decide
theorem cert_e2422364412654 : check e2422364412654 [[],[]] .smaller = true := by decide
def e2422364412662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.var 1))))))))
theorem wire_e2422364412662 : Closed e2422364412662 ∧ code e2422364412662 = 11218457434870 := by decide
theorem cert_e2422364412662 : check e2422364412662 [[],[]] .smaller = true := by decide
def e2422364412666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 4)) (.var 0))))))))
theorem wire_e2422364412666 : Closed e2422364412666 ∧ code e2422364412666 = 11218457434874 := by decide
theorem cert_e2422364412666 : check e2422364412666 [[],[]] .three = true := by decide
def e2422364412766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 3))))))))
theorem wire_e2422364412766 : Closed e2422364412766 ∧ code e2422364412766 = 11218457434974 := by decide
theorem cert_e2422364412766 : check e2422364412766 [[],[]] .smaller = true := by decide
def e2422364412782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e2422364412782 : Closed e2422364412782 ∧ code e2422364412782 = 11218457434990 := by decide
theorem cert_e2422364412782 : check e2422364412782 [[],[]] .smaller = true := by decide
def e2422364412790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e2422364412790 : Closed e2422364412790 ∧ code e2422364412790 = 11218457434998 := by decide
theorem cert_e2422364412790 : check e2422364412790 [[],[]] .smaller = true := by decide
def e2422364412794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)) (.var 0))))))))
theorem wire_e2422364412794 : Closed e2422364412794 ∧ code e2422364412794 = 11218457435002 := by decide
theorem cert_e2422364412794 : check e2422364412794 [[],[]] .smaller = true := by decide
def e2422364412810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364412810 : Closed e2422364412810 ∧ code e2422364412810 = 11218457435018 := by decide
theorem cert_e2422364412810 : check e2422364412810 [[],[]] .smaller = true := by decide
def e2422364412834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364412834 : Closed e2422364412834 ∧ code e2422364412834 = 11218457435042 := by decide
theorem cert_e2422364412834 : check e2422364412834 [[],[]] .smaller = true := by decide
def e2422364412846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e2422364412846 : Closed e2422364412846 ∧ code e2422364412846 = 11218457435054 := by decide
theorem cert_e2422364412846 : check e2422364412846 [[],[]] .smaller = true := by decide
def e2422364412854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))))
theorem wire_e2422364412854 : Closed e2422364412854 ∧ code e2422364412854 = 11218457435062 := by decide
theorem cert_e2422364412854 : check e2422364412854 [[],[]] .smaller = true := by decide
def e2422364412858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e2422364412858 : Closed e2422364412858 ∧ code e2422364412858 = 11218457435066 := by decide
theorem cert_e2422364412858 : check e2422364412858 [[],[]] .smaller = true := by decide
def e2422364412886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e2422364412886 : Closed e2422364412886 ∧ code e2422364412886 = 11218457435094 := by decide
theorem cert_e2422364412886 : check e2422364412886 [[],[]] .smaller = true := by decide
def e2422364412890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e2422364412890 : Closed e2422364412890 ∧ code e2422364412890 = 11218457435098 := by decide
theorem cert_e2422364412890 : check e2422364412890 [[],[]] .smaller = true := by decide
def e2422364412906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 0)) (.var 0))))))))
theorem wire_e2422364412906 : Closed e2422364412906 ∧ code e2422364412906 = 11218457435114 := by decide
theorem cert_e2422364412906 : check e2422364412906 [[],[]] .three = true := by decide
def e2422364413278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e2422364413278 : Closed e2422364413278 ∧ code e2422364413278 = 11218457435486 := by decide
theorem cert_e2422364413278 : check e2422364413278 [[],[]] .smaller = true := by decide
def e2422364413294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e2422364413294 : Closed e2422364413294 ∧ code e2422364413294 = 11218457435502 := by decide
theorem cert_e2422364413294 : check e2422364413294 [[],[]] .smaller = true := by decide
def e2422364413302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e2422364413302 : Closed e2422364413302 ∧ code e2422364413302 = 11218457435510 := by decide
theorem cert_e2422364413302 : check e2422364413302 [[],[]] .smaller = true := by decide
def e2422364413306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e2422364413306 : Closed e2422364413306 ∧ code e2422364413306 = 11218457435514 := by decide
theorem cert_e2422364413306 : check e2422364413306 [[],[]] .smaller = true := by decide
def e2422364413358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e2422364413358 : Closed e2422364413358 ∧ code e2422364413358 = 11218457435566 := by decide
theorem cert_e2422364413358 : check e2422364413358 [[],[]] .smaller = true := by decide
def e2422364413370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e2422364413370 : Closed e2422364413370 ∧ code e2422364413370 = 11218457435578 := by decide
theorem cert_e2422364413370 : check e2422364413370 [[],[]] .smaller = true := by decide
def e2422364413398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e2422364413398 : Closed e2422364413398 ∧ code e2422364413398 = 11218457435606 := by decide
theorem cert_e2422364413398 : check e2422364413398 [[],[]] .smaller = true := by decide
def e2422364413402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e2422364413402 : Closed e2422364413402 ∧ code e2422364413402 = 11218457435610 := by decide
theorem cert_e2422364413402 : check e2422364413402 [[],[]] .smaller = true := by decide
def e2422364413418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e2422364413418 : Closed e2422364413418 ∧ code e2422364413418 = 11218457435626 := by decide
theorem cert_e2422364413418 : check e2422364413418 [[],[]] .smaller = true := by decide
def e2422364413482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0))))))))
theorem wire_e2422364413482 : Closed e2422364413482 ∧ code e2422364413482 = 11218457435690 := by decide
theorem cert_e2422364413482 : check e2422364413482 [[],[]] .smaller = true := by decide
def e2422364413578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364413578 : Closed e2422364413578 ∧ code e2422364413578 = 11218457435786 := by decide
theorem cert_e2422364413578 : check e2422364413578 [[],[]] .smaller = true := by decide
def e2422364413602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364413602 : Closed e2422364413602 ∧ code e2422364413602 = 11218457435810 := by decide
theorem cert_e2422364413602 : check e2422364413602 [[],[]] .smaller = true := by decide
def e2422364413614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422364413614 : Closed e2422364413614 ∧ code e2422364413614 = 11218457435822 := by decide
theorem cert_e2422364413614 : check e2422364413614 [[],[]] .smaller = true := by decide
def e2422364413622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e2422364413622 : Closed e2422364413622 ∧ code e2422364413622 = 11218457435830 := by decide
theorem cert_e2422364413622 : check e2422364413622 [[],[]] .smaller = true := by decide
def e2422364413626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422364413626 : Closed e2422364413626 ∧ code e2422364413626 = 11218457435834 := by decide
theorem cert_e2422364413626 : check e2422364413626 [[],[]] .smaller = true := by decide
def e2422364413654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e2422364413654 : Closed e2422364413654 ∧ code e2422364413654 = 11218457435862 := by decide
theorem cert_e2422364413654 : check e2422364413654 [[],[]] .smaller = true := by decide
def e2422364413658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e2422364413658 : Closed e2422364413658 ∧ code e2422364413658 = 11218457435866 := by decide
theorem cert_e2422364413658 : check e2422364413658 [[],[]] .smaller = true := by decide
def e2422364413674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422364413674 : Closed e2422364413674 ∧ code e2422364413674 = 11218457435882 := by decide
theorem cert_e2422364413674 : check e2422364413674 [[],[]] .smaller = true := by decide
def e2422364413782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422364413782 : Closed e2422364413782 ∧ code e2422364413782 = 11218457435990 := by decide
theorem cert_e2422364413782 : check e2422364413782 [[],[]] .smaller = true := by decide
def e2422364413786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422364413786 : Closed e2422364413786 ∧ code e2422364413786 = 11218457435994 := by decide
theorem cert_e2422364413786 : check e2422364413786 [[],[]] .smaller = true := by decide
def e2422364413802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422364413802 : Closed e2422364413802 ∧ code e2422364413802 = 11218457436010 := by decide
theorem cert_e2422364413802 : check e2422364413802 [[],[]] .smaller = true := by decide
def e2422364413866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422364413866 : Closed e2422364413866 ∧ code e2422364413866 = 11218457436074 := by decide
theorem cert_e2422364413866 : check e2422364413866 [[],[]] .three = true := by decide
def e2422364414190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2422364414190 : Closed e2422364414190 ∧ code e2422364414190 = 11218457436398 := by decide
theorem cert_e2422364414190 : check e2422364414190 [[],[]] .smaller = true := by decide
def e2422364414202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e2422364414202 : Closed e2422364414202 ∧ code e2422364414202 = 11218457436410 := by decide
theorem cert_e2422364414202 : check e2422364414202 [[],[]] .smaller = true := by decide
def e2422364414382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422364414382 : Closed e2422364414382 ∧ code e2422364414382 = 11218457436590 := by decide
theorem cert_e2422364414382 : check e2422364414382 [[],[]] .smaller = true := by decide
def e2422364414574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364414574 : Closed e2422364414574 ∧ code e2422364414574 = 11218457436782 := by decide
theorem cert_e2422364414574 : check e2422364414574 [[],[]] .smaller = true := by decide
def e2422364414586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364414586 : Closed e2422364414586 ∧ code e2422364414586 = 11218457436794 := by decide
theorem cert_e2422364414586 : check e2422364414586 [[],[]] .smaller = true := by decide
def e2422364414750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2422364414750 : Closed e2422364414750 ∧ code e2422364414750 = 11218457436958 := by decide
theorem cert_e2422364414750 : check e2422364414750 [[],[]] .smaller = true := by decide
def e2422364414910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 4))))))))
theorem wire_e2422364414910 : Closed e2422364414910 ∧ code e2422364414910 = 11218457437118 := by decide
theorem cert_e2422364414910 : check e2422364414910 [[],[]] .three = true := by decide
def e2422364414918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e2422364414918 : Closed e2422364414918 ∧ code e2422364414918 = 11218457437126 := by decide
theorem cert_e2422364414918 : check e2422364414918 [[],[]] .smaller = true := by decide
def e2422364414966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 5))) (.var 1))))))))
theorem wire_e2422364414966 : Closed e2422364414966 ∧ code e2422364414966 = 11218457437174 := by decide
theorem cert_e2422364414966 : check e2422364414966 [[],[]] .three = true := by decide
def e2422364415534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422364415534 : Closed e2422364415534 ∧ code e2422364415534 = 11218457437742 := by decide
theorem cert_e2422364415534 : check e2422364415534 [[],[]] .smaller = true := by decide
def e2422364415678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 4))))))))
theorem wire_e2422364415678 : Closed e2422364415678 ∧ code e2422364415678 = 11218457437886 := by decide
theorem cert_e2422364415678 : check e2422364415678 [[],[]] .three = true := by decide
def e2422364415710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2422364415710 : Closed e2422364415710 ∧ code e2422364415710 = 11218457437918 := by decide
theorem cert_e2422364415710 : check e2422364415710 [[],[]] .smaller = true := by decide
def e2422364415714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422364415714 : Closed e2422364415714 ∧ code e2422364415714 = 11218457437922 := by decide
theorem cert_e2422364415714 : check e2422364415714 [[],[]] .smaller = true := by decide
def e2422364415726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e2422364415726 : Closed e2422364415726 ∧ code e2422364415726 = 11218457437934 := by decide
theorem cert_e2422364415726 : check e2422364415726 [[],[]] .smaller = true := by decide
def e2422364415734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2422364415734 : Closed e2422364415734 ∧ code e2422364415734 = 11218457437942 := by decide
theorem cert_e2422364415734 : check e2422364415734 [[],[]] .smaller = true := by decide
def e2422364415738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 4))) (.var 0))))))))
theorem wire_e2422364415738 : Closed e2422364415738 ∧ code e2422364415738 = 11218457437946 := by decide
theorem cert_e2422364415738 : check e2422364415738 [[],[]] .three = true := by decide
def e2422364415838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2422364415838 : Closed e2422364415838 ∧ code e2422364415838 = 11218457438046 := by decide
theorem cert_e2422364415838 : check e2422364415838 [[],[]] .smaller = true := by decide
def e2422364415854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e2422364415854 : Closed e2422364415854 ∧ code e2422364415854 = 11218457438062 := by decide
theorem cert_e2422364415854 : check e2422364415854 [[],[]] .smaller = true := by decide
def e2422364415862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e2422364415862 : Closed e2422364415862 ∧ code e2422364415862 = 11218457438070 := by decide
theorem cert_e2422364415862 : check e2422364415862 [[],[]] .smaller = true := by decide
def e2422364415866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2422364415866 : Closed e2422364415866 ∧ code e2422364415866 = 11218457438074 := by decide
theorem cert_e2422364415866 : check e2422364415866 [[],[]] .smaller = true := by decide
def e2422364415882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364415882 : Closed e2422364415882 ∧ code e2422364415882 = 11218457438090 := by decide
theorem cert_e2422364415882 : check e2422364415882 [[],[]] .smaller = true := by decide
def e2422364415906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364415906 : Closed e2422364415906 ∧ code e2422364415906 = 11218457438114 := by decide
theorem cert_e2422364415906 : check e2422364415906 [[],[]] .smaller = true := by decide
def e2422364415918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e2422364415918 : Closed e2422364415918 ∧ code e2422364415918 = 11218457438126 := by decide
theorem cert_e2422364415918 : check e2422364415918 [[],[]] .smaller = true := by decide
def e2422364415926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e2422364415926 : Closed e2422364415926 ∧ code e2422364415926 = 11218457438134 := by decide
theorem cert_e2422364415926 : check e2422364415926 [[],[]] .smaller = true := by decide
def e2422364415930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e2422364415930 : Closed e2422364415930 ∧ code e2422364415930 = 11218457438138 := by decide
theorem cert_e2422364415930 : check e2422364415930 [[],[]] .smaller = true := by decide
def e2422364415958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2422364415958 : Closed e2422364415958 ∧ code e2422364415958 = 11218457438166 := by decide
theorem cert_e2422364415958 : check e2422364415958 [[],[]] .smaller = true := by decide
def e2422364415962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2422364415962 : Closed e2422364415962 ∧ code e2422364415962 = 11218457438170 := by decide
theorem cert_e2422364415962 : check e2422364415962 [[],[]] .smaller = true := by decide
def e2422364415978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 0))) (.var 0))))))))
theorem wire_e2422364415978 : Closed e2422364415978 ∧ code e2422364415978 = 11218457438186 := by decide
theorem cert_e2422364415978 : check e2422364415978 [[],[]] .three = true := by decide
def e2422364416062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422364416062 : Closed e2422364416062 ∧ code e2422364416062 = 11218457438270 := by decide
theorem cert_e2422364416062 : check e2422364416062 [[],[]] .smaller = true := by decide
def e2422364416446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364416446 : Closed e2422364416446 ∧ code e2422364416446 = 11218457438654 := by decide
theorem cert_e2422364416446 : check e2422364416446 [[],[]] .three = true := by decide
def e2422364416478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364416478 : Closed e2422364416478 ∧ code e2422364416478 = 11218457438686 := by decide
theorem cert_e2422364416478 : check e2422364416478 [[],[]] .smaller = true := by decide
def e2422364416482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422364416482 : Closed e2422364416482 ∧ code e2422364416482 = 11218457438690 := by decide
theorem cert_e2422364416482 : check e2422364416482 [[],[]] .smaller = true := by decide
end Blc.Floor43
