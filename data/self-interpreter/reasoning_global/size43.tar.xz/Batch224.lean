import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393169251182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393169251182 : Closed e2393169251182 ∧ code e2393169251182 = 11189262273390 := by decide
theorem cert_e2393169251182 : check e2393169251182 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2393169251190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393169251190 : Closed e2393169251190 ∧ code e2393169251190 = 11189262273398 := by decide
theorem cert_e2393169251190 : check e2393169251190 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2393169251246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393169251246 : Closed e2393169251246 ∧ code e2393169251246 = 11189262273454 := by decide
theorem cert_e2393169251246 : check e2393169251246 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2393169251258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393169251258 : Closed e2393169251258 ∧ code e2393169251258 = 11189262273466 := by decide
theorem cert_e2393169251258 : check e2393169251258 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2393169251286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393169251286 : Closed e2393169251286 ∧ code e2393169251286 = 11189262273494 := by decide
theorem cert_e2393169251286 : check e2393169251286 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393169251290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393169251290 : Closed e2393169251290 ∧ code e2393169251290 = 11189262273498 := by decide
theorem cert_e2393169251290 : checkPay e2393169251290 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e2393169251566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393169251566 : Closed e2393169251566 ∧ code e2393169251566 = 11189262273774 := by decide
theorem cert_e2393169251566 : check e2393169251566 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2393169251574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393169251574 : Closed e2393169251574 ∧ code e2393169251574 = 11189262273782 := by decide
theorem cert_e2393169251574 : check e2393169251574 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2393169251950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393169251950 : Closed e2393169251950 ∧ code e2393169251950 = 11189262274158 := by decide
theorem cert_e2393169251950 : check e2393169251950 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2393169251962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393169251962 : Closed e2393169251962 ∧ code e2393169251962 = 11189262274170 := by decide
theorem cert_e2393169251962 : check e2393169251962 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2393169252150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393169252150 : Closed e2393169252150 ∧ code e2393169252150 = 11189262274358 := by decide
theorem cert_e2393169252150 : check e2393169252150 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2393169252154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393169252154 : Closed e2393169252154 ∧ code e2393169252154 = 11189262274362 := by decide
theorem cert_e2393169252154 : check e2393169252154 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2393169257902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2393169257902 : Closed e2393169257902 ∧ code e2393169257902 = 11189262280110 := by decide
theorem cert_e2393169257902 : check e2393169257902 [[],[.left],[]] .sourceHead = true := by decide
def e2393169257914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2393169257914 : Closed e2393169257914 ∧ code e2393169257914 = 11189262280122 := by decide
theorem cert_e2393169257914 : check e2393169257914 [[],[.left],[]] .sourceHead = true := by decide
def e2393169257962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2393169257962 : Closed e2393169257962 ∧ code e2393169257962 = 11189262280170 := by decide
theorem cert_e2393169257962 : check e2393169257962 [[],[.left],[]] .sourceHead = true := by decide
def e2393169258094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393169258094 : Closed e2393169258094 ∧ code e2393169258094 = 11189262280302 := by decide
theorem cert_e2393169258094 : check e2393169258094 [[],[.left],[]] .sourceHead = true := by decide
def e2393169258106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393169258106 : Closed e2393169258106 ∧ code e2393169258106 = 11189262280314 := by decide
theorem cert_e2393169258106 : check e2393169258106 [[],[.left],[]] .sourceHead = true := by decide
def e2393169258394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393169258394 : Closed e2393169258394 ∧ code e2393169258394 = 11189262280602 := by decide
theorem cert_e2393169258394 : check e2393169258394 [[],[.left],[]] .sourceHead = true := by decide
def e2393169261270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2393169261270 : Closed e2393169261270 ∧ code e2393169261270 = 11189262283478 := by decide
theorem cert_e2393169261270 : check e2393169261270 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2393169261274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2393169261274 : Closed e2393169261274 ∧ code e2393169261274 = 11189262283482 := by decide
theorem cert_e2393169261274 : check e2393169261274 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2393169261290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2393169261290 : Closed e2393169261290 ∧ code e2393169261290 = 11189262283498 := by decide
theorem cert_e2393169261290 : check e2393169261290 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2393169261366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393169261366 : Closed e2393169261366 ∧ code e2393169261366 = 11189262283574 := by decide
theorem cert_e2393169261366 : check e2393169261366 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2393169261370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393169261370 : Closed e2393169261370 ∧ code e2393169261370 = 11189262283578 := by decide
theorem cert_e2393169261370 : check e2393169261370 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2393169261466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393169261466 : Closed e2393169261466 ∧ code e2393169261466 = 11189262283674 := by decide
theorem cert_e2393169261466 : check e2393169261466 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2393169377006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2393169377006 : Closed e2393169377006 ∧ code e2393169377006 = 11189262399214 := by decide
theorem cert_e2393169377006 : check e2393169377006 [[],[.left],[]] .sourceHead = true := by decide
def e2393169377134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2393169377134 : Closed e2393169377134 ∧ code e2393169377134 = 11189262399342 := by decide
theorem cert_e2393169377134 : check e2393169377134 [[],[.left],[]] .sourceHead = true := by decide
def e2393169377142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2393169377142 : Closed e2393169377142 ∧ code e2393169377142 = 11189262399350 := by decide
theorem cert_e2393169377142 : check e2393169377142 [[],[.left],[]] .sourceHead = true := by decide
def e2393169378030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2393169378030 : Closed e2393169378030 ∧ code e2393169378030 = 11189262400238 := by decide
theorem cert_e2393169378030 : check e2393169378030 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393169378222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2393169378222 : Closed e2393169378222 ∧ code e2393169378222 = 11189262400430 := by decide
theorem cert_e2393169378222 : check e2393169378222 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393169378234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2393169378234 : Closed e2393169378234 ∧ code e2393169378234 = 11189262400442 := by decide
def e2393169378670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2393169378670 : Closed e2393169378670 ∧ code e2393169378670 = 11189262400878 := by decide
theorem cert_e2393169378670 : check e2393169378670 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169378678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2393169378678 : Closed e2393169378678 ∧ code e2393169378678 = 11189262400886 := by decide
theorem cert_e2393169378678 : check e2393169378678 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169378734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2393169378734 : Closed e2393169378734 ∧ code e2393169378734 = 11189262400942 := by decide
theorem cert_e2393169378734 : check e2393169378734 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393169378746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2393169378746 : Closed e2393169378746 ∧ code e2393169378746 = 11189262400954 := by decide
def e2393169378774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2393169378774 : Closed e2393169378774 ∧ code e2393169378774 = 11189262400982 := by decide
private def t_e2393169378774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e2393169378774 : ¬ IsSelfInterpreter e2393169378774 :=
  wSource (t := t_e2393169378774) (replay_sound (ps := []) (t := e2393169378774) (by decide)) (by decide)
def e2393169378778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2393169378778 : Closed e2393169378778 ∧ code e2393169378778 = 11189262400986 := by decide
private def t_e2393169378778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e2393169378778 : ¬ IsSelfInterpreter e2393169378778 :=
  wSource (t := t_e2393169378778) (replay_sound (ps := []) (t := e2393169378778) (by decide)) (by decide)
def e2393169383150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2393169383150 : Closed e2393169383150 ∧ code e2393169383150 = 11189262405358 := by decide
theorem cert_e2393169383150 : check e2393169383150 [[],[.left],[]] .sourceHead = true := by decide
def e2393169383278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2393169383278 : Closed e2393169383278 ∧ code e2393169383278 = 11189262405486 := by decide
theorem cert_e2393169383278 : check e2393169383278 [[],[.left],[]] .sourceHead = true := by decide
def e2393169383286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2393169383286 : Closed e2393169383286 ∧ code e2393169383286 = 11189262405494 := by decide
theorem cert_e2393169383286 : check e2393169383286 [[],[.left],[]] .sourceHead = true := by decide
def e2393169385966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2393169385966 : Closed e2393169385966 ∧ code e2393169385966 = 11189262408174 := by decide
theorem cert_e2393169385966 : check e2393169385966 [[],[.left],[]] .sourceHead = true := by decide
def e2393169386734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393169386734 : Closed e2393169386734 ∧ code e2393169386734 = 11189262408942 := by decide
theorem cert_e2393169386734 : check e2393169386734 [[],[.left],[]] .sourceHead = true := by decide
def e2393169386742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393169386742 : Closed e2393169386742 ∧ code e2393169386742 = 11189262408950 := by decide
theorem cert_e2393169386742 : check e2393169386742 [[],[.left],[]] .sourceHead = true := by decide
def e2393169389294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2393169389294 : Closed e2393169389294 ∧ code e2393169389294 = 11189262411502 := by decide
theorem cert_e2393169389294 : check e2393169389294 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169389486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2393169389486 : Closed e2393169389486 ∧ code e2393169389486 = 11189262411694 := by decide
theorem cert_e2393169389486 : check e2393169389486 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169389498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2393169389498 : Closed e2393169389498 ∧ code e2393169389498 = 11189262411706 := by decide
def e2393169390062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2393169390062 : Closed e2393169390062 ∧ code e2393169390062 = 11189262412270 := by decide
theorem cert_e2393169390062 : check e2393169390062 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169391214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393169391214 : Closed e2393169391214 ∧ code e2393169391214 = 11189262413422 := by decide
theorem cert_e2393169391214 : check e2393169391214 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169391226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393169391226 : Closed e2393169391226 ∧ code e2393169391226 = 11189262413434 := by decide
theorem cert_e2393169391226 : check e2393169391226 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393169392494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2393169392494 : Closed e2393169392494 ∧ code e2393169392494 = 11189262414702 := by decide
theorem cert_e2393169392494 : check e2393169392494 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169392502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2393169392502 : Closed e2393169392502 ∧ code e2393169392502 = 11189262414710 := by decide
theorem cert_e2393169392502 : check e2393169392502 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169392558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2393169392558 : Closed e2393169392558 ∧ code e2393169392558 = 11189262414766 := by decide
theorem cert_e2393169392558 : check e2393169392558 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393169392570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2393169392570 : Closed e2393169392570 ∧ code e2393169392570 = 11189262414778 := by decide
theorem cert_e2393169392570 : check e2393169392570 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393169392598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2393169392598 : Closed e2393169392598 ∧ code e2393169392598 = 11189262414806 := by decide
theorem cert_e2393169392598 : checkPay e2393169392598 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.right],[.right,.under,.under,.left],[.right,.under,.under],[.right,.under,.under,.under,.left,.left],[.right,.under,.under,.under,.left],[.right,.under,.under,.under],[.right,.under,.under,.under,.right,.left],[.right,.under,.under,.under,.right]] = true := by decide
def e2393169392602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2393169392602 : Closed e2393169392602 ∧ code e2393169392602 = 11189262414810 := by decide
theorem cert_e2393169392602 : check e2393169392602 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393169392878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393169392878 : Closed e2393169392878 ∧ code e2393169392878 = 11189262415086 := by decide
theorem cert_e2393169392878 : checkPay e2393169392878 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393169392886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393169392886 : Closed e2393169392886 ∧ code e2393169392886 = 11189262415094 := by decide
theorem cert_e2393169392886 : checkPay e2393169392886 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393169393262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393169393262 : Closed e2393169393262 ∧ code e2393169393262 = 11189262415470 := by decide
theorem cert_e2393169393262 : check e2393169393262 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393169393274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393169393274 : Closed e2393169393274 ∧ code e2393169393274 = 11189262415482 := by decide
theorem cert_e2393169393274 : check e2393169393274 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393169393462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393169393462 : Closed e2393169393462 ∧ code e2393169393462 = 11189262415670 := by decide
private def t_e2393169393462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e2393169393462 : ¬ IsSelfInterpreter e2393169393462 :=
  wSource (t := t_e2393169393462) (replay_sound (ps := []) (t := e2393169393462) (by decide)) (by decide)
def e2393169393466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393169393466 : Closed e2393169393466 ∧ code e2393169393466 = 11189262415674 := by decide
private def t_e2393169393466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e2393169393466 : ¬ IsSelfInterpreter e2393169393466 :=
  wSource (t := t_e2393169393466) (replay_sound (ps := []) (t := e2393169393466) (by decide)) (by decide)
def e2393169398638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393169398638 : Closed e2393169398638 ∧ code e2393169398638 = 11189262420846 := by decide
theorem cert_e2393169398638 : check e2393169398638 [[],[.left],[]] .sourceHead = true := by decide
def e2393169398646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393169398646 : Closed e2393169398646 ∧ code e2393169398646 = 11189262420854 := by decide
theorem cert_e2393169398646 : check e2393169398646 [[],[.left],[]] .sourceHead = true := by decide
def e2393169398702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393169398702 : Closed e2393169398702 ∧ code e2393169398702 = 11189262420910 := by decide
theorem cert_e2393169398702 : check e2393169398702 [[],[.left],[]] .sourceHead = true := by decide
def e2393169398714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393169398714 : Closed e2393169398714 ∧ code e2393169398714 = 11189262420922 := by decide
theorem cert_e2393169398714 : check e2393169398714 [[],[.left],[]] .sourceHead = true := by decide
def e2393169398742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393169398742 : Closed e2393169398742 ∧ code e2393169398742 = 11189262420950 := by decide
theorem cert_e2393169398742 : check e2393169398742 [[],[.left],[]] .sourceHead = true := by decide
def e2393169398746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393169398746 : Closed e2393169398746 ∧ code e2393169398746 = 11189262420954 := by decide
theorem cert_e2393169398746 : check e2393169398746 [[],[.left],[]] .sourceHead = true := by decide
def e2393169399022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393169399022 : Closed e2393169399022 ∧ code e2393169399022 = 11189262421230 := by decide
theorem cert_e2393169399022 : check e2393169399022 [[],[.left],[]] .sourceHead = true := by decide
def e2393169399030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393169399030 : Closed e2393169399030 ∧ code e2393169399030 = 11189262421238 := by decide
theorem cert_e2393169399030 : check e2393169399030 [[],[.left],[]] .sourceHead = true := by decide
def e2393169399406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393169399406 : Closed e2393169399406 ∧ code e2393169399406 = 11189262421614 := by decide
theorem cert_e2393169399406 : check e2393169399406 [[],[.left],[]] .sourceHead = true := by decide
def e2393169399418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393169399418 : Closed e2393169399418 ∧ code e2393169399418 = 11189262421626 := by decide
theorem cert_e2393169399418 : check e2393169399418 [[],[.left],[]] .sourceHead = true := by decide
def e2393169399606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393169399606 : Closed e2393169399606 ∧ code e2393169399606 = 11189262421814 := by decide
theorem cert_e2393169399606 : check e2393169399606 [[],[.left],[]] .sourceHead = true := by decide
def e2393169399610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393169399610 : Closed e2393169399610 ∧ code e2393169399610 = 11189262421818 := by decide
theorem cert_e2393169399610 : check e2393169399610 [[],[.left],[]] .sourceHead = true := by decide
def e2393169407726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2393169407726 : Closed e2393169407726 ∧ code e2393169407726 = 11189262429934 := by decide
theorem cert_e2393169407726 : check e2393169407726 [[],[.left],[]] .sourceHead = true := by decide
def e2393169407854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2393169407854 : Closed e2393169407854 ∧ code e2393169407854 = 11189262430062 := by decide
theorem cert_e2393169407854 : check e2393169407854 [[],[.left],[]] .sourceHead = true := by decide
def e2393169407862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2393169407862 : Closed e2393169407862 ∧ code e2393169407862 = 11189262430070 := by decide
theorem cert_e2393169407862 : check e2393169407862 [[],[.left],[]] .sourceHead = true := by decide
def e2393169410542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2393169410542 : Closed e2393169410542 ∧ code e2393169410542 = 11189262432750 := by decide
theorem cert_e2393169410542 : check e2393169410542 [[],[.left],[]] .sourceHead = true := by decide
def e2393169411310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2393169411310 : Closed e2393169411310 ∧ code e2393169411310 = 11189262433518 := by decide
theorem cert_e2393169411310 : check e2393169411310 [[],[.left],[]] .sourceHead = true := by decide
def e2393169411318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2393169411318 : Closed e2393169411318 ∧ code e2393169411318 = 11189262433526 := by decide
theorem cert_e2393169411318 : check e2393169411318 [[],[.left],[]] .sourceHead = true := by decide
def e2393169434350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2393169434350 : Closed e2393169434350 ∧ code e2393169434350 = 11189262456558 := by decide
theorem cert_e2393169434350 : check e2393169434350 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169434542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2393169434542 : Closed e2393169434542 ∧ code e2393169434542 = 11189262456750 := by decide
theorem cert_e2393169434542 : check e2393169434542 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2393169434554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2393169434554 : Closed e2393169434554 ∧ code e2393169434554 = 11189262456762 := by decide
theorem cert_e2393169434554 : check e2393169434554 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393169435118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2393169435118 : Closed e2393169435118 ∧ code e2393169435118 = 11189262457326 := by decide
theorem cert_e2393169435118 : checkPay e2393169435118 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [[],[.left,.left],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] = true := by decide
def e2393169436270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2393169436270 : Closed e2393169436270 ∧ code e2393169436270 = 11189262458478 := by decide
theorem cert_e2393169436270 : check e2393169436270 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393169436282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2393169436282 : Closed e2393169436282 ∧ code e2393169436282 = 11189262458490 := by decide
theorem cert_e2393169436282 : check e2393169436282 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393169447790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393169447790 : Closed e2393169447790 ∧ code e2393169447790 = 11189262469998 := by decide
theorem cert_e2393169447790 : check e2393169447790 [[],[.left],[],[.under]] .three = true := by decide
def e2393169447798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393169447798 : Closed e2393169447798 ∧ code e2393169447798 = 11189262470006 := by decide
theorem cert_e2393169447798 : check e2393169447798 [[],[.left],[],[.under]] .three = true := by decide
def e2393169447854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393169447854 : Closed e2393169447854 ∧ code e2393169447854 = 11189262470062 := by decide
theorem cert_e2393169447854 : check e2393169447854 [[],[.left],[],[.under]] .three = true := by decide
def e2393169447866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393169447866 : Closed e2393169447866 ∧ code e2393169447866 = 11189262470074 := by decide
theorem cert_e2393169447866 : check e2393169447866 [[],[.left],[],[.under]] .three = true := by decide
def e2393169447894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393169447894 : Closed e2393169447894 ∧ code e2393169447894 = 11189262470102 := by decide
theorem cert_e2393169447894 : check e2393169447894 [[],[.left],[],[.under]] .three = true := by decide
def e2393169447898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393169447898 : Closed e2393169447898 ∧ code e2393169447898 = 11189262470106 := by decide
theorem cert_e2393169447898 : check e2393169447898 [[],[.left],[],[.under]] .three = true := by decide
def e2393169448174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393169448174 : Closed e2393169448174 ∧ code e2393169448174 = 11189262470382 := by decide
theorem cert_e2393169448174 : check e2393169448174 [[],[.left],[],[.under]] .three = true := by decide
def e2393169448182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393169448182 : Closed e2393169448182 ∧ code e2393169448182 = 11189262470390 := by decide
theorem cert_e2393169448182 : check e2393169448182 [[],[.left],[],[.under]] .three = true := by decide
def e2393169448558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393169448558 : Closed e2393169448558 ∧ code e2393169448558 = 11189262470766 := by decide
theorem cert_e2393169448558 : check e2393169448558 [[],[.left],[],[.under]] .three = true := by decide
def e2393169448570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393169448570 : Closed e2393169448570 ∧ code e2393169448570 = 11189262470778 := by decide
theorem cert_e2393169448570 : check e2393169448570 [[],[.left],[],[.under]] .three = true := by decide
def e2393169448758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393169448758 : Closed e2393169448758 ∧ code e2393169448758 = 11189262470966 := by decide
theorem cert_e2393169448758 : check e2393169448758 [[],[.left],[],[.under]] .three = true := by decide
def e2393169448762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393169448762 : Closed e2393169448762 ∧ code e2393169448762 = 11189262470970 := by decide
theorem cert_e2393169448762 : check e2393169448762 [[],[.left],[],[.under]] .three = true := by decide
def e2393169988462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393169988462 : Closed e2393169988462 ∧ code e2393169988462 = 11189263010670 := by decide
theorem cert_e2393169988462 : check e2393169988462 [[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2393169988470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393169988470 : Closed e2393169988470 ∧ code e2393169988470 = 11189263010678 := by decide
theorem cert_e2393169988470 : check e2393169988470 [[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2393169988526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393169988526 : Closed e2393169988526 ∧ code e2393169988526 = 11189263010734 := by decide
theorem cert_e2393169988526 : check e2393169988526 [[],[.left],[],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169988538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393169988538 : Closed e2393169988538 ∧ code e2393169988538 = 11189263010746 := by decide
def e2393169988566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393169988566 : Closed e2393169988566 ∧ code e2393169988566 = 11189263010774 := by decide
theorem cert_e2393169988566 : check e2393169988566 [[],[.left],[],[.left],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393169988570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393169988570 : Closed e2393169988570 ∧ code e2393169988570 = 11189263010778 := by decide
def e2393169988846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393169988846 : Closed e2393169988846 ∧ code e2393169988846 = 11189263011054 := by decide
theorem cert_e2393169988846 : check e2393169988846 [[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2393169988854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393169988854 : Closed e2393169988854 ∧ code e2393169988854 = 11189263011062 := by decide
theorem cert_e2393169988854 : check e2393169988854 [[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2393169989230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393169989230 : Closed e2393169989230 ∧ code e2393169989230 = 11189263011438 := by decide
theorem cert_e2393169989230 : checkPay e2393169989230 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[]] = true := by decide
def e2393169989242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393169989242 : Closed e2393169989242 ∧ code e2393169989242 = 11189263011450 := by decide
theorem cert_e2393169989242 : checkPay e2393169989242 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left]] 0 [] = true := by decide
def e2393169989430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393169989430 : Closed e2393169989430 ∧ code e2393169989430 = 11189263011638 := by decide
theorem cert_e2393169989430 : check e2393169989430 [[],[.left],[],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393169989434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393169989434 : Closed e2393169989434 ∧ code e2393169989434 = 11189263011642 := by decide
theorem cert_e2393169989434 : check e2393169989434 [[],[.left],[],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under],[.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393370570094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2393370570094 : Closed e2393370570094 ∧ code e2393370570094 = 11189463592302 := by decide
theorem cert_e2393370570094 : check e2393370570094 [[],[.left],[]] .smaller = true := by decide
def e2393370570102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2393370570102 : Closed e2393370570102 ∧ code e2393370570102 = 11189463592310 := by decide
theorem cert_e2393370570102 : check e2393370570102 [[],[.left],[]] .smaller = true := by decide
def e2393370570158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2393370570158 : Closed e2393370570158 ∧ code e2393370570158 = 11189463592366 := by decide
theorem cert_e2393370570158 : check e2393370570158 [[],[.left],[]] .smaller = true := by decide
def e2393370570170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2393370570170 : Closed e2393370570170 ∧ code e2393370570170 = 11189463592378 := by decide
theorem cert_e2393370570170 : check e2393370570170 [[],[.left],[]] .smaller = true := by decide
def e2393370570198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2393370570198 : Closed e2393370570198 ∧ code e2393370570198 = 11189463592406 := by decide
theorem cert_e2393370570198 : check e2393370570198 [[],[.left],[]] .smaller = true := by decide
def e2393370570202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2393370570202 : Closed e2393370570202 ∧ code e2393370570202 = 11189463592410 := by decide
theorem cert_e2393370570202 : check e2393370570202 [[],[.left],[]] .smaller = true := by decide
def e2393370570414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2393370570414 : Closed e2393370570414 ∧ code e2393370570414 = 11189463592622 := by decide
theorem cert_e2393370570414 : check e2393370570414 [[],[.left],[]] .smaller = true := by decide
def e2393370570426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2393370570426 : Closed e2393370570426 ∧ code e2393370570426 = 11189463592634 := by decide
theorem cert_e2393370570426 : check e2393370570426 [[],[.left],[]] .smaller = true := by decide
def e2393370570474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2393370570474 : Closed e2393370570474 ∧ code e2393370570474 = 11189463592682 := by decide
theorem cert_e2393370570474 : check e2393370570474 [[],[.left],[]] .smaller = true := by decide
def e2393370570582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2393370570582 : Closed e2393370570582 ∧ code e2393370570582 = 11189463592790 := by decide
theorem cert_e2393370570582 : check e2393370570582 [[],[.left],[]] .smaller = true := by decide
def e2393370570586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2393370570586 : Closed e2393370570586 ∧ code e2393370570586 = 11189463592794 := by decide
theorem cert_e2393370570586 : check e2393370570586 [[],[.left],[]] .smaller = true := by decide
def e2393370570602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2393370570602 : Closed e2393370570602 ∧ code e2393370570602 = 11189463592810 := by decide
theorem cert_e2393370570602 : check e2393370570602 [[],[.left],[]] .smaller = true := by decide
def e2393370571630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2393370571630 : Closed e2393370571630 ∧ code e2393370571630 = 11189463593838 := by decide
theorem cert_e2393370571630 : check e2393370571630 [[],[.left],[]] .smaller = true := by decide
def e2393370571638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2393370571638 : Closed e2393370571638 ∧ code e2393370571638 = 11189463593846 := by decide
theorem cert_e2393370571638 : check e2393370571638 [[],[.left],[]] .smaller = true := by decide
def e2393370571694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2393370571694 : Closed e2393370571694 ∧ code e2393370571694 = 11189463593902 := by decide
theorem cert_e2393370571694 : check e2393370571694 [[],[.left],[]] .smaller = true := by decide
def e2393370571706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2393370571706 : Closed e2393370571706 ∧ code e2393370571706 = 11189463593914 := by decide
theorem cert_e2393370571706 : check e2393370571706 [[],[.left],[]] .smaller = true := by decide
def e2393370571734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2393370571734 : Closed e2393370571734 ∧ code e2393370571734 = 11189463593942 := by decide
theorem cert_e2393370571734 : check e2393370571734 [[],[.left],[]] .smaller = true := by decide
def e2393370571738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2393370571738 : Closed e2393370571738 ∧ code e2393370571738 = 11189463593946 := by decide
theorem cert_e2393370571738 : check e2393370571738 [[],[.left],[]] .smaller = true := by decide
def e2393370572014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393370572014 : Closed e2393370572014 ∧ code e2393370572014 = 11189463594222 := by decide
theorem cert_e2393370572014 : check e2393370572014 [[],[.left],[]] .smaller = true := by decide
def e2393370572022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393370572022 : Closed e2393370572022 ∧ code e2393370572022 = 11189463594230 := by decide
theorem cert_e2393370572022 : check e2393370572022 [[],[.left],[]] .smaller = true := by decide
def e2393370572398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393370572398 : Closed e2393370572398 ∧ code e2393370572398 = 11189463594606 := by decide
theorem cert_e2393370572398 : check e2393370572398 [[],[.left],[]] .smaller = true := by decide
def e2393370572410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393370572410 : Closed e2393370572410 ∧ code e2393370572410 = 11189463594618 := by decide
theorem cert_e2393370572410 : check e2393370572410 [[],[.left],[]] .smaller = true := by decide
def e2393370572598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393370572598 : Closed e2393370572598 ∧ code e2393370572598 = 11189463594806 := by decide
theorem cert_e2393370572598 : check e2393370572598 [[],[.left],[]] .smaller = true := by decide
def e2393370572602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393370572602 : Closed e2393370572602 ∧ code e2393370572602 = 11189463594810 := by decide
theorem cert_e2393370572602 : check e2393370572602 [[],[.left],[]] .smaller = true := by decide
def e2393370573230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2393370573230 : Closed e2393370573230 ∧ code e2393370573230 = 11189463595438 := by decide
theorem cert_e2393370573230 : check e2393370573230 [[],[.left],[]] .smaller = true := by decide
def e2393370573242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2393370573242 : Closed e2393370573242 ∧ code e2393370573242 = 11189463595450 := by decide
theorem cert_e2393370573242 : check e2393370573242 [[],[.left],[]] .smaller = true := by decide
def e2393370573290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2393370573290 : Closed e2393370573290 ∧ code e2393370573290 = 11189463595498 := by decide
theorem cert_e2393370573290 : check e2393370573290 [[],[.left],[]] .smaller = true := by decide
def e2393370573422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393370573422 : Closed e2393370573422 ∧ code e2393370573422 = 11189463595630 := by decide
theorem cert_e2393370573422 : check e2393370573422 [[],[.left],[]] .smaller = true := by decide
def e2393370573434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393370573434 : Closed e2393370573434 ∧ code e2393370573434 = 11189463595642 := by decide
theorem cert_e2393370573434 : check e2393370573434 [[],[.left],[]] .smaller = true := by decide
def e2393370573722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393370573722 : Closed e2393370573722 ∧ code e2393370573722 = 11189463595930 := by decide
theorem cert_e2393370573722 : check e2393370573722 [[],[.left],[]] .smaller = true := by decide
def e2393370574038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2393370574038 : Closed e2393370574038 ∧ code e2393370574038 = 11189463596246 := by decide
theorem cert_e2393370574038 : check e2393370574038 [[],[.left],[]] .smaller = true := by decide
def e2393370574042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2393370574042 : Closed e2393370574042 ∧ code e2393370574042 = 11189463596250 := by decide
theorem cert_e2393370574042 : check e2393370574042 [[],[.left],[]] .smaller = true := by decide
def e2393370574058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2393370574058 : Closed e2393370574058 ∧ code e2393370574058 = 11189463596266 := by decide
theorem cert_e2393370574058 : check e2393370574058 [[],[.left],[]] .smaller = true := by decide
def e2393370574134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393370574134 : Closed e2393370574134 ∧ code e2393370574134 = 11189463596342 := by decide
theorem cert_e2393370574134 : check e2393370574134 [[],[.left],[]] .smaller = true := by decide
def e2393370574138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393370574138 : Closed e2393370574138 ∧ code e2393370574138 = 11189463596346 := by decide
theorem cert_e2393370574138 : check e2393370574138 [[],[.left],[]] .smaller = true := by decide
def e2393370574234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393370574234 : Closed e2393370574234 ∧ code e2393370574234 = 11189463596442 := by decide
theorem cert_e2393370574234 : check e2393370574234 [[],[.left],[]] .smaller = true := by decide
def e2393370577774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2393370577774 : Closed e2393370577774 ∧ code e2393370577774 = 11189463599982 := by decide
theorem cert_e2393370577774 : check e2393370577774 [[],[.left],[]] .smaller = true := by decide
def e2393370577782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2393370577782 : Closed e2393370577782 ∧ code e2393370577782 = 11189463599990 := by decide
theorem cert_e2393370577782 : check e2393370577782 [[],[.left],[]] .smaller = true := by decide
def e2393370577838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2393370577838 : Closed e2393370577838 ∧ code e2393370577838 = 11189463600046 := by decide
theorem cert_e2393370577838 : check e2393370577838 [[],[.left],[]] .smaller = true := by decide
def e2393370577850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2393370577850 : Closed e2393370577850 ∧ code e2393370577850 = 11189463600058 := by decide
theorem cert_e2393370577850 : check e2393370577850 [[],[.left],[]] .smaller = true := by decide
def e2393370577878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2393370577878 : Closed e2393370577878 ∧ code e2393370577878 = 11189463600086 := by decide
theorem cert_e2393370577878 : check e2393370577878 [[],[.left],[]] .smaller = true := by decide
def e2393370577882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2393370577882 : Closed e2393370577882 ∧ code e2393370577882 = 11189463600090 := by decide
theorem cert_e2393370577882 : check e2393370577882 [[],[.left],[]] .smaller = true := by decide
def e2393370578158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2393370578158 : Closed e2393370578158 ∧ code e2393370578158 = 11189463600366 := by decide
theorem cert_e2393370578158 : check e2393370578158 [[],[.left],[]] .smaller = true := by decide
def e2393370578166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2393370578166 : Closed e2393370578166 ∧ code e2393370578166 = 11189463600374 := by decide
theorem cert_e2393370578166 : check e2393370578166 [[],[.left],[]] .smaller = true := by decide
def e2393370578542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2393370578542 : Closed e2393370578542 ∧ code e2393370578542 = 11189463600750 := by decide
theorem cert_e2393370578542 : check e2393370578542 [[],[.left],[]] .smaller = true := by decide
def e2393370578554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2393370578554 : Closed e2393370578554 ∧ code e2393370578554 = 11189463600762 := by decide
theorem cert_e2393370578554 : check e2393370578554 [[],[.left],[]] .smaller = true := by decide
def e2393370578742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2393370578742 : Closed e2393370578742 ∧ code e2393370578742 = 11189463600950 := by decide
theorem cert_e2393370578742 : check e2393370578742 [[],[.left],[]] .smaller = true := by decide
def e2393370578746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2393370578746 : Closed e2393370578746 ∧ code e2393370578746 = 11189463600954 := by decide
theorem cert_e2393370578746 : check e2393370578746 [[],[.left],[]] .smaller = true := by decide
def e2393370584494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2393370584494 : Closed e2393370584494 ∧ code e2393370584494 = 11189463606702 := by decide
theorem cert_e2393370584494 : check e2393370584494 [[],[.left],[]] .smaller = true := by decide
def e2393370584506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2393370584506 : Closed e2393370584506 ∧ code e2393370584506 = 11189463606714 := by decide
theorem cert_e2393370584506 : check e2393370584506 [[],[.left],[]] .smaller = true := by decide
def e2393370584554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2393370584554 : Closed e2393370584554 ∧ code e2393370584554 = 11189463606762 := by decide
theorem cert_e2393370584554 : check e2393370584554 [[],[.left],[]] .smaller = true := by decide
def e2393370584686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2393370584686 : Closed e2393370584686 ∧ code e2393370584686 = 11189463606894 := by decide
theorem cert_e2393370584686 : check e2393370584686 [[],[.left],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393169378774
#print axioms Blc.Floor43.cert_e2393169378778
#print axioms Blc.Floor43.cert_e2393169393462
#print axioms Blc.Floor43.cert_e2393169393466
