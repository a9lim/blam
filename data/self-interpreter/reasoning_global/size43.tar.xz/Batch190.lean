import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2388184459802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388184459802 : Closed e2388184459802 ∧ code e2388184459802 = 11184277482010 := by decide
theorem cert_e2388184459802 : check e2388184459802 [[]] .width = true := by decide
def e2388184840730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388184840730 : Closed e2388184840730 ∧ code e2388184840730 = 11184277862938 := by decide
theorem cert_e2388184840730 : check e2388184840730 [[]] .width = true := by decide
def e2388184983578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388184983578 : Closed e2388184983578 ∧ code e2388184983578 = 11184278005786 := by decide
theorem cert_e2388184983578 : check e2388184983578 [[]] .width = true := by decide
def e2388185025050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185025050 : Closed e2388185025050 ∧ code e2388185025050 = 11184278047258 := by decide
theorem cert_e2388185025050 : check e2388185025050 [[]] .width = true := by decide
def e2388185032730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388185032730 : Closed e2388185032730 ∧ code e2388185032730 = 11184278054938 := by decide
theorem cert_e2388185032730 : check e2388185032730 [[]] .width = true := by decide
def e2388185037338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185037338 : Closed e2388185037338 ∧ code e2388185037338 = 11184278059546 := by decide
theorem cert_e2388185037338 : check e2388185037338 [[]] .width = true := by decide
def e2388185197082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185197082 : Closed e2388185197082 ∧ code e2388185197082 = 11184278219290 := by decide
private def t_e2388185197082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185197082 : ¬ IsSelfInterpreter e2388185197082 :=
  wSource (t := t_e2388185197082) (replay_sound (ps := []) (t := e2388185197082) (by decide)) (by decide)
def e2388185221658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185221658 : Closed e2388185221658 ∧ code e2388185221658 = 11184278243866 := by decide
private def t_e2388185221658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185221658 : ¬ IsSelfInterpreter e2388185221658 :=
  wSource (t := t_e2388185221658) (replay_sound (ps := []) (t := e2388185221658) (by decide)) (by decide)
def e2388185229338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388185229338 : Closed e2388185229338 ∧ code e2388185229338 = 11184278251546 := by decide
theorem cert_e2388185229338 : check e2388185229338 [[]] .width = true := by decide
def e2388185233946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185233946 : Closed e2388185233946 ∧ code e2388185233946 = 11184278256154 := by decide
private def t_e2388185233946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185233946 : ¬ IsSelfInterpreter e2388185233946 :=
  wSource (t := t_e2388185233946) (replay_sound (ps := []) (t := e2388185233946) (by decide)) (by decide)
def e2388185246234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185246234 : Closed e2388185246234 ∧ code e2388185246234 = 11184278268442 := by decide
private def t_e2388185246234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185246234 : ¬ IsSelfInterpreter e2388185246234 :=
  wSource (t := t_e2388185246234) (replay_sound (ps := []) (t := e2388185246234) (by decide)) (by decide)
def e2388185405978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185405978 : Closed e2388185405978 ∧ code e2388185405978 = 11184278428186 := by decide
theorem cert_e2388185405978 : check e2388185405978 [[]] .width = true := by decide
def e2388185410074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185410074 : Closed e2388185410074 ∧ code e2388185410074 = 11184278432282 := by decide
theorem cert_e2388185410074 : check e2388185410074 [[]] .width = true := by decide
def e2388185602586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185602586 : Closed e2388185602586 ∧ code e2388185602586 = 11184278624794 := by decide
theorem cert_e2388185602586 : check e2388185602586 [[]] .width = true := by decide
def e2388185671706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388185671706 : Closed e2388185671706 ∧ code e2388185671706 = 11184278693914 := by decide
theorem cert_e2388185671706 : check e2388185671706 [[]] .width = true := by decide
def e2388185680410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185680410 : Closed e2388185680410 ∧ code e2388185680410 = 11184278702618 := by decide
theorem cert_e2388185680410 : check e2388185680410 [[]] .width = true := by decide
def e2388185688090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388185688090 : Closed e2388185688090 ∧ code e2388185688090 = 11184278710298 := by decide
theorem cert_e2388185688090 : check e2388185688090 [[]] .width = true := by decide
def e2388185692698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185692698 : Closed e2388185692698 ∧ code e2388185692698 = 11184278714906 := by decide
theorem cert_e2388185692698 : check e2388185692698 [[]] .width = true := by decide
def e2388185700890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185700890 : Closed e2388185700890 ∧ code e2388185700890 = 11184278723098 := by decide
theorem cert_e2388185700890 : check e2388185700890 [[]] .width = true := by decide
def e2388185721370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185721370 : Closed e2388185721370 ∧ code e2388185721370 = 11184278743578 := by decide
private def t_e2388185721370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185721370 : ¬ IsSelfInterpreter e2388185721370 :=
  wSource (t := t_e2388185721370) (replay_sound (ps := []) (t := e2388185721370) (by decide)) (by decide)
def e2388185745946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185745946 : Closed e2388185745946 ∧ code e2388185745946 = 11184278768154 := by decide
private def t_e2388185745946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185745946 : ¬ IsSelfInterpreter e2388185745946 :=
  wSource (t := t_e2388185745946) (replay_sound (ps := []) (t := e2388185745946) (by decide)) (by decide)
def e2388185753626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388185753626 : Closed e2388185753626 ∧ code e2388185753626 = 11184278775834 := by decide
theorem cert_e2388185753626 : check e2388185753626 [[]] .width = true := by decide
def e2388185758234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185758234 : Closed e2388185758234 ∧ code e2388185758234 = 11184278780442 := by decide
private def t_e2388185758234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185758234 : ¬ IsSelfInterpreter e2388185758234 :=
  wSource (t := t_e2388185758234) (replay_sound (ps := []) (t := e2388185758234) (by decide)) (by decide)
def e2388185770522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185770522 : Closed e2388185770522 ∧ code e2388185770522 = 11184278792730 := by decide
private def t_e2388185770522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185770522 : ¬ IsSelfInterpreter e2388185770522 :=
  wSource (t := t_e2388185770522) (replay_sound (ps := []) (t := e2388185770522) (by decide)) (by decide)
def e2388185799194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185799194 : Closed e2388185799194 ∧ code e2388185799194 = 11184278821402 := by decide
private def t_e2388185799194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185799194 : ¬ IsSelfInterpreter e2388185799194 :=
  wSource (t := t_e2388185799194) (replay_sound (ps := []) (t := e2388185799194) (by decide)) (by decide)
def e2388185803290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388185803290 : Closed e2388185803290 ∧ code e2388185803290 = 11184278825498 := by decide
private def t_e2388185803290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388185803290 : ¬ IsSelfInterpreter e2388185803290 :=
  wSource (t := t_e2388185803290) (replay_sound (ps := []) (t := e2388185803290) (by decide)) (by decide)
def e2388186872346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388186872346 : Closed e2388186872346 ∧ code e2388186872346 = 11184279894554 := by decide
theorem cert_e2388186872346 : check e2388186872346 [[]] .width = true := by decide
def e2388186880538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388186880538 : Closed e2388186880538 ∧ code e2388186880538 = 11184279902746 := by decide
theorem cert_e2388186880538 : check e2388186880538 [[]] .width = true := by decide
def e2388187658778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388187658778 : Closed e2388187658778 ∧ code e2388187658778 = 11184280680986 := by decide
theorem cert_e2388187658778 : check e2388187658778 [[]] .width = true := by decide
def e2388187666970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388187666970 : Closed e2388187666970 ∧ code e2388187666970 = 11184280689178 := by decide
theorem cert_e2388187666970 : check e2388187666970 [[]] .width = true := by decide
def e2388188232218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388188232218 : Closed e2388188232218 ∧ code e2388188232218 = 11184281254426 := by decide
theorem cert_e2388188232218 : check e2388188232218 [[]] .width = true := by decide
def e2388188317210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388188317210 : Closed e2388188317210 ∧ code e2388188317210 = 11184281339418 := by decide
theorem cert_e2388188317210 : check e2388188317210 [[]] .width = true := by decide
def e2388188319942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388188319942 : Closed e2388188319942 ∧ code e2388188319942 = 11184281342150 := by decide
theorem cert_e2388188319942 : check e2388188319942 [[]] .width = true := by decide
def e2388188346906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388188346906 : Closed e2388188346906 ∧ code e2388188346906 = 11184281369114 := by decide
theorem cert_e2388188346906 : check e2388188346906 [[]] .width = true := by decide
def e2388188382746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388188382746 : Closed e2388188382746 ∧ code e2388188382746 = 11184281404954 := by decide
theorem cert_e2388188382746 : check e2388188382746 [[]] .width = true := by decide
def e2388188385478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388188385478 : Closed e2388188385478 ∧ code e2388188385478 = 11184281407686 := by decide
theorem cert_e2388188385478 : check e2388188385478 [[]] .width = true := by decide
def e2388189964314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388189964314 : Closed e2388189964314 ∧ code e2388189964314 = 11184282986522 := by decide
theorem cert_e2388189964314 : check e2388189964314 [[]] .width = true := by decide
def e2388189997082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388189997082 : Closed e2388189997082 ∧ code e2388189997082 = 11184283019290 := by decide
theorem cert_e2388189997082 : check e2388189997082 [[]] .width = true := by decide
def e2388190083610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388190083610 : Closed e2388190083610 ∧ code e2388190083610 = 11184283105818 := by decide
theorem cert_e2388190083610 : check e2388190083610 [[]] .width = true := by decide
def e2388190226458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388190226458 : Closed e2388190226458 ∧ code e2388190226458 = 11184283248666 := by decide
theorem cert_e2388190226458 : check e2388190226458 [[]] .width = true := by decide
def e2388190267930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388190267930 : Closed e2388190267930 ∧ code e2388190267930 = 11184283290138 := by decide
theorem cert_e2388190267930 : check e2388190267930 [[]] .width = true := by decide
def e2388190275610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388190275610 : Closed e2388190275610 ∧ code e2388190275610 = 11184283297818 := by decide
theorem cert_e2388190275610 : check e2388190275610 [[]] .width = true := by decide
def e2388190280218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388190280218 : Closed e2388190280218 ∧ code e2388190280218 = 11184283302426 := by decide
theorem cert_e2388190280218 : check e2388190280218 [[]] .width = true := by decide
def e2388190321178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388190321178 : Closed e2388190321178 ∧ code e2388190321178 = 11184283343386 := by decide
theorem cert_e2388190321178 : check e2388190321178 [[]] .width = true := by decide
def e2388190390298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388190390298 : Closed e2388190390298 ∧ code e2388190390298 = 11184283412506 := by decide
theorem cert_e2388190390298 : check e2388190390298 [[]] .width = true := by decide
def e2388190399002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388190399002 : Closed e2388190399002 ∧ code e2388190399002 = 11184283421210 := by decide
theorem cert_e2388190399002 : check e2388190399002 [[]] .width = true := by decide
def e2388190406682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388190406682 : Closed e2388190406682 ∧ code e2388190406682 = 11184283428890 := by decide
theorem cert_e2388190406682 : check e2388190406682 [[]] .width = true := by decide
def e2388190411290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388190411290 : Closed e2388190411290 ∧ code e2388190411290 = 11184283433498 := by decide
theorem cert_e2388190411290 : check e2388190411290 [[]] .width = true := by decide
def e2388190419482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388190419482 : Closed e2388190419482 ∧ code e2388190419482 = 11184283441690 := by decide
theorem cert_e2388190419482 : check e2388190419482 [[]] .width = true := by decide
def e2388191537178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388191537178 : Closed e2388191537178 ∧ code e2388191537178 = 11184284559386 := by decide
theorem cert_e2388191537178 : check e2388191537178 [[]] .width = true := by decide
def e2388191569946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388191569946 : Closed e2388191569946 ∧ code e2388191569946 = 11184284592154 := by decide
theorem cert_e2388191569946 : check e2388191569946 [[]] .width = true := by decide
def e2388192721434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388192721434 : Closed e2388192721434 ∧ code e2388192721434 = 11184285743642 := by decide
theorem cert_e2388192721434 : check e2388192721434 [[]] .width = true := by decide
def e2388192904730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388192904730 : Closed e2388192904730 ∧ code e2388192904730 = 11184285926938 := by decide
theorem cert_e2388192904730 : check e2388192904730 [[]] .width = true := by decide
def e2388192907462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388192907462 : Closed e2388192907462 ∧ code e2388192907462 = 11184285929670 := by decide
theorem cert_e2388192907462 : check e2388192907462 [[]] .width = true := by decide
def e2388193110042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388193110042 : Closed e2388193110042 ∧ code e2388193110042 = 11184286132250 := by decide
theorem cert_e2388193110042 : check e2388193110042 [[]] .width = true := by decide
def e2388193151514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388193151514 : Closed e2388193151514 ∧ code e2388193151514 = 11184286173722 := by decide
theorem cert_e2388193151514 : check e2388193151514 [[]] .width = true := by decide
def e2388193159194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388193159194 : Closed e2388193159194 ∧ code e2388193159194 = 11184286181402 := by decide
theorem cert_e2388193159194 : check e2388193159194 [[]] .width = true := by decide
def e2388193163802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388193163802 : Closed e2388193163802 ∧ code e2388193163802 = 11184286186010 := by decide
theorem cert_e2388193163802 : check e2388193163802 [[]] .width = true := by decide
def e2388193576986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388193576986 : Closed e2388193576986 ∧ code e2388193576986 = 11184286599194 := by decide
theorem cert_e2388193576986 : check e2388193576986 [[]] .width = true := by decide
def e2388193578522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388193578522 : Closed e2388193578522 ∧ code e2388193578522 = 11184286600730 := by decide
theorem cert_e2388193578522 : check e2388193578522 [[]] .width = true := by decide
def e2388193583130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388193583130 : Closed e2388193583130 ∧ code e2388193583130 = 11184286605338 := by decide
theorem cert_e2388193583130 : check e2388193583130 [[]] .width = true := by decide
def e2388193583222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388193583222 : Closed e2388193583222 ∧ code e2388193583222 = 11184286605430 := by decide
theorem cert_e2388193583222 : check e2388193583222 [[]] .width = true := by decide
def e2388193583466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388193583466 : Closed e2388193583466 ∧ code e2388193583466 = 11184286605674 := by decide
theorem cert_e2388193583466 : check e2388193583466 [[]] .width = true := by decide
def e2388193583514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388193583514 : Closed e2388193583514 ∧ code e2388193583514 = 11184286605722 := by decide
theorem cert_e2388193583514 : check e2388193583514 [[]] .width = true := by decide
def e2388193587398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388193587398 : Closed e2388193587398 ∧ code e2388193587398 = 11184286609606 := by decide
theorem cert_e2388193587398 : check e2388193587398 [[]] .width = true := by decide
def e2388193600026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388193600026 : Closed e2388193600026 ∧ code e2388193600026 = 11184286622234 := by decide
theorem cert_e2388193600026 : check e2388193600026 [[]] .width = true := by decide
def e2388193601562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388193601562 : Closed e2388193601562 ∧ code e2388193601562 = 11184286623770 := by decide
theorem cert_e2388193601562 : check e2388193601562 [[]] .width = true := by decide
def e2388193607706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388193607706 : Closed e2388193607706 ∧ code e2388193607706 = 11184286629914 := by decide
theorem cert_e2388193607706 : check e2388193607706 [[]] .width = true := by decide
def e2388193607798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388193607798 : Closed e2388193607798 ∧ code e2388193607798 = 11184286630006 := by decide
theorem cert_e2388193607798 : check e2388193607798 [[]] .width = true := by decide
def e2388193608042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388193608042 : Closed e2388193608042 ∧ code e2388193608042 = 11184286630250 := by decide
theorem cert_e2388193608042 : check e2388193608042 [[]] .width = true := by decide
def e2388193608090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388193608090 : Closed e2388193608090 ∧ code e2388193608090 = 11184286630298 := by decide
theorem cert_e2388193608090 : check e2388193608090 [[]] .width = true := by decide
def e2388193609098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388193609098 : Closed e2388193609098 ∧ code e2388193609098 = 11184286631306 := by decide
theorem cert_e2388193609098 : check e2388193609098 [[]] .width = true := by decide
def e2388193609122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388193609122 : Closed e2388193609122 ∧ code e2388193609122 = 11184286631330 := by decide
theorem cert_e2388193609122 : check e2388193609122 [[]] .width = true := by decide
def e2388193609230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388193609230 : Closed e2388193609230 ∧ code e2388193609230 = 11184286631438 := by decide
theorem cert_e2388193609230 : check e2388193609230 [[]] .width = true := by decide
def e2388193609242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388193609242 : Closed e2388193609242 ∧ code e2388193609242 = 11184286631450 := by decide
theorem cert_e2388193609242 : check e2388193609242 [[]] .width = true := by decide
def e2388193609314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388193609314 : Closed e2388193609314 ∧ code e2388193609314 = 11184286631522 := by decide
theorem cert_e2388193609314 : check e2388193609314 [[]] .width = true := by decide
def e2388193737242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388193737242 : Closed e2388193737242 ∧ code e2388193737242 = 11184286759450 := by decide
theorem cert_e2388193737242 : check e2388193737242 [[]] .width = true := by decide
def e2388193822234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388193822234 : Closed e2388193822234 ∧ code e2388193822234 = 11184286844442 := by decide
theorem cert_e2388193822234 : check e2388193822234 [[]] .width = true := by decide
def e2388193824966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388193824966 : Closed e2388193824966 ∧ code e2388193824966 = 11184286847174 := by decide
theorem cert_e2388193824966 : check e2388193824966 [[]] .width = true := by decide
def e2388193929242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388193929242 : Closed e2388193929242 ∧ code e2388193929242 = 11184286951450 := by decide
theorem cert_e2388193929242 : check e2388193929242 [[]] .width = true := by decide
def e2388193937946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388193937946 : Closed e2388193937946 ∧ code e2388193937946 = 11184286960154 := by decide
theorem cert_e2388193937946 : check e2388193937946 [[]] .width = true := by decide
def e2388193945626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388193945626 : Closed e2388193945626 ∧ code e2388193945626 = 11184286967834 := by decide
theorem cert_e2388193945626 : check e2388193945626 [[]] .width = true := by decide
def e2388193950234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388193950234 : Closed e2388193950234 ∧ code e2388193950234 = 11184286972442 := by decide
theorem cert_e2388193950234 : check e2388193950234 [[]] .width = true := by decide
def e2388193958426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388193958426 : Closed e2388193958426 ∧ code e2388193958426 = 11184286980634 := by decide
theorem cert_e2388193958426 : check e2388193958426 [[]] .width = true := by decide
def e2388194101274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388194101274 : Closed e2388194101274 ∧ code e2388194101274 = 11184287123482 := by decide
theorem cert_e2388194101274 : check e2388194101274 [[]] .width = true := by decide
def e2388194102810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388194102810 : Closed e2388194102810 ∧ code e2388194102810 = 11184287125018 := by decide
theorem cert_e2388194102810 : check e2388194102810 [[]] .width = true := by decide
def e2388194107418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388194107418 : Closed e2388194107418 ∧ code e2388194107418 = 11184287129626 := by decide
theorem cert_e2388194107418 : check e2388194107418 [[]] .width = true := by decide
def e2388194107510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388194107510 : Closed e2388194107510 ∧ code e2388194107510 = 11184287129718 := by decide
theorem cert_e2388194107510 : check e2388194107510 [[]] .width = true := by decide
def e2388194107754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388194107754 : Closed e2388194107754 ∧ code e2388194107754 = 11184287129962 := by decide
theorem cert_e2388194107754 : check e2388194107754 [[]] .width = true := by decide
def e2388194107802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388194107802 : Closed e2388194107802 ∧ code e2388194107802 = 11184287130010 := by decide
theorem cert_e2388194107802 : check e2388194107802 [[]] .width = true := by decide
def e2388194111686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388194111686 : Closed e2388194111686 ∧ code e2388194111686 = 11184287133894 := by decide
theorem cert_e2388194111686 : check e2388194111686 [[]] .width = true := by decide
def e2388194124314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388194124314 : Closed e2388194124314 ∧ code e2388194124314 = 11184287146522 := by decide
theorem cert_e2388194124314 : check e2388194124314 [[]] .width = true := by decide
def e2388194125850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388194125850 : Closed e2388194125850 ∧ code e2388194125850 = 11184287148058 := by decide
theorem cert_e2388194125850 : check e2388194125850 [[]] .width = true := by decide
def e2388194131994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388194131994 : Closed e2388194131994 ∧ code e2388194131994 = 11184287154202 := by decide
theorem cert_e2388194131994 : check e2388194131994 [[]] .width = true := by decide
def e2388194132086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388194132086 : Closed e2388194132086 ∧ code e2388194132086 = 11184287154294 := by decide
theorem cert_e2388194132086 : check e2388194132086 [[]] .width = true := by decide
def e2388194132330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388194132330 : Closed e2388194132330 ∧ code e2388194132330 = 11184287154538 := by decide
theorem cert_e2388194132330 : check e2388194132330 [[]] .width = true := by decide
def e2388194132378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388194132378 : Closed e2388194132378 ∧ code e2388194132378 = 11184287154586 := by decide
theorem cert_e2388194132378 : check e2388194132378 [[]] .width = true := by decide
def e2388194133386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388194133386 : Closed e2388194133386 ∧ code e2388194133386 = 11184287155594 := by decide
theorem cert_e2388194133386 : check e2388194133386 [[]] .width = true := by decide
def e2388194133410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388194133410 : Closed e2388194133410 ∧ code e2388194133410 = 11184287155618 := by decide
theorem cert_e2388194133410 : check e2388194133410 [[]] .width = true := by decide
def e2388194133518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388194133518 : Closed e2388194133518 ∧ code e2388194133518 = 11184287155726 := by decide
theorem cert_e2388194133518 : check e2388194133518 [[]] .width = true := by decide
def e2388194133530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388194133530 : Closed e2388194133530 ∧ code e2388194133530 = 11184287155738 := by decide
theorem cert_e2388194133530 : check e2388194133530 [[]] .width = true := by decide
def e2388194133602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388194133602 : Closed e2388194133602 ∧ code e2388194133602 = 11184287155810 := by decide
theorem cert_e2388194133602 : check e2388194133602 [[]] .width = true := by decide
def e2388194998810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388194998810 : Closed e2388194998810 ∧ code e2388194998810 = 11184288021018 := by decide
theorem cert_e2388194998810 : check e2388194998810 [[]] .width = true := by decide
def e2388195011098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388195011098 : Closed e2388195011098 ∧ code e2388195011098 = 11184288033306 := by decide
theorem cert_e2388195011098 : check e2388195011098 [[]] .width = true := by decide
def e2388195392026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388195392026 : Closed e2388195392026 ∧ code e2388195392026 = 11184288414234 := by decide
theorem cert_e2388195392026 : check e2388195392026 [[]] .width = true := by decide
def e2388195404314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388195404314 : Closed e2388195404314 ∧ code e2388195404314 = 11184288426522 := by decide
theorem cert_e2388195404314 : check e2388195404314 [[]] .width = true := by decide
def e2388195572250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388195572250 : Closed e2388195572250 ∧ code e2388195572250 = 11184288594458 := by decide
theorem cert_e2388195572250 : check e2388195572250 [[]] .width = true := by decide
def e2388195657242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388195657242 : Closed e2388195657242 ∧ code e2388195657242 = 11184288679450 := by decide
theorem cert_e2388195657242 : check e2388195657242 [[]] .width = true := by decide
def e2388195659974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388195659974 : Closed e2388195659974 ∧ code e2388195659974 = 11184288682182 := by decide
theorem cert_e2388195659974 : check e2388195659974 [[]] .width = true := by decide
def e2388195744282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388195744282 : Closed e2388195744282 ∧ code e2388195744282 = 11184288766490 := by decide
theorem cert_e2388195744282 : check e2388195744282 [[]] .width = true := by decide
def e2388195755546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388195755546 : Closed e2388195755546 ∧ code e2388195755546 = 11184288777754 := by decide
theorem cert_e2388195755546 : check e2388195755546 [[]] .width = true := by decide
def e2388195758278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388195758278 : Closed e2388195758278 ∧ code e2388195758278 = 11184288780486 := by decide
theorem cert_e2388195758278 : check e2388195758278 [[]] .width = true := by decide
def e2388196375066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388196375066 : Closed e2388196375066 ∧ code e2388196375066 = 11184289397274 := by decide
theorem cert_e2388196375066 : check e2388196375066 [[]] .width = true := by decide
def e2388196517914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388196517914 : Closed e2388196517914 ∧ code e2388196517914 = 11184289540122 := by decide
theorem cert_e2388196517914 : check e2388196517914 [[]] .width = true := by decide
def e2388196559386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388196559386 : Closed e2388196559386 ∧ code e2388196559386 = 11184289581594 := by decide
theorem cert_e2388196559386 : check e2388196559386 [[]] .width = true := by decide
def e2388196567066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388196567066 : Closed e2388196567066 ∧ code e2388196567066 = 11184289589274 := by decide
theorem cert_e2388196567066 : check e2388196567066 [[]] .width = true := by decide
def e2388196571674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388196571674 : Closed e2388196571674 ∧ code e2388196571674 = 11184289593882 := by decide
theorem cert_e2388196571674 : check e2388196571674 [[]] .width = true := by decide
def e2388196731418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388196731418 : Closed e2388196731418 ∧ code e2388196731418 = 11184289753626 := by decide
theorem cert_e2388196731418 : check e2388196731418 [[]] .width = true := by decide
def e2388196755994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388196755994 : Closed e2388196755994 ∧ code e2388196755994 = 11184289778202 := by decide
theorem cert_e2388196755994 : check e2388196755994 [[]] .width = true := by decide
def e2388196763674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388196763674 : Closed e2388196763674 ∧ code e2388196763674 = 11184289785882 := by decide
theorem cert_e2388196763674 : check e2388196763674 [[]] .width = true := by decide
def e2388196768282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388196768282 : Closed e2388196768282 ∧ code e2388196768282 = 11184289790490 := by decide
theorem cert_e2388196768282 : check e2388196768282 [[]] .width = true := by decide
def e2388196780570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388196780570 : Closed e2388196780570 ∧ code e2388196780570 = 11184289802778 := by decide
private def t_e2388196780570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388196780570 : ¬ IsSelfInterpreter e2388196780570 :=
  wSource (t := t_e2388196780570) (replay_sound (ps := []) (t := e2388196780570) (by decide)) (by decide)
def e2388196915738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388196915738 : Closed e2388196915738 ∧ code e2388196915738 = 11184289937946 := by decide
theorem cert_e2388196915738 : check e2388196915738 [[]] .width = true := by decide
def e2388197099034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388197099034 : Closed e2388197099034 ∧ code e2388197099034 = 11184290121242 := by decide
theorem cert_e2388197099034 : check e2388197099034 [[]] .width = true := by decide
def e2388197101766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388197101766 : Closed e2388197101766 ∧ code e2388197101766 = 11184290123974 := by decide
theorem cert_e2388197101766 : check e2388197101766 [[]] .width = true := by decide
def e2388197304346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388197304346 : Closed e2388197304346 ∧ code e2388197304346 = 11184290326554 := by decide
theorem cert_e2388197304346 : check e2388197304346 [[]] .width = true := by decide
def e2388197345818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388197345818 : Closed e2388197345818 ∧ code e2388197345818 = 11184290368026 := by decide
theorem cert_e2388197345818 : check e2388197345818 [[]] .width = true := by decide
def e2388197353498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388197353498 : Closed e2388197353498 ∧ code e2388197353498 = 11184290375706 := by decide
theorem cert_e2388197353498 : check e2388197353498 [[]] .width = true := by decide
def e2388197358106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388197358106 : Closed e2388197358106 ∧ code e2388197358106 = 11184290380314 := by decide
theorem cert_e2388197358106 : check e2388197358106 [[]] .width = true := by decide
def e2388197771290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388197771290 : Closed e2388197771290 ∧ code e2388197771290 = 11184290793498 := by decide
theorem cert_e2388197771290 : check e2388197771290 [[]] .width = true := by decide
def e2388197772826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388197772826 : Closed e2388197772826 ∧ code e2388197772826 = 11184290795034 := by decide
theorem cert_e2388197772826 : check e2388197772826 [[]] .width = true := by decide
def e2388197777434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388197777434 : Closed e2388197777434 ∧ code e2388197777434 = 11184290799642 := by decide
theorem cert_e2388197777434 : check e2388197777434 [[]] .width = true := by decide
def e2388197777526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388197777526 : Closed e2388197777526 ∧ code e2388197777526 = 11184290799734 := by decide
theorem cert_e2388197777526 : check e2388197777526 [[]] .width = true := by decide
def e2388197777770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388197777770 : Closed e2388197777770 ∧ code e2388197777770 = 11184290799978 := by decide
theorem cert_e2388197777770 : check e2388197777770 [[]] .width = true := by decide
def e2388197777818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388197777818 : Closed e2388197777818 ∧ code e2388197777818 = 11184290800026 := by decide
theorem cert_e2388197777818 : check e2388197777818 [[]] .width = true := by decide
def e2388197781702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388197781702 : Closed e2388197781702 ∧ code e2388197781702 = 11184290803910 := by decide
theorem cert_e2388197781702 : check e2388197781702 [[]] .width = true := by decide
def e2388197794330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388197794330 : Closed e2388197794330 ∧ code e2388197794330 = 11184290816538 := by decide
theorem cert_e2388197794330 : check e2388197794330 [[]] .width = true := by decide
def e2388197795866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388197795866 : Closed e2388197795866 ∧ code e2388197795866 = 11184290818074 := by decide
theorem cert_e2388197795866 : check e2388197795866 [[]] .width = true := by decide
def e2388197802010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388197802010 : Closed e2388197802010 ∧ code e2388197802010 = 11184290824218 := by decide
theorem cert_e2388197802010 : check e2388197802010 [[]] .width = true := by decide
def e2388197802102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388197802102 : Closed e2388197802102 ∧ code e2388197802102 = 11184290824310 := by decide
theorem cert_e2388197802102 : check e2388197802102 [[]] .width = true := by decide
def e2388197802346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388197802346 : Closed e2388197802346 ∧ code e2388197802346 = 11184290824554 := by decide
theorem cert_e2388197802346 : check e2388197802346 [[]] .width = true := by decide
def e2388197802394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388197802394 : Closed e2388197802394 ∧ code e2388197802394 = 11184290824602 := by decide
theorem cert_e2388197802394 : check e2388197802394 [[]] .width = true := by decide
def e2388197803402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388197803402 : Closed e2388197803402 ∧ code e2388197803402 = 11184290825610 := by decide
theorem cert_e2388197803402 : check e2388197803402 [[]] .width = true := by decide
def e2388197803426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388197803426 : Closed e2388197803426 ∧ code e2388197803426 = 11184290825634 := by decide
theorem cert_e2388197803426 : check e2388197803426 [[]] .width = true := by decide
def e2388197803534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388197803534 : Closed e2388197803534 ∧ code e2388197803534 = 11184290825742 := by decide
theorem cert_e2388197803534 : check e2388197803534 [[]] .width = true := by decide
def e2388197803546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388197803546 : Closed e2388197803546 ∧ code e2388197803546 = 11184290825754 := by decide
theorem cert_e2388197803546 : check e2388197803546 [[]] .width = true := by decide
def e2388197803618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388197803618 : Closed e2388197803618 ∧ code e2388197803618 = 11184290825826 := by decide
theorem cert_e2388197803618 : check e2388197803618 [[]] .width = true := by decide
def e2388198439450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388198439450 : Closed e2388198439450 ∧ code e2388198439450 = 11184291461658 := by decide
private def t_e2388198439450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388198439450 : ¬ IsSelfInterpreter e2388198439450 :=
  wSource (t := t_e2388198439450) (replay_sound (ps := []) (t := e2388198439450) (by decide)) (by decide)
def e2388198475290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388198475290 : Closed e2388198475290 ∧ code e2388198475290 = 11184291497498 := by decide
private def t_e2388198475290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388198475290 : ¬ IsSelfInterpreter e2388198475290 :=
  wSource (t := t_e2388198475290) (replay_sound (ps := []) (t := e2388198475290) (by decide)) (by decide)
def e2388198478022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388198478022 : Closed e2388198478022 ∧ code e2388198478022 = 11184291500230 := by decide
theorem cert_e2388198478022 : check e2388198478022 [[]] .width = true := by decide
def e2388198525466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388198525466 : Closed e2388198525466 ∧ code e2388198525466 = 11184291547674 := by decide
private def t_e2388198525466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388198525466 : ¬ IsSelfInterpreter e2388198525466 :=
  wSource (t := t_e2388198525466) (replay_sound (ps := []) (t := e2388198525466) (by decide)) (by decide)
def e2388198533146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388198533146 : Closed e2388198533146 ∧ code e2388198533146 = 11184291555354 := by decide
theorem cert_e2388198533146 : check e2388198533146 [[]] .width = true := by decide
def e2388198537754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388198537754 : Closed e2388198537754 ∧ code e2388198537754 = 11184291559962 := by decide
private def t_e2388198537754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388198537754 : ¬ IsSelfInterpreter e2388198537754 :=
  wSource (t := t_e2388198537754) (replay_sound (ps := []) (t := e2388198537754) (by decide)) (by decide)
def e2388198550042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388198550042 : Closed e2388198550042 ∧ code e2388198550042 = 11184291572250 := by decide
private def t_e2388198550042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388198550042 : ¬ IsSelfInterpreter e2388198550042 :=
  wSource (t := t_e2388198550042) (replay_sound (ps := []) (t := e2388198550042) (by decide)) (by decide)
def e2388198557722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388198557722 : Closed e2388198557722 ∧ code e2388198557722 = 11184291579930 := by decide
theorem cert_e2388198557722 : check e2388198557722 [[]] .width = true := by decide
def e2388198559258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388198559258 : Closed e2388198559258 ∧ code e2388198559258 = 11184291581466 := by decide
private def t_e2388198559258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388198559258 : ¬ IsSelfInterpreter e2388198559258 :=
  wSource (t := t_e2388198559258) (replay_sound (ps := []) (t := e2388198559258) (by decide)) (by decide)
def e2388198563866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388198563866 : Closed e2388198563866 ∧ code e2388198563866 = 11184291586074 := by decide
theorem cert_e2388198563866 : check e2388198563866 [[]] .width = true := by decide
def e2388198563958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388198563958 : Closed e2388198563958 ∧ code e2388198563958 = 11184291586166 := by decide
private def t_e2388198563958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2388198563958 : ¬ IsSelfInterpreter e2388198563958 :=
  wSource (t := t_e2388198563958) (replay_sound (ps := []) (t := e2388198563958) (by decide)) (by decide)
def e2388198564202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388198564202 : Closed e2388198564202 ∧ code e2388198564202 = 11184291586410 := by decide
private def t_e2388198564202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2388198564202 : ¬ IsSelfInterpreter e2388198564202 :=
  wSource (t := t_e2388198564202) (replay_sound (ps := []) (t := e2388198564202) (by decide)) (by decide)
def e2388198564250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388198564250 : Closed e2388198564250 ∧ code e2388198564250 = 11184291586458 := by decide
private def t_e2388198564250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2388198564250 : ¬ IsSelfInterpreter e2388198564250 :=
  wSource (t := t_e2388198564250) (replay_sound (ps := []) (t := e2388198564250) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2388185197082
#print axioms Blc.Floor43.cert_e2388185221658
#print axioms Blc.Floor43.cert_e2388185233946
#print axioms Blc.Floor43.cert_e2388185246234
#print axioms Blc.Floor43.cert_e2388185721370
#print axioms Blc.Floor43.cert_e2388185745946
#print axioms Blc.Floor43.cert_e2388185758234
#print axioms Blc.Floor43.cert_e2388185770522
#print axioms Blc.Floor43.cert_e2388185799194
#print axioms Blc.Floor43.cert_e2388185803290
#print axioms Blc.Floor43.cert_e2388196780570
#print axioms Blc.Floor43.cert_e2388198439450
#print axioms Blc.Floor43.cert_e2388198475290
#print axioms Blc.Floor43.cert_e2388198525466
#print axioms Blc.Floor43.cert_e2388198537754
#print axioms Blc.Floor43.cert_e2388198550042
#print axioms Blc.Floor43.cert_e2388198559258
#print axioms Blc.Floor43.cert_e2388198563958
#print axioms Blc.Floor43.cert_e2388198564202
#print axioms Blc.Floor43.cert_e2388198564250
