import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262374825782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374825782 : Closed e2262374825782 ∧ code e2262374825782 = 11058467847990 := by decide
theorem cert_e2262374825782 : check e2262374825782 [[],[.under]] .three = true := by decide
def e2262374825786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374825786 : Closed e2262374825786 ∧ code e2262374825786 = 11058467847994 := by decide
theorem cert_e2262374825786 : check e2262374825786 [[],[.under]] .three = true := by decide
def e2262374853998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2262374853998 : Closed e2262374853998 ∧ code e2262374853998 = 11058467876206 := by decide
theorem cert_e2262374853998 : check e2262374853998 [[],[.under]] .smaller = true := by decide
def e2262374854006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2262374854006 : Closed e2262374854006 ∧ code e2262374854006 = 11058467876214 := by decide
theorem cert_e2262374854006 : check e2262374854006 [[],[.under]] .smaller = true := by decide
def e2262374854062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2262374854062 : Closed e2262374854062 ∧ code e2262374854062 = 11058467876270 := by decide
theorem cert_e2262374854062 : check e2262374854062 [[],[.under]] .smaller = true := by decide
def e2262374854074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2262374854074 : Closed e2262374854074 ∧ code e2262374854074 = 11058467876282 := by decide
theorem cert_e2262374854074 : check e2262374854074 [[],[.under]] .smaller = true := by decide
def e2262374854102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2262374854102 : Closed e2262374854102 ∧ code e2262374854102 = 11058467876310 := by decide
theorem cert_e2262374854102 : check e2262374854102 [[],[.under]] .smaller = true := by decide
def e2262374854106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2262374854106 : Closed e2262374854106 ∧ code e2262374854106 = 11058467876314 := by decide
theorem cert_e2262374854106 : check e2262374854106 [[],[.under]] .smaller = true := by decide
def e2262374854318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2262374854318 : Closed e2262374854318 ∧ code e2262374854318 = 11058467876526 := by decide
theorem cert_e2262374854318 : check e2262374854318 [[],[.under]] .smaller = true := by decide
def e2262374854330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2262374854330 : Closed e2262374854330 ∧ code e2262374854330 = 11058467876538 := by decide
theorem cert_e2262374854330 : check e2262374854330 [[],[.under]] .smaller = true := by decide
def e2262374854378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2262374854378 : Closed e2262374854378 ∧ code e2262374854378 = 11058467876586 := by decide
theorem cert_e2262374854378 : check e2262374854378 [[],[.under]] .smaller = true := by decide
def e2262374854486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2262374854486 : Closed e2262374854486 ∧ code e2262374854486 = 11058467876694 := by decide
theorem cert_e2262374854486 : check e2262374854486 [[],[.under]] .smaller = true := by decide
def e2262374854490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2262374854490 : Closed e2262374854490 ∧ code e2262374854490 = 11058467876698 := by decide
theorem cert_e2262374854490 : check e2262374854490 [[],[.under]] .smaller = true := by decide
def e2262374854506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2262374854506 : Closed e2262374854506 ∧ code e2262374854506 = 11058467876714 := by decide
theorem cert_e2262374854506 : check e2262374854506 [[],[.under]] .smaller = true := by decide
def e2262374855134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2262374855134 : Closed e2262374855134 ∧ code e2262374855134 = 11058467877342 := by decide
theorem cert_e2262374855134 : check e2262374855134 [[],[.under]] .three = true := by decide
def e2262374855158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2262374855158 : Closed e2262374855158 ∧ code e2262374855158 = 11058467877366 := by decide
theorem cert_e2262374855158 : check e2262374855158 [[],[.under]] .three = true := by decide
def e2262374855534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2262374855534 : Closed e2262374855534 ∧ code e2262374855534 = 11058467877742 := by decide
theorem cert_e2262374855534 : check e2262374855534 [[],[.under]] .smaller = true := by decide
def e2262374855542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2262374855542 : Closed e2262374855542 ∧ code e2262374855542 = 11058467877750 := by decide
theorem cert_e2262374855542 : check e2262374855542 [[],[.under]] .smaller = true := by decide
def e2262374855598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2262374855598 : Closed e2262374855598 ∧ code e2262374855598 = 11058467877806 := by decide
theorem cert_e2262374855598 : check e2262374855598 [[],[.under]] .smaller = true := by decide
def e2262374855610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2262374855610 : Closed e2262374855610 ∧ code e2262374855610 = 11058467877818 := by decide
theorem cert_e2262374855610 : check e2262374855610 [[],[.under]] .smaller = true := by decide
def e2262374855638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2262374855638 : Closed e2262374855638 ∧ code e2262374855638 = 11058467877846 := by decide
theorem cert_e2262374855638 : check e2262374855638 [[],[.under]] .smaller = true := by decide
def e2262374855642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2262374855642 : Closed e2262374855642 ∧ code e2262374855642 = 11058467877850 := by decide
theorem cert_e2262374855642 : check e2262374855642 [[],[.under]] .smaller = true := by decide
def e2262374855918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262374855918 : Closed e2262374855918 ∧ code e2262374855918 = 11058467878126 := by decide
theorem cert_e2262374855918 : check e2262374855918 [[],[.under]] .smaller = true := by decide
def e2262374855926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262374855926 : Closed e2262374855926 ∧ code e2262374855926 = 11058467878134 := by decide
theorem cert_e2262374855926 : check e2262374855926 [[],[.under]] .smaller = true := by decide
def e2262374856254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2262374856254 : Closed e2262374856254 ∧ code e2262374856254 = 11058467878462 := by decide
theorem cert_e2262374856254 : check e2262374856254 [[],[.under]] .three = true := by decide
def e2262374856302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374856302 : Closed e2262374856302 ∧ code e2262374856302 = 11058467878510 := by decide
theorem cert_e2262374856302 : check e2262374856302 [[],[.under]] .smaller = true := by decide
def e2262374856314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374856314 : Closed e2262374856314 ∧ code e2262374856314 = 11058467878522 := by decide
theorem cert_e2262374856314 : check e2262374856314 [[],[.under]] .smaller = true := by decide
def e2262374856502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374856502 : Closed e2262374856502 ∧ code e2262374856502 = 11058467878710 := by decide
theorem cert_e2262374856502 : check e2262374856502 [[],[.under]] .smaller = true := by decide
def e2262374856506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374856506 : Closed e2262374856506 ∧ code e2262374856506 = 11058467878714 := by decide
theorem cert_e2262374856506 : check e2262374856506 [[],[.under]] .smaller = true := by decide
def e2262374856590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2262374856590 : Closed e2262374856590 ∧ code e2262374856590 = 11058467878798 := by decide
theorem cert_e2262374856590 : check e2262374856590 [[],[.under]] .three = true := by decide
def e2262374856926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2262374856926 : Closed e2262374856926 ∧ code e2262374856926 = 11058467879134 := by decide
theorem cert_e2262374856926 : check e2262374856926 [[],[.under]] .three = true := by decide
def e2262374856942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2262374856942 : Closed e2262374856942 ∧ code e2262374856942 = 11058467879150 := by decide
theorem cert_e2262374856942 : check e2262374856942 [[],[.under]] .smaller = true := by decide
def e2262374856950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2262374856950 : Closed e2262374856950 ∧ code e2262374856950 = 11058467879158 := by decide
theorem cert_e2262374856950 : check e2262374856950 [[],[.under]] .smaller = true := by decide
def e2262374856954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2262374856954 : Closed e2262374856954 ∧ code e2262374856954 = 11058467879162 := by decide
theorem cert_e2262374856954 : check e2262374856954 [[],[.under]] .three = true := by decide
def e2262374857134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2262374857134 : Closed e2262374857134 ∧ code e2262374857134 = 11058467879342 := by decide
theorem cert_e2262374857134 : check e2262374857134 [[],[.under]] .smaller = true := by decide
def e2262374857146 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2262374857146 : Closed e2262374857146 ∧ code e2262374857146 = 11058467879354 := by decide
theorem cert_e2262374857146 : check e2262374857146 [[],[.under]] .smaller = true := by decide
def e2262374857194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2262374857194 : Closed e2262374857194 ∧ code e2262374857194 = 11058467879402 := by decide
theorem cert_e2262374857194 : check e2262374857194 [[],[.under]] .smaller = true := by decide
def e2262374857278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2262374857278 : Closed e2262374857278 ∧ code e2262374857278 = 11058467879486 := by decide
theorem cert_e2262374857278 : check e2262374857278 [[],[.under]] .three = true := by decide
def e2262374857326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374857326 : Closed e2262374857326 ∧ code e2262374857326 = 11058467879534 := by decide
theorem cert_e2262374857326 : check e2262374857326 [[],[.under]] .smaller = true := by decide
def e2262374857338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374857338 : Closed e2262374857338 ∧ code e2262374857338 = 11058467879546 := by decide
theorem cert_e2262374857338 : check e2262374857338 [[],[.under]] .smaller = true := by decide
def e2262374857502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2262374857502 : Closed e2262374857502 ∧ code e2262374857502 = 11058467879710 := by decide
theorem cert_e2262374857502 : check e2262374857502 [[],[.under]] .smaller = true := by decide
def e2262374857614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2262374857614 : Closed e2262374857614 ∧ code e2262374857614 = 11058467879822 := by decide
theorem cert_e2262374857614 : check e2262374857614 [[],[.under]] .smaller = true := by decide
def e2262374857626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374857626 : Closed e2262374857626 ∧ code e2262374857626 = 11058467879834 := by decide
theorem cert_e2262374857626 : check e2262374857626 [[],[.under]] .smaller = true := by decide
def e2262374857670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2262374857670 : Closed e2262374857670 ∧ code e2262374857670 = 11058467879878 := by decide
theorem cert_e2262374857670 : check e2262374857670 [[],[.under]] .three = true := by decide
def e2262374857694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 3))))))))
theorem wire_e2262374857694 : Closed e2262374857694 ∧ code e2262374857694 = 11058467879902 := by decide
theorem cert_e2262374857694 : check e2262374857694 [[],[.under]] .three = true := by decide
def e2262374857846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2262374857846 : Closed e2262374857846 ∧ code e2262374857846 = 11058467880054 := by decide
theorem cert_e2262374857846 : check e2262374857846 [[],[.under]] .smaller = true := by decide
def e2262374857942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2262374857942 : Closed e2262374857942 ∧ code e2262374857942 = 11058467880150 := by decide
theorem cert_e2262374857942 : check e2262374857942 [[],[.under]] .smaller = true := by decide
def e2262374857946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2262374857946 : Closed e2262374857946 ∧ code e2262374857946 = 11058467880154 := by decide
theorem cert_e2262374857946 : check e2262374857946 [[],[.under]] .smaller = true := by decide
def e2262374857962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2262374857962 : Closed e2262374857962 ∧ code e2262374857962 = 11058467880170 := by decide
theorem cert_e2262374857962 : check e2262374857962 [[],[.under]] .smaller = true := by decide
def e2262374858038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374858038 : Closed e2262374858038 ∧ code e2262374858038 = 11058467880246 := by decide
theorem cert_e2262374858038 : check e2262374858038 [[],[.under]] .smaller = true := by decide
def e2262374858042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374858042 : Closed e2262374858042 ∧ code e2262374858042 = 11058467880250 := by decide
theorem cert_e2262374858042 : check e2262374858042 [[],[.under]] .smaller = true := by decide
def e2262374858126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2262374858126 : Closed e2262374858126 ∧ code e2262374858126 = 11058467880334 := by decide
theorem cert_e2262374858126 : check e2262374858126 [[],[.under]] .smaller = true := by decide
def e2262374858138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374858138 : Closed e2262374858138 ∧ code e2262374858138 = 11058467880346 := by decide
theorem cert_e2262374858138 : check e2262374858138 [[],[.under]] .smaller = true := by decide
def e2262374858206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e2262374858206 : Closed e2262374858206 ∧ code e2262374858206 = 11058467880414 := by decide
theorem cert_e2262374858206 : check e2262374858206 [[],[.under]] .three = true := by decide
def e2262374858222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e2262374858222 : Closed e2262374858222 ∧ code e2262374858222 = 11058467880430 := by decide
theorem cert_e2262374858222 : check e2262374858222 [[],[.under]] .three = true := by decide
def e2262374858294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2262374858294 : Closed e2262374858294 ∧ code e2262374858294 = 11058467880502 := by decide
theorem cert_e2262374858294 : check e2262374858294 [[],[.under]] .three = true := by decide
def e2262374858298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2262374858298 : Closed e2262374858298 ∧ code e2262374858298 = 11058467880506 := by decide
theorem cert_e2262374858298 : check e2262374858298 [[],[.under]] .three = true := by decide
def e2262374858382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2262374858382 : Closed e2262374858382 ∧ code e2262374858382 = 11058467880590 := by decide
theorem cert_e2262374858382 : check e2262374858382 [[],[.under]] .three = true := by decide
def e2262374858438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2262374858438 : Closed e2262374858438 ∧ code e2262374858438 = 11058467880646 := by decide
theorem cert_e2262374858438 : check e2262374858438 [[],[.under]] .three = true := by decide
def e2262374858462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 3))))))))
theorem wire_e2262374858462 : Closed e2262374858462 ∧ code e2262374858462 = 11058467880670 := by decide
theorem cert_e2262374858462 : check e2262374858462 [[],[.under]] .three = true := by decide
def e2262374858478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e2262374858478 : Closed e2262374858478 ∧ code e2262374858478 = 11058467880686 := by decide
theorem cert_e2262374858478 : check e2262374858478 [[],[.under]] .three = true := by decide
def e2262374858486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 1))))))))
theorem wire_e2262374858486 : Closed e2262374858486 ∧ code e2262374858486 = 11058467880694 := by decide
theorem cert_e2262374858486 : check e2262374858486 [[],[.under]] .three = true := by decide
def e2262374859742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2262374859742 : Closed e2262374859742 ∧ code e2262374859742 = 11058467881950 := by decide
theorem cert_e2262374859742 : check e2262374859742 [[],[.under]] .smaller = true := by decide
def e2262374859758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2262374859758 : Closed e2262374859758 ∧ code e2262374859758 = 11058467881966 := by decide
theorem cert_e2262374859758 : check e2262374859758 [[],[.under]] .smaller = true := by decide
def e2262374861678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262374861678 : Closed e2262374861678 ∧ code e2262374861678 = 11058467883886 := by decide
theorem cert_e2262374861678 : check e2262374861678 [[],[.under]] .smaller = true := by decide
def e2262374861686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262374861686 : Closed e2262374861686 ∧ code e2262374861686 = 11058467883894 := by decide
theorem cert_e2262374861686 : check e2262374861686 [[],[.under]] .smaller = true := by decide
def e2262374861742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262374861742 : Closed e2262374861742 ∧ code e2262374861742 = 11058467883950 := by decide
theorem cert_e2262374861742 : check e2262374861742 [[],[.under]] .smaller = true := by decide
def e2262374861754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262374861754 : Closed e2262374861754 ∧ code e2262374861754 = 11058467883962 := by decide
theorem cert_e2262374861754 : check e2262374861754 [[],[.under]] .smaller = true := by decide
def e2262374861782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262374861782 : Closed e2262374861782 ∧ code e2262374861782 = 11058467883990 := by decide
theorem cert_e2262374861782 : check e2262374861782 [[],[.under]] .smaller = true := by decide
def e2262374861786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262374861786 : Closed e2262374861786 ∧ code e2262374861786 = 11058467883994 := by decide
theorem cert_e2262374861786 : check e2262374861786 [[],[.under]] .smaller = true := by decide
def e2262374862062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262374862062 : Closed e2262374862062 ∧ code e2262374862062 = 11058467884270 := by decide
theorem cert_e2262374862062 : check e2262374862062 [[],[.under]] .smaller = true := by decide
def e2262374862070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262374862070 : Closed e2262374862070 ∧ code e2262374862070 = 11058467884278 := by decide
theorem cert_e2262374862070 : check e2262374862070 [[],[.under]] .smaller = true := by decide
def e2262374862398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2262374862398 : Closed e2262374862398 ∧ code e2262374862398 = 11058467884606 := by decide
theorem cert_e2262374862398 : check e2262374862398 [[],[.under]] .three = true := by decide
def e2262374862446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262374862446 : Closed e2262374862446 ∧ code e2262374862446 = 11058467884654 := by decide
theorem cert_e2262374862446 : check e2262374862446 [[],[.under]] .smaller = true := by decide
def e2262374862458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262374862458 : Closed e2262374862458 ∧ code e2262374862458 = 11058467884666 := by decide
theorem cert_e2262374862458 : check e2262374862458 [[],[.under]] .smaller = true := by decide
def e2262374862646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374862646 : Closed e2262374862646 ∧ code e2262374862646 = 11058467884854 := by decide
theorem cert_e2262374862646 : check e2262374862646 [[],[.under]] .smaller = true := by decide
def e2262374862650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374862650 : Closed e2262374862650 ∧ code e2262374862650 = 11058467884858 := by decide
theorem cert_e2262374862650 : check e2262374862650 [[],[.under]] .smaller = true := by decide
def e2262374862734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2262374862734 : Closed e2262374862734 ∧ code e2262374862734 = 11058467884942 := by decide
theorem cert_e2262374862734 : check e2262374862734 [[],[.under]] .three = true := by decide
def e2262374867422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2262374867422 : Closed e2262374867422 ∧ code e2262374867422 = 11058467889630 := by decide
theorem cert_e2262374867422 : check e2262374867422 [[],[.under]] .smaller = true := by decide
def e2262374867446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2262374867446 : Closed e2262374867446 ∧ code e2262374867446 = 11058467889654 := by decide
theorem cert_e2262374867446 : check e2262374867446 [[],[.under]] .smaller = true := by decide
def e2262374868398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2262374868398 : Closed e2262374868398 ∧ code e2262374868398 = 11058467890606 := by decide
theorem cert_e2262374868398 : check e2262374868398 [[],[.under]] .smaller = true := by decide
def e2262374868410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2262374868410 : Closed e2262374868410 ∧ code e2262374868410 = 11058467890618 := by decide
theorem cert_e2262374868410 : check e2262374868410 [[],[.under]] .smaller = true := by decide
def e2262374868458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2262374868458 : Closed e2262374868458 ∧ code e2262374868458 = 11058467890666 := by decide
theorem cert_e2262374868458 : check e2262374868458 [[],[.under]] .smaller = true := by decide
def e2262374868542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2262374868542 : Closed e2262374868542 ∧ code e2262374868542 = 11058467890750 := by decide
theorem cert_e2262374868542 : check e2262374868542 [[],[.under]] .three = true := by decide
def e2262374868590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262374868590 : Closed e2262374868590 ∧ code e2262374868590 = 11058467890798 := by decide
theorem cert_e2262374868590 : check e2262374868590 [[],[.under]] .smaller = true := by decide
def e2262374868602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262374868602 : Closed e2262374868602 ∧ code e2262374868602 = 11058467890810 := by decide
theorem cert_e2262374868602 : check e2262374868602 [[],[.under]] .smaller = true := by decide
def e2262374868766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2262374868766 : Closed e2262374868766 ∧ code e2262374868766 = 11058467890974 := by decide
theorem cert_e2262374868766 : check e2262374868766 [[],[.under]] .smaller = true := by decide
def e2262374868878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2262374868878 : Closed e2262374868878 ∧ code e2262374868878 = 11058467891086 := by decide
theorem cert_e2262374868878 : check e2262374868878 [[],[.under]] .smaller = true := by decide
def e2262374868890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374868890 : Closed e2262374868890 ∧ code e2262374868890 = 11058467891098 := by decide
theorem cert_e2262374868890 : check e2262374868890 [[],[.under]] .smaller = true := by decide
def e2262374868934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2262374868934 : Closed e2262374868934 ∧ code e2262374868934 = 11058467891142 := by decide
theorem cert_e2262374868934 : check e2262374868934 [[],[.under]] .three = true := by decide
def e2262374868958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 3)))))))))
theorem wire_e2262374868958 : Closed e2262374868958 ∧ code e2262374868958 = 11058467891166 := by decide
theorem cert_e2262374868958 : check e2262374868958 [[],[.under]] .three = true := by decide
def e2262374871278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2262374871278 : Closed e2262374871278 ∧ code e2262374871278 = 11058467893486 := by decide
theorem cert_e2262374871278 : check e2262374871278 [[],[.under]] .smaller = true := by decide
def e2262374871286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2262374871286 : Closed e2262374871286 ∧ code e2262374871286 = 11058467893494 := by decide
theorem cert_e2262374871286 : check e2262374871286 [[],[.under]] .smaller = true := by decide
def e2262374871766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2262374871766 : Closed e2262374871766 ∧ code e2262374871766 = 11058467893974 := by decide
theorem cert_e2262374871766 : check e2262374871766 [[],[.under]] .smaller = true := by decide
def e2262374871770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2262374871770 : Closed e2262374871770 ∧ code e2262374871770 = 11058467893978 := by decide
theorem cert_e2262374871770 : check e2262374871770 [[],[.under]] .smaller = true := by decide
def e2262374871786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2262374871786 : Closed e2262374871786 ∧ code e2262374871786 = 11058467893994 := by decide
theorem cert_e2262374871786 : check e2262374871786 [[],[.under]] .smaller = true := by decide
def e2262374871862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262374871862 : Closed e2262374871862 ∧ code e2262374871862 = 11058467894070 := by decide
theorem cert_e2262374871862 : check e2262374871862 [[],[.under]] .smaller = true := by decide
def e2262374871866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262374871866 : Closed e2262374871866 ∧ code e2262374871866 = 11058467894074 := by decide
theorem cert_e2262374871866 : check e2262374871866 [[],[.under]] .smaller = true := by decide
def e2262374871950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2262374871950 : Closed e2262374871950 ∧ code e2262374871950 = 11058467894158 := by decide
theorem cert_e2262374871950 : check e2262374871950 [[],[.under]] .smaller = true := by decide
def e2262374871962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374871962 : Closed e2262374871962 ∧ code e2262374871962 = 11058467894170 := by decide
theorem cert_e2262374871962 : check e2262374871962 [[],[.under]] .smaller = true := by decide
def e2262374872030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e2262374872030 : Closed e2262374872030 ∧ code e2262374872030 = 11058467894238 := by decide
theorem cert_e2262374872030 : check e2262374872030 [[],[.under]] .three = true := by decide
def e2262374872046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e2262374872046 : Closed e2262374872046 ∧ code e2262374872046 = 11058467894254 := by decide
theorem cert_e2262374872046 : check e2262374872046 [[],[.under]] .three = true := by decide
def e2262374873486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2262374873486 : Closed e2262374873486 ∧ code e2262374873486 = 11058467895694 := by decide
theorem cert_e2262374873486 : check e2262374873486 [[],[.under]] .three = true := by decide
def e2262374873542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2262374873542 : Closed e2262374873542 ∧ code e2262374873542 = 11058467895750 := by decide
theorem cert_e2262374873542 : check e2262374873542 [[],[.under]] .three = true := by decide
def e2262374873566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 3)))))))))
theorem wire_e2262374873566 : Closed e2262374873566 ∧ code e2262374873566 = 11058467895774 := by decide
theorem cert_e2262374873566 : check e2262374873566 [[],[.under]] .three = true := by decide
def e2262374873582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262374873582 : Closed e2262374873582 ∧ code e2262374873582 = 11058467895790 := by decide
theorem cert_e2262374873582 : check e2262374873582 [[],[.under]] .three = true := by decide
def e2262374873590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 1)))))))))
theorem wire_e2262374873590 : Closed e2262374873590 ∧ code e2262374873590 = 11058467895798 := by decide
theorem cert_e2262374873590 : check e2262374873590 [[],[.under]] .three = true := by decide
def e2262374962862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2262374962862 : Closed e2262374962862 ∧ code e2262374962862 = 11058467985070 := by decide
theorem cert_e2262374962862 : check e2262374962862 [[],[.under]] .smaller = true := by decide
def e2262374962874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2262374962874 : Closed e2262374962874 ∧ code e2262374962874 = 11058467985082 := by decide
theorem cert_e2262374962874 : check e2262374962874 [[],[.under]] .smaller = true := by decide
def e2262374962922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2262374962922 : Closed e2262374962922 ∧ code e2262374962922 = 11058467985130 := by decide
theorem cert_e2262374962922 : check e2262374962922 [[],[.under]] .smaller = true := by decide
def e2262374963114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2262374963114 : Closed e2262374963114 ∧ code e2262374963114 = 11058467985322 := by decide
theorem cert_e2262374963114 : check e2262374963114 [[],[.under]] .smaller = true := by decide
def e2262374963422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2262374963422 : Closed e2262374963422 ∧ code e2262374963422 = 11058467985630 := by decide
theorem cert_e2262374963422 : check e2262374963422 [[],[.under]] .three = true := by decide
def e2262374963438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2262374963438 : Closed e2262374963438 ∧ code e2262374963438 = 11058467985646 := by decide
theorem cert_e2262374963438 : check e2262374963438 [[],[.under]] .smaller = true := by decide
def e2262374963446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2262374963446 : Closed e2262374963446 ∧ code e2262374963446 = 11058467985654 := by decide
theorem cert_e2262374963446 : check e2262374963446 [[],[.under]] .smaller = true := by decide
def e2262374963450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2262374963450 : Closed e2262374963450 ∧ code e2262374963450 = 11058467985658 := by decide
theorem cert_e2262374963450 : check e2262374963450 [[],[.under]] .three = true := by decide
def e2262374963630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2262374963630 : Closed e2262374963630 ∧ code e2262374963630 = 11058467985838 := by decide
theorem cert_e2262374963630 : check e2262374963630 [[],[.under]] .smaller = true := by decide
def e2262374963642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2262374963642 : Closed e2262374963642 ∧ code e2262374963642 = 11058467985850 := by decide
theorem cert_e2262374963642 : check e2262374963642 [[],[.under]] .smaller = true := by decide
def e2262374963690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2262374963690 : Closed e2262374963690 ∧ code e2262374963690 = 11058467985898 := by decide
theorem cert_e2262374963690 : check e2262374963690 [[],[.under]] .smaller = true := by decide
def e2262374963774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2262374963774 : Closed e2262374963774 ∧ code e2262374963774 = 11058467985982 := by decide
theorem cert_e2262374963774 : check e2262374963774 [[],[.under]] .three = true := by decide
def e2262374963822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374963822 : Closed e2262374963822 ∧ code e2262374963822 = 11058467986030 := by decide
theorem cert_e2262374963822 : check e2262374963822 [[],[.under]] .smaller = true := by decide
def e2262374963834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374963834 : Closed e2262374963834 ∧ code e2262374963834 = 11058467986042 := by decide
theorem cert_e2262374963834 : check e2262374963834 [[],[.under]] .smaller = true := by decide
def e2262374963998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2262374963998 : Closed e2262374963998 ∧ code e2262374963998 = 11058467986206 := by decide
theorem cert_e2262374963998 : check e2262374963998 [[],[.under]] .smaller = true := by decide
def e2262374964110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2262374964110 : Closed e2262374964110 ∧ code e2262374964110 = 11058467986318 := by decide
theorem cert_e2262374964110 : check e2262374964110 [[],[.under]] .smaller = true := by decide
def e2262374964122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374964122 : Closed e2262374964122 ∧ code e2262374964122 = 11058467986330 := by decide
theorem cert_e2262374964122 : check e2262374964122 [[],[.under]] .smaller = true := by decide
def e2262374964166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2262374964166 : Closed e2262374964166 ∧ code e2262374964166 = 11058467986374 := by decide
theorem cert_e2262374964166 : check e2262374964166 [[],[.under]] .three = true := by decide
def e2262374964190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 3))))))))
theorem wire_e2262374964190 : Closed e2262374964190 ∧ code e2262374964190 = 11058467986398 := by decide
theorem cert_e2262374964190 : check e2262374964190 [[],[.under]] .three = true := by decide
def e2262374964334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2262374964334 : Closed e2262374964334 ∧ code e2262374964334 = 11058467986542 := by decide
theorem cert_e2262374964334 : check e2262374964334 [[],[.under]] .smaller = true := by decide
def e2262374964346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2262374964346 : Closed e2262374964346 ∧ code e2262374964346 = 11058467986554 := by decide
theorem cert_e2262374964346 : check e2262374964346 [[],[.under]] .smaller = true := by decide
def e2262374964510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2262374964510 : Closed e2262374964510 ∧ code e2262374964510 = 11058467986718 := by decide
theorem cert_e2262374964510 : check e2262374964510 [[],[.under]] .smaller = true := by decide
def e2262374964678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2262374964678 : Closed e2262374964678 ∧ code e2262374964678 = 11058467986886 := by decide
theorem cert_e2262374964678 : check e2262374964678 [[],[.under]] .smaller = true := by decide
def e2262374964702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2262374964702 : Closed e2262374964702 ∧ code e2262374964702 = 11058467986910 := by decide
theorem cert_e2262374964702 : check e2262374964702 [[],[.under]] .three = true := by decide
def e2262374964718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2262374964718 : Closed e2262374964718 ∧ code e2262374964718 = 11058467986926 := by decide
theorem cert_e2262374964718 : check e2262374964718 [[],[.under]] .three = true := by decide
def e2262374964790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2262374964790 : Closed e2262374964790 ∧ code e2262374964790 = 11058467986998 := by decide
theorem cert_e2262374964790 : check e2262374964790 [[],[.under]] .smaller = true := by decide
def e2262374964794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2262374964794 : Closed e2262374964794 ∧ code e2262374964794 = 11058467987002 := by decide
theorem cert_e2262374964794 : check e2262374964794 [[],[.under]] .smaller = true := by decide
def e2262374964842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2262374964842 : Closed e2262374964842 ∧ code e2262374964842 = 11058467987050 := by decide
theorem cert_e2262374964842 : check e2262374964842 [[],[.under]] .smaller = true := by decide
def e2262374964878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2262374964878 : Closed e2262374964878 ∧ code e2262374964878 = 11058467987086 := by decide
theorem cert_e2262374964878 : check e2262374964878 [[],[.under]] .smaller = true := by decide
def e2262374964890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374964890 : Closed e2262374964890 ∧ code e2262374964890 = 11058467987098 := by decide
theorem cert_e2262374964890 : check e2262374964890 [[],[.under]] .smaller = true := by decide
def e2262374964934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2262374964934 : Closed e2262374964934 ∧ code e2262374964934 = 11058467987142 := by decide
theorem cert_e2262374964934 : check e2262374964934 [[],[.under]] .smaller = true := by decide
def e2262374964958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2262374964958 : Closed e2262374964958 ∧ code e2262374964958 = 11058467987166 := by decide
theorem cert_e2262374964958 : check e2262374964958 [[],[.under]] .three = true := by decide
def e2262374964982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2262374964982 : Closed e2262374964982 ∧ code e2262374964982 = 11058467987190 := by decide
theorem cert_e2262374964982 : check e2262374964982 [[],[.under]] .three = true := by decide
def e2262374965018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2262374965018 : Closed e2262374965018 ∧ code e2262374965018 = 11058467987226 := by decide
theorem cert_e2262374965018 : check e2262374965018 [[],[.under]] .three = true := by decide
def e2262374965062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2262374965062 : Closed e2262374965062 ∧ code e2262374965062 = 11058467987270 := by decide
theorem cert_e2262374965062 : check e2262374965062 [[],[.under]] .three = true := by decide
def e2262374965086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 3))))))))
theorem wire_e2262374965086 : Closed e2262374965086 ∧ code e2262374965086 = 11058467987294 := by decide
theorem cert_e2262374965086 : check e2262374965086 [[],[.under]] .three = true := by decide
def e2262374965102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2262374965102 : Closed e2262374965102 ∧ code e2262374965102 = 11058467987310 := by decide
theorem cert_e2262374965102 : check e2262374965102 [[],[.under]] .three = true := by decide
def e2262374965110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2262374965110 : Closed e2262374965110 ∧ code e2262374965110 = 11058467987318 := by decide
theorem cert_e2262374965110 : check e2262374965110 [[],[.under]] .three = true := by decide
def e2262374965114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 0))))))))
theorem wire_e2262374965114 : Closed e2262374965114 ∧ code e2262374965114 = 11058467987322 := by decide
theorem cert_e2262374965114 : check e2262374965114 [[],[.under]] .three = true := by decide
def e2262374965726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2262374965726 : Closed e2262374965726 ∧ code e2262374965726 = 11058467987934 := by decide
theorem cert_e2262374965726 : check e2262374965726 [[],[.under]] .smaller = true := by decide
def e2262374965750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2262374965750 : Closed e2262374965750 ∧ code e2262374965750 = 11058467987958 := by decide
theorem cert_e2262374965750 : check e2262374965750 [[],[.under]] .smaller = true := by decide
def e2262374966702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2262374966702 : Closed e2262374966702 ∧ code e2262374966702 = 11058467988910 := by decide
theorem cert_e2262374966702 : check e2262374966702 [[],[.under]] .smaller = true := by decide
def e2262374966714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2262374966714 : Closed e2262374966714 ∧ code e2262374966714 = 11058467988922 := by decide
theorem cert_e2262374966714 : check e2262374966714 [[],[.under]] .smaller = true := by decide
def e2262374966762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2262374966762 : Closed e2262374966762 ∧ code e2262374966762 = 11058467988970 := by decide
theorem cert_e2262374966762 : check e2262374966762 [[],[.under]] .smaller = true := by decide
def e2262374966846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2262374966846 : Closed e2262374966846 ∧ code e2262374966846 = 11058467989054 := by decide
theorem cert_e2262374966846 : check e2262374966846 [[],[.under]] .three = true := by decide
def e2262374966894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262374966894 : Closed e2262374966894 ∧ code e2262374966894 = 11058467989102 := by decide
theorem cert_e2262374966894 : check e2262374966894 [[],[.under]] .smaller = true := by decide
def e2262374966906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262374966906 : Closed e2262374966906 ∧ code e2262374966906 = 11058467989114 := by decide
theorem cert_e2262374966906 : check e2262374966906 [[],[.under]] .smaller = true := by decide
def e2262374967070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2262374967070 : Closed e2262374967070 ∧ code e2262374967070 = 11058467989278 := by decide
theorem cert_e2262374967070 : check e2262374967070 [[],[.under]] .smaller = true := by decide
def e2262374967182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2262374967182 : Closed e2262374967182 ∧ code e2262374967182 = 11058467989390 := by decide
theorem cert_e2262374967182 : check e2262374967182 [[],[.under]] .smaller = true := by decide
def e2262374967194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374967194 : Closed e2262374967194 ∧ code e2262374967194 = 11058467989402 := by decide
theorem cert_e2262374967194 : check e2262374967194 [[],[.under]] .smaller = true := by decide
def e2262374967238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2262374967238 : Closed e2262374967238 ∧ code e2262374967238 = 11058467989446 := by decide
theorem cert_e2262374967238 : check e2262374967238 [[],[.under]] .three = true := by decide
def e2262374967262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 3)))))))))
theorem wire_e2262374967262 : Closed e2262374967262 ∧ code e2262374967262 = 11058467989470 := by decide
theorem cert_e2262374967262 : check e2262374967262 [[],[.under]] .three = true := by decide
def e2262374970142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2262374970142 : Closed e2262374970142 ∧ code e2262374970142 = 11058467992350 := by decide
theorem cert_e2262374970142 : check e2262374970142 [[],[.under]] .smaller = true := by decide
end Blc.Floor43
