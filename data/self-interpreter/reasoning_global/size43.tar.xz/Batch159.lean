import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2260713854490 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260713854490 : Closed e2260713854490 ∧ code e2260713854490 = 11056806876698 := by decide
theorem cert_e2260713854490 : check e2260713854490 [[]] .width = true := by decide
def e2260713855514 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260713855514 : Closed e2260713855514 ∧ code e2260713855514 = 11056806877722 := by decide
theorem cert_e2260713855514 : check e2260713855514 [[]] .width = true := by decide
def e2260713926170 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260713926170 : Closed e2260713926170 ∧ code e2260713926170 = 11056806948378 := by decide
theorem cert_e2260713926170 : check e2260713926170 [[]] .width = true := by decide
def e2260713928218 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260713928218 : Closed e2260713928218 ∧ code e2260713928218 = 11056806950426 := by decide
theorem cert_e2260713928218 : check e2260713928218 [[]] .width = true := by decide
def e2260714024474 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260714024474 : Closed e2260714024474 ∧ code e2260714024474 = 11056807046682 := by decide
theorem cert_e2260714024474 : check e2260714024474 [[]] .width = true := by decide
def e2260714027546 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260714027546 : Closed e2260714027546 ∧ code e2260714027546 = 11056807049754 := by decide
theorem cert_e2260714027546 : check e2260714027546 [[]] .width = true := by decide
def e2260714075674 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260714075674 : Closed e2260714075674 ∧ code e2260714075674 = 11056807097882 := by decide
theorem cert_e2260714075674 : check e2260714075674 [[]] .width = true := by decide
def e2260714076698 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260714076698 : Closed e2260714076698 ∧ code e2260714076698 = 11056807098906 := by decide
theorem cert_e2260714076698 : check e2260714076698 [[]] .width = true := by decide
def e2260787380422 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260787380422 : Closed e2260787380422 ∧ code e2260787380422 = 11056880402630 := by decide
theorem cert_e2260787380422 : check e2260787380422 [[]] .width = true := by decide
def e2260787445958 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260787445958 : Closed e2260787445958 ∧ code e2260787445958 = 11056880468166 := by decide
theorem cert_e2260787445958 : check e2260787445958 [[]] .width = true := by decide
def e2260787904710 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260787904710 : Closed e2260787904710 ∧ code e2260787904710 = 11056880926918 := by decide
theorem cert_e2260787904710 : check e2260787904710 [[]] .width = true := by decide
def e2260788003014 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260788003014 : Closed e2260788003014 ∧ code e2260788003014 = 11056881025222 := by decide
theorem cert_e2260788003014 : check e2260788003014 [[]] .width = true := by decide
def e2260788232390 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260788232390 : Closed e2260788232390 ∧ code e2260788232390 = 11056881254598 := by decide
theorem cert_e2260788232390 : check e2260788232390 [[]] .width = true := by decide
def e2260788265158 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260788265158 : Closed e2260788265158 ∧ code e2260788265158 = 11056881287366 := by decide
theorem cert_e2260788265158 : check e2260788265158 [[]] .width = true := by decide
def e2260790526150 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260790526150 : Closed e2260790526150 ∧ code e2260790526150 = 11056883548358 := by decide
theorem cert_e2260790526150 : check e2260790526150 [[]] .width = true := by decide
def e2260790591686 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260790591686 : Closed e2260790591686 ∧ code e2260790591686 = 11056883613894 := by decide
theorem cert_e2260790591686 : check e2260790591686 [[]] .width = true := by decide
def e2260793671878 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260793671878 : Closed e2260793671878 ∧ code e2260793671878 = 11056886694086 := by decide
theorem cert_e2260793671878 : check e2260793671878 [[]] .width = true := by decide
def e2260793770182 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260793770182 : Closed e2260793770182 ∧ code e2260793770182 = 11056886792390 := by decide
theorem cert_e2260793770182 : check e2260793770182 [[]] .width = true := by decide
def e2260795310278 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260795310278 : Closed e2260795310278 ∧ code e2260795310278 = 11056888332486 := by decide
theorem cert_e2260795310278 : check e2260795310278 [[]] .width = true := by decide
def e2260795343046 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2260795343046 : Closed e2260795343046 ∧ code e2260795343046 = 11056888365254 := by decide
theorem cert_e2260795343046 : check e2260795343046 [[]] .width = true := by decide
def e2260881600026 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881600026 : Closed e2260881600026 ∧ code e2260881600026 = 11056974622234 := by decide
theorem cert_e2260881600026 : check e2260881600026 [[]] .width = true := by decide
def e2260881602074 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881602074 : Closed e2260881602074 ∧ code e2260881602074 = 11056974624282 := by decide
theorem cert_e2260881602074 : check e2260881602074 [[]] .width = true := by decide
def e2260881616410 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881616410 : Closed e2260881616410 ∧ code e2260881616410 = 11056974638618 := by decide
theorem cert_e2260881616410 : check e2260881616410 [[]] .width = true := by decide
def e2260881619482 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881619482 : Closed e2260881619482 ∧ code e2260881619482 = 11056974641690 := by decide
theorem cert_e2260881619482 : check e2260881619482 [[]] .width = true := by decide
def e2260881626650 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881626650 : Closed e2260881626650 ∧ code e2260881626650 = 11056974648858 := by decide
theorem cert_e2260881626650 : check e2260881626650 [[]] .width = true := by decide
def e2260881627674 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881627674 : Closed e2260881627674 ∧ code e2260881627674 = 11056974649882 := by decide
theorem cert_e2260881627674 : check e2260881627674 [[]] .width = true := by decide
def e2260881698330 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881698330 : Closed e2260881698330 ∧ code e2260881698330 = 11056974720538 := by decide
theorem cert_e2260881698330 : check e2260881698330 [[]] .width = true := by decide
def e2260881700378 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881700378 : Closed e2260881700378 ∧ code e2260881700378 = 11056974722586 := by decide
theorem cert_e2260881700378 : check e2260881700378 [[]] .width = true := by decide
def e2260881796634 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881796634 : Closed e2260881796634 ∧ code e2260881796634 = 11056974818842 := by decide
theorem cert_e2260881796634 : check e2260881796634 [[]] .width = true := by decide
def e2260881799706 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881799706 : Closed e2260881799706 ∧ code e2260881799706 = 11056974821914 := by decide
theorem cert_e2260881799706 : check e2260881799706 [[]] .width = true := by decide
def e2260881847834 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881847834 : Closed e2260881847834 ∧ code e2260881847834 = 11056974870042 := by decide
theorem cert_e2260881847834 : check e2260881847834 [[]] .width = true := by decide
def e2260881848858 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260881848858 : Closed e2260881848858 ∧ code e2260881848858 = 11056974871066 := by decide
theorem cert_e2260881848858 : check e2260881848858 [[]] .width = true := by decide
def e2260964781422 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2260964781422 : Closed e2260964781422 ∧ code e2260964781422 = 11057057803630 := by decide
theorem cert_e2260964781422 : check e2260964781422 [[],[.under]] .smaller = true := by decide
def e2260964781430 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2260964781430 : Closed e2260964781430 ∧ code e2260964781430 = 11057057803638 := by decide
theorem cert_e2260964781430 : check e2260964781430 [[],[.under]] .smaller = true := by decide
def e2260964781486 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2260964781486 : Closed e2260964781486 ∧ code e2260964781486 = 11057057803694 := by decide
theorem cert_e2260964781486 : check e2260964781486 [[],[.under]] .smaller = true := by decide
def e2260964781498 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2260964781498 : Closed e2260964781498 ∧ code e2260964781498 = 11057057803706 := by decide
theorem cert_e2260964781498 : check e2260964781498 [[],[.under]] .smaller = true := by decide
def e2260964781526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2260964781526 : Closed e2260964781526 ∧ code e2260964781526 = 11057057803734 := by decide
theorem cert_e2260964781526 : check e2260964781526 [[],[.under]] .smaller = true := by decide
def e2260964781530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2260964781530 : Closed e2260964781530 ∧ code e2260964781530 = 11057057803738 := by decide
theorem cert_e2260964781530 : check e2260964781530 [[],[.under]] .smaller = true := by decide
def e2260964781742 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2260964781742 : Closed e2260964781742 ∧ code e2260964781742 = 11057057803950 := by decide
theorem cert_e2260964781742 : check e2260964781742 [[],[.under]] .smaller = true := by decide
def e2260964781754 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2260964781754 : Closed e2260964781754 ∧ code e2260964781754 = 11057057803962 := by decide
theorem cert_e2260964781754 : check e2260964781754 [[],[.under]] .smaller = true := by decide
def e2260964781802 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2260964781802 : Closed e2260964781802 ∧ code e2260964781802 = 11057057804010 := by decide
theorem cert_e2260964781802 : check e2260964781802 [[],[.under]] .smaller = true := by decide
def e2260964781910 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2260964781910 : Closed e2260964781910 ∧ code e2260964781910 = 11057057804118 := by decide
theorem cert_e2260964781910 : check e2260964781910 [[],[.under]] .smaller = true := by decide
def e2260964781914 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2260964781914 : Closed e2260964781914 ∧ code e2260964781914 = 11057057804122 := by decide
theorem cert_e2260964781914 : check e2260964781914 [[],[.under]] .smaller = true := by decide
def e2260964781930 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2260964781930 : Closed e2260964781930 ∧ code e2260964781930 = 11057057804138 := by decide
theorem cert_e2260964781930 : check e2260964781930 [[],[.under]] .smaller = true := by decide
def e2260964782958 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2260964782958 : Closed e2260964782958 ∧ code e2260964782958 = 11057057805166 := by decide
theorem cert_e2260964782958 : check e2260964782958 [[],[.under]] .smaller = true := by decide
def e2260964782966 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2260964782966 : Closed e2260964782966 ∧ code e2260964782966 = 11057057805174 := by decide
theorem cert_e2260964782966 : check e2260964782966 [[],[.under]] .smaller = true := by decide
def e2260964783022 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2260964783022 : Closed e2260964783022 ∧ code e2260964783022 = 11057057805230 := by decide
theorem cert_e2260964783022 : check e2260964783022 [[],[.under]] .smaller = true := by decide
def e2260964783034 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2260964783034 : Closed e2260964783034 ∧ code e2260964783034 = 11057057805242 := by decide
theorem cert_e2260964783034 : check e2260964783034 [[],[.under]] .smaller = true := by decide
def e2260964783062 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2260964783062 : Closed e2260964783062 ∧ code e2260964783062 = 11057057805270 := by decide
theorem cert_e2260964783062 : check e2260964783062 [[],[.under]] .smaller = true := by decide
def e2260964783066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2260964783066 : Closed e2260964783066 ∧ code e2260964783066 = 11057057805274 := by decide
theorem cert_e2260964783066 : check e2260964783066 [[],[.under]] .smaller = true := by decide
def e2260964783342 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2260964783342 : Closed e2260964783342 ∧ code e2260964783342 = 11057057805550 := by decide
theorem cert_e2260964783342 : check e2260964783342 [[],[.under]] .smaller = true := by decide
def e2260964783350 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2260964783350 : Closed e2260964783350 ∧ code e2260964783350 = 11057057805558 := by decide
theorem cert_e2260964783350 : check e2260964783350 [[],[.under]] .smaller = true := by decide
def e2260964783726 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2260964783726 : Closed e2260964783726 ∧ code e2260964783726 = 11057057805934 := by decide
theorem cert_e2260964783726 : check e2260964783726 [[],[.under]] .smaller = true := by decide
def e2260964783738 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2260964783738 : Closed e2260964783738 ∧ code e2260964783738 = 11057057805946 := by decide
theorem cert_e2260964783738 : check e2260964783738 [[],[.under]] .smaller = true := by decide
def e2260964783926 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2260964783926 : Closed e2260964783926 ∧ code e2260964783926 = 11057057806134 := by decide
theorem cert_e2260964783926 : check e2260964783926 [[],[.under]] .smaller = true := by decide
def e2260964783930 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2260964783930 : Closed e2260964783930 ∧ code e2260964783930 = 11057057806138 := by decide
theorem cert_e2260964783930 : check e2260964783930 [[],[.under]] .smaller = true := by decide
def e2260964784558 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2260964784558 : Closed e2260964784558 ∧ code e2260964784558 = 11057057806766 := by decide
theorem cert_e2260964784558 : check e2260964784558 [[],[.under]] .smaller = true := by decide
def e2260964784570 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2260964784570 : Closed e2260964784570 ∧ code e2260964784570 = 11057057806778 := by decide
theorem cert_e2260964784570 : check e2260964784570 [[],[.under]] .smaller = true := by decide
def e2260964784618 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2260964784618 : Closed e2260964784618 ∧ code e2260964784618 = 11057057806826 := by decide
theorem cert_e2260964784618 : check e2260964784618 [[],[.under]] .smaller = true := by decide
def e2260964784750 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2260964784750 : Closed e2260964784750 ∧ code e2260964784750 = 11057057806958 := by decide
theorem cert_e2260964784750 : check e2260964784750 [[],[.under]] .smaller = true := by decide
def e2260964784762 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2260964784762 : Closed e2260964784762 ∧ code e2260964784762 = 11057057806970 := by decide
theorem cert_e2260964784762 : check e2260964784762 [[],[.under]] .smaller = true := by decide
def e2260964785050 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2260964785050 : Closed e2260964785050 ∧ code e2260964785050 = 11057057807258 := by decide
theorem cert_e2260964785050 : check e2260964785050 [[],[.under]] .smaller = true := by decide
def e2260964785366 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2260964785366 : Closed e2260964785366 ∧ code e2260964785366 = 11057057807574 := by decide
theorem cert_e2260964785366 : check e2260964785366 [[],[.under]] .smaller = true := by decide
def e2260964785370 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2260964785370 : Closed e2260964785370 ∧ code e2260964785370 = 11057057807578 := by decide
theorem cert_e2260964785370 : check e2260964785370 [[],[.under]] .smaller = true := by decide
def e2260964785386 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2260964785386 : Closed e2260964785386 ∧ code e2260964785386 = 11057057807594 := by decide
theorem cert_e2260964785386 : check e2260964785386 [[],[.under]] .smaller = true := by decide
def e2260964785462 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2260964785462 : Closed e2260964785462 ∧ code e2260964785462 = 11057057807670 := by decide
theorem cert_e2260964785462 : check e2260964785462 [[],[.under]] .smaller = true := by decide
def e2260964785466 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2260964785466 : Closed e2260964785466 ∧ code e2260964785466 = 11057057807674 := by decide
theorem cert_e2260964785466 : check e2260964785466 [[],[.under]] .smaller = true := by decide
def e2260964785562 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2260964785562 : Closed e2260964785562 ∧ code e2260964785562 = 11057057807770 := by decide
theorem cert_e2260964785562 : check e2260964785562 [[],[.under]] .smaller = true := by decide
def e2260964789102 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2260964789102 : Closed e2260964789102 ∧ code e2260964789102 = 11057057811310 := by decide
theorem cert_e2260964789102 : check e2260964789102 [[],[.under]] .smaller = true := by decide
def e2260964789110 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2260964789110 : Closed e2260964789110 ∧ code e2260964789110 = 11057057811318 := by decide
theorem cert_e2260964789110 : check e2260964789110 [[],[.under]] .smaller = true := by decide
def e2260964789166 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2260964789166 : Closed e2260964789166 ∧ code e2260964789166 = 11057057811374 := by decide
theorem cert_e2260964789166 : check e2260964789166 [[],[.under]] .smaller = true := by decide
def e2260964789178 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2260964789178 : Closed e2260964789178 ∧ code e2260964789178 = 11057057811386 := by decide
theorem cert_e2260964789178 : check e2260964789178 [[],[.under]] .smaller = true := by decide
def e2260964789206 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2260964789206 : Closed e2260964789206 ∧ code e2260964789206 = 11057057811414 := by decide
theorem cert_e2260964789206 : check e2260964789206 [[],[.under]] .smaller = true := by decide
def e2260964789210 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2260964789210 : Closed e2260964789210 ∧ code e2260964789210 = 11057057811418 := by decide
theorem cert_e2260964789210 : check e2260964789210 [[],[.under]] .smaller = true := by decide
def e2260964789486 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2260964789486 : Closed e2260964789486 ∧ code e2260964789486 = 11057057811694 := by decide
theorem cert_e2260964789486 : check e2260964789486 [[],[.under]] .smaller = true := by decide
def e2260964789494 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2260964789494 : Closed e2260964789494 ∧ code e2260964789494 = 11057057811702 := by decide
theorem cert_e2260964789494 : check e2260964789494 [[],[.under]] .smaller = true := by decide
def e2260964789870 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2260964789870 : Closed e2260964789870 ∧ code e2260964789870 = 11057057812078 := by decide
theorem cert_e2260964789870 : check e2260964789870 [[],[.under]] .smaller = true := by decide
def e2260964789882 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2260964789882 : Closed e2260964789882 ∧ code e2260964789882 = 11057057812090 := by decide
theorem cert_e2260964789882 : check e2260964789882 [[],[.under]] .smaller = true := by decide
def e2260964790070 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260964790070 : Closed e2260964790070 ∧ code e2260964790070 = 11057057812278 := by decide
theorem cert_e2260964790070 : check e2260964790070 [[],[.under]] .smaller = true := by decide
def e2260964790074 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260964790074 : Closed e2260964790074 ∧ code e2260964790074 = 11057057812282 := by decide
theorem cert_e2260964790074 : check e2260964790074 [[],[.under]] .smaller = true := by decide
def e2260964795822 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2260964795822 : Closed e2260964795822 ∧ code e2260964795822 = 11057057818030 := by decide
theorem cert_e2260964795822 : check e2260964795822 [[],[.under]] .smaller = true := by decide
def e2260964795834 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2260964795834 : Closed e2260964795834 ∧ code e2260964795834 = 11057057818042 := by decide
theorem cert_e2260964795834 : check e2260964795834 [[],[.under]] .smaller = true := by decide
def e2260964795882 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2260964795882 : Closed e2260964795882 ∧ code e2260964795882 = 11057057818090 := by decide
theorem cert_e2260964795882 : check e2260964795882 [[],[.under]] .smaller = true := by decide
def e2260964796014 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2260964796014 : Closed e2260964796014 ∧ code e2260964796014 = 11057057818222 := by decide
theorem cert_e2260964796014 : check e2260964796014 [[],[.under]] .smaller = true := by decide
def e2260964796026 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2260964796026 : Closed e2260964796026 ∧ code e2260964796026 = 11057057818234 := by decide
theorem cert_e2260964796026 : check e2260964796026 [[],[.under]] .smaller = true := by decide
def e2260964796314 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2260964796314 : Closed e2260964796314 ∧ code e2260964796314 = 11057057818522 := by decide
theorem cert_e2260964796314 : check e2260964796314 [[],[.under]] .smaller = true := by decide
def e2260964799190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2260964799190 : Closed e2260964799190 ∧ code e2260964799190 = 11057057821398 := by decide
theorem cert_e2260964799190 : check e2260964799190 [[],[.under]] .smaller = true := by decide
def e2260964799194 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2260964799194 : Closed e2260964799194 ∧ code e2260964799194 = 11057057821402 := by decide
theorem cert_e2260964799194 : check e2260964799194 [[],[.under]] .smaller = true := by decide
def e2260964799210 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2260964799210 : Closed e2260964799210 ∧ code e2260964799210 = 11057057821418 := by decide
theorem cert_e2260964799210 : check e2260964799210 [[],[.under]] .smaller = true := by decide
def e2260964799286 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260964799286 : Closed e2260964799286 ∧ code e2260964799286 = 11057057821494 := by decide
theorem cert_e2260964799286 : check e2260964799286 [[],[.under]] .smaller = true := by decide
def e2260964799290 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260964799290 : Closed e2260964799290 ∧ code e2260964799290 = 11057057821498 := by decide
theorem cert_e2260964799290 : check e2260964799290 [[],[.under]] .smaller = true := by decide
def e2260964799386 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2260964799386 : Closed e2260964799386 ∧ code e2260964799386 = 11057057821594 := by decide
theorem cert_e2260964799386 : check e2260964799386 [[],[.under]] .smaller = true := by decide
def e2260964914926 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2260964914926 : Closed e2260964914926 ∧ code e2260964914926 = 11057057937134 := by decide
theorem cert_e2260964914926 : check e2260964914926 [[],[.under]] .three = true := by decide
def e2260964915054 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2260964915054 : Closed e2260964915054 ∧ code e2260964915054 = 11057057937262 := by decide
theorem cert_e2260964915054 : check e2260964915054 [[],[.under]] .three = true := by decide
def e2260964915062 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2260964915062 : Closed e2260964915062 ∧ code e2260964915062 = 11057057937270 := by decide
theorem cert_e2260964915062 : check e2260964915062 [[],[.under]] .three = true := by decide
def e2260964915950 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2260964915950 : Closed e2260964915950 ∧ code e2260964915950 = 11057057938158 := by decide
theorem cert_e2260964915950 : check e2260964915950 [[],[.under]] .three = true := by decide
def e2260964916142 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2260964916142 : Closed e2260964916142 ∧ code e2260964916142 = 11057057938350 := by decide
theorem cert_e2260964916142 : check e2260964916142 [[],[.under]] .three = true := by decide
def e2260964916154 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2260964916154 : Closed e2260964916154 ∧ code e2260964916154 = 11057057938362 := by decide
theorem cert_e2260964916154 : check e2260964916154 [[],[.under]] .three = true := by decide
def e2260964916590 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2260964916590 : Closed e2260964916590 ∧ code e2260964916590 = 11057057938798 := by decide
theorem cert_e2260964916590 : check e2260964916590 [[],[.under]] .three = true := by decide
def e2260964916598 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2260964916598 : Closed e2260964916598 ∧ code e2260964916598 = 11057057938806 := by decide
theorem cert_e2260964916598 : check e2260964916598 [[],[.under]] .three = true := by decide
def e2260964916654 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2260964916654 : Closed e2260964916654 ∧ code e2260964916654 = 11057057938862 := by decide
theorem cert_e2260964916654 : check e2260964916654 [[],[.under]] .three = true := by decide
def e2260964916666 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2260964916666 : Closed e2260964916666 ∧ code e2260964916666 = 11057057938874 := by decide
theorem cert_e2260964916666 : check e2260964916666 [[],[.under]] .three = true := by decide
def e2260964916694 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2260964916694 : Closed e2260964916694 ∧ code e2260964916694 = 11057057938902 := by decide
theorem cert_e2260964916694 : check e2260964916694 [[],[.under]] .three = true := by decide
def e2260964916698 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2260964916698 : Closed e2260964916698 ∧ code e2260964916698 = 11057057938906 := by decide
theorem cert_e2260964916698 : check e2260964916698 [[],[.under]] .three = true := by decide
def e2260964921070 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2260964921070 : Closed e2260964921070 ∧ code e2260964921070 = 11057057943278 := by decide
theorem cert_e2260964921070 : check e2260964921070 [[],[.under]] .three = true := by decide
def e2260964921198 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2260964921198 : Closed e2260964921198 ∧ code e2260964921198 = 11057057943406 := by decide
theorem cert_e2260964921198 : check e2260964921198 [[],[.under]] .three = true := by decide
def e2260964921206 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2260964921206 : Closed e2260964921206 ∧ code e2260964921206 = 11057057943414 := by decide
theorem cert_e2260964921206 : check e2260964921206 [[],[.under]] .three = true := by decide
def e2260964923886 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2260964923886 : Closed e2260964923886 ∧ code e2260964923886 = 11057057946094 := by decide
theorem cert_e2260964923886 : check e2260964923886 [[],[.under]] .three = true := by decide
def e2260964924654 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2260964924654 : Closed e2260964924654 ∧ code e2260964924654 = 11057057946862 := by decide
theorem cert_e2260964924654 : check e2260964924654 [[],[.under]] .three = true := by decide
def e2260964924662 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2260964924662 : Closed e2260964924662 ∧ code e2260964924662 = 11057057946870 := by decide
theorem cert_e2260964924662 : check e2260964924662 [[],[.under]] .three = true := by decide
def e2260964927214 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2260964927214 : Closed e2260964927214 ∧ code e2260964927214 = 11057057949422 := by decide
theorem cert_e2260964927214 : check e2260964927214 [[],[.under]] .three = true := by decide
def e2260964927406 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2260964927406 : Closed e2260964927406 ∧ code e2260964927406 = 11057057949614 := by decide
theorem cert_e2260964927406 : check e2260964927406 [[],[.under]] .three = true := by decide
def e2260964927418 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2260964927418 : Closed e2260964927418 ∧ code e2260964927418 = 11057057949626 := by decide
theorem cert_e2260964927418 : check e2260964927418 [[],[.under]] .three = true := by decide
def e2260964927982 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2260964927982 : Closed e2260964927982 ∧ code e2260964927982 = 11057057950190 := by decide
theorem cert_e2260964927982 : check e2260964927982 [[],[.under]] .three = true := by decide
def e2260964929134 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2260964929134 : Closed e2260964929134 ∧ code e2260964929134 = 11057057951342 := by decide
theorem cert_e2260964929134 : check e2260964929134 [[],[.under]] .three = true := by decide
def e2260964929146 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2260964929146 : Closed e2260964929146 ∧ code e2260964929146 = 11057057951354 := by decide
theorem cert_e2260964929146 : check e2260964929146 [[],[.under]] .three = true := by decide
def e2260964930414 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2260964930414 : Closed e2260964930414 ∧ code e2260964930414 = 11057057952622 := by decide
theorem cert_e2260964930414 : check e2260964930414 [[],[.under]] .three = true := by decide
def e2260964930422 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2260964930422 : Closed e2260964930422 ∧ code e2260964930422 = 11057057952630 := by decide
theorem cert_e2260964930422 : check e2260964930422 [[],[.under]] .three = true := by decide
def e2260964930478 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2260964930478 : Closed e2260964930478 ∧ code e2260964930478 = 11057057952686 := by decide
theorem cert_e2260964930478 : check e2260964930478 [[],[.under]] .three = true := by decide
def e2260964930490 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2260964930490 : Closed e2260964930490 ∧ code e2260964930490 = 11057057952698 := by decide
theorem cert_e2260964930490 : check e2260964930490 [[],[.under]] .three = true := by decide
def e2260964930518 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2260964930518 : Closed e2260964930518 ∧ code e2260964930518 = 11057057952726 := by decide
theorem cert_e2260964930518 : check e2260964930518 [[],[.under]] .three = true := by decide
def e2260964930522 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2260964930522 : Closed e2260964930522 ∧ code e2260964930522 = 11057057952730 := by decide
theorem cert_e2260964930522 : check e2260964930522 [[],[.under]] .three = true := by decide
def e2260964930798 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2260964930798 : Closed e2260964930798 ∧ code e2260964930798 = 11057057953006 := by decide
theorem cert_e2260964930798 : check e2260964930798 [[],[.under]] .three = true := by decide
def e2260964930806 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2260964930806 : Closed e2260964930806 ∧ code e2260964930806 = 11057057953014 := by decide
theorem cert_e2260964930806 : check e2260964930806 [[],[.under]] .three = true := by decide
def e2260964931182 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2260964931182 : Closed e2260964931182 ∧ code e2260964931182 = 11057057953390 := by decide
theorem cert_e2260964931182 : check e2260964931182 [[],[.under]] .three = true := by decide
def e2260964931194 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2260964931194 : Closed e2260964931194 ∧ code e2260964931194 = 11057057953402 := by decide
theorem cert_e2260964931194 : check e2260964931194 [[],[.under]] .three = true := by decide
def e2260964931382 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2260964931382 : Closed e2260964931382 ∧ code e2260964931382 = 11057057953590 := by decide
theorem cert_e2260964931382 : check e2260964931382 [[],[.under]] .three = true := by decide
def e2260964931386 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2260964931386 : Closed e2260964931386 ∧ code e2260964931386 = 11057057953594 := by decide
theorem cert_e2260964931386 : check e2260964931386 [[],[.under]] .three = true := by decide
def e2260964936558 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2260964936558 : Closed e2260964936558 ∧ code e2260964936558 = 11057057958766 := by decide
theorem cert_e2260964936558 : check e2260964936558 [[],[.under]] .smaller = true := by decide
def e2260964936566 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2260964936566 : Closed e2260964936566 ∧ code e2260964936566 = 11057057958774 := by decide
theorem cert_e2260964936566 : check e2260964936566 [[],[.under]] .smaller = true := by decide
def e2260964936622 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2260964936622 : Closed e2260964936622 ∧ code e2260964936622 = 11057057958830 := by decide
theorem cert_e2260964936622 : check e2260964936622 [[],[.under]] .smaller = true := by decide
def e2260964936634 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2260964936634 : Closed e2260964936634 ∧ code e2260964936634 = 11057057958842 := by decide
theorem cert_e2260964936634 : check e2260964936634 [[],[.under]] .smaller = true := by decide
def e2260964936662 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2260964936662 : Closed e2260964936662 ∧ code e2260964936662 = 11057057958870 := by decide
theorem cert_e2260964936662 : check e2260964936662 [[],[.under]] .smaller = true := by decide
def e2260964936666 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2260964936666 : Closed e2260964936666 ∧ code e2260964936666 = 11057057958874 := by decide
theorem cert_e2260964936666 : check e2260964936666 [[],[.under]] .smaller = true := by decide
def e2260964936942 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2260964936942 : Closed e2260964936942 ∧ code e2260964936942 = 11057057959150 := by decide
theorem cert_e2260964936942 : check e2260964936942 [[],[.under]] .smaller = true := by decide
def e2260964936950 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2260964936950 : Closed e2260964936950 ∧ code e2260964936950 = 11057057959158 := by decide
theorem cert_e2260964936950 : check e2260964936950 [[],[.under]] .smaller = true := by decide
def e2260964937326 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2260964937326 : Closed e2260964937326 ∧ code e2260964937326 = 11057057959534 := by decide
theorem cert_e2260964937326 : check e2260964937326 [[],[.under]] .smaller = true := by decide
def e2260964937338 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2260964937338 : Closed e2260964937338 ∧ code e2260964937338 = 11057057959546 := by decide
theorem cert_e2260964937338 : check e2260964937338 [[],[.under]] .smaller = true := by decide
def e2260964937526 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260964937526 : Closed e2260964937526 ∧ code e2260964937526 = 11057057959734 := by decide
theorem cert_e2260964937526 : check e2260964937526 [[],[.under]] .smaller = true := by decide
def e2260964937530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260964937530 : Closed e2260964937530 ∧ code e2260964937530 = 11057057959738 := by decide
theorem cert_e2260964937530 : check e2260964937530 [[],[.under]] .smaller = true := by decide
def e2260964945646 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2260964945646 : Closed e2260964945646 ∧ code e2260964945646 = 11057057967854 := by decide
theorem cert_e2260964945646 : check e2260964945646 [[],[.under]] .three = true := by decide
def e2260964945774 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2260964945774 : Closed e2260964945774 ∧ code e2260964945774 = 11057057967982 := by decide
theorem cert_e2260964945774 : check e2260964945774 [[],[.under]] .three = true := by decide
def e2260964945782 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2260964945782 : Closed e2260964945782 ∧ code e2260964945782 = 11057057967990 := by decide
theorem cert_e2260964945782 : check e2260964945782 [[],[.under]] .three = true := by decide
def e2260964948462 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2260964948462 : Closed e2260964948462 ∧ code e2260964948462 = 11057057970670 := by decide
theorem cert_e2260964948462 : check e2260964948462 [[],[.under]] .three = true := by decide
def e2260964949230 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2260964949230 : Closed e2260964949230 ∧ code e2260964949230 = 11057057971438 := by decide
theorem cert_e2260964949230 : check e2260964949230 [[],[.under]] .three = true := by decide
def e2260964949238 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2260964949238 : Closed e2260964949238 ∧ code e2260964949238 = 11057057971446 := by decide
theorem cert_e2260964949238 : check e2260964949238 [[],[.under]] .three = true := by decide
def e2260964972270 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2260964972270 : Closed e2260964972270 ∧ code e2260964972270 = 11057057994478 := by decide
theorem cert_e2260964972270 : check e2260964972270 [[],[.under]] .three = true := by decide
def e2260964972462 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2260964972462 : Closed e2260964972462 ∧ code e2260964972462 = 11057057994670 := by decide
theorem cert_e2260964972462 : check e2260964972462 [[],[.under]] .three = true := by decide
def e2260964972474 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2260964972474 : Closed e2260964972474 ∧ code e2260964972474 = 11057057994682 := by decide
theorem cert_e2260964972474 : check e2260964972474 [[],[.under]] .three = true := by decide
def e2260964973038 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2260964973038 : Closed e2260964973038 ∧ code e2260964973038 = 11057057995246 := by decide
theorem cert_e2260964973038 : check e2260964973038 [[],[.under]] .three = true := by decide
def e2260964974190 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2260964974190 : Closed e2260964974190 ∧ code e2260964974190 = 11057057996398 := by decide
theorem cert_e2260964974190 : check e2260964974190 [[],[.under]] .three = true := by decide
def e2260964974202 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2260964974202 : Closed e2260964974202 ∧ code e2260964974202 = 11057057996410 := by decide
theorem cert_e2260964974202 : check e2260964974202 [[],[.under]] .three = true := by decide
def e2260964985710 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2260964985710 : Closed e2260964985710 ∧ code e2260964985710 = 11057058007918 := by decide
theorem cert_e2260964985710 : check e2260964985710 [[],[.under]] .three = true := by decide
def e2260964985718 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2260964985718 : Closed e2260964985718 ∧ code e2260964985718 = 11057058007926 := by decide
theorem cert_e2260964985718 : check e2260964985718 [[],[.under]] .three = true := by decide
def e2260964985774 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2260964985774 : Closed e2260964985774 ∧ code e2260964985774 = 11057058007982 := by decide
theorem cert_e2260964985774 : check e2260964985774 [[],[.under]] .three = true := by decide
def e2260964985786 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2260964985786 : Closed e2260964985786 ∧ code e2260964985786 = 11057058007994 := by decide
theorem cert_e2260964985786 : check e2260964985786 [[],[.under]] .three = true := by decide
def e2260964985814 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2260964985814 : Closed e2260964985814 ∧ code e2260964985814 = 11057058008022 := by decide
theorem cert_e2260964985814 : check e2260964985814 [[],[.under]] .three = true := by decide
def e2260964985818 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2260964985818 : Closed e2260964985818 ∧ code e2260964985818 = 11057058008026 := by decide
theorem cert_e2260964985818 : check e2260964985818 [[],[.under]] .three = true := by decide
def e2260964986094 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2260964986094 : Closed e2260964986094 ∧ code e2260964986094 = 11057058008302 := by decide
theorem cert_e2260964986094 : check e2260964986094 [[],[.under]] .three = true := by decide
def e2260964986102 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2260964986102 : Closed e2260964986102 ∧ code e2260964986102 = 11057058008310 := by decide
theorem cert_e2260964986102 : check e2260964986102 [[],[.under]] .three = true := by decide
end Blc.Floor43
