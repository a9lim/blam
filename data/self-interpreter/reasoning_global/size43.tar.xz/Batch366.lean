import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422362279662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))))
theorem wire_e2422362279662 : Closed e2422362279662 ∧ code e2422362279662 = 11218455301870 := by decide
theorem cert_e2422362279662 : check e2422362279662 [[],[]] .smaller = true := by decide
def e2422362279670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))))
theorem wire_e2422362279670 : Closed e2422362279670 ∧ code e2422362279670 = 11218455301878 := by decide
theorem cert_e2422362279670 : check e2422362279670 [[],[]] .smaller = true := by decide
def e2422362279790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))))
theorem wire_e2422362279790 : Closed e2422362279790 ∧ code e2422362279790 = 11218455301998 := by decide
theorem cert_e2422362279790 : check e2422362279790 [[],[]] .smaller = true := by decide
def e2422362279802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))))
theorem wire_e2422362279802 : Closed e2422362279802 ∧ code e2422362279802 = 11218455302010 := by decide
theorem cert_e2422362279802 : check e2422362279802 [[],[]] .smaller = true := by decide
def e2422362279862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))))
theorem wire_e2422362279862 : Closed e2422362279862 ∧ code e2422362279862 = 11218455302070 := by decide
theorem cert_e2422362279862 : check e2422362279862 [[],[]] .smaller = true := by decide
def e2422362279866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))))
theorem wire_e2422362279866 : Closed e2422362279866 ∧ code e2422362279866 = 11218455302074 := by decide
theorem cert_e2422362279866 : check e2422362279866 [[],[]] .smaller = true := by decide
def e2422362282462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422362282462 : Closed e2422362282462 ∧ code e2422362282462 = 11218455304670 := by decide
theorem cert_e2422362282462 : check e2422362282462 [[],[]] .smaller = true := by decide
def e2422362282486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422362282486 : Closed e2422362282486 ∧ code e2422362282486 = 11218455304694 := by decide
theorem cert_e2422362282486 : check e2422362282486 [[],[]] .smaller = true := by decide
def e2422362283230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422362283230 : Closed e2422362283230 ∧ code e2422362283230 = 11218455305438 := by decide
theorem cert_e2422362283230 : check e2422362283230 [[],[]] .smaller = true := by decide
def e2422362283246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422362283246 : Closed e2422362283246 ∧ code e2422362283246 = 11218455305454 := by decide
theorem cert_e2422362283246 : check e2422362283246 [[],[]] .smaller = true := by decide
def e2422362283254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422362283254 : Closed e2422362283254 ∧ code e2422362283254 = 11218455305462 := by decide
theorem cert_e2422362283254 : check e2422362283254 [[],[]] .smaller = true := by decide
def e2422362283258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422362283258 : Closed e2422362283258 ∧ code e2422362283258 = 11218455305466 := by decide
theorem cert_e2422362283258 : check e2422362283258 [[],[]] .smaller = true := by decide
def e2422362283638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422362283638 : Closed e2422362283638 ∧ code e2422362283638 = 11218455305846 := by decide
theorem cert_e2422362283638 : check e2422362283638 [[],[]] .smaller = true := by decide
def e2422362283830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362283830 : Closed e2422362283830 ∧ code e2422362283830 = 11218455306038 := by decide
theorem cert_e2422362283830 : check e2422362283830 [[],[]] .smaller = true := by decide
def e2422362283834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362283834 : Closed e2422362283834 ∧ code e2422362283834 = 11218455306042 := by decide
theorem cert_e2422362283834 : check e2422362283834 [[],[]] .smaller = true := by decide
def e2422362287470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))))
theorem wire_e2422362287470 : Closed e2422362287470 ∧ code e2422362287470 = 11218455309678 := by decide
theorem cert_e2422362287470 : check e2422362287470 [[],[]] .smaller = true := by decide
def e2422362287478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))))
theorem wire_e2422362287478 : Closed e2422362287478 ∧ code e2422362287478 = 11218455309686 := by decide
theorem cert_e2422362287478 : check e2422362287478 [[],[]] .smaller = true := by decide
def e2422362287534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))))
theorem wire_e2422362287534 : Closed e2422362287534 ∧ code e2422362287534 = 11218455309742 := by decide
theorem cert_e2422362287534 : check e2422362287534 [[],[]] .smaller = true := by decide
def e2422362287546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))))
theorem wire_e2422362287546 : Closed e2422362287546 ∧ code e2422362287546 = 11218455309754 := by decide
theorem cert_e2422362287546 : check e2422362287546 [[],[]] .smaller = true := by decide
def e2422362287574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))))
theorem wire_e2422362287574 : Closed e2422362287574 ∧ code e2422362287574 = 11218455309782 := by decide
theorem cert_e2422362287574 : check e2422362287574 [[],[]] .smaller = true := by decide
def e2422362287578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))))
theorem wire_e2422362287578 : Closed e2422362287578 ∧ code e2422362287578 = 11218455309786 := by decide
theorem cert_e2422362287578 : check e2422362287578 [[],[]] .smaller = true := by decide
def e2422362287790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))))
theorem wire_e2422362287790 : Closed e2422362287790 ∧ code e2422362287790 = 11218455309998 := by decide
theorem cert_e2422362287790 : check e2422362287790 [[],[]] .smaller = true := by decide
def e2422362287802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))))
theorem wire_e2422362287802 : Closed e2422362287802 ∧ code e2422362287802 = 11218455310010 := by decide
theorem cert_e2422362287802 : check e2422362287802 [[],[]] .smaller = true := by decide
def e2422362287850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))))
theorem wire_e2422362287850 : Closed e2422362287850 ∧ code e2422362287850 = 11218455310058 := by decide
theorem cert_e2422362287850 : check e2422362287850 [[],[]] .smaller = true := by decide
def e2422362287958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))))
theorem wire_e2422362287958 : Closed e2422362287958 ∧ code e2422362287958 = 11218455310166 := by decide
theorem cert_e2422362287958 : check e2422362287958 [[],[]] .smaller = true := by decide
def e2422362287962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))))
theorem wire_e2422362287962 : Closed e2422362287962 ∧ code e2422362287962 = 11218455310170 := by decide
theorem cert_e2422362287962 : check e2422362287962 [[],[]] .smaller = true := by decide
def e2422362287978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))))
theorem wire_e2422362287978 : Closed e2422362287978 ∧ code e2422362287978 = 11218455310186 := by decide
theorem cert_e2422362287978 : check e2422362287978 [[],[]] .smaller = true := by decide
def e2422362288606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 3)))))))))
theorem wire_e2422362288606 : Closed e2422362288606 ∧ code e2422362288606 = 11218455310814 := by decide
theorem cert_e2422362288606 : check e2422362288606 [[],[]] .smaller = true := by decide
def e2422362288630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 1)))))))))
theorem wire_e2422362288630 : Closed e2422362288630 ∧ code e2422362288630 = 11218455310838 := by decide
theorem cert_e2422362288630 : check e2422362288630 [[],[]] .smaller = true := by decide
def e2422362289006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))))
theorem wire_e2422362289006 : Closed e2422362289006 ∧ code e2422362289006 = 11218455311214 := by decide
theorem cert_e2422362289006 : check e2422362289006 [[],[]] .smaller = true := by decide
def e2422362289014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))))
theorem wire_e2422362289014 : Closed e2422362289014 ∧ code e2422362289014 = 11218455311222 := by decide
theorem cert_e2422362289014 : check e2422362289014 [[],[]] .smaller = true := by decide
def e2422362289070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))))
theorem wire_e2422362289070 : Closed e2422362289070 ∧ code e2422362289070 = 11218455311278 := by decide
theorem cert_e2422362289070 : check e2422362289070 [[],[]] .smaller = true := by decide
def e2422362289082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))))
theorem wire_e2422362289082 : Closed e2422362289082 ∧ code e2422362289082 = 11218455311290 := by decide
theorem cert_e2422362289082 : check e2422362289082 [[],[]] .smaller = true := by decide
def e2422362289110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))))
theorem wire_e2422362289110 : Closed e2422362289110 ∧ code e2422362289110 = 11218455311318 := by decide
theorem cert_e2422362289110 : check e2422362289110 [[],[]] .smaller = true := by decide
def e2422362289114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))))
theorem wire_e2422362289114 : Closed e2422362289114 ∧ code e2422362289114 = 11218455311322 := by decide
theorem cert_e2422362289114 : check e2422362289114 [[],[]] .smaller = true := by decide
def e2422362289390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422362289390 : Closed e2422362289390 ∧ code e2422362289390 = 11218455311598 := by decide
theorem cert_e2422362289390 : check e2422362289390 [[],[]] .smaller = true := by decide
def e2422362289398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422362289398 : Closed e2422362289398 ∧ code e2422362289398 = 11218455311606 := by decide
theorem cert_e2422362289398 : check e2422362289398 [[],[]] .smaller = true := by decide
def e2422362289726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 4))))))))))
theorem wire_e2422362289726 : Closed e2422362289726 ∧ code e2422362289726 = 11218455311934 := by decide
theorem cert_e2422362289726 : check e2422362289726 [[],[]] .smaller = true := by decide
def e2422362289774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362289774 : Closed e2422362289774 ∧ code e2422362289774 = 11218455311982 := by decide
theorem cert_e2422362289774 : check e2422362289774 [[],[]] .smaller = true := by decide
def e2422362289786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362289786 : Closed e2422362289786 ∧ code e2422362289786 = 11218455311994 := by decide
theorem cert_e2422362289786 : check e2422362289786 [[],[]] .smaller = true := by decide
def e2422362289974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362289974 : Closed e2422362289974 ∧ code e2422362289974 = 11218455312182 := by decide
theorem cert_e2422362289974 : check e2422362289974 [[],[]] .smaller = true := by decide
def e2422362289978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362289978 : Closed e2422362289978 ∧ code e2422362289978 = 11218455312186 := by decide
theorem cert_e2422362289978 : check e2422362289978 [[],[]] .smaller = true := by decide
def e2422362290046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 5)))))))))
theorem wire_e2422362290046 : Closed e2422362290046 ∧ code e2422362290046 = 11218455312254 := by decide
theorem cert_e2422362290046 : check e2422362290046 [[],[]] .three = true := by decide
def e2422362290062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 2))))))))))
theorem wire_e2422362290062 : Closed e2422362290062 ∧ code e2422362290062 = 11218455312270 := by decide
theorem cert_e2422362290062 : check e2422362290062 [[],[]] .smaller = true := by decide
def e2422362290110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 4)))))))))
theorem wire_e2422362290110 : Closed e2422362290110 ∧ code e2422362290110 = 11218455312318 := by decide
theorem cert_e2422362290110 : check e2422362290110 [[],[]] .smaller = true := by decide
def e2422362290142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 3)))))))))
theorem wire_e2422362290142 : Closed e2422362290142 ∧ code e2422362290142 = 11218455312350 := by decide
theorem cert_e2422362290142 : check e2422362290142 [[],[]] .smaller = true := by decide
def e2422362290158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 5))) (.var 2)))))))))
theorem wire_e2422362290158 : Closed e2422362290158 ∧ code e2422362290158 = 11218455312366 := by decide
theorem cert_e2422362290158 : check e2422362290158 [[],[]] .three = true := by decide
def e2422362290398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 3)))))))))
theorem wire_e2422362290398 : Closed e2422362290398 ∧ code e2422362290398 = 11218455312606 := by decide
theorem cert_e2422362290398 : check e2422362290398 [[],[]] .smaller = true := by decide
def e2422362290414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))))
theorem wire_e2422362290414 : Closed e2422362290414 ∧ code e2422362290414 = 11218455312622 := by decide
theorem cert_e2422362290414 : check e2422362290414 [[],[]] .smaller = true := by decide
def e2422362290422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))))
theorem wire_e2422362290422 : Closed e2422362290422 ∧ code e2422362290422 = 11218455312630 := by decide
theorem cert_e2422362290422 : check e2422362290422 [[],[]] .smaller = true := by decide
def e2422362290426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 0)))))))))
theorem wire_e2422362290426 : Closed e2422362290426 ∧ code e2422362290426 = 11218455312634 := by decide
theorem cert_e2422362290426 : check e2422362290426 [[],[]] .smaller = true := by decide
def e2422362290606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))))
theorem wire_e2422362290606 : Closed e2422362290606 ∧ code e2422362290606 = 11218455312814 := by decide
theorem cert_e2422362290606 : check e2422362290606 [[],[]] .smaller = true := by decide
def e2422362290618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))))
theorem wire_e2422362290618 : Closed e2422362290618 ∧ code e2422362290618 = 11218455312826 := by decide
theorem cert_e2422362290618 : check e2422362290618 [[],[]] .smaller = true := by decide
def e2422362290666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))))
theorem wire_e2422362290666 : Closed e2422362290666 ∧ code e2422362290666 = 11218455312874 := by decide
theorem cert_e2422362290666 : check e2422362290666 [[],[]] .smaller = true := by decide
def e2422362290750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 4))))))))))
theorem wire_e2422362290750 : Closed e2422362290750 ∧ code e2422362290750 = 11218455312958 := by decide
theorem cert_e2422362290750 : check e2422362290750 [[],[]] .smaller = true := by decide
def e2422362290798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362290798 : Closed e2422362290798 ∧ code e2422362290798 = 11218455313006 := by decide
theorem cert_e2422362290798 : check e2422362290798 [[],[]] .smaller = true := by decide
def e2422362290810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362290810 : Closed e2422362290810 ∧ code e2422362290810 = 11218455313018 := by decide
theorem cert_e2422362290810 : check e2422362290810 [[],[]] .smaller = true := by decide
def e2422362290974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))))
theorem wire_e2422362290974 : Closed e2422362290974 ∧ code e2422362290974 = 11218455313182 := by decide
theorem cert_e2422362290974 : check e2422362290974 [[],[]] .smaller = true := by decide
def e2422362291070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 5)))))))))
theorem wire_e2422362291070 : Closed e2422362291070 ∧ code e2422362291070 = 11218455313278 := by decide
theorem cert_e2422362291070 : check e2422362291070 [[],[]] .three = true := by decide
def e2422362291086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))))
theorem wire_e2422362291086 : Closed e2422362291086 ∧ code e2422362291086 = 11218455313294 := by decide
theorem cert_e2422362291086 : check e2422362291086 [[],[]] .smaller = true := by decide
def e2422362291098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362291098 : Closed e2422362291098 ∧ code e2422362291098 = 11218455313306 := by decide
theorem cert_e2422362291098 : check e2422362291098 [[],[]] .smaller = true := by decide
def e2422362291142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 1))))))))))
theorem wire_e2422362291142 : Closed e2422362291142 ∧ code e2422362291142 = 11218455313350 := by decide
theorem cert_e2422362291142 : check e2422362291142 [[],[]] .smaller = true := by decide
def e2422362291166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 3)))))))))
theorem wire_e2422362291166 : Closed e2422362291166 ∧ code e2422362291166 = 11218455313374 := by decide
theorem cert_e2422362291166 : check e2422362291166 [[],[]] .smaller = true := by decide
def e2422362291190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 5))) (.var 1)))))))))
theorem wire_e2422362291190 : Closed e2422362291190 ∧ code e2422362291190 = 11218455313398 := by decide
theorem cert_e2422362291190 : check e2422362291190 [[],[]] .three = true := by decide
def e2422362291318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))))
theorem wire_e2422362291318 : Closed e2422362291318 ∧ code e2422362291318 = 11218455313526 := by decide
theorem cert_e2422362291318 : check e2422362291318 [[],[]] .smaller = true := by decide
def e2422362291414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))))
theorem wire_e2422362291414 : Closed e2422362291414 ∧ code e2422362291414 = 11218455313622 := by decide
theorem cert_e2422362291414 : check e2422362291414 [[],[]] .smaller = true := by decide
def e2422362291418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))))
theorem wire_e2422362291418 : Closed e2422362291418 ∧ code e2422362291418 = 11218455313626 := by decide
theorem cert_e2422362291418 : check e2422362291418 [[],[]] .smaller = true := by decide
def e2422362291434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))))
theorem wire_e2422362291434 : Closed e2422362291434 ∧ code e2422362291434 = 11218455313642 := by decide
theorem cert_e2422362291434 : check e2422362291434 [[],[]] .smaller = true := by decide
def e2422362291510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362291510 : Closed e2422362291510 ∧ code e2422362291510 = 11218455313718 := by decide
theorem cert_e2422362291510 : check e2422362291510 [[],[]] .smaller = true := by decide
def e2422362291514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362291514 : Closed e2422362291514 ∧ code e2422362291514 = 11218455313722 := by decide
theorem cert_e2422362291514 : check e2422362291514 [[],[]] .smaller = true := by decide
def e2422362291582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 5)))))))))
theorem wire_e2422362291582 : Closed e2422362291582 ∧ code e2422362291582 = 11218455313790 := by decide
theorem cert_e2422362291582 : check e2422362291582 [[],[]] .three = true := by decide
def e2422362291598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))))
theorem wire_e2422362291598 : Closed e2422362291598 ∧ code e2422362291598 = 11218455313806 := by decide
theorem cert_e2422362291598 : check e2422362291598 [[],[]] .smaller = true := by decide
def e2422362291610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362291610 : Closed e2422362291610 ∧ code e2422362291610 = 11218455313818 := by decide
theorem cert_e2422362291610 : check e2422362291610 [[],[]] .smaller = true := by decide
def e2422362291678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 3)))))))))
theorem wire_e2422362291678 : Closed e2422362291678 ∧ code e2422362291678 = 11218455313886 := by decide
theorem cert_e2422362291678 : check e2422362291678 [[],[]] .smaller = true := by decide
def e2422362291694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 2)))))))))
theorem wire_e2422362291694 : Closed e2422362291694 ∧ code e2422362291694 = 11218455313902 := by decide
theorem cert_e2422362291694 : check e2422362291694 [[],[]] .smaller = true := by decide
def e2422362291706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 5))) (.var 0)))))))))
theorem wire_e2422362291706 : Closed e2422362291706 ∧ code e2422362291706 = 11218455313914 := by decide
theorem cert_e2422362291706 : check e2422362291706 [[],[]] .three = true := by decide
def e2422362291766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 1)))))))))
theorem wire_e2422362291766 : Closed e2422362291766 ∧ code e2422362291766 = 11218455313974 := by decide
theorem cert_e2422362291766 : check e2422362291766 [[],[]] .smaller = true := by decide
def e2422362291770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 0)))))))))
theorem wire_e2422362291770 : Closed e2422362291770 ∧ code e2422362291770 = 11218455313978 := by decide
theorem cert_e2422362291770 : check e2422362291770 [[],[]] .smaller = true := by decide
def e2422362291854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 2))))))))))
theorem wire_e2422362291854 : Closed e2422362291854 ∧ code e2422362291854 = 11218455314062 := by decide
theorem cert_e2422362291854 : check e2422362291854 [[],[]] .smaller = true := by decide
def e2422362291902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 4)))))))))
theorem wire_e2422362291902 : Closed e2422362291902 ∧ code e2422362291902 = 11218455314110 := by decide
theorem cert_e2422362291902 : check e2422362291902 [[],[]] .smaller = true := by decide
def e2422362291910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 1))))))))))
theorem wire_e2422362291910 : Closed e2422362291910 ∧ code e2422362291910 = 11218455314118 := by decide
theorem cert_e2422362291910 : check e2422362291910 [[],[]] .smaller = true := by decide
def e2422362291934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 3)))))))))
theorem wire_e2422362291934 : Closed e2422362291934 ∧ code e2422362291934 = 11218455314142 := by decide
theorem cert_e2422362291934 : check e2422362291934 [[],[]] .smaller = true := by decide
def e2422362291950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 2)))))))))
theorem wire_e2422362291950 : Closed e2422362291950 ∧ code e2422362291950 = 11218455314158 := by decide
theorem cert_e2422362291950 : check e2422362291950 [[],[]] .smaller = true := by decide
def e2422362291958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 1)))))))))
theorem wire_e2422362291958 : Closed e2422362291958 ∧ code e2422362291958 = 11218455314166 := by decide
theorem cert_e2422362291958 : check e2422362291958 [[],[]] .smaller = true := by decide
def e2422362291962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 4))) (.var 0)))))))))
theorem wire_e2422362291962 : Closed e2422362291962 ∧ code e2422362291962 = 11218455314170 := by decide
theorem cert_e2422362291962 : check e2422362291962 [[],[]] .smaller = true := by decide
def e2422362292062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 3)))))))))
theorem wire_e2422362292062 : Closed e2422362292062 ∧ code e2422362292062 = 11218455314270 := by decide
theorem cert_e2422362292062 : check e2422362292062 [[],[]] .smaller = true := by decide
def e2422362292090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 3))) (.var 0)))))))))
theorem wire_e2422362292090 : Closed e2422362292090 ∧ code e2422362292090 = 11218455314298 := by decide
theorem cert_e2422362292090 : check e2422362292090 [[],[]] .smaller = true := by decide
def e2422362292142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 5) (.var 0))) (.var 2)))))))))
theorem wire_e2422362292142 : Closed e2422362292142 ∧ code e2422362292142 = 11218455314350 := by decide
theorem cert_e2422362292142 : check e2422362292142 [[],[]] .three = true := by decide
def e2422362292150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 5) (.var 1))) (.var 1)))))))))
theorem wire_e2422362292150 : Closed e2422362292150 ∧ code e2422362292150 = 11218455314358 := by decide
theorem cert_e2422362292150 : check e2422362292150 [[],[]] .three = true := by decide
def e2422362292154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 5) (.var 2))) (.var 0)))))))))
theorem wire_e2422362292154 : Closed e2422362292154 ∧ code e2422362292154 = 11218455314362 := by decide
theorem cert_e2422362292154 : check e2422362292154 [[],[]] .three = true := by decide
def e2422362293214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422362293214 : Closed e2422362293214 ∧ code e2422362293214 = 11218455315422 := by decide
theorem cert_e2422362293214 : check e2422362293214 [[],[]] .smaller = true := by decide
def e2422362293230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422362293230 : Closed e2422362293230 ∧ code e2422362293230 = 11218455315438 := by decide
theorem cert_e2422362293230 : check e2422362293230 [[],[]] .smaller = true := by decide
def e2422362295150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422362295150 : Closed e2422362295150 ∧ code e2422362295150 = 11218455317358 := by decide
theorem cert_e2422362295150 : check e2422362295150 [[],[]] .smaller = true := by decide
def e2422362295158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422362295158 : Closed e2422362295158 ∧ code e2422362295158 = 11218455317366 := by decide
theorem cert_e2422362295158 : check e2422362295158 [[],[]] .smaller = true := by decide
def e2422362295214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422362295214 : Closed e2422362295214 ∧ code e2422362295214 = 11218455317422 := by decide
theorem cert_e2422362295214 : check e2422362295214 [[],[]] .smaller = true := by decide
def e2422362295226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422362295226 : Closed e2422362295226 ∧ code e2422362295226 = 11218455317434 := by decide
theorem cert_e2422362295226 : check e2422362295226 [[],[]] .smaller = true := by decide
def e2422362295254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422362295254 : Closed e2422362295254 ∧ code e2422362295254 = 11218455317462 := by decide
theorem cert_e2422362295254 : check e2422362295254 [[],[]] .smaller = true := by decide
def e2422362295258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422362295258 : Closed e2422362295258 ∧ code e2422362295258 = 11218455317466 := by decide
theorem cert_e2422362295258 : check e2422362295258 [[],[]] .smaller = true := by decide
def e2422362295534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422362295534 : Closed e2422362295534 ∧ code e2422362295534 = 11218455317742 := by decide
theorem cert_e2422362295534 : check e2422362295534 [[],[]] .smaller = true := by decide
def e2422362295542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422362295542 : Closed e2422362295542 ∧ code e2422362295542 = 11218455317750 := by decide
theorem cert_e2422362295542 : check e2422362295542 [[],[]] .smaller = true := by decide
def e2422362295870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e2422362295870 : Closed e2422362295870 ∧ code e2422362295870 = 11218455318078 := by decide
theorem cert_e2422362295870 : check e2422362295870 [[],[]] .smaller = true := by decide
def e2422362295918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362295918 : Closed e2422362295918 ∧ code e2422362295918 = 11218455318126 := by decide
theorem cert_e2422362295918 : check e2422362295918 [[],[]] .smaller = true := by decide
def e2422362295930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362295930 : Closed e2422362295930 ∧ code e2422362295930 = 11218455318138 := by decide
theorem cert_e2422362295930 : check e2422362295930 [[],[]] .smaller = true := by decide
def e2422362296118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422362296118 : Closed e2422362296118 ∧ code e2422362296118 = 11218455318326 := by decide
theorem cert_e2422362296118 : check e2422362296118 [[],[]] .smaller = true := by decide
def e2422362296122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422362296122 : Closed e2422362296122 ∧ code e2422362296122 = 11218455318330 := by decide
theorem cert_e2422362296122 : check e2422362296122 [[],[]] .smaller = true := by decide
def e2422362296190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 5))))))))))
theorem wire_e2422362296190 : Closed e2422362296190 ∧ code e2422362296190 = 11218455318398 := by decide
theorem cert_e2422362296190 : check e2422362296190 [[],[]] .three = true := by decide
def e2422362296206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e2422362296206 : Closed e2422362296206 ∧ code e2422362296206 = 11218455318414 := by decide
theorem cert_e2422362296206 : check e2422362296206 [[],[]] .smaller = true := by decide
def e2422362296254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 4))))))))))
theorem wire_e2422362296254 : Closed e2422362296254 ∧ code e2422362296254 = 11218455318462 := by decide
theorem cert_e2422362296254 : check e2422362296254 [[],[]] .smaller = true := by decide
def e2422362296286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 3))))))))))
theorem wire_e2422362296286 : Closed e2422362296286 ∧ code e2422362296286 = 11218455318494 := by decide
theorem cert_e2422362296286 : check e2422362296286 [[],[]] .smaller = true := by decide
def e2422362296302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 5) (.var 2))))))))))
theorem wire_e2422362296302 : Closed e2422362296302 ∧ code e2422362296302 = 11218455318510 := by decide
theorem cert_e2422362296302 : check e2422362296302 [[],[]] .three = true := by decide
def e2422362300894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422362300894 : Closed e2422362300894 ∧ code e2422362300894 = 11218455323102 := by decide
theorem cert_e2422362300894 : check e2422362300894 [[],[]] .smaller = true := by decide
def e2422362300918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422362300918 : Closed e2422362300918 ∧ code e2422362300918 = 11218455323126 := by decide
theorem cert_e2422362300918 : check e2422362300918 [[],[]] .smaller = true := by decide
def e2422362301870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422362301870 : Closed e2422362301870 ∧ code e2422362301870 = 11218455324078 := by decide
theorem cert_e2422362301870 : check e2422362301870 [[],[]] .smaller = true := by decide
def e2422362301882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422362301882 : Closed e2422362301882 ∧ code e2422362301882 = 11218455324090 := by decide
theorem cert_e2422362301882 : check e2422362301882 [[],[]] .smaller = true := by decide
def e2422362301930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422362301930 : Closed e2422362301930 ∧ code e2422362301930 = 11218455324138 := by decide
theorem cert_e2422362301930 : check e2422362301930 [[],[]] .smaller = true := by decide
def e2422362302014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e2422362302014 : Closed e2422362302014 ∧ code e2422362302014 = 11218455324222 := by decide
theorem cert_e2422362302014 : check e2422362302014 [[],[]] .smaller = true := by decide
def e2422362302062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362302062 : Closed e2422362302062 ∧ code e2422362302062 = 11218455324270 := by decide
theorem cert_e2422362302062 : check e2422362302062 [[],[]] .smaller = true := by decide
def e2422362302074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362302074 : Closed e2422362302074 ∧ code e2422362302074 = 11218455324282 := by decide
theorem cert_e2422362302074 : check e2422362302074 [[],[]] .smaller = true := by decide
def e2422362302238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422362302238 : Closed e2422362302238 ∧ code e2422362302238 = 11218455324446 := by decide
theorem cert_e2422362302238 : check e2422362302238 [[],[]] .smaller = true := by decide
def e2422362302334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 5))))))))))
theorem wire_e2422362302334 : Closed e2422362302334 ∧ code e2422362302334 = 11218455324542 := by decide
theorem cert_e2422362302334 : check e2422362302334 [[],[]] .three = true := by decide
def e2422362302350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422362302350 : Closed e2422362302350 ∧ code e2422362302350 = 11218455324558 := by decide
theorem cert_e2422362302350 : check e2422362302350 [[],[]] .smaller = true := by decide
def e2422362302362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362302362 : Closed e2422362302362 ∧ code e2422362302362 = 11218455324570 := by decide
theorem cert_e2422362302362 : check e2422362302362 [[],[]] .smaller = true := by decide
def e2422362302406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e2422362302406 : Closed e2422362302406 ∧ code e2422362302406 = 11218455324614 := by decide
theorem cert_e2422362302406 : check e2422362302406 [[],[]] .smaller = true := by decide
def e2422362302430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 3))))))))))
theorem wire_e2422362302430 : Closed e2422362302430 ∧ code e2422362302430 = 11218455324638 := by decide
theorem cert_e2422362302430 : check e2422362302430 [[],[]] .smaller = true := by decide
def e2422362302454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 5) (.var 1))))))))))
theorem wire_e2422362302454 : Closed e2422362302454 ∧ code e2422362302454 = 11218455324662 := by decide
theorem cert_e2422362302454 : check e2422362302454 [[],[]] .three = true := by decide
def e2422362304750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422362304750 : Closed e2422362304750 ∧ code e2422362304750 = 11218455326958 := by decide
theorem cert_e2422362304750 : check e2422362304750 [[],[]] .smaller = true := by decide
def e2422362304758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422362304758 : Closed e2422362304758 ∧ code e2422362304758 = 11218455326966 := by decide
theorem cert_e2422362304758 : check e2422362304758 [[],[]] .smaller = true := by decide
def e2422362305238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422362305238 : Closed e2422362305238 ∧ code e2422362305238 = 11218455327446 := by decide
theorem cert_e2422362305238 : check e2422362305238 [[],[]] .smaller = true := by decide
def e2422362305242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422362305242 : Closed e2422362305242 ∧ code e2422362305242 = 11218455327450 := by decide
theorem cert_e2422362305242 : check e2422362305242 [[],[]] .smaller = true := by decide
def e2422362305258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422362305258 : Closed e2422362305258 ∧ code e2422362305258 = 11218455327466 := by decide
theorem cert_e2422362305258 : check e2422362305258 [[],[]] .smaller = true := by decide
def e2422362305334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422362305334 : Closed e2422362305334 ∧ code e2422362305334 = 11218455327542 := by decide
theorem cert_e2422362305334 : check e2422362305334 [[],[]] .smaller = true := by decide
def e2422362305338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422362305338 : Closed e2422362305338 ∧ code e2422362305338 = 11218455327546 := by decide
theorem cert_e2422362305338 : check e2422362305338 [[],[]] .smaller = true := by decide
def e2422362305406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 5))))))))))
theorem wire_e2422362305406 : Closed e2422362305406 ∧ code e2422362305406 = 11218455327614 := by decide
theorem cert_e2422362305406 : check e2422362305406 [[],[]] .three = true := by decide
def e2422362305422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422362305422 : Closed e2422362305422 ∧ code e2422362305422 = 11218455327630 := by decide
theorem cert_e2422362305422 : check e2422362305422 [[],[]] .smaller = true := by decide
def e2422362305434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362305434 : Closed e2422362305434 ∧ code e2422362305434 = 11218455327642 := by decide
theorem cert_e2422362305434 : check e2422362305434 [[],[]] .smaller = true := by decide
def e2422362305502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422362305502 : Closed e2422362305502 ∧ code e2422362305502 = 11218455327710 := by decide
theorem cert_e2422362305502 : check e2422362305502 [[],[]] .smaller = true := by decide
def e2422362305518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422362305518 : Closed e2422362305518 ∧ code e2422362305518 = 11218455327726 := by decide
theorem cert_e2422362305518 : check e2422362305518 [[],[]] .smaller = true := by decide
def e2422362305530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 5) (.var 0))))))))))
theorem wire_e2422362305530 : Closed e2422362305530 ∧ code e2422362305530 = 11218455327738 := by decide
theorem cert_e2422362305530 : check e2422362305530 [[],[]] .three = true := by decide
def e2422362306958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422362306958 : Closed e2422362306958 ∧ code e2422362306958 = 11218455329166 := by decide
theorem cert_e2422362306958 : check e2422362306958 [[],[]] .smaller = true := by decide
def e2422362307006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422362307006 : Closed e2422362307006 ∧ code e2422362307006 = 11218455329214 := by decide
theorem cert_e2422362307006 : check e2422362307006 [[],[]] .smaller = true := by decide
def e2422362307014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422362307014 : Closed e2422362307014 ∧ code e2422362307014 = 11218455329222 := by decide
theorem cert_e2422362307014 : check e2422362307014 [[],[]] .smaller = true := by decide
def e2422362307038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422362307038 : Closed e2422362307038 ∧ code e2422362307038 = 11218455329246 := by decide
theorem cert_e2422362307038 : check e2422362307038 [[],[]] .smaller = true := by decide
def e2422362307054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422362307054 : Closed e2422362307054 ∧ code e2422362307054 = 11218455329262 := by decide
theorem cert_e2422362307054 : check e2422362307054 [[],[]] .smaller = true := by decide
def e2422362307062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422362307062 : Closed e2422362307062 ∧ code e2422362307062 = 11218455329270 := by decide
theorem cert_e2422362307062 : check e2422362307062 [[],[]] .smaller = true := by decide
def e2422362307066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422362307066 : Closed e2422362307066 ∧ code e2422362307066 = 11218455329274 := by decide
theorem cert_e2422362307066 : check e2422362307066 [[],[]] .smaller = true := by decide
def e2422362307806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422362307806 : Closed e2422362307806 ∧ code e2422362307806 = 11218455330014 := by decide
theorem cert_e2422362307806 : check e2422362307806 [[],[]] .smaller = true := by decide
def e2422362307834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422362307834 : Closed e2422362307834 ∧ code e2422362307834 = 11218455330042 := by decide
theorem cert_e2422362307834 : check e2422362307834 [[],[]] .smaller = true := by decide
def e2422362308206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 5)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362308206 : Closed e2422362308206 ∧ code e2422362308206 = 11218455330414 := by decide
theorem cert_e2422362308206 : check e2422362308206 [[],[]] .three = true := by decide
def e2422362308214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 5)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422362308214 : Closed e2422362308214 ∧ code e2422362308214 = 11218455330422 := by decide
theorem cert_e2422362308214 : check e2422362308214 [[],[]] .three = true := by decide
def e2422362308218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 5)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362308218 : Closed e2422362308218 ∧ code e2422362308218 = 11218455330426 := by decide
theorem cert_e2422362308218 : check e2422362308218 [[],[]] .three = true := by decide
def e2422362310510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))))
theorem wire_e2422362310510 : Closed e2422362310510 ∧ code e2422362310510 = 11218455332718 := by decide
theorem cert_e2422362310510 : check e2422362310510 [[],[]] .smaller = true := by decide
def e2422362310522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))))
theorem wire_e2422362310522 : Closed e2422362310522 ∧ code e2422362310522 = 11218455332730 := by decide
theorem cert_e2422362310522 : check e2422362310522 [[],[]] .smaller = true := by decide
def e2422362310618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))))
theorem wire_e2422362310618 : Closed e2422362310618 ∧ code e2422362310618 = 11218455332826 := by decide
theorem cert_e2422362310618 : check e2422362310618 [[],[]] .smaller = true := by decide
def e2422362311902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422362311902 : Closed e2422362311902 ∧ code e2422362311902 = 11218455334110 := by decide
theorem cert_e2422362311902 : check e2422362311902 [[],[]] .smaller = true := by decide
def e2422362311918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422362311918 : Closed e2422362311918 ∧ code e2422362311918 = 11218455334126 := by decide
theorem cert_e2422362311918 : check e2422362311918 [[],[]] .smaller = true := by decide
def e2422362311926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422362311926 : Closed e2422362311926 ∧ code e2422362311926 = 11218455334134 := by decide
theorem cert_e2422362311926 : check e2422362311926 [[],[]] .smaller = true := by decide
def e2422362311930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422362311930 : Closed e2422362311930 ∧ code e2422362311930 = 11218455334138 := by decide
theorem cert_e2422362311930 : check e2422362311930 [[],[]] .smaller = true := by decide
def e2422362312302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362312302 : Closed e2422362312302 ∧ code e2422362312302 = 11218455334510 := by decide
theorem cert_e2422362312302 : check e2422362312302 [[],[]] .smaller = true := by decide
def e2422362312314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362312314 : Closed e2422362312314 ∧ code e2422362312314 = 11218455334522 := by decide
theorem cert_e2422362312314 : check e2422362312314 [[],[]] .smaller = true := by decide
def e2422362312502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362312502 : Closed e2422362312502 ∧ code e2422362312502 = 11218455334710 := by decide
theorem cert_e2422362312502 : check e2422362312502 [[],[]] .smaller = true := by decide
end Blc.Floor43
