import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374322014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))))
theorem wire_e2422374322014 : Closed e2422374322014 ∧ code e2422374322014 = 11218467344222 := by decide
theorem cert_e2422374322014 : check e2422374322014 [[],[]] .smaller = true := by decide
def e2422374322018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))))
theorem wire_e2422374322018 : Closed e2422374322018 ∧ code e2422374322018 = 11218467344226 := by decide
theorem cert_e2422374322018 : check e2422374322018 [[],[]] .smaller = true := by decide
def e2422374322030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))))
theorem wire_e2422374322030 : Closed e2422374322030 ∧ code e2422374322030 = 11218467344238 := by decide
theorem cert_e2422374322030 : check e2422374322030 [[],[]] .smaller = true := by decide
def e2422374322038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))))
theorem wire_e2422374322038 : Closed e2422374322038 ∧ code e2422374322038 = 11218467344246 := by decide
theorem cert_e2422374322038 : check e2422374322038 [[],[]] .smaller = true := by decide
def e2422374322042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))))
theorem wire_e2422374322042 : Closed e2422374322042 ∧ code e2422374322042 = 11218467344250 := by decide
theorem cert_e2422374322042 : check e2422374322042 [[],[]] .smaller = true := by decide
def e2422374322094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))))
theorem wire_e2422374322094 : Closed e2422374322094 ∧ code e2422374322094 = 11218467344302 := by decide
theorem cert_e2422374322094 : check e2422374322094 [[],[]] .smaller = true := by decide
def e2422374322102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))))
theorem wire_e2422374322102 : Closed e2422374322102 ∧ code e2422374322102 = 11218467344310 := by decide
theorem cert_e2422374322102 : check e2422374322102 [[],[]] .smaller = true := by decide
def e2422374322106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))))
theorem wire_e2422374322106 : Closed e2422374322106 ∧ code e2422374322106 = 11218467344314 := by decide
theorem cert_e2422374322106 : check e2422374322106 [[],[]] .smaller = true := by decide
def e2422374322134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 1)))))))))
theorem wire_e2422374322134 : Closed e2422374322134 ∧ code e2422374322134 = 11218467344342 := by decide
theorem cert_e2422374322134 : check e2422374322134 [[],[]] .three = true := by decide
def e2422374322138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 0)))))))))
theorem wire_e2422374322138 : Closed e2422374322138 ∧ code e2422374322138 = 11218467344346 := by decide
theorem cert_e2422374322138 : check e2422374322138 [[],[]] .three = true := by decide
def e2422374323134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422374323134 : Closed e2422374323134 ∧ code e2422374323134 = 11218467345342 := by decide
theorem cert_e2422374323134 : check e2422374323134 [[],[]] .three = true := by decide
def e2422374323166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422374323166 : Closed e2422374323166 ∧ code e2422374323166 = 11218467345374 := by decide
theorem cert_e2422374323166 : check e2422374323166 [[],[]] .smaller = true := by decide
def e2422374323182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422374323182 : Closed e2422374323182 ∧ code e2422374323182 = 11218467345390 := by decide
theorem cert_e2422374323182 : check e2422374323182 [[],[]] .smaller = true := by decide
def e2422374323190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422374323190 : Closed e2422374323190 ∧ code e2422374323190 = 11218467345398 := by decide
theorem cert_e2422374323190 : check e2422374323190 [[],[]] .three = true := by decide
def e2422374324286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422374324286 : Closed e2422374324286 ∧ code e2422374324286 = 11218467346494 := by decide
theorem cert_e2422374324286 : check e2422374324286 [[],[]] .smaller = true := by decide
def e2422374324670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422374324670 : Closed e2422374324670 ∧ code e2422374324670 = 11218467346878 := by decide
theorem cert_e2422374324670 : check e2422374324670 [[],[]] .three = true := by decide
def e2422374324702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422374324702 : Closed e2422374324702 ∧ code e2422374324702 = 11218467346910 := by decide
theorem cert_e2422374324702 : check e2422374324702 [[],[]] .smaller = true := by decide
def e2422374324706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422374324706 : Closed e2422374324706 ∧ code e2422374324706 = 11218467346914 := by decide
theorem cert_e2422374324706 : check e2422374324706 [[],[]] .smaller = true := by decide
def e2422374324718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422374324718 : Closed e2422374324718 ∧ code e2422374324718 = 11218467346926 := by decide
theorem cert_e2422374324718 : check e2422374324718 [[],[]] .smaller = true := by decide
def e2422374324726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422374324726 : Closed e2422374324726 ∧ code e2422374324726 = 11218467346934 := by decide
theorem cert_e2422374324726 : check e2422374324726 [[],[]] .smaller = true := by decide
def e2422374324730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422374324730 : Closed e2422374324730 ∧ code e2422374324730 = 11218467346938 := by decide
theorem cert_e2422374324730 : check e2422374324730 [[],[]] .three = true := by decide
def e2422374325278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422374325278 : Closed e2422374325278 ∧ code e2422374325278 = 11218467347486 := by decide
theorem cert_e2422374325278 : check e2422374325278 [[],[]] .smaller = true := by decide
def e2422374325470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422374325470 : Closed e2422374325470 ∧ code e2422374325470 = 11218467347678 := by decide
theorem cert_e2422374325470 : check e2422374325470 [[],[]] .smaller = true := by decide
def e2422374325474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422374325474 : Closed e2422374325474 ∧ code e2422374325474 = 11218467347682 := by decide
theorem cert_e2422374325474 : check e2422374325474 [[],[]] .smaller = true := by decide
def e2422374325486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422374325486 : Closed e2422374325486 ∧ code e2422374325486 = 11218467347694 := by decide
theorem cert_e2422374325486 : check e2422374325486 [[],[]] .smaller = true := by decide
def e2422374325494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422374325494 : Closed e2422374325494 ∧ code e2422374325494 = 11218467347702 := by decide
theorem cert_e2422374325494 : check e2422374325494 [[],[]] .smaller = true := by decide
def e2422374325498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422374325498 : Closed e2422374325498 ∧ code e2422374325498 = 11218467347706 := by decide
theorem cert_e2422374325498 : check e2422374325498 [[],[]] .smaller = true := by decide
def e2422374325870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374325870 : Closed e2422374325870 ∧ code e2422374325870 = 11218467348078 := by decide
theorem cert_e2422374325870 : check e2422374325870 [[],[]] .smaller = true := by decide
def e2422374325878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422374325878 : Closed e2422374325878 ∧ code e2422374325878 = 11218467348086 := by decide
theorem cert_e2422374325878 : check e2422374325878 [[],[]] .smaller = true := by decide
def e2422374325882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374325882 : Closed e2422374325882 ∧ code e2422374325882 = 11218467348090 := by decide
theorem cert_e2422374325882 : check e2422374325882 [[],[]] .smaller = true := by decide
def e2422374326070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374326070 : Closed e2422374326070 ∧ code e2422374326070 = 11218467348278 := by decide
theorem cert_e2422374326070 : check e2422374326070 [[],[]] .three = true := by decide
def e2422374326074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374326074 : Closed e2422374326074 ∧ code e2422374326074 = 11218467348282 := by decide
theorem cert_e2422374326074 : check e2422374326074 [[],[]] .three = true := by decide
def e2422374326510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))))
theorem wire_e2422374326510 : Closed e2422374326510 ∧ code e2422374326510 = 11218467348718 := by decide
theorem cert_e2422374326510 : check e2422374326510 [[],[]] .smaller = true := by decide
def e2422374326522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))))
theorem wire_e2422374326522 : Closed e2422374326522 ∧ code e2422374326522 = 11218467348730 := by decide
theorem cert_e2422374326522 : check e2422374326522 [[],[]] .smaller = true := by decide
def e2422374326894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374326894 : Closed e2422374326894 ∧ code e2422374326894 = 11218467349102 := by decide
theorem cert_e2422374326894 : check e2422374326894 [[],[]] .smaller = true := by decide
def e2422374326906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374326906 : Closed e2422374326906 ∧ code e2422374326906 = 11218467349114 := by decide
theorem cert_e2422374326906 : check e2422374326906 [[],[]] .smaller = true := by decide
def e2422374327070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))))
theorem wire_e2422374327070 : Closed e2422374327070 ∧ code e2422374327070 = 11218467349278 := by decide
theorem cert_e2422374327070 : check e2422374327070 [[],[]] .smaller = true := by decide
def e2422374327238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))))
theorem wire_e2422374327238 : Closed e2422374327238 ∧ code e2422374327238 = 11218467349446 := by decide
theorem cert_e2422374327238 : check e2422374327238 [[],[]] .smaller = true := by decide
def e2422374327262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 3)))))))))
theorem wire_e2422374327262 : Closed e2422374327262 ∧ code e2422374327262 = 11218467349470 := by decide
theorem cert_e2422374327262 : check e2422374327262 [[],[]] .smaller = true := by decide
def e2422374327278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 2)))))))))
theorem wire_e2422374327278 : Closed e2422374327278 ∧ code e2422374327278 = 11218467349486 := by decide
theorem cert_e2422374327278 : check e2422374327278 [[],[]] .smaller = true := by decide
def e2422374327854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))))
theorem wire_e2422374327854 : Closed e2422374327854 ∧ code e2422374327854 = 11218467350062 := by decide
theorem cert_e2422374327854 : check e2422374327854 [[],[]] .smaller = true := by decide
def e2422374327998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 4)))))))))
theorem wire_e2422374327998 : Closed e2422374327998 ∧ code e2422374327998 = 11218467350206 := by decide
theorem cert_e2422374327998 : check e2422374327998 [[],[]] .three = true := by decide
def e2422374328030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e2422374328030 : Closed e2422374328030 ∧ code e2422374328030 = 11218467350238 := by decide
theorem cert_e2422374328030 : check e2422374328030 [[],[]] .smaller = true := by decide
def e2422374328034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))))
theorem wire_e2422374328034 : Closed e2422374328034 ∧ code e2422374328034 = 11218467350242 := by decide
theorem cert_e2422374328034 : check e2422374328034 [[],[]] .smaller = true := by decide
def e2422374328046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))))
theorem wire_e2422374328046 : Closed e2422374328046 ∧ code e2422374328046 = 11218467350254 := by decide
theorem cert_e2422374328046 : check e2422374328046 [[],[]] .smaller = true := by decide
def e2422374328054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e2422374328054 : Closed e2422374328054 ∧ code e2422374328054 = 11218467350262 := by decide
theorem cert_e2422374328054 : check e2422374328054 [[],[]] .smaller = true := by decide
def e2422374328058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 0)))))))))
theorem wire_e2422374328058 : Closed e2422374328058 ∧ code e2422374328058 = 11218467350266 := by decide
theorem cert_e2422374328058 : check e2422374328058 [[],[]] .three = true := by decide
def e2422374328158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e2422374328158 : Closed e2422374328158 ∧ code e2422374328158 = 11218467350366 := by decide
theorem cert_e2422374328158 : check e2422374328158 [[],[]] .smaller = true := by decide
def e2422374328186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e2422374328186 : Closed e2422374328186 ∧ code e2422374328186 = 11218467350394 := by decide
theorem cert_e2422374328186 : check e2422374328186 [[],[]] .smaller = true := by decide
def e2422374328202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422374328202 : Closed e2422374328202 ∧ code e2422374328202 = 11218467350410 := by decide
theorem cert_e2422374328202 : check e2422374328202 [[],[]] .smaller = true := by decide
def e2422374328226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))))
theorem wire_e2422374328226 : Closed e2422374328226 ∧ code e2422374328226 = 11218467350434 := by decide
theorem cert_e2422374328226 : check e2422374328226 [[],[]] .smaller = true := by decide
def e2422374328238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))))
theorem wire_e2422374328238 : Closed e2422374328238 ∧ code e2422374328238 = 11218467350446 := by decide
theorem cert_e2422374328238 : check e2422374328238 [[],[]] .smaller = true := by decide
def e2422374328250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))))
theorem wire_e2422374328250 : Closed e2422374328250 ∧ code e2422374328250 = 11218467350458 := by decide
theorem cert_e2422374328250 : check e2422374328250 [[],[]] .smaller = true := by decide
def e2422374328278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e2422374328278 : Closed e2422374328278 ∧ code e2422374328278 = 11218467350486 := by decide
theorem cert_e2422374328278 : check e2422374328278 [[],[]] .smaller = true := by decide
def e2422374328282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e2422374328282 : Closed e2422374328282 ∧ code e2422374328282 = 11218467350490 := by decide
theorem cert_e2422374328282 : check e2422374328282 [[],[]] .smaller = true := by decide
def e2422374328298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 0)))))))))
theorem wire_e2422374328298 : Closed e2422374328298 ∧ code e2422374328298 = 11218467350506 := by decide
theorem cert_e2422374328298 : check e2422374328298 [[],[]] .three = true := by decide
def e2422374328382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422374328382 : Closed e2422374328382 ∧ code e2422374328382 = 11218467350590 := by decide
theorem cert_e2422374328382 : check e2422374328382 [[],[]] .smaller = true := by decide
def e2422374328766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422374328766 : Closed e2422374328766 ∧ code e2422374328766 = 11218467350974 := by decide
theorem cert_e2422374328766 : check e2422374328766 [[],[]] .three = true := by decide
def e2422374328798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422374328798 : Closed e2422374328798 ∧ code e2422374328798 = 11218467351006 := by decide
theorem cert_e2422374328798 : check e2422374328798 [[],[]] .smaller = true := by decide
def e2422374328802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422374328802 : Closed e2422374328802 ∧ code e2422374328802 = 11218467351010 := by decide
theorem cert_e2422374328802 : check e2422374328802 [[],[]] .smaller = true := by decide
def e2422374328814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422374328814 : Closed e2422374328814 ∧ code e2422374328814 = 11218467351022 := by decide
theorem cert_e2422374328814 : check e2422374328814 [[],[]] .smaller = true := by decide
def e2422374328822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422374328822 : Closed e2422374328822 ∧ code e2422374328822 = 11218467351030 := by decide
theorem cert_e2422374328822 : check e2422374328822 [[],[]] .smaller = true := by decide
def e2422374328826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422374328826 : Closed e2422374328826 ∧ code e2422374328826 = 11218467351034 := by decide
theorem cert_e2422374328826 : check e2422374328826 [[],[]] .three = true := by decide
def e2422374329566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422374329566 : Closed e2422374329566 ∧ code e2422374329566 = 11218467351774 := by decide
theorem cert_e2422374329566 : check e2422374329566 [[],[]] .smaller = true := by decide
def e2422374329594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422374329594 : Closed e2422374329594 ∧ code e2422374329594 = 11218467351802 := by decide
theorem cert_e2422374329594 : check e2422374329594 [[],[]] .smaller = true := by decide
def e2422374329870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422374329870 : Closed e2422374329870 ∧ code e2422374329870 = 11218467352078 := by decide
theorem cert_e2422374329870 : check e2422374329870 [[],[]] .smaller = true := by decide
def e2422374329918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 4))))))))))
theorem wire_e2422374329918 : Closed e2422374329918 ∧ code e2422374329918 = 11218467352126 := by decide
theorem cert_e2422374329918 : check e2422374329918 [[],[]] .smaller = true := by decide
def e2422374329954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422374329954 : Closed e2422374329954 ∧ code e2422374329954 = 11218467352162 := by decide
theorem cert_e2422374329954 : check e2422374329954 [[],[]] .smaller = true := by decide
def e2422374329966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374329966 : Closed e2422374329966 ∧ code e2422374329966 = 11218467352174 := by decide
theorem cert_e2422374329966 : check e2422374329966 [[],[]] .smaller = true := by decide
def e2422374329978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374329978 : Closed e2422374329978 ∧ code e2422374329978 = 11218467352186 := by decide
theorem cert_e2422374329978 : check e2422374329978 [[],[]] .smaller = true := by decide
def e2422374330142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 3))))))))))
theorem wire_e2422374330142 : Closed e2422374330142 ∧ code e2422374330142 = 11218467352350 := by decide
theorem cert_e2422374330142 : check e2422374330142 [[],[]] .smaller = true := by decide
def e2422374330166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374330166 : Closed e2422374330166 ∧ code e2422374330166 = 11218467352374 := by decide
theorem cert_e2422374330166 : check e2422374330166 [[],[]] .smaller = true := by decide
def e2422374330170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374330170 : Closed e2422374330170 ∧ code e2422374330170 = 11218467352378 := by decide
theorem cert_e2422374330170 : check e2422374330170 [[],[]] .smaller = true := by decide
def e2422374330266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374330266 : Closed e2422374330266 ∧ code e2422374330266 = 11218467352474 := by decide
theorem cert_e2422374330266 : check e2422374330266 [[],[]] .three = true := by decide
def e2422374330486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))))
theorem wire_e2422374330486 : Closed e2422374330486 ∧ code e2422374330486 = 11218467352694 := by decide
theorem cert_e2422374330486 : check e2422374330486 [[],[]] .smaller = true := by decide
def e2422374330490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))))
theorem wire_e2422374330490 : Closed e2422374330490 ∧ code e2422374330490 = 11218467352698 := by decide
theorem cert_e2422374330490 : check e2422374330490 [[],[]] .smaller = true := by decide
def e2422374330678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374330678 : Closed e2422374330678 ∧ code e2422374330678 = 11218467352886 := by decide
theorem cert_e2422374330678 : check e2422374330678 [[],[]] .smaller = true := by decide
def e2422374330682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374330682 : Closed e2422374330682 ∧ code e2422374330682 = 11218467352890 := by decide
theorem cert_e2422374330682 : check e2422374330682 [[],[]] .smaller = true := by decide
def e2422374330766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))))
theorem wire_e2422374330766 : Closed e2422374330766 ∧ code e2422374330766 = 11218467352974 := by decide
theorem cert_e2422374330766 : check e2422374330766 [[],[]] .smaller = true := by decide
def e2422374330822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))))
theorem wire_e2422374330822 : Closed e2422374330822 ∧ code e2422374330822 = 11218467353030 := by decide
theorem cert_e2422374330822 : check e2422374330822 [[],[]] .smaller = true := by decide
def e2422374330846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e2422374330846 : Closed e2422374330846 ∧ code e2422374330846 = 11218467353054 := by decide
theorem cert_e2422374330846 : check e2422374330846 [[],[]] .smaller = true := by decide
def e2422374330870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e2422374330870 : Closed e2422374330870 ∧ code e2422374330870 = 11218467353078 := by decide
theorem cert_e2422374330870 : check e2422374330870 [[],[]] .smaller = true := by decide
def e2422374331158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))))
theorem wire_e2422374331158 : Closed e2422374331158 ∧ code e2422374331158 = 11218467353366 := by decide
theorem cert_e2422374331158 : check e2422374331158 [[],[]] .smaller = true := by decide
def e2422374331230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e2422374331230 : Closed e2422374331230 ∧ code e2422374331230 = 11218467353438 := by decide
theorem cert_e2422374331230 : check e2422374331230 [[],[]] .smaller = true := by decide
def e2422374331234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))))
theorem wire_e2422374331234 : Closed e2422374331234 ∧ code e2422374331234 = 11218467353442 := by decide
theorem cert_e2422374331234 : check e2422374331234 [[],[]] .smaller = true := by decide
def e2422374331246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2422374331246 : Closed e2422374331246 ∧ code e2422374331246 = 11218467353454 := by decide
theorem cert_e2422374331246 : check e2422374331246 [[],[]] .smaller = true := by decide
def e2422374331254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2422374331254 : Closed e2422374331254 ∧ code e2422374331254 = 11218467353462 := by decide
theorem cert_e2422374331254 : check e2422374331254 [[],[]] .smaller = true := by decide
def e2422374331258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e2422374331258 : Closed e2422374331258 ∧ code e2422374331258 = 11218467353466 := by decide
theorem cert_e2422374331258 : check e2422374331258 [[],[]] .smaller = true := by decide
def e2422374331274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422374331274 : Closed e2422374331274 ∧ code e2422374331274 = 11218467353482 := by decide
theorem cert_e2422374331274 : check e2422374331274 [[],[]] .smaller = true := by decide
def e2422374331298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))))
theorem wire_e2422374331298 : Closed e2422374331298 ∧ code e2422374331298 = 11218467353506 := by decide
theorem cert_e2422374331298 : check e2422374331298 [[],[]] .smaller = true := by decide
def e2422374331310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2422374331310 : Closed e2422374331310 ∧ code e2422374331310 = 11218467353518 := by decide
theorem cert_e2422374331310 : check e2422374331310 [[],[]] .smaller = true := by decide
def e2422374331322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2422374331322 : Closed e2422374331322 ∧ code e2422374331322 = 11218467353530 := by decide
theorem cert_e2422374331322 : check e2422374331322 [[],[]] .smaller = true := by decide
def e2422374331350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2422374331350 : Closed e2422374331350 ∧ code e2422374331350 = 11218467353558 := by decide
theorem cert_e2422374331350 : check e2422374331350 [[],[]] .smaller = true := by decide
def e2422374331354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2422374331354 : Closed e2422374331354 ∧ code e2422374331354 = 11218467353562 := by decide
theorem cert_e2422374331354 : check e2422374331354 [[],[]] .smaller = true := by decide
def e2422374331370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e2422374331370 : Closed e2422374331370 ∧ code e2422374331370 = 11218467353578 := by decide
theorem cert_e2422374331370 : check e2422374331370 [[],[]] .smaller = true := by decide
def e2422374331422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422374331422 : Closed e2422374331422 ∧ code e2422374331422 = 11218467353630 := by decide
theorem cert_e2422374331422 : check e2422374331422 [[],[]] .smaller = true := by decide
def e2422374331614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422374331614 : Closed e2422374331614 ∧ code e2422374331614 = 11218467353822 := by decide
theorem cert_e2422374331614 : check e2422374331614 [[],[]] .smaller = true := by decide
def e2422374331618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422374331618 : Closed e2422374331618 ∧ code e2422374331618 = 11218467353826 := by decide
theorem cert_e2422374331618 : check e2422374331618 [[],[]] .smaller = true := by decide
def e2422374331630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422374331630 : Closed e2422374331630 ∧ code e2422374331630 = 11218467353838 := by decide
theorem cert_e2422374331630 : check e2422374331630 [[],[]] .smaller = true := by decide
def e2422374331638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422374331638 : Closed e2422374331638 ∧ code e2422374331638 = 11218467353846 := by decide
theorem cert_e2422374331638 : check e2422374331638 [[],[]] .smaller = true := by decide
def e2422374331642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422374331642 : Closed e2422374331642 ∧ code e2422374331642 = 11218467353850 := by decide
theorem cert_e2422374331642 : check e2422374331642 [[],[]] .smaller = true := by decide
def e2422374331918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422374331918 : Closed e2422374331918 ∧ code e2422374331918 = 11218467354126 := by decide
theorem cert_e2422374331918 : check e2422374331918 [[],[]] .smaller = true := by decide
def e2422374331966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e2422374331966 : Closed e2422374331966 ∧ code e2422374331966 = 11218467354174 := by decide
theorem cert_e2422374331966 : check e2422374331966 [[],[]] .smaller = true := by decide
def e2422374332002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422374332002 : Closed e2422374332002 ∧ code e2422374332002 = 11218467354210 := by decide
theorem cert_e2422374332002 : check e2422374332002 [[],[]] .smaller = true := by decide
def e2422374332014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374332014 : Closed e2422374332014 ∧ code e2422374332014 = 11218467354222 := by decide
theorem cert_e2422374332014 : check e2422374332014 [[],[]] .smaller = true := by decide
def e2422374332026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374332026 : Closed e2422374332026 ∧ code e2422374332026 = 11218467354234 := by decide
theorem cert_e2422374332026 : check e2422374332026 [[],[]] .smaller = true := by decide
def e2422374332214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374332214 : Closed e2422374332214 ∧ code e2422374332214 = 11218467354422 := by decide
theorem cert_e2422374332214 : check e2422374332214 [[],[]] .smaller = true := by decide
def e2422374332218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374332218 : Closed e2422374332218 ∧ code e2422374332218 = 11218467354426 := by decide
theorem cert_e2422374332218 : check e2422374332218 [[],[]] .smaller = true := by decide
def e2422374332302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e2422374332302 : Closed e2422374332302 ∧ code e2422374332302 = 11218467354510 := by decide
theorem cert_e2422374332302 : check e2422374332302 [[],[]] .smaller = true := by decide
def e2422374332314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374332314 : Closed e2422374332314 ∧ code e2422374332314 = 11218467354522 := by decide
theorem cert_e2422374332314 : check e2422374332314 [[],[]] .smaller = true := by decide
def e2422374332654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2422374332654 : Closed e2422374332654 ∧ code e2422374332654 = 11218467354862 := by decide
theorem cert_e2422374332654 : check e2422374332654 [[],[]] .smaller = true := by decide
def e2422374332662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2422374332662 : Closed e2422374332662 ∧ code e2422374332662 = 11218467354870 := by decide
theorem cert_e2422374332662 : check e2422374332662 [[],[]] .smaller = true := by decide
def e2422374332846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422374332846 : Closed e2422374332846 ∧ code e2422374332846 = 11218467355054 := by decide
theorem cert_e2422374332846 : check e2422374332846 [[],[]] .smaller = true := by decide
def e2422374332854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e2422374332854 : Closed e2422374332854 ∧ code e2422374332854 = 11218467355062 := by decide
theorem cert_e2422374332854 : check e2422374332854 [[],[]] .smaller = true := by decide
def e2422374332858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422374332858 : Closed e2422374332858 ∧ code e2422374332858 = 11218467355066 := by decide
theorem cert_e2422374332858 : check e2422374332858 [[],[]] .smaller = true := by decide
def e2422374332886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e2422374332886 : Closed e2422374332886 ∧ code e2422374332886 = 11218467355094 := by decide
theorem cert_e2422374332886 : check e2422374332886 [[],[]] .smaller = true := by decide
def e2422374332890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e2422374332890 : Closed e2422374332890 ∧ code e2422374332890 = 11218467355098 := by decide
theorem cert_e2422374332890 : check e2422374332890 [[],[]] .smaller = true := by decide
def e2422374332906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422374332906 : Closed e2422374332906 ∧ code e2422374332906 = 11218467355114 := by decide
theorem cert_e2422374332906 : check e2422374332906 [[],[]] .smaller = true := by decide
def e2422374333038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374333038 : Closed e2422374333038 ∧ code e2422374333038 = 11218467355246 := by decide
theorem cert_e2422374333038 : check e2422374333038 [[],[]] .smaller = true := by decide
def e2422374333046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422374333046 : Closed e2422374333046 ∧ code e2422374333046 = 11218467355254 := by decide
theorem cert_e2422374333046 : check e2422374333046 [[],[]] .smaller = true := by decide
def e2422374333050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374333050 : Closed e2422374333050 ∧ code e2422374333050 = 11218467355258 := by decide
theorem cert_e2422374333050 : check e2422374333050 [[],[]] .smaller = true := by decide
def e2422374333214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2422374333214 : Closed e2422374333214 ∧ code e2422374333214 = 11218467355422 := by decide
theorem cert_e2422374333214 : check e2422374333214 [[],[]] .smaller = true := by decide
def e2422374333238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374333238 : Closed e2422374333238 ∧ code e2422374333238 = 11218467355446 := by decide
theorem cert_e2422374333238 : check e2422374333238 [[],[]] .smaller = true := by decide
def e2422374333242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374333242 : Closed e2422374333242 ∧ code e2422374333242 = 11218467355450 := by decide
theorem cert_e2422374333242 : check e2422374333242 [[],[]] .smaller = true := by decide
def e2422374333326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2422374333326 : Closed e2422374333326 ∧ code e2422374333326 = 11218467355534 := by decide
theorem cert_e2422374333326 : check e2422374333326 [[],[]] .smaller = true := by decide
def e2422374333338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374333338 : Closed e2422374333338 ∧ code e2422374333338 = 11218467355546 := by decide
theorem cert_e2422374333338 : check e2422374333338 [[],[]] .smaller = true := by decide
def e2422374333654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422374333654 : Closed e2422374333654 ∧ code e2422374333654 = 11218467355862 := by decide
theorem cert_e2422374333654 : check e2422374333654 [[],[]] .three = true := by decide
def e2422374333658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422374333658 : Closed e2422374333658 ∧ code e2422374333658 = 11218467355866 := by decide
theorem cert_e2422374333658 : check e2422374333658 [[],[]] .three = true := by decide
def e2422374333674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422374333674 : Closed e2422374333674 ∧ code e2422374333674 = 11218467355882 := by decide
theorem cert_e2422374333674 : check e2422374333674 [[],[]] .three = true := by decide
def e2422374333750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374333750 : Closed e2422374333750 ∧ code e2422374333750 = 11218467355958 := by decide
theorem cert_e2422374333750 : check e2422374333750 [[],[]] .three = true := by decide
def e2422374333754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374333754 : Closed e2422374333754 ∧ code e2422374333754 = 11218467355962 := by decide
theorem cert_e2422374333754 : check e2422374333754 [[],[]] .three = true := by decide
def e2422374333850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374333850 : Closed e2422374333850 ∧ code e2422374333850 = 11218467356058 := by decide
theorem cert_e2422374333850 : check e2422374333850 [[],[]] .three = true := by decide
def e2422374337390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e2422374337390 : Closed e2422374337390 ∧ code e2422374337390 = 11218467359598 := by decide
theorem cert_e2422374337390 : check e2422374337390 [[],[]] .smaller = true := by decide
def e2422374337398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e2422374337398 : Closed e2422374337398 ∧ code e2422374337398 = 11218467359606 := by decide
theorem cert_e2422374337398 : check e2422374337398 [[],[]] .smaller = true := by decide
def e2422374337454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e2422374337454 : Closed e2422374337454 ∧ code e2422374337454 = 11218467359662 := by decide
theorem cert_e2422374337454 : check e2422374337454 [[],[]] .smaller = true := by decide
def e2422374337466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e2422374337466 : Closed e2422374337466 ∧ code e2422374337466 = 11218467359674 := by decide
theorem cert_e2422374337466 : check e2422374337466 [[],[]] .smaller = true := by decide
def e2422374337494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e2422374337494 : Closed e2422374337494 ∧ code e2422374337494 = 11218467359702 := by decide
theorem cert_e2422374337494 : check e2422374337494 [[],[]] .smaller = true := by decide
def e2422374337498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e2422374337498 : Closed e2422374337498 ∧ code e2422374337498 = 11218467359706 := by decide
theorem cert_e2422374337498 : check e2422374337498 [[],[]] .smaller = true := by decide
def e2422374337774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422374337774 : Closed e2422374337774 ∧ code e2422374337774 = 11218467359982 := by decide
theorem cert_e2422374337774 : check e2422374337774 [[],[]] .smaller = true := by decide
def e2422374337782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422374337782 : Closed e2422374337782 ∧ code e2422374337782 = 11218467359990 := by decide
theorem cert_e2422374337782 : check e2422374337782 [[],[]] .smaller = true := by decide
def e2422374338158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422374338158 : Closed e2422374338158 ∧ code e2422374338158 = 11218467360366 := by decide
theorem cert_e2422374338158 : check e2422374338158 [[],[]] .smaller = true := by decide
def e2422374338170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422374338170 : Closed e2422374338170 ∧ code e2422374338170 = 11218467360378 := by decide
theorem cert_e2422374338170 : check e2422374338170 [[],[]] .smaller = true := by decide
def e2422374338358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422374338358 : Closed e2422374338358 ∧ code e2422374338358 = 11218467360566 := by decide
theorem cert_e2422374338358 : check e2422374338358 [[],[]] .smaller = true := by decide
def e2422374338362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422374338362 : Closed e2422374338362 ∧ code e2422374338362 = 11218467360570 := by decide
theorem cert_e2422374338362 : check e2422374338362 [[],[]] .smaller = true := by decide
def e2422374338430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 5)))))))))))
theorem wire_e2422374338430 : Closed e2422374338430 ∧ code e2422374338430 = 11218467360638 := by decide
theorem cert_e2422374338430 : check e2422374338430 [[],[]] .three = true := by decide
def e2422374338542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 5) (.var 2)))))))))))
theorem wire_e2422374338542 : Closed e2422374338542 ∧ code e2422374338542 = 11218467360750 := by decide
theorem cert_e2422374338542 : check e2422374338542 [[],[]] .three = true := by decide
def e2422374346174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 4))))))))))
theorem wire_e2422374346174 : Closed e2422374346174 ∧ code e2422374346174 = 11218467368382 := by decide
theorem cert_e2422374346174 : check e2422374346174 [[],[]] .three = true := by decide
def e2422374346206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e2422374346206 : Closed e2422374346206 ∧ code e2422374346206 = 11218467368414 := by decide
theorem cert_e2422374346206 : check e2422374346206 [[],[]] .smaller = true := by decide
def e2422374346222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e2422374346222 : Closed e2422374346222 ∧ code e2422374346222 = 11218467368430 := by decide
theorem cert_e2422374346222 : check e2422374346222 [[],[]] .smaller = true := by decide
def e2422374346230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 1))))))))))
theorem wire_e2422374346230 : Closed e2422374346230 ∧ code e2422374346230 = 11218467368438 := by decide
theorem cert_e2422374346230 : check e2422374346230 [[],[]] .three = true := by decide
def e2422374346286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))))
theorem wire_e2422374346286 : Closed e2422374346286 ∧ code e2422374346286 = 11218467368494 := by decide
theorem cert_e2422374346286 : check e2422374346286 [[],[]] .smaller = true := by decide
def e2422374346430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 4))))))))))
theorem wire_e2422374346430 : Closed e2422374346430 ∧ code e2422374346430 = 11218467368638 := by decide
theorem cert_e2422374346430 : check e2422374346430 [[],[]] .three = true := by decide
def e2422374346462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))))
theorem wire_e2422374346462 : Closed e2422374346462 ∧ code e2422374346462 = 11218467368670 := by decide
theorem cert_e2422374346462 : check e2422374346462 [[],[]] .smaller = true := by decide
def e2422374346466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))))
theorem wire_e2422374346466 : Closed e2422374346466 ∧ code e2422374346466 = 11218467368674 := by decide
theorem cert_e2422374346466 : check e2422374346466 [[],[]] .smaller = true := by decide
def e2422374346478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))))
theorem wire_e2422374346478 : Closed e2422374346478 ∧ code e2422374346478 = 11218467368686 := by decide
theorem cert_e2422374346478 : check e2422374346478 [[],[]] .smaller = true := by decide
def e2422374346486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))))
theorem wire_e2422374346486 : Closed e2422374346486 ∧ code e2422374346486 = 11218467368694 := by decide
theorem cert_e2422374346486 : check e2422374346486 [[],[]] .smaller = true := by decide
def e2422374346490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 0))))))))))
theorem wire_e2422374346490 : Closed e2422374346490 ∧ code e2422374346490 = 11218467368698 := by decide
theorem cert_e2422374346490 : check e2422374346490 [[],[]] .three = true := by decide
def e2422374346518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))))
theorem wire_e2422374346518 : Closed e2422374346518 ∧ code e2422374346518 = 11218467368726 := by decide
theorem cert_e2422374346518 : check e2422374346518 [[],[]] .smaller = true := by decide
def e2422374346590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e2422374346590 : Closed e2422374346590 ∧ code e2422374346590 = 11218467368798 := by decide
theorem cert_e2422374346590 : check e2422374346590 [[],[]] .smaller = true := by decide
def e2422374346594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))))
theorem wire_e2422374346594 : Closed e2422374346594 ∧ code e2422374346594 = 11218467368802 := by decide
theorem cert_e2422374346594 : check e2422374346594 [[],[]] .smaller = true := by decide
end Blc.Floor43
