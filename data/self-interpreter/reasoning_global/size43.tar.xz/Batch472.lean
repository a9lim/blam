import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407068174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407068174 : Closed e2422407068174 ∧ code e2422407068174 = 11218500090382 := by decide
theorem cert_e2422407068174 : check e2422407068174 [[],[]] .chain = true := by decide
def e2422407068186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407068186 : Closed e2422407068186 ∧ code e2422407068186 = 11218500090394 := by decide
theorem cert_e2422407068186 : check e2422407068186 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407068258 : Closed e2422407068258 ∧ code e2422407068258 = 11218500090466 := by decide
theorem cert_e2422407068258 : check e2422407068258 [[],[]] .chain = true := by decide
def e2422407068270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407068270 : Closed e2422407068270 ∧ code e2422407068270 = 11218500090478 := by decide
theorem cert_e2422407068270 : check e2422407068270 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407068278 : Closed e2422407068278 ∧ code e2422407068278 = 11218500090486 := by decide
theorem cert_e2422407068278 : check e2422407068278 [[],[]] .chain = true := by decide
def e2422407068282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407068282 : Closed e2422407068282 ∧ code e2422407068282 = 11218500090490 := by decide
theorem cert_e2422407068282 : check e2422407068282 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407068422 : Closed e2422407068422 ∧ code e2422407068422 = 11218500090630 := by decide
theorem cert_e2422407068422 : check e2422407068422 [[],[]] .chain = true := by decide
def e2422407068446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422407068446 : Closed e2422407068446 ∧ code e2422407068446 = 11218500090654 := by decide
theorem cert_e2422407068446 : check e2422407068446 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407068470 : Closed e2422407068470 ∧ code e2422407068470 = 11218500090678 := by decide
theorem cert_e2422407068470 : check e2422407068470 [[],[]] .chain = true := by decide
def e2422407068474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407068474 : Closed e2422407068474 ∧ code e2422407068474 = 11218500090682 := by decide
theorem cert_e2422407068474 : check e2422407068474 [[],[]] .chain = true := by decide
def e2422407068546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407068546 : Closed e2422407068546 ∧ code e2422407068546 = 11218500090754 := by decide
theorem cert_e2422407068546 : check e2422407068546 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422407068558 : Closed e2422407068558 ∧ code e2422407068558 = 11218500090766 := by decide
theorem cert_e2422407068558 : check e2422407068558 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407068570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407068570 : Closed e2422407068570 ∧ code e2422407068570 = 11218500090778 := by decide
theorem cert_e2422407068570 : check e2422407068570 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407070142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422407070142 : Closed e2422407070142 ∧ code e2422407070142 = 11218500092350 := by decide
theorem cert_e2422407070142 : check e2422407070142 [[],[]] .chain = true := by decide
def e2422407070202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422407070202 : Closed e2422407070202 ∧ code e2422407070202 = 11218500092410 := by decide
theorem cert_e2422407070202 : check e2422407070202 [[],[]] .chain = true := by decide
def e2422407071294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422407071294 : Closed e2422407071294 ∧ code e2422407071294 = 11218500093502 := by decide
theorem cert_e2422407071294 : check e2422407071294 [[],[]] .chain = true := by decide
def e2422407071686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422407071686 : Closed e2422407071686 ∧ code e2422407071686 = 11218500093894 := by decide
theorem cert_e2422407071686 : check e2422407071686 [[],[]] .chain = true := by decide
def e2422407071710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2422407071710 : Closed e2422407071710 ∧ code e2422407071710 = 11218500093918 := by decide
theorem cert_e2422407071710 : check e2422407071710 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407075374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422407075374 : Closed e2422407075374 ∧ code e2422407075374 = 11218500097582 := by decide
theorem cert_e2422407075374 : check e2422407075374 [[],[]] .chain = true := by decide
def e2422407075554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422407075554 : Closed e2422407075554 ∧ code e2422407075554 = 11218500097762 := by decide
theorem cert_e2422407075554 : check e2422407075554 [[],[]] .chain = true := by decide
def e2422407075566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2422407075566 : Closed e2422407075566 ∧ code e2422407075566 = 11218500097774 := by decide
theorem cert_e2422407075566 : check e2422407075566 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407075694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2422407075694 : Closed e2422407075694 ∧ code e2422407075694 = 11218500097902 := by decide
theorem cert_e2422407075694 : check e2422407075694 [[],[]] .chain = true := by decide
def e2422407075702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2422407075702 : Closed e2422407075702 ∧ code e2422407075702 = 11218500097910 := by decide
theorem cert_e2422407075702 : check e2422407075702 [[],[]] .chain = true := by decide
def e2422407075722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407075722 : Closed e2422407075722 ∧ code e2422407075722 = 11218500097930 := by decide
theorem cert_e2422407075722 : check e2422407075722 [[],[]] .chain = true := by decide
def e2422407075746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407075746 : Closed e2422407075746 ∧ code e2422407075746 = 11218500097954 := by decide
theorem cert_e2422407075746 : check e2422407075746 [[],[]] .chain = true := by decide
def e2422407075758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2422407075758 : Closed e2422407075758 ∧ code e2422407075758 = 11218500097966 := by decide
theorem cert_e2422407075758 : check e2422407075758 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407075766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2422407075766 : Closed e2422407075766 ∧ code e2422407075766 = 11218500097974 := by decide
theorem cert_e2422407075766 : check e2422407075766 [[],[]] .chain = true := by decide
def e2422407075770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2422407075770 : Closed e2422407075770 ∧ code e2422407075770 = 11218500097978 := by decide
theorem cert_e2422407075770 : check e2422407075770 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407075902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2422407075902 : Closed e2422407075902 ∧ code e2422407075902 = 11218500098110 := by decide
theorem cert_e2422407075902 : check e2422407075902 [[],[]] .chain = true := by decide
def e2422407076322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422407076322 : Closed e2422407076322 ∧ code e2422407076322 = 11218500098530 := by decide
theorem cert_e2422407076322 : check e2422407076322 [[],[]] .chain = true := by decide
def e2422407076334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2422407076334 : Closed e2422407076334 ∧ code e2422407076334 = 11218500098542 := by decide
theorem cert_e2422407076334 : check e2422407076334 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407077102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407077102 : Closed e2422407077102 ∧ code e2422407077102 = 11218500099310 := by decide
theorem cert_e2422407077102 : check e2422407077102 [[],[]] .chain = true := by decide
def e2422407077110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407077110 : Closed e2422407077110 ∧ code e2422407077110 = 11218500099318 := by decide
theorem cert_e2422407077110 : check e2422407077110 [[],[]] .chain = true := by decide
def e2422407077378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407077378 : Closed e2422407077378 ∧ code e2422407077378 = 11218500099586 := by decide
theorem cert_e2422407077378 : check e2422407077378 [[],[]] .chain = true := by decide
def e2422407077390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407077390 : Closed e2422407077390 ∧ code e2422407077390 = 11218500099598 := by decide
theorem cert_e2422407077390 : check e2422407077390 [[],[]] .chain = true := by decide
def e2422407077402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407077402 : Closed e2422407077402 ∧ code e2422407077402 = 11218500099610 := by decide
theorem cert_e2422407077402 : check e2422407077402 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407077474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407077474 : Closed e2422407077474 ∧ code e2422407077474 = 11218500099682 := by decide
theorem cert_e2422407077474 : check e2422407077474 [[],[]] .chain = true := by decide
def e2422407077486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407077486 : Closed e2422407077486 ∧ code e2422407077486 = 11218500099694 := by decide
theorem cert_e2422407077486 : check e2422407077486 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407077494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407077494 : Closed e2422407077494 ∧ code e2422407077494 = 11218500099702 := by decide
theorem cert_e2422407077494 : check e2422407077494 [[],[]] .chain = true := by decide
def e2422407077498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407077498 : Closed e2422407077498 ∧ code e2422407077498 = 11218500099706 := by decide
theorem cert_e2422407077498 : check e2422407077498 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407086206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e2422407086206 : Closed e2422407086206 ∧ code e2422407086206 = 11218500108414 := by decide
theorem cert_e2422407086206 : check e2422407086206 [[],[]] .chain = true := by decide
def e2422407087070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422407087070 : Closed e2422407087070 ∧ code e2422407087070 = 11218500109278 := by decide
theorem cert_e2422407087070 : check e2422407087070 [[],[]] .chain = true := by decide
def e2422407087074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422407087074 : Closed e2422407087074 ∧ code e2422407087074 = 11218500109282 := by decide
theorem cert_e2422407087074 : check e2422407087074 [[],[]] .chain = true := by decide
def e2422407087086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422407087086 : Closed e2422407087086 ∧ code e2422407087086 = 11218500109294 := by decide
theorem cert_e2422407087086 : check e2422407087086 [[],[]] .chain = true := by decide
def e2422407089006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422407089006 : Closed e2422407089006 ∧ code e2422407089006 = 11218500111214 := by decide
theorem cert_e2422407089006 : check e2422407089006 [[],[]] .chain = true := by decide
def e2422407089014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422407089014 : Closed e2422407089014 ∧ code e2422407089014 = 11218500111222 := by decide
theorem cert_e2422407089014 : check e2422407089014 [[],[]] .chain = true := by decide
def e2422407089070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422407089070 : Closed e2422407089070 ∧ code e2422407089070 = 11218500111278 := by decide
theorem cert_e2422407089070 : check e2422407089070 [[],[]] .chain = true := by decide
def e2422407089082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422407089082 : Closed e2422407089082 ∧ code e2422407089082 = 11218500111290 := by decide
theorem cert_e2422407089082 : check e2422407089082 [[],[]] .chain = true := by decide
def e2422407089110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422407089110 : Closed e2422407089110 ∧ code e2422407089110 = 11218500111318 := by decide
theorem cert_e2422407089110 : check e2422407089110 [[],[]] .chain = true := by decide
def e2422407089114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422407089114 : Closed e2422407089114 ∧ code e2422407089114 = 11218500111322 := by decide
theorem cert_e2422407089114 : check e2422407089114 [[],[]] .chain = true := by decide
def e2422407089390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407089390 : Closed e2422407089390 ∧ code e2422407089390 = 11218500111598 := by decide
theorem cert_e2422407089390 : check e2422407089390 [[],[]] .chain = true := by decide
def e2422407089398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407089398 : Closed e2422407089398 ∧ code e2422407089398 = 11218500111606 := by decide
theorem cert_e2422407089398 : check e2422407089398 [[],[]] .chain = true := by decide
def e2422407089774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407089774 : Closed e2422407089774 ∧ code e2422407089774 = 11218500111982 := by decide
theorem cert_e2422407089774 : check e2422407089774 [[],[]] .chain = true := by decide
def e2422407089786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407089786 : Closed e2422407089786 ∧ code e2422407089786 = 11218500111994 := by decide
theorem cert_e2422407089786 : check e2422407089786 [[],[]] .chain = true := by decide
def e2422407089926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407089926 : Closed e2422407089926 ∧ code e2422407089926 = 11218500112134 := by decide
theorem cert_e2422407089926 : check e2422407089926 [[],[]] .chain = true := by decide
def e2422407089950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e2422407089950 : Closed e2422407089950 ∧ code e2422407089950 = 11218500112158 := by decide
theorem cert_e2422407089950 : check e2422407089950 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407089974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407089974 : Closed e2422407089974 ∧ code e2422407089974 = 11218500112182 := by decide
theorem cert_e2422407089974 : check e2422407089974 [[],[]] .chain = true := by decide
def e2422407089978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407089978 : Closed e2422407089978 ∧ code e2422407089978 = 11218500112186 := by decide
theorem cert_e2422407089978 : check e2422407089978 [[],[]] .chain = true := by decide
def e2422407094298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422407094298 : Closed e2422407094298 ∧ code e2422407094298 = 11218500116506 := by decide
theorem cert_e2422407094298 : check e2422407094298 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407094334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e2422407094334 : Closed e2422407094334 ∧ code e2422407094334 = 11218500116542 := by decide
theorem cert_e2422407094334 : check e2422407094334 [[],[]] .chain = true := by decide
def e2422407094382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422407094382 : Closed e2422407094382 ∧ code e2422407094382 = 11218500116590 := by decide
theorem cert_e2422407094382 : check e2422407094382 [[],[]] .chain = true := by decide
def e2422407094390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422407094390 : Closed e2422407094390 ∧ code e2422407094390 = 11218500116598 := by decide
theorem cert_e2422407094390 : check e2422407094390 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407094394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422407094394 : Closed e2422407094394 ∧ code e2422407094394 = 11218500116602 := by decide
theorem cert_e2422407094394 : check e2422407094394 [[],[]] .chain = true := by decide
def e2422407094634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422407094634 : Closed e2422407094634 ∧ code e2422407094634 = 11218500116842 := by decide
theorem cert_e2422407094634 : check e2422407094634 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407094670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422407094670 : Closed e2422407094670 ∧ code e2422407094670 = 11218500116878 := by decide
theorem cert_e2422407094670 : check e2422407094670 [[],[]] .chain = true := by decide
def e2422407094682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407094682 : Closed e2422407094682 ∧ code e2422407094682 = 11218500116890 := by decide
theorem cert_e2422407094682 : check e2422407094682 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407094726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422407094726 : Closed e2422407094726 ∧ code e2422407094726 = 11218500116934 := by decide
theorem cert_e2422407094726 : check e2422407094726 [[],[]] .chain = true := by decide
def e2422407094750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407094750 : Closed e2422407094750 ∧ code e2422407094750 = 11218500116958 := by decide
theorem cert_e2422407094750 : check e2422407094750 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407094754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422407094754 : Closed e2422407094754 ∧ code e2422407094754 = 11218500116962 := by decide
theorem cert_e2422407094754 : check e2422407094754 [[],[]] .chain = true := by decide
def e2422407094766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e2422407094766 : Closed e2422407094766 ∧ code e2422407094766 = 11218500116974 := by decide
theorem cert_e2422407094766 : check e2422407094766 [[],[]] .chain = true := by decide
def e2422407094774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407094774 : Closed e2422407094774 ∧ code e2422407094774 = 11218500116982 := by decide
theorem cert_e2422407094774 : check e2422407094774 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407095690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407095690 : Closed e2422407095690 ∧ code e2422407095690 = 11218500117898 := by decide
theorem cert_e2422407095690 : check e2422407095690 [[],[]] .chain = true := by decide
def e2422407095714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407095714 : Closed e2422407095714 ∧ code e2422407095714 = 11218500117922 := by decide
theorem cert_e2422407095714 : check e2422407095714 [[],[]] .chain = true := by decide
def e2422407095726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407095726 : Closed e2422407095726 ∧ code e2422407095726 = 11218500117934 := by decide
theorem cert_e2422407095726 : check e2422407095726 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407095734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2422407095734 : Closed e2422407095734 ∧ code e2422407095734 = 11218500117942 := by decide
theorem cert_e2422407095734 : check e2422407095734 [[],[]] .chain = true := by decide
def e2422407095738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407095738 : Closed e2422407095738 ∧ code e2422407095738 = 11218500117946 := by decide
theorem cert_e2422407095738 : check e2422407095738 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407095766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2422407095766 : Closed e2422407095766 ∧ code e2422407095766 = 11218500117974 := by decide
theorem cert_e2422407095766 : check e2422407095766 [[],[]] .chain = true := by decide
def e2422407095770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2422407095770 : Closed e2422407095770 ∧ code e2422407095770 = 11218500117978 := by decide
theorem cert_e2422407095770 : check e2422407095770 [[],[]] .chain = true := by decide
def e2422407095786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407095786 : Closed e2422407095786 ∧ code e2422407095786 = 11218500117994 := by decide
theorem cert_e2422407095786 : check e2422407095786 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407095810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407095810 : Closed e2422407095810 ∧ code e2422407095810 = 11218500118018 := by decide
theorem cert_e2422407095810 : check e2422407095810 [[],[]] .chain = true := by decide
def e2422407095822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407095822 : Closed e2422407095822 ∧ code e2422407095822 = 11218500118030 := by decide
theorem cert_e2422407095822 : check e2422407095822 [[],[]] .chain = true := by decide
def e2422407095834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407095834 : Closed e2422407095834 ∧ code e2422407095834 = 11218500118042 := by decide
theorem cert_e2422407095834 : check e2422407095834 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407095906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407095906 : Closed e2422407095906 ∧ code e2422407095906 = 11218500118114 := by decide
theorem cert_e2422407095906 : check e2422407095906 [[],[]] .chain = true := by decide
def e2422407095918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407095918 : Closed e2422407095918 ∧ code e2422407095918 = 11218500118126 := by decide
theorem cert_e2422407095918 : check e2422407095918 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407095926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407095926 : Closed e2422407095926 ∧ code e2422407095926 = 11218500118134 := by decide
theorem cert_e2422407095926 : check e2422407095926 [[],[]] .chain = true := by decide
def e2422407095930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407095930 : Closed e2422407095930 ∧ code e2422407095930 = 11218500118138 := by decide
theorem cert_e2422407095930 : check e2422407095930 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407096070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407096070 : Closed e2422407096070 ∧ code e2422407096070 = 11218500118278 := by decide
theorem cert_e2422407096070 : check e2422407096070 [[],[]] .chain = true := by decide
def e2422407096094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407096094 : Closed e2422407096094 ∧ code e2422407096094 = 11218500118302 := by decide
theorem cert_e2422407096094 : check e2422407096094 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407096118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407096118 : Closed e2422407096118 ∧ code e2422407096118 = 11218500118326 := by decide
theorem cert_e2422407096118 : check e2422407096118 [[],[]] .chain = true := by decide
def e2422407096122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407096122 : Closed e2422407096122 ∧ code e2422407096122 = 11218500118330 := by decide
theorem cert_e2422407096122 : check e2422407096122 [[],[]] .chain = true := by decide
def e2422407096194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407096194 : Closed e2422407096194 ∧ code e2422407096194 = 11218500118402 := by decide
theorem cert_e2422407096194 : check e2422407096194 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407096206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407096206 : Closed e2422407096206 ∧ code e2422407096206 = 11218500118414 := by decide
theorem cert_e2422407096206 : check e2422407096206 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407096218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407096218 : Closed e2422407096218 ∧ code e2422407096218 = 11218500118426 := by decide
theorem cert_e2422407096218 : check e2422407096218 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407102678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e2422407102678 : Closed e2422407102678 ∧ code e2422407102678 = 11218500124886 := by decide
theorem cert_e2422407102678 : check e2422407102678 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407102774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407102774 : Closed e2422407102774 ∧ code e2422407102774 = 11218500124982 := by decide
theorem cert_e2422407102774 : check e2422407102774 [[],[]] .chain = true := by decide
def e2422407102778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407102778 : Closed e2422407102778 ∧ code e2422407102778 = 11218500124986 := by decide
theorem cert_e2422407102778 : check e2422407102778 [[],[]] .chain = true := by decide
def e2422407102966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e2422407102966 : Closed e2422407102966 ∧ code e2422407102966 = 11218500125174 := by decide
theorem cert_e2422407102966 : check e2422407102966 [[],[]] .chain = true := by decide
def e2422407103350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e2422407103350 : Closed e2422407103350 ∧ code e2422407103350 = 11218500125558 := by decide
theorem cert_e2422407103350 : check e2422407103350 [[],[]] .chain = true := by decide
def e2422407103354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e2422407103354 : Closed e2422407103354 ∧ code e2422407103354 = 11218500125562 := by decide
theorem cert_e2422407103354 : check e2422407103354 [[],[]] .chain = true := by decide
def e2422407103414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e2422407103414 : Closed e2422407103414 ∧ code e2422407103414 = 11218500125622 := by decide
theorem cert_e2422407103414 : check e2422407103414 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407103446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e2422407103446 : Closed e2422407103446 ∧ code e2422407103446 = 11218500125654 := by decide
theorem cert_e2422407103446 : check e2422407103446 [[],[]] .chain = true := by decide
def e2422407103466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e2422407103466 : Closed e2422407103466 ∧ code e2422407103466 = 11218500125674 := by decide
theorem cert_e2422407103466 : check e2422407103466 [[],[]] .chain = true := by decide
def e2422407103726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407103726 : Closed e2422407103726 ∧ code e2422407103726 = 11218500125934 := by decide
theorem cert_e2422407103726 : check e2422407103726 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407103734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407103734 : Closed e2422407103734 ∧ code e2422407103734 = 11218500125942 := by decide
theorem cert_e2422407103734 : check e2422407103734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422407104118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407104118 : Closed e2422407104118 ∧ code e2422407104118 = 11218500126326 := by decide
theorem cert_e2422407104118 : check e2422407104118 [[],[]] .chain = true := by decide
def e2422407104310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407104310 : Closed e2422407104310 ∧ code e2422407104310 = 11218500126518 := by decide
theorem cert_e2422407104310 : check e2422407104310 [[],[]] .chain = true := by decide
def e2422407104314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407104314 : Closed e2422407104314 ∧ code e2422407104314 = 11218500126522 := by decide
theorem cert_e2422407104314 : check e2422407104314 [[],[]] .chain = true := by decide
def e2422407104398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2422407104398 : Closed e2422407104398 ∧ code e2422407104398 = 11218500126606 := by decide
theorem cert_e2422407104398 : check e2422407104398 [[],[]] .chain = true := by decide
def e2422407104410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407104410 : Closed e2422407104410 ∧ code e2422407104410 = 11218500126618 := by decide
theorem cert_e2422407104410 : check e2422407104410 [[],[]] .chain = true := by decide
def e2422407105366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e2422407105366 : Closed e2422407105366 ∧ code e2422407105366 = 11218500127574 := by decide
theorem cert_e2422407105366 : checkPay e2422407105366 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422407105654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422407105654 : Closed e2422407105654 ∧ code e2422407105654 = 11218500127862 := by decide
theorem cert_e2422407105654 : check e2422407105654 [[],[]] .chain = true := by decide
def e2422407105658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.lam (.var 3))))) (.var 0))))))
theorem wire_e2422407105658 : Closed e2422407105658 ∧ code e2422407105658 = 11218500127866 := by decide
theorem cert_e2422407105658 : check e2422407105658 [[],[]] .chain = true := by decide
def e2422407105750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2422407105750 : Closed e2422407105750 ∧ code e2422407105750 = 11218500127958 := by decide
theorem cert_e2422407105750 : check e2422407105750 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407105846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407105846 : Closed e2422407105846 ∧ code e2422407105846 = 11218500128054 := by decide
theorem cert_e2422407105846 : check e2422407105846 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407105850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407105850 : Closed e2422407105850 ∧ code e2422407105850 = 11218500128058 := by decide
theorem cert_e2422407105850 : check e2422407105850 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2422407105934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422407105934 : Closed e2422407105934 ∧ code e2422407105934 = 11218500128142 := by decide
theorem cert_e2422407105934 : check e2422407105934 [[],[]] .chain = true := by decide
def e2422407105990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2422407105990 : Closed e2422407105990 ∧ code e2422407105990 = 11218500128198 := by decide
theorem cert_e2422407105990 : check e2422407105990 [[],[]] .chain = true := by decide
def e2422407106102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407106102 : Closed e2422407106102 ∧ code e2422407106102 = 11218500128310 := by decide
theorem cert_e2422407106102 : check e2422407106102 [[],[]] .chain = true := by decide
def e2422407106190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407106190 : Closed e2422407106190 ∧ code e2422407106190 = 11218500128398 := by decide
theorem cert_e2422407106190 : check e2422407106190 [[],[]] .chain = true := by decide
def e2422407106274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407106274 : Closed e2422407106274 ∧ code e2422407106274 = 11218500128482 := by decide
theorem cert_e2422407106274 : check e2422407106274 [[],[]] .chain = true := by decide
def e2422407106286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2422407106286 : Closed e2422407106286 ∧ code e2422407106286 = 11218500128494 := by decide
theorem cert_e2422407106286 : check e2422407106286 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407106294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2422407106294 : Closed e2422407106294 ∧ code e2422407106294 = 11218500128502 := by decide
def e2422407106326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407106326 : Closed e2422407106326 ∧ code e2422407106326 = 11218500128534 := by decide
theorem cert_e2422407106326 : check e2422407106326 [[],[]] .chain = true := by decide
def e2422407106330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407106330 : Closed e2422407106330 ∧ code e2422407106330 = 11218500128538 := by decide
theorem cert_e2422407106330 : check e2422407106330 [[],[]] .chain = true := by decide
def e2422407106374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407106374 : Closed e2422407106374 ∧ code e2422407106374 = 11218500128582 := by decide
theorem cert_e2422407106374 : check e2422407106374 [[],[]] .chain = true := by decide
def e2422407106402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407106402 : Closed e2422407106402 ∧ code e2422407106402 = 11218500128610 := by decide
theorem cert_e2422407106402 : check e2422407106402 [[],[]] .chain = true := by decide
def e2422407106414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2422407106414 : Closed e2422407106414 ∧ code e2422407106414 = 11218500128622 := by decide
theorem cert_e2422407106414 : check e2422407106414 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407106422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e2422407106422 : Closed e2422407106422 ∧ code e2422407106422 = 11218500128630 := by decide
theorem cert_e2422407106422 : check e2422407106422 [[],[]] .chain = true := by decide
def e2422407106426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2422407106426 : Closed e2422407106426 ∧ code e2422407106426 = 11218500128634 := by decide
theorem cert_e2422407106426 : check e2422407106426 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407106486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2422407106486 : Closed e2422407106486 ∧ code e2422407106486 = 11218500128694 := by decide
theorem cert_e2422407106486 : check e2422407106486 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422407106490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2422407106490 : Closed e2422407106490 ∧ code e2422407106490 = 11218500128698 := by decide
def e2422407106798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407106798 : Closed e2422407106798 ∧ code e2422407106798 = 11218500129006 := by decide
theorem cert_e2422407106798 : check e2422407106798 [[],[]] .chain = true := by decide
def e2422407106806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407106806 : Closed e2422407106806 ∧ code e2422407106806 = 11218500129014 := by decide
theorem cert_e2422407106806 : check e2422407106806 [[],[]] .chain = true := by decide
def e2422407107286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407107286 : Closed e2422407107286 ∧ code e2422407107286 = 11218500129494 := by decide
theorem cert_e2422407107286 : check e2422407107286 [[],[]] .chain = true := by decide
def e2422407107290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407107290 : Closed e2422407107290 ∧ code e2422407107290 = 11218500129498 := by decide
theorem cert_e2422407107290 : check e2422407107290 [[],[]] .chain = true := by decide
def e2422407107306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407107306 : Closed e2422407107306 ∧ code e2422407107306 = 11218500129514 := by decide
theorem cert_e2422407107306 : check e2422407107306 [[],[]] .chain = true := by decide
def e2422407107382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407107382 : Closed e2422407107382 ∧ code e2422407107382 = 11218500129590 := by decide
theorem cert_e2422407107382 : check e2422407107382 [[],[]] .chain = true := by decide
def e2422407107386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407107386 : Closed e2422407107386 ∧ code e2422407107386 = 11218500129594 := by decide
theorem cert_e2422407107386 : check e2422407107386 [[],[]] .chain = true := by decide
def e2422407107470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422407107470 : Closed e2422407107470 ∧ code e2422407107470 = 11218500129678 := by decide
theorem cert_e2422407107470 : check e2422407107470 [[],[]] .chain = true := by decide
def e2422407107482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407107482 : Closed e2422407107482 ∧ code e2422407107482 = 11218500129690 := by decide
theorem cert_e2422407107482 : check e2422407107482 [[],[]] .chain = true := by decide
def e2422407108718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2422407108718 : Closed e2422407108718 ∧ code e2422407108718 = 11218500130926 := by decide
theorem cert_e2422407108718 : check e2422407108718 [[],[]] .chain = true := by decide
def e2422407108730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2422407108730 : Closed e2422407108730 ∧ code e2422407108730 = 11218500130938 := by decide
theorem cert_e2422407108730 : check e2422407108730 [[],[]] .chain = true := by decide
def e2422407109006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407109006 : Closed e2422407109006 ∧ code e2422407109006 = 11218500131214 := by decide
theorem cert_e2422407109006 : check e2422407109006 [[],[]] .chain = true := by decide
def e2422407109062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407109062 : Closed e2422407109062 ∧ code e2422407109062 = 11218500131270 := by decide
theorem cert_e2422407109062 : check e2422407109062 [[],[]] .chain = true := by decide
def e2422407109662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407109662 : Closed e2422407109662 ∧ code e2422407109662 = 11218500131870 := by decide
theorem cert_e2422407109662 : check e2422407109662 [[],[]] .chain = true := by decide
def e2422407109686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407109686 : Closed e2422407109686 ∧ code e2422407109686 = 11218500131894 := by decide
theorem cert_e2422407109686 : check e2422407109686 [[],[]] .chain = true := by decide
def e2422407109690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407109690 : Closed e2422407109690 ∧ code e2422407109690 = 11218500131898 := by decide
theorem cert_e2422407109690 : check e2422407109690 [[],[]] .chain = true := by decide
def e2422407109830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407109830 : Closed e2422407109830 ∧ code e2422407109830 = 11218500132038 := by decide
theorem cert_e2422407109830 : check e2422407109830 [[],[]] .chain = true := by decide
def e2422407109858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407109858 : Closed e2422407109858 ∧ code e2422407109858 = 11218500132066 := by decide
theorem cert_e2422407109858 : check e2422407109858 [[],[]] .chain = true := by decide
def e2422407109870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407109870 : Closed e2422407109870 ∧ code e2422407109870 = 11218500132078 := by decide
theorem cert_e2422407109870 : check e2422407109870 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407109878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407109878 : Closed e2422407109878 ∧ code e2422407109878 = 11218500132086 := by decide
theorem cert_e2422407109878 : check e2422407109878 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407110262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407110262 : Closed e2422407110262 ∧ code e2422407110262 = 11218500132470 := by decide
theorem cert_e2422407110262 : check e2422407110262 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407113814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2422407113814 : Closed e2422407113814 ∧ code e2422407113814 = 11218500136022 := by decide
theorem cert_e2422407113814 : check e2422407113814 [[],[]] .chain = true := by decide
def e2422407113818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2422407113818 : Closed e2422407113818 ∧ code e2422407113818 = 11218500136026 := by decide
theorem cert_e2422407113818 : check e2422407113818 [[],[]] .chain = true := by decide
def e2422407114006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422407114006 : Closed e2422407114006 ∧ code e2422407114006 = 11218500136214 := by decide
theorem cert_e2422407114006 : check e2422407114006 [[],[]] .chain = true := by decide
def e2422407114082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407114082 : Closed e2422407114082 ∧ code e2422407114082 = 11218500136290 := by decide
theorem cert_e2422407114082 : check e2422407114082 [[],[]] .chain = true := by decide
def e2422407114094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422407114094 : Closed e2422407114094 ∧ code e2422407114094 = 11218500136302 := by decide
theorem cert_e2422407114094 : check e2422407114094 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422407114102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422407114102 : Closed e2422407114102 ∧ code e2422407114102 = 11218500136310 := by decide
theorem cert_e2422407114102 : checkPay e2422407114102 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422407114122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407114122 : Closed e2422407114122 ∧ code e2422407114122 = 11218500136330 := by decide
theorem cert_e2422407114122 : check e2422407114122 [[],[]] .chain = true := by decide
def e2422407114146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407114146 : Closed e2422407114146 ∧ code e2422407114146 = 11218500136354 := by decide
theorem cert_e2422407114146 : check e2422407114146 [[],[]] .chain = true := by decide
end Blc.Floor43
