import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411625609114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625609114 : Closed e2411625609114 ∧ code e2411625609114 = 11207718631322 := by decide
theorem cert_e2411625609114 : check e2411625609114 [[],[]] .three = true := by decide
def e2411625609438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2411625609438 : Closed e2411625609438 ∧ code e2411625609438 = 11207718631646 := by decide
theorem cert_e2411625609438 : check e2411625609438 [[],[]] .three = true := by decide
def e2411625609454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2411625609454 : Closed e2411625609454 ∧ code e2411625609454 = 11207718631662 := by decide
theorem cert_e2411625609454 : check e2411625609454 [[],[]] .smaller = true := by decide
def e2411625609462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2411625609462 : Closed e2411625609462 ∧ code e2411625609462 = 11207718631670 := by decide
theorem cert_e2411625609462 : check e2411625609462 [[],[]] .smaller = true := by decide
def e2411625609466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2411625609466 : Closed e2411625609466 ∧ code e2411625609466 = 11207718631674 := by decide
theorem cert_e2411625609466 : check e2411625609466 [[],[]] .three = true := by decide
def e2411625609654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2411625609654 : Closed e2411625609654 ∧ code e2411625609654 = 11207718631862 := by decide
theorem cert_e2411625609654 : check e2411625609654 [[],[]] .smaller = true := by decide
def e2411625609686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2411625609686 : Closed e2411625609686 ∧ code e2411625609686 = 11207718631894 := by decide
theorem cert_e2411625609686 : check e2411625609686 [[],[]] .smaller = true := by decide
def e2411625609690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e2411625609690 : Closed e2411625609690 ∧ code e2411625609690 = 11207718631898 := by decide
theorem cert_e2411625609690 : check e2411625609690 [[],[]] .smaller = true := by decide
def e2411625609790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2411625609790 : Closed e2411625609790 ∧ code e2411625609790 = 11207718631998 := by decide
theorem cert_e2411625609790 : check e2411625609790 [[],[]] .three = true := by decide
def e2411625609846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e2411625609846 : Closed e2411625609846 ∧ code e2411625609846 = 11207718632054 := by decide
theorem cert_e2411625609846 : check e2411625609846 [[],[]] .smaller = true := by decide
def e2411625610014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2411625610014 : Closed e2411625610014 ∧ code e2411625610014 = 11207718632222 := by decide
theorem cert_e2411625610014 : check e2411625610014 [[],[]] .smaller = true := by decide
def e2411625610038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625610038 : Closed e2411625610038 ∧ code e2411625610038 = 11207718632246 := by decide
theorem cert_e2411625610038 : check e2411625610038 [[],[]] .smaller = true := by decide
def e2411625610042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625610042 : Closed e2411625610042 ∧ code e2411625610042 = 11207718632250 := by decide
theorem cert_e2411625610042 : check e2411625610042 [[],[]] .smaller = true := by decide
def e2411625610126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2411625610126 : Closed e2411625610126 ∧ code e2411625610126 = 11207718632334 := by decide
theorem cert_e2411625610126 : check e2411625610126 [[],[]] .smaller = true := by decide
def e2411625610182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2411625610182 : Closed e2411625610182 ∧ code e2411625610182 = 11207718632390 := by decide
theorem cert_e2411625610182 : check e2411625610182 [[],[]] .three = true := by decide
def e2411625610206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 3)))))))
theorem wire_e2411625610206 : Closed e2411625610206 ∧ code e2411625610206 = 11207718632414 := by decide
theorem cert_e2411625610206 : check e2411625610206 [[],[]] .three = true := by decide
def e2411625610350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411625610350 : Closed e2411625610350 ∧ code e2411625610350 = 11207718632558 := by decide
theorem cert_e2411625610350 : check e2411625610350 [[],[]] .three = true := by decide
def e2411625610358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2411625610358 : Closed e2411625610358 ∧ code e2411625610358 = 11207718632566 := by decide
theorem cert_e2411625610358 : check e2411625610358 [[],[]] .three = true := by decide
def e2411625610362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411625610362 : Closed e2411625610362 ∧ code e2411625610362 = 11207718632570 := by decide
theorem cert_e2411625610362 : check e2411625610362 [[],[]] .three = true := by decide
def e2411625610454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2411625610454 : Closed e2411625610454 ∧ code e2411625610454 = 11207718632662 := by decide
theorem cert_e2411625610454 : check e2411625610454 [[],[]] .three = true := by decide
def e2411625610458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2411625610458 : Closed e2411625610458 ∧ code e2411625610458 = 11207718632666 := by decide
theorem cert_e2411625610458 : check e2411625610458 [[],[]] .three = true := by decide
def e2411625610474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2411625610474 : Closed e2411625610474 ∧ code e2411625610474 = 11207718632682 := by decide
theorem cert_e2411625610474 : check e2411625610474 [[],[]] .three = true := by decide
def e2411625610526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411625610526 : Closed e2411625610526 ∧ code e2411625610526 = 11207718632734 := by decide
theorem cert_e2411625610526 : check e2411625610526 [[],[]] .three = true := by decide
def e2411625610550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625610550 : Closed e2411625610550 ∧ code e2411625610550 = 11207718632758 := by decide
theorem cert_e2411625610550 : check e2411625610550 [[],[]] .three = true := by decide
def e2411625610554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625610554 : Closed e2411625610554 ∧ code e2411625610554 = 11207718632762 := by decide
theorem cert_e2411625610554 : check e2411625610554 [[],[]] .three = true := by decide
def e2411625610638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2411625610638 : Closed e2411625610638 ∧ code e2411625610638 = 11207718632846 := by decide
theorem cert_e2411625610638 : check e2411625610638 [[],[]] .three = true := by decide
def e2411625610650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625610650 : Closed e2411625610650 ∧ code e2411625610650 = 11207718632858 := by decide
theorem cert_e2411625610650 : check e2411625610650 [[],[]] .three = true := by decide
def e2411625610694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411625610694 : Closed e2411625610694 ∧ code e2411625610694 = 11207718632902 := by decide
theorem cert_e2411625610694 : check e2411625610694 [[],[]] .three = true := by decide
def e2411625610718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 3)))))))
theorem wire_e2411625610718 : Closed e2411625610718 ∧ code e2411625610718 = 11207718632926 := by decide
theorem cert_e2411625610718 : check e2411625610718 [[],[]] .three = true := by decide
def e2411625610734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 2)))))))
theorem wire_e2411625610734 : Closed e2411625610734 ∧ code e2411625610734 = 11207718632942 := by decide
theorem cert_e2411625610734 : check e2411625610734 [[],[]] .three = true := by decide
def e2411625613246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e2411625613246 : Closed e2411625613246 ∧ code e2411625613246 = 11207718635454 := by decide
theorem cert_e2411625613246 : check e2411625613246 [[],[]] .three = true := by decide
def e2411625613294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e2411625613294 : Closed e2411625613294 ∧ code e2411625613294 = 11207718635502 := by decide
theorem cert_e2411625613294 : check e2411625613294 [[],[]] .three = true := by decide
def e2411625617118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2411625617118 : Closed e2411625617118 ∧ code e2411625617118 = 11207718639326 := by decide
theorem cert_e2411625617118 : check e2411625617118 [[],[]] .three = true := by decide
def e2411625617142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2411625617142 : Closed e2411625617142 ∧ code e2411625617142 = 11207718639350 := by decide
theorem cert_e2411625617142 : check e2411625617142 [[],[]] .three = true := by decide
def e2411625617246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2411625617246 : Closed e2411625617246 ∧ code e2411625617246 = 11207718639454 := by decide
theorem cert_e2411625617246 : check e2411625617246 [[],[]] .three = true := by decide
def e2411625617262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2411625617262 : Closed e2411625617262 ∧ code e2411625617262 = 11207718639470 := by decide
theorem cert_e2411625617262 : check e2411625617262 [[],[]] .smaller = true := by decide
def e2411625617270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2411625617270 : Closed e2411625617270 ∧ code e2411625617270 = 11207718639478 := by decide
theorem cert_e2411625617270 : check e2411625617270 [[],[]] .smaller = true := by decide
def e2411625617274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2411625617274 : Closed e2411625617274 ∧ code e2411625617274 = 11207718639482 := by decide
theorem cert_e2411625617274 : check e2411625617274 [[],[]] .three = true := by decide
def e2411625617334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2411625617334 : Closed e2411625617334 ∧ code e2411625617334 = 11207718639542 := by decide
theorem cert_e2411625617334 : check e2411625617334 [[],[]] .smaller = true := by decide
def e2411625617366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2411625617366 : Closed e2411625617366 ∧ code e2411625617366 = 11207718639574 := by decide
theorem cert_e2411625617366 : check e2411625617366 [[],[]] .three = true := by decide
def e2411625617370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2411625617370 : Closed e2411625617370 ∧ code e2411625617370 = 11207718639578 := by decide
theorem cert_e2411625617370 : check e2411625617370 [[],[]] .three = true := by decide
def e2411625617886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411625617886 : Closed e2411625617886 ∧ code e2411625617886 = 11207718640094 := by decide
theorem cert_e2411625617886 : check e2411625617886 [[],[]] .three = true := by decide
def e2411625617910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411625617910 : Closed e2411625617910 ∧ code e2411625617910 = 11207718640118 := by decide
theorem cert_e2411625617910 : check e2411625617910 [[],[]] .three = true := by decide
def e2411625618654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411625618654 : Closed e2411625618654 ∧ code e2411625618654 = 11207718640862 := by decide
theorem cert_e2411625618654 : check e2411625618654 [[],[]] .three = true := by decide
def e2411625618670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411625618670 : Closed e2411625618670 ∧ code e2411625618670 = 11207718640878 := by decide
theorem cert_e2411625618670 : check e2411625618670 [[],[]] .smaller = true := by decide
def e2411625618678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411625618678 : Closed e2411625618678 ∧ code e2411625618678 = 11207718640886 := by decide
theorem cert_e2411625618678 : check e2411625618678 [[],[]] .smaller = true := by decide
def e2411625618682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411625618682 : Closed e2411625618682 ∧ code e2411625618682 = 11207718640890 := by decide
theorem cert_e2411625618682 : check e2411625618682 [[],[]] .three = true := by decide
def e2411625619006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e2411625619006 : Closed e2411625619006 ∧ code e2411625619006 = 11207718641214 := by decide
theorem cert_e2411625619006 : check e2411625619006 [[],[]] .three = true := by decide
def e2411625619062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411625619062 : Closed e2411625619062 ∧ code e2411625619062 = 11207718641270 := by decide
theorem cert_e2411625619062 : check e2411625619062 [[],[]] .smaller = true := by decide
def e2411625619230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e2411625619230 : Closed e2411625619230 ∧ code e2411625619230 = 11207718641438 := by decide
theorem cert_e2411625619230 : check e2411625619230 [[],[]] .three = true := by decide
def e2411625619254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625619254 : Closed e2411625619254 ∧ code e2411625619254 = 11207718641462 := by decide
theorem cert_e2411625619254 : check e2411625619254 [[],[]] .three = true := by decide
def e2411625619258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625619258 : Closed e2411625619258 ∧ code e2411625619258 = 11207718641466 := by decide
theorem cert_e2411625619258 : check e2411625619258 [[],[]] .three = true := by decide
def e2411625628606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e2411625628606 : Closed e2411625628606 ∧ code e2411625628606 = 11207718650814 := by decide
theorem cert_e2411625628606 : check e2411625628606 [[],[]] .three = true := by decide
def e2411625628638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2411625628638 : Closed e2411625628638 ∧ code e2411625628638 = 11207718650846 := by decide
theorem cert_e2411625628638 : check e2411625628638 [[],[]] .smaller = true := by decide
def e2411625628654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2411625628654 : Closed e2411625628654 ∧ code e2411625628654 = 11207718650862 := by decide
theorem cert_e2411625628654 : check e2411625628654 [[],[]] .smaller = true := by decide
def e2411625628662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e2411625628662 : Closed e2411625628662 ∧ code e2411625628662 = 11207718650870 := by decide
theorem cert_e2411625628662 : check e2411625628662 [[],[]] .three = true := by decide
def e2411625630558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2411625630558 : Closed e2411625630558 ∧ code e2411625630558 = 11207718652766 := by decide
theorem cert_e2411625630558 : check e2411625630558 [[],[]] .three = true := by decide
def e2411625630574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2411625630574 : Closed e2411625630574 ∧ code e2411625630574 = 11207718652782 := by decide
theorem cert_e2411625630574 : check e2411625630574 [[],[]] .smaller = true := by decide
def e2411625630582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2411625630582 : Closed e2411625630582 ∧ code e2411625630582 = 11207718652790 := by decide
theorem cert_e2411625630582 : check e2411625630582 [[],[]] .smaller = true := by decide
def e2411625630586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2411625630586 : Closed e2411625630586 ∧ code e2411625630586 = 11207718652794 := by decide
theorem cert_e2411625630586 : check e2411625630586 [[],[]] .three = true := by decide
def e2411625630638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2411625630638 : Closed e2411625630638 ∧ code e2411625630638 = 11207718652846 := by decide
theorem cert_e2411625630638 : check e2411625630638 [[],[]] .smaller = true := by decide
def e2411625630650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2411625630650 : Closed e2411625630650 ∧ code e2411625630650 = 11207718652858 := by decide
theorem cert_e2411625630650 : check e2411625630650 [[],[]] .smaller = true := by decide
def e2411625630678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2411625630678 : Closed e2411625630678 ∧ code e2411625630678 = 11207718652886 := by decide
theorem cert_e2411625630678 : check e2411625630678 [[],[]] .smaller = true := by decide
def e2411625630682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2411625630682 : Closed e2411625630682 ∧ code e2411625630682 = 11207718652890 := by decide
theorem cert_e2411625630682 : check e2411625630682 [[],[]] .smaller = true := by decide
def e2411625630698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2411625630698 : Closed e2411625630698 ∧ code e2411625630698 = 11207718652906 := by decide
theorem cert_e2411625630698 : check e2411625630698 [[],[]] .three = true := by decide
def e2411625630942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411625630942 : Closed e2411625630942 ∧ code e2411625630942 = 11207718653150 := by decide
theorem cert_e2411625630942 : check e2411625630942 [[],[]] .three = true := by decide
def e2411625630958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411625630958 : Closed e2411625630958 ∧ code e2411625630958 = 11207718653166 := by decide
theorem cert_e2411625630958 : check e2411625630958 [[],[]] .smaller = true := by decide
def e2411625630966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411625630966 : Closed e2411625630966 ∧ code e2411625630966 = 11207718653174 := by decide
theorem cert_e2411625630966 : check e2411625630966 [[],[]] .smaller = true := by decide
def e2411625630970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411625630970 : Closed e2411625630970 ∧ code e2411625630970 = 11207718653178 := by decide
theorem cert_e2411625630970 : check e2411625630970 [[],[]] .three = true := by decide
def e2411625631294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2411625631294 : Closed e2411625631294 ∧ code e2411625631294 = 11207718653502 := by decide
theorem cert_e2411625631294 : check e2411625631294 [[],[]] .three = true := by decide
def e2411625631342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411625631342 : Closed e2411625631342 ∧ code e2411625631342 = 11207718653550 := by decide
theorem cert_e2411625631342 : check e2411625631342 [[],[]] .smaller = true := by decide
def e2411625631354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411625631354 : Closed e2411625631354 ∧ code e2411625631354 = 11207718653562 := by decide
theorem cert_e2411625631354 : check e2411625631354 [[],[]] .smaller = true := by decide
def e2411625631518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e2411625631518 : Closed e2411625631518 ∧ code e2411625631518 = 11207718653726 := by decide
theorem cert_e2411625631518 : check e2411625631518 [[],[]] .smaller = true := by decide
def e2411625631542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625631542 : Closed e2411625631542 ∧ code e2411625631542 = 11207718653750 := by decide
theorem cert_e2411625631542 : check e2411625631542 [[],[]] .smaller = true := by decide
def e2411625631546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625631546 : Closed e2411625631546 ∧ code e2411625631546 = 11207718653754 := by decide
theorem cert_e2411625631546 : check e2411625631546 [[],[]] .smaller = true := by decide
def e2411625631630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2411625631630 : Closed e2411625631630 ∧ code e2411625631630 = 11207718653838 := by decide
theorem cert_e2411625631630 : check e2411625631630 [[],[]] .three = true := by decide
def e2411625631642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625631642 : Closed e2411625631642 ∧ code e2411625631642 = 11207718653850 := by decide
theorem cert_e2411625631642 : check e2411625631642 [[],[]] .three = true := by decide
def e2411625636334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e2411625636334 : Closed e2411625636334 ∧ code e2411625636334 = 11207718658542 := by decide
theorem cert_e2411625636334 : check e2411625636334 [[],[]] .smaller = true := by decide
def e2411625637302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2411625637302 : Closed e2411625637302 ∧ code e2411625637302 = 11207718659510 := by decide
theorem cert_e2411625637302 : check e2411625637302 [[],[]] .smaller = true := by decide
def e2411625637334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2411625637334 : Closed e2411625637334 ∧ code e2411625637334 = 11207718659542 := by decide
theorem cert_e2411625637334 : check e2411625637334 [[],[]] .smaller = true := by decide
def e2411625637338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2411625637338 : Closed e2411625637338 ∧ code e2411625637338 = 11207718659546 := by decide
theorem cert_e2411625637338 : check e2411625637338 [[],[]] .smaller = true := by decide
def e2411625637438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2411625637438 : Closed e2411625637438 ∧ code e2411625637438 = 11207718659646 := by decide
theorem cert_e2411625637438 : check e2411625637438 [[],[]] .three = true := by decide
def e2411625637494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411625637494 : Closed e2411625637494 ∧ code e2411625637494 = 11207718659702 := by decide
theorem cert_e2411625637494 : check e2411625637494 [[],[]] .smaller = true := by decide
def e2411625637662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411625637662 : Closed e2411625637662 ∧ code e2411625637662 = 11207718659870 := by decide
theorem cert_e2411625637662 : check e2411625637662 [[],[]] .smaller = true := by decide
def e2411625637686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625637686 : Closed e2411625637686 ∧ code e2411625637686 = 11207718659894 := by decide
theorem cert_e2411625637686 : check e2411625637686 [[],[]] .smaller = true := by decide
def e2411625637690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625637690 : Closed e2411625637690 ∧ code e2411625637690 = 11207718659898 := by decide
theorem cert_e2411625637690 : check e2411625637690 [[],[]] .smaller = true := by decide
def e2411625637774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411625637774 : Closed e2411625637774 ∧ code e2411625637774 = 11207718659982 := by decide
theorem cert_e2411625637774 : check e2411625637774 [[],[]] .smaller = true := by decide
def e2411625637830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2411625637830 : Closed e2411625637830 ∧ code e2411625637830 = 11207718660038 := by decide
theorem cert_e2411625637830 : check e2411625637830 [[],[]] .three = true := by decide
def e2411625637854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 3))))))))
theorem wire_e2411625637854 : Closed e2411625637854 ∧ code e2411625637854 = 11207718660062 := by decide
theorem cert_e2411625637854 : check e2411625637854 [[],[]] .three = true := by decide
def e2411625640174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2411625640174 : Closed e2411625640174 ∧ code e2411625640174 = 11207718662382 := by decide
theorem cert_e2411625640174 : check e2411625640174 [[],[]] .three = true := by decide
def e2411625640182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2411625640182 : Closed e2411625640182 ∧ code e2411625640182 = 11207718662390 := by decide
theorem cert_e2411625640182 : check e2411625640182 [[],[]] .three = true := by decide
def e2411625640662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2411625640662 : Closed e2411625640662 ∧ code e2411625640662 = 11207718662870 := by decide
theorem cert_e2411625640662 : check e2411625640662 [[],[]] .three = true := by decide
def e2411625640666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2411625640666 : Closed e2411625640666 ∧ code e2411625640666 = 11207718662874 := by decide
theorem cert_e2411625640666 : check e2411625640666 [[],[]] .three = true := by decide
def e2411625640682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2411625640682 : Closed e2411625640682 ∧ code e2411625640682 = 11207718662890 := by decide
theorem cert_e2411625640682 : check e2411625640682 [[],[]] .three = true := by decide
def e2411625640734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411625640734 : Closed e2411625640734 ∧ code e2411625640734 = 11207718662942 := by decide
theorem cert_e2411625640734 : check e2411625640734 [[],[]] .three = true := by decide
def e2411625640758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625640758 : Closed e2411625640758 ∧ code e2411625640758 = 11207718662966 := by decide
theorem cert_e2411625640758 : check e2411625640758 [[],[]] .three = true := by decide
def e2411625640762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625640762 : Closed e2411625640762 ∧ code e2411625640762 = 11207718662970 := by decide
theorem cert_e2411625640762 : check e2411625640762 [[],[]] .three = true := by decide
def e2411625640846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2411625640846 : Closed e2411625640846 ∧ code e2411625640846 = 11207718663054 := by decide
theorem cert_e2411625640846 : check e2411625640846 [[],[]] .three = true := by decide
def e2411625640858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625640858 : Closed e2411625640858 ∧ code e2411625640858 = 11207718663066 := by decide
theorem cert_e2411625640858 : check e2411625640858 [[],[]] .three = true := by decide
def e2411625640902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411625640902 : Closed e2411625640902 ∧ code e2411625640902 = 11207718663110 := by decide
theorem cert_e2411625640902 : check e2411625640902 [[],[]] .three = true := by decide
def e2411625640926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 3))))))))
theorem wire_e2411625640926 : Closed e2411625640926 ∧ code e2411625640926 = 11207718663134 := by decide
theorem cert_e2411625640926 : check e2411625640926 [[],[]] .three = true := by decide
def e2411625640942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 2))))))))
theorem wire_e2411625640942 : Closed e2411625640942 ∧ code e2411625640942 = 11207718663150 := by decide
theorem cert_e2411625640942 : check e2411625640942 [[],[]] .three = true := by decide
def e2411625647838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e2411625647838 : Closed e2411625647838 ∧ code e2411625647838 = 11207718670046 := by decide
theorem cert_e2411625647838 : check e2411625647838 [[],[]] .three = true := by decide
def e2411625647854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e2411625647854 : Closed e2411625647854 ∧ code e2411625647854 = 11207718670062 := by decide
theorem cert_e2411625647854 : check e2411625647854 [[],[]] .smaller = true := by decide
def e2411625647862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e2411625647862 : Closed e2411625647862 ∧ code e2411625647862 = 11207718670070 := by decide
theorem cert_e2411625647862 : check e2411625647862 [[],[]] .smaller = true := by decide
def e2411625647866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 4)))) (.var 0)))))))
theorem wire_e2411625647866 : Closed e2411625647866 ∧ code e2411625647866 = 11207718670074 := by decide
theorem cert_e2411625647866 : check e2411625647866 [[],[]] .three = true := by decide
def e2411625647982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e2411625647982 : Closed e2411625647982 ∧ code e2411625647982 = 11207718670190 := by decide
theorem cert_e2411625647982 : check e2411625647982 [[],[]] .smaller = true := by decide
def e2411625647994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e2411625647994 : Closed e2411625647994 ∧ code e2411625647994 = 11207718670202 := by decide
theorem cert_e2411625647994 : check e2411625647994 [[],[]] .smaller = true := by decide
def e2411625648054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e2411625648054 : Closed e2411625648054 ∧ code e2411625648054 = 11207718670262 := by decide
theorem cert_e2411625648054 : check e2411625648054 [[],[]] .smaller = true := by decide
def e2411625648058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e2411625648058 : Closed e2411625648058 ∧ code e2411625648058 = 11207718670266 := by decide
theorem cert_e2411625648058 : check e2411625648058 [[],[]] .smaller = true := by decide
def e2411625648090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 1)))) (.var 0)))))))
theorem wire_e2411625648090 : Closed e2411625648090 ∧ code e2411625648090 = 11207718670298 := by decide
theorem cert_e2411625648090 : check e2411625648090 [[],[]] .three = true := by decide
def e2411625650654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e2411625650654 : Closed e2411625650654 ∧ code e2411625650654 = 11207718672862 := by decide
theorem cert_e2411625650654 : check e2411625650654 [[],[]] .three = true := by decide
def e2411625650670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e2411625650670 : Closed e2411625650670 ∧ code e2411625650670 = 11207718672878 := by decide
theorem cert_e2411625650670 : check e2411625650670 [[],[]] .smaller = true := by decide
def e2411625650678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e2411625650678 : Closed e2411625650678 ∧ code e2411625650678 = 11207718672886 := by decide
theorem cert_e2411625650678 : check e2411625650678 [[],[]] .three = true := by decide
def e2411625651422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625651422 : Closed e2411625651422 ∧ code e2411625651422 = 11207718673630 := by decide
theorem cert_e2411625651422 : check e2411625651422 [[],[]] .three = true := by decide
def e2411625651450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625651450 : Closed e2411625651450 ∧ code e2411625651450 = 11207718673658 := by decide
theorem cert_e2411625651450 : check e2411625651450 [[],[]] .three = true := by decide
def e2411625651822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625651822 : Closed e2411625651822 ∧ code e2411625651822 = 11207718674030 := by decide
theorem cert_e2411625651822 : check e2411625651822 [[],[]] .smaller = true := by decide
def e2411625651834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625651834 : Closed e2411625651834 ∧ code e2411625651834 = 11207718674042 := by decide
theorem cert_e2411625651834 : check e2411625651834 [[],[]] .smaller = true := by decide
def e2411625652022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625652022 : Closed e2411625652022 ∧ code e2411625652022 = 11207718674230 := by decide
theorem cert_e2411625652022 : check e2411625652022 [[],[]] .three = true := by decide
def e2411625652026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625652026 : Closed e2411625652026 ∧ code e2411625652026 = 11207718674234 := by decide
theorem cert_e2411625652026 : check e2411625652026 [[],[]] .three = true := by decide
def e2411625655646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e2411625655646 : Closed e2411625655646 ∧ code e2411625655646 = 11207718677854 := by decide
theorem cert_e2411625655646 : check e2411625655646 [[],[]] .three = true := by decide
def e2411625655662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2411625655662 : Closed e2411625655662 ∧ code e2411625655662 = 11207718677870 := by decide
theorem cert_e2411625655662 : check e2411625655662 [[],[]] .smaller = true := by decide
def e2411625655670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2411625655670 : Closed e2411625655670 ∧ code e2411625655670 = 11207718677878 := by decide
theorem cert_e2411625655670 : check e2411625655670 [[],[]] .smaller = true := by decide
def e2411625655674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e2411625655674 : Closed e2411625655674 ∧ code e2411625655674 = 11207718677882 := by decide
theorem cert_e2411625655674 : check e2411625655674 [[],[]] .three = true := by decide
def e2411625655726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2411625655726 : Closed e2411625655726 ∧ code e2411625655726 = 11207718677934 := by decide
theorem cert_e2411625655726 : check e2411625655726 [[],[]] .smaller = true := by decide
def e2411625655738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2411625655738 : Closed e2411625655738 ∧ code e2411625655738 = 11207718677946 := by decide
theorem cert_e2411625655738 : check e2411625655738 [[],[]] .smaller = true := by decide
def e2411625655766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2411625655766 : Closed e2411625655766 ∧ code e2411625655766 = 11207718677974 := by decide
theorem cert_e2411625655766 : check e2411625655766 [[],[]] .smaller = true := by decide
def e2411625655770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2411625655770 : Closed e2411625655770 ∧ code e2411625655770 = 11207718677978 := by decide
theorem cert_e2411625655770 : check e2411625655770 [[],[]] .smaller = true := by decide
def e2411625655786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e2411625655786 : Closed e2411625655786 ∧ code e2411625655786 = 11207718677994 := by decide
theorem cert_e2411625655786 : check e2411625655786 [[],[]] .three = true := by decide
def e2411625655982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2411625655982 : Closed e2411625655982 ∧ code e2411625655982 = 11207718678190 := by decide
theorem cert_e2411625655982 : check e2411625655982 [[],[]] .smaller = true := by decide
def e2411625655994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2411625655994 : Closed e2411625655994 ∧ code e2411625655994 = 11207718678202 := by decide
theorem cert_e2411625655994 : check e2411625655994 [[],[]] .smaller = true := by decide
def e2411625656042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2411625656042 : Closed e2411625656042 ∧ code e2411625656042 = 11207718678250 := by decide
theorem cert_e2411625656042 : check e2411625656042 [[],[]] .smaller = true := by decide
def e2411625656150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2411625656150 : Closed e2411625656150 ∧ code e2411625656150 = 11207718678358 := by decide
theorem cert_e2411625656150 : check e2411625656150 [[],[]] .smaller = true := by decide
def e2411625656154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2411625656154 : Closed e2411625656154 ∧ code e2411625656154 = 11207718678362 := by decide
theorem cert_e2411625656154 : check e2411625656154 [[],[]] .smaller = true := by decide
def e2411625656170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2411625656170 : Closed e2411625656170 ∧ code e2411625656170 = 11207718678378 := by decide
theorem cert_e2411625656170 : check e2411625656170 [[],[]] .smaller = true := by decide
def e2411625656234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2411625656234 : Closed e2411625656234 ∧ code e2411625656234 = 11207718678442 := by decide
theorem cert_e2411625656234 : check e2411625656234 [[],[]] .three = true := by decide
def e2411625656798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2411625656798 : Closed e2411625656798 ∧ code e2411625656798 = 11207718679006 := by decide
theorem cert_e2411625656798 : check e2411625656798 [[],[]] .three = true := by decide
def e2411625656814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2411625656814 : Closed e2411625656814 ∧ code e2411625656814 = 11207718679022 := by decide
theorem cert_e2411625656814 : check e2411625656814 [[],[]] .smaller = true := by decide
def e2411625656822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2411625656822 : Closed e2411625656822 ∧ code e2411625656822 = 11207718679030 := by decide
theorem cert_e2411625656822 : check e2411625656822 [[],[]] .three = true := by decide
def e2411625657182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e2411625657182 : Closed e2411625657182 ∧ code e2411625657182 = 11207718679390 := by decide
theorem cert_e2411625657182 : check e2411625657182 [[],[]] .three = true := by decide
def e2411625657198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2411625657198 : Closed e2411625657198 ∧ code e2411625657198 = 11207718679406 := by decide
theorem cert_e2411625657198 : check e2411625657198 [[],[]] .smaller = true := by decide
def e2411625657206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2411625657206 : Closed e2411625657206 ∧ code e2411625657206 = 11207718679414 := by decide
theorem cert_e2411625657206 : check e2411625657206 [[],[]] .smaller = true := by decide
def e2411625657210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2411625657210 : Closed e2411625657210 ∧ code e2411625657210 = 11207718679418 := by decide
theorem cert_e2411625657210 : check e2411625657210 [[],[]] .three = true := by decide
def e2411625657262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2411625657262 : Closed e2411625657262 ∧ code e2411625657262 = 11207718679470 := by decide
theorem cert_e2411625657262 : check e2411625657262 [[],[]] .smaller = true := by decide
def e2411625657274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2411625657274 : Closed e2411625657274 ∧ code e2411625657274 = 11207718679482 := by decide
theorem cert_e2411625657274 : check e2411625657274 [[],[]] .smaller = true := by decide
def e2411625657302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2411625657302 : Closed e2411625657302 ∧ code e2411625657302 = 11207718679510 := by decide
theorem cert_e2411625657302 : check e2411625657302 [[],[]] .smaller = true := by decide
def e2411625657306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2411625657306 : Closed e2411625657306 ∧ code e2411625657306 = 11207718679514 := by decide
theorem cert_e2411625657306 : check e2411625657306 [[],[]] .smaller = true := by decide
def e2411625657322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2411625657322 : Closed e2411625657322 ∧ code e2411625657322 = 11207718679530 := by decide
theorem cert_e2411625657322 : check e2411625657322 [[],[]] .three = true := by decide
def e2411625657566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625657566 : Closed e2411625657566 ∧ code e2411625657566 = 11207718679774 := by decide
theorem cert_e2411625657566 : check e2411625657566 [[],[]] .three = true := by decide
def e2411625657582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625657582 : Closed e2411625657582 ∧ code e2411625657582 = 11207718679790 := by decide
theorem cert_e2411625657582 : check e2411625657582 [[],[]] .smaller = true := by decide
def e2411625657590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625657590 : Closed e2411625657590 ∧ code e2411625657590 = 11207718679798 := by decide
theorem cert_e2411625657590 : check e2411625657590 [[],[]] .smaller = true := by decide
def e2411625657594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625657594 : Closed e2411625657594 ∧ code e2411625657594 = 11207718679802 := by decide
theorem cert_e2411625657594 : check e2411625657594 [[],[]] .three = true := by decide
def e2411625657918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 4))))))))
theorem wire_e2411625657918 : Closed e2411625657918 ∧ code e2411625657918 = 11207718680126 := by decide
theorem cert_e2411625657918 : check e2411625657918 [[],[]] .three = true := by decide
def e2411625657966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625657966 : Closed e2411625657966 ∧ code e2411625657966 = 11207718680174 := by decide
theorem cert_e2411625657966 : check e2411625657966 [[],[]] .smaller = true := by decide
def e2411625657978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625657978 : Closed e2411625657978 ∧ code e2411625657978 = 11207718680186 := by decide
theorem cert_e2411625657978 : check e2411625657978 [[],[]] .smaller = true := by decide
def e2411625658142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3))))))))
theorem wire_e2411625658142 : Closed e2411625658142 ∧ code e2411625658142 = 11207718680350 := by decide
theorem cert_e2411625658142 : check e2411625658142 [[],[]] .smaller = true := by decide
def e2411625658166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625658166 : Closed e2411625658166 ∧ code e2411625658166 = 11207718680374 := by decide
theorem cert_e2411625658166 : check e2411625658166 [[],[]] .smaller = true := by decide
def e2411625658170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625658170 : Closed e2411625658170 ∧ code e2411625658170 = 11207718680378 := by decide
theorem cert_e2411625658170 : check e2411625658170 [[],[]] .smaller = true := by decide
def e2411625658254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 2))))))))
theorem wire_e2411625658254 : Closed e2411625658254 ∧ code e2411625658254 = 11207718680462 := by decide
theorem cert_e2411625658254 : check e2411625658254 [[],[]] .three = true := by decide
def e2411625658266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625658266 : Closed e2411625658266 ∧ code e2411625658266 = 11207718680474 := by decide
theorem cert_e2411625658266 : check e2411625658266 [[],[]] .three = true := by decide
end Blc.Floor43
