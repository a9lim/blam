import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419190705838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2419190705838 : Closed e2419190705838 ∧ code e2419190705838 = 11215283728046 := by decide
theorem cert_e2419190705838 : check e2419190705838 [[],[],[.left],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2419190705850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2419190705850 : Closed e2419190705850 ∧ code e2419190705850 = 11215283728058 := by decide
theorem cert_e2419190705850 : check e2419190705850 [[],[],[.left],[.left],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2419190705898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2419190705898 : Closed e2419190705898 ∧ code e2419190705898 = 11215283728106 := by decide
theorem cert_e2419190705898 : check e2419190705898 [[],[],[.left],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2419190706006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2419190706006 : Closed e2419190706006 ∧ code e2419190706006 = 11215283728214 := by decide
theorem cert_e2419190706006 : check e2419190706006 [[],[],[.left],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2419190706010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2419190706010 : Closed e2419190706010 ∧ code e2419190706010 = 11215283728218 := by decide
theorem cert_e2419190706010 : check e2419190706010 [[],[],[.left],[.left],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2419190706026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2419190706026 : Closed e2419190706026 ∧ code e2419190706026 = 11215283728234 := by decide
theorem cert_e2419190706026 : check e2419190706026 [[],[],[.left],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2419190706654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2419190706654 : Closed e2419190706654 ∧ code e2419190706654 = 11215283728862 := by decide
theorem cert_e2419190706654 : check e2419190706654 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190706678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2419190706678 : Closed e2419190706678 ∧ code e2419190706678 = 11215283728886 := by decide
theorem cert_e2419190706678 : check e2419190706678 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2419190707054 : Closed e2419190707054 ∧ code e2419190707054 = 11215283729262 := by decide
theorem cert_e2419190707054 : check e2419190707054 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2419190707062 : Closed e2419190707062 ∧ code e2419190707062 = 11215283729270 := by decide
theorem cert_e2419190707062 : check e2419190707062 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2419190707118 : Closed e2419190707118 ∧ code e2419190707118 = 11215283729326 := by decide
theorem cert_e2419190707118 : check e2419190707118 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2419190707130 : Closed e2419190707130 ∧ code e2419190707130 = 11215283729338 := by decide
theorem cert_e2419190707130 : check e2419190707130 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2419190707158 : Closed e2419190707158 ∧ code e2419190707158 = 11215283729366 := by decide
theorem cert_e2419190707158 : check e2419190707158 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2419190707162 : Closed e2419190707162 ∧ code e2419190707162 = 11215283729370 := by decide
theorem cert_e2419190707162 : check e2419190707162 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419190707438 : Closed e2419190707438 ∧ code e2419190707438 = 11215283729646 := by decide
theorem cert_e2419190707438 : check e2419190707438 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419190707446 : Closed e2419190707446 ∧ code e2419190707446 = 11215283729654 := by decide
theorem cert_e2419190707446 : check e2419190707446 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2419190707774 : Closed e2419190707774 ∧ code e2419190707774 = 11215283729982 := by decide
theorem cert_e2419190707774 : check e2419190707774 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419190707822 : Closed e2419190707822 ∧ code e2419190707822 = 11215283730030 := by decide
theorem cert_e2419190707822 : check e2419190707822 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190707834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419190707834 : Closed e2419190707834 ∧ code e2419190707834 = 11215283730042 := by decide
theorem cert_e2419190707834 : check e2419190707834 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190708022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419190708022 : Closed e2419190708022 ∧ code e2419190708022 = 11215283730230 := by decide
theorem cert_e2419190708022 : check e2419190708022 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190708026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419190708026 : Closed e2419190708026 ∧ code e2419190708026 = 11215283730234 := by decide
theorem cert_e2419190708026 : check e2419190708026 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190708110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2419190708110 : Closed e2419190708110 ∧ code e2419190708110 = 11215283730318 := by decide
theorem cert_e2419190708110 : check e2419190708110 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190708446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2419190708446 : Closed e2419190708446 ∧ code e2419190708446 = 11215283730654 := by decide
theorem cert_e2419190708446 : check e2419190708446 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419190708474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2419190708474 : Closed e2419190708474 ∧ code e2419190708474 = 11215283730682 := by decide
theorem cert_e2419190708474 : checkPay e2419190708474 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.under],[.under],[.under]] = true := by decide
def e2419190708654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2419190708654 : Closed e2419190708654 ∧ code e2419190708654 = 11215283730862 := by decide
theorem cert_e2419190708654 : check e2419190708654 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2419190708666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2419190708666 : Closed e2419190708666 ∧ code e2419190708666 = 11215283730874 := by decide
theorem cert_e2419190708666 : check e2419190708666 [[],[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2419190708714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2419190708714 : Closed e2419190708714 ∧ code e2419190708714 = 11215283730922 := by decide
theorem cert_e2419190708714 : check e2419190708714 [[],[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2419190708798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2419190708798 : Closed e2419190708798 ∧ code e2419190708798 = 11215283731006 := by decide
theorem cert_e2419190708798 : check e2419190708798 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2419190708846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419190708846 : Closed e2419190708846 ∧ code e2419190708846 = 11215283731054 := by decide
theorem cert_e2419190708846 : check e2419190708846 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2419190708858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419190708858 : Closed e2419190708858 ∧ code e2419190708858 = 11215283731066 := by decide
theorem cert_e2419190708858 : check e2419190708858 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2419190709146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419190709146 : Closed e2419190709146 ∧ code e2419190709146 = 11215283731354 := by decide
theorem cert_e2419190709146 : check e2419190709146 [[],[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2419190709190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2419190709190 : Closed e2419190709190 ∧ code e2419190709190 = 11215283731398 := by decide
theorem cert_e2419190709190 : check e2419190709190 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .smaller = true := by decide
def e2419190709462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2419190709462 : Closed e2419190709462 ∧ code e2419190709462 = 11215283731670 := by decide
theorem cert_e2419190709462 : check e2419190709462 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2419190709466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2419190709466 : Closed e2419190709466 ∧ code e2419190709466 = 11215283731674 := by decide
theorem cert_e2419190709466 : check e2419190709466 [[],[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2419190709482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2419190709482 : Closed e2419190709482 ∧ code e2419190709482 = 11215283731690 := by decide
theorem cert_e2419190709482 : check e2419190709482 [[],[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2419190709558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419190709558 : Closed e2419190709558 ∧ code e2419190709558 = 11215283731766 := by decide
theorem cert_e2419190709558 : check e2419190709558 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2419190709562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419190709562 : Closed e2419190709562 ∧ code e2419190709562 = 11215283731770 := by decide
theorem cert_e2419190709562 : check e2419190709562 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2419190709658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419190709658 : Closed e2419190709658 ∧ code e2419190709658 = 11215283731866 := by decide
theorem cert_e2419190709658 : check e2419190709658 [[],[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2419190709814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2419190709814 : Closed e2419190709814 ∧ code e2419190709814 = 11215283732022 := by decide
theorem cert_e2419190709814 : check e2419190709814 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e2419190709818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2419190709818 : Closed e2419190709818 ∧ code e2419190709818 = 11215283732026 := by decide
theorem cert_e2419190709818 : check e2419190709818 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under]] .three = true := by decide
def e2419190709902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2419190709902 : Closed e2419190709902 ∧ code e2419190709902 = 11215283732110 := by decide
theorem cert_e2419190709902 : check e2419190709902 [[],[],[.left],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2419190709958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2419190709958 : Closed e2419190709958 ∧ code e2419190709958 = 11215283732166 := by decide
theorem cert_e2419190709958 : check e2419190709958 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2419190713198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419190713198 : Closed e2419190713198 ∧ code e2419190713198 = 11215283735406 := by decide
theorem cert_e2419190713198 : check e2419190713198 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419190713206 : Closed e2419190713206 ∧ code e2419190713206 = 11215283735414 := by decide
theorem cert_e2419190713206 : check e2419190713206 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419190713262 : Closed e2419190713262 ∧ code e2419190713262 = 11215283735470 := by decide
theorem cert_e2419190713262 : check e2419190713262 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419190713274 : Closed e2419190713274 ∧ code e2419190713274 = 11215283735482 := by decide
theorem cert_e2419190713274 : check e2419190713274 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419190713302 : Closed e2419190713302 ∧ code e2419190713302 = 11215283735510 := by decide
theorem cert_e2419190713302 : check e2419190713302 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419190713306 : Closed e2419190713306 ∧ code e2419190713306 = 11215283735514 := by decide
theorem cert_e2419190713306 : check e2419190713306 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419190713582 : Closed e2419190713582 ∧ code e2419190713582 = 11215283735790 := by decide
theorem cert_e2419190713582 : check e2419190713582 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419190713590 : Closed e2419190713590 ∧ code e2419190713590 = 11215283735798 := by decide
theorem cert_e2419190713590 : check e2419190713590 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2419190713918 : Closed e2419190713918 ∧ code e2419190713918 = 11215283736126 := by decide
theorem cert_e2419190713918 : check e2419190713918 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419190713966 : Closed e2419190713966 ∧ code e2419190713966 = 11215283736174 := by decide
theorem cert_e2419190713966 : check e2419190713966 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190713978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419190713978 : Closed e2419190713978 ∧ code e2419190713978 = 11215283736186 := by decide
theorem cert_e2419190713978 : check e2419190713978 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190714166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419190714166 : Closed e2419190714166 ∧ code e2419190714166 = 11215283736374 := by decide
theorem cert_e2419190714166 : check e2419190714166 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190714170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419190714170 : Closed e2419190714170 ∧ code e2419190714170 = 11215283736378 := by decide
theorem cert_e2419190714170 : check e2419190714170 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190714254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2419190714254 : Closed e2419190714254 ∧ code e2419190714254 = 11215283736462 := by decide
theorem cert_e2419190714254 : check e2419190714254 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419190719918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2419190719918 : Closed e2419190719918 ∧ code e2419190719918 = 11215283742126 := by decide
theorem cert_e2419190719918 : check e2419190719918 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190719930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2419190719930 : Closed e2419190719930 ∧ code e2419190719930 = 11215283742138 := by decide
theorem cert_e2419190719930 : check e2419190719930 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190719978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2419190719978 : Closed e2419190719978 ∧ code e2419190719978 = 11215283742186 := by decide
theorem cert_e2419190719978 : check e2419190719978 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190720062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2419190720062 : Closed e2419190720062 ∧ code e2419190720062 = 11215283742270 := by decide
theorem cert_e2419190720062 : check e2419190720062 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190720110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419190720110 : Closed e2419190720110 ∧ code e2419190720110 = 11215283742318 := by decide
theorem cert_e2419190720110 : check e2419190720110 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190720122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419190720122 : Closed e2419190720122 ∧ code e2419190720122 = 11215283742330 := by decide
theorem cert_e2419190720122 : check e2419190720122 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190720410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419190720410 : Closed e2419190720410 ∧ code e2419190720410 = 11215283742618 := by decide
theorem cert_e2419190720410 : check e2419190720410 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190720454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2419190720454 : Closed e2419190720454 ∧ code e2419190720454 = 11215283742662 := by decide
theorem cert_e2419190720454 : check e2419190720454 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190723286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2419190723286 : Closed e2419190723286 ∧ code e2419190723286 = 11215283745494 := by decide
theorem cert_e2419190723286 : check e2419190723286 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190723290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2419190723290 : Closed e2419190723290 ∧ code e2419190723290 = 11215283745498 := by decide
theorem cert_e2419190723290 : check e2419190723290 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190723306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2419190723306 : Closed e2419190723306 ∧ code e2419190723306 = 11215283745514 := by decide
theorem cert_e2419190723306 : check e2419190723306 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190723382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419190723382 : Closed e2419190723382 ∧ code e2419190723382 = 11215283745590 := by decide
theorem cert_e2419190723382 : check e2419190723382 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190723386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419190723386 : Closed e2419190723386 ∧ code e2419190723386 = 11215283745594 := by decide
theorem cert_e2419190723386 : check e2419190723386 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190723482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419190723482 : Closed e2419190723482 ∧ code e2419190723482 = 11215283745690 := by decide
theorem cert_e2419190723482 : check e2419190723482 [[],[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2419190725006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2419190725006 : Closed e2419190725006 ∧ code e2419190725006 = 11215283747214 := by decide
theorem cert_e2419190725006 : check e2419190725006 [[],[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2419190725062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2419190725062 : Closed e2419190725062 ∧ code e2419190725062 = 11215283747270 := by decide
theorem cert_e2419190725062 : check e2419190725062 [[],[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419190837614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2419190837614 : Closed e2419190837614 ∧ code e2419190837614 = 11215283859822 := by decide
theorem cert_e2419190837614 : check e2419190837614 [[],[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2419190837622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2419190837622 : Closed e2419190837622 ∧ code e2419190837622 = 11215283859830 := by decide
theorem cert_e2419190837622 : check e2419190837622 [[],[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2419190838830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419190838830 : Closed e2419190838830 ∧ code e2419190838830 = 11215283861038 := by decide
theorem cert_e2419190838830 : check e2419190838830 [[],[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .chain = true := by decide
def e2419190839010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419190839010 : Closed e2419190839010 ∧ code e2419190839010 = 11215283861218 := by decide
def e2419190839022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2419190839022 : Closed e2419190839022 ∧ code e2419190839022 = 11215283861230 := by decide
def e2419190839062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419190839062 : Closed e2419190839062 ∧ code e2419190839062 = 11215283861270 := by decide
theorem cert_e2419190839062 : check e2419190839062 [[],[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .chain = true := by decide
def e2419190839138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419190839138 : Closed e2419190839138 ∧ code e2419190839138 = 11215283861346 := by decide
def e2419190839150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2419190839150 : Closed e2419190839150 ∧ code e2419190839150 = 11215283861358 := by decide
def e2419190839158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2419190839158 : Closed e2419190839158 ∧ code e2419190839158 = 11215283861366 := by decide
def e2419190839470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2419190839470 : Closed e2419190839470 ∧ code e2419190839470 = 11215283861678 := by decide
def e2419190839482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2419190839482 : Closed e2419190839482 ∧ code e2419190839482 = 11215283861690 := by decide
theorem cert_e2419190839482 : check e2419190839482 [[],[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2419190839854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419190839854 : Closed e2419190839854 ∧ code e2419190839854 = 11215283862062 := by decide
theorem cert_e2419190839854 : check e2419190839854 [[],[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2419190840034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419190840034 : Closed e2419190840034 ∧ code e2419190840034 = 11215283862242 := by decide
def e2419190840046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2419190840046 : Closed e2419190840046 ∧ code e2419190840046 = 11215283862254 := by decide
def e2419190840202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419190840202 : Closed e2419190840202 ∧ code e2419190840202 = 11215283862410 := by decide
private def t_e2419190840202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem cert_e2419190840202 : ¬ IsSelfInterpreter e2419190840202 :=
  wSource (t := t_e2419190840202) (replay_sound (ps := []) (t := e2419190840202) (by decide)) (by decide)
def e2419190840226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419190840226 : Closed e2419190840226 ∧ code e2419190840226 = 11215283862434 := by decide
private def t_e2419190840226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem cert_e2419190840226 : ¬ IsSelfInterpreter e2419190840226 :=
  wSource (t := t_e2419190840226) (replay_sound (ps := []) (t := e2419190840226) (by decide)) (by decide)
def e2419190840238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2419190840238 : Closed e2419190840238 ∧ code e2419190840238 = 11215283862446 := by decide
private def t_e2419190840238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem cert_e2419190840238 : ¬ IsSelfInterpreter e2419190840238 :=
  wSource (t := t_e2419190840238) (replay_sound (ps := []) (t := e2419190840238) (by decide)) (by decide)
def e2419190840250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2419190840250 : Closed e2419190840250 ∧ code e2419190840250 = 11215283862458 := by decide
private def t_e2419190840250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem cert_e2419190840250 : ¬ IsSelfInterpreter e2419190840250 :=
  wSource (t := t_e2419190840250) (replay_sound (ps := []) (t := e2419190840250) (by decide)) (by decide)
def e2419190840406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2419190840406 : Closed e2419190840406 ∧ code e2419190840406 = 11215283862614 := by decide
theorem cert_e2419190840406 : check e2419190840406 [[],[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2419190840410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2419190840410 : Closed e2419190840410 ∧ code e2419190840410 = 11215283862618 := by decide
theorem cert_e2419190840410 : check e2419190840410 [[],[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2419190840598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419190840598 : Closed e2419190840598 ∧ code e2419190840598 = 11215283862806 := by decide
theorem cert_e2419190840598 : check e2419190840598 [[],[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left]] .chain = true := by decide
def e2419190840674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419190840674 : Closed e2419190840674 ∧ code e2419190840674 = 11215283862882 := by decide
def e2419190840686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2419190840686 : Closed e2419190840686 ∧ code e2419190840686 = 11215283862894 := by decide
def e2419190840694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2419190840694 : Closed e2419190840694 ∧ code e2419190840694 = 11215283862902 := by decide
def e2419190840714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419190840714 : Closed e2419190840714 ∧ code e2419190840714 = 11215283862922 := by decide
private def t_e2419190840714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem cert_e2419190840714 : ¬ IsSelfInterpreter e2419190840714 :=
  wSource (t := t_e2419190840714) (replay_sound (ps := []) (t := e2419190840714) (by decide)) (by decide)
def e2419190840738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419190840738 : Closed e2419190840738 ∧ code e2419190840738 = 11215283862946 := by decide
private def t_e2419190840738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem cert_e2419190840738 : ¬ IsSelfInterpreter e2419190840738 :=
  wSource (t := t_e2419190840738) (replay_sound (ps := []) (t := e2419190840738) (by decide)) (by decide)
def e2419190840750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2419190840750 : Closed e2419190840750 ∧ code e2419190840750 = 11215283862958 := by decide
private def t_e2419190840750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem cert_e2419190840750 : ¬ IsSelfInterpreter e2419190840750 :=
  wSource (t := t_e2419190840750) (replay_sound (ps := []) (t := e2419190840750) (by decide)) (by decide)
def e2419190840762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2419190840762 : Closed e2419190840762 ∧ code e2419190840762 = 11215283862970 := by decide
private def t_e2419190840762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem cert_e2419190840762 : ¬ IsSelfInterpreter e2419190840762 :=
  wSource (t := t_e2419190840762) (replay_sound (ps := []) (t := e2419190840762) (by decide)) (by decide)
def e2419190840790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2419190840790 : Closed e2419190840790 ∧ code e2419190840790 = 11215283862998 := by decide
private def t_e2419190840790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem cert_e2419190840790 : ¬ IsSelfInterpreter e2419190840790 :=
  wSource (t := t_e2419190840790) (replay_sound (ps := []) (t := e2419190840790) (by decide)) (by decide)
def e2419190840794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2419190840794 : Closed e2419190840794 ∧ code e2419190840794 = 11215283863002 := by decide
private def t_e2419190840794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem cert_e2419190840794 : ¬ IsSelfInterpreter e2419190840794 :=
  wSource (t := t_e2419190840794) (replay_sound (ps := []) (t := e2419190840794) (by decide)) (by decide)
def e2419190841838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2419190841838 : Closed e2419190841838 ∧ code e2419190841838 = 11215283864046 := by decide
theorem cert_e2419190841838 : check e2419190841838 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[.left],[]] .three = true := by decide
def e2419190841846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2419190841846 : Closed e2419190841846 ∧ code e2419190841846 = 11215283864054 := by decide
theorem cert_e2419190841846 : check e2419190841846 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2419190842606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2419190842606 : Closed e2419190842606 ∧ code e2419190842606 = 11215283864814 := by decide
def e2419190842614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2419190842614 : Closed e2419190842614 ∧ code e2419190842614 = 11215283864822 := by decide
def e2419190843166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2419190843166 : Closed e2419190843166 ∧ code e2419190843166 = 11215283865374 := by decide
theorem cert_e2419190843166 : check e2419190843166 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[],[],[]] .sourceHead = true := by decide
def e2419190843278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2419190843278 : Closed e2419190843278 ∧ code e2419190843278 = 11215283865486 := by decide
theorem cert_e2419190843278 : check e2419190843278 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2419190844974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2419190844974 : Closed e2419190844974 ∧ code e2419190844974 = 11215283867182 := by decide
def e2419190845154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2419190845154 : Closed e2419190845154 ∧ code e2419190845154 = 11215283867362 := by decide
def e2419190845166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2419190845166 : Closed e2419190845166 ∧ code e2419190845166 = 11215283867374 := by decide
def e2419190845206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2419190845206 : Closed e2419190845206 ∧ code e2419190845206 = 11215283867414 := by decide
theorem cert_e2419190845206 : check e2419190845206 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2419190845282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2419190845282 : Closed e2419190845282 ∧ code e2419190845282 = 11215283867490 := by decide
def e2419190845294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2419190845294 : Closed e2419190845294 ∧ code e2419190845294 = 11215283867502 := by decide
def e2419190845302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2419190845302 : Closed e2419190845302 ∧ code e2419190845302 = 11215283867510 := by decide
def e2419190847550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2419190847550 : Closed e2419190847550 ∧ code e2419190847550 = 11215283869758 := by decide
theorem cert_e2419190847550 : check e2419190847550 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2419190847970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419190847970 : Closed e2419190847970 ∧ code e2419190847970 = 11215283870178 := by decide
theorem cert_e2419190847970 : check e2419190847970 [[],[],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .chain = true := by decide
def e2419190847982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2419190847982 : Closed e2419190847982 ∧ code e2419190847982 = 11215283870190 := by decide
def e2419190848542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2419190848542 : Closed e2419190848542 ∧ code e2419190848542 = 11215283870750 := by decide
theorem cert_e2419190848542 : check e2419190848542 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .chain = true := by decide
def e2419190848738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419190848738 : Closed e2419190848738 ∧ code e2419190848738 = 11215283870946 := by decide
theorem cert_e2419190848738 : check e2419190848738 [[],[],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .chain = true := by decide
def e2419190848750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419190848750 : Closed e2419190848750 ∧ code e2419190848750 = 11215283870958 := by decide
def e2419190848758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419190848758 : Closed e2419190848758 ∧ code e2419190848758 = 11215283870966 := by decide
def e2419190849774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2419190849774 : Closed e2419190849774 ∧ code e2419190849774 = 11215283871982 := by decide
theorem cert_e2419190849774 : checkPay e2419190849774 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419190849786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2419190849786 : Closed e2419190849786 ∧ code e2419190849786 = 11215283871994 := by decide
theorem cert_e2419190849786 : check e2419190849786 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2419190850158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2419190850158 : Closed e2419190850158 ∧ code e2419190850158 = 11215283872366 := by decide
theorem cert_e2419190850158 : check e2419190850158 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2419190850170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2419190850170 : Closed e2419190850170 ∧ code e2419190850170 = 11215283872378 := by decide
theorem cert_e2419190850170 : check e2419190850170 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e2419190850334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2419190850334 : Closed e2419190850334 ∧ code e2419190850334 = 11215283872542 := by decide
theorem cert_e2419190850334 : check e2419190850334 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .smaller = true := by decide
def e2419190850502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2419190850502 : Closed e2419190850502 ∧ code e2419190850502 = 11215283872710 := by decide
theorem cert_e2419190850502 : check e2419190850502 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[]] .three = true := by decide
def e2419190851118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2419190851118 : Closed e2419190851118 ∧ code e2419190851118 = 11215283873326 := by decide
theorem cert_e2419190851118 : check e2419190851118 [[],[],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2419190851298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2419190851298 : Closed e2419190851298 ∧ code e2419190851298 = 11215283873506 := by decide
def e2419190851310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2419190851310 : Closed e2419190851310 ∧ code e2419190851310 = 11215283873518 := by decide
def e2419190851466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419190851466 : Closed e2419190851466 ∧ code e2419190851466 = 11215283873674 := by decide
theorem cert_e2419190851466 : checkPay e2419190851466 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[]] = true := by decide
def e2419190851490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419190851490 : Closed e2419190851490 ∧ code e2419190851490 = 11215283873698 := by decide
def e2419190851502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2419190851502 : Closed e2419190851502 ∧ code e2419190851502 = 11215283873710 := by decide
def e2419190851514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2419190851514 : Closed e2419190851514 ∧ code e2419190851514 = 11215283873722 := by decide
private def t_e2419190851514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem cert_e2419190851514 : ¬ IsSelfInterpreter e2419190851514 :=
  wSource (t := t_e2419190851514) (replay_sound (ps := []) (t := e2419190851514) (by decide)) (by decide)
def e2419190851646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2419190851646 : Closed e2419190851646 ∧ code e2419190851646 = 11215283873854 := by decide
theorem cert_e2419190851646 : check e2419190851646 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2419190852066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419190852066 : Closed e2419190852066 ∧ code e2419190852066 = 11215283874274 := by decide
theorem cert_e2419190852066 : check e2419190852066 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left]] .chain = true := by decide
def e2419190852078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2419190852078 : Closed e2419190852078 ∧ code e2419190852078 = 11215283874286 := by decide
def e2419190853134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419190853134 : Closed e2419190853134 ∧ code e2419190853134 = 11215283875342 := by decide
private def t_e2419190853134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem cert_e2419190853134 : ¬ IsSelfInterpreter e2419190853134 :=
  wSource (t := t_e2419190853134) (replay_sound (ps := []) (t := e2419190853134) (by decide)) (by decide)
def e2419190853218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419190853218 : Closed e2419190853218 ∧ code e2419190853218 = 11215283875426 := by decide
private def t_e2419190853218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem cert_e2419190853218 : ¬ IsSelfInterpreter e2419190853218 :=
  wSource (t := t_e2419190853218) (replay_sound (ps := []) (t := e2419190853218) (by decide)) (by decide)
def e2419190853230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419190853230 : Closed e2419190853230 ∧ code e2419190853230 = 11215283875438 := by decide
private def t_e2419190853230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem cert_e2419190853230 : ¬ IsSelfInterpreter e2419190853230 :=
  wSource (t := t_e2419190853230) (replay_sound (ps := []) (t := e2419190853230) (by decide)) (by decide)
def e2419190853242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419190853242 : Closed e2419190853242 ∧ code e2419190853242 = 11215283875450 := by decide
private def t_e2419190853242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem cert_e2419190853242 : ¬ IsSelfInterpreter e2419190853242 :=
  wSource (t := t_e2419190853242) (replay_sound (ps := []) (t := e2419190853242) (by decide)) (by decide)
def e2419190853750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2419190853750 : Closed e2419190853750 ∧ code e2419190853750 = 11215283875958 := by decide
theorem cert_e2419190853750 : check e2419190853750 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2419190853754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2419190853754 : Closed e2419190853754 ∧ code e2419190853754 = 11215283875962 := by decide
theorem cert_e2419190853754 : check e2419190853754 [[],[],[.left],[.left],[.left],[],[.left],[.left],[]] .chain = true := by decide
def e2419190853942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419190853942 : Closed e2419190853942 ∧ code e2419190853942 = 11215283876150 := by decide
theorem cert_e2419190853942 : check e2419190853942 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2419190853946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419190853946 : Closed e2419190853946 ∧ code e2419190853946 = 11215283876154 := by decide
theorem cert_e2419190853946 : check e2419190853946 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2419190854030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2419190854030 : Closed e2419190854030 ∧ code e2419190854030 = 11215283876238 := by decide
theorem cert_e2419190854030 : check e2419190854030 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2419190854086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2419190854086 : Closed e2419190854086 ∧ code e2419190854086 = 11215283876294 := by decide
theorem cert_e2419190854086 : check e2419190854086 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .three = true := by decide
def e2419190854422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2419190854422 : Closed e2419190854422 ∧ code e2419190854422 = 11215283876630 := by decide
def e2419190854498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2419190854498 : Closed e2419190854498 ∧ code e2419190854498 = 11215283876706 := by decide
def e2419190854510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2419190854510 : Closed e2419190854510 ∧ code e2419190854510 = 11215283876718 := by decide
def e2419190854518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2419190854518 : Closed e2419190854518 ∧ code e2419190854518 = 11215283876726 := by decide
def e2419190854538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419190854538 : Closed e2419190854538 ∧ code e2419190854538 = 11215283876746 := by decide
theorem cert_e2419190854538 : check e2419190854538 [[],[],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419190854562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419190854562 : Closed e2419190854562 ∧ code e2419190854562 = 11215283876770 := by decide
def e2419190854574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2419190854574 : Closed e2419190854574 ∧ code e2419190854574 = 11215283876782 := by decide
def e2419190854586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2419190854586 : Closed e2419190854586 ∧ code e2419190854586 = 11215283876794 := by decide
private def t_e2419190854586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem cert_e2419190854586 : ¬ IsSelfInterpreter e2419190854586 :=
  wSource (t := t_e2419190854586) (replay_sound (ps := []) (t := e2419190854586) (by decide)) (by decide)
def e2419190854614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2419190854614 : Closed e2419190854614 ∧ code e2419190854614 = 11215283876822 := by decide
def e2419190854618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2419190854618 : Closed e2419190854618 ∧ code e2419190854618 = 11215283876826 := by decide
private def t_e2419190854618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem cert_e2419190854618 : ¬ IsSelfInterpreter e2419190854618 :=
  wSource (t := t_e2419190854618) (replay_sound (ps := []) (t := e2419190854618) (by decide)) (by decide)
def e2419190854686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2419190854686 : Closed e2419190854686 ∧ code e2419190854686 = 11215283876894 := by decide
theorem cert_e2419190854686 : check e2419190854686 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .three = true := by decide
def e2419190854882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419190854882 : Closed e2419190854882 ∧ code e2419190854882 = 11215283877090 := by decide
theorem cert_e2419190854882 : check e2419190854882 [[],[],[.left],[.left],[.left],[],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419190840202
#print axioms Blc.Floor43.cert_e2419190840226
#print axioms Blc.Floor43.cert_e2419190840238
#print axioms Blc.Floor43.cert_e2419190840250
#print axioms Blc.Floor43.cert_e2419190840714
#print axioms Blc.Floor43.cert_e2419190840738
#print axioms Blc.Floor43.cert_e2419190840750
#print axioms Blc.Floor43.cert_e2419190840762
#print axioms Blc.Floor43.cert_e2419190840790
#print axioms Blc.Floor43.cert_e2419190840794
#print axioms Blc.Floor43.cert_e2419190851514
#print axioms Blc.Floor43.cert_e2419190853134
#print axioms Blc.Floor43.cert_e2419190853218
#print axioms Blc.Floor43.cert_e2419190853230
#print axioms Blc.Floor43.cert_e2419190853242
#print axioms Blc.Floor43.cert_e2419190854586
#print axioms Blc.Floor43.cert_e2419190854618
