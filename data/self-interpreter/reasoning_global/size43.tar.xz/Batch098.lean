import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e834096904622 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e834096904622 : Closed e834096904622 ∧ code e834096904622 = 9630189926830 := by decide
theorem cert_e834096904622 : check e834096904622 [] .sourceHead = true := by decide
def e834096904634 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e834096904634 : Closed e834096904634 ∧ code e834096904634 = 9630189926842 := by decide
theorem cert_e834096904634 : check e834096904634 [] .sourceHead = true := by decide
def e834096904682 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e834096904682 : Closed e834096904682 ∧ code e834096904682 = 9630189926890 := by decide
theorem cert_e834096904682 : check e834096904682 [] .sourceHead = true := by decide
def e834096904814 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834096904814 : Closed e834096904814 ∧ code e834096904814 = 9630189927022 := by decide
theorem cert_e834096904814 : check e834096904814 [] .sourceHead = true := by decide
def e834096904826 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834096904826 : Closed e834096904826 ∧ code e834096904826 = 9630189927034 := by decide
theorem cert_e834096904826 : check e834096904826 [] .sourceHead = true := by decide
def e834096904990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e834096904990 : Closed e834096904990 ∧ code e834096904990 = 9630189927198 := by decide
theorem cert_e834096904990 : check e834096904990 [] .sourceHead = true := by decide
def e834096905102 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e834096905102 : Closed e834096905102 ∧ code e834096905102 = 9630189927310 := by decide
theorem cert_e834096905102 : check e834096905102 [] .sourceHead = true := by decide
def e834096905114 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096905114 : Closed e834096905114 ∧ code e834096905114 = 9630189927322 := by decide
theorem cert_e834096905114 : check e834096905114 [] .sourceHead = true := by decide
def e834096905334 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e834096905334 : Closed e834096905334 ∧ code e834096905334 = 9630189927542 := by decide
theorem cert_e834096905334 : check e834096905334 [] .sourceHead = true := by decide
def e834096905430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e834096905430 : Closed e834096905430 ∧ code e834096905430 = 9630189927638 := by decide
theorem cert_e834096905430 : check e834096905430 [] .sourceHead = true := by decide
def e834096905434 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e834096905434 : Closed e834096905434 ∧ code e834096905434 = 9630189927642 := by decide
theorem cert_e834096905434 : check e834096905434 [] .sourceHead = true := by decide
def e834096905450 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e834096905450 : Closed e834096905450 ∧ code e834096905450 = 9630189927658 := by decide
theorem cert_e834096905450 : check e834096905450 [] .sourceHead = true := by decide
def e834096905526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834096905526 : Closed e834096905526 ∧ code e834096905526 = 9630189927734 := by decide
theorem cert_e834096905526 : check e834096905526 [] .sourceHead = true := by decide
def e834096905530 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834096905530 : Closed e834096905530 ∧ code e834096905530 = 9630189927738 := by decide
theorem cert_e834096905530 : check e834096905530 [] .sourceHead = true := by decide
def e834096905614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e834096905614 : Closed e834096905614 ∧ code e834096905614 = 9630189927822 := by decide
theorem cert_e834096905614 : check e834096905614 [] .sourceHead = true := by decide
def e834096905626 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096905626 : Closed e834096905626 ∧ code e834096905626 = 9630189927834 := by decide
theorem cert_e834096905626 : check e834096905626 [] .sourceHead = true := by decide
def e834096907230 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e834096907230 : Closed e834096907230 ∧ code e834096907230 = 9630189929438 := by decide
theorem cert_e834096907230 : check e834096907230 [] .sourceHead = true := by decide
def e834096907246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e834096907246 : Closed e834096907246 ∧ code e834096907246 = 9630189929454 := by decide
theorem cert_e834096907246 : check e834096907246 [] .sourceHead = true := by decide
def e834096909166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e834096909166 : Closed e834096909166 ∧ code e834096909166 = 9630189931374 := by decide
theorem cert_e834096909166 : check e834096909166 [] .sourceHead = true := by decide
def e834096909174 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e834096909174 : Closed e834096909174 ∧ code e834096909174 = 9630189931382 := by decide
theorem cert_e834096909174 : check e834096909174 [] .sourceHead = true := by decide
def e834096909230 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e834096909230 : Closed e834096909230 ∧ code e834096909230 = 9630189931438 := by decide
theorem cert_e834096909230 : check e834096909230 [] .sourceHead = true := by decide
def e834096909242 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e834096909242 : Closed e834096909242 ∧ code e834096909242 = 9630189931450 := by decide
theorem cert_e834096909242 : check e834096909242 [] .sourceHead = true := by decide
def e834096909270 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e834096909270 : Closed e834096909270 ∧ code e834096909270 = 9630189931478 := by decide
theorem cert_e834096909270 : check e834096909270 [] .sourceHead = true := by decide
def e834096909274 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e834096909274 : Closed e834096909274 ∧ code e834096909274 = 9630189931482 := by decide
theorem cert_e834096909274 : check e834096909274 [] .sourceHead = true := by decide
def e834096909550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e834096909550 : Closed e834096909550 ∧ code e834096909550 = 9630189931758 := by decide
theorem cert_e834096909550 : check e834096909550 [] .sourceHead = true := by decide
def e834096909558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e834096909558 : Closed e834096909558 ∧ code e834096909558 = 9630189931766 := by decide
theorem cert_e834096909558 : check e834096909558 [] .sourceHead = true := by decide
def e834096909934 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834096909934 : Closed e834096909934 ∧ code e834096909934 = 9630189932142 := by decide
theorem cert_e834096909934 : check e834096909934 [] .sourceHead = true := by decide
def e834096909946 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834096909946 : Closed e834096909946 ∧ code e834096909946 = 9630189932154 := by decide
theorem cert_e834096909946 : check e834096909946 [] .sourceHead = true := by decide
def e834096910134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834096910134 : Closed e834096910134 ∧ code e834096910134 = 9630189932342 := by decide
theorem cert_e834096910134 : check e834096910134 [] .sourceHead = true := by decide
def e834096910138 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834096910138 : Closed e834096910138 ∧ code e834096910138 = 9630189932346 := by decide
theorem cert_e834096910138 : check e834096910138 [] .sourceHead = true := by decide
def e834096914910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e834096914910 : Closed e834096914910 ∧ code e834096914910 = 9630189937118 := by decide
theorem cert_e834096914910 : check e834096914910 [] .sourceHead = true := by decide
def e834096914934 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e834096914934 : Closed e834096914934 ∧ code e834096914934 = 9630189937142 := by decide
theorem cert_e834096914934 : check e834096914934 [] .sourceHead = true := by decide
def e834096915886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e834096915886 : Closed e834096915886 ∧ code e834096915886 = 9630189938094 := by decide
theorem cert_e834096915886 : check e834096915886 [] .sourceHead = true := by decide
def e834096915898 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e834096915898 : Closed e834096915898 ∧ code e834096915898 = 9630189938106 := by decide
theorem cert_e834096915898 : check e834096915898 [] .sourceHead = true := by decide
def e834096915946 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e834096915946 : Closed e834096915946 ∧ code e834096915946 = 9630189938154 := by decide
theorem cert_e834096915946 : check e834096915946 [] .sourceHead = true := by decide
def e834096916078 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834096916078 : Closed e834096916078 ∧ code e834096916078 = 9630189938286 := by decide
theorem cert_e834096916078 : check e834096916078 [] .sourceHead = true := by decide
def e834096916090 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834096916090 : Closed e834096916090 ∧ code e834096916090 = 9630189938298 := by decide
theorem cert_e834096916090 : check e834096916090 [] .sourceHead = true := by decide
def e834096916254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e834096916254 : Closed e834096916254 ∧ code e834096916254 = 9630189938462 := by decide
theorem cert_e834096916254 : check e834096916254 [] .sourceHead = true := by decide
def e834096916366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e834096916366 : Closed e834096916366 ∧ code e834096916366 = 9630189938574 := by decide
theorem cert_e834096916366 : check e834096916366 [] .sourceHead = true := by decide
def e834096916378 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834096916378 : Closed e834096916378 ∧ code e834096916378 = 9630189938586 := by decide
theorem cert_e834096916378 : check e834096916378 [] .sourceHead = true := by decide
def e834096918766 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e834096918766 : Closed e834096918766 ∧ code e834096918766 = 9630189940974 := by decide
theorem cert_e834096918766 : check e834096918766 [] .sourceHead = true := by decide
def e834096918774 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e834096918774 : Closed e834096918774 ∧ code e834096918774 = 9630189940982 := by decide
theorem cert_e834096918774 : check e834096918774 [] .sourceHead = true := by decide
def e834096919254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e834096919254 : Closed e834096919254 ∧ code e834096919254 = 9630189941462 := by decide
theorem cert_e834096919254 : check e834096919254 [] .sourceHead = true := by decide
def e834096919258 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e834096919258 : Closed e834096919258 ∧ code e834096919258 = 9630189941466 := by decide
theorem cert_e834096919258 : check e834096919258 [] .sourceHead = true := by decide
def e834096919274 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e834096919274 : Closed e834096919274 ∧ code e834096919274 = 9630189941482 := by decide
theorem cert_e834096919274 : check e834096919274 [] .sourceHead = true := by decide
def e834096919350 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834096919350 : Closed e834096919350 ∧ code e834096919350 = 9630189941558 := by decide
theorem cert_e834096919350 : check e834096919350 [] .sourceHead = true := by decide
def e834096919354 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834096919354 : Closed e834096919354 ∧ code e834096919354 = 9630189941562 := by decide
theorem cert_e834096919354 : check e834096919354 [] .sourceHead = true := by decide
def e834096919438 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e834096919438 : Closed e834096919438 ∧ code e834096919438 = 9630189941646 := by decide
theorem cert_e834096919438 : check e834096919438 [] .sourceHead = true := by decide
def e834096919450 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834096919450 : Closed e834096919450 ∧ code e834096919450 = 9630189941658 := by decide
theorem cert_e834096919450 : check e834096919450 [] .sourceHead = true := by decide
def e834097010350 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e834097010350 : Closed e834097010350 ∧ code e834097010350 = 9630190032558 := by decide
theorem cert_e834097010350 : check e834097010350 [] .sourceHead = true := by decide
def e834097010362 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e834097010362 : Closed e834097010362 ∧ code e834097010362 = 9630190032570 := by decide
theorem cert_e834097010362 : check e834097010362 [] .sourceHead = true := by decide
def e834097010410 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e834097010410 : Closed e834097010410 ∧ code e834097010410 = 9630190032618 := by decide
theorem cert_e834097010410 : check e834097010410 [] .sourceHead = true := by decide
def e834097010602 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e834097010602 : Closed e834097010602 ∧ code e834097010602 = 9630190032810 := by decide
theorem cert_e834097010602 : check e834097010602 [] .sourceHead = true := by decide
def e834097010926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e834097010926 : Closed e834097010926 ∧ code e834097010926 = 9630190033134 := by decide
theorem cert_e834097010926 : check e834097010926 [] .sourceHead = true := by decide
def e834097010934 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e834097010934 : Closed e834097010934 ∧ code e834097010934 = 9630190033142 := by decide
theorem cert_e834097010934 : check e834097010934 [] .sourceHead = true := by decide
def e834097011118 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e834097011118 : Closed e834097011118 ∧ code e834097011118 = 9630190033326 := by decide
theorem cert_e834097011118 : check e834097011118 [] .sourceHead = true := by decide
def e834097011130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e834097011130 : Closed e834097011130 ∧ code e834097011130 = 9630190033338 := by decide
theorem cert_e834097011130 : check e834097011130 [] .sourceHead = true := by decide
def e834097011178 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e834097011178 : Closed e834097011178 ∧ code e834097011178 = 9630190033386 := by decide
theorem cert_e834097011178 : check e834097011178 [] .sourceHead = true := by decide
def e834097011310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834097011310 : Closed e834097011310 ∧ code e834097011310 = 9630190033518 := by decide
theorem cert_e834097011310 : check e834097011310 [] .sourceHead = true := by decide
def e834097011322 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834097011322 : Closed e834097011322 ∧ code e834097011322 = 9630190033530 := by decide
theorem cert_e834097011322 : check e834097011322 [] .sourceHead = true := by decide
def e834097011486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e834097011486 : Closed e834097011486 ∧ code e834097011486 = 9630190033694 := by decide
theorem cert_e834097011486 : check e834097011486 [] .sourceHead = true := by decide
def e834097011598 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e834097011598 : Closed e834097011598 ∧ code e834097011598 = 9630190033806 := by decide
theorem cert_e834097011598 : check e834097011598 [] .sourceHead = true := by decide
def e834097011610 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834097011610 : Closed e834097011610 ∧ code e834097011610 = 9630190033818 := by decide
theorem cert_e834097011610 : check e834097011610 [] .sourceHead = true := by decide
def e834097011822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e834097011822 : Closed e834097011822 ∧ code e834097011822 = 9630190034030 := by decide
theorem cert_e834097011822 : check e834097011822 [] .sourceHead = true := by decide
def e834097011834 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e834097011834 : Closed e834097011834 ∧ code e834097011834 = 9630190034042 := by decide
theorem cert_e834097011834 : check e834097011834 [] .sourceHead = true := by decide
def e834097011998 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e834097011998 : Closed e834097011998 ∧ code e834097011998 = 9630190034206 := by decide
theorem cert_e834097011998 : check e834097011998 [] .sourceHead = true := by decide
def e834097012166 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e834097012166 : Closed e834097012166 ∧ code e834097012166 = 9630190034374 := by decide
theorem cert_e834097012166 : check e834097012166 [] .sourceHead = true := by decide
def e834097012278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e834097012278 : Closed e834097012278 ∧ code e834097012278 = 9630190034486 := by decide
theorem cert_e834097012278 : check e834097012278 [] .sourceHead = true := by decide
def e834097012282 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e834097012282 : Closed e834097012282 ∧ code e834097012282 = 9630190034490 := by decide
theorem cert_e834097012282 : check e834097012282 [] .sourceHead = true := by decide
def e834097012330 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e834097012330 : Closed e834097012330 ∧ code e834097012330 = 9630190034538 := by decide
theorem cert_e834097012330 : check e834097012330 [] .sourceHead = true := by decide
def e834097012366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e834097012366 : Closed e834097012366 ∧ code e834097012366 = 9630190034574 := by decide
theorem cert_e834097012366 : check e834097012366 [] .sourceHead = true := by decide
def e834097012378 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834097012378 : Closed e834097012378 ∧ code e834097012378 = 9630190034586 := by decide
theorem cert_e834097012378 : check e834097012378 [] .sourceHead = true := by decide
def e834097012422 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e834097012422 : Closed e834097012422 ∧ code e834097012422 = 9630190034630 := by decide
theorem cert_e834097012422 : check e834097012422 [] .sourceHead = true := by decide
def e834097013214 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e834097013214 : Closed e834097013214 ∧ code e834097013214 = 9630190035422 := by decide
theorem cert_e834097013214 : check e834097013214 [] .sourceHead = true := by decide
def e834097013238 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e834097013238 : Closed e834097013238 ∧ code e834097013238 = 9630190035446 := by decide
theorem cert_e834097013238 : check e834097013238 [] .sourceHead = true := by decide
def e834097014190 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e834097014190 : Closed e834097014190 ∧ code e834097014190 = 9630190036398 := by decide
theorem cert_e834097014190 : check e834097014190 [] .sourceHead = true := by decide
def e834097014202 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e834097014202 : Closed e834097014202 ∧ code e834097014202 = 9630190036410 := by decide
theorem cert_e834097014202 : check e834097014202 [] .sourceHead = true := by decide
def e834097014250 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e834097014250 : Closed e834097014250 ∧ code e834097014250 = 9630190036458 := by decide
theorem cert_e834097014250 : check e834097014250 [] .sourceHead = true := by decide
def e834097014382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834097014382 : Closed e834097014382 ∧ code e834097014382 = 9630190036590 := by decide
theorem cert_e834097014382 : check e834097014382 [] .sourceHead = true := by decide
def e834097014394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834097014394 : Closed e834097014394 ∧ code e834097014394 = 9630190036602 := by decide
theorem cert_e834097014394 : check e834097014394 [] .sourceHead = true := by decide
def e834097014558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e834097014558 : Closed e834097014558 ∧ code e834097014558 = 9630190036766 := by decide
theorem cert_e834097014558 : check e834097014558 [] .sourceHead = true := by decide
def e834097014670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e834097014670 : Closed e834097014670 ∧ code e834097014670 = 9630190036878 := by decide
theorem cert_e834097014670 : check e834097014670 [] .sourceHead = true := by decide
def e834097014682 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834097014682 : Closed e834097014682 ∧ code e834097014682 = 9630190036890 := by decide
theorem cert_e834097014682 : check e834097014682 [] .sourceHead = true := by decide
def e834097017630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e834097017630 : Closed e834097017630 ∧ code e834097017630 = 9630190039838 := by decide
theorem cert_e834097017630 : check e834097017630 [] .sourceHead = true := by decide
def e834097017798 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e834097017798 : Closed e834097017798 ∧ code e834097017798 = 9630190040006 := by decide
theorem cert_e834097017798 : check e834097017798 [] .sourceHead = true := by decide
def e834097018998 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e834097018998 : Closed e834097018998 ∧ code e834097018998 = 9630190041206 := by decide
theorem cert_e834097018998 : check e834097018998 [] .sourceHead = true := by decide
def e834097019242 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e834097019242 : Closed e834097019242 ∧ code e834097019242 = 9630190041450 := by decide
theorem cert_e834097019242 : check e834097019242 [] .sourceHead = true := by decide
def e834097019278 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e834097019278 : Closed e834097019278 ∧ code e834097019278 = 9630190041486 := by decide
theorem cert_e834097019278 : check e834097019278 [] .sourceHead = true := by decide
def e834097019290 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834097019290 : Closed e834097019290 ∧ code e834097019290 = 9630190041498 := by decide
theorem cert_e834097019290 : check e834097019290 [] .sourceHead = true := by decide
def e834097019334 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e834097019334 : Closed e834097019334 ∧ code e834097019334 = 9630190041542 := by decide
theorem cert_e834097019334 : check e834097019334 [] .sourceHead = true := by decide
def e834097064790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e834097064790 : Closed e834097064790 ∧ code e834097064790 = 9630190086998 := by decide
theorem cert_e834097064790 : check e834097064790 [] .sourceHead = true := by decide
def e834097064794 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e834097064794 : Closed e834097064794 ∧ code e834097064794 = 9630190087002 := by decide
theorem cert_e834097064794 : check e834097064794 [] .sourceHead = true := by decide
def e834097064810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e834097064810 : Closed e834097064810 ∧ code e834097064810 = 9630190087018 := by decide
theorem cert_e834097064810 : check e834097064810 [] .sourceHead = true := by decide
def e834097064874 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e834097064874 : Closed e834097064874 ∧ code e834097064874 = 9630190087082 := by decide
theorem cert_e834097064874 : check e834097064874 [] .sourceHead = true := by decide
def e834097065078 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e834097065078 : Closed e834097065078 ∧ code e834097065078 = 9630190087286 := by decide
theorem cert_e834097065078 : check e834097065078 [] .sourceHead = true := by decide
def e834097065174 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e834097065174 : Closed e834097065174 ∧ code e834097065174 = 9630190087382 := by decide
theorem cert_e834097065174 : check e834097065174 [] .sourceHead = true := by decide
def e834097065178 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e834097065178 : Closed e834097065178 ∧ code e834097065178 = 9630190087386 := by decide
theorem cert_e834097065178 : check e834097065178 [] .sourceHead = true := by decide
def e834097065194 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e834097065194 : Closed e834097065194 ∧ code e834097065194 = 9630190087402 := by decide
theorem cert_e834097065194 : check e834097065194 [] .sourceHead = true := by decide
def e834097065270 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834097065270 : Closed e834097065270 ∧ code e834097065270 = 9630190087478 := by decide
theorem cert_e834097065270 : check e834097065270 [] .sourceHead = true := by decide
def e834097065274 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834097065274 : Closed e834097065274 ∧ code e834097065274 = 9630190087482 := by decide
theorem cert_e834097065274 : check e834097065274 [] .sourceHead = true := by decide
def e834097065358 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e834097065358 : Closed e834097065358 ∧ code e834097065358 = 9630190087566 := by decide
theorem cert_e834097065358 : check e834097065358 [] .sourceHead = true := by decide
def e834097065370 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834097065370 : Closed e834097065370 ∧ code e834097065370 = 9630190087578 := by decide
theorem cert_e834097065370 : check e834097065370 [] .sourceHead = true := by decide
def e834097065526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e834097065526 : Closed e834097065526 ∧ code e834097065526 = 9630190087734 := by decide
theorem cert_e834097065526 : check e834097065526 [] .sourceHead = true := by decide
def e834097065530 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e834097065530 : Closed e834097065530 ∧ code e834097065530 = 9630190087738 := by decide
theorem cert_e834097065530 : check e834097065530 [] .sourceHead = true := by decide
def e834097065578 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e834097065578 : Closed e834097065578 ∧ code e834097065578 = 9630190087786 := by decide
theorem cert_e834097065578 : check e834097065578 [] .sourceHead = true := by decide
def e834097065614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e834097065614 : Closed e834097065614 ∧ code e834097065614 = 9630190087822 := by decide
theorem cert_e834097065614 : check e834097065614 [] .sourceHead = true := by decide
def e834097065626 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e834097065626 : Closed e834097065626 ∧ code e834097065626 = 9630190087834 := by decide
theorem cert_e834097065626 : check e834097065626 [] .sourceHead = true := by decide
def e834097065670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e834097065670 : Closed e834097065670 ∧ code e834097065670 = 9630190087878 := by decide
theorem cert_e834097065670 : check e834097065670 [] .sourceHead = true := by decide
def e834097066222 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e834097066222 : Closed e834097066222 ∧ code e834097066222 = 9630190088430 := by decide
theorem cert_e834097066222 : check e834097066222 [] .sourceHead = true := by decide
def e834097066230 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e834097066230 : Closed e834097066230 ∧ code e834097066230 = 9630190088438 := by decide
theorem cert_e834097066230 : check e834097066230 [] .sourceHead = true := by decide
def e834097066710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e834097066710 : Closed e834097066710 ∧ code e834097066710 = 9630190088918 := by decide
theorem cert_e834097066710 : check e834097066710 [] .sourceHead = true := by decide
def e834097066714 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e834097066714 : Closed e834097066714 ∧ code e834097066714 = 9630190088922 := by decide
theorem cert_e834097066714 : check e834097066714 [] .sourceHead = true := by decide
def e834097066730 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e834097066730 : Closed e834097066730 ∧ code e834097066730 = 9630190088938 := by decide
theorem cert_e834097066730 : check e834097066730 [] .sourceHead = true := by decide
def e834097066806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e834097066806 : Closed e834097066806 ∧ code e834097066806 = 9630190089014 := by decide
theorem cert_e834097066806 : check e834097066806 [] .sourceHead = true := by decide
def e834097066810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e834097066810 : Closed e834097066810 ∧ code e834097066810 = 9630190089018 := by decide
theorem cert_e834097066810 : check e834097066810 [] .sourceHead = true := by decide
def e834097066894 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e834097066894 : Closed e834097066894 ∧ code e834097066894 = 9630190089102 := by decide
theorem cert_e834097066894 : check e834097066894 [] .sourceHead = true := by decide
def e834097066906 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834097066906 : Closed e834097066906 ∧ code e834097066906 = 9630190089114 := by decide
theorem cert_e834097066906 : check e834097066906 [] .sourceHead = true := by decide
def e834097068150 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e834097068150 : Closed e834097068150 ∧ code e834097068150 = 9630190090358 := by decide
theorem cert_e834097068150 : check e834097068150 [] .sourceHead = true := by decide
def e834097068394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e834097068394 : Closed e834097068394 ∧ code e834097068394 = 9630190090602 := by decide
theorem cert_e834097068394 : check e834097068394 [] .sourceHead = true := by decide
def e834097068430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e834097068430 : Closed e834097068430 ∧ code e834097068430 = 9630190090638 := by decide
theorem cert_e834097068430 : check e834097068430 [] .sourceHead = true := by decide
def e834097068442 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e834097068442 : Closed e834097068442 ∧ code e834097068442 = 9630190090650 := by decide
theorem cert_e834097068442 : check e834097068442 [] .sourceHead = true := by decide
def e834097068486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e834097068486 : Closed e834097068486 ∧ code e834097068486 = 9630190090694 := by decide
theorem cert_e834097068486 : check e834097068486 [] .sourceHead = true := by decide
def e834098965946 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))))
theorem wire_e834098965946 : Closed e834098965946 ∧ code e834098965946 = 9630191988154 := by decide
theorem cert_e834098965946 : check e834098965946 [] .sourceHead = true := by decide
def e834098965978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))))
theorem wire_e834098965978 : Closed e834098965978 ∧ code e834098965978 = 9630191988186 := by decide
theorem cert_e834098965978 : check e834098965978 [] .sourceHead = true := by decide
def e834098966202 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e834098966202 : Closed e834098966202 ∧ code e834098966202 = 9630191988410 := by decide
theorem cert_e834098966202 : check e834098966202 [] .sourceHead = true := by decide
def e834098966250 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e834098966250 : Closed e834098966250 ∧ code e834098966250 = 9630191988458 := by decide
theorem cert_e834098966250 : check e834098966250 [] .sourceHead = true := by decide
def e834098966362 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e834098966362 : Closed e834098966362 ∧ code e834098966362 = 9630191988570 := by decide
theorem cert_e834098966362 : check e834098966362 [] .sourceHead = true := by decide
def e834098966378 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e834098966378 : Closed e834098966378 ∧ code e834098966378 = 9630191988586 := by decide
theorem cert_e834098966378 : check e834098966378 [] .sourceHead = true := by decide
def e834098967482 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))))
theorem wire_e834098967482 : Closed e834098967482 ∧ code e834098967482 = 9630191989690 := by decide
theorem cert_e834098967482 : check e834098967482 [] .sourceHead = true := by decide
def e834098967514 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))))
theorem wire_e834098967514 : Closed e834098967514 ∧ code e834098967514 = 9630191989722 := by decide
theorem cert_e834098967514 : check e834098967514 [] .sourceHead = true := by decide
def e834098969018 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e834098969018 : Closed e834098969018 ∧ code e834098969018 = 9630191991226 := by decide
theorem cert_e834098969018 : check e834098969018 [] .sourceHead = true := by decide
def e834098969066 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e834098969066 : Closed e834098969066 ∧ code e834098969066 = 9630191991274 := by decide
theorem cert_e834098969066 : check e834098969066 [] .sourceHead = true := by decide
def e834098969818 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e834098969818 : Closed e834098969818 ∧ code e834098969818 = 9630191992026 := by decide
theorem cert_e834098969818 : check e834098969818 [] .sourceHead = true := by decide
def e834098969834 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e834098969834 : Closed e834098969834 ∧ code e834098969834 = 9630191992042 := by decide
theorem cert_e834098969834 : check e834098969834 [] .sourceHead = true := by decide
def e834099022702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e834099022702 : Closed e834099022702 ∧ code e834099022702 = 9630192044910 := by decide
theorem cert_e834099022702 : check e834099022702 [] .sourceHead = true := by decide
def e834099022710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e834099022710 : Closed e834099022710 ∧ code e834099022710 = 9630192044918 := by decide
theorem cert_e834099022710 : check e834099022710 [] .sourceHead = true := by decide
def e834099022766 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e834099022766 : Closed e834099022766 ∧ code e834099022766 = 9630192044974 := by decide
theorem cert_e834099022766 : check e834099022766 [] .sourceHead = true := by decide
def e834099022778 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e834099022778 : Closed e834099022778 ∧ code e834099022778 = 9630192044986 := by decide
theorem cert_e834099022778 : check e834099022778 [] .sourceHead = true := by decide
def e834099022806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e834099022806 : Closed e834099022806 ∧ code e834099022806 = 9630192045014 := by decide
theorem cert_e834099022806 : check e834099022806 [] .sourceHead = true := by decide
def e834099022810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e834099022810 : Closed e834099022810 ∧ code e834099022810 = 9630192045018 := by decide
theorem cert_e834099022810 : check e834099022810 [] .sourceHead = true := by decide
def e834099023086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e834099023086 : Closed e834099023086 ∧ code e834099023086 = 9630192045294 := by decide
theorem cert_e834099023086 : check e834099023086 [] .sourceHead = true := by decide
def e834099023094 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e834099023094 : Closed e834099023094 ∧ code e834099023094 = 9630192045302 := by decide
theorem cert_e834099023094 : check e834099023094 [] .sourceHead = true := by decide
def e834099023470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e834099023470 : Closed e834099023470 ∧ code e834099023470 = 9630192045678 := by decide
theorem cert_e834099023470 : check e834099023470 [] .sourceHead = true := by decide
def e834099023482 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e834099023482 : Closed e834099023482 ∧ code e834099023482 = 9630192045690 := by decide
theorem cert_e834099023482 : check e834099023482 [] .sourceHead = true := by decide
def e834099023670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e834099023670 : Closed e834099023670 ∧ code e834099023670 = 9630192045878 := by decide
theorem cert_e834099023670 : check e834099023670 [] .sourceHead = true := by decide
def e834099023674 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e834099023674 : Closed e834099023674 ∧ code e834099023674 = 9630192045882 := by decide
theorem cert_e834099023674 : check e834099023674 [] .sourceHead = true := by decide
def e834099228126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e834099228126 : Closed e834099228126 ∧ code e834099228126 = 9630192250334 := by decide
theorem cert_e834099228126 : check e834099228126 [] .sourceHead = true := by decide
def e834099228142 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e834099228142 : Closed e834099228142 ∧ code e834099228142 = 9630192250350 := by decide
theorem cert_e834099228142 : check e834099228142 [] .sourceHead = true := by decide
def e834099228510 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e834099228510 : Closed e834099228510 ∧ code e834099228510 = 9630192250718 := by decide
theorem cert_e834099228510 : check e834099228510 [] .sourceHead = true := by decide
def e834099228538 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e834099228538 : Closed e834099228538 ∧ code e834099228538 = 9630192250746 := by decide
theorem cert_e834099228538 : check e834099228538 [] .sourceHead = true := by decide
def e834099228590 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e834099228590 : Closed e834099228590 ∧ code e834099228590 = 9630192250798 := by decide
theorem cert_e834099228590 : check e834099228590 [] .sourceHead = true := by decide
def e834099228602 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e834099228602 : Closed e834099228602 ∧ code e834099228602 = 9630192250810 := by decide
theorem cert_e834099228602 : check e834099228602 [] .sourceHead = true := by decide
def e834099229662 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e834099229662 : Closed e834099229662 ∧ code e834099229662 = 9630192251870 := by decide
theorem cert_e834099229662 : check e834099229662 [] .sourceHead = true := by decide
def e834099229678 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e834099229678 : Closed e834099229678 ∧ code e834099229678 = 9630192251886 := by decide
theorem cert_e834099229678 : check e834099229678 [] .sourceHead = true := by decide
def e834099231966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e834099231966 : Closed e834099231966 ∧ code e834099231966 = 9630192254174 := by decide
theorem cert_e834099231966 : check e834099231966 [] .sourceHead = true := by decide
def e834099231994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e834099231994 : Closed e834099231994 ∧ code e834099231994 = 9630192254202 := by decide
theorem cert_e834099231994 : check e834099231994 [] .sourceHead = true := by decide
def e834099232366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e834099232366 : Closed e834099232366 ∧ code e834099232366 = 9630192254574 := by decide
theorem cert_e834099232366 : check e834099232366 [] .sourceHead = true := by decide
def e834099232378 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e834099232378 : Closed e834099232378 ∧ code e834099232378 = 9630192254586 := by decide
theorem cert_e834099232378 : check e834099232378 [] .sourceHead = true := by decide
def e834099260782 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e834099260782 : Closed e834099260782 ∧ code e834099260782 = 9630192282990 := by decide
theorem cert_e834099260782 : check e834099260782 [] .sourceHead = true := by decide
def e834099260790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e834099260790 : Closed e834099260790 ∧ code e834099260790 = 9630192282998 := by decide
theorem cert_e834099260790 : check e834099260790 [] .sourceHead = true := by decide
end Blc.Floor43
