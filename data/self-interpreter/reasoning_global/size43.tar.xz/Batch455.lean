import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406399926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e2422406399926 : Closed e2422406399926 ∧ code e2422406399926 = 11218499422134 := by decide
theorem cert_e2422406399926 : check e2422406399926 [[],[]] .chain = true := by decide
def e2422406401390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406401390 : Closed e2422406401390 ∧ code e2422406401390 = 11218499423598 := by decide
theorem cert_e2422406401390 : check e2422406401390 [[],[]] .chain = true := by decide
def e2422406401398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406401398 : Closed e2422406401398 ∧ code e2422406401398 = 11218499423606 := by decide
theorem cert_e2422406401398 : check e2422406401398 [[],[]] .chain = true := by decide
def e2422406401454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406401454 : Closed e2422406401454 ∧ code e2422406401454 = 11218499423662 := by decide
theorem cert_e2422406401454 : check e2422406401454 [[],[]] .chain = true := by decide
def e2422406401466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406401466 : Closed e2422406401466 ∧ code e2422406401466 = 11218499423674 := by decide
theorem cert_e2422406401466 : check e2422406401466 [[],[]] .chain = true := by decide
def e2422406401494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406401494 : Closed e2422406401494 ∧ code e2422406401494 = 11218499423702 := by decide
theorem cert_e2422406401494 : check e2422406401494 [[],[]] .chain = true := by decide
def e2422406401498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406401498 : Closed e2422406401498 ∧ code e2422406401498 = 11218499423706 := by decide
theorem cert_e2422406401498 : check e2422406401498 [[],[]] .chain = true := by decide
def e2422406401710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406401710 : Closed e2422406401710 ∧ code e2422406401710 = 11218499423918 := by decide
theorem cert_e2422406401710 : check e2422406401710 [[],[]] .chain = true := by decide
def e2422406401722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406401722 : Closed e2422406401722 ∧ code e2422406401722 = 11218499423930 := by decide
theorem cert_e2422406401722 : check e2422406401722 [[],[]] .chain = true := by decide
def e2422406401770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406401770 : Closed e2422406401770 ∧ code e2422406401770 = 11218499423978 := by decide
theorem cert_e2422406401770 : check e2422406401770 [[],[]] .chain = true := by decide
def e2422406401878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406401878 : Closed e2422406401878 ∧ code e2422406401878 = 11218499424086 := by decide
theorem cert_e2422406401878 : check e2422406401878 [[],[]] .chain = true := by decide
def e2422406401882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406401882 : Closed e2422406401882 ∧ code e2422406401882 = 11218499424090 := by decide
theorem cert_e2422406401882 : check e2422406401882 [[],[]] .chain = true := by decide
def e2422406401898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406401898 : Closed e2422406401898 ∧ code e2422406401898 = 11218499424106 := by decide
theorem cert_e2422406401898 : check e2422406401898 [[],[]] .chain = true := by decide
def e2422406402926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406402926 : Closed e2422406402926 ∧ code e2422406402926 = 11218499425134 := by decide
theorem cert_e2422406402926 : check e2422406402926 [[],[]] .chain = true := by decide
def e2422406402934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406402934 : Closed e2422406402934 ∧ code e2422406402934 = 11218499425142 := by decide
theorem cert_e2422406402934 : check e2422406402934 [[],[]] .chain = true := by decide
def e2422406402990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406402990 : Closed e2422406402990 ∧ code e2422406402990 = 11218499425198 := by decide
theorem cert_e2422406402990 : check e2422406402990 [[],[]] .chain = true := by decide
def e2422406403002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406403002 : Closed e2422406403002 ∧ code e2422406403002 = 11218499425210 := by decide
theorem cert_e2422406403002 : check e2422406403002 [[],[]] .chain = true := by decide
def e2422406403030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406403030 : Closed e2422406403030 ∧ code e2422406403030 = 11218499425238 := by decide
theorem cert_e2422406403030 : check e2422406403030 [[],[]] .chain = true := by decide
def e2422406403034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406403034 : Closed e2422406403034 ∧ code e2422406403034 = 11218499425242 := by decide
theorem cert_e2422406403034 : check e2422406403034 [[],[]] .chain = true := by decide
def e2422406403310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406403310 : Closed e2422406403310 ∧ code e2422406403310 = 11218499425518 := by decide
theorem cert_e2422406403310 : check e2422406403310 [[],[]] .chain = true := by decide
def e2422406403318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406403318 : Closed e2422406403318 ∧ code e2422406403318 = 11218499425526 := by decide
theorem cert_e2422406403318 : check e2422406403318 [[],[]] .chain = true := by decide
def e2422406403694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406403694 : Closed e2422406403694 ∧ code e2422406403694 = 11218499425902 := by decide
theorem cert_e2422406403694 : check e2422406403694 [[],[]] .chain = true := by decide
def e2422406403706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406403706 : Closed e2422406403706 ∧ code e2422406403706 = 11218499425914 := by decide
theorem cert_e2422406403706 : check e2422406403706 [[],[]] .chain = true := by decide
def e2422406403894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406403894 : Closed e2422406403894 ∧ code e2422406403894 = 11218499426102 := by decide
theorem cert_e2422406403894 : check e2422406403894 [[],[]] .chain = true := by decide
def e2422406403898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406403898 : Closed e2422406403898 ∧ code e2422406403898 = 11218499426106 := by decide
theorem cert_e2422406403898 : check e2422406403898 [[],[]] .chain = true := by decide
def e2422406404334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406404334 : Closed e2422406404334 ∧ code e2422406404334 = 11218499426542 := by decide
theorem cert_e2422406404334 : check e2422406404334 [[],[]] .chain = true := by decide
def e2422406404342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406404342 : Closed e2422406404342 ∧ code e2422406404342 = 11218499426550 := by decide
theorem cert_e2422406404342 : check e2422406404342 [[],[]] .chain = true := by decide
def e2422406404526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406404526 : Closed e2422406404526 ∧ code e2422406404526 = 11218499426734 := by decide
theorem cert_e2422406404526 : check e2422406404526 [[],[]] .chain = true := by decide
def e2422406404538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406404538 : Closed e2422406404538 ∧ code e2422406404538 = 11218499426746 := by decide
theorem cert_e2422406404538 : check e2422406404538 [[],[]] .chain = true := by decide
def e2422406404586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406404586 : Closed e2422406404586 ∧ code e2422406404586 = 11218499426794 := by decide
theorem cert_e2422406404586 : check e2422406404586 [[],[]] .chain = true := by decide
def e2422406404718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406404718 : Closed e2422406404718 ∧ code e2422406404718 = 11218499426926 := by decide
theorem cert_e2422406404718 : check e2422406404718 [[],[]] .chain = true := by decide
def e2422406404730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406404730 : Closed e2422406404730 ∧ code e2422406404730 = 11218499426938 := by decide
theorem cert_e2422406404730 : check e2422406404730 [[],[]] .chain = true := by decide
def e2422406404894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406404894 : Closed e2422406404894 ∧ code e2422406404894 = 11218499427102 := by decide
theorem cert_e2422406404894 : check e2422406404894 [[],[]] .chain = true := by decide
def e2422406405006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406405006 : Closed e2422406405006 ∧ code e2422406405006 = 11218499427214 := by decide
theorem cert_e2422406405006 : check e2422406405006 [[],[]] .chain = true := by decide
def e2422406405018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406405018 : Closed e2422406405018 ∧ code e2422406405018 = 11218499427226 := by decide
theorem cert_e2422406405018 : check e2422406405018 [[],[]] .chain = true := by decide
def e2422406405238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406405238 : Closed e2422406405238 ∧ code e2422406405238 = 11218499427446 := by decide
theorem cert_e2422406405238 : check e2422406405238 [[],[]] .chain = true := by decide
def e2422406405334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406405334 : Closed e2422406405334 ∧ code e2422406405334 = 11218499427542 := by decide
theorem cert_e2422406405334 : check e2422406405334 [[],[]] .chain = true := by decide
def e2422406405338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406405338 : Closed e2422406405338 ∧ code e2422406405338 = 11218499427546 := by decide
theorem cert_e2422406405338 : check e2422406405338 [[],[]] .chain = true := by decide
def e2422406405354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406405354 : Closed e2422406405354 ∧ code e2422406405354 = 11218499427562 := by decide
theorem cert_e2422406405354 : check e2422406405354 [[],[]] .chain = true := by decide
def e2422406405430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406405430 : Closed e2422406405430 ∧ code e2422406405430 = 11218499427638 := by decide
theorem cert_e2422406405430 : check e2422406405430 [[],[]] .chain = true := by decide
def e2422406405434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406405434 : Closed e2422406405434 ∧ code e2422406405434 = 11218499427642 := by decide
theorem cert_e2422406405434 : check e2422406405434 [[],[]] .chain = true := by decide
def e2422406405518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406405518 : Closed e2422406405518 ∧ code e2422406405518 = 11218499427726 := by decide
theorem cert_e2422406405518 : check e2422406405518 [[],[]] .chain = true := by decide
def e2422406405530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406405530 : Closed e2422406405530 ∧ code e2422406405530 = 11218499427738 := by decide
theorem cert_e2422406405530 : check e2422406405530 [[],[]] .chain = true := by decide
def e2422406407022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422406407022 : Closed e2422406407022 ∧ code e2422406407022 = 11218499429230 := by decide
theorem cert_e2422406407022 : check e2422406407022 [[],[]] .chain = true := by decide
def e2422406407030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422406407030 : Closed e2422406407030 ∧ code e2422406407030 = 11218499429238 := by decide
theorem cert_e2422406407030 : check e2422406407030 [[],[]] .chain = true := by decide
def e2422406407086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422406407086 : Closed e2422406407086 ∧ code e2422406407086 = 11218499429294 := by decide
theorem cert_e2422406407086 : check e2422406407086 [[],[]] .chain = true := by decide
def e2422406407098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422406407098 : Closed e2422406407098 ∧ code e2422406407098 = 11218499429306 := by decide
theorem cert_e2422406407098 : check e2422406407098 [[],[]] .chain = true := by decide
def e2422406407126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2422406407126 : Closed e2422406407126 ∧ code e2422406407126 = 11218499429334 := by decide
theorem cert_e2422406407126 : check e2422406407126 [[],[]] .chain = true := by decide
def e2422406407130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2422406407130 : Closed e2422406407130 ∧ code e2422406407130 = 11218499429338 := by decide
theorem cert_e2422406407130 : check e2422406407130 [[],[]] .chain = true := by decide
def e2422406408430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406408430 : Closed e2422406408430 ∧ code e2422406408430 = 11218499430638 := by decide
theorem cert_e2422406408430 : check e2422406408430 [[],[]] .chain = true := by decide
def e2422406408438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406408438 : Closed e2422406408438 ∧ code e2422406408438 = 11218499430646 := by decide
theorem cert_e2422406408438 : check e2422406408438 [[],[]] .chain = true := by decide
def e2422406408990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406408990 : Closed e2422406408990 ∧ code e2422406408990 = 11218499431198 := by decide
theorem cert_e2422406408990 : check e2422406408990 [[],[]] .chain = true := by decide
def e2422406409102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406409102 : Closed e2422406409102 ∧ code e2422406409102 = 11218499431310 := by decide
theorem cert_e2422406409102 : check e2422406409102 [[],[]] .chain = true := by decide
def e2422406409326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406409326 : Closed e2422406409326 ∧ code e2422406409326 = 11218499431534 := by decide
theorem cert_e2422406409326 : check e2422406409326 [[],[]] .chain = true := by decide
def e2422406409338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406409338 : Closed e2422406409338 ∧ code e2422406409338 = 11218499431546 := by decide
theorem cert_e2422406409338 : check e2422406409338 [[],[]] .chain = true := by decide
def e2422406409502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406409502 : Closed e2422406409502 ∧ code e2422406409502 = 11218499431710 := by decide
theorem cert_e2422406409502 : check e2422406409502 [[],[]] .chain = true := by decide
def e2422406409670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406409670 : Closed e2422406409670 ∧ code e2422406409670 = 11218499431878 := by decide
theorem cert_e2422406409670 : check e2422406409670 [[],[]] .chain = true := by decide
def e2422406409782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406409782 : Closed e2422406409782 ∧ code e2422406409782 = 11218499431990 := by decide
theorem cert_e2422406409782 : check e2422406409782 [[],[]] .chain = true := by decide
def e2422406409786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406409786 : Closed e2422406409786 ∧ code e2422406409786 = 11218499431994 := by decide
theorem cert_e2422406409786 : check e2422406409786 [[],[]] .chain = true := by decide
def e2422406409870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406409870 : Closed e2422406409870 ∧ code e2422406409870 = 11218499432078 := by decide
theorem cert_e2422406409870 : check e2422406409870 [[],[]] .chain = true := by decide
def e2422406409926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406409926 : Closed e2422406409926 ∧ code e2422406409926 = 11218499432134 := by decide
theorem cert_e2422406409926 : check e2422406409926 [[],[]] .chain = true := by decide
def e2422406410606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406410606 : Closed e2422406410606 ∧ code e2422406410606 = 11218499432814 := by decide
theorem cert_e2422406410606 : check e2422406410606 [[],[]] .chain = true := by decide
def e2422406410614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406410614 : Closed e2422406410614 ∧ code e2422406410614 = 11218499432822 := by decide
theorem cert_e2422406410614 : check e2422406410614 [[],[]] .chain = true := by decide
def e2422406410670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406410670 : Closed e2422406410670 ∧ code e2422406410670 = 11218499432878 := by decide
theorem cert_e2422406410670 : check e2422406410670 [[],[]] .chain = true := by decide
def e2422406410682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406410682 : Closed e2422406410682 ∧ code e2422406410682 = 11218499432890 := by decide
theorem cert_e2422406410682 : check e2422406410682 [[],[]] .chain = true := by decide
def e2422406410730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2422406410730 : Closed e2422406410730 ∧ code e2422406410730 = 11218499432938 := by decide
theorem cert_e2422406410730 : check e2422406410730 [[],[]] .chain = true := by decide
def e2422406411374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406411374 : Closed e2422406411374 ∧ code e2422406411374 = 11218499433582 := by decide
theorem cert_e2422406411374 : check e2422406411374 [[],[]] .chain = true := by decide
def e2422406411386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406411386 : Closed e2422406411386 ∧ code e2422406411386 = 11218499433594 := by decide
theorem cert_e2422406411386 : check e2422406411386 [[],[]] .chain = true := by decide
def e2422406411550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406411550 : Closed e2422406411550 ∧ code e2422406411550 = 11218499433758 := by decide
theorem cert_e2422406411550 : check e2422406411550 [[],[]] .chain = true := by decide
def e2422406411718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406411718 : Closed e2422406411718 ∧ code e2422406411718 = 11218499433926 := by decide
theorem cert_e2422406411718 : check e2422406411718 [[],[]] .chain = true := by decide
def e2422406411822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406411822 : Closed e2422406411822 ∧ code e2422406411822 = 11218499434030 := by decide
theorem cert_e2422406411822 : check e2422406411822 [[],[]] .chain = true := by decide
def e2422406412002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406412002 : Closed e2422406412002 ∧ code e2422406412002 = 11218499434210 := by decide
theorem cert_e2422406412002 : check e2422406412002 [[],[]] .chain = true := by decide
def e2422406412014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2422406412014 : Closed e2422406412014 ∧ code e2422406412014 = 11218499434222 := by decide
theorem cert_e2422406412014 : check e2422406412014 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406412054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406412054 : Closed e2422406412054 ∧ code e2422406412054 = 11218499434262 := by decide
theorem cert_e2422406412054 : check e2422406412054 [[],[]] .chain = true := by decide
def e2422406412058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406412058 : Closed e2422406412058 ∧ code e2422406412058 = 11218499434266 := by decide
theorem cert_e2422406412058 : check e2422406412058 [[],[]] .chain = true := by decide
def e2422406412102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406412102 : Closed e2422406412102 ∧ code e2422406412102 = 11218499434310 := by decide
theorem cert_e2422406412102 : check e2422406412102 [[],[]] .chain = true := by decide
def e2422406412130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406412130 : Closed e2422406412130 ∧ code e2422406412130 = 11218499434338 := by decide
theorem cert_e2422406412130 : check e2422406412130 [[],[]] .chain = true := by decide
def e2422406412142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2422406412142 : Closed e2422406412142 ∧ code e2422406412142 = 11218499434350 := by decide
theorem cert_e2422406412142 : check e2422406412142 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406412150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2422406412150 : Closed e2422406412150 ∧ code e2422406412150 = 11218499434358 := by decide
theorem cert_e2422406412150 : check e2422406412150 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406412470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406412470 : Closed e2422406412470 ∧ code e2422406412470 = 11218499434678 := by decide
theorem cert_e2422406412470 : check e2422406412470 [[],[]] .chain = true := by decide
def e2422406412502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406412502 : Closed e2422406412502 ∧ code e2422406412502 = 11218499434710 := by decide
theorem cert_e2422406412502 : check e2422406412502 [[],[]] .chain = true := by decide
def e2422406412506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406412506 : Closed e2422406412506 ∧ code e2422406412506 = 11218499434714 := by decide
theorem cert_e2422406412506 : check e2422406412506 [[],[]] .chain = true := by decide
def e2422406412522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406412522 : Closed e2422406412522 ∧ code e2422406412522 = 11218499434730 := by decide
theorem cert_e2422406412522 : check e2422406412522 [[],[]] .chain = true := by decide
def e2422406412854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406412854 : Closed e2422406412854 ∧ code e2422406412854 = 11218499435062 := by decide
theorem cert_e2422406412854 : check e2422406412854 [[],[]] .chain = true := by decide
def e2422406412858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406412858 : Closed e2422406412858 ∧ code e2422406412858 = 11218499435066 := by decide
theorem cert_e2422406412858 : check e2422406412858 [[],[]] .chain = true := by decide
def e2422406412942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406412942 : Closed e2422406412942 ∧ code e2422406412942 = 11218499435150 := by decide
theorem cert_e2422406412942 : check e2422406412942 [[],[]] .chain = true := by decide
def e2422406412998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406412998 : Closed e2422406412998 ∧ code e2422406412998 = 11218499435206 := by decide
theorem cert_e2422406412998 : check e2422406412998 [[],[]] .chain = true := by decide
def e2422406413078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406413078 : Closed e2422406413078 ∧ code e2422406413078 = 11218499435286 := by decide
theorem cert_e2422406413078 : check e2422406413078 [[],[]] .chain = true := by decide
def e2422406413082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406413082 : Closed e2422406413082 ∧ code e2422406413082 = 11218499435290 := by decide
theorem cert_e2422406413082 : check e2422406413082 [[],[]] .chain = true := by decide
def e2422406413126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406413126 : Closed e2422406413126 ∧ code e2422406413126 = 11218499435334 := by decide
theorem cert_e2422406413126 : check e2422406413126 [[],[]] .chain = true := by decide
def e2422406413154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406413154 : Closed e2422406413154 ∧ code e2422406413154 = 11218499435362 := by decide
theorem cert_e2422406413154 : check e2422406413154 [[],[]] .chain = true := by decide
def e2422406413166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2422406413166 : Closed e2422406413166 ∧ code e2422406413166 = 11218499435374 := by decide
theorem cert_e2422406413166 : check e2422406413166 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406413174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2422406413174 : Closed e2422406413174 ∧ code e2422406413174 = 11218499435382 := by decide
theorem cert_e2422406413174 : check e2422406413174 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406413238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2422406413238 : Closed e2422406413238 ∧ code e2422406413238 = 11218499435446 := by decide
theorem cert_e2422406413238 : check e2422406413238 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406432110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406432110 : Closed e2422406432110 ∧ code e2422406432110 = 11218499454318 := by decide
theorem cert_e2422406432110 : check e2422406432110 [[],[]] .chain = true := by decide
def e2422406432118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406432118 : Closed e2422406432118 ∧ code e2422406432118 = 11218499454326 := by decide
theorem cert_e2422406432118 : check e2422406432118 [[],[]] .chain = true := by decide
def e2422406432174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406432174 : Closed e2422406432174 ∧ code e2422406432174 = 11218499454382 := by decide
theorem cert_e2422406432174 : check e2422406432174 [[],[]] .chain = true := by decide
def e2422406432186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406432186 : Closed e2422406432186 ∧ code e2422406432186 = 11218499454394 := by decide
theorem cert_e2422406432186 : check e2422406432186 [[],[]] .chain = true := by decide
def e2422406432214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406432214 : Closed e2422406432214 ∧ code e2422406432214 = 11218499454422 := by decide
theorem cert_e2422406432214 : check e2422406432214 [[],[]] .chain = true := by decide
def e2422406432218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406432218 : Closed e2422406432218 ∧ code e2422406432218 = 11218499454426 := by decide
theorem cert_e2422406432218 : check e2422406432218 [[],[]] .chain = true := by decide
def e2422406435182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406435182 : Closed e2422406435182 ∧ code e2422406435182 = 11218499457390 := by decide
theorem cert_e2422406435182 : check e2422406435182 [[],[]] .chain = true := by decide
def e2422406435190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406435190 : Closed e2422406435190 ∧ code e2422406435190 = 11218499457398 := by decide
theorem cert_e2422406435190 : check e2422406435190 [[],[]] .chain = true := by decide
def e2422406436398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406436398 : Closed e2422406436398 ∧ code e2422406436398 = 11218499458606 := by decide
theorem cert_e2422406436398 : check e2422406436398 [[],[]] .chain = true := by decide
def e2422406436578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406436578 : Closed e2422406436578 ∧ code e2422406436578 = 11218499458786 := by decide
theorem cert_e2422406436578 : check e2422406436578 [[],[]] .chain = true := by decide
def e2422406436590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2422406436590 : Closed e2422406436590 ∧ code e2422406436590 = 11218499458798 := by decide
theorem cert_e2422406436590 : check e2422406436590 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406436630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406436630 : Closed e2422406436630 ∧ code e2422406436630 = 11218499458838 := by decide
theorem cert_e2422406436630 : check e2422406436630 [[],[]] .chain = true := by decide
def e2422406436706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406436706 : Closed e2422406436706 ∧ code e2422406436706 = 11218499458914 := by decide
theorem cert_e2422406436706 : check e2422406436706 [[],[]] .chain = true := by decide
def e2422406436718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2422406436718 : Closed e2422406436718 ∧ code e2422406436718 = 11218499458926 := by decide
theorem cert_e2422406436718 : check e2422406436718 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406436726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2422406436726 : Closed e2422406436726 ∧ code e2422406436726 = 11218499458934 := by decide
theorem cert_e2422406436726 : check e2422406436726 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406437038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406437038 : Closed e2422406437038 ∧ code e2422406437038 = 11218499459246 := by decide
theorem cert_e2422406437038 : check e2422406437038 [[],[]] .chain = true := by decide
def e2422406437050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406437050 : Closed e2422406437050 ∧ code e2422406437050 = 11218499459258 := by decide
theorem cert_e2422406437050 : check e2422406437050 [[],[]] .chain = true := by decide
def e2422406437422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406437422 : Closed e2422406437422 ∧ code e2422406437422 = 11218499459630 := by decide
theorem cert_e2422406437422 : check e2422406437422 [[],[]] .chain = true := by decide
def e2422406437602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406437602 : Closed e2422406437602 ∧ code e2422406437602 = 11218499459810 := by decide
theorem cert_e2422406437602 : check e2422406437602 [[],[]] .chain = true := by decide
def e2422406437614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2422406437614 : Closed e2422406437614 ∧ code e2422406437614 = 11218499459822 := by decide
theorem cert_e2422406437614 : check e2422406437614 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406437742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2422406437742 : Closed e2422406437742 ∧ code e2422406437742 = 11218499459950 := by decide
theorem cert_e2422406437742 : check e2422406437742 [[],[]] .chain = true := by decide
def e2422406437750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2422406437750 : Closed e2422406437750 ∧ code e2422406437750 = 11218499459958 := by decide
theorem cert_e2422406437750 : check e2422406437750 [[],[]] .chain = true := by decide
def e2422406437770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406437770 : Closed e2422406437770 ∧ code e2422406437770 = 11218499459978 := by decide
theorem cert_e2422406437770 : check e2422406437770 [[],[]] .chain = true := by decide
def e2422406437794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406437794 : Closed e2422406437794 ∧ code e2422406437794 = 11218499460002 := by decide
theorem cert_e2422406437794 : check e2422406437794 [[],[]] .chain = true := by decide
def e2422406437806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2422406437806 : Closed e2422406437806 ∧ code e2422406437806 = 11218499460014 := by decide
theorem cert_e2422406437806 : check e2422406437806 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406437814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2422406437814 : Closed e2422406437814 ∧ code e2422406437814 = 11218499460022 := by decide
theorem cert_e2422406437814 : check e2422406437814 [[],[]] .chain = true := by decide
def e2422406437818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2422406437818 : Closed e2422406437818 ∧ code e2422406437818 = 11218499460026 := by decide
theorem cert_e2422406437818 : check e2422406437818 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406437974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406437974 : Closed e2422406437974 ∧ code e2422406437974 = 11218499460182 := by decide
theorem cert_e2422406437974 : check e2422406437974 [[],[]] .chain = true := by decide
def e2422406437978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406437978 : Closed e2422406437978 ∧ code e2422406437978 = 11218499460186 := by decide
theorem cert_e2422406437978 : check e2422406437978 [[],[]] .chain = true := by decide
def e2422406438166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406438166 : Closed e2422406438166 ∧ code e2422406438166 = 11218499460374 := by decide
theorem cert_e2422406438166 : check e2422406438166 [[],[]] .chain = true := by decide
def e2422406438242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406438242 : Closed e2422406438242 ∧ code e2422406438242 = 11218499460450 := by decide
theorem cert_e2422406438242 : check e2422406438242 [[],[]] .chain = true := by decide
def e2422406438254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406438254 : Closed e2422406438254 ∧ code e2422406438254 = 11218499460462 := by decide
theorem cert_e2422406438254 : check e2422406438254 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406438262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406438262 : Closed e2422406438262 ∧ code e2422406438262 = 11218499460470 := by decide
theorem cert_e2422406438262 : checkPay e2422406438262 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422406438282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406438282 : Closed e2422406438282 ∧ code e2422406438282 = 11218499460490 := by decide
theorem cert_e2422406438282 : check e2422406438282 [[],[]] .chain = true := by decide
def e2422406438306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406438306 : Closed e2422406438306 ∧ code e2422406438306 = 11218499460514 := by decide
theorem cert_e2422406438306 : check e2422406438306 [[],[]] .chain = true := by decide
def e2422406438318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406438318 : Closed e2422406438318 ∧ code e2422406438318 = 11218499460526 := by decide
theorem cert_e2422406438318 : check e2422406438318 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406438326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2422406438326 : Closed e2422406438326 ∧ code e2422406438326 = 11218499460534 := by decide
theorem cert_e2422406438326 : check e2422406438326 [[],[]] .chain = true := by decide
def e2422406438330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406438330 : Closed e2422406438330 ∧ code e2422406438330 = 11218499460538 := by decide
theorem cert_e2422406438330 : check e2422406438330 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406438358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406438358 : Closed e2422406438358 ∧ code e2422406438358 = 11218499460566 := by decide
theorem cert_e2422406438358 : check e2422406438358 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406438362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406438362 : Closed e2422406438362 ∧ code e2422406438362 = 11218499460570 := by decide
theorem cert_e2422406438362 : check e2422406438362 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406439598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406439598 : Closed e2422406439598 ∧ code e2422406439598 = 11218499461806 := by decide
theorem cert_e2422406439598 : check e2422406439598 [[],[]] .chain = true := by decide
def e2422406439610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406439610 : Closed e2422406439610 ∧ code e2422406439610 = 11218499461818 := by decide
theorem cert_e2422406439610 : check e2422406439610 [[],[]] .chain = true := by decide
def e2422406439658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406439658 : Closed e2422406439658 ∧ code e2422406439658 = 11218499461866 := by decide
theorem cert_e2422406439658 : check e2422406439658 [[],[]] .chain = true := by decide
def e2422406441134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406441134 : Closed e2422406441134 ∧ code e2422406441134 = 11218499463342 := by decide
theorem cert_e2422406441134 : check e2422406441134 [[],[]] .chain = true := by decide
def e2422406441146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406441146 : Closed e2422406441146 ∧ code e2422406441146 = 11218499463354 := by decide
theorem cert_e2422406441146 : check e2422406441146 [[],[]] .chain = true := by decide
def e2422406441518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406441518 : Closed e2422406441518 ∧ code e2422406441518 = 11218499463726 := by decide
theorem cert_e2422406441518 : check e2422406441518 [[],[]] .chain = true := by decide
def e2422406441698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406441698 : Closed e2422406441698 ∧ code e2422406441698 = 11218499463906 := by decide
theorem cert_e2422406441698 : check e2422406441698 [[],[]] .chain = true := by decide
def e2422406441710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2422406441710 : Closed e2422406441710 ∧ code e2422406441710 = 11218499463918 := by decide
theorem cert_e2422406441710 : check e2422406441710 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406441838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2422406441838 : Closed e2422406441838 ∧ code e2422406441838 = 11218499464046 := by decide
theorem cert_e2422406441838 : check e2422406441838 [[],[]] .chain = true := by decide
def e2422406441846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2422406441846 : Closed e2422406441846 ∧ code e2422406441846 = 11218499464054 := by decide
theorem cert_e2422406441846 : check e2422406441846 [[],[]] .chain = true := by decide
def e2422406441866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406441866 : Closed e2422406441866 ∧ code e2422406441866 = 11218499464074 := by decide
theorem cert_e2422406441866 : check e2422406441866 [[],[]] .chain = true := by decide
def e2422406441890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406441890 : Closed e2422406441890 ∧ code e2422406441890 = 11218499464098 := by decide
theorem cert_e2422406441890 : check e2422406441890 [[],[]] .chain = true := by decide
def e2422406441902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2422406441902 : Closed e2422406441902 ∧ code e2422406441902 = 11218499464110 := by decide
theorem cert_e2422406441902 : check e2422406441902 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406441910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2422406441910 : Closed e2422406441910 ∧ code e2422406441910 = 11218499464118 := by decide
theorem cert_e2422406441910 : check e2422406441910 [[],[]] .chain = true := by decide
def e2422406441914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2422406441914 : Closed e2422406441914 ∧ code e2422406441914 = 11218499464122 := by decide
theorem cert_e2422406441914 : check e2422406441914 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406442350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406442350 : Closed e2422406442350 ∧ code e2422406442350 = 11218499464558 := by decide
theorem cert_e2422406442350 : check e2422406442350 [[],[]] .chain = true := by decide
def e2422406442358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406442358 : Closed e2422406442358 ∧ code e2422406442358 = 11218499464566 := by decide
theorem cert_e2422406442358 : check e2422406442358 [[],[]] .chain = true := by decide
def e2422406442414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406442414 : Closed e2422406442414 ∧ code e2422406442414 = 11218499464622 := by decide
theorem cert_e2422406442414 : check e2422406442414 [[],[]] .chain = true := by decide
def e2422406442426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406442426 : Closed e2422406442426 ∧ code e2422406442426 = 11218499464634 := by decide
theorem cert_e2422406442426 : check e2422406442426 [[],[]] .chain = true := by decide
def e2422406442454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406442454 : Closed e2422406442454 ∧ code e2422406442454 = 11218499464662 := by decide
theorem cert_e2422406442454 : check e2422406442454 [[],[]] .chain = true := by decide
def e2422406442458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406442458 : Closed e2422406442458 ∧ code e2422406442458 = 11218499464666 := by decide
theorem cert_e2422406442458 : check e2422406442458 [[],[]] .chain = true := by decide
def e2422406442538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406442538 : Closed e2422406442538 ∧ code e2422406442538 = 11218499464746 := by decide
theorem cert_e2422406442538 : check e2422406442538 [[],[]] .chain = true := by decide
def e2422406442634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406442634 : Closed e2422406442634 ∧ code e2422406442634 = 11218499464842 := by decide
theorem cert_e2422406442634 : check e2422406442634 [[],[]] .chain = true := by decide
def e2422406442658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406442658 : Closed e2422406442658 ∧ code e2422406442658 = 11218499464866 := by decide
theorem cert_e2422406442658 : check e2422406442658 [[],[]] .chain = true := by decide
def e2422406442670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406442670 : Closed e2422406442670 ∧ code e2422406442670 = 11218499464878 := by decide
theorem cert_e2422406442670 : check e2422406442670 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406442678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406442678 : Closed e2422406442678 ∧ code e2422406442678 = 11218499464886 := by decide
theorem cert_e2422406442678 : check e2422406442678 [[],[]] .chain = true := by decide
end Blc.Floor43
