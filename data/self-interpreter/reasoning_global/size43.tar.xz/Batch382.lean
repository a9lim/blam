import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364664534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422364664534 : Closed e2422364664534 ∧ code e2422364664534 = 11218457686742 := by decide
theorem cert_e2422364664534 : check e2422364664534 [[],[]] .smaller = true := by decide
def e2422364664538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422364664538 : Closed e2422364664538 ∧ code e2422364664538 = 11218457686746 := by decide
theorem cert_e2422364664538 : check e2422364664538 [[],[]] .smaller = true := by decide
def e2422364664554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422364664554 : Closed e2422364664554 ∧ code e2422364664554 = 11218457686762 := by decide
theorem cert_e2422364664554 : check e2422364664554 [[],[]] .smaller = true := by decide
def e2422364664630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364664630 : Closed e2422364664630 ∧ code e2422364664630 = 11218457686838 := by decide
theorem cert_e2422364664630 : check e2422364664630 [[],[]] .smaller = true := by decide
def e2422364664634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364664634 : Closed e2422364664634 ∧ code e2422364664634 = 11218457686842 := by decide
theorem cert_e2422364664634 : check e2422364664634 [[],[]] .smaller = true := by decide
def e2422364664730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364664730 : Closed e2422364664730 ∧ code e2422364664730 = 11218457686938 := by decide
theorem cert_e2422364664730 : check e2422364664730 [[],[]] .smaller = true := by decide
def e2422364664766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2422364664766 : Closed e2422364664766 ∧ code e2422364664766 = 11218457686974 := by decide
theorem cert_e2422364664766 : check e2422364664766 [[],[]] .three = true := by decide
def e2422364664822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2422364664822 : Closed e2422364664822 ∧ code e2422364664822 = 11218457687030 := by decide
theorem cert_e2422364664822 : check e2422364664822 [[],[]] .three = true := by decide
def e2422364665974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364665974 : Closed e2422364665974 ∧ code e2422364665974 = 11218457688182 := by decide
theorem cert_e2422364665974 : check e2422364665974 [[],[]] .smaller = true := by decide
def e2422364666218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422364666218 : Closed e2422364666218 ∧ code e2422364666218 = 11218457688426 := by decide
theorem cert_e2422364666218 : check e2422364666218 [[],[]] .smaller = true := by decide
def e2422364666266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364666266 : Closed e2422364666266 ∧ code e2422364666266 = 11218457688474 := by decide
theorem cert_e2422364666266 : check e2422364666266 [[],[]] .smaller = true := by decide
def e2422364666334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364666334 : Closed e2422364666334 ∧ code e2422364666334 = 11218457688542 := by decide
theorem cert_e2422364666334 : check e2422364666334 [[],[]] .smaller = true := by decide
def e2422364666358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364666358 : Closed e2422364666358 ∧ code e2422364666358 = 11218457688566 := by decide
theorem cert_e2422364666358 : check e2422364666358 [[],[]] .smaller = true := by decide
def e2422364667078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422364667078 : Closed e2422364667078 ∧ code e2422364667078 = 11218457689286 := by decide
theorem cert_e2422364667078 : check e2422364667078 [[],[]] .three = true := by decide
def e2422364667118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364667118 : Closed e2422364667118 ∧ code e2422364667118 = 11218457689326 := by decide
theorem cert_e2422364667118 : check e2422364667118 [[],[]] .three = true := by decide
def e2422364667126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364667126 : Closed e2422364667126 ∧ code e2422364667126 = 11218457689334 := by decide
theorem cert_e2422364667126 : check e2422364667126 [[],[]] .three = true := by decide
def e2422364669806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e2422364669806 : Closed e2422364669806 ∧ code e2422364669806 = 11218457692014 := by decide
theorem cert_e2422364669806 : check e2422364669806 [[],[]] .smaller = true := by decide
def e2422364669814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))))
theorem wire_e2422364669814 : Closed e2422364669814 ∧ code e2422364669814 = 11218457692022 := by decide
theorem cert_e2422364669814 : check e2422364669814 [[],[]] .smaller = true := by decide
def e2422364669818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e2422364669818 : Closed e2422364669818 ∧ code e2422364669818 = 11218457692026 := by decide
theorem cert_e2422364669818 : check e2422364669818 [[],[]] .smaller = true := by decide
def e2422364669878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))))
theorem wire_e2422364669878 : Closed e2422364669878 ∧ code e2422364669878 = 11218457692086 := by decide
theorem cert_e2422364669878 : check e2422364669878 [[],[]] .smaller = true := by decide
def e2422364669882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))))
theorem wire_e2422364669882 : Closed e2422364669882 ∧ code e2422364669882 = 11218457692090 := by decide
theorem cert_e2422364669882 : check e2422364669882 [[],[]] .smaller = true := by decide
def e2422364669914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e2422364669914 : Closed e2422364669914 ∧ code e2422364669914 = 11218457692122 := by decide
theorem cert_e2422364669914 : check e2422364669914 [[],[]] .smaller = true := by decide
def e2422364673710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e2422364673710 : Closed e2422364673710 ∧ code e2422364673710 = 11218457695918 := by decide
theorem cert_e2422364673710 : check e2422364673710 [[],[]] .smaller = true := by decide
def e2422364673718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))))
theorem wire_e2422364673718 : Closed e2422364673718 ∧ code e2422364673718 = 11218457695926 := by decide
theorem cert_e2422364673718 : check e2422364673718 [[],[]] .smaller = true := by decide
def e2422364673722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e2422364673722 : Closed e2422364673722 ∧ code e2422364673722 = 11218457695930 := by decide
theorem cert_e2422364673722 : check e2422364673722 [[],[]] .smaller = true := by decide
def e2422364673750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))))
theorem wire_e2422364673750 : Closed e2422364673750 ∧ code e2422364673750 = 11218457695958 := by decide
theorem cert_e2422364673750 : check e2422364673750 [[],[]] .smaller = true := by decide
def e2422364673754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))))
theorem wire_e2422364673754 : Closed e2422364673754 ∧ code e2422364673754 = 11218457695962 := by decide
theorem cert_e2422364673754 : check e2422364673754 [[],[]] .smaller = true := by decide
def e2422364673770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e2422364673770 : Closed e2422364673770 ∧ code e2422364673770 = 11218457695978 := by decide
theorem cert_e2422364673770 : check e2422364673770 [[],[]] .smaller = true := by decide
def e2422364673878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e2422364673878 : Closed e2422364673878 ∧ code e2422364673878 = 11218457696086 := by decide
theorem cert_e2422364673878 : check e2422364673878 [[],[]] .smaller = true := by decide
def e2422364673882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e2422364673882 : Closed e2422364673882 ∧ code e2422364673882 = 11218457696090 := by decide
theorem cert_e2422364673882 : check e2422364673882 [[],[]] .smaller = true := by decide
def e2422364673898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e2422364673898 : Closed e2422364673898 ∧ code e2422364673898 = 11218457696106 := by decide
theorem cert_e2422364673898 : check e2422364673898 [[],[]] .smaller = true := by decide
def e2422364673962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422364673962 : Closed e2422364673962 ∧ code e2422364673962 = 11218457696170 := by decide
theorem cert_e2422364673962 : check e2422364673962 [[],[]] .smaller = true := by decide
def e2422364674478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422364674478 : Closed e2422364674478 ∧ code e2422364674478 = 11218457696686 := by decide
theorem cert_e2422364674478 : check e2422364674478 [[],[]] .smaller = true := by decide
def e2422364674486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e2422364674486 : Closed e2422364674486 ∧ code e2422364674486 = 11218457696694 := by decide
theorem cert_e2422364674486 : check e2422364674486 [[],[]] .smaller = true := by decide
def e2422364674490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422364674490 : Closed e2422364674490 ∧ code e2422364674490 = 11218457696698 := by decide
theorem cert_e2422364674490 : check e2422364674490 [[],[]] .smaller = true := by decide
def e2422364674518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e2422364674518 : Closed e2422364674518 ∧ code e2422364674518 = 11218457696726 := by decide
theorem cert_e2422364674518 : check e2422364674518 [[],[]] .smaller = true := by decide
def e2422364674522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))))
theorem wire_e2422364674522 : Closed e2422364674522 ∧ code e2422364674522 = 11218457696730 := by decide
theorem cert_e2422364674522 : check e2422364674522 [[],[]] .smaller = true := by decide
def e2422364674538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422364674538 : Closed e2422364674538 ∧ code e2422364674538 = 11218457696746 := by decide
theorem cert_e2422364674538 : check e2422364674538 [[],[]] .smaller = true := by decide
def e2422364674670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364674670 : Closed e2422364674670 ∧ code e2422364674670 = 11218457696878 := by decide
theorem cert_e2422364674670 : check e2422364674670 [[],[]] .smaller = true := by decide
def e2422364674678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364674678 : Closed e2422364674678 ∧ code e2422364674678 = 11218457696886 := by decide
theorem cert_e2422364674678 : check e2422364674678 [[],[]] .smaller = true := by decide
def e2422364674682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364674682 : Closed e2422364674682 ∧ code e2422364674682 = 11218457696890 := by decide
theorem cert_e2422364674682 : check e2422364674682 [[],[]] .smaller = true := by decide
def e2422364674870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364674870 : Closed e2422364674870 ∧ code e2422364674870 = 11218457697078 := by decide
theorem cert_e2422364674870 : check e2422364674870 [[],[]] .smaller = true := by decide
def e2422364674874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364674874 : Closed e2422364674874 ∧ code e2422364674874 = 11218457697082 := by decide
theorem cert_e2422364674874 : check e2422364674874 [[],[]] .smaller = true := by decide
def e2422364674970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364674970 : Closed e2422364674970 ∧ code e2422364674970 = 11218457697178 := by decide
theorem cert_e2422364674970 : check e2422364674970 [[],[]] .smaller = true := by decide
def e2422364675286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422364675286 : Closed e2422364675286 ∧ code e2422364675286 = 11218457697494 := by decide
theorem cert_e2422364675286 : check e2422364675286 [[],[]] .smaller = true := by decide
def e2422364675290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422364675290 : Closed e2422364675290 ∧ code e2422364675290 = 11218457697498 := by decide
theorem cert_e2422364675290 : check e2422364675290 [[],[]] .smaller = true := by decide
def e2422364675306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422364675306 : Closed e2422364675306 ∧ code e2422364675306 = 11218457697514 := by decide
theorem cert_e2422364675306 : check e2422364675306 [[],[]] .smaller = true := by decide
def e2422364675382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364675382 : Closed e2422364675382 ∧ code e2422364675382 = 11218457697590 := by decide
theorem cert_e2422364675382 : check e2422364675382 [[],[]] .smaller = true := by decide
def e2422364675386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364675386 : Closed e2422364675386 ∧ code e2422364675386 = 11218457697594 := by decide
theorem cert_e2422364675386 : check e2422364675386 [[],[]] .smaller = true := by decide
def e2422364675482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364675482 : Closed e2422364675482 ∧ code e2422364675482 = 11218457697690 := by decide
theorem cert_e2422364675482 : check e2422364675482 [[],[]] .smaller = true := by decide
def e2422364675518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 4))))))))
theorem wire_e2422364675518 : Closed e2422364675518 ∧ code e2422364675518 = 11218457697726 := by decide
theorem cert_e2422364675518 : check e2422364675518 [[],[]] .three = true := by decide
def e2422364675550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e2422364675550 : Closed e2422364675550 ∧ code e2422364675550 = 11218457697758 := by decide
theorem cert_e2422364675550 : check e2422364675550 [[],[]] .smaller = true := by decide
def e2422364675566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e2422364675566 : Closed e2422364675566 ∧ code e2422364675566 = 11218457697774 := by decide
theorem cert_e2422364675566 : check e2422364675566 [[],[]] .smaller = true := by decide
def e2422364675574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 4))) (.var 1))))))))
theorem wire_e2422364675574 : Closed e2422364675574 ∧ code e2422364675574 = 11218457697782 := by decide
theorem cert_e2422364675574 : check e2422364675574 [[],[]] .three = true := by decide
def e2422364675690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422364675690 : Closed e2422364675690 ∧ code e2422364675690 = 11218457697898 := by decide
theorem cert_e2422364675690 : check e2422364675690 [[],[]] .smaller = true := by decide
def e2422364675738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364675738 : Closed e2422364675738 ∧ code e2422364675738 = 11218457697946 := by decide
theorem cert_e2422364675738 : check e2422364675738 [[],[]] .smaller = true := by decide
def e2422364675806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e2422364675806 : Closed e2422364675806 ∧ code e2422364675806 = 11218457698014 := by decide
theorem cert_e2422364675806 : check e2422364675806 [[],[]] .smaller = true := by decide
def e2422364675830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e2422364675830 : Closed e2422364675830 ∧ code e2422364675830 = 11218457698038 := by decide
theorem cert_e2422364675830 : check e2422364675830 [[],[]] .smaller = true := by decide
def e2422364675950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e2422364675950 : Closed e2422364675950 ∧ code e2422364675950 = 11218457698158 := by decide
theorem cert_e2422364675950 : check e2422364675950 [[],[]] .smaller = true := by decide
def e2422364675958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e2422364675958 : Closed e2422364675958 ∧ code e2422364675958 = 11218457698166 := by decide
theorem cert_e2422364675958 : check e2422364675958 [[],[]] .smaller = true := by decide
def e2422364676022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 4) (.var 1))) (.var 1))))))))
theorem wire_e2422364676022 : Closed e2422364676022 ∧ code e2422364676022 = 11218457698230 := by decide
theorem cert_e2422364676022 : check e2422364676022 [[],[]] .three = true := by decide
def e2422364676574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422364676574 : Closed e2422364676574 ∧ code e2422364676574 = 11218457698782 := by decide
theorem cert_e2422364676574 : check e2422364676574 [[],[]] .smaller = true := by decide
def e2422364676590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e2422364676590 : Closed e2422364676590 ∧ code e2422364676590 = 11218457698798 := by decide
theorem cert_e2422364676590 : check e2422364676590 [[],[]] .smaller = true := by decide
def e2422364676598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422364676598 : Closed e2422364676598 ∧ code e2422364676598 = 11218457698806 := by decide
theorem cert_e2422364676598 : check e2422364676598 [[],[]] .smaller = true := by decide
def e2422364677550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422364677550 : Closed e2422364677550 ∧ code e2422364677550 = 11218457699758 := by decide
theorem cert_e2422364677550 : check e2422364677550 [[],[]] .smaller = true := by decide
def e2422364677558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2422364677558 : Closed e2422364677558 ∧ code e2422364677558 = 11218457699766 := by decide
theorem cert_e2422364677558 : check e2422364677558 [[],[]] .smaller = true := by decide
def e2422364677562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422364677562 : Closed e2422364677562 ∧ code e2422364677562 = 11218457699770 := by decide
theorem cert_e2422364677562 : check e2422364677562 [[],[]] .smaller = true := by decide
def e2422364677590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2422364677590 : Closed e2422364677590 ∧ code e2422364677590 = 11218457699798 := by decide
theorem cert_e2422364677590 : check e2422364677590 [[],[]] .smaller = true := by decide
def e2422364677594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2422364677594 : Closed e2422364677594 ∧ code e2422364677594 = 11218457699802 := by decide
theorem cert_e2422364677594 : check e2422364677594 [[],[]] .smaller = true := by decide
def e2422364677610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422364677610 : Closed e2422364677610 ∧ code e2422364677610 = 11218457699818 := by decide
theorem cert_e2422364677610 : check e2422364677610 [[],[]] .smaller = true := by decide
def e2422364677742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364677742 : Closed e2422364677742 ∧ code e2422364677742 = 11218457699950 := by decide
theorem cert_e2422364677742 : check e2422364677742 [[],[]] .smaller = true := by decide
def e2422364677750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364677750 : Closed e2422364677750 ∧ code e2422364677750 = 11218457699958 := by decide
theorem cert_e2422364677750 : check e2422364677750 [[],[]] .smaller = true := by decide
def e2422364677754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364677754 : Closed e2422364677754 ∧ code e2422364677754 = 11218457699962 := by decide
theorem cert_e2422364677754 : check e2422364677754 [[],[]] .smaller = true := by decide
def e2422364677942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364677942 : Closed e2422364677942 ∧ code e2422364677942 = 11218457700150 := by decide
theorem cert_e2422364677942 : check e2422364677942 [[],[]] .smaller = true := by decide
def e2422364677946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364677946 : Closed e2422364677946 ∧ code e2422364677946 = 11218457700154 := by decide
theorem cert_e2422364677946 : check e2422364677946 [[],[]] .smaller = true := by decide
def e2422364678042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364678042 : Closed e2422364678042 ∧ code e2422364678042 = 11218457700250 := by decide
theorem cert_e2422364678042 : check e2422364678042 [[],[]] .smaller = true := by decide
def e2422364680430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364680430 : Closed e2422364680430 ∧ code e2422364680430 = 11218457702638 := by decide
theorem cert_e2422364680430 : check e2422364680430 [[],[]] .smaller = true := by decide
def e2422364680438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364680438 : Closed e2422364680438 ∧ code e2422364680438 = 11218457702646 := by decide
theorem cert_e2422364680438 : check e2422364680438 [[],[]] .smaller = true := by decide
def e2422364680918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422364680918 : Closed e2422364680918 ∧ code e2422364680918 = 11218457703126 := by decide
theorem cert_e2422364680918 : check e2422364680918 [[],[]] .smaller = true := by decide
def e2422364680922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422364680922 : Closed e2422364680922 ∧ code e2422364680922 = 11218457703130 := by decide
theorem cert_e2422364680922 : check e2422364680922 [[],[]] .smaller = true := by decide
def e2422364680938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422364680938 : Closed e2422364680938 ∧ code e2422364680938 = 11218457703146 := by decide
theorem cert_e2422364680938 : check e2422364680938 [[],[]] .smaller = true := by decide
def e2422364681014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364681014 : Closed e2422364681014 ∧ code e2422364681014 = 11218457703222 := by decide
theorem cert_e2422364681014 : check e2422364681014 [[],[]] .smaller = true := by decide
def e2422364681018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364681018 : Closed e2422364681018 ∧ code e2422364681018 = 11218457703226 := by decide
theorem cert_e2422364681018 : check e2422364681018 [[],[]] .smaller = true := by decide
def e2422364681114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364681114 : Closed e2422364681114 ∧ code e2422364681114 = 11218457703322 := by decide
theorem cert_e2422364681114 : check e2422364681114 [[],[]] .smaller = true := by decide
def e2422364681150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2422364681150 : Closed e2422364681150 ∧ code e2422364681150 = 11218457703358 := by decide
theorem cert_e2422364681150 : check e2422364681150 [[],[]] .three = true := by decide
def e2422364681182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422364681182 : Closed e2422364681182 ∧ code e2422364681182 = 11218457703390 := by decide
theorem cert_e2422364681182 : check e2422364681182 [[],[]] .smaller = true := by decide
def e2422364681198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422364681198 : Closed e2422364681198 ∧ code e2422364681198 = 11218457703406 := by decide
theorem cert_e2422364681198 : check e2422364681198 [[],[]] .smaller = true := by decide
def e2422364681206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2422364681206 : Closed e2422364681206 ∧ code e2422364681206 = 11218457703414 := by decide
theorem cert_e2422364681206 : check e2422364681206 [[],[]] .three = true := by decide
def e2422364682358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364682358 : Closed e2422364682358 ∧ code e2422364682358 = 11218457704566 := by decide
theorem cert_e2422364682358 : check e2422364682358 [[],[]] .smaller = true := by decide
def e2422364682602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422364682602 : Closed e2422364682602 ∧ code e2422364682602 = 11218457704810 := by decide
theorem cert_e2422364682602 : check e2422364682602 [[],[]] .smaller = true := by decide
def e2422364682650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364682650 : Closed e2422364682650 ∧ code e2422364682650 = 11218457704858 := by decide
theorem cert_e2422364682650 : check e2422364682650 [[],[]] .smaller = true := by decide
def e2422364682718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364682718 : Closed e2422364682718 ∧ code e2422364682718 = 11218457704926 := by decide
theorem cert_e2422364682718 : check e2422364682718 [[],[]] .smaller = true := by decide
def e2422364682742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364682742 : Closed e2422364682742 ∧ code e2422364682742 = 11218457704950 := by decide
theorem cert_e2422364682742 : check e2422364682742 [[],[]] .smaller = true := by decide
def e2422364683502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364683502 : Closed e2422364683502 ∧ code e2422364683502 = 11218457705710 := by decide
theorem cert_e2422364683502 : check e2422364683502 [[],[]] .smaller = true := by decide
def e2422364683510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364683510 : Closed e2422364683510 ∧ code e2422364683510 = 11218457705718 := by decide
theorem cert_e2422364683510 : check e2422364683510 [[],[]] .smaller = true := by decide
def e2422364683894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 4)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364683894 : Closed e2422364683894 ∧ code e2422364683894 = 11218457706102 := by decide
theorem cert_e2422364683894 : check e2422364683894 [[],[]] .three = true := by decide
def e2422364685238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e2422364685238 : Closed e2422364685238 ∧ code e2422364685238 = 11218457707446 := by decide
theorem cert_e2422364685238 : check e2422364685238 [[],[]] .three = true := by decide
def e2422364685242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e2422364685242 : Closed e2422364685242 ∧ code e2422364685242 = 11218457707450 := by decide
theorem cert_e2422364685242 : check e2422364685242 [[],[]] .three = true := by decide
def e2422364685274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e2422364685274 : Closed e2422364685274 ∧ code e2422364685274 = 11218457707482 := by decide
theorem cert_e2422364685274 : check e2422364685274 [[],[]] .three = true := by decide
def e2422364685934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364685934 : Closed e2422364685934 ∧ code e2422364685934 = 11218457708142 := by decide
theorem cert_e2422364685934 : check e2422364685934 [[],[]] .three = true := by decide
def e2422364685942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364685942 : Closed e2422364685942 ∧ code e2422364685942 = 11218457708150 := by decide
theorem cert_e2422364685942 : check e2422364685942 [[],[]] .three = true := by decide
def e2422364685946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364685946 : Closed e2422364685946 ∧ code e2422364685946 = 11218457708154 := by decide
theorem cert_e2422364685946 : check e2422364685946 [[],[]] .three = true := by decide
def e2422364686134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364686134 : Closed e2422364686134 ∧ code e2422364686134 = 11218457708342 := by decide
theorem cert_e2422364686134 : check e2422364686134 [[],[]] .three = true := by decide
def e2422364686138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364686138 : Closed e2422364686138 ∧ code e2422364686138 = 11218457708346 := by decide
theorem cert_e2422364686138 : check e2422364686138 [[],[]] .three = true := by decide
def e2422364686234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364686234 : Closed e2422364686234 ∧ code e2422364686234 = 11218457708442 := by decide
theorem cert_e2422364686234 : check e2422364686234 [[],[]] .three = true := by decide
def e2422364687190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e2422364687190 : Closed e2422364687190 ∧ code e2422364687190 = 11218457709398 := by decide
theorem cert_e2422364687190 : check e2422364687190 [[],[]] .three = true := by decide
def e2422364687194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e2422364687194 : Closed e2422364687194 ∧ code e2422364687194 = 11218457709402 := by decide
theorem cert_e2422364687194 : check e2422364687194 [[],[]] .three = true := by decide
def e2422364687210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e2422364687210 : Closed e2422364687210 ∧ code e2422364687210 = 11218457709418 := by decide
theorem cert_e2422364687210 : check e2422364687210 [[],[]] .three = true := by decide
def e2422364687274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422364687274 : Closed e2422364687274 ∧ code e2422364687274 = 11218457709482 := by decide
theorem cert_e2422364687274 : check e2422364687274 [[],[]] .three = true := by decide
def e2422364687470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e2422364687470 : Closed e2422364687470 ∧ code e2422364687470 = 11218457709678 := by decide
theorem cert_e2422364687470 : check e2422364687470 [[],[]] .three = true := by decide
def e2422364687478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422364687478 : Closed e2422364687478 ∧ code e2422364687478 = 11218457709686 := by decide
theorem cert_e2422364687478 : check e2422364687478 [[],[]] .three = true := by decide
def e2422364687482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422364687482 : Closed e2422364687482 ∧ code e2422364687482 = 11218457709690 := by decide
theorem cert_e2422364687482 : check e2422364687482 [[],[]] .three = true := by decide
def e2422364687574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422364687574 : Closed e2422364687574 ∧ code e2422364687574 = 11218457709782 := by decide
theorem cert_e2422364687574 : check e2422364687574 [[],[]] .three = true := by decide
def e2422364687578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422364687578 : Closed e2422364687578 ∧ code e2422364687578 = 11218457709786 := by decide
theorem cert_e2422364687578 : check e2422364687578 [[],[]] .three = true := by decide
def e2422364687594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422364687594 : Closed e2422364687594 ∧ code e2422364687594 = 11218457709802 := by decide
theorem cert_e2422364687594 : check e2422364687594 [[],[]] .three = true := by decide
def e2422364687646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e2422364687646 : Closed e2422364687646 ∧ code e2422364687646 = 11218457709854 := by decide
theorem cert_e2422364687646 : check e2422364687646 [[],[]] .three = true := by decide
def e2422364687670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364687670 : Closed e2422364687670 ∧ code e2422364687670 = 11218457709878 := by decide
theorem cert_e2422364687670 : check e2422364687670 [[],[]] .three = true := by decide
def e2422364687674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364687674 : Closed e2422364687674 ∧ code e2422364687674 = 11218457709882 := by decide
theorem cert_e2422364687674 : check e2422364687674 [[],[]] .three = true := by decide
def e2422364687758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422364687758 : Closed e2422364687758 ∧ code e2422364687758 = 11218457709966 := by decide
theorem cert_e2422364687758 : check e2422364687758 [[],[]] .three = true := by decide
def e2422364687770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364687770 : Closed e2422364687770 ∧ code e2422364687770 = 11218457709978 := by decide
theorem cert_e2422364687770 : check e2422364687770 [[],[]] .three = true := by decide
def e2422364687806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 4))))))))
theorem wire_e2422364687806 : Closed e2422364687806 ∧ code e2422364687806 = 11218457710014 := by decide
theorem cert_e2422364687806 : check e2422364687806 [[],[]] .three = true := by decide
def e2422364687814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422364687814 : Closed e2422364687814 ∧ code e2422364687814 = 11218457710022 := by decide
theorem cert_e2422364687814 : check e2422364687814 [[],[]] .three = true := by decide
def e2422364687862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 4))) (.var 1))))))))
theorem wire_e2422364687862 : Closed e2422364687862 ∧ code e2422364687862 = 11218457710070 := by decide
theorem cert_e2422364687862 : check e2422364687862 [[],[]] .three = true := by decide
def e2422364687926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422364687926 : Closed e2422364687926 ∧ code e2422364687926 = 11218457710134 := by decide
theorem cert_e2422364687926 : check e2422364687926 [[],[]] .three = true := by decide
def e2422364687930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422364687930 : Closed e2422364687930 ∧ code e2422364687930 = 11218457710138 := by decide
theorem cert_e2422364687930 : check e2422364687930 [[],[]] .three = true := by decide
def e2422364687978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422364687978 : Closed e2422364687978 ∧ code e2422364687978 = 11218457710186 := by decide
theorem cert_e2422364687978 : check e2422364687978 [[],[]] .three = true := by decide
def e2422364688014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422364688014 : Closed e2422364688014 ∧ code e2422364688014 = 11218457710222 := by decide
theorem cert_e2422364688014 : check e2422364688014 [[],[]] .three = true := by decide
def e2422364688026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364688026 : Closed e2422364688026 ∧ code e2422364688026 = 11218457710234 := by decide
theorem cert_e2422364688026 : check e2422364688026 [[],[]] .three = true := by decide
def e2422364688062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 4))))))))
theorem wire_e2422364688062 : Closed e2422364688062 ∧ code e2422364688062 = 11218457710270 := by decide
theorem cert_e2422364688062 : check e2422364688062 [[],[]] .three = true := by decide
def e2422364688070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422364688070 : Closed e2422364688070 ∧ code e2422364688070 = 11218457710278 := by decide
theorem cert_e2422364688070 : check e2422364688070 [[],[]] .three = true := by decide
def e2422364688094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e2422364688094 : Closed e2422364688094 ∧ code e2422364688094 = 11218457710302 := by decide
theorem cert_e2422364688094 : check e2422364688094 [[],[]] .three = true := by decide
def e2422364688110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e2422364688110 : Closed e2422364688110 ∧ code e2422364688110 = 11218457710318 := by decide
theorem cert_e2422364688110 : check e2422364688110 [[],[]] .three = true := by decide
def e2422364688118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e2422364688118 : Closed e2422364688118 ∧ code e2422364688118 = 11218457710326 := by decide
theorem cert_e2422364688118 : check e2422364688118 [[],[]] .three = true := by decide
def e2422364688122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 4))) (.var 0))))))))
theorem wire_e2422364688122 : Closed e2422364688122 ∧ code e2422364688122 = 11218457710330 := by decide
theorem cert_e2422364688122 : check e2422364688122 [[],[]] .three = true := by decide
def e2422364688154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422364688154 : Closed e2422364688154 ∧ code e2422364688154 = 11218457710362 := by decide
theorem cert_e2422364688154 : check e2422364688154 [[],[]] .three = true := by decide
def e2422364688198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422364688198 : Closed e2422364688198 ∧ code e2422364688198 = 11218457710406 := by decide
theorem cert_e2422364688198 : check e2422364688198 [[],[]] .three = true := by decide
def e2422364688238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e2422364688238 : Closed e2422364688238 ∧ code e2422364688238 = 11218457710446 := by decide
theorem cert_e2422364688238 : check e2422364688238 [[],[]] .three = true := by decide
def e2422364688246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e2422364688246 : Closed e2422364688246 ∧ code e2422364688246 = 11218457710454 := by decide
theorem cert_e2422364688246 : check e2422364688246 [[],[]] .three = true := by decide
def e2422364688310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e2422364688310 : Closed e2422364688310 ∧ code e2422364688310 = 11218457710518 := by decide
theorem cert_e2422364688310 : check e2422364688310 [[],[]] .three = true := by decide
def e2422364688342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 4) (.var 0))) (.var 1))))))))
theorem wire_e2422364688342 : Closed e2422364688342 ∧ code e2422364688342 = 11218457710550 := by decide
theorem cert_e2422364688342 : check e2422364688342 [[],[]] .three = true := by decide
def e2422364688346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 4) (.var 1))) (.var 0))))))))
theorem wire_e2422364688346 : Closed e2422364688346 ∧ code e2422364688346 = 11218457710554 := by decide
theorem cert_e2422364688346 : check e2422364688346 [[],[]] .three = true := by decide
def e2422364688622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364688622 : Closed e2422364688622 ∧ code e2422364688622 = 11218457710830 := by decide
theorem cert_e2422364688622 : check e2422364688622 [[],[]] .three = true := by decide
def e2422364688630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364688630 : Closed e2422364688630 ∧ code e2422364688630 = 11218457710838 := by decide
theorem cert_e2422364688630 : check e2422364688630 [[],[]] .three = true := by decide
def e2422364689110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422364689110 : Closed e2422364689110 ∧ code e2422364689110 = 11218457711318 := by decide
theorem cert_e2422364689110 : check e2422364689110 [[],[]] .three = true := by decide
def e2422364689114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422364689114 : Closed e2422364689114 ∧ code e2422364689114 = 11218457711322 := by decide
theorem cert_e2422364689114 : check e2422364689114 [[],[]] .three = true := by decide
def e2422364689130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422364689130 : Closed e2422364689130 ∧ code e2422364689130 = 11218457711338 := by decide
theorem cert_e2422364689130 : check e2422364689130 [[],[]] .three = true := by decide
def e2422364689182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422364689182 : Closed e2422364689182 ∧ code e2422364689182 = 11218457711390 := by decide
theorem cert_e2422364689182 : check e2422364689182 [[],[]] .three = true := by decide
def e2422364689206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364689206 : Closed e2422364689206 ∧ code e2422364689206 = 11218457711414 := by decide
theorem cert_e2422364689206 : check e2422364689206 [[],[]] .three = true := by decide
def e2422364689210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364689210 : Closed e2422364689210 ∧ code e2422364689210 = 11218457711418 := by decide
theorem cert_e2422364689210 : check e2422364689210 [[],[]] .three = true := by decide
def e2422364689294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422364689294 : Closed e2422364689294 ∧ code e2422364689294 = 11218457711502 := by decide
theorem cert_e2422364689294 : check e2422364689294 [[],[]] .three = true := by decide
def e2422364689306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364689306 : Closed e2422364689306 ∧ code e2422364689306 = 11218457711514 := by decide
theorem cert_e2422364689306 : check e2422364689306 [[],[]] .three = true := by decide
def e2422364689342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2422364689342 : Closed e2422364689342 ∧ code e2422364689342 = 11218457711550 := by decide
theorem cert_e2422364689342 : check e2422364689342 [[],[]] .three = true := by decide
def e2422364689350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422364689350 : Closed e2422364689350 ∧ code e2422364689350 = 11218457711558 := by decide
theorem cert_e2422364689350 : check e2422364689350 [[],[]] .three = true := by decide
def e2422364689398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2422364689398 : Closed e2422364689398 ∧ code e2422364689398 = 11218457711606 := by decide
theorem cert_e2422364689398 : check e2422364689398 [[],[]] .three = true := by decide
def e2422364690550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364690550 : Closed e2422364690550 ∧ code e2422364690550 = 11218457712758 := by decide
theorem cert_e2422364690550 : check e2422364690550 [[],[]] .three = true := by decide
def e2422364690794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422364690794 : Closed e2422364690794 ∧ code e2422364690794 = 11218457713002 := by decide
theorem cert_e2422364690794 : check e2422364690794 [[],[]] .three = true := by decide
def e2422364690830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422364690830 : Closed e2422364690830 ∧ code e2422364690830 = 11218457713038 := by decide
theorem cert_e2422364690830 : check e2422364690830 [[],[]] .three = true := by decide
def e2422364690842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364690842 : Closed e2422364690842 ∧ code e2422364690842 = 11218457713050 := by decide
theorem cert_e2422364690842 : check e2422364690842 [[],[]] .three = true := by decide
def e2422364690878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364690878 : Closed e2422364690878 ∧ code e2422364690878 = 11218457713086 := by decide
theorem cert_e2422364690878 : check e2422364690878 [[],[]] .three = true := by decide
def e2422364690886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422364690886 : Closed e2422364690886 ∧ code e2422364690886 = 11218457713094 := by decide
theorem cert_e2422364690886 : check e2422364690886 [[],[]] .three = true := by decide
end Blc.Floor43
