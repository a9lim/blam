import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389344193774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2389344193774 : Closed e2389344193774 ∧ code e2389344193774 = 11185437215982 := by decide
theorem cert_e2389344193774 : check e2389344193774 [[],[.left],[]] .smaller = true := by decide
def e2389344193782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2389344193782 : Closed e2389344193782 ∧ code e2389344193782 = 11185437215990 := by decide
theorem cert_e2389344193782 : check e2389344193782 [[],[.left],[]] .smaller = true := by decide
def e2389344194158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2389344194158 : Closed e2389344194158 ∧ code e2389344194158 = 11185437216366 := by decide
theorem cert_e2389344194158 : check e2389344194158 [[],[.left],[]] .smaller = true := by decide
def e2389344194170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2389344194170 : Closed e2389344194170 ∧ code e2389344194170 = 11185437216378 := by decide
theorem cert_e2389344194170 : check e2389344194170 [[],[.left],[]] .smaller = true := by decide
def e2389344194358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2389344194358 : Closed e2389344194358 ∧ code e2389344194358 = 11185437216566 := by decide
theorem cert_e2389344194358 : check e2389344194358 [[],[.left],[]] .smaller = true := by decide
def e2389344194362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2389344194362 : Closed e2389344194362 ∧ code e2389344194362 = 11185437216570 := by decide
theorem cert_e2389344194362 : check e2389344194362 [[],[.left],[]] .smaller = true := by decide
def e2389344202206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2389344202206 : Closed e2389344202206 ∧ code e2389344202206 = 11185437224414 := by decide
theorem cert_e2389344202206 : check e2389344202206 [[],[.left],[]] .chain = true := by decide
def e2389344202222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2389344202222 : Closed e2389344202222 ∧ code e2389344202222 = 11185437224430 := by decide
theorem cert_e2389344202222 : check e2389344202222 [[],[.left],[]] .chain = true := by decide
def e2389344202462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2389344202462 : Closed e2389344202462 ∧ code e2389344202462 = 11185437224670 := by decide
theorem cert_e2389344202462 : check e2389344202462 [[],[.left],[]] .smaller = true := by decide
def e2389344202478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2389344202478 : Closed e2389344202478 ∧ code e2389344202478 = 11185437224686 := by decide
theorem cert_e2389344202478 : check e2389344202478 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2389344202486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2389344202486 : Closed e2389344202486 ∧ code e2389344202486 = 11185437224694 := by decide
theorem cert_e2389344202486 : check e2389344202486 [[],[.left],[]] .smaller = true := by decide
def e2389344202590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2389344202590 : Closed e2389344202590 ∧ code e2389344202590 = 11185437224798 := by decide
theorem cert_e2389344202590 : check e2389344202590 [[],[.left],[]] .chain = true := by decide
def e2389344202606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2389344202606 : Closed e2389344202606 ∧ code e2389344202606 = 11185437224814 := by decide
theorem cert_e2389344202606 : check e2389344202606 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2389344202614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2389344202614 : Closed e2389344202614 ∧ code e2389344202614 = 11185437224822 := by decide
theorem cert_e2389344202614 : check e2389344202614 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2389344202618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2389344202618 : Closed e2389344202618 ∧ code e2389344202618 = 11185437224826 := by decide
theorem cert_e2389344202618 : check e2389344202618 [[],[.left],[]] .chain = true := by decide
def e2389344202670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2389344202670 : Closed e2389344202670 ∧ code e2389344202670 = 11185437224878 := by decide
theorem cert_e2389344202670 : check e2389344202670 [[],[.left],[]] .chain = true := by decide
def e2389344202678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2389344202678 : Closed e2389344202678 ∧ code e2389344202678 = 11185437224886 := by decide
theorem cert_e2389344202678 : check e2389344202678 [[],[.left],[]] .smaller = true := by decide
def e2389344202682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2389344202682 : Closed e2389344202682 ∧ code e2389344202682 = 11185437224890 := by decide
theorem cert_e2389344202682 : check e2389344202682 [[],[.left],[]] .chain = true := by decide
def e2389344203742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2389344203742 : Closed e2389344203742 ∧ code e2389344203742 = 11185437225950 := by decide
theorem cert_e2389344203742 : check e2389344203742 [[],[.left],[]] .chain = true := by decide
def e2389344203758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2389344203758 : Closed e2389344203758 ∧ code e2389344203758 = 11185437225966 := by decide
theorem cert_e2389344203758 : check e2389344203758 [[],[.left],[]] .chain = true := by decide
def e2389344205278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2389344205278 : Closed e2389344205278 ∧ code e2389344205278 = 11185437227486 := by decide
theorem cert_e2389344205278 : check e2389344205278 [[],[.left],[]] .smaller = true := by decide
def e2389344205294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2389344205294 : Closed e2389344205294 ∧ code e2389344205294 = 11185437227502 := by decide
theorem cert_e2389344205294 : check e2389344205294 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2389344205302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2389344205302 : Closed e2389344205302 ∧ code e2389344205302 = 11185437227510 := by decide
theorem cert_e2389344205302 : check e2389344205302 [[],[.left],[]] .smaller = true := by decide
def e2389344206046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389344206046 : Closed e2389344206046 ∧ code e2389344206046 = 11185437228254 := by decide
theorem cert_e2389344206046 : check e2389344206046 [[],[.left],[]] .chain = true := by decide
def e2389344206062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389344206062 : Closed e2389344206062 ∧ code e2389344206062 = 11185437228270 := by decide
theorem cert_e2389344206062 : check e2389344206062 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2389344206070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389344206070 : Closed e2389344206070 ∧ code e2389344206070 = 11185437228278 := by decide
theorem cert_e2389344206070 : check e2389344206070 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2389344206074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389344206074 : Closed e2389344206074 ∧ code e2389344206074 = 11185437228282 := by decide
theorem cert_e2389344206074 : check e2389344206074 [[],[.left],[]] .chain = true := by decide
def e2389344206446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389344206446 : Closed e2389344206446 ∧ code e2389344206446 = 11185437228654 := by decide
theorem cert_e2389344206446 : check e2389344206446 [[],[.left],[]] .chain = true := by decide
def e2389344206454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2389344206454 : Closed e2389344206454 ∧ code e2389344206454 = 11185437228662 := by decide
theorem cert_e2389344206454 : check e2389344206454 [[],[.left],[]] .smaller = true := by decide
def e2389344206458 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389344206458 : Closed e2389344206458 ∧ code e2389344206458 = 11185437228666 := by decide
theorem cert_e2389344206458 : check e2389344206458 [[],[.left],[]] .chain = true := by decide
def e2389344229086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2389344229086 : Closed e2389344229086 ∧ code e2389344229086 = 11185437251294 := by decide
theorem cert_e2389344229086 : check e2389344229086 [[],[.left],[]] .smaller = true := by decide
def e2389344229102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2389344229102 : Closed e2389344229102 ∧ code e2389344229102 = 11185437251310 := by decide
theorem cert_e2389344229102 : check e2389344229102 [[],[.left],[]] .sourceHead = true := by decide
def e2389344229110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2389344229110 : Closed e2389344229110 ∧ code e2389344229110 = 11185437251318 := by decide
theorem cert_e2389344229110 : check e2389344229110 [[],[.left],[]] .smaller = true := by decide
def e2389344229214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2389344229214 : Closed e2389344229214 ∧ code e2389344229214 = 11185437251422 := by decide
theorem cert_e2389344229214 : check e2389344229214 [[],[.left],[]] .smaller = true := by decide
def e2389344229242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2389344229242 : Closed e2389344229242 ∧ code e2389344229242 = 11185437251450 := by decide
theorem cert_e2389344229242 : check e2389344229242 [[],[.left],[]] .smaller = true := by decide
def e2389344229294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2389344229294 : Closed e2389344229294 ∧ code e2389344229294 = 11185437251502 := by decide
theorem cert_e2389344229294 : check e2389344229294 [[],[.left],[]] .sourceHead = true := by decide
def e2389344229306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2389344229306 : Closed e2389344229306 ∧ code e2389344229306 = 11185437251514 := by decide
theorem cert_e2389344229306 : check e2389344229306 [[],[.left],[]] .sourceHead = true := by decide
def e2389344229334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2389344229334 : Closed e2389344229334 ∧ code e2389344229334 = 11185437251542 := by decide
theorem cert_e2389344229334 : check e2389344229334 [[],[.left],[]] .smaller = true := by decide
def e2389344229338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2389344229338 : Closed e2389344229338 ∧ code e2389344229338 = 11185437251546 := by decide
theorem cert_e2389344229338 : check e2389344229338 [[],[.left],[]] .smaller = true := by decide
def e2389344229854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2389344229854 : Closed e2389344229854 ∧ code e2389344229854 = 11185437252062 := by decide
theorem cert_e2389344229854 : check e2389344229854 [[],[.left],[]] .smaller = true := by decide
def e2389344229870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2389344229870 : Closed e2389344229870 ∧ code e2389344229870 = 11185437252078 := by decide
theorem cert_e2389344229870 : check e2389344229870 [[],[.left],[]] .sourceHead = true := by decide
def e2389344229878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2389344229878 : Closed e2389344229878 ∧ code e2389344229878 = 11185437252086 := by decide
theorem cert_e2389344229878 : check e2389344229878 [[],[.left],[]] .smaller = true := by decide
def e2389344230622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389344230622 : Closed e2389344230622 ∧ code e2389344230622 = 11185437252830 := by decide
theorem cert_e2389344230622 : check e2389344230622 [[],[.left],[]] .smaller = true := by decide
def e2389344230650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389344230650 : Closed e2389344230650 ∧ code e2389344230650 = 11185437252858 := by decide
theorem cert_e2389344230650 : check e2389344230650 [[],[.left],[]] .smaller = true := by decide
def e2389344231022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389344231022 : Closed e2389344231022 ∧ code e2389344231022 = 11185437253230 := by decide
theorem cert_e2389344231022 : check e2389344231022 [[],[.left],[]] .sourceHead = true := by decide
def e2389344231034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389344231034 : Closed e2389344231034 ∧ code e2389344231034 = 11185437253242 := by decide
theorem cert_e2389344231034 : check e2389344231034 [[],[.left],[]] .sourceHead = true := by decide
def e2389344231222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389344231222 : Closed e2389344231222 ∧ code e2389344231222 = 11185437253430 := by decide
theorem cert_e2389344231222 : check e2389344231222 [[],[.left],[]] .smaller = true := by decide
def e2389344231226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389344231226 : Closed e2389344231226 ∧ code e2389344231226 = 11185437253434 := by decide
theorem cert_e2389344231226 : check e2389344231226 [[],[.left],[]] .smaller = true := by decide
def e2389344242526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2389344242526 : Closed e2389344242526 ∧ code e2389344242526 = 11185437264734 := by decide
theorem cert_e2389344242526 : check e2389344242526 [[],[.left],[]] .chain = true := by decide
def e2389344242542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2389344242542 : Closed e2389344242542 ∧ code e2389344242542 = 11185437264750 := by decide
theorem cert_e2389344242542 : check e2389344242542 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344242550 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2389344242550 : Closed e2389344242550 ∧ code e2389344242550 = 11185437264758 := by decide
theorem cert_e2389344242550 : check e2389344242550 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344242554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2389344242554 : Closed e2389344242554 ∧ code e2389344242554 = 11185437264762 := by decide
theorem cert_e2389344242554 : check e2389344242554 [[],[.left],[]] .chain = true := by decide
def e2389344242606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2389344242606 : Closed e2389344242606 ∧ code e2389344242606 = 11185437264814 := by decide
theorem cert_e2389344242606 : check e2389344242606 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344242618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2389344242618 : Closed e2389344242618 ∧ code e2389344242618 = 11185437264826 := by decide
theorem cert_e2389344242618 : check e2389344242618 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344242646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2389344242646 : Closed e2389344242646 ∧ code e2389344242646 = 11185437264854 := by decide
theorem cert_e2389344242646 : check e2389344242646 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344242650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2389344242650 : Closed e2389344242650 ∧ code e2389344242650 = 11185437264858 := by decide
theorem cert_e2389344242650 : check e2389344242650 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344242666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2389344242666 : Closed e2389344242666 ∧ code e2389344242666 = 11185437264874 := by decide
theorem cert_e2389344242666 : check e2389344242666 [[],[.left],[]] .chain = true := by decide
def e2389344242910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389344242910 : Closed e2389344242910 ∧ code e2389344242910 = 11185437265118 := by decide
theorem cert_e2389344242910 : check e2389344242910 [[],[.left],[]] .chain = true := by decide
def e2389344242926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389344242926 : Closed e2389344242926 ∧ code e2389344242926 = 11185437265134 := by decide
theorem cert_e2389344242926 : check e2389344242926 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344242934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389344242934 : Closed e2389344242934 ∧ code e2389344242934 = 11185437265142 := by decide
theorem cert_e2389344242934 : check e2389344242934 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344242938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389344242938 : Closed e2389344242938 ∧ code e2389344242938 = 11185437265146 := by decide
theorem cert_e2389344242938 : check e2389344242938 [[],[.left],[]] .chain = true := by decide
def e2389344243310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389344243310 : Closed e2389344243310 ∧ code e2389344243310 = 11185437265518 := by decide
theorem cert_e2389344243310 : check e2389344243310 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344243322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389344243322 : Closed e2389344243322 ∧ code e2389344243322 = 11185437265530 := by decide
theorem cert_e2389344243322 : check e2389344243322 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344243510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389344243510 : Closed e2389344243510 ∧ code e2389344243510 = 11185437265718 := by decide
theorem cert_e2389344243510 : check e2389344243510 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344243514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389344243514 : Closed e2389344243514 ∧ code e2389344243514 = 11185437265722 := by decide
theorem cert_e2389344243514 : check e2389344243514 [[],[.left],[],[.under,.under]] .smaller = true := by decide
def e2389344243610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344243610 : Closed e2389344243610 ∧ code e2389344243610 = 11185437265818 := by decide
theorem cert_e2389344243610 : check e2389344243610 [[],[.left],[]] .chain = true := by decide
def e2389344249262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2389344249262 : Closed e2389344249262 ∧ code e2389344249262 = 11185437271470 := by decide
theorem cert_e2389344249262 : check e2389344249262 [[],[.left],[]] .chain = true := by decide
def e2389344249270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2389344249270 : Closed e2389344249270 ∧ code e2389344249270 = 11185437271478 := by decide
theorem cert_e2389344249270 : check e2389344249270 [[],[.left],[]] .smaller = true := by decide
def e2389344249274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2389344249274 : Closed e2389344249274 ∧ code e2389344249274 = 11185437271482 := by decide
theorem cert_e2389344249274 : check e2389344249274 [[],[.left],[]] .chain = true := by decide
def e2389344249302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2389344249302 : Closed e2389344249302 ∧ code e2389344249302 = 11185437271510 := by decide
theorem cert_e2389344249302 : check e2389344249302 [[],[.left],[]] .smaller = true := by decide
def e2389344249306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2389344249306 : Closed e2389344249306 ∧ code e2389344249306 = 11185437271514 := by decide
theorem cert_e2389344249306 : check e2389344249306 [[],[.left],[]] .smaller = true := by decide
def e2389344249322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2389344249322 : Closed e2389344249322 ∧ code e2389344249322 = 11185437271530 := by decide
theorem cert_e2389344249322 : check e2389344249322 [[],[.left],[]] .chain = true := by decide
def e2389344249454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389344249454 : Closed e2389344249454 ∧ code e2389344249454 = 11185437271662 := by decide
theorem cert_e2389344249454 : check e2389344249454 [[],[.left],[]] .chain = true := by decide
def e2389344249462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2389344249462 : Closed e2389344249462 ∧ code e2389344249462 = 11185437271670 := by decide
theorem cert_e2389344249462 : check e2389344249462 [[],[.left],[]] .smaller = true := by decide
def e2389344249466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389344249466 : Closed e2389344249466 ∧ code e2389344249466 = 11185437271674 := by decide
theorem cert_e2389344249466 : check e2389344249466 [[],[.left],[]] .chain = true := by decide
def e2389344249654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389344249654 : Closed e2389344249654 ∧ code e2389344249654 = 11185437271862 := by decide
theorem cert_e2389344249654 : check e2389344249654 [[],[.left],[]] .smaller = true := by decide
def e2389344249658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389344249658 : Closed e2389344249658 ∧ code e2389344249658 = 11185437271866 := by decide
theorem cert_e2389344249658 : check e2389344249658 [[],[.left],[]] .smaller = true := by decide
def e2389344249754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344249754 : Closed e2389344249754 ∧ code e2389344249754 = 11185437271962 := by decide
theorem cert_e2389344249754 : check e2389344249754 [[],[.left],[]] .chain = true := by decide
def e2389344695662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2389344695662 : Closed e2389344695662 ∧ code e2389344695662 = 11185437717870 := by decide
theorem cert_e2389344695662 : check e2389344695662 [[],[.left],[]] .chain = true := by decide
def e2389344695670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2389344695670 : Closed e2389344695670 ∧ code e2389344695670 = 11185437717878 := by decide
theorem cert_e2389344695670 : check e2389344695670 [[],[.left],[]] .chain = true := by decide
def e2389344695726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2389344695726 : Closed e2389344695726 ∧ code e2389344695726 = 11185437717934 := by decide
theorem cert_e2389344695726 : check e2389344695726 [[],[.left],[]] .chain = true := by decide
def e2389344695738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2389344695738 : Closed e2389344695738 ∧ code e2389344695738 = 11185437717946 := by decide
theorem cert_e2389344695738 : check e2389344695738 [[],[.left],[]] .chain = true := by decide
def e2389344695766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2389344695766 : Closed e2389344695766 ∧ code e2389344695766 = 11185437717974 := by decide
theorem cert_e2389344695766 : check e2389344695766 [[],[.left],[]] .chain = true := by decide
def e2389344695770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2389344695770 : Closed e2389344695770 ∧ code e2389344695770 = 11185437717978 := by decide
theorem cert_e2389344695770 : check e2389344695770 [[],[.left],[]] .chain = true := by decide
def e2389344695982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2389344695982 : Closed e2389344695982 ∧ code e2389344695982 = 11185437718190 := by decide
theorem cert_e2389344695982 : check e2389344695982 [[],[.left],[]] .chain = true := by decide
def e2389344695994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2389344695994 : Closed e2389344695994 ∧ code e2389344695994 = 11185437718202 := by decide
theorem cert_e2389344695994 : check e2389344695994 [[],[.left],[]] .chain = true := by decide
def e2389344696042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2389344696042 : Closed e2389344696042 ∧ code e2389344696042 = 11185437718250 := by decide
theorem cert_e2389344696042 : check e2389344696042 [[],[.left],[]] .chain = true := by decide
def e2389344696150 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2389344696150 : Closed e2389344696150 ∧ code e2389344696150 = 11185437718358 := by decide
theorem cert_e2389344696150 : check e2389344696150 [[],[.left],[]] .chain = true := by decide
def e2389344696154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2389344696154 : Closed e2389344696154 ∧ code e2389344696154 = 11185437718362 := by decide
theorem cert_e2389344696154 : check e2389344696154 [[],[.left],[]] .chain = true := by decide
def e2389344696170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2389344696170 : Closed e2389344696170 ∧ code e2389344696170 = 11185437718378 := by decide
theorem cert_e2389344696170 : check e2389344696170 [[],[.left],[]] .chain = true := by decide
def e2389344697006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2389344697006 : Closed e2389344697006 ∧ code e2389344697006 = 11185437719214 := by decide
theorem cert_e2389344697006 : check e2389344697006 [[],[.left],[]] .chain = true := by decide
def e2389344697018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2389344697018 : Closed e2389344697018 ∧ code e2389344697018 = 11185437719226 := by decide
theorem cert_e2389344697018 : check e2389344697018 [[],[.left],[]] .chain = true := by decide
def e2389344697066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2389344697066 : Closed e2389344697066 ∧ code e2389344697066 = 11185437719274 := by decide
theorem cert_e2389344697066 : check e2389344697066 [[],[.left],[]] .chain = true := by decide
def e2389344697258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2389344697258 : Closed e2389344697258 ∧ code e2389344697258 = 11185437719466 := by decide
theorem cert_e2389344697258 : check e2389344697258 [[],[.left],[]] .chain = true := by decide
def e2389344697686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2389344697686 : Closed e2389344697686 ∧ code e2389344697686 = 11185437719894 := by decide
theorem cert_e2389344697686 : check e2389344697686 [[],[.left],[]] .chain = true := by decide
def e2389344697690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2389344697690 : Closed e2389344697690 ∧ code e2389344697690 = 11185437719898 := by decide
theorem cert_e2389344697690 : check e2389344697690 [[],[.left],[]] .chain = true := by decide
def e2389344697706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2389344697706 : Closed e2389344697706 ∧ code e2389344697706 = 11185437719914 := by decide
theorem cert_e2389344697706 : check e2389344697706 [[],[.left],[]] .chain = true := by decide
def e2389344697770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2389344697770 : Closed e2389344697770 ∧ code e2389344697770 = 11185437719978 := by decide
theorem cert_e2389344697770 : check e2389344697770 [[],[.left],[]] .chain = true := by decide
def e2389344700270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2389344700270 : Closed e2389344700270 ∧ code e2389344700270 = 11185437722478 := by decide
theorem cert_e2389344700270 : check e2389344700270 [[],[.left],[]] .sourceHead = true := by decide
def e2389344700278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2389344700278 : Closed e2389344700278 ∧ code e2389344700278 = 11185437722486 := by decide
theorem cert_e2389344700278 : check e2389344700278 [[],[.left],[]] .sourceHead = true := by decide
def e2389344700342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e2389344700342 : Closed e2389344700342 ∧ code e2389344700342 = 11185437722550 := by decide
theorem cert_e2389344700342 : check e2389344700342 [[],[.left],[]] .sourceHead = true := by decide
def e2389344701806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2389344701806 : Closed e2389344701806 ∧ code e2389344701806 = 11185437724014 := by decide
theorem cert_e2389344701806 : check e2389344701806 [[],[.left],[]] .chain = true := by decide
def e2389344701814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2389344701814 : Closed e2389344701814 ∧ code e2389344701814 = 11185437724022 := by decide
theorem cert_e2389344701814 : check e2389344701814 [[],[.left],[]] .chain = true := by decide
def e2389344701870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2389344701870 : Closed e2389344701870 ∧ code e2389344701870 = 11185437724078 := by decide
theorem cert_e2389344701870 : check e2389344701870 [[],[.left],[]] .chain = true := by decide
def e2389344701882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2389344701882 : Closed e2389344701882 ∧ code e2389344701882 = 11185437724090 := by decide
theorem cert_e2389344701882 : check e2389344701882 [[],[.left],[]] .chain = true := by decide
def e2389344701910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2389344701910 : Closed e2389344701910 ∧ code e2389344701910 = 11185437724118 := by decide
theorem cert_e2389344701910 : check e2389344701910 [[],[.left],[]] .chain = true := by decide
def e2389344701914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2389344701914 : Closed e2389344701914 ∧ code e2389344701914 = 11185437724122 := by decide
theorem cert_e2389344701914 : check e2389344701914 [[],[.left],[]] .chain = true := by decide
def e2389344702126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2389344702126 : Closed e2389344702126 ∧ code e2389344702126 = 11185437724334 := by decide
theorem cert_e2389344702126 : check e2389344702126 [[],[.left],[]] .chain = true := by decide
def e2389344702138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2389344702138 : Closed e2389344702138 ∧ code e2389344702138 = 11185437724346 := by decide
theorem cert_e2389344702138 : check e2389344702138 [[],[.left],[]] .chain = true := by decide
def e2389344702186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2389344702186 : Closed e2389344702186 ∧ code e2389344702186 = 11185437724394 := by decide
theorem cert_e2389344702186 : check e2389344702186 [[],[.left],[]] .chain = true := by decide
def e2389344702294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2389344702294 : Closed e2389344702294 ∧ code e2389344702294 = 11185437724502 := by decide
theorem cert_e2389344702294 : check e2389344702294 [[],[.left],[]] .chain = true := by decide
def e2389344702298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2389344702298 : Closed e2389344702298 ∧ code e2389344702298 = 11185437724506 := by decide
theorem cert_e2389344702298 : check e2389344702298 [[],[.left],[]] .chain = true := by decide
def e2389344702314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2389344702314 : Closed e2389344702314 ∧ code e2389344702314 = 11185437724522 := by decide
theorem cert_e2389344702314 : check e2389344702314 [[],[.left],[]] .chain = true := by decide
def e2389344703342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2389344703342 : Closed e2389344703342 ∧ code e2389344703342 = 11185437725550 := by decide
theorem cert_e2389344703342 : check e2389344703342 [[],[.left],[]] .chain = true := by decide
def e2389344703350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2389344703350 : Closed e2389344703350 ∧ code e2389344703350 = 11185437725558 := by decide
theorem cert_e2389344703350 : check e2389344703350 [[],[.left],[]] .chain = true := by decide
def e2389344703406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2389344703406 : Closed e2389344703406 ∧ code e2389344703406 = 11185437725614 := by decide
theorem cert_e2389344703406 : check e2389344703406 [[],[.left],[]] .chain = true := by decide
def e2389344703418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2389344703418 : Closed e2389344703418 ∧ code e2389344703418 = 11185437725626 := by decide
theorem cert_e2389344703418 : check e2389344703418 [[],[.left],[]] .chain = true := by decide
def e2389344703446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2389344703446 : Closed e2389344703446 ∧ code e2389344703446 = 11185437725654 := by decide
theorem cert_e2389344703446 : check e2389344703446 [[],[.left],[]] .chain = true := by decide
def e2389344703450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2389344703450 : Closed e2389344703450 ∧ code e2389344703450 = 11185437725658 := by decide
theorem cert_e2389344703450 : check e2389344703450 [[],[.left],[]] .chain = true := by decide
def e2389344703726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2389344703726 : Closed e2389344703726 ∧ code e2389344703726 = 11185437725934 := by decide
theorem cert_e2389344703726 : check e2389344703726 [[],[.left],[]] .chain = true := by decide
def e2389344703734 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2389344703734 : Closed e2389344703734 ∧ code e2389344703734 = 11185437725942 := by decide
theorem cert_e2389344703734 : check e2389344703734 [[],[.left],[]] .chain = true := by decide
def e2389344704110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2389344704110 : Closed e2389344704110 ∧ code e2389344704110 = 11185437726318 := by decide
theorem cert_e2389344704110 : check e2389344704110 [[],[.left],[]] .chain = true := by decide
def e2389344704122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2389344704122 : Closed e2389344704122 ∧ code e2389344704122 = 11185437726330 := by decide
theorem cert_e2389344704122 : check e2389344704122 [[],[.left],[]] .chain = true := by decide
def e2389344704310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389344704310 : Closed e2389344704310 ∧ code e2389344704310 = 11185437726518 := by decide
theorem cert_e2389344704310 : check e2389344704310 [[],[.left],[]] .chain = true := by decide
def e2389344704314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389344704314 : Closed e2389344704314 ∧ code e2389344704314 = 11185437726522 := by decide
theorem cert_e2389344704314 : check e2389344704314 [[],[.left],[]] .chain = true := by decide
def e2389344704750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2389344704750 : Closed e2389344704750 ∧ code e2389344704750 = 11185437726958 := by decide
theorem cert_e2389344704750 : check e2389344704750 [[],[.left],[]] .sourceHead = true := by decide
def e2389344704758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2389344704758 : Closed e2389344704758 ∧ code e2389344704758 = 11185437726966 := by decide
theorem cert_e2389344704758 : check e2389344704758 [[],[.left],[]] .sourceHead = true := by decide
def e2389344704942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2389344704942 : Closed e2389344704942 ∧ code e2389344704942 = 11185437727150 := by decide
theorem cert_e2389344704942 : check e2389344704942 [[],[.left],[]] .chain = true := by decide
def e2389344704954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2389344704954 : Closed e2389344704954 ∧ code e2389344704954 = 11185437727162 := by decide
theorem cert_e2389344704954 : check e2389344704954 [[],[.left],[]] .chain = true := by decide
def e2389344705002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2389344705002 : Closed e2389344705002 ∧ code e2389344705002 = 11185437727210 := by decide
theorem cert_e2389344705002 : check e2389344705002 [[],[.left],[]] .chain = true := by decide
def e2389344705134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2389344705134 : Closed e2389344705134 ∧ code e2389344705134 = 11185437727342 := by decide
theorem cert_e2389344705134 : check e2389344705134 [[],[.left],[]] .chain = true := by decide
def e2389344705146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2389344705146 : Closed e2389344705146 ∧ code e2389344705146 = 11185437727354 := by decide
theorem cert_e2389344705146 : check e2389344705146 [[],[.left],[]] .chain = true := by decide
def e2389344705310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2389344705310 : Closed e2389344705310 ∧ code e2389344705310 = 11185437727518 := by decide
theorem cert_e2389344705310 : check e2389344705310 [[],[.left],[]] .sourceHead = true := by decide
def e2389344705422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2389344705422 : Closed e2389344705422 ∧ code e2389344705422 = 11185437727630 := by decide
theorem cert_e2389344705422 : check e2389344705422 [[],[.left],[]] .sourceHead = true := by decide
def e2389344705434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344705434 : Closed e2389344705434 ∧ code e2389344705434 = 11185437727642 := by decide
theorem cert_e2389344705434 : check e2389344705434 [[],[.left],[]] .chain = true := by decide
def e2389344705654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2389344705654 : Closed e2389344705654 ∧ code e2389344705654 = 11185437727862 := by decide
theorem cert_e2389344705654 : check e2389344705654 [[],[.left],[]] .sourceHead = true := by decide
def e2389344705750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2389344705750 : Closed e2389344705750 ∧ code e2389344705750 = 11185437727958 := by decide
theorem cert_e2389344705750 : check e2389344705750 [[],[.left],[]] .chain = true := by decide
def e2389344705754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2389344705754 : Closed e2389344705754 ∧ code e2389344705754 = 11185437727962 := by decide
theorem cert_e2389344705754 : check e2389344705754 [[],[.left],[]] .chain = true := by decide
def e2389344705770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2389344705770 : Closed e2389344705770 ∧ code e2389344705770 = 11185437727978 := by decide
theorem cert_e2389344705770 : check e2389344705770 [[],[.left],[]] .chain = true := by decide
def e2389344705846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389344705846 : Closed e2389344705846 ∧ code e2389344705846 = 11185437728054 := by decide
theorem cert_e2389344705846 : check e2389344705846 [[],[.left],[]] .chain = true := by decide
def e2389344705850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389344705850 : Closed e2389344705850 ∧ code e2389344705850 = 11185437728058 := by decide
theorem cert_e2389344705850 : check e2389344705850 [[],[.left],[]] .chain = true := by decide
def e2389344705934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2389344705934 : Closed e2389344705934 ∧ code e2389344705934 = 11185437728142 := by decide
theorem cert_e2389344705934 : check e2389344705934 [[],[.left],[]] .sourceHead = true := by decide
def e2389344705946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389344705946 : Closed e2389344705946 ∧ code e2389344705946 = 11185437728154 := by decide
theorem cert_e2389344705946 : check e2389344705946 [[],[.left],[]] .chain = true := by decide
def e2389344707438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2389344707438 : Closed e2389344707438 ∧ code e2389344707438 = 11185437729646 := by decide
def e2389344707446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2389344707446 : Closed e2389344707446 ∧ code e2389344707446 = 11185437729654 := by decide
theorem cert_e2389344707446 : check e2389344707446 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344707502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2389344707502 : Closed e2389344707502 ∧ code e2389344707502 = 11185437729710 := by decide
theorem cert_e2389344707502 : check e2389344707502 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389344707514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2389344707514 : Closed e2389344707514 ∧ code e2389344707514 = 11185437729722 := by decide
theorem cert_e2389344707514 : check e2389344707514 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2389344707542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2389344707542 : Closed e2389344707542 ∧ code e2389344707542 = 11185437729750 := by decide
theorem cert_e2389344707542 : check e2389344707542 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344707546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2389344707546 : Closed e2389344707546 ∧ code e2389344707546 = 11185437729754 := by decide
def e2389344708270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2389344708270 : Closed e2389344708270 ∧ code e2389344708270 = 11185437730478 := by decide
theorem cert_e2389344708270 : check e2389344708270 [[],[.left],[]] .chain = true := by decide
def e2389344708282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2389344708282 : Closed e2389344708282 ∧ code e2389344708282 = 11185437730490 := by decide
theorem cert_e2389344708282 : check e2389344708282 [[],[.left],[]] .chain = true := by decide
def e2389344708330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2389344708330 : Closed e2389344708330 ∧ code e2389344708330 = 11185437730538 := by decide
theorem cert_e2389344708330 : check e2389344708330 [[],[.left],[]] .chain = true := by decide
def e2389344708522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2389344708522 : Closed e2389344708522 ∧ code e2389344708522 = 11185437730730 := by decide
theorem cert_e2389344708522 : check e2389344708522 [[],[.left],[]] .chain = true := by decide
def e2389344708846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2389344708846 : Closed e2389344708846 ∧ code e2389344708846 = 11185437731054 := by decide
theorem cert_e2389344708846 : check e2389344708846 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344708854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2389344708854 : Closed e2389344708854 ∧ code e2389344708854 = 11185437731062 := by decide
theorem cert_e2389344708854 : check e2389344708854 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389344709038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2389344709038 : Closed e2389344709038 ∧ code e2389344709038 = 11185437731246 := by decide
theorem cert_e2389344709038 : check e2389344709038 [[],[.left],[]] .chain = true := by decide
def e2389344709050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2389344709050 : Closed e2389344709050 ∧ code e2389344709050 = 11185437731258 := by decide
theorem cert_e2389344709050 : check e2389344709050 [[],[.left],[]] .chain = true := by decide
def e2389344709098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2389344709098 : Closed e2389344709098 ∧ code e2389344709098 = 11185437731306 := by decide
theorem cert_e2389344709098 : check e2389344709098 [[],[.left],[]] .chain = true := by decide
def e2389344709230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2389344709230 : Closed e2389344709230 ∧ code e2389344709230 = 11185437731438 := by decide
theorem cert_e2389344709230 : check e2389344709230 [[],[.left],[]] .chain = true := by decide
def e2389344709242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2389344709242 : Closed e2389344709242 ∧ code e2389344709242 = 11185437731450 := by decide
theorem cert_e2389344709242 : check e2389344709242 [[],[.left],[]] .chain = true := by decide
end Blc.Floor43
