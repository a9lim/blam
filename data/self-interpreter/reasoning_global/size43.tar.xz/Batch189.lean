import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2388056186998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388056186998 : Closed e2388056186998 ∧ code e2388056186998 = 11184149209206 := by decide
theorem cert_e2388056186998 : check e2388056186998 [[],[.left]] .chain = true := by decide
def e2388056187242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388056187242 : Closed e2388056187242 ∧ code e2388056187242 = 11184149209450 := by decide
theorem cert_e2388056187242 : check e2388056187242 [[],[.left]] .chain = true := by decide
def e2388056187290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388056187290 : Closed e2388056187290 ∧ code e2388056187290 = 11184149209498 := by decide
theorem cert_e2388056187290 : check e2388056187290 [[],[.left]] .chain = true := by decide
def e2388056205338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388056205338 : Closed e2388056205338 ∧ code e2388056205338 = 11184149227546 := by decide
theorem cert_e2388056205338 : check e2388056205338 [[]] .width = true := by decide
def e2388056226330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388056226330 : Closed e2388056226330 ∧ code e2388056226330 = 11184149248538 := by decide
theorem cert_e2388056226330 : check e2388056226330 [[]] .width = true := by decide
def e2388056262170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388056262170 : Closed e2388056262170 ∧ code e2388056262170 = 11184149284378 := by decide
theorem cert_e2388056262170 : check e2388056262170 [[]] .width = true := by decide
def e2388056264902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388056264902 : Closed e2388056264902 ∧ code e2388056264902 = 11184149287110 := by decide
theorem cert_e2388056264902 : check e2388056264902 [[]] .width = true := by decide
def e2388056270874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388056270874 : Closed e2388056270874 ∧ code e2388056270874 = 11184149293082 := by decide
theorem cert_e2388056270874 : check e2388056270874 [[]] .width = true := by decide
def e2388061026842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388061026842 : Closed e2388061026842 ∧ code e2388061026842 = 11184154049050 := by decide
theorem cert_e2388061026842 : check e2388061026842 [[],[.left]] .chain = true := by decide
def e2388061051418 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388061051418 : Closed e2388061051418 ∧ code e2388061051418 = 11184154073626 := by decide
theorem cert_e2388061051418 : check e2388061051418 [[],[.left]] .chain = true := by decide
def e2388062026266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062026266 : Closed e2388062026266 ∧ code e2388062026266 = 11184155048474 := by decide
theorem cert_e2388062026266 : check e2388062026266 [[],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2388062038554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062038554 : Closed e2388062038554 ∧ code e2388062038554 = 11184155060762 := by decide
theorem cert_e2388062038554 : check e2388062038554 [[],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2388062087706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062087706 : Closed e2388062087706 ∧ code e2388062087706 = 11184155109914 := by decide
theorem cert_e2388062087706 : check e2388062087706 [[],[.left],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2388062173722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062173722 : Closed e2388062173722 ∧ code e2388062173722 = 11184155195930 := by decide
theorem cert_e2388062173722 : check e2388062173722 [[]] .width = true := by decide
def e2388062222874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062222874 : Closed e2388062222874 ∧ code e2388062222874 = 11184155245082 := by decide
theorem cert_e2388062222874 : check e2388062222874 [[],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2388062235162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062235162 : Closed e2388062235162 ∧ code e2388062235162 = 11184155257370 := by decide
theorem cert_e2388062235162 : check e2388062235162 [[],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2388062345754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062345754 : Closed e2388062345754 ∧ code e2388062345754 = 11184155367962 := by decide
private def t_e2388062345754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e2388062345754 : ¬ IsSelfInterpreter e2388062345754 :=
  wSource (t := t_e2388062345754) (replay_sound (ps := [[],[.left],[.left],[]]) (t := e2388062345754) (by decide)) (by decide)
def e2388062347290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388062347290 : Closed e2388062347290 ∧ code e2388062347290 = 11184155369498 := by decide
theorem cert_e2388062347290 : check e2388062347290 [[],[.left]] .smaller = true := by decide
def e2388062347382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388062347382 : Closed e2388062347382 ∧ code e2388062347382 = 11184155369590 := by decide
theorem cert_e2388062347382 : check e2388062347382 [[],[.left]] .chain = true := by decide
def e2388062347626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388062347626 : Closed e2388062347626 ∧ code e2388062347626 = 11184155369834 := by decide
theorem cert_e2388062347626 : check e2388062347626 [[],[.left]] .chain = true := by decide
def e2388062347674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388062347674 : Closed e2388062347674 ∧ code e2388062347674 = 11184155369882 := by decide
theorem cert_e2388062347674 : check e2388062347674 [[],[.left]] .chain = true := by decide
def e2388062357018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062357018 : Closed e2388062357018 ∧ code e2388062357018 = 11184155379226 := by decide
theorem cert_e2388062357018 : check e2388062357018 [[]] .width = true := by decide
def e2388062359750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388062359750 : Closed e2388062359750 ∧ code e2388062359750 = 11184155381958 := by decide
theorem cert_e2388062359750 : check e2388062359750 [[]] .width = true := by decide
def e2388062530074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062530074 : Closed e2388062530074 ∧ code e2388062530074 = 11184155552282 := by decide
theorem cert_e2388062530074 : check e2388062530074 [[],[.left],[.left],[],[.under],[.under,.left],[.under]] .chain = true := by decide
def e2388062542362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062542362 : Closed e2388062542362 ∧ code e2388062542362 = 11184155564570 := by decide
private def t_e2388062542362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.app (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem cert_e2388062542362 : ¬ IsSelfInterpreter e2388062542362 :=
  wSource (t := t_e2388062542362) (replay_sound (ps := [[],[.left],[.left],[]]) (t := e2388062542362) (by decide)) (by decide)
def e2388062543898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388062543898 : Closed e2388062543898 ∧ code e2388062543898 = 11184155566106 := by decide
theorem cert_e2388062543898 : check e2388062543898 [[],[.left]] .smaller = true := by decide
def e2388062543990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388062543990 : Closed e2388062543990 ∧ code e2388062543990 = 11184155566198 := by decide
theorem cert_e2388062543990 : check e2388062543990 [[],[.left]] .chain = true := by decide
def e2388062544234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388062544234 : Closed e2388062544234 ∧ code e2388062544234 = 11184155566442 := by decide
theorem cert_e2388062544234 : check e2388062544234 [[],[.left]] .chain = true := by decide
def e2388062544282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388062544282 : Closed e2388062544282 ∧ code e2388062544282 = 11184155566490 := by decide
theorem cert_e2388062544282 : check e2388062544282 [[],[.left]] .chain = true := by decide
def e2388062575130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062575130 : Closed e2388062575130 ∧ code e2388062575130 = 11184155597338 := by decide
theorem cert_e2388062575130 : check e2388062575130 [[]] .width = true := by decide
def e2388062586394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388062586394 : Closed e2388062586394 ∧ code e2388062586394 = 11184155608602 := by decide
theorem cert_e2388062586394 : check e2388062586394 [[]] .width = true := by decide
def e2388062589126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388062589126 : Closed e2388062589126 ∧ code e2388062589126 = 11184155611334 := by decide
theorem cert_e2388062589126 : check e2388062589126 [[]] .width = true := by decide
def e2388064975386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388064975386 : Closed e2388064975386 ∧ code e2388064975386 = 11184157997594 := by decide
theorem cert_e2388064975386 : check e2388064975386 [[],[.left]] .chain = true := by decide
def e2388064983578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388064983578 : Closed e2388064983578 ∧ code e2388064983578 = 11184158005786 := by decide
theorem cert_e2388064983578 : check e2388064983578 [[],[.left]] .chain = true := by decide
def e2388065475098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388065475098 : Closed e2388065475098 ∧ code e2388065475098 = 11184158497306 := by decide
theorem cert_e2388065475098 : check e2388065475098 [[],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2388065479194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388065479194 : Closed e2388065479194 ∧ code e2388065479194 = 11184158501402 := by decide
theorem cert_e2388065479194 : check e2388065479194 [[],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2388065495578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388065495578 : Closed e2388065495578 ∧ code e2388065495578 = 11184158517786 := by decide
theorem cert_e2388065495578 : check e2388065495578 [[],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2388065573402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388065573402 : Closed e2388065573402 ∧ code e2388065573402 = 11184158595610 := by decide
theorem cert_e2388065573402 : check e2388065573402 [[],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2388065577498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388065577498 : Closed e2388065577498 ∧ code e2388065577498 = 11184158599706 := by decide
theorem cert_e2388065577498 : check e2388065577498 [[],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2388065622554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388065622554 : Closed e2388065622554 ∧ code e2388065622554 = 11184158644762 := by decide
theorem cert_e2388065622554 : check e2388065622554 [[],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2388065624090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388065624090 : Closed e2388065624090 ∧ code e2388065624090 = 11184158646298 := by decide
theorem cert_e2388065624090 : check e2388065624090 [[],[.left]] .smaller = true := by decide
def e2388065624182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388065624182 : Closed e2388065624182 ∧ code e2388065624182 = 11184158646390 := by decide
theorem cert_e2388065624182 : check e2388065624182 [[],[.left]] .chain = true := by decide
def e2388065624426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388065624426 : Closed e2388065624426 ∧ code e2388065624426 = 11184158646634 := by decide
theorem cert_e2388065624426 : check e2388065624426 [[],[.left]] .chain = true := by decide
def e2388065624474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388065624474 : Closed e2388065624474 ∧ code e2388065624474 = 11184158646682 := by decide
theorem cert_e2388065624474 : check e2388065624474 [[],[.left]] .chain = true := by decide
def e2388065642522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388065642522 : Closed e2388065642522 ∧ code e2388065642522 = 11184158664730 := by decide
theorem cert_e2388065642522 : check e2388065642522 [[]] .width = true := by decide
def e2388065675802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388065675802 : Closed e2388065675802 ∧ code e2388065675802 = 11184158698010 := by decide
theorem cert_e2388065675802 : check e2388065675802 [[],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2388065688090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388065688090 : Closed e2388065688090 ∧ code e2388065688090 = 11184158710298 := by decide
theorem cert_e2388065688090 : check e2388065688090 [[],[.left],[.left],[],[.under]] .smaller = true := by decide
def e2388065689626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388065689626 : Closed e2388065689626 ∧ code e2388065689626 = 11184158711834 := by decide
theorem cert_e2388065689626 : check e2388065689626 [[],[.left]] .smaller = true := by decide
def e2388065689718 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388065689718 : Closed e2388065689718 ∧ code e2388065689718 = 11184158711926 := by decide
theorem cert_e2388065689718 : check e2388065689718 [[],[.left]] .chain = true := by decide
def e2388065689962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388065689962 : Closed e2388065689962 ∧ code e2388065689962 = 11184158712170 := by decide
theorem cert_e2388065689962 : check e2388065689962 [[],[.left]] .chain = true := by decide
def e2388065690010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388065690010 : Closed e2388065690010 ∧ code e2388065690010 = 11184158712218 := by decide
theorem cert_e2388065690010 : check e2388065690010 [[],[.left]] .chain = true := by decide
def e2388065757210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388065757210 : Closed e2388065757210 ∧ code e2388065757210 = 11184158779418 := by decide
theorem cert_e2388065757210 : check e2388065757210 [[]] .width = true := by decide
def e2388067236378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388067236378 : Closed e2388067236378 ∧ code e2388067236378 = 11184160258586 := by decide
theorem cert_e2388067236378 : check e2388067236378 [[]] .width = true := by decide
def e2388067272218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388067272218 : Closed e2388067272218 ∧ code e2388067272218 = 11184160294426 := by decide
theorem cert_e2388067272218 : check e2388067272218 [[]] .width = true := by decide
def e2388067274950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388067274950 : Closed e2388067274950 ∧ code e2388067274950 = 11184160297158 := by decide
theorem cert_e2388067274950 : check e2388067274950 [[]] .width = true := by decide
def e2388067280922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388067280922 : Closed e2388067280922 ∧ code e2388067280922 = 11184160303130 := by decide
theorem cert_e2388067280922 : check e2388067280922 [[]] .width = true := by decide
def e2388067293722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388067293722 : Closed e2388067293722 ∧ code e2388067293722 = 11184160315930 := by decide
theorem cert_e2388067293722 : check e2388067293722 [[]] .width = true := by decide
def e2388067304986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388067304986 : Closed e2388067304986 ∧ code e2388067304986 = 11184160327194 := by decide
theorem cert_e2388067304986 : check e2388067304986 [[]] .width = true := by decide
def e2388067307718 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388067307718 : Closed e2388067307718 ∧ code e2388067307718 = 11184160329926 := by decide
theorem cert_e2388067307718 : check e2388067307718 [[]] .width = true := by decide
def e2388067330074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388067330074 : Closed e2388067330074 ∧ code e2388067330074 = 11184160352282 := by decide
theorem cert_e2388067330074 : check e2388067330074 [[]] .width = true := by decide
def e2388085747054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2388085747054 : Closed e2388085747054 ∧ code e2388085747054 = 11184178769262 := by decide
theorem cert_e2388085747054 : check e2388085747054 [[],[.left],[]] .chain = true := by decide
def e2388085747062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2388085747062 : Closed e2388085747062 ∧ code e2388085747062 = 11184178769270 := by decide
theorem cert_e2388085747062 : check e2388085747062 [[],[.left],[]] .chain = true := by decide
def e2388085747118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2388085747118 : Closed e2388085747118 ∧ code e2388085747118 = 11184178769326 := by decide
theorem cert_e2388085747118 : check e2388085747118 [[],[.left],[]] .chain = true := by decide
def e2388085747130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2388085747130 : Closed e2388085747130 ∧ code e2388085747130 = 11184178769338 := by decide
theorem cert_e2388085747130 : check e2388085747130 [[],[.left],[]] .chain = true := by decide
def e2388085747158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2388085747158 : Closed e2388085747158 ∧ code e2388085747158 = 11184178769366 := by decide
theorem cert_e2388085747158 : check e2388085747158 [[],[.left],[]] .chain = true := by decide
def e2388085747162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2388085747162 : Closed e2388085747162 ∧ code e2388085747162 = 11184178769370 := by decide
theorem cert_e2388085747162 : check e2388085747162 [[],[.left],[]] .chain = true := by decide
def e2388085747374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2388085747374 : Closed e2388085747374 ∧ code e2388085747374 = 11184178769582 := by decide
theorem cert_e2388085747374 : check e2388085747374 [[],[.left],[]] .chain = true := by decide
def e2388085747386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2388085747386 : Closed e2388085747386 ∧ code e2388085747386 = 11184178769594 := by decide
theorem cert_e2388085747386 : check e2388085747386 [[],[.left],[]] .chain = true := by decide
def e2388085747434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2388085747434 : Closed e2388085747434 ∧ code e2388085747434 = 11184178769642 := by decide
theorem cert_e2388085747434 : check e2388085747434 [[],[.left],[]] .chain = true := by decide
def e2388085747542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2388085747542 : Closed e2388085747542 ∧ code e2388085747542 = 11184178769750 := by decide
theorem cert_e2388085747542 : check e2388085747542 [[],[.left],[]] .chain = true := by decide
def e2388085747546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2388085747546 : Closed e2388085747546 ∧ code e2388085747546 = 11184178769754 := by decide
theorem cert_e2388085747546 : check e2388085747546 [[],[.left],[]] .chain = true := by decide
def e2388085747562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2388085747562 : Closed e2388085747562 ∧ code e2388085747562 = 11184178769770 := by decide
theorem cert_e2388085747562 : check e2388085747562 [[],[.left],[]] .chain = true := by decide
def e2388085748590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2388085748590 : Closed e2388085748590 ∧ code e2388085748590 = 11184178770798 := by decide
theorem cert_e2388085748590 : check e2388085748590 [[],[.left],[]] .chain = true := by decide
def e2388085748598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2388085748598 : Closed e2388085748598 ∧ code e2388085748598 = 11184178770806 := by decide
theorem cert_e2388085748598 : check e2388085748598 [[],[.left],[]] .chain = true := by decide
def e2388085748654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2388085748654 : Closed e2388085748654 ∧ code e2388085748654 = 11184178770862 := by decide
theorem cert_e2388085748654 : check e2388085748654 [[],[.left],[]] .chain = true := by decide
def e2388085748666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2388085748666 : Closed e2388085748666 ∧ code e2388085748666 = 11184178770874 := by decide
theorem cert_e2388085748666 : check e2388085748666 [[],[.left],[]] .chain = true := by decide
def e2388085748694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2388085748694 : Closed e2388085748694 ∧ code e2388085748694 = 11184178770902 := by decide
theorem cert_e2388085748694 : check e2388085748694 [[],[.left],[]] .chain = true := by decide
def e2388085748698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2388085748698 : Closed e2388085748698 ∧ code e2388085748698 = 11184178770906 := by decide
theorem cert_e2388085748698 : check e2388085748698 [[],[.left],[]] .chain = true := by decide
def e2388085748974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2388085748974 : Closed e2388085748974 ∧ code e2388085748974 = 11184178771182 := by decide
theorem cert_e2388085748974 : check e2388085748974 [[],[.left],[]] .chain = true := by decide
def e2388085748982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2388085748982 : Closed e2388085748982 ∧ code e2388085748982 = 11184178771190 := by decide
theorem cert_e2388085748982 : check e2388085748982 [[],[.left],[]] .chain = true := by decide
def e2388085749358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2388085749358 : Closed e2388085749358 ∧ code e2388085749358 = 11184178771566 := by decide
theorem cert_e2388085749358 : check e2388085749358 [[],[.left],[]] .chain = true := by decide
def e2388085749370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2388085749370 : Closed e2388085749370 ∧ code e2388085749370 = 11184178771578 := by decide
theorem cert_e2388085749370 : check e2388085749370 [[],[.left],[]] .chain = true := by decide
def e2388085749558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2388085749558 : Closed e2388085749558 ∧ code e2388085749558 = 11184178771766 := by decide
theorem cert_e2388085749558 : check e2388085749558 [[],[.left],[]] .chain = true := by decide
def e2388085749562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2388085749562 : Closed e2388085749562 ∧ code e2388085749562 = 11184178771770 := by decide
theorem cert_e2388085749562 : check e2388085749562 [[],[.left],[]] .chain = true := by decide
def e2388085750190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2388085750190 : Closed e2388085750190 ∧ code e2388085750190 = 11184178772398 := by decide
theorem cert_e2388085750190 : check e2388085750190 [[],[.left],[]] .chain = true := by decide
def e2388085750202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2388085750202 : Closed e2388085750202 ∧ code e2388085750202 = 11184178772410 := by decide
theorem cert_e2388085750202 : check e2388085750202 [[],[.left],[]] .chain = true := by decide
def e2388085750250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2388085750250 : Closed e2388085750250 ∧ code e2388085750250 = 11184178772458 := by decide
theorem cert_e2388085750250 : check e2388085750250 [[],[.left],[]] .chain = true := by decide
def e2388085750382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2388085750382 : Closed e2388085750382 ∧ code e2388085750382 = 11184178772590 := by decide
theorem cert_e2388085750382 : check e2388085750382 [[],[.left],[]] .chain = true := by decide
def e2388085750394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2388085750394 : Closed e2388085750394 ∧ code e2388085750394 = 11184178772602 := by decide
theorem cert_e2388085750394 : check e2388085750394 [[],[.left],[]] .chain = true := by decide
def e2388085750682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2388085750682 : Closed e2388085750682 ∧ code e2388085750682 = 11184178772890 := by decide
theorem cert_e2388085750682 : check e2388085750682 [[],[.left],[]] .chain = true := by decide
def e2388085750998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2388085750998 : Closed e2388085750998 ∧ code e2388085750998 = 11184178773206 := by decide
theorem cert_e2388085750998 : check e2388085750998 [[],[.left],[]] .chain = true := by decide
def e2388085751002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2388085751002 : Closed e2388085751002 ∧ code e2388085751002 = 11184178773210 := by decide
theorem cert_e2388085751002 : check e2388085751002 [[],[.left],[]] .chain = true := by decide
def e2388085751018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2388085751018 : Closed e2388085751018 ∧ code e2388085751018 = 11184178773226 := by decide
theorem cert_e2388085751018 : check e2388085751018 [[],[.left],[]] .chain = true := by decide
def e2388085751094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2388085751094 : Closed e2388085751094 ∧ code e2388085751094 = 11184178773302 := by decide
theorem cert_e2388085751094 : check e2388085751094 [[],[.left],[]] .chain = true := by decide
def e2388085751098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2388085751098 : Closed e2388085751098 ∧ code e2388085751098 = 11184178773306 := by decide
theorem cert_e2388085751098 : check e2388085751098 [[],[.left],[]] .chain = true := by decide
def e2388085751194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2388085751194 : Closed e2388085751194 ∧ code e2388085751194 = 11184178773402 := by decide
theorem cert_e2388085751194 : check e2388085751194 [[],[.left],[]] .chain = true := by decide
def e2388085754734 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388085754734 : Closed e2388085754734 ∧ code e2388085754734 = 11184178776942 := by decide
theorem cert_e2388085754734 : check e2388085754734 [[],[.left],[]] .chain = true := by decide
def e2388085754742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388085754742 : Closed e2388085754742 ∧ code e2388085754742 = 11184178776950 := by decide
theorem cert_e2388085754742 : check e2388085754742 [[],[.left],[]] .chain = true := by decide
def e2388085754798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388085754798 : Closed e2388085754798 ∧ code e2388085754798 = 11184178777006 := by decide
theorem cert_e2388085754798 : check e2388085754798 [[],[.left],[]] .chain = true := by decide
def e2388085754810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388085754810 : Closed e2388085754810 ∧ code e2388085754810 = 11184178777018 := by decide
theorem cert_e2388085754810 : check e2388085754810 [[],[.left],[]] .chain = true := by decide
def e2388085754838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388085754838 : Closed e2388085754838 ∧ code e2388085754838 = 11184178777046 := by decide
theorem cert_e2388085754838 : check e2388085754838 [[],[.left],[]] .chain = true := by decide
def e2388085754842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388085754842 : Closed e2388085754842 ∧ code e2388085754842 = 11184178777050 := by decide
theorem cert_e2388085754842 : check e2388085754842 [[],[.left],[]] .chain = true := by decide
def e2388085755118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388085755118 : Closed e2388085755118 ∧ code e2388085755118 = 11184178777326 := by decide
theorem cert_e2388085755118 : check e2388085755118 [[],[.left],[]] .chain = true := by decide
def e2388085755126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388085755126 : Closed e2388085755126 ∧ code e2388085755126 = 11184178777334 := by decide
theorem cert_e2388085755126 : check e2388085755126 [[],[.left],[]] .chain = true := by decide
def e2388085755502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388085755502 : Closed e2388085755502 ∧ code e2388085755502 = 11184178777710 := by decide
theorem cert_e2388085755502 : check e2388085755502 [[],[.left],[]] .chain = true := by decide
def e2388085755514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388085755514 : Closed e2388085755514 ∧ code e2388085755514 = 11184178777722 := by decide
theorem cert_e2388085755514 : check e2388085755514 [[],[.left],[]] .chain = true := by decide
def e2388085755702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388085755702 : Closed e2388085755702 ∧ code e2388085755702 = 11184178777910 := by decide
theorem cert_e2388085755702 : check e2388085755702 [[],[.left],[]] .chain = true := by decide
def e2388085755706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388085755706 : Closed e2388085755706 ∧ code e2388085755706 = 11184178777914 := by decide
theorem cert_e2388085755706 : check e2388085755706 [[],[.left],[]] .chain = true := by decide
def e2388085761454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2388085761454 : Closed e2388085761454 ∧ code e2388085761454 = 11184178783662 := by decide
theorem cert_e2388085761454 : check e2388085761454 [[],[.left],[]] .chain = true := by decide
def e2388085761466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2388085761466 : Closed e2388085761466 ∧ code e2388085761466 = 11184178783674 := by decide
theorem cert_e2388085761466 : check e2388085761466 [[],[.left],[]] .chain = true := by decide
def e2388085761514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2388085761514 : Closed e2388085761514 ∧ code e2388085761514 = 11184178783722 := by decide
theorem cert_e2388085761514 : check e2388085761514 [[],[.left],[]] .chain = true := by decide
def e2388085761646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2388085761646 : Closed e2388085761646 ∧ code e2388085761646 = 11184178783854 := by decide
theorem cert_e2388085761646 : check e2388085761646 [[],[.left],[]] .chain = true := by decide
def e2388085761658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2388085761658 : Closed e2388085761658 ∧ code e2388085761658 = 11184178783866 := by decide
theorem cert_e2388085761658 : check e2388085761658 [[],[.left],[]] .chain = true := by decide
def e2388085761946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2388085761946 : Closed e2388085761946 ∧ code e2388085761946 = 11184178784154 := by decide
theorem cert_e2388085761946 : check e2388085761946 [[],[.left],[]] .chain = true := by decide
def e2388085764822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2388085764822 : Closed e2388085764822 ∧ code e2388085764822 = 11184178787030 := by decide
theorem cert_e2388085764822 : check e2388085764822 [[],[.left],[]] .chain = true := by decide
def e2388085764826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2388085764826 : Closed e2388085764826 ∧ code e2388085764826 = 11184178787034 := by decide
theorem cert_e2388085764826 : check e2388085764826 [[],[.left],[]] .chain = true := by decide
def e2388085764842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2388085764842 : Closed e2388085764842 ∧ code e2388085764842 = 11184178787050 := by decide
theorem cert_e2388085764842 : check e2388085764842 [[],[.left],[]] .chain = true := by decide
def e2388085764918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2388085764918 : Closed e2388085764918 ∧ code e2388085764918 = 11184178787126 := by decide
theorem cert_e2388085764918 : check e2388085764918 [[],[.left],[]] .chain = true := by decide
def e2388085764922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2388085764922 : Closed e2388085764922 ∧ code e2388085764922 = 11184178787130 := by decide
theorem cert_e2388085764922 : check e2388085764922 [[],[.left],[]] .chain = true := by decide
def e2388085765018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2388085765018 : Closed e2388085765018 ∧ code e2388085765018 = 11184178787226 := by decide
theorem cert_e2388085765018 : check e2388085765018 [[],[.left],[]] .chain = true := by decide
def e2388085902190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388085902190 : Closed e2388085902190 ∧ code e2388085902190 = 11184178924398 := by decide
theorem cert_e2388085902190 : check e2388085902190 [[],[.left],[],[]] .chain = true := by decide
def e2388085902198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388085902198 : Closed e2388085902198 ∧ code e2388085902198 = 11184178924406 := by decide
theorem cert_e2388085902198 : check e2388085902198 [[],[.left],[],[]] .chain = true := by decide
def e2388085902254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388085902254 : Closed e2388085902254 ∧ code e2388085902254 = 11184178924462 := by decide
theorem cert_e2388085902254 : check e2388085902254 [[],[.left],[],[]] .chain = true := by decide
def e2388085902266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388085902266 : Closed e2388085902266 ∧ code e2388085902266 = 11184178924474 := by decide
theorem cert_e2388085902266 : check e2388085902266 [[],[.left],[],[]] .chain = true := by decide
def e2388085902294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388085902294 : Closed e2388085902294 ∧ code e2388085902294 = 11184178924502 := by decide
theorem cert_e2388085902294 : check e2388085902294 [[],[.left],[],[]] .chain = true := by decide
def e2388085902298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388085902298 : Closed e2388085902298 ∧ code e2388085902298 = 11184178924506 := by decide
theorem cert_e2388085902298 : check e2388085902298 [[],[.left],[],[]] .chain = true := by decide
def e2388085902574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388085902574 : Closed e2388085902574 ∧ code e2388085902574 = 11184178924782 := by decide
theorem cert_e2388085902574 : check e2388085902574 [[],[.left],[],[]] .chain = true := by decide
def e2388085902582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388085902582 : Closed e2388085902582 ∧ code e2388085902582 = 11184178924790 := by decide
theorem cert_e2388085902582 : check e2388085902582 [[],[.left],[],[]] .chain = true := by decide
def e2388085902958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388085902958 : Closed e2388085902958 ∧ code e2388085902958 = 11184178925166 := by decide
theorem cert_e2388085902958 : check e2388085902958 [[],[.left],[],[]] .chain = true := by decide
def e2388085902970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388085902970 : Closed e2388085902970 ∧ code e2388085902970 = 11184178925178 := by decide
theorem cert_e2388085902970 : check e2388085902970 [[],[.left],[],[]] .chain = true := by decide
def e2388085903158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388085903158 : Closed e2388085903158 ∧ code e2388085903158 = 11184178925366 := by decide
theorem cert_e2388085903158 : check e2388085903158 [[],[.left],[],[]] .chain = true := by decide
def e2388085903162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388085903162 : Closed e2388085903162 ∧ code e2388085903162 = 11184178925370 := by decide
theorem cert_e2388085903162 : check e2388085903162 [[],[.left],[],[]] .chain = true := by decide
def e2388086492014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388086492014 : Closed e2388086492014 ∧ code e2388086492014 = 11184179514222 := by decide
theorem cert_e2388086492014 : check e2388086492014 [[],[.left]] .chain = true := by decide
def e2388086492022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388086492022 : Closed e2388086492022 ∧ code e2388086492022 = 11184179514230 := by decide
theorem cert_e2388086492022 : check e2388086492022 [[],[.left]] .chain = true := by decide
def e2388086492078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388086492078 : Closed e2388086492078 ∧ code e2388086492078 = 11184179514286 := by decide
theorem cert_e2388086492078 : check e2388086492078 [[],[.left]] .chain = true := by decide
def e2388086492090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388086492090 : Closed e2388086492090 ∧ code e2388086492090 = 11184179514298 := by decide
theorem cert_e2388086492090 : check e2388086492090 [[],[.left]] .chain = true := by decide
def e2388086492118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388086492118 : Closed e2388086492118 ∧ code e2388086492118 = 11184179514326 := by decide
theorem cert_e2388086492118 : check e2388086492118 [[],[.left]] .chain = true := by decide
def e2388086492122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388086492122 : Closed e2388086492122 ∧ code e2388086492122 = 11184179514330 := by decide
theorem cert_e2388086492122 : check e2388086492122 [[],[.left]] .chain = true := by decide
def e2388086492398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388086492398 : Closed e2388086492398 ∧ code e2388086492398 = 11184179514606 := by decide
theorem cert_e2388086492398 : check e2388086492398 [[],[.left]] .chain = true := by decide
def e2388086492406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388086492406 : Closed e2388086492406 ∧ code e2388086492406 = 11184179514614 := by decide
theorem cert_e2388086492406 : check e2388086492406 [[],[.left]] .chain = true := by decide
def e2388086492782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388086492782 : Closed e2388086492782 ∧ code e2388086492782 = 11184179514990 := by decide
theorem cert_e2388086492782 : check e2388086492782 [[],[.left]] .chain = true := by decide
def e2388086492794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388086492794 : Closed e2388086492794 ∧ code e2388086492794 = 11184179515002 := by decide
theorem cert_e2388086492794 : check e2388086492794 [[],[.left]] .chain = true := by decide
def e2388086492982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388086492982 : Closed e2388086492982 ∧ code e2388086492982 = 11184179515190 := by decide
theorem cert_e2388086492982 : check e2388086492982 [[],[.left]] .chain = true := by decide
def e2388086492986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388086492986 : Closed e2388086492986 ∧ code e2388086492986 = 11184179515194 := by decide
theorem cert_e2388086492986 : check e2388086492986 [[],[.left]] .chain = true := by decide
def e2388182546970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388182546970 : Closed e2388182546970 ∧ code e2388182546970 = 11184275569178 := by decide
theorem cert_e2388182546970 : check e2388182546970 [[]] .width = true := by decide
def e2388182555162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388182555162 : Closed e2388182555162 ∧ code e2388182555162 = 11184275577370 := by decide
theorem cert_e2388182555162 : check e2388182555162 [[]] .width = true := by decide
def e2388183672858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388183672858 : Closed e2388183672858 ∧ code e2388183672858 = 11184276695066 := by decide
theorem cert_e2388183672858 : check e2388183672858 [[]] .width = true := by decide
def e2388183705626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388183705626 : Closed e2388183705626 ∧ code e2388183705626 = 11184276727834 := by decide
theorem cert_e2388183705626 : check e2388183705626 [[]] .width = true := by decide
def e2388183792154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388183792154 : Closed e2388183792154 ∧ code e2388183792154 = 11184276814362 := by decide
theorem cert_e2388183792154 : check e2388183792154 [[]] .width = true := by decide
def e2388183935002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388183935002 : Closed e2388183935002 ∧ code e2388183935002 = 11184276957210 := by decide
theorem cert_e2388183935002 : check e2388183935002 [[]] .width = true := by decide
def e2388183976474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388183976474 : Closed e2388183976474 ∧ code e2388183976474 = 11184276998682 := by decide
theorem cert_e2388183976474 : check e2388183976474 [[]] .width = true := by decide
def e2388183984154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388183984154 : Closed e2388183984154 ∧ code e2388183984154 = 11184277006362 := by decide
theorem cert_e2388183984154 : check e2388183984154 [[]] .width = true := by decide
def e2388183988762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388183988762 : Closed e2388183988762 ∧ code e2388183988762 = 11184277010970 := by decide
theorem cert_e2388183988762 : check e2388183988762 [[]] .width = true := by decide
def e2388184029722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388184029722 : Closed e2388184029722 ∧ code e2388184029722 = 11184277051930 := by decide
theorem cert_e2388184029722 : check e2388184029722 [[]] .width = true := by decide
def e2388184098842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388184098842 : Closed e2388184098842 ∧ code e2388184098842 = 11184277121050 := by decide
theorem cert_e2388184098842 : check e2388184098842 [[]] .width = true := by decide
def e2388184107546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388184107546 : Closed e2388184107546 ∧ code e2388184107546 = 11184277129754 := by decide
theorem cert_e2388184107546 : check e2388184107546 [[]] .width = true := by decide
def e2388184115226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388184115226 : Closed e2388184115226 ∧ code e2388184115226 = 11184277137434 := by decide
theorem cert_e2388184115226 : check e2388184115226 [[]] .width = true := by decide
def e2388184119834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388184119834 : Closed e2388184119834 ∧ code e2388184119834 = 11184277142042 := by decide
theorem cert_e2388184119834 : check e2388184119834 [[]] .width = true := by decide
def e2388184128026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388184128026 : Closed e2388184128026 ∧ code e2388184128026 = 11184277150234 := by decide
theorem cert_e2388184128026 : check e2388184128026 [[]] .width = true := by decide
def e2388184447514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388184447514 : Closed e2388184447514 ∧ code e2388184447514 = 11184277469722 := by decide
theorem cert_e2388184447514 : check e2388184447514 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2388062345754
#print axioms Blc.Floor43.cert_e2388062542362
