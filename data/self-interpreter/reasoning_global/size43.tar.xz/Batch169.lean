import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262374970310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2262374970310 : Closed e2262374970310 ∧ code e2262374970310 = 11058467992518 := by decide
theorem cert_e2262374970310 : check e2262374970310 [[],[.under]] .smaller = true := by decide
def e2262374970334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2262374970334 : Closed e2262374970334 ∧ code e2262374970334 = 11058467992542 := by decide
theorem cert_e2262374970334 : check e2262374970334 [[],[.under]] .three = true := by decide
def e2262374970350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2262374970350 : Closed e2262374970350 ∧ code e2262374970350 = 11058467992558 := by decide
theorem cert_e2262374970350 : check e2262374970350 [[],[.under]] .three = true := by decide
def e2262374971510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2262374971510 : Closed e2262374971510 ∧ code e2262374971510 = 11058467993718 := by decide
theorem cert_e2262374971510 : check e2262374971510 [[],[.under]] .smaller = true := by decide
def e2262374971754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2262374971754 : Closed e2262374971754 ∧ code e2262374971754 = 11058467993962 := by decide
theorem cert_e2262374971754 : check e2262374971754 [[],[.under]] .smaller = true := by decide
def e2262374971790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2262374971790 : Closed e2262374971790 ∧ code e2262374971790 = 11058467993998 := by decide
theorem cert_e2262374971790 : check e2262374971790 [[],[.under]] .smaller = true := by decide
def e2262374971802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262374971802 : Closed e2262374971802 ∧ code e2262374971802 = 11058467994010 := by decide
theorem cert_e2262374971802 : check e2262374971802 [[],[.under]] .smaller = true := by decide
def e2262374971846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2262374971846 : Closed e2262374971846 ∧ code e2262374971846 = 11058467994054 := by decide
theorem cert_e2262374971846 : check e2262374971846 [[],[.under]] .smaller = true := by decide
def e2262374971870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2262374971870 : Closed e2262374971870 ∧ code e2262374971870 = 11058467994078 := by decide
theorem cert_e2262374971870 : check e2262374971870 [[],[.under]] .three = true := by decide
def e2262374971894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2262374971894 : Closed e2262374971894 ∧ code e2262374971894 = 11058467994102 := by decide
theorem cert_e2262374971894 : check e2262374971894 [[],[.under]] .three = true := by decide
def e2262374972614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2262374972614 : Closed e2262374972614 ∧ code e2262374972614 = 11058467994822 := by decide
theorem cert_e2262374972614 : check e2262374972614 [[],[.under]] .three = true := by decide
def e2262374972638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 3)))))))))
theorem wire_e2262374972638 : Closed e2262374972638 ∧ code e2262374972638 = 11058467994846 := by decide
theorem cert_e2262374972638 : check e2262374972638 [[],[.under]] .three = true := by decide
def e2262374972654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262374972654 : Closed e2262374972654 ∧ code e2262374972654 = 11058467994862 := by decide
theorem cert_e2262374972654 : check e2262374972654 [[],[.under]] .three = true := by decide
def e2262374972662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262374972662 : Closed e2262374972662 ∧ code e2262374972662 = 11058467994870 := by decide
theorem cert_e2262374972662 : check e2262374972662 [[],[.under]] .three = true := by decide
def e2262374972666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 0)))))))))
theorem wire_e2262374972666 : Closed e2262374972666 ∧ code e2262374972666 = 11058467994874 := by decide
theorem cert_e2262374972666 : check e2262374972666 [[],[.under]] .three = true := by decide
def e2262375017302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2262375017302 : Closed e2262375017302 ∧ code e2262375017302 = 11058468039510 := by decide
theorem cert_e2262375017302 : check e2262375017302 [[],[.under]] .smaller = true := by decide
def e2262375017306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2262375017306 : Closed e2262375017306 ∧ code e2262375017306 = 11058468039514 := by decide
theorem cert_e2262375017306 : check e2262375017306 [[],[.under]] .smaller = true := by decide
def e2262375017322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2262375017322 : Closed e2262375017322 ∧ code e2262375017322 = 11058468039530 := by decide
theorem cert_e2262375017322 : check e2262375017322 [[],[.under]] .smaller = true := by decide
def e2262375017386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2262375017386 : Closed e2262375017386 ∧ code e2262375017386 = 11058468039594 := by decide
theorem cert_e2262375017386 : check e2262375017386 [[],[.under]] .smaller = true := by decide
def e2262375017590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2262375017590 : Closed e2262375017590 ∧ code e2262375017590 = 11058468039798 := by decide
theorem cert_e2262375017590 : check e2262375017590 [[],[.under]] .smaller = true := by decide
def e2262375017686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2262375017686 : Closed e2262375017686 ∧ code e2262375017686 = 11058468039894 := by decide
theorem cert_e2262375017686 : check e2262375017686 [[],[.under]] .smaller = true := by decide
def e2262375017690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2262375017690 : Closed e2262375017690 ∧ code e2262375017690 = 11058468039898 := by decide
theorem cert_e2262375017690 : check e2262375017690 [[],[.under]] .smaller = true := by decide
def e2262375017706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2262375017706 : Closed e2262375017706 ∧ code e2262375017706 = 11058468039914 := by decide
theorem cert_e2262375017706 : check e2262375017706 [[],[.under]] .smaller = true := by decide
def e2262375017782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262375017782 : Closed e2262375017782 ∧ code e2262375017782 = 11058468039990 := by decide
theorem cert_e2262375017782 : check e2262375017782 [[],[.under]] .smaller = true := by decide
def e2262375017786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262375017786 : Closed e2262375017786 ∧ code e2262375017786 = 11058468039994 := by decide
theorem cert_e2262375017786 : check e2262375017786 [[],[.under]] .smaller = true := by decide
def e2262375017870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2262375017870 : Closed e2262375017870 ∧ code e2262375017870 = 11058468040078 := by decide
theorem cert_e2262375017870 : check e2262375017870 [[],[.under]] .smaller = true := by decide
def e2262375017882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262375017882 : Closed e2262375017882 ∧ code e2262375017882 = 11058468040090 := by decide
theorem cert_e2262375017882 : check e2262375017882 [[],[.under]] .smaller = true := by decide
def e2262375017950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2262375017950 : Closed e2262375017950 ∧ code e2262375017950 = 11058468040158 := by decide
theorem cert_e2262375017950 : check e2262375017950 [[],[.under]] .three = true := by decide
def e2262375017966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2262375017966 : Closed e2262375017966 ∧ code e2262375017966 = 11058468040174 := by decide
theorem cert_e2262375017966 : check e2262375017966 [[],[.under]] .three = true := by decide
def e2262375018038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2262375018038 : Closed e2262375018038 ∧ code e2262375018038 = 11058468040246 := by decide
theorem cert_e2262375018038 : check e2262375018038 [[],[.under]] .smaller = true := by decide
def e2262375018042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2262375018042 : Closed e2262375018042 ∧ code e2262375018042 = 11058468040250 := by decide
theorem cert_e2262375018042 : check e2262375018042 [[],[.under]] .smaller = true := by decide
def e2262375018090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2262375018090 : Closed e2262375018090 ∧ code e2262375018090 = 11058468040298 := by decide
theorem cert_e2262375018090 : check e2262375018090 [[],[.under]] .smaller = true := by decide
def e2262375018126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2262375018126 : Closed e2262375018126 ∧ code e2262375018126 = 11058468040334 := by decide
theorem cert_e2262375018126 : check e2262375018126 [[],[.under]] .smaller = true := by decide
def e2262375018138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262375018138 : Closed e2262375018138 ∧ code e2262375018138 = 11058468040346 := by decide
theorem cert_e2262375018138 : check e2262375018138 [[],[.under]] .smaller = true := by decide
def e2262375018182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2262375018182 : Closed e2262375018182 ∧ code e2262375018182 = 11058468040390 := by decide
theorem cert_e2262375018182 : check e2262375018182 [[],[.under]] .smaller = true := by decide
def e2262375018206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2262375018206 : Closed e2262375018206 ∧ code e2262375018206 = 11058468040414 := by decide
theorem cert_e2262375018206 : check e2262375018206 [[],[.under]] .three = true := by decide
def e2262375018230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2262375018230 : Closed e2262375018230 ∧ code e2262375018230 = 11058468040438 := by decide
theorem cert_e2262375018230 : check e2262375018230 [[],[.under]] .three = true := by decide
def e2262375018334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2262375018334 : Closed e2262375018334 ∧ code e2262375018334 = 11058468040542 := by decide
theorem cert_e2262375018334 : check e2262375018334 [[],[.under]] .three = true := by decide
def e2262375018362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2262375018362 : Closed e2262375018362 ∧ code e2262375018362 = 11058468040570 := by decide
theorem cert_e2262375018362 : check e2262375018362 [[],[.under]] .three = true := by decide
def e2262375018414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2262375018414 : Closed e2262375018414 ∧ code e2262375018414 = 11058468040622 := by decide
theorem cert_e2262375018414 : check e2262375018414 [[],[.under]] .three = true := by decide
def e2262375018422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2262375018422 : Closed e2262375018422 ∧ code e2262375018422 = 11058468040630 := by decide
theorem cert_e2262375018422 : check e2262375018422 [[],[.under]] .three = true := by decide
def e2262375018426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2262375018426 : Closed e2262375018426 ∧ code e2262375018426 = 11058468040634 := by decide
theorem cert_e2262375018426 : check e2262375018426 [[],[.under]] .three = true := by decide
def e2262375018734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2262375018734 : Closed e2262375018734 ∧ code e2262375018734 = 11058468040942 := by decide
theorem cert_e2262375018734 : check e2262375018734 [[],[.under]] .smaller = true := by decide
def e2262375018742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2262375018742 : Closed e2262375018742 ∧ code e2262375018742 = 11058468040950 := by decide
theorem cert_e2262375018742 : check e2262375018742 [[],[.under]] .smaller = true := by decide
def e2262375019222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2262375019222 : Closed e2262375019222 ∧ code e2262375019222 = 11058468041430 := by decide
theorem cert_e2262375019222 : check e2262375019222 [[],[.under]] .smaller = true := by decide
def e2262375019226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2262375019226 : Closed e2262375019226 ∧ code e2262375019226 = 11058468041434 := by decide
theorem cert_e2262375019226 : check e2262375019226 [[],[.under]] .smaller = true := by decide
def e2262375019242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2262375019242 : Closed e2262375019242 ∧ code e2262375019242 = 11058468041450 := by decide
theorem cert_e2262375019242 : check e2262375019242 [[],[.under]] .smaller = true := by decide
def e2262375019318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262375019318 : Closed e2262375019318 ∧ code e2262375019318 = 11058468041526 := by decide
theorem cert_e2262375019318 : check e2262375019318 [[],[.under]] .smaller = true := by decide
def e2262375019322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262375019322 : Closed e2262375019322 ∧ code e2262375019322 = 11058468041530 := by decide
theorem cert_e2262375019322 : check e2262375019322 [[],[.under]] .smaller = true := by decide
def e2262375019406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2262375019406 : Closed e2262375019406 ∧ code e2262375019406 = 11058468041614 := by decide
theorem cert_e2262375019406 : check e2262375019406 [[],[.under]] .smaller = true := by decide
def e2262375019418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262375019418 : Closed e2262375019418 ∧ code e2262375019418 = 11058468041626 := by decide
theorem cert_e2262375019418 : check e2262375019418 [[],[.under]] .smaller = true := by decide
def e2262375019486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2262375019486 : Closed e2262375019486 ∧ code e2262375019486 = 11058468041694 := by decide
theorem cert_e2262375019486 : check e2262375019486 [[],[.under]] .three = true := by decide
def e2262375019502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2262375019502 : Closed e2262375019502 ∧ code e2262375019502 = 11058468041710 := by decide
theorem cert_e2262375019502 : check e2262375019502 [[],[.under]] .three = true := by decide
def e2262375020662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2262375020662 : Closed e2262375020662 ∧ code e2262375020662 = 11058468042870 := by decide
theorem cert_e2262375020662 : check e2262375020662 [[],[.under]] .smaller = true := by decide
def e2262375020906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2262375020906 : Closed e2262375020906 ∧ code e2262375020906 = 11058468043114 := by decide
theorem cert_e2262375020906 : check e2262375020906 [[],[.under]] .smaller = true := by decide
def e2262375020942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2262375020942 : Closed e2262375020942 ∧ code e2262375020942 = 11058468043150 := by decide
theorem cert_e2262375020942 : check e2262375020942 [[],[.under]] .smaller = true := by decide
def e2262375020954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2262375020954 : Closed e2262375020954 ∧ code e2262375020954 = 11058468043162 := by decide
theorem cert_e2262375020954 : check e2262375020954 [[],[.under]] .smaller = true := by decide
def e2262375020998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2262375020998 : Closed e2262375020998 ∧ code e2262375020998 = 11058468043206 := by decide
theorem cert_e2262375020998 : check e2262375020998 [[],[.under]] .smaller = true := by decide
def e2262375021022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2262375021022 : Closed e2262375021022 ∧ code e2262375021022 = 11058468043230 := by decide
theorem cert_e2262375021022 : check e2262375021022 [[],[.under]] .three = true := by decide
def e2262375021046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2262375021046 : Closed e2262375021046 ∧ code e2262375021046 = 11058468043254 := by decide
theorem cert_e2262375021046 : check e2262375021046 [[],[.under]] .three = true := by decide
def e2262375021790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2262375021790 : Closed e2262375021790 ∧ code e2262375021790 = 11058468043998 := by decide
theorem cert_e2262375021790 : check e2262375021790 [[],[.under]] .three = true := by decide
def e2262375021818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2262375021818 : Closed e2262375021818 ∧ code e2262375021818 = 11058468044026 := by decide
theorem cert_e2262375021818 : check e2262375021818 [[],[.under]] .three = true := by decide
def e2262375022190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262375022190 : Closed e2262375022190 ∧ code e2262375022190 = 11058468044398 := by decide
theorem cert_e2262375022190 : check e2262375022190 [[],[.under]] .three = true := by decide
def e2262375022198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262375022198 : Closed e2262375022198 ∧ code e2262375022198 = 11058468044406 := by decide
theorem cert_e2262375022198 : check e2262375022198 [[],[.under]] .three = true := by decide
def e2262375022202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262375022202 : Closed e2262375022202 ∧ code e2262375022202 = 11058468044410 := by decide
theorem cert_e2262375022202 : check e2262375022202 [[],[.under]] .three = true := by decide
def e2262375044662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2262375044662 : Closed e2262375044662 ∧ code e2262375044662 = 11058468066870 := by decide
theorem cert_e2262375044662 : check e2262375044662 [[],[.under]] .three = true := by decide
def e2262375044666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2262375044666 : Closed e2262375044666 ∧ code e2262375044666 = 11058468066874 := by decide
theorem cert_e2262375044666 : check e2262375044666 [[],[.under]] .three = true := by decide
def e2262375044750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2262375044750 : Closed e2262375044750 ∧ code e2262375044750 = 11058468066958 := by decide
theorem cert_e2262375044750 : check e2262375044750 [[],[.under]] .three = true := by decide
def e2262375044806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2262375044806 : Closed e2262375044806 ∧ code e2262375044806 = 11058468067014 := by decide
theorem cert_e2262375044806 : check e2262375044806 [[],[.under]] .three = true := by decide
def e2262375044830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2262375044830 : Closed e2262375044830 ∧ code e2262375044830 = 11058468067038 := by decide
theorem cert_e2262375044830 : check e2262375044830 [[],[.under]] .three = true := by decide
def e2262375044846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2262375044846 : Closed e2262375044846 ∧ code e2262375044846 = 11058468067054 := by decide
theorem cert_e2262375044846 : check e2262375044846 [[],[.under]] .three = true := by decide
def e2262375044854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2262375044854 : Closed e2262375044854 ∧ code e2262375044854 = 11058468067062 := by decide
theorem cert_e2262375044854 : check e2262375044854 [[],[.under]] .three = true := by decide
def e2262375044890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2262375044890 : Closed e2262375044890 ∧ code e2262375044890 = 11058468067098 := by decide
theorem cert_e2262375044890 : check e2262375044890 [[],[.under]] .three = true := by decide
def e2262375044934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2262375044934 : Closed e2262375044934 ∧ code e2262375044934 = 11058468067142 := by decide
theorem cert_e2262375044934 : check e2262375044934 [[],[.under]] .three = true := by decide
def e2262375044958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2262375044958 : Closed e2262375044958 ∧ code e2262375044958 = 11058468067166 := by decide
theorem cert_e2262375044958 : check e2262375044958 [[],[.under]] .three = true := by decide
def e2262375044974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2262375044974 : Closed e2262375044974 ∧ code e2262375044974 = 11058468067182 := by decide
theorem cert_e2262375044974 : check e2262375044974 [[],[.under]] .three = true := by decide
def e2262375044982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2262375044982 : Closed e2262375044982 ∧ code e2262375044982 = 11058468067190 := by decide
theorem cert_e2262375044982 : check e2262375044982 [[],[.under]] .three = true := by decide
def e2262375044986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2262375044986 : Closed e2262375044986 ∧ code e2262375044986 = 11058468067194 := by decide
theorem cert_e2262375044986 : check e2262375044986 [[],[.under]] .three = true := by decide
def e2262375045038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2262375045038 : Closed e2262375045038 ∧ code e2262375045038 = 11058468067246 := by decide
theorem cert_e2262375045038 : check e2262375045038 [[],[.under]] .three = true := by decide
def e2262375045046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2262375045046 : Closed e2262375045046 ∧ code e2262375045046 = 11058468067254 := by decide
theorem cert_e2262375045046 : check e2262375045046 [[],[.under]] .three = true := by decide
def e2262375045050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2262375045050 : Closed e2262375045050 ∧ code e2262375045050 = 11058468067258 := by decide
theorem cert_e2262375045050 : check e2262375045050 [[],[.under]] .three = true := by decide
def e2262375045078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2262375045078 : Closed e2262375045078 ∧ code e2262375045078 = 11058468067286 := by decide
theorem cert_e2262375045078 : check e2262375045078 [[],[.under]] .three = true := by decide
def e2262375045082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2262375045082 : Closed e2262375045082 ∧ code e2262375045082 = 11058468067290 := by decide
theorem cert_e2262375045082 : check e2262375045082 [[],[.under]] .three = true := by decide
def e2262375045518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2262375045518 : Closed e2262375045518 ∧ code e2262375045518 = 11058468067726 := by decide
theorem cert_e2262375045518 : check e2262375045518 [[],[.under]] .three = true := by decide
def e2262375045574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2262375045574 : Closed e2262375045574 ∧ code e2262375045574 = 11058468067782 := by decide
theorem cert_e2262375045574 : check e2262375045574 [[],[.under]] .three = true := by decide
def e2262375045598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2262375045598 : Closed e2262375045598 ∧ code e2262375045598 = 11058468067806 := by decide
theorem cert_e2262375045598 : check e2262375045598 [[],[.under]] .three = true := by decide
def e2262375045614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262375045614 : Closed e2262375045614 ∧ code e2262375045614 = 11058468067822 := by decide
theorem cert_e2262375045614 : check e2262375045614 [[],[.under]] .three = true := by decide
def e2262375045622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2262375045622 : Closed e2262375045622 ∧ code e2262375045622 = 11058468067830 := by decide
theorem cert_e2262375045622 : check e2262375045622 [[],[.under]] .three = true := by decide
def e2262375046342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2262375046342 : Closed e2262375046342 ∧ code e2262375046342 = 11058468068550 := by decide
theorem cert_e2262375046342 : check e2262375046342 [[],[.under]] .three = true := by decide
def e2262375046366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2262375046366 : Closed e2262375046366 ∧ code e2262375046366 = 11058468068574 := by decide
theorem cert_e2262375046366 : check e2262375046366 [[],[.under]] .three = true := by decide
def e2262375046382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262375046382 : Closed e2262375046382 ∧ code e2262375046382 = 11058468068590 := by decide
theorem cert_e2262375046382 : check e2262375046382 [[],[.under]] .three = true := by decide
def e2262375046390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262375046390 : Closed e2262375046390 ∧ code e2262375046390 = 11058468068598 := by decide
theorem cert_e2262375046390 : check e2262375046390 [[],[.under]] .three = true := by decide
def e2262375046394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2262375046394 : Closed e2262375046394 ∧ code e2262375046394 = 11058468068602 := by decide
theorem cert_e2262375046394 : check e2262375046394 [[],[.under]] .three = true := by decide
def e2262375046766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262375046766 : Closed e2262375046766 ∧ code e2262375046766 = 11058468068974 := by decide
theorem cert_e2262375046766 : check e2262375046766 [[],[.under]] .three = true := by decide
def e2262375046774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262375046774 : Closed e2262375046774 ∧ code e2262375046774 = 11058468068982 := by decide
theorem cert_e2262375046774 : check e2262375046774 [[],[.under]] .three = true := by decide
def e2262375046778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262375046778 : Closed e2262375046778 ∧ code e2262375046778 = 11058468068986 := by decide
theorem cert_e2262375046778 : check e2262375046778 [[],[.under]] .three = true := by decide
def e2262375046966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262375046966 : Closed e2262375046966 ∧ code e2262375046966 = 11058468069174 := by decide
theorem cert_e2262375046966 : check e2262375046966 [[],[.under]] .three = true := by decide
def e2262375046970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262375046970 : Closed e2262375046970 ∧ code e2262375046970 = 11058468069178 := by decide
theorem cert_e2262375046970 : check e2262375046970 [[],[.under]] .three = true := by decide
def e2262376336238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262376336238 : Closed e2262376336238 ∧ code e2262376336238 = 11058469358446 := by decide
theorem cert_e2262376336238 : check e2262376336238 [[],[.under]] .three = true := by decide
def e2262376336246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262376336246 : Closed e2262376336246 ∧ code e2262376336246 = 11058469358454 := by decide
theorem cert_e2262376336246 : check e2262376336246 [[],[.under]] .three = true := by decide
def e2262376336302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262376336302 : Closed e2262376336302 ∧ code e2262376336302 = 11058469358510 := by decide
theorem cert_e2262376336302 : check e2262376336302 [[],[.under]] .three = true := by decide
def e2262376336314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262376336314 : Closed e2262376336314 ∧ code e2262376336314 = 11058469358522 := by decide
theorem cert_e2262376336314 : check e2262376336314 [[],[.under]] .three = true := by decide
def e2262376336342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262376336342 : Closed e2262376336342 ∧ code e2262376336342 = 11058469358550 := by decide
theorem cert_e2262376336342 : check e2262376336342 [[],[.under]] .three = true := by decide
def e2262376336346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262376336346 : Closed e2262376336346 ∧ code e2262376336346 = 11058469358554 := by decide
theorem cert_e2262376336346 : check e2262376336346 [[],[.under]] .three = true := by decide
def e2262376336622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262376336622 : Closed e2262376336622 ∧ code e2262376336622 = 11058469358830 := by decide
theorem cert_e2262376336622 : check e2262376336622 [[],[.under]] .three = true := by decide
def e2262376336630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262376336630 : Closed e2262376336630 ∧ code e2262376336630 = 11058469358838 := by decide
theorem cert_e2262376336630 : check e2262376336630 [[],[.under]] .three = true := by decide
def e2262376337006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262376337006 : Closed e2262376337006 ∧ code e2262376337006 = 11058469359214 := by decide
theorem cert_e2262376337006 : check e2262376337006 [[],[.under]] .three = true := by decide
def e2262376337018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262376337018 : Closed e2262376337018 ∧ code e2262376337018 = 11058469359226 := by decide
theorem cert_e2262376337018 : check e2262376337018 [[],[.under]] .three = true := by decide
def e2262376337206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262376337206 : Closed e2262376337206 ∧ code e2262376337206 = 11058469359414 := by decide
theorem cert_e2262376337206 : check e2262376337206 [[],[.under]] .three = true := by decide
def e2262376337210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262376337210 : Closed e2262376337210 ∧ code e2262376337210 = 11058469359418 := by decide
theorem cert_e2262376337210 : check e2262376337210 [[],[.under]] .three = true := by decide
def e2262376698742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2262376698742 : Closed e2262376698742 ∧ code e2262376698742 = 11058469720950 := by decide
theorem cert_e2262376698742 : check e2262376698742 [[],[.under]] .three = true := by decide
def e2262376698810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2262376698810 : Closed e2262376698810 ∧ code e2262376698810 = 11058469721018 := by decide
theorem cert_e2262376698810 : check e2262376698810 [[],[.under]] .three = true := by decide
def e2262376698838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2262376698838 : Closed e2262376698838 ∧ code e2262376698838 = 11058469721046 := by decide
theorem cert_e2262376698838 : check e2262376698838 [[],[.under]] .three = true := by decide
def e2262376698842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2262376698842 : Closed e2262376698842 ∧ code e2262376698842 = 11058469721050 := by decide
theorem cert_e2262376698842 : check e2262376698842 [[],[.under]] .three = true := by decide
def e2262376826222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2262376826222 : Closed e2262376826222 ∧ code e2262376826222 = 11058469848430 := by decide
theorem cert_e2262376826222 : check e2262376826222 [[],[.under]] .three = true := by decide
def e2262376826230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2262376826230 : Closed e2262376826230 ∧ code e2262376826230 = 11058469848438 := by decide
theorem cert_e2262376826230 : check e2262376826230 [[],[.under]] .three = true := by decide
def e2262376826286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2262376826286 : Closed e2262376826286 ∧ code e2262376826286 = 11058469848494 := by decide
theorem cert_e2262376826286 : check e2262376826286 [[],[.under]] .three = true := by decide
def e2262376826298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2262376826298 : Closed e2262376826298 ∧ code e2262376826298 = 11058469848506 := by decide
theorem cert_e2262376826298 : check e2262376826298 [[],[.under]] .three = true := by decide
def e2262376826326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2262376826326 : Closed e2262376826326 ∧ code e2262376826326 = 11058469848534 := by decide
theorem cert_e2262376826326 : check e2262376826326 [[],[.under]] .three = true := by decide
def e2262376826330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2262376826330 : Closed e2262376826330 ∧ code e2262376826330 = 11058469848538 := by decide
theorem cert_e2262376826330 : check e2262376826330 [[],[.under]] .three = true := by decide
def e2262376829294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2262376829294 : Closed e2262376829294 ∧ code e2262376829294 = 11058469851502 := by decide
theorem cert_e2262376829294 : check e2262376829294 [[],[.under]] .three = true := by decide
def e2262376829302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2262376829302 : Closed e2262376829302 ∧ code e2262376829302 = 11058469851510 := by decide
theorem cert_e2262376829302 : check e2262376829302 [[],[.under]] .three = true := by decide
def e2262376830510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2262376830510 : Closed e2262376830510 ∧ code e2262376830510 = 11058469852718 := by decide
theorem cert_e2262376830510 : check e2262376830510 [[],[.under]] .three = true := by decide
def e2262376830690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2262376830690 : Closed e2262376830690 ∧ code e2262376830690 = 11058469852898 := by decide
theorem cert_e2262376830690 : check e2262376830690 [[],[.under]] .three = true := by decide
def e2262376830702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2262376830702 : Closed e2262376830702 ∧ code e2262376830702 = 11058469852910 := by decide
theorem cert_e2262376830702 : check e2262376830702 [[],[.under]] .three = true := by decide
def e2262376830742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2262376830742 : Closed e2262376830742 ∧ code e2262376830742 = 11058469852950 := by decide
theorem cert_e2262376830742 : check e2262376830742 [[],[.under]] .three = true := by decide
def e2262376830818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2262376830818 : Closed e2262376830818 ∧ code e2262376830818 = 11058469853026 := by decide
theorem cert_e2262376830818 : check e2262376830818 [[],[.under]] .three = true := by decide
def e2262376830830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2262376830830 : Closed e2262376830830 ∧ code e2262376830830 = 11058469853038 := by decide
theorem cert_e2262376830830 : check e2262376830830 [[],[.under]] .three = true := by decide
def e2262376830838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2262376830838 : Closed e2262376830838 ∧ code e2262376830838 = 11058469853046 := by decide
theorem cert_e2262376830838 : check e2262376830838 [[],[.under]] .three = true := by decide
def e2262376831150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2262376831150 : Closed e2262376831150 ∧ code e2262376831150 = 11058469853358 := by decide
theorem cert_e2262376831150 : check e2262376831150 [[],[.under]] .three = true := by decide
def e2262376831162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2262376831162 : Closed e2262376831162 ∧ code e2262376831162 = 11058469853370 := by decide
theorem cert_e2262376831162 : check e2262376831162 [[],[.under]] .three = true := by decide
def e2262376831534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2262376831534 : Closed e2262376831534 ∧ code e2262376831534 = 11058469853742 := by decide
theorem cert_e2262376831534 : check e2262376831534 [[],[.under]] .three = true := by decide
def e2262376831714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2262376831714 : Closed e2262376831714 ∧ code e2262376831714 = 11058469853922 := by decide
theorem cert_e2262376831714 : check e2262376831714 [[],[.under]] .three = true := by decide
def e2262376831726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2262376831726 : Closed e2262376831726 ∧ code e2262376831726 = 11058469853934 := by decide
theorem cert_e2262376831726 : check e2262376831726 [[],[.under]] .three = true := by decide
def e2262376831854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2262376831854 : Closed e2262376831854 ∧ code e2262376831854 = 11058469854062 := by decide
theorem cert_e2262376831854 : check e2262376831854 [[],[.under]] .three = true := by decide
def e2262376831862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2262376831862 : Closed e2262376831862 ∧ code e2262376831862 = 11058469854070 := by decide
theorem cert_e2262376831862 : check e2262376831862 [[],[.under]] .three = true := by decide
def e2262376831882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376831882 : Closed e2262376831882 ∧ code e2262376831882 = 11058469854090 := by decide
theorem cert_e2262376831882 : check e2262376831882 [[],[.under]] .three = true := by decide
def e2262376831906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376831906 : Closed e2262376831906 ∧ code e2262376831906 = 11058469854114 := by decide
theorem cert_e2262376831906 : check e2262376831906 [[],[.under]] .three = true := by decide
def e2262376831918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2262376831918 : Closed e2262376831918 ∧ code e2262376831918 = 11058469854126 := by decide
theorem cert_e2262376831918 : check e2262376831918 [[],[.under]] .three = true := by decide
def e2262376831926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2262376831926 : Closed e2262376831926 ∧ code e2262376831926 = 11058469854134 := by decide
theorem cert_e2262376831926 : check e2262376831926 [[],[.under]] .three = true := by decide
def e2262376831930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2262376831930 : Closed e2262376831930 ∧ code e2262376831930 = 11058469854138 := by decide
theorem cert_e2262376831930 : check e2262376831930 [[],[.under]] .three = true := by decide
def e2262376832086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2262376832086 : Closed e2262376832086 ∧ code e2262376832086 = 11058469854294 := by decide
theorem cert_e2262376832086 : check e2262376832086 [[],[.under]] .three = true := by decide
def e2262376832090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2262376832090 : Closed e2262376832090 ∧ code e2262376832090 = 11058469854298 := by decide
theorem cert_e2262376832090 : check e2262376832090 [[],[.under]] .three = true := by decide
def e2262376832278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2262376832278 : Closed e2262376832278 ∧ code e2262376832278 = 11058469854486 := by decide
theorem cert_e2262376832278 : check e2262376832278 [[],[.under]] .three = true := by decide
def e2262376832354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2262376832354 : Closed e2262376832354 ∧ code e2262376832354 = 11058469854562 := by decide
theorem cert_e2262376832354 : check e2262376832354 [[],[.under]] .three = true := by decide
def e2262376832366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2262376832366 : Closed e2262376832366 ∧ code e2262376832366 = 11058469854574 := by decide
theorem cert_e2262376832366 : check e2262376832366 [[],[.under]] .three = true := by decide
def e2262376832374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2262376832374 : Closed e2262376832374 ∧ code e2262376832374 = 11058469854582 := by decide
theorem cert_e2262376832374 : check e2262376832374 [[],[.under]] .three = true := by decide
def e2262376832394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2262376832394 : Closed e2262376832394 ∧ code e2262376832394 = 11058469854602 := by decide
theorem cert_e2262376832394 : check e2262376832394 [[],[.under]] .three = true := by decide
def e2262376832418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2262376832418 : Closed e2262376832418 ∧ code e2262376832418 = 11058469854626 := by decide
theorem cert_e2262376832418 : check e2262376832418 [[],[.under]] .three = true := by decide
def e2262376832430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2262376832430 : Closed e2262376832430 ∧ code e2262376832430 = 11058469854638 := by decide
theorem cert_e2262376832430 : check e2262376832430 [[],[.under]] .three = true := by decide
def e2262376832438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2262376832438 : Closed e2262376832438 ∧ code e2262376832438 = 11058469854646 := by decide
theorem cert_e2262376832438 : check e2262376832438 [[],[.under]] .three = true := by decide
def e2262376832442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2262376832442 : Closed e2262376832442 ∧ code e2262376832442 = 11058469854650 := by decide
theorem cert_e2262376832442 : check e2262376832442 [[],[.under]] .three = true := by decide
def e2262376832470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2262376832470 : Closed e2262376832470 ∧ code e2262376832470 = 11058469854678 := by decide
theorem cert_e2262376832470 : check e2262376832470 [[],[.under]] .three = true := by decide
def e2262376832474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2262376832474 : Closed e2262376832474 ∧ code e2262376832474 = 11058469854682 := by decide
theorem cert_e2262376832474 : check e2262376832474 [[],[.under]] .three = true := by decide
def e2262376833710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2262376833710 : Closed e2262376833710 ∧ code e2262376833710 = 11058469855918 := by decide
theorem cert_e2262376833710 : check e2262376833710 [[],[.under]] .three = true := by decide
def e2262376833722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2262376833722 : Closed e2262376833722 ∧ code e2262376833722 = 11058469855930 := by decide
theorem cert_e2262376833722 : check e2262376833722 [[],[.under]] .three = true := by decide
def e2262376833770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2262376833770 : Closed e2262376833770 ∧ code e2262376833770 = 11058469855978 := by decide
theorem cert_e2262376833770 : check e2262376833770 [[],[.under]] .three = true := by decide
def e2262376835246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2262376835246 : Closed e2262376835246 ∧ code e2262376835246 = 11058469857454 := by decide
theorem cert_e2262376835246 : check e2262376835246 [[],[.under]] .three = true := by decide
def e2262376835258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2262376835258 : Closed e2262376835258 ∧ code e2262376835258 = 11058469857466 := by decide
theorem cert_e2262376835258 : check e2262376835258 [[],[.under]] .three = true := by decide
def e2262376835630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2262376835630 : Closed e2262376835630 ∧ code e2262376835630 = 11058469857838 := by decide
theorem cert_e2262376835630 : check e2262376835630 [[],[.under]] .three = true := by decide
end Blc.Floor43
