import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393370725998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2393370725998 : Closed e2393370725998 ∧ code e2393370725998 = 11189463748206 := by decide
theorem cert_e2393370725998 : check e2393370725998 [[],[.left],[]] .smaller = true := by decide
def e2393370726010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2393370726010 : Closed e2393370726010 ∧ code e2393370726010 = 11189463748218 := by decide
theorem cert_e2393370726010 : check e2393370726010 [[],[.left],[]] .smaller = true := by decide
def e2393370726198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2393370726198 : Closed e2393370726198 ∧ code e2393370726198 = 11189463748406 := by decide
theorem cert_e2393370726198 : check e2393370726198 [[],[.left],[]] .smaller = true := by decide
def e2393370726202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2393370726202 : Closed e2393370726202 ∧ code e2393370726202 = 11189463748410 := by decide
theorem cert_e2393370726202 : check e2393370726202 [[],[.left],[]] .smaller = true := by decide
def e2393370734014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2393370734014 : Closed e2393370734014 ∧ code e2393370734014 = 11189463756222 := by decide
theorem cert_e2393370734014 : check e2393370734014 [[],[.left],[]] .three = true := by decide
def e2393370734046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2393370734046 : Closed e2393370734046 ∧ code e2393370734046 = 11189463756254 := by decide
theorem cert_e2393370734046 : check e2393370734046 [[],[.left],[]] .three = true := by decide
def e2393370734062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2393370734062 : Closed e2393370734062 ∧ code e2393370734062 = 11189463756270 := by decide
theorem cert_e2393370734062 : check e2393370734062 [[],[.left],[]] .three = true := by decide
def e2393370734070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2393370734070 : Closed e2393370734070 ∧ code e2393370734070 = 11189463756278 := by decide
theorem cert_e2393370734070 : check e2393370734070 [[],[.left],[]] .three = true := by decide
def e2393370734270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2393370734270 : Closed e2393370734270 ∧ code e2393370734270 = 11189463756478 := by decide
theorem cert_e2393370734270 : check e2393370734270 [[],[.left],[]] .three = true := by decide
def e2393370734302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e2393370734302 : Closed e2393370734302 ∧ code e2393370734302 = 11189463756510 := by decide
theorem cert_e2393370734302 : check e2393370734302 [[],[.left],[]] .three = true := by decide
def e2393370734318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e2393370734318 : Closed e2393370734318 ∧ code e2393370734318 = 11189463756526 := by decide
theorem cert_e2393370734318 : check e2393370734318 [[],[.left],[]] .smaller = true := by decide
def e2393370734326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e2393370734326 : Closed e2393370734326 ∧ code e2393370734326 = 11189463756534 := by decide
theorem cert_e2393370734326 : check e2393370734326 [[],[.left],[]] .three = true := by decide
def e2393370734330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2393370734330 : Closed e2393370734330 ∧ code e2393370734330 = 11189463756538 := by decide
theorem cert_e2393370734330 : check e2393370734330 [[],[.left],[]] .three = true := by decide
def e2393370734430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2393370734430 : Closed e2393370734430 ∧ code e2393370734430 = 11189463756638 := by decide
theorem cert_e2393370734430 : check e2393370734430 [[],[.left],[]] .three = true := by decide
def e2393370734446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e2393370734446 : Closed e2393370734446 ∧ code e2393370734446 = 11189463756654 := by decide
theorem cert_e2393370734446 : check e2393370734446 [[],[.left],[]] .smaller = true := by decide
def e2393370734454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e2393370734454 : Closed e2393370734454 ∧ code e2393370734454 = 11189463756662 := by decide
theorem cert_e2393370734454 : check e2393370734454 [[],[.left],[]] .smaller = true := by decide
def e2393370734458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2393370734458 : Closed e2393370734458 ∧ code e2393370734458 = 11189463756666 := by decide
theorem cert_e2393370734458 : check e2393370734458 [[],[.left],[]] .three = true := by decide
def e2393370734510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2393370734510 : Closed e2393370734510 ∧ code e2393370734510 = 11189463756718 := by decide
theorem cert_e2393370734510 : check e2393370734510 [[],[.left],[]] .three = true := by decide
def e2393370734518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e2393370734518 : Closed e2393370734518 ∧ code e2393370734518 = 11189463756726 := by decide
theorem cert_e2393370734518 : check e2393370734518 [[],[.left],[]] .three = true := by decide
def e2393370734522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2393370734522 : Closed e2393370734522 ∧ code e2393370734522 = 11189463756730 := by decide
theorem cert_e2393370734522 : check e2393370734522 [[],[.left],[]] .three = true := by decide
def e2393370734550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2393370734550 : Closed e2393370734550 ∧ code e2393370734550 = 11189463756758 := by decide
theorem cert_e2393370734550 : check e2393370734550 [[],[.left],[]] .three = true := by decide
def e2393370734554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2393370734554 : Closed e2393370734554 ∧ code e2393370734554 = 11189463756762 := by decide
theorem cert_e2393370734554 : check e2393370734554 [[],[.left],[]] .three = true := by decide
def e2393370735550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2393370735550 : Closed e2393370735550 ∧ code e2393370735550 = 11189463757758 := by decide
theorem cert_e2393370735550 : check e2393370735550 [[],[.left],[]] .three = true := by decide
def e2393370735582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2393370735582 : Closed e2393370735582 ∧ code e2393370735582 = 11189463757790 := by decide
theorem cert_e2393370735582 : check e2393370735582 [[],[.left],[]] .three = true := by decide
def e2393370735598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2393370735598 : Closed e2393370735598 ∧ code e2393370735598 = 11189463757806 := by decide
theorem cert_e2393370735598 : check e2393370735598 [[],[.left],[]] .three = true := by decide
def e2393370735606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2393370735606 : Closed e2393370735606 ∧ code e2393370735606 = 11189463757814 := by decide
theorem cert_e2393370735606 : check e2393370735606 [[],[.left],[]] .three = true := by decide
def e2393370737086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2393370737086 : Closed e2393370737086 ∧ code e2393370737086 = 11189463759294 := by decide
theorem cert_e2393370737086 : check e2393370737086 [[],[.left],[]] .three = true := by decide
def e2393370737118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e2393370737118 : Closed e2393370737118 ∧ code e2393370737118 = 11189463759326 := by decide
theorem cert_e2393370737118 : check e2393370737118 [[],[.left],[]] .three = true := by decide
def e2393370737134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e2393370737134 : Closed e2393370737134 ∧ code e2393370737134 = 11189463759342 := by decide
theorem cert_e2393370737134 : check e2393370737134 [[],[.left],[]] .smaller = true := by decide
def e2393370737142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e2393370737142 : Closed e2393370737142 ∧ code e2393370737142 = 11189463759350 := by decide
theorem cert_e2393370737142 : check e2393370737142 [[],[.left],[]] .three = true := by decide
def e2393370737146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2393370737146 : Closed e2393370737146 ∧ code e2393370737146 = 11189463759354 := by decide
theorem cert_e2393370737146 : check e2393370737146 [[],[.left],[]] .three = true := by decide
def e2393370737886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2393370737886 : Closed e2393370737886 ∧ code e2393370737886 = 11189463760094 := by decide
theorem cert_e2393370737886 : check e2393370737886 [[],[.left],[]] .three = true := by decide
def e2393370737902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393370737902 : Closed e2393370737902 ∧ code e2393370737902 = 11189463760110 := by decide
theorem cert_e2393370737902 : check e2393370737902 [[],[.left],[]] .smaller = true := by decide
def e2393370737910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393370737910 : Closed e2393370737910 ∧ code e2393370737910 = 11189463760118 := by decide
theorem cert_e2393370737910 : check e2393370737910 [[],[.left],[]] .smaller = true := by decide
def e2393370737914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2393370737914 : Closed e2393370737914 ∧ code e2393370737914 = 11189463760122 := by decide
theorem cert_e2393370737914 : check e2393370737914 [[],[.left],[]] .three = true := by decide
def e2393370738286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393370738286 : Closed e2393370738286 ∧ code e2393370738286 = 11189463760494 := by decide
theorem cert_e2393370738286 : check e2393370738286 [[],[.left],[]] .three = true := by decide
def e2393370738294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e2393370738294 : Closed e2393370738294 ∧ code e2393370738294 = 11189463760502 := by decide
theorem cert_e2393370738294 : check e2393370738294 [[],[.left],[]] .three = true := by decide
def e2393370738298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393370738298 : Closed e2393370738298 ∧ code e2393370738298 = 11189463760506 := by decide
theorem cert_e2393370738298 : check e2393370738298 [[],[.left],[]] .three = true := by decide
def e2393370738486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393370738486 : Closed e2393370738486 ∧ code e2393370738486 = 11189463760694 := by decide
theorem cert_e2393370738486 : check e2393370738486 [[],[.left],[]] .three = true := by decide
def e2393370738490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393370738490 : Closed e2393370738490 ∧ code e2393370738490 = 11189463760698 := by decide
theorem cert_e2393370738490 : check e2393370738490 [[],[.left],[]] .three = true := by decide
def e2393370760894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e2393370760894 : Closed e2393370760894 ∧ code e2393370760894 = 11189463783102 := by decide
theorem cert_e2393370760894 : check e2393370760894 [[],[.left],[]] .three = true := by decide
def e2393370760926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2393370760926 : Closed e2393370760926 ∧ code e2393370760926 = 11189463783134 := by decide
theorem cert_e2393370760926 : check e2393370760926 [[],[.left],[]] .three = true := by decide
def e2393370760942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e2393370760942 : Closed e2393370760942 ∧ code e2393370760942 = 11189463783150 := by decide
theorem cert_e2393370760942 : check e2393370760942 [[],[.left],[]] .smaller = true := by decide
def e2393370760950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2393370760950 : Closed e2393370760950 ∧ code e2393370760950 = 11189463783158 := by decide
theorem cert_e2393370760950 : check e2393370760950 [[],[.left],[]] .three = true := by decide
def e2393370760954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e2393370760954 : Closed e2393370760954 ∧ code e2393370760954 = 11189463783162 := by decide
theorem cert_e2393370760954 : check e2393370760954 [[],[.left],[]] .three = true := by decide
def e2393370761054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2393370761054 : Closed e2393370761054 ∧ code e2393370761054 = 11189463783262 := by decide
theorem cert_e2393370761054 : check e2393370761054 [[],[.left],[]] .three = true := by decide
def e2393370761082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2393370761082 : Closed e2393370761082 ∧ code e2393370761082 = 11189463783290 := by decide
theorem cert_e2393370761082 : check e2393370761082 [[],[.left],[]] .three = true := by decide
def e2393370761134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e2393370761134 : Closed e2393370761134 ∧ code e2393370761134 = 11189463783342 := by decide
theorem cert_e2393370761134 : check e2393370761134 [[],[.left],[]] .smaller = true := by decide
def e2393370761146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e2393370761146 : Closed e2393370761146 ∧ code e2393370761146 = 11189463783354 := by decide
theorem cert_e2393370761146 : check e2393370761146 [[],[.left],[]] .smaller = true := by decide
def e2393370761174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2393370761174 : Closed e2393370761174 ∧ code e2393370761174 = 11189463783382 := by decide
theorem cert_e2393370761174 : check e2393370761174 [[],[.left],[]] .three = true := by decide
def e2393370761178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2393370761178 : Closed e2393370761178 ∧ code e2393370761178 = 11189463783386 := by decide
theorem cert_e2393370761178 : check e2393370761178 [[],[.left],[]] .three = true := by decide
def e2393370761194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e2393370761194 : Closed e2393370761194 ∧ code e2393370761194 = 11189463783402 := by decide
theorem cert_e2393370761194 : check e2393370761194 [[],[.left],[]] .three = true := by decide
def e2393370761662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e2393370761662 : Closed e2393370761662 ∧ code e2393370761662 = 11189463783870 := by decide
theorem cert_e2393370761662 : check e2393370761662 [[],[.left],[]] .three = true := by decide
def e2393370761694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2393370761694 : Closed e2393370761694 ∧ code e2393370761694 = 11189463783902 := by decide
theorem cert_e2393370761694 : check e2393370761694 [[],[.left],[]] .three = true := by decide
def e2393370761710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e2393370761710 : Closed e2393370761710 ∧ code e2393370761710 = 11189463783918 := by decide
theorem cert_e2393370761710 : check e2393370761710 [[],[.left],[]] .smaller = true := by decide
def e2393370761718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2393370761718 : Closed e2393370761718 ∧ code e2393370761718 = 11189463783926 := by decide
theorem cert_e2393370761718 : check e2393370761718 [[],[.left],[]] .three = true := by decide
def e2393370761722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e2393370761722 : Closed e2393370761722 ∧ code e2393370761722 = 11189463783930 := by decide
theorem cert_e2393370761722 : check e2393370761722 [[],[.left],[]] .three = true := by decide
def e2393370762462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2393370762462 : Closed e2393370762462 ∧ code e2393370762462 = 11189463784670 := by decide
theorem cert_e2393370762462 : check e2393370762462 [[],[.left],[]] .three = true := by decide
def e2393370762490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2393370762490 : Closed e2393370762490 ∧ code e2393370762490 = 11189463784698 := by decide
theorem cert_e2393370762490 : check e2393370762490 [[],[.left],[]] .three = true := by decide
def e2393370762862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393370762862 : Closed e2393370762862 ∧ code e2393370762862 = 11189463785070 := by decide
theorem cert_e2393370762862 : check e2393370762862 [[],[.left],[]] .smaller = true := by decide
def e2393370762874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393370762874 : Closed e2393370762874 ∧ code e2393370762874 = 11189463785082 := by decide
theorem cert_e2393370762874 : check e2393370762874 [[],[.left],[]] .smaller = true := by decide
def e2393370763062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393370763062 : Closed e2393370763062 ∧ code e2393370763062 = 11189463785270 := by decide
theorem cert_e2393370763062 : check e2393370763062 [[],[.left],[]] .three = true := by decide
def e2393370763066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393370763066 : Closed e2393370763066 ∧ code e2393370763066 = 11189463785274 := by decide
theorem cert_e2393370763066 : check e2393370763066 [[],[.left],[]] .three = true := by decide
def e2393370763162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393370763162 : Closed e2393370763162 ∧ code e2393370763162 = 11189463785370 := by decide
theorem cert_e2393370763162 : check e2393370763162 [[],[.left],[]] .three = true := by decide
def e2393370774366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2393370774366 : Closed e2393370774366 ∧ code e2393370774366 = 11189463796574 := by decide
theorem cert_e2393370774366 : check e2393370774366 [[],[.left],[]] .three = true := by decide
def e2393370774382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393370774382 : Closed e2393370774382 ∧ code e2393370774382 = 11189463796590 := by decide
theorem cert_e2393370774382 : check e2393370774382 [[],[.left],[]] .smaller = true := by decide
def e2393370774390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393370774390 : Closed e2393370774390 ∧ code e2393370774390 = 11189463796598 := by decide
theorem cert_e2393370774390 : check e2393370774390 [[],[.left],[]] .smaller = true := by decide
def e2393370774394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2393370774394 : Closed e2393370774394 ∧ code e2393370774394 = 11189463796602 := by decide
theorem cert_e2393370774394 : check e2393370774394 [[],[.left],[]] .three = true := by decide
def e2393370774446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393370774446 : Closed e2393370774446 ∧ code e2393370774446 = 11189463796654 := by decide
theorem cert_e2393370774446 : check e2393370774446 [[],[.left],[]] .smaller = true := by decide
def e2393370774458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393370774458 : Closed e2393370774458 ∧ code e2393370774458 = 11189463796666 := by decide
theorem cert_e2393370774458 : check e2393370774458 [[],[.left],[]] .smaller = true := by decide
def e2393370774486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393370774486 : Closed e2393370774486 ∧ code e2393370774486 = 11189463796694 := by decide
theorem cert_e2393370774486 : check e2393370774486 [[],[.left],[]] .smaller = true := by decide
def e2393370774490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393370774490 : Closed e2393370774490 ∧ code e2393370774490 = 11189463796698 := by decide
theorem cert_e2393370774490 : check e2393370774490 [[],[.left],[]] .smaller = true := by decide
def e2393370774506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2393370774506 : Closed e2393370774506 ∧ code e2393370774506 = 11189463796714 := by decide
theorem cert_e2393370774506 : check e2393370774506 [[],[.left],[]] .three = true := by decide
def e2393370774750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2393370774750 : Closed e2393370774750 ∧ code e2393370774750 = 11189463796958 := by decide
theorem cert_e2393370774750 : check e2393370774750 [[],[.left],[]] .three = true := by decide
def e2393370774766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393370774766 : Closed e2393370774766 ∧ code e2393370774766 = 11189463796974 := by decide
theorem cert_e2393370774766 : check e2393370774766 [[],[.left],[]] .smaller = true := by decide
def e2393370774774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393370774774 : Closed e2393370774774 ∧ code e2393370774774 = 11189463796982 := by decide
theorem cert_e2393370774774 : check e2393370774774 [[],[.left],[]] .smaller = true := by decide
def e2393370774778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2393370774778 : Closed e2393370774778 ∧ code e2393370774778 = 11189463796986 := by decide
theorem cert_e2393370774778 : check e2393370774778 [[],[.left],[]] .three = true := by decide
def e2393370775150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393370775150 : Closed e2393370775150 ∧ code e2393370775150 = 11189463797358 := by decide
theorem cert_e2393370775150 : check e2393370775150 [[],[.left],[]] .smaller = true := by decide
def e2393370775162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393370775162 : Closed e2393370775162 ∧ code e2393370775162 = 11189463797370 := by decide
theorem cert_e2393370775162 : check e2393370775162 [[],[.left],[]] .smaller = true := by decide
def e2393370775350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393370775350 : Closed e2393370775350 ∧ code e2393370775350 = 11189463797558 := by decide
theorem cert_e2393370775350 : check e2393370775350 [[],[.left],[]] .smaller = true := by decide
def e2393370775354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393370775354 : Closed e2393370775354 ∧ code e2393370775354 = 11189463797562 := by decide
theorem cert_e2393370775354 : check e2393370775354 [[],[.left],[]] .smaller = true := by decide
def e2393370775450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393370775450 : Closed e2393370775450 ∧ code e2393370775450 = 11189463797658 := by decide
theorem cert_e2393370775450 : check e2393370775450 [[],[.left],[]] .three = true := by decide
def e2393370781102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2393370781102 : Closed e2393370781102 ∧ code e2393370781102 = 11189463803310 := by decide
theorem cert_e2393370781102 : check e2393370781102 [[],[.left],[]] .three = true := by decide
def e2393370781110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2393370781110 : Closed e2393370781110 ∧ code e2393370781110 = 11189463803318 := by decide
theorem cert_e2393370781110 : check e2393370781110 [[],[.left],[]] .three = true := by decide
def e2393370781114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2393370781114 : Closed e2393370781114 ∧ code e2393370781114 = 11189463803322 := by decide
theorem cert_e2393370781114 : check e2393370781114 [[],[.left],[]] .three = true := by decide
def e2393370781142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2393370781142 : Closed e2393370781142 ∧ code e2393370781142 = 11189463803350 := by decide
theorem cert_e2393370781142 : check e2393370781142 [[],[.left],[]] .three = true := by decide
def e2393370781146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2393370781146 : Closed e2393370781146 ∧ code e2393370781146 = 11189463803354 := by decide
theorem cert_e2393370781146 : check e2393370781146 [[],[.left],[]] .three = true := by decide
def e2393370781162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2393370781162 : Closed e2393370781162 ∧ code e2393370781162 = 11189463803370 := by decide
theorem cert_e2393370781162 : check e2393370781162 [[],[.left],[]] .three = true := by decide
def e2393370781294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393370781294 : Closed e2393370781294 ∧ code e2393370781294 = 11189463803502 := by decide
theorem cert_e2393370781294 : check e2393370781294 [[],[.left],[]] .three = true := by decide
def e2393370781302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2393370781302 : Closed e2393370781302 ∧ code e2393370781302 = 11189463803510 := by decide
theorem cert_e2393370781302 : check e2393370781302 [[],[.left],[]] .three = true := by decide
def e2393370781306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393370781306 : Closed e2393370781306 ∧ code e2393370781306 = 11189463803514 := by decide
theorem cert_e2393370781306 : check e2393370781306 [[],[.left],[]] .three = true := by decide
def e2393370781494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393370781494 : Closed e2393370781494 ∧ code e2393370781494 = 11189463803702 := by decide
theorem cert_e2393370781494 : check e2393370781494 [[],[.left],[]] .three = true := by decide
def e2393370781498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393370781498 : Closed e2393370781498 ∧ code e2393370781498 = 11189463803706 := by decide
theorem cert_e2393370781498 : check e2393370781498 [[],[.left],[]] .three = true := by decide
def e2393370781594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393370781594 : Closed e2393370781594 ∧ code e2393370781594 = 11189463803802 := by decide
theorem cert_e2393370781594 : check e2393370781594 [[],[.left],[]] .three = true := by decide
def e2393370784470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2393370784470 : Closed e2393370784470 ∧ code e2393370784470 = 11189463806678 := by decide
theorem cert_e2393370784470 : check e2393370784470 [[],[.left],[]] .three = true := by decide
def e2393370784474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2393370784474 : Closed e2393370784474 ∧ code e2393370784474 = 11189463806682 := by decide
theorem cert_e2393370784474 : check e2393370784474 [[],[.left],[]] .three = true := by decide
def e2393370784490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2393370784490 : Closed e2393370784490 ∧ code e2393370784490 = 11189463806698 := by decide
theorem cert_e2393370784490 : check e2393370784490 [[],[.left],[]] .three = true := by decide
def e2393370784566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393370784566 : Closed e2393370784566 ∧ code e2393370784566 = 11189463806774 := by decide
theorem cert_e2393370784566 : check e2393370784566 [[],[.left],[]] .three = true := by decide
def e2393370784570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393370784570 : Closed e2393370784570 ∧ code e2393370784570 = 11189463806778 := by decide
theorem cert_e2393370784570 : check e2393370784570 [[],[.left],[]] .three = true := by decide
def e2393370784666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393370784666 : Closed e2393370784666 ∧ code e2393370784666 = 11189463806874 := by decide
theorem cert_e2393370784666 : check e2393370784666 [[],[.left],[]] .three = true := by decide
def e2393371227502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2393371227502 : Closed e2393371227502 ∧ code e2393371227502 = 11189464249710 := by decide
theorem cert_e2393371227502 : check e2393371227502 [[],[.left],[]] .chain = true := by decide
def e2393371227510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2393371227510 : Closed e2393371227510 ∧ code e2393371227510 = 11189464249718 := by decide
theorem cert_e2393371227510 : check e2393371227510 [[],[.left],[]] .chain = true := by decide
def e2393371227566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2393371227566 : Closed e2393371227566 ∧ code e2393371227566 = 11189464249774 := by decide
theorem cert_e2393371227566 : check e2393371227566 [[],[.left],[]] .chain = true := by decide
def e2393371227578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2393371227578 : Closed e2393371227578 ∧ code e2393371227578 = 11189464249786 := by decide
theorem cert_e2393371227578 : check e2393371227578 [[],[.left],[]] .chain = true := by decide
def e2393371227606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2393371227606 : Closed e2393371227606 ∧ code e2393371227606 = 11189464249814 := by decide
theorem cert_e2393371227606 : check e2393371227606 [[],[.left],[]] .chain = true := by decide
def e2393371227610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2393371227610 : Closed e2393371227610 ∧ code e2393371227610 = 11189464249818 := by decide
theorem cert_e2393371227610 : check e2393371227610 [[],[.left],[]] .chain = true := by decide
def e2393371227822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2393371227822 : Closed e2393371227822 ∧ code e2393371227822 = 11189464250030 := by decide
theorem cert_e2393371227822 : check e2393371227822 [[],[.left],[]] .chain = true := by decide
def e2393371227834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2393371227834 : Closed e2393371227834 ∧ code e2393371227834 = 11189464250042 := by decide
theorem cert_e2393371227834 : check e2393371227834 [[],[.left],[]] .chain = true := by decide
def e2393371227882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2393371227882 : Closed e2393371227882 ∧ code e2393371227882 = 11189464250090 := by decide
theorem cert_e2393371227882 : check e2393371227882 [[],[.left],[]] .chain = true := by decide
def e2393371227990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2393371227990 : Closed e2393371227990 ∧ code e2393371227990 = 11189464250198 := by decide
theorem cert_e2393371227990 : check e2393371227990 [[],[.left],[]] .chain = true := by decide
def e2393371227994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2393371227994 : Closed e2393371227994 ∧ code e2393371227994 = 11189464250202 := by decide
theorem cert_e2393371227994 : check e2393371227994 [[],[.left],[]] .chain = true := by decide
def e2393371228010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2393371228010 : Closed e2393371228010 ∧ code e2393371228010 = 11189464250218 := by decide
theorem cert_e2393371228010 : check e2393371228010 [[],[.left],[]] .chain = true := by decide
def e2393371228846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2393371228846 : Closed e2393371228846 ∧ code e2393371228846 = 11189464251054 := by decide
theorem cert_e2393371228846 : check e2393371228846 [[],[.left],[]] .chain = true := by decide
def e2393371228858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2393371228858 : Closed e2393371228858 ∧ code e2393371228858 = 11189464251066 := by decide
theorem cert_e2393371228858 : check e2393371228858 [[],[.left],[]] .chain = true := by decide
def e2393371228906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2393371228906 : Closed e2393371228906 ∧ code e2393371228906 = 11189464251114 := by decide
theorem cert_e2393371228906 : check e2393371228906 [[],[.left],[]] .chain = true := by decide
def e2393371229098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2393371229098 : Closed e2393371229098 ∧ code e2393371229098 = 11189464251306 := by decide
theorem cert_e2393371229098 : check e2393371229098 [[],[.left],[]] .chain = true := by decide
def e2393371229526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2393371229526 : Closed e2393371229526 ∧ code e2393371229526 = 11189464251734 := by decide
theorem cert_e2393371229526 : check e2393371229526 [[],[.left],[]] .chain = true := by decide
def e2393371229530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2393371229530 : Closed e2393371229530 ∧ code e2393371229530 = 11189464251738 := by decide
theorem cert_e2393371229530 : check e2393371229530 [[],[.left],[]] .chain = true := by decide
def e2393371229546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2393371229546 : Closed e2393371229546 ∧ code e2393371229546 = 11189464251754 := by decide
theorem cert_e2393371229546 : check e2393371229546 [[],[.left],[]] .chain = true := by decide
def e2393371229610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2393371229610 : Closed e2393371229610 ∧ code e2393371229610 = 11189464251818 := by decide
theorem cert_e2393371229610 : check e2393371229610 [[],[.left],[]] .chain = true := by decide
def e2393371231966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e2393371231966 : Closed e2393371231966 ∧ code e2393371231966 = 11189464254174 := by decide
theorem cert_e2393371231966 : check e2393371231966 [[],[.left],[]] .chain = true := by decide
def e2393371231990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e2393371231990 : Closed e2393371231990 ∧ code e2393371231990 = 11189464254198 := by decide
theorem cert_e2393371231990 : check e2393371231990 [[],[.left],[]] .chain = true := by decide
def e2393371232094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e2393371232094 : Closed e2393371232094 ∧ code e2393371232094 = 11189464254302 := by decide
theorem cert_e2393371232094 : check e2393371232094 [[],[.left],[]] .chain = true := by decide
def e2393371232110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e2393371232110 : Closed e2393371232110 ∧ code e2393371232110 = 11189464254318 := by decide
theorem cert_e2393371232110 : check e2393371232110 [[],[.left],[]] .chain = true := by decide
def e2393371232118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e2393371232118 : Closed e2393371232118 ∧ code e2393371232118 = 11189464254326 := by decide
theorem cert_e2393371232118 : check e2393371232118 [[],[.left],[]] .chain = true := by decide
def e2393371232122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e2393371232122 : Closed e2393371232122 ∧ code e2393371232122 = 11189464254330 := by decide
theorem cert_e2393371232122 : check e2393371232122 [[],[.left],[]] .chain = true := by decide
def e2393371232182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e2393371232182 : Closed e2393371232182 ∧ code e2393371232182 = 11189464254390 := by decide
theorem cert_e2393371232182 : check e2393371232182 [[],[.left],[]] .chain = true := by decide
def e2393371232214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 1)))))))
theorem wire_e2393371232214 : Closed e2393371232214 ∧ code e2393371232214 = 11189464254422 := by decide
theorem cert_e2393371232214 : check e2393371232214 [[],[.left],[]] .chain = true := by decide
def e2393371232218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 0)))))))
theorem wire_e2393371232218 : Closed e2393371232218 ∧ code e2393371232218 = 11189464254426 := by decide
theorem cert_e2393371232218 : check e2393371232218 [[],[.left],[]] .chain = true := by decide
def e2393371233646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2393371233646 : Closed e2393371233646 ∧ code e2393371233646 = 11189464255854 := by decide
theorem cert_e2393371233646 : check e2393371233646 [[],[.left],[]] .chain = true := by decide
def e2393371233654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2393371233654 : Closed e2393371233654 ∧ code e2393371233654 = 11189464255862 := by decide
theorem cert_e2393371233654 : check e2393371233654 [[],[.left],[]] .chain = true := by decide
def e2393371233710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2393371233710 : Closed e2393371233710 ∧ code e2393371233710 = 11189464255918 := by decide
theorem cert_e2393371233710 : check e2393371233710 [[],[.left],[]] .chain = true := by decide
def e2393371233722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2393371233722 : Closed e2393371233722 ∧ code e2393371233722 = 11189464255930 := by decide
theorem cert_e2393371233722 : check e2393371233722 [[],[.left],[]] .chain = true := by decide
def e2393371233750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2393371233750 : Closed e2393371233750 ∧ code e2393371233750 = 11189464255958 := by decide
theorem cert_e2393371233750 : check e2393371233750 [[],[.left],[]] .chain = true := by decide
def e2393371233754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2393371233754 : Closed e2393371233754 ∧ code e2393371233754 = 11189464255962 := by decide
theorem cert_e2393371233754 : check e2393371233754 [[],[.left],[]] .chain = true := by decide
def e2393371233966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2393371233966 : Closed e2393371233966 ∧ code e2393371233966 = 11189464256174 := by decide
theorem cert_e2393371233966 : check e2393371233966 [[],[.left],[]] .chain = true := by decide
def e2393371233978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2393371233978 : Closed e2393371233978 ∧ code e2393371233978 = 11189464256186 := by decide
theorem cert_e2393371233978 : check e2393371233978 [[],[.left],[]] .chain = true := by decide
def e2393371234026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2393371234026 : Closed e2393371234026 ∧ code e2393371234026 = 11189464256234 := by decide
theorem cert_e2393371234026 : check e2393371234026 [[],[.left],[]] .chain = true := by decide
def e2393371234134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2393371234134 : Closed e2393371234134 ∧ code e2393371234134 = 11189464256342 := by decide
theorem cert_e2393371234134 : check e2393371234134 [[],[.left],[]] .chain = true := by decide
def e2393371234138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2393371234138 : Closed e2393371234138 ∧ code e2393371234138 = 11189464256346 := by decide
theorem cert_e2393371234138 : check e2393371234138 [[],[.left],[]] .chain = true := by decide
def e2393371234154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2393371234154 : Closed e2393371234154 ∧ code e2393371234154 = 11189464256362 := by decide
theorem cert_e2393371234154 : check e2393371234154 [[],[.left],[]] .chain = true := by decide
def e2393371234782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2393371234782 : Closed e2393371234782 ∧ code e2393371234782 = 11189464256990 := by decide
theorem cert_e2393371234782 : check e2393371234782 [[],[.left],[]] .chain = true := by decide
def e2393371234806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2393371234806 : Closed e2393371234806 ∧ code e2393371234806 = 11189464257014 := by decide
theorem cert_e2393371234806 : check e2393371234806 [[],[.left],[]] .chain = true := by decide
def e2393371235182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2393371235182 : Closed e2393371235182 ∧ code e2393371235182 = 11189464257390 := by decide
theorem cert_e2393371235182 : check e2393371235182 [[],[.left],[]] .chain = true := by decide
def e2393371235190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2393371235190 : Closed e2393371235190 ∧ code e2393371235190 = 11189464257398 := by decide
theorem cert_e2393371235190 : check e2393371235190 [[],[.left],[]] .chain = true := by decide
def e2393371235246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2393371235246 : Closed e2393371235246 ∧ code e2393371235246 = 11189464257454 := by decide
theorem cert_e2393371235246 : check e2393371235246 [[],[.left],[]] .chain = true := by decide
def e2393371235258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2393371235258 : Closed e2393371235258 ∧ code e2393371235258 = 11189464257466 := by decide
theorem cert_e2393371235258 : check e2393371235258 [[],[.left],[]] .chain = true := by decide
def e2393371235286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2393371235286 : Closed e2393371235286 ∧ code e2393371235286 = 11189464257494 := by decide
theorem cert_e2393371235286 : check e2393371235286 [[],[.left],[]] .chain = true := by decide
def e2393371235290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2393371235290 : Closed e2393371235290 ∧ code e2393371235290 = 11189464257498 := by decide
theorem cert_e2393371235290 : check e2393371235290 [[],[.left],[]] .chain = true := by decide
def e2393371235566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393371235566 : Closed e2393371235566 ∧ code e2393371235566 = 11189464257774 := by decide
theorem cert_e2393371235566 : check e2393371235566 [[],[.left],[]] .chain = true := by decide
def e2393371235574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393371235574 : Closed e2393371235574 ∧ code e2393371235574 = 11189464257782 := by decide
theorem cert_e2393371235574 : check e2393371235574 [[],[.left],[]] .chain = true := by decide
def e2393371235902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2393371235902 : Closed e2393371235902 ∧ code e2393371235902 = 11189464258110 := by decide
theorem cert_e2393371235902 : check e2393371235902 [[],[.left],[]] .chain = true := by decide
def e2393371235950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393371235950 : Closed e2393371235950 ∧ code e2393371235950 = 11189464258158 := by decide
theorem cert_e2393371235950 : check e2393371235950 [[],[.left],[]] .chain = true := by decide
def e2393371235962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393371235962 : Closed e2393371235962 ∧ code e2393371235962 = 11189464258170 := by decide
theorem cert_e2393371235962 : check e2393371235962 [[],[.left],[]] .chain = true := by decide
def e2393371236150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371236150 : Closed e2393371236150 ∧ code e2393371236150 = 11189464258358 := by decide
theorem cert_e2393371236150 : check e2393371236150 [[],[.left],[]] .chain = true := by decide
def e2393371236154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371236154 : Closed e2393371236154 ∧ code e2393371236154 = 11189464258362 := by decide
theorem cert_e2393371236154 : check e2393371236154 [[],[.left],[]] .chain = true := by decide
def e2393371236238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2393371236238 : Closed e2393371236238 ∧ code e2393371236238 = 11189464258446 := by decide
theorem cert_e2393371236238 : check e2393371236238 [[],[.left],[]] .chain = true := by decide
def e2393371236574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2393371236574 : Closed e2393371236574 ∧ code e2393371236574 = 11189464258782 := by decide
theorem cert_e2393371236574 : check e2393371236574 [[],[.left],[]] .chain = true := by decide
def e2393371236590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2393371236590 : Closed e2393371236590 ∧ code e2393371236590 = 11189464258798 := by decide
theorem cert_e2393371236590 : check e2393371236590 [[],[.left],[]] .chain = true := by decide
def e2393371236598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2393371236598 : Closed e2393371236598 ∧ code e2393371236598 = 11189464258806 := by decide
theorem cert_e2393371236598 : check e2393371236598 [[],[.left],[]] .chain = true := by decide
end Blc.Floor43
