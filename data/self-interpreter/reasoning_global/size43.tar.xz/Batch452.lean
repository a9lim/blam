import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422398077910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422398077910 : Closed e2422398077910 ∧ code e2422398077910 = 11218491100118 := by decide
def e2422398077914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422398077914 : Closed e2422398077914 ∧ code e2422398077914 = 11218491100122 := by decide
theorem cert_e2422398077914 : check e2422398077914 [[],[],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422398078190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422398078190 : Closed e2422398078190 ∧ code e2422398078190 = 11218491100398 := by decide
theorem cert_e2422398078190 : check e2422398078190 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2422398078198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422398078198 : Closed e2422398078198 ∧ code e2422398078198 = 11218491100406 := by decide
theorem cert_e2422398078198 : check e2422398078198 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422398078574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422398078574 : Closed e2422398078574 ∧ code e2422398078574 = 11218491100782 := by decide
theorem cert_e2422398078574 : check e2422398078574 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398078586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422398078586 : Closed e2422398078586 ∧ code e2422398078586 = 11218491100794 := by decide
theorem cert_e2422398078586 : check e2422398078586 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398078774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422398078774 : Closed e2422398078774 ∧ code e2422398078774 = 11218491100982 := by decide
def e2422398078778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422398078778 : Closed e2422398078778 ∧ code e2422398078778 = 11218491100986 := by decide
theorem cert_e2422398078778 : check e2422398078778 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2422398084894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422398084894 : Closed e2422398084894 ∧ code e2422398084894 = 11218491107102 := by decide
theorem cert_e2422398084894 : check e2422398084894 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398085006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422398085006 : Closed e2422398085006 ∧ code e2422398085006 = 11218491107214 := by decide
theorem cert_e2422398085006 : check e2422398085006 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422398087966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422398087966 : Closed e2422398087966 ∧ code e2422398087966 = 11218491110174 := by decide
theorem cert_e2422398087966 : check e2422398087966 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422398088134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422398088134 : Closed e2422398088134 ∧ code e2422398088134 = 11218491110342 := by decide
theorem cert_e2422398088134 : check e2422398088134 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422398089614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422398089614 : Closed e2422398089614 ∧ code e2422398089614 = 11218491111822 := by decide
theorem cert_e2422398089614 : check e2422398089614 [[],[]] .chain = true := by decide
def e2422398089670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422398089670 : Closed e2422398089670 ∧ code e2422398089670 = 11218491111878 := by decide
theorem cert_e2422398089670 : check e2422398089670 [[],[]] .chain = true := by decide
def e2422398094574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422398094574 : Closed e2422398094574 ∧ code e2422398094574 = 11218491116782 := by decide
theorem cert_e2422398094574 : check e2422398094574 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398094582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422398094582 : Closed e2422398094582 ∧ code e2422398094582 = 11218491116790 := by decide
theorem cert_e2422398094582 : check e2422398094582 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .chain = true := by decide
def e2422398101278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422398101278 : Closed e2422398101278 ∧ code e2422398101278 = 11218491123486 := by decide
theorem cert_e2422398101278 : check e2422398101278 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398101390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422398101390 : Closed e2422398101390 ∧ code e2422398101390 = 11218491123598 := by decide
theorem cert_e2422398101390 : check e2422398101390 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .chain = true := by decide
def e2422398109294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422398109294 : Closed e2422398109294 ∧ code e2422398109294 = 11218491131502 := by decide
theorem cert_e2422398109294 : check e2422398109294 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e2422398109306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422398109306 : Closed e2422398109306 ∧ code e2422398109306 = 11218491131514 := by decide
theorem cert_e2422398109306 : check e2422398109306 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422398112542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422398112542 : Closed e2422398112542 ∧ code e2422398112542 = 11218491134750 := by decide
theorem cert_e2422398112542 : check e2422398112542 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e2422398112710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422398112710 : Closed e2422398112710 ∧ code e2422398112710 = 11218491134918 := by decide
theorem cert_e2422398112710 : check e2422398112710 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422398118286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 3)) (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422398118286 : Closed e2422398118286 ∧ code e2422398118286 = 11218491140494 := by decide
theorem cert_e2422398118286 : check e2422398118286 [[],[]] .chain = true := by decide
def e2422398118342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 3)) (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422398118342 : Closed e2422398118342 ∧ code e2422398118342 = 11218491140550 := by decide
theorem cert_e2422398118342 : check e2422398118342 [[],[]] .chain = true := by decide
def e2422398137582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422398137582 : Closed e2422398137582 ∧ code e2422398137582 = 11218491159790 := by decide
theorem cert_e2422398137582 : check e2422398137582 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422398137590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422398137590 : Closed e2422398137590 ∧ code e2422398137590 = 11218491159798 := by decide
theorem cert_e2422398137590 : check e2422398137590 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422398160110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422398160110 : Closed e2422398160110 ∧ code e2422398160110 = 11218491182318 := by decide
theorem cert_e2422398160110 : check e2422398160110 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2422398160118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422398160118 : Closed e2422398160118 ∧ code e2422398160118 = 11218491182326 := by decide
theorem cert_e2422398160118 : check e2422398160118 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422398166814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422398166814 : Closed e2422398166814 ∧ code e2422398166814 = 11218491189022 := by decide
theorem cert_e2422398166814 : check e2422398166814 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2422398166926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422398166926 : Closed e2422398166926 ∧ code e2422398166926 = 11218491189134 := by decide
theorem cert_e2422398166926 : check e2422398166926 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422398196334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422398196334 : Closed e2422398196334 ∧ code e2422398196334 = 11218491218542 := by decide
theorem cert_e2422398196334 : checkPay e2422398196334 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under],[.under,.left],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] = true := by decide
def e2422398196346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422398196346 : Closed e2422398196346 ∧ code e2422398196346 = 11218491218554 := by decide
theorem cert_e2422398196346 : checkPay e2422398196346 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under],[.under,.under,.under],[.under,.under,.under,.left,.right,.under],[.under,.under,.under,.right]] = true := by decide
def e2422398207598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422398207598 : Closed e2422398207598 ∧ code e2422398207598 = 11218491229806 := by decide
theorem cert_e2422398207598 : checkPay e2422398207598 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left],[],[.under],[.under,.left]] = true := by decide
def e2422398207610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422398207610 : Closed e2422398207610 ∧ code e2422398207610 = 11218491229818 := by decide
theorem cert_e2422398207610 : checkPay e2422398207610 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.under,.under],[.under,.under,.left,.right],[.under,.under,.right,.under]] = true := by decide
def e2422398210846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422398210846 : Closed e2422398210846 ∧ code e2422398210846 = 11218491233054 := by decide
theorem cert_e2422398210846 : checkPay e2422398210846 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left],[],[.under,.under]] = true := by decide
def e2422398211014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422398211014 : Closed e2422398211014 ∧ code e2422398211014 = 11218491233222 := by decide
theorem cert_e2422398211014 : checkPay e2422398211014 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.under,.under],[.under,.under,.left,.right],[.under,.under,.right]] = true := by decide
def e2422398232974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 3) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422398232974 : Closed e2422398232974 ∧ code e2422398232974 = 11218491255182 := by decide
theorem cert_e2422398232974 : check e2422398232974 [[],[]] .chain = true := by decide
def e2422398233030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 3) (.var 0)) (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422398233030 : Closed e2422398233030 ∧ code e2422398233030 = 11218491255238 := by decide
theorem cert_e2422398233030 : check e2422398233030 [[],[]] .chain = true := by decide
def e2422398459118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422398459118 : Closed e2422398459118 ∧ code e2422398459118 = 11218491481326 := by decide
theorem cert_e2422398459118 : checkPay e2422398459118 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under,.under,.under]] = true := by decide
def e2422398459126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422398459126 : Closed e2422398459126 ∧ code e2422398459126 = 11218491481334 := by decide
theorem cert_e2422398459126 : check e2422398459126 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398471022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422398471022 : Closed e2422398471022 ∧ code e2422398471022 = 11218491493230 := by decide
theorem cert_e2422398471022 : check e2422398471022 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2422398471030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422398471030 : Closed e2422398471030 ∧ code e2422398471030 = 11218491493238 := by decide
theorem cert_e2422398471030 : check e2422398471030 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e2422398471086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422398471086 : Closed e2422398471086 ∧ code e2422398471086 = 11218491493294 := by decide
theorem cert_e2422398471086 : check e2422398471086 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398471098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422398471098 : Closed e2422398471098 ∧ code e2422398471098 = 11218491493306 := by decide
theorem cert_e2422398471098 : check e2422398471098 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398471126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422398471126 : Closed e2422398471126 ∧ code e2422398471126 = 11218491493334 := by decide
def e2422398471130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422398471130 : Closed e2422398471130 ∧ code e2422398471130 = 11218491493338 := by decide
theorem cert_e2422398471130 : check e2422398471130 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2422398471406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422398471406 : Closed e2422398471406 ∧ code e2422398471406 = 11218491493614 := by decide
theorem cert_e2422398471406 : check e2422398471406 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2422398471414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422398471414 : Closed e2422398471414 ∧ code e2422398471414 = 11218491493622 := by decide
theorem cert_e2422398471414 : check e2422398471414 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422398471790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422398471790 : Closed e2422398471790 ∧ code e2422398471790 = 11218491493998 := by decide
theorem cert_e2422398471790 : checkPay e2422398471790 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left],[],[.under],[.under,.left],[.under,.right,.left],[.under,.right,.right]] = true := by decide
def e2422398471802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422398471802 : Closed e2422398471802 ∧ code e2422398471802 = 11218491494010 := by decide
theorem cert_e2422398471802 : checkPay e2422398471802 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.under,.under],[.under,.under,.left,.right],[.under,.under,.right,.left,.right],[.under,.under,.right,.right,.right]] = true := by decide
def e2422398471990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422398471990 : Closed e2422398471990 ∧ code e2422398471990 = 11218491494198 := by decide
theorem cert_e2422398471990 : check e2422398471990 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398471994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422398471994 : Closed e2422398471994 ∧ code e2422398471994 = 11218491494202 := by decide
theorem cert_e2422398471994 : check e2422398471994 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398478110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422398478110 : Closed e2422398478110 ∧ code e2422398478110 = 11218491500318 := by decide
theorem cert_e2422398478110 : checkPay e2422398478110 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under,.under,.under,.under]] = true := by decide
def e2422398478222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422398478222 : Closed e2422398478222 ∧ code e2422398478222 = 11218491500430 := by decide
theorem cert_e2422398478222 : check e2422398478222 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398481182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422398481182 : Closed e2422398481182 ∧ code e2422398481182 = 11218491503390 := by decide
theorem cert_e2422398481182 : check e2422398481182 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422398481350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422398481350 : Closed e2422398481350 ∧ code e2422398481350 = 11218491503558 := by decide
theorem cert_e2422398481350 : check e2422398481350 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398482830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 3)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422398482830 : Closed e2422398482830 ∧ code e2422398482830 = 11218491505038 := by decide
theorem cert_e2422398482830 : check e2422398482830 [[],[]] .chain = true := by decide
def e2422398482886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 3)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422398482886 : Closed e2422398482886 ∧ code e2422398482886 = 11218491505094 := by decide
theorem cert_e2422398482886 : check e2422398482886 [[],[]] .chain = true := by decide
def e2422398487790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422398487790 : Closed e2422398487790 ∧ code e2422398487790 = 11218491509998 := by decide
theorem cert_e2422398487790 : checkPay e2422398487790 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under,.under,.under]] = true := by decide
def e2422398487798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422398487798 : Closed e2422398487798 ∧ code e2422398487798 = 11218491510006 := by decide
theorem cert_e2422398487798 : check e2422398487798 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398494494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422398494494 : Closed e2422398494494 ∧ code e2422398494494 = 11218491516702 := by decide
theorem cert_e2422398494494 : checkPay e2422398494494 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under,.under,.under,.under]] = true := by decide
def e2422398494606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422398494606 : Closed e2422398494606 ∧ code e2422398494606 = 11218491516814 := by decide
theorem cert_e2422398494606 : check e2422398494606 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398502510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422398502510 : Closed e2422398502510 ∧ code e2422398502510 = 11218491524718 := by decide
theorem cert_e2422398502510 : check e2422398502510 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422398502522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422398502522 : Closed e2422398502522 ∧ code e2422398502522 = 11218491524730 := by decide
theorem cert_e2422398502522 : check e2422398502522 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398505758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422398505758 : Closed e2422398505758 ∧ code e2422398505758 = 11218491527966 := by decide
theorem cert_e2422398505758 : check e2422398505758 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422398505926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422398505926 : Closed e2422398505926 ∧ code e2422398505926 = 11218491528134 := by decide
theorem cert_e2422398505926 : check e2422398505926 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398511502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 3) (.var 0)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422398511502 : Closed e2422398511502 ∧ code e2422398511502 = 11218491533710 := by decide
theorem cert_e2422398511502 : check e2422398511502 [[],[]] .chain = true := by decide
def e2422398511558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 3) (.var 0)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422398511558 : Closed e2422398511558 ∧ code e2422398511558 = 11218491533766 := by decide
theorem cert_e2422398511558 : check e2422398511558 [[],[]] .chain = true := by decide
def e2422398520174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422398520174 : Closed e2422398520174 ∧ code e2422398520174 = 11218491542382 := by decide
theorem cert_e2422398520174 : check e2422398520174 [[],[]] .smaller = true := by decide
def e2422398520182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422398520182 : Closed e2422398520182 ∧ code e2422398520182 = 11218491542390 := by decide
theorem cert_e2422398520182 : check e2422398520182 [[],[]] .smaller = true := by decide
def e2422398520238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422398520238 : Closed e2422398520238 ∧ code e2422398520238 = 11218491542446 := by decide
theorem cert_e2422398520238 : check e2422398520238 [[],[]] .smaller = true := by decide
def e2422398520250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422398520250 : Closed e2422398520250 ∧ code e2422398520250 = 11218491542458 := by decide
theorem cert_e2422398520250 : check e2422398520250 [[],[]] .smaller = true := by decide
def e2422398520278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422398520278 : Closed e2422398520278 ∧ code e2422398520278 = 11218491542486 := by decide
theorem cert_e2422398520278 : check e2422398520278 [[],[]] .smaller = true := by decide
def e2422398520282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422398520282 : Closed e2422398520282 ∧ code e2422398520282 = 11218491542490 := by decide
theorem cert_e2422398520282 : check e2422398520282 [[],[]] .smaller = true := by decide
def e2422398520558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422398520558 : Closed e2422398520558 ∧ code e2422398520558 = 11218491542766 := by decide
theorem cert_e2422398520558 : check e2422398520558 [[],[]] .smaller = true := by decide
def e2422398520566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422398520566 : Closed e2422398520566 ∧ code e2422398520566 = 11218491542774 := by decide
theorem cert_e2422398520566 : check e2422398520566 [[],[]] .smaller = true := by decide
def e2422398520942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422398520942 : Closed e2422398520942 ∧ code e2422398520942 = 11218491543150 := by decide
theorem cert_e2422398520942 : check e2422398520942 [[],[]] .smaller = true := by decide
def e2422398520954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422398520954 : Closed e2422398520954 ∧ code e2422398520954 = 11218491543162 := by decide
theorem cert_e2422398520954 : check e2422398520954 [[],[]] .smaller = true := by decide
def e2422398521142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422398521142 : Closed e2422398521142 ∧ code e2422398521142 = 11218491543350 := by decide
theorem cert_e2422398521142 : check e2422398521142 [[],[]] .smaller = true := by decide
def e2422398521146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422398521146 : Closed e2422398521146 ∧ code e2422398521146 = 11218491543354 := by decide
theorem cert_e2422398521146 : check e2422398521146 [[],[]] .smaller = true := by decide
def e2422398528990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2422398528990 : Closed e2422398528990 ∧ code e2422398528990 = 11218491551198 := by decide
theorem cert_e2422398528990 : check e2422398528990 [[],[],[.under,.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e2422398529006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2422398529006 : Closed e2422398529006 ∧ code e2422398529006 = 11218491551214 := by decide
private def t_e2422398529006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem cert_e2422398529006 : ¬ IsSelfInterpreter e2422398529006 :=
  wSource (t := t_e2422398529006) (replay_sound (ps := []) (t := e2422398529006) (by decide)) (by decide)
def e2422398529374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2422398529374 : Closed e2422398529374 ∧ code e2422398529374 = 11218491551582 := by decide
theorem cert_e2422398529374 : checkPay e2422398529374 [[.left,.left],[.left,.left],[.left],[],[],[]] 0 [[.under,.right,.under,.under,.under],[.under,.right,.under,.under,.under]] = true := by decide
def e2422398529402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2422398529402 : Closed e2422398529402 ∧ code e2422398529402 = 11218491551610 := by decide
theorem cert_e2422398529402 : checkPay e2422398529402 [[.left,.left],[.left,.left],[.left],[],[],[]] 0 [[.under,.under,.under],[.under,.under,.under]] = true := by decide
def e2422398529454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2422398529454 : Closed e2422398529454 ∧ code e2422398529454 = 11218491551662 := by decide
private def t_e2422398529454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem cert_e2422398529454 : ¬ IsSelfInterpreter e2422398529454 :=
  wSource (t := t_e2422398529454) (replay_sound (ps := []) (t := e2422398529454) (by decide)) (by decide)
def e2422398529466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2422398529466 : Closed e2422398529466 ∧ code e2422398529466 = 11218491551674 := by decide
theorem cert_e2422398529466 : check e2422398529466 [[],[],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398530526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422398530526 : Closed e2422398530526 ∧ code e2422398530526 = 11218491552734 := by decide
theorem cert_e2422398530526 : checkPay e2422398530526 [[.left,.left],[.left,.left],[.left],[],[],[],[]] 0 [[.under,.under,.under],[.under,.under,.under],[.under,.under,.under]] = true := by decide
def e2422398530542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422398530542 : Closed e2422398530542 ∧ code e2422398530542 = 11218491552750 := by decide
theorem cert_e2422398530542 : check e2422398530542 [[],[],[.under,.under],[.under,.under],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398532830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422398532830 : Closed e2422398532830 ∧ code e2422398532830 = 11218491555038 := by decide
theorem cert_e2422398532830 : check e2422398532830 [[],[],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2422398532858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422398532858 : Closed e2422398532858 ∧ code e2422398532858 = 11218491555066 := by decide
theorem cert_e2422398532858 : check e2422398532858 [[],[],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2422398533230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422398533230 : Closed e2422398533230 ∧ code e2422398533230 = 11218491555438 := by decide
theorem cert_e2422398533230 : check e2422398533230 [[],[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2422398533242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422398533242 : Closed e2422398533242 ∧ code e2422398533242 = 11218491555450 := by decide
theorem cert_e2422398533242 : check e2422398533242 [[],[],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2422398561646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422398561646 : Closed e2422398561646 ∧ code e2422398561646 = 11218491583854 := by decide
def e2422398561654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422398561654 : Closed e2422398561654 ∧ code e2422398561654 = 11218491583862 := by decide
theorem cert_e2422398561654 : check e2422398561654 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422398561710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422398561710 : Closed e2422398561710 ∧ code e2422398561710 = 11218491583918 := by decide
theorem cert_e2422398561710 : check e2422398561710 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422398561722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422398561722 : Closed e2422398561722 ∧ code e2422398561722 = 11218491583930 := by decide
theorem cert_e2422398561722 : check e2422398561722 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422398561750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422398561750 : Closed e2422398561750 ∧ code e2422398561750 = 11218491583958 := by decide
theorem cert_e2422398561750 : check e2422398561750 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422398561754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422398561754 : Closed e2422398561754 ∧ code e2422398561754 = 11218491583962 := by decide
theorem cert_e2422398561754 : check e2422398561754 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422398561966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422398561966 : Closed e2422398561966 ∧ code e2422398561966 = 11218491584174 := by decide
theorem cert_e2422398561966 : check e2422398561966 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398561978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422398561978 : Closed e2422398561978 ∧ code e2422398561978 = 11218491584186 := by decide
theorem cert_e2422398561978 : check e2422398561978 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398562026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422398562026 : Closed e2422398562026 ∧ code e2422398562026 = 11218491584234 := by decide
theorem cert_e2422398562026 : check e2422398562026 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398562134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422398562134 : Closed e2422398562134 ∧ code e2422398562134 = 11218491584342 := by decide
theorem cert_e2422398562134 : check e2422398562134 [[],[],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2422398562138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422398562138 : Closed e2422398562138 ∧ code e2422398562138 = 11218491584346 := by decide
theorem cert_e2422398562138 : check e2422398562138 [[],[],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2422398562154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422398562154 : Closed e2422398562154 ∧ code e2422398562154 = 11218491584362 := by decide
theorem cert_e2422398562154 : check e2422398562154 [[],[],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2422398563182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422398563182 : Closed e2422398563182 ∧ code e2422398563182 = 11218491585390 := by decide
theorem cert_e2422398563182 : check e2422398563182 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422398563190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422398563190 : Closed e2422398563190 ∧ code e2422398563190 = 11218491585398 := by decide
theorem cert_e2422398563190 : check e2422398563190 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422398563246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422398563246 : Closed e2422398563246 ∧ code e2422398563246 = 11218491585454 := by decide
theorem cert_e2422398563246 : check e2422398563246 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2422398563258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422398563258 : Closed e2422398563258 ∧ code e2422398563258 = 11218491585466 := by decide
theorem cert_e2422398563258 : check e2422398563258 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2422398563286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422398563286 : Closed e2422398563286 ∧ code e2422398563286 = 11218491585494 := by decide
def e2422398563290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422398563290 : Closed e2422398563290 ∧ code e2422398563290 = 11218491585498 := by decide
theorem cert_e2422398563290 : check e2422398563290 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422398563566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422398563566 : Closed e2422398563566 ∧ code e2422398563566 = 11218491585774 := by decide
theorem cert_e2422398563566 : check e2422398563566 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422398563574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422398563574 : Closed e2422398563574 ∧ code e2422398563574 = 11218491585782 := by decide
theorem cert_e2422398563574 : check e2422398563574 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422398563950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422398563950 : Closed e2422398563950 ∧ code e2422398563950 = 11218491586158 := by decide
theorem cert_e2422398563950 : check e2422398563950 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2422398563962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422398563962 : Closed e2422398563962 ∧ code e2422398563962 = 11218491586170 := by decide
theorem cert_e2422398563962 : check e2422398563962 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2422398564150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422398564150 : Closed e2422398564150 ∧ code e2422398564150 = 11218491586358 := by decide
theorem cert_e2422398564150 : check e2422398564150 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422398564154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422398564154 : Closed e2422398564154 ∧ code e2422398564154 = 11218491586362 := by decide
theorem cert_e2422398564154 : check e2422398564154 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left]] .identityHead = true := by decide
def e2422398564782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422398564782 : Closed e2422398564782 ∧ code e2422398564782 = 11218491586990 := by decide
theorem cert_e2422398564782 : check e2422398564782 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398564794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422398564794 : Closed e2422398564794 ∧ code e2422398564794 = 11218491587002 := by decide
theorem cert_e2422398564794 : check e2422398564794 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398564842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422398564842 : Closed e2422398564842 ∧ code e2422398564842 = 11218491587050 := by decide
theorem cert_e2422398564842 : check e2422398564842 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398564974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422398564974 : Closed e2422398564974 ∧ code e2422398564974 = 11218491587182 := by decide
theorem cert_e2422398564974 : check e2422398564974 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398564986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422398564986 : Closed e2422398564986 ∧ code e2422398564986 = 11218491587194 := by decide
theorem cert_e2422398564986 : check e2422398564986 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398565274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422398565274 : Closed e2422398565274 ∧ code e2422398565274 = 11218491587482 := by decide
theorem cert_e2422398565274 : check e2422398565274 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398565590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422398565590 : Closed e2422398565590 ∧ code e2422398565590 = 11218491587798 := by decide
def e2422398565594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422398565594 : Closed e2422398565594 ∧ code e2422398565594 = 11218491587802 := by decide
def e2422398565610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422398565610 : Closed e2422398565610 ∧ code e2422398565610 = 11218491587818 := by decide
theorem cert_e2422398565610 : check e2422398565610 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2422398565686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422398565686 : Closed e2422398565686 ∧ code e2422398565686 = 11218491587894 := by decide
def e2422398565690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422398565690 : Closed e2422398565690 ∧ code e2422398565690 = 11218491587898 := by decide
def e2422398565786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422398565786 : Closed e2422398565786 ∧ code e2422398565786 = 11218491587994 := by decide
theorem cert_e2422398565786 : check e2422398565786 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2422398567390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2422398567390 : Closed e2422398567390 ∧ code e2422398567390 = 11218491589598 := by decide
theorem cert_e2422398567390 : check e2422398567390 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2422398567406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2422398567406 : Closed e2422398567406 ∧ code e2422398567406 = 11218491589614 := by decide
theorem cert_e2422398567406 : check e2422398567406 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422398569326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422398569326 : Closed e2422398569326 ∧ code e2422398569326 = 11218491591534 := by decide
theorem cert_e2422398569326 : check e2422398569326 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422398569334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422398569334 : Closed e2422398569334 ∧ code e2422398569334 = 11218491591542 := by decide
theorem cert_e2422398569334 : check e2422398569334 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422398569390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422398569390 : Closed e2422398569390 ∧ code e2422398569390 = 11218491591598 := by decide
theorem cert_e2422398569390 : check e2422398569390 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2422398569402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422398569402 : Closed e2422398569402 ∧ code e2422398569402 = 11218491591610 := by decide
theorem cert_e2422398569402 : check e2422398569402 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2422398569430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422398569430 : Closed e2422398569430 ∧ code e2422398569430 = 11218491591638 := by decide
theorem cert_e2422398569430 : check e2422398569430 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422398569434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422398569434 : Closed e2422398569434 ∧ code e2422398569434 = 11218491591642 := by decide
theorem cert_e2422398569434 : check e2422398569434 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422398569710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422398569710 : Closed e2422398569710 ∧ code e2422398569710 = 11218491591918 := by decide
theorem cert_e2422398569710 : check e2422398569710 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422398569718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422398569718 : Closed e2422398569718 ∧ code e2422398569718 = 11218491591926 := by decide
theorem cert_e2422398569718 : check e2422398569718 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422398570094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422398570094 : Closed e2422398570094 ∧ code e2422398570094 = 11218491592302 := by decide
theorem cert_e2422398570094 : check e2422398570094 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2422398570106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422398570106 : Closed e2422398570106 ∧ code e2422398570106 = 11218491592314 := by decide
theorem cert_e2422398570106 : check e2422398570106 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2422398570294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422398570294 : Closed e2422398570294 ∧ code e2422398570294 = 11218491592502 := by decide
theorem cert_e2422398570294 : check e2422398570294 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422398570298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422398570298 : Closed e2422398570298 ∧ code e2422398570298 = 11218491592506 := by decide
theorem cert_e2422398570298 : check e2422398570298 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422398575070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422398575070 : Closed e2422398575070 ∧ code e2422398575070 = 11218491597278 := by decide
theorem cert_e2422398575070 : checkPay e2422398575070 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under],[.under,.left],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.right],[.under,.under,.right,.left]] = true := by decide
def e2422398575094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422398575094 : Closed e2422398575094 ∧ code e2422398575094 = 11218491597302 := by decide
theorem cert_e2422398575094 : checkPay e2422398575094 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under],[.under,.under,.under],[.under,.under,.under,.left,.right,.under],[.under,.under,.under,.right,.right,.under]] = true := by decide
def e2422398576046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422398576046 : Closed e2422398576046 ∧ code e2422398576046 = 11218491598254 := by decide
theorem cert_e2422398576046 : checkPay e2422398576046 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2422398576058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422398576058 : Closed e2422398576058 ∧ code e2422398576058 = 11218491598266 := by decide
theorem cert_e2422398576058 : checkPay e2422398576058 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2422398576106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422398576106 : Closed e2422398576106 ∧ code e2422398576106 = 11218491598314 := by decide
theorem cert_e2422398576106 : checkPay e2422398576106 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.left],[],[.under],[.under,.left],[.under,.left,.left,.left,.left],[.under,.right],[.under,.right,.left,.left,.left]] = true := by decide
def e2422398576238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422398576238 : Closed e2422398576238 ∧ code e2422398576238 = 11218491598446 := by decide
theorem cert_e2422398576238 : checkPay e2422398576238 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[.left],[]] = true := by decide
def e2422398576250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422398576250 : Closed e2422398576250 ∧ code e2422398576250 = 11218491598458 := by decide
theorem cert_e2422398576250 : checkPay e2422398576250 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.left,.left],[.left],[],[],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2422398576538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422398576538 : Closed e2422398576538 ∧ code e2422398576538 = 11218491598746 := by decide
theorem cert_e2422398576538 : checkPay e2422398576538 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[],[.under,.under],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right],[.under,.under,.right,.right,.left],[.under,.under,.right,.right,.left,.left],[.under,.under,.right,.right,.left,.left,.left],[.under,.under,.right,.right,.left,.left],[.under,.under,.right,.right,.left],[.under,.under,.right,.right]] = true := by decide
def e2422398578926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422398578926 : Closed e2422398578926 ∧ code e2422398578926 = 11218491601134 := by decide
theorem cert_e2422398578926 : check e2422398578926 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398578934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422398578934 : Closed e2422398578934 ∧ code e2422398578934 = 11218491601142 := by decide
theorem cert_e2422398578934 : check e2422398578934 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398579414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422398579414 : Closed e2422398579414 ∧ code e2422398579414 = 11218491601622 := by decide
theorem cert_e2422398579414 : check e2422398579414 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398579418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422398579418 : Closed e2422398579418 ∧ code e2422398579418 = 11218491601626 := by decide
theorem cert_e2422398579418 : check e2422398579418 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398579434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422398579434 : Closed e2422398579434 ∧ code e2422398579434 = 11218491601642 := by decide
theorem cert_e2422398579434 : check e2422398579434 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398579510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422398579510 : Closed e2422398579510 ∧ code e2422398579510 = 11218491601718 := by decide
theorem cert_e2422398579510 : check e2422398579510 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398579514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422398579514 : Closed e2422398579514 ∧ code e2422398579514 = 11218491601722 := by decide
theorem cert_e2422398579514 : check e2422398579514 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398579610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422398579610 : Closed e2422398579610 ∧ code e2422398579610 = 11218491601818 := by decide
theorem cert_e2422398579610 : check e2422398579610 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2422398881006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422398881006 : Closed e2422398881006 ∧ code e2422398881006 = 11218491903214 := by decide
theorem cert_e2422398881006 : check e2422398881006 [[.left,.left],[.left,.left],[.left],[],[],[]] .identityHead = true := by decide
def e2422398881014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422398881014 : Closed e2422398881014 ∧ code e2422398881014 = 11218491903222 := by decide
theorem cert_e2422398881014 : checkPay e2422398881014 [[.left,.left],[.left,.left],[.left],[],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[]] 0 [[.under],[.under,.under,.under]] = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422398529006
#print axioms Blc.Floor43.cert_e2422398529454
