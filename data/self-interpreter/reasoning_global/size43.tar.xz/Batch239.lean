import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393373871062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393373871062 : Closed e2393373871062 ∧ code e2393373871062 = 11189466893270 := by decide
theorem cert_e2393373871062 : check e2393373871062 [[],[.left],[]] .chain = true := by decide
def e2393373871066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393373871066 : Closed e2393373871066 ∧ code e2393373871066 = 11189466893274 := by decide
theorem cert_e2393373871066 : check e2393373871066 [[],[.left],[]] .chain = true := by decide
def e2393373871342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393373871342 : Closed e2393373871342 ∧ code e2393373871342 = 11189466893550 := by decide
theorem cert_e2393373871342 : check e2393373871342 [[],[.left],[]] .chain = true := by decide
def e2393373871350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393373871350 : Closed e2393373871350 ∧ code e2393373871350 = 11189466893558 := by decide
theorem cert_e2393373871350 : check e2393373871350 [[],[.left],[]] .chain = true := by decide
def e2393373871726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393373871726 : Closed e2393373871726 ∧ code e2393373871726 = 11189466893934 := by decide
theorem cert_e2393373871726 : check e2393373871726 [[],[.left],[]] .chain = true := by decide
def e2393373871738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393373871738 : Closed e2393373871738 ∧ code e2393373871738 = 11189466893946 := by decide
theorem cert_e2393373871738 : check e2393373871738 [[],[.left],[]] .chain = true := by decide
def e2393373871926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393373871926 : Closed e2393373871926 ∧ code e2393373871926 = 11189466894134 := by decide
theorem cert_e2393373871926 : check e2393373871926 [[],[.left],[]] .chain = true := by decide
def e2393373871930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393373871930 : Closed e2393373871930 ∧ code e2393373871930 = 11189466894138 := by decide
theorem cert_e2393373871930 : check e2393373871930 [[],[.left],[]] .chain = true := by decide
def e2393373879854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2393373879854 : Closed e2393373879854 ∧ code e2393373879854 = 11189466902062 := by decide
theorem cert_e2393373879854 : check e2393373879854 [[],[.left],[]] .sourceHead = true := by decide
def e2393373880034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2393373880034 : Closed e2393373880034 ∧ code e2393373880034 = 11189466902242 := by decide
theorem cert_e2393373880034 : check e2393373880034 [[],[.left],[]] .sourceHead = true := by decide
def e2393373880046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2393373880046 : Closed e2393373880046 ∧ code e2393373880046 = 11189466902254 := by decide
theorem cert_e2393373880046 : check e2393373880046 [[],[.left],[]] .sourceHead = true := by decide
def e2393373880086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2393373880086 : Closed e2393373880086 ∧ code e2393373880086 = 11189466902294 := by decide
theorem cert_e2393373880086 : check e2393373880086 [[],[.left],[]] .sourceHead = true := by decide
def e2393373880162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2393373880162 : Closed e2393373880162 ∧ code e2393373880162 = 11189466902370 := by decide
theorem cert_e2393373880162 : check e2393373880162 [[],[.left],[]] .sourceHead = true := by decide
def e2393373880174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2393373880174 : Closed e2393373880174 ∧ code e2393373880174 = 11189466902382 := by decide
theorem cert_e2393373880174 : check e2393373880174 [[],[.left],[]] .sourceHead = true := by decide
def e2393373880182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2393373880182 : Closed e2393373880182 ∧ code e2393373880182 = 11189466902390 := by decide
theorem cert_e2393373880182 : check e2393373880182 [[],[.left],[]] .sourceHead = true := by decide
def e2393373882430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2393373882430 : Closed e2393373882430 ∧ code e2393373882430 = 11189466904638 := by decide
theorem cert_e2393373882430 : check e2393373882430 [[],[.left],[]] .sourceHead = true := by decide
def e2393373882850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2393373882850 : Closed e2393373882850 ∧ code e2393373882850 = 11189466905058 := by decide
theorem cert_e2393373882850 : check e2393373882850 [[],[.left],[]] .sourceHead = true := by decide
def e2393373882862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393373882862 : Closed e2393373882862 ∧ code e2393373882862 = 11189466905070 := by decide
theorem cert_e2393373882862 : check e2393373882862 [[],[.left],[]] .sourceHead = true := by decide
def e2393373883422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2393373883422 : Closed e2393373883422 ∧ code e2393373883422 = 11189466905630 := by decide
theorem cert_e2393373883422 : check e2393373883422 [[],[.left],[]] .sourceHead = true := by decide
def e2393373883618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2393373883618 : Closed e2393373883618 ∧ code e2393373883618 = 11189466905826 := by decide
theorem cert_e2393373883618 : check e2393373883618 [[],[.left],[]] .sourceHead = true := by decide
def e2393373883630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393373883630 : Closed e2393373883630 ∧ code e2393373883630 = 11189466905838 := by decide
theorem cert_e2393373883630 : check e2393373883630 [[],[.left],[]] .sourceHead = true := by decide
def e2393373883638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393373883638 : Closed e2393373883638 ∧ code e2393373883638 = 11189466905846 := by decide
theorem cert_e2393373883638 : check e2393373883638 [[],[.left],[]] .sourceHead = true := by decide
def e2393373902814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e2393373902814 : Closed e2393373902814 ∧ code e2393373902814 = 11189466925022 := by decide
theorem cert_e2393373902814 : check e2393373902814 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2393373906478 : Closed e2393373906478 ∧ code e2393373906478 = 11189466928686 := by decide
theorem cert_e2393373906478 : check e2393373906478 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2393373906658 : Closed e2393373906658 ∧ code e2393373906658 = 11189466928866 := by decide
theorem cert_e2393373906658 : check e2393373906658 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2393373906670 : Closed e2393373906670 ∧ code e2393373906670 = 11189466928878 := by decide
theorem cert_e2393373906670 : check e2393373906670 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2393373906798 : Closed e2393373906798 ∧ code e2393373906798 = 11189466929006 := by decide
theorem cert_e2393373906798 : check e2393373906798 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2393373906806 : Closed e2393373906806 ∧ code e2393373906806 = 11189466929014 := by decide
theorem cert_e2393373906806 : check e2393373906806 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393373906826 : Closed e2393373906826 ∧ code e2393373906826 = 11189466929034 := by decide
theorem cert_e2393373906826 : check e2393373906826 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393373906850 : Closed e2393373906850 ∧ code e2393373906850 = 11189466929058 := by decide
theorem cert_e2393373906850 : check e2393373906850 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2393373906862 : Closed e2393373906862 ∧ code e2393373906862 = 11189466929070 := by decide
theorem cert_e2393373906862 : check e2393373906862 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2393373906870 : Closed e2393373906870 ∧ code e2393373906870 = 11189466929078 := by decide
theorem cert_e2393373906870 : check e2393373906870 [[],[.left],[]] .sourceHead = true := by decide
def e2393373906874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2393373906874 : Closed e2393373906874 ∧ code e2393373906874 = 11189466929082 := by decide
theorem cert_e2393373906874 : check e2393373906874 [[],[.left],[]] .sourceHead = true := by decide
def e2393373907006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2393373907006 : Closed e2393373907006 ∧ code e2393373907006 = 11189466929214 := by decide
theorem cert_e2393373907006 : check e2393373907006 [[],[.left],[]] .sourceHead = true := by decide
def e2393373907426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2393373907426 : Closed e2393373907426 ∧ code e2393373907426 = 11189466929634 := by decide
theorem cert_e2393373907426 : check e2393373907426 [[],[.left],[]] .sourceHead = true := by decide
def e2393373907438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393373907438 : Closed e2393373907438 ∧ code e2393373907438 = 11189466929646 := by decide
theorem cert_e2393373907438 : check e2393373907438 [[],[.left],[]] .sourceHead = true := by decide
def e2393373908206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393373908206 : Closed e2393373908206 ∧ code e2393373908206 = 11189466930414 := by decide
theorem cert_e2393373908206 : check e2393373908206 [[],[.left],[]] .sourceHead = true := by decide
def e2393373908214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393373908214 : Closed e2393373908214 ∧ code e2393373908214 = 11189466930422 := by decide
theorem cert_e2393373908214 : check e2393373908214 [[],[.left],[]] .sourceHead = true := by decide
def e2393373908494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2393373908494 : Closed e2393373908494 ∧ code e2393373908494 = 11189466930702 := by decide
theorem cert_e2393373908494 : check e2393373908494 [[],[.left],[]] .sourceHead = true := by decide
def e2393373908506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2393373908506 : Closed e2393373908506 ∧ code e2393373908506 = 11189466930714 := by decide
theorem cert_e2393373908506 : check e2393373908506 [[],[.left],[]] .sourceHead = true := by decide
def e2393373908578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393373908578 : Closed e2393373908578 ∧ code e2393373908578 = 11189466930786 := by decide
theorem cert_e2393373908578 : check e2393373908578 [[],[.left],[]] .sourceHead = true := by decide
def e2393373908590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393373908590 : Closed e2393373908590 ∧ code e2393373908590 = 11189466930798 := by decide
theorem cert_e2393373908590 : check e2393373908590 [[],[.left],[]] .sourceHead = true := by decide
def e2393373908598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393373908598 : Closed e2393373908598 ∧ code e2393373908598 = 11189466930806 := by decide
theorem cert_e2393373908598 : check e2393373908598 [[],[.left],[]] .sourceHead = true := by decide
def e2393373908602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393373908602 : Closed e2393373908602 ∧ code e2393373908602 = 11189466930810 := by decide
theorem cert_e2393373908602 : check e2393373908602 [[],[.left],[]] .sourceHead = true := by decide
def e2393373918174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2393373918174 : Closed e2393373918174 ∧ code e2393373918174 = 11189466940382 := by decide
theorem cert_e2393373918174 : check e2393373918174 [[],[.left],[]] .sourceHead = true := by decide
def e2393373918190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2393373918190 : Closed e2393373918190 ∧ code e2393373918190 = 11189466940398 := by decide
theorem cert_e2393373918190 : check e2393373918190 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2393373920022 : Closed e2393373920022 ∧ code e2393373920022 = 11189466942230 := by decide
theorem cert_e2393373920022 : check e2393373920022 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2393373920098 : Closed e2393373920098 ∧ code e2393373920098 = 11189466942306 := by decide
theorem cert_e2393373920098 : check e2393373920098 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393373920110 : Closed e2393373920110 ∧ code e2393373920110 = 11189466942318 := by decide
theorem cert_e2393373920110 : check e2393373920110 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393373920118 : Closed e2393373920118 ∧ code e2393373920118 = 11189466942326 := by decide
theorem cert_e2393373920118 : check e2393373920118 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393373920138 : Closed e2393373920138 ∧ code e2393373920138 = 11189466942346 := by decide
theorem cert_e2393373920138 : check e2393373920138 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393373920162 : Closed e2393373920162 ∧ code e2393373920162 = 11189466942370 := by decide
theorem cert_e2393373920162 : check e2393373920162 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393373920174 : Closed e2393373920174 ∧ code e2393373920174 = 11189466942382 := by decide
theorem cert_e2393373920174 : check e2393373920174 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e2393373920182 : Closed e2393373920182 ∧ code e2393373920182 = 11189466942390 := by decide
theorem cert_e2393373920182 : check e2393373920182 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393373920186 : Closed e2393373920186 ∧ code e2393373920186 = 11189466942394 := by decide
theorem cert_e2393373920186 : check e2393373920186 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393373920214 : Closed e2393373920214 ∧ code e2393373920214 = 11189466942422 := by decide
theorem cert_e2393373920214 : check e2393373920214 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393373920218 : Closed e2393373920218 ∧ code e2393373920218 = 11189466942426 := by decide
theorem cert_e2393373920218 : check e2393373920218 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2393373920286 : Closed e2393373920286 ∧ code e2393373920286 = 11189466942494 := by decide
theorem cert_e2393373920286 : check e2393373920286 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2393373920482 : Closed e2393373920482 ∧ code e2393373920482 = 11189466942690 := by decide
theorem cert_e2393373920482 : check e2393373920482 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393373920494 : Closed e2393373920494 ∧ code e2393373920494 = 11189466942702 := by decide
theorem cert_e2393373920494 : check e2393373920494 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393373920502 : Closed e2393373920502 ∧ code e2393373920502 = 11189466942710 := by decide
theorem cert_e2393373920502 : check e2393373920502 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2393373920782 : Closed e2393373920782 ∧ code e2393373920782 = 11189466942990 := by decide
theorem cert_e2393373920782 : check e2393373920782 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2393373920794 : Closed e2393373920794 ∧ code e2393373920794 = 11189466943002 := by decide
theorem cert_e2393373920794 : check e2393373920794 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393373920866 : Closed e2393373920866 ∧ code e2393373920866 = 11189466943074 := by decide
theorem cert_e2393373920866 : check e2393373920866 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393373920878 : Closed e2393373920878 ∧ code e2393373920878 = 11189466943086 := by decide
theorem cert_e2393373920878 : check e2393373920878 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393373920886 : Closed e2393373920886 ∧ code e2393373920886 = 11189466943094 := by decide
theorem cert_e2393373920886 : check e2393373920886 [[],[.left],[]] .sourceHead = true := by decide
def e2393373920890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393373920890 : Closed e2393373920890 ∧ code e2393373920890 = 11189466943098 := by decide
theorem cert_e2393373920890 : check e2393373920890 [[],[.left],[]] .sourceHead = true := by decide
def e2393373921078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393373921078 : Closed e2393373921078 ∧ code e2393373921078 = 11189466943286 := by decide
theorem cert_e2393373921078 : check e2393373921078 [[],[.left],[]] .sourceHead = true := by decide
def e2393373921082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393373921082 : Closed e2393373921082 ∧ code e2393373921082 = 11189466943290 := by decide
theorem cert_e2393373921082 : check e2393373921082 [[],[.left],[]] .sourceHead = true := by decide
def e2393374201566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2393374201566 : Closed e2393374201566 ∧ code e2393374201566 = 11189467223774 := by decide
theorem cert_e2393374201566 : check e2393374201566 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374201590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2393374201590 : Closed e2393374201590 ∧ code e2393374201590 = 11189467223798 := by decide
theorem cert_e2393374201590 : check e2393374201590 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374201694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2393374201694 : Closed e2393374201694 ∧ code e2393374201694 = 11189467223902 := by decide
theorem cert_e2393374201694 : check e2393374201694 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374201722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2393374201722 : Closed e2393374201722 ∧ code e2393374201722 = 11189467223930 := by decide
theorem cert_e2393374201722 : check e2393374201722 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374201814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2393374201814 : Closed e2393374201814 ∧ code e2393374201814 = 11189467224022 := by decide
theorem cert_e2393374201814 : check e2393374201814 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374201818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2393374201818 : Closed e2393374201818 ∧ code e2393374201818 = 11189467224026 := by decide
theorem cert_e2393374201818 : check e2393374201818 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374202334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2393374202334 : Closed e2393374202334 ∧ code e2393374202334 = 11189467224542 := by decide
theorem cert_e2393374202334 : check e2393374202334 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374202358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2393374202358 : Closed e2393374202358 ∧ code e2393374202358 = 11189467224566 := by decide
theorem cert_e2393374202358 : check e2393374202358 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374203102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2393374203102 : Closed e2393374203102 ∧ code e2393374203102 = 11189467225310 := by decide
theorem cert_e2393374203102 : check e2393374203102 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374203130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2393374203130 : Closed e2393374203130 ∧ code e2393374203130 = 11189467225338 := by decide
theorem cert_e2393374203130 : check e2393374203130 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374203702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393374203702 : Closed e2393374203702 ∧ code e2393374203702 = 11189467225910 := by decide
theorem cert_e2393374203702 : check e2393374203702 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374203706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393374203706 : Closed e2393374203706 ∧ code e2393374203706 = 11189467225914 := by decide
theorem cert_e2393374203706 : check e2393374203706 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374218478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2393374218478 : Closed e2393374218478 ∧ code e2393374218478 = 11189467240686 := by decide
theorem cert_e2393374218478 : check e2393374218478 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374218486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2393374218486 : Closed e2393374218486 ∧ code e2393374218486 = 11189467240694 := by decide
theorem cert_e2393374218486 : check e2393374218486 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2393374219038 : Closed e2393374219038 ∧ code e2393374219038 = 11189467241246 := by decide
theorem cert_e2393374219038 : check e2393374219038 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2393374219150 : Closed e2393374219150 ∧ code e2393374219150 = 11189467241358 := by decide
theorem cert_e2393374219150 : check e2393374219150 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2393374219374 : Closed e2393374219374 ∧ code e2393374219374 = 11189467241582 := by decide
theorem cert_e2393374219374 : check e2393374219374 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2393374219386 : Closed e2393374219386 ∧ code e2393374219386 = 11189467241594 := by decide
theorem cert_e2393374219386 : check e2393374219386 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2393374219550 : Closed e2393374219550 ∧ code e2393374219550 = 11189467241758 := by decide
theorem cert_e2393374219550 : check e2393374219550 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2393374219718 : Closed e2393374219718 ∧ code e2393374219718 = 11189467241926 := by decide
theorem cert_e2393374219718 : check e2393374219718 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2393374219742 : Closed e2393374219742 ∧ code e2393374219742 = 11189467241950 := by decide
theorem cert_e2393374219742 : check e2393374219742 [[],[.left],[],[.under]] .three = true := by decide
def e2393374219758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2393374219758 : Closed e2393374219758 ∧ code e2393374219758 = 11189467241966 := by decide
theorem cert_e2393374219758 : check e2393374219758 [[],[.left],[],[.under]] .three = true := by decide
def e2393374219830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2393374219830 : Closed e2393374219830 ∧ code e2393374219830 = 11189467242038 := by decide
theorem cert_e2393374219830 : check e2393374219830 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2393374219834 : Closed e2393374219834 ∧ code e2393374219834 = 11189467242042 := by decide
theorem cert_e2393374219834 : check e2393374219834 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2393374219918 : Closed e2393374219918 ∧ code e2393374219918 = 11189467242126 := by decide
theorem cert_e2393374219918 : check e2393374219918 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2393374219974 : Closed e2393374219974 ∧ code e2393374219974 = 11189467242182 := by decide
theorem cert_e2393374219974 : check e2393374219974 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374219998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2393374219998 : Closed e2393374219998 ∧ code e2393374219998 = 11189467242206 := by decide
theorem cert_e2393374219998 : check e2393374219998 [[],[.left],[],[.under]] .three = true := by decide
def e2393374220022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2393374220022 : Closed e2393374220022 ∧ code e2393374220022 = 11189467242230 := by decide
theorem cert_e2393374220022 : check e2393374220022 [[],[.left],[],[.under]] .three = true := by decide
def e2393374220142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2393374220142 : Closed e2393374220142 ∧ code e2393374220142 = 11189467242350 := by decide
theorem cert_e2393374220142 : check e2393374220142 [[],[.left],[],[.under]] .three = true := by decide
def e2393374220150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2393374220150 : Closed e2393374220150 ∧ code e2393374220150 = 11189467242358 := by decide
theorem cert_e2393374220150 : check e2393374220150 [[],[.left],[],[.under]] .three = true := by decide
def e2393374222110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2393374222110 : Closed e2393374222110 ∧ code e2393374222110 = 11189467244318 := by decide
theorem cert_e2393374222110 : check e2393374222110 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374222222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2393374222222 : Closed e2393374222222 ∧ code e2393374222222 = 11189467244430 := by decide
theorem cert_e2393374222222 : check e2393374222222 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374225182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2393374225182 : Closed e2393374225182 ∧ code e2393374225182 = 11189467247390 := by decide
theorem cert_e2393374225182 : check e2393374225182 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374225350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2393374225350 : Closed e2393374225350 ∧ code e2393374225350 = 11189467247558 := by decide
theorem cert_e2393374225350 : check e2393374225350 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374225374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2393374225374 : Closed e2393374225374 ∧ code e2393374225374 = 11189467247582 := by decide
theorem cert_e2393374225374 : check e2393374225374 [[],[.left],[],[.under]] .three = true := by decide
def e2393374225390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2393374225390 : Closed e2393374225390 ∧ code e2393374225390 = 11189467247598 := by decide
theorem cert_e2393374225390 : check e2393374225390 [[],[.left],[],[.under]] .three = true := by decide
def e2393374226830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2393374226830 : Closed e2393374226830 ∧ code e2393374226830 = 11189467249038 := by decide
theorem cert_e2393374226830 : check e2393374226830 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374226886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2393374226886 : Closed e2393374226886 ∧ code e2393374226886 = 11189467249094 := by decide
theorem cert_e2393374226886 : check e2393374226886 [[],[.left],[],[.under]] .smaller = true := by decide
def e2393374226910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2393374226910 : Closed e2393374226910 ∧ code e2393374226910 = 11189467249118 := by decide
theorem cert_e2393374226910 : check e2393374226910 [[],[.left],[],[.under]] .three = true := by decide
def e2393374226934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2393374226934 : Closed e2393374226934 ∧ code e2393374226934 = 11189467249142 := by decide
theorem cert_e2393374226934 : check e2393374226934 [[],[.left],[],[.under]] .three = true := by decide
def e2393374227694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393374227694 : Closed e2393374227694 ∧ code e2393374227694 = 11189467249902 := by decide
theorem cert_e2393374227694 : check e2393374227694 [[],[.left],[],[.under]] .three = true := by decide
def e2393374227702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393374227702 : Closed e2393374227702 ∧ code e2393374227702 = 11189467249910 := by decide
theorem cert_e2393374227702 : check e2393374227702 [[],[.left],[],[.under]] .three = true := by decide
def e2393374268014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2393374268014 : Closed e2393374268014 ∧ code e2393374268014 = 11189467290222 := by decide
theorem cert_e2393374268014 : check e2393374268014 [[],[.left],[],[.under]] .three = true := by decide
def e2393374268026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2393374268026 : Closed e2393374268026 ∧ code e2393374268026 = 11189467290234 := by decide
theorem cert_e2393374268026 : check e2393374268026 [[],[.left],[],[.under]] .three = true := by decide
def e2393374283950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2393374283950 : Closed e2393374283950 ∧ code e2393374283950 = 11189467306158 := by decide
theorem cert_e2393374283950 : check e2393374283950 [[],[.left],[],[.under]] .three = true := by decide
def e2393374283962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2393374283962 : Closed e2393374283962 ∧ code e2393374283962 = 11189467306170 := by decide
theorem cert_e2393374283962 : check e2393374283962 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393374284334 : Closed e2393374284334 ∧ code e2393374284334 = 11189467306542 := by decide
theorem cert_e2393374284334 : check e2393374284334 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393374284514 : Closed e2393374284514 ∧ code e2393374284514 = 11189467306722 := by decide
theorem cert_e2393374284514 : check e2393374284514 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2393374284526 : Closed e2393374284526 ∧ code e2393374284526 = 11189467306734 := by decide
theorem cert_e2393374284526 : check e2393374284526 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2393374284654 : Closed e2393374284654 ∧ code e2393374284654 = 11189467306862 := by decide
theorem cert_e2393374284654 : check e2393374284654 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2393374284662 : Closed e2393374284662 ∧ code e2393374284662 = 11189467306870 := by decide
theorem cert_e2393374284662 : check e2393374284662 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393374284682 : Closed e2393374284682 ∧ code e2393374284682 = 11189467306890 := by decide
theorem cert_e2393374284682 : check e2393374284682 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393374284706 : Closed e2393374284706 ∧ code e2393374284706 = 11189467306914 := by decide
theorem cert_e2393374284706 : check e2393374284706 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2393374284718 : Closed e2393374284718 ∧ code e2393374284718 = 11189467306926 := by decide
theorem cert_e2393374284718 : check e2393374284718 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2393374284726 : Closed e2393374284726 ∧ code e2393374284726 = 11189467306934 := by decide
theorem cert_e2393374284726 : check e2393374284726 [[],[.left],[],[.under]] .three = true := by decide
def e2393374284730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2393374284730 : Closed e2393374284730 ∧ code e2393374284730 = 11189467306938 := by decide
theorem cert_e2393374284730 : check e2393374284730 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2393374285166 : Closed e2393374285166 ∧ code e2393374285166 = 11189467307374 := by decide
theorem cert_e2393374285166 : check e2393374285166 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2393374285174 : Closed e2393374285174 ∧ code e2393374285174 = 11189467307382 := by decide
theorem cert_e2393374285174 : check e2393374285174 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2393374285230 : Closed e2393374285230 ∧ code e2393374285230 = 11189467307438 := by decide
theorem cert_e2393374285230 : check e2393374285230 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2393374285242 : Closed e2393374285242 ∧ code e2393374285242 = 11189467307450 := by decide
theorem cert_e2393374285242 : check e2393374285242 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2393374285270 : Closed e2393374285270 ∧ code e2393374285270 = 11189467307478 := by decide
theorem cert_e2393374285270 : check e2393374285270 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2393374285274 : Closed e2393374285274 ∧ code e2393374285274 = 11189467307482 := by decide
theorem cert_e2393374285274 : check e2393374285274 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2393374285354 : Closed e2393374285354 ∧ code e2393374285354 = 11189467307562 := by decide
theorem cert_e2393374285354 : check e2393374285354 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393374285450 : Closed e2393374285450 ∧ code e2393374285450 = 11189467307658 := by decide
theorem cert_e2393374285450 : check e2393374285450 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393374285474 : Closed e2393374285474 ∧ code e2393374285474 = 11189467307682 := by decide
theorem cert_e2393374285474 : check e2393374285474 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2393374285486 : Closed e2393374285486 ∧ code e2393374285486 = 11189467307694 := by decide
theorem cert_e2393374285486 : check e2393374285486 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2393374285494 : Closed e2393374285494 ∧ code e2393374285494 = 11189467307702 := by decide
theorem cert_e2393374285494 : check e2393374285494 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2393374285498 : Closed e2393374285498 ∧ code e2393374285498 = 11189467307706 := by decide
theorem cert_e2393374285498 : check e2393374285498 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2393374285526 : Closed e2393374285526 ∧ code e2393374285526 = 11189467307734 := by decide
theorem cert_e2393374285526 : check e2393374285526 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2393374285530 : Closed e2393374285530 ∧ code e2393374285530 = 11189467307738 := by decide
theorem cert_e2393374285530 : check e2393374285530 [[],[.left],[],[.under]] .three = true := by decide
def e2393374285546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2393374285546 : Closed e2393374285546 ∧ code e2393374285546 = 11189467307754 := by decide
theorem cert_e2393374285546 : check e2393374285546 [[],[.left],[],[.under]] .three = true := by decide
def e2393374286062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2393374286062 : Closed e2393374286062 ∧ code e2393374286062 = 11189467308270 := by decide
theorem cert_e2393374286062 : check e2393374286062 [[],[.left],[],[.under]] .three = true := by decide
def e2393374286074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2393374286074 : Closed e2393374286074 ∧ code e2393374286074 = 11189467308282 := by decide
theorem cert_e2393374286074 : check e2393374286074 [[],[.left],[],[.under]] .three = true := by decide
def e2393374286254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2393374286254 : Closed e2393374286254 ∧ code e2393374286254 = 11189467308462 := by decide
theorem cert_e2393374286254 : check e2393374286254 [[],[.left],[],[.under]] .three = true := by decide
def e2393374286446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2393374286446 : Closed e2393374286446 ∧ code e2393374286446 = 11189467308654 := by decide
theorem cert_e2393374286446 : check e2393374286446 [[],[.left],[],[.under]] .three = true := by decide
def e2393374286458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2393374286458 : Closed e2393374286458 ∧ code e2393374286458 = 11189467308666 := by decide
theorem cert_e2393374286458 : check e2393374286458 [[],[.left],[],[.under]] .three = true := by decide
def e2393374286622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2393374286622 : Closed e2393374286622 ∧ code e2393374286622 = 11189467308830 := by decide
theorem cert_e2393374286622 : check e2393374286622 [[],[.left],[],[.under]] .three = true := by decide
def e2393374286790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2393374286790 : Closed e2393374286790 ∧ code e2393374286790 = 11189467308998 := by decide
theorem cert_e2393374286790 : check e2393374286790 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2393374287406 : Closed e2393374287406 ∧ code e2393374287406 = 11189467309614 := by decide
theorem cert_e2393374287406 : check e2393374287406 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2393374287586 : Closed e2393374287586 ∧ code e2393374287586 = 11189467309794 := by decide
theorem cert_e2393374287586 : check e2393374287586 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2393374287598 : Closed e2393374287598 ∧ code e2393374287598 = 11189467309806 := by decide
theorem cert_e2393374287598 : check e2393374287598 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2393374287726 : Closed e2393374287726 ∧ code e2393374287726 = 11189467309934 := by decide
theorem cert_e2393374287726 : check e2393374287726 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2393374287734 : Closed e2393374287734 ∧ code e2393374287734 = 11189467309942 := by decide
theorem cert_e2393374287734 : check e2393374287734 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393374287754 : Closed e2393374287754 ∧ code e2393374287754 = 11189467309962 := by decide
theorem cert_e2393374287754 : check e2393374287754 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393374287778 : Closed e2393374287778 ∧ code e2393374287778 = 11189467309986 := by decide
theorem cert_e2393374287778 : check e2393374287778 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2393374287790 : Closed e2393374287790 ∧ code e2393374287790 = 11189467309998 := by decide
theorem cert_e2393374287790 : check e2393374287790 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2393374287798 : Closed e2393374287798 ∧ code e2393374287798 = 11189467310006 := by decide
theorem cert_e2393374287798 : check e2393374287798 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2393374287802 : Closed e2393374287802 ∧ code e2393374287802 = 11189467310010 := by decide
theorem cert_e2393374287802 : check e2393374287802 [[],[.left],[],[.under]] .three = true := by decide
def e2393374287934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2393374287934 : Closed e2393374287934 ∧ code e2393374287934 = 11189467310142 := by decide
theorem cert_e2393374287934 : check e2393374287934 [[],[.left],[],[.under]] .three = true := by decide
def e2393374288354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393374288354 : Closed e2393374288354 ∧ code e2393374288354 = 11189467310562 := by decide
theorem cert_e2393374288354 : check e2393374288354 [[],[.left],[],[.under]] .three = true := by decide
def e2393374288366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2393374288366 : Closed e2393374288366 ∧ code e2393374288366 = 11189467310574 := by decide
theorem cert_e2393374288366 : check e2393374288366 [[],[.left],[],[.under]] .three = true := by decide
end Blc.Floor43
