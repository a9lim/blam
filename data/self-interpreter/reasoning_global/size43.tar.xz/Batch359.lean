import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419153090746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2419153090746 : Closed e2419153090746 ∧ code e2419153090746 = 11215246112954 := by decide
theorem cert_e2419153090746 : check e2419153090746 [[],[]] .sourceHead = true := by decide
def e2419153091118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419153091118 : Closed e2419153091118 ∧ code e2419153091118 = 11215246113326 := by decide
theorem cert_e2419153091118 : check e2419153091118 [[],[]] .sourceHead = true := by decide
def e2419153091298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419153091298 : Closed e2419153091298 ∧ code e2419153091298 = 11215246113506 := by decide
theorem cert_e2419153091298 : check e2419153091298 [[],[]] .sourceHead = true := by decide
def e2419153091310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2419153091310 : Closed e2419153091310 ∧ code e2419153091310 = 11215246113518 := by decide
theorem cert_e2419153091310 : check e2419153091310 [[],[]] .sourceHead = true := by decide
def e2419153091466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419153091466 : Closed e2419153091466 ∧ code e2419153091466 = 11215246113674 := by decide
theorem cert_e2419153091466 : check e2419153091466 [[],[]] .sourceHead = true := by decide
def e2419153091490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419153091490 : Closed e2419153091490 ∧ code e2419153091490 = 11215246113698 := by decide
theorem cert_e2419153091490 : check e2419153091490 [[],[]] .sourceHead = true := by decide
def e2419153091502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2419153091502 : Closed e2419153091502 ∧ code e2419153091502 = 11215246113710 := by decide
theorem cert_e2419153091502 : check e2419153091502 [[],[]] .sourceHead = true := by decide
def e2419153091514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2419153091514 : Closed e2419153091514 ∧ code e2419153091514 = 11215246113722 := by decide
theorem cert_e2419153091514 : check e2419153091514 [[],[]] .sourceHead = true := by decide
def e2419153091670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2419153091670 : Closed e2419153091670 ∧ code e2419153091670 = 11215246113878 := by decide
theorem cert_e2419153091670 : check e2419153091670 [[],[]] .sourceHead = true := by decide
def e2419153091674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2419153091674 : Closed e2419153091674 ∧ code e2419153091674 = 11215246113882 := by decide
theorem cert_e2419153091674 : check e2419153091674 [[],[]] .sourceHead = true := by decide
def e2419153091862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419153091862 : Closed e2419153091862 ∧ code e2419153091862 = 11215246114070 := by decide
theorem cert_e2419153091862 : check e2419153091862 [[],[]] .sourceHead = true := by decide
def e2419153091938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419153091938 : Closed e2419153091938 ∧ code e2419153091938 = 11215246114146 := by decide
theorem cert_e2419153091938 : check e2419153091938 [[],[]] .sourceHead = true := by decide
def e2419153091950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2419153091950 : Closed e2419153091950 ∧ code e2419153091950 = 11215246114158 := by decide
theorem cert_e2419153091950 : check e2419153091950 [[],[]] .sourceHead = true := by decide
def e2419153091958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2419153091958 : Closed e2419153091958 ∧ code e2419153091958 = 11215246114166 := by decide
theorem cert_e2419153091958 : check e2419153091958 [[],[]] .sourceHead = true := by decide
def e2419153091978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419153091978 : Closed e2419153091978 ∧ code e2419153091978 = 11215246114186 := by decide
theorem cert_e2419153091978 : check e2419153091978 [[],[]] .sourceHead = true := by decide
def e2419153092002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419153092002 : Closed e2419153092002 ∧ code e2419153092002 = 11215246114210 := by decide
theorem cert_e2419153092002 : check e2419153092002 [[],[]] .sourceHead = true := by decide
def e2419153092014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2419153092014 : Closed e2419153092014 ∧ code e2419153092014 = 11215246114222 := by decide
theorem cert_e2419153092014 : check e2419153092014 [[],[]] .sourceHead = true := by decide
def e2419153092026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2419153092026 : Closed e2419153092026 ∧ code e2419153092026 = 11215246114234 := by decide
theorem cert_e2419153092026 : check e2419153092026 [[],[]] .sourceHead = true := by decide
def e2419153092054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2419153092054 : Closed e2419153092054 ∧ code e2419153092054 = 11215246114262 := by decide
theorem cert_e2419153092054 : check e2419153092054 [[],[]] .sourceHead = true := by decide
def e2419153092058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2419153092058 : Closed e2419153092058 ∧ code e2419153092058 = 11215246114266 := by decide
theorem cert_e2419153092058 : check e2419153092058 [[],[]] .sourceHead = true := by decide
def e2419153093102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2419153093102 : Closed e2419153093102 ∧ code e2419153093102 = 11215246115310 := by decide
theorem cert_e2419153093102 : check e2419153093102 [[],[]] .sourceHead = true := by decide
def e2419153093110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2419153093110 : Closed e2419153093110 ∧ code e2419153093110 = 11215246115318 := by decide
theorem cert_e2419153093110 : check e2419153093110 [[],[]] .sourceHead = true := by decide
def e2419153093870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2419153093870 : Closed e2419153093870 ∧ code e2419153093870 = 11215246116078 := by decide
theorem cert_e2419153093870 : check e2419153093870 [[],[]] .sourceHead = true := by decide
def e2419153093878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2419153093878 : Closed e2419153093878 ∧ code e2419153093878 = 11215246116086 := by decide
theorem cert_e2419153093878 : check e2419153093878 [[],[]] .sourceHead = true := by decide
def e2419153094430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2419153094430 : Closed e2419153094430 ∧ code e2419153094430 = 11215246116638 := by decide
theorem cert_e2419153094430 : check e2419153094430 [[],[]] .sourceHead = true := by decide
def e2419153094542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2419153094542 : Closed e2419153094542 ∧ code e2419153094542 = 11215246116750 := by decide
theorem cert_e2419153094542 : check e2419153094542 [[],[]] .sourceHead = true := by decide
def e2419153096238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2419153096238 : Closed e2419153096238 ∧ code e2419153096238 = 11215246118446 := by decide
theorem cert_e2419153096238 : check e2419153096238 [[],[]] .sourceHead = true := by decide
def e2419153096418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2419153096418 : Closed e2419153096418 ∧ code e2419153096418 = 11215246118626 := by decide
theorem cert_e2419153096418 : check e2419153096418 [[],[]] .sourceHead = true := by decide
def e2419153096430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2419153096430 : Closed e2419153096430 ∧ code e2419153096430 = 11215246118638 := by decide
theorem cert_e2419153096430 : check e2419153096430 [[],[]] .sourceHead = true := by decide
def e2419153096470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2419153096470 : Closed e2419153096470 ∧ code e2419153096470 = 11215246118678 := by decide
theorem cert_e2419153096470 : check e2419153096470 [[],[]] .sourceHead = true := by decide
def e2419153096546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2419153096546 : Closed e2419153096546 ∧ code e2419153096546 = 11215246118754 := by decide
theorem cert_e2419153096546 : check e2419153096546 [[],[]] .sourceHead = true := by decide
def e2419153096558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2419153096558 : Closed e2419153096558 ∧ code e2419153096558 = 11215246118766 := by decide
theorem cert_e2419153096558 : check e2419153096558 [[],[]] .sourceHead = true := by decide
def e2419153096566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2419153096566 : Closed e2419153096566 ∧ code e2419153096566 = 11215246118774 := by decide
theorem cert_e2419153096566 : check e2419153096566 [[],[]] .sourceHead = true := by decide
def e2419153098814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2419153098814 : Closed e2419153098814 ∧ code e2419153098814 = 11215246121022 := by decide
theorem cert_e2419153098814 : check e2419153098814 [[],[]] .sourceHead = true := by decide
def e2419153099234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419153099234 : Closed e2419153099234 ∧ code e2419153099234 = 11215246121442 := by decide
theorem cert_e2419153099234 : check e2419153099234 [[],[]] .sourceHead = true := by decide
def e2419153099246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2419153099246 : Closed e2419153099246 ∧ code e2419153099246 = 11215246121454 := by decide
theorem cert_e2419153099246 : check e2419153099246 [[],[]] .sourceHead = true := by decide
def e2419153099806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2419153099806 : Closed e2419153099806 ∧ code e2419153099806 = 11215246122014 := by decide
theorem cert_e2419153099806 : check e2419153099806 [[],[]] .sourceHead = true := by decide
def e2419153100002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419153100002 : Closed e2419153100002 ∧ code e2419153100002 = 11215246122210 := by decide
theorem cert_e2419153100002 : check e2419153100002 [[],[]] .sourceHead = true := by decide
def e2419153100014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419153100014 : Closed e2419153100014 ∧ code e2419153100014 = 11215246122222 := by decide
theorem cert_e2419153100014 : check e2419153100014 [[],[]] .sourceHead = true := by decide
def e2419153100022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419153100022 : Closed e2419153100022 ∧ code e2419153100022 = 11215246122230 := by decide
theorem cert_e2419153100022 : check e2419153100022 [[],[]] .sourceHead = true := by decide
def e2419153101038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2419153101038 : Closed e2419153101038 ∧ code e2419153101038 = 11215246123246 := by decide
theorem cert_e2419153101038 : check e2419153101038 [[],[]] .sourceHead = true := by decide
def e2419153101050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2419153101050 : Closed e2419153101050 ∧ code e2419153101050 = 11215246123258 := by decide
theorem cert_e2419153101050 : check e2419153101050 [[],[]] .sourceHead = true := by decide
def e2419153101422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2419153101422 : Closed e2419153101422 ∧ code e2419153101422 = 11215246123630 := by decide
theorem cert_e2419153101422 : check e2419153101422 [[],[]] .sourceHead = true := by decide
def e2419153101434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2419153101434 : Closed e2419153101434 ∧ code e2419153101434 = 11215246123642 := by decide
theorem cert_e2419153101434 : check e2419153101434 [[],[]] .sourceHead = true := by decide
def e2419153101598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2419153101598 : Closed e2419153101598 ∧ code e2419153101598 = 11215246123806 := by decide
theorem cert_e2419153101598 : check e2419153101598 [[],[]] .sourceHead = true := by decide
def e2419153101766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2419153101766 : Closed e2419153101766 ∧ code e2419153101766 = 11215246123974 := by decide
theorem cert_e2419153101766 : check e2419153101766 [[],[]] .sourceHead = true := by decide
def e2419153102382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2419153102382 : Closed e2419153102382 ∧ code e2419153102382 = 11215246124590 := by decide
theorem cert_e2419153102382 : check e2419153102382 [[],[]] .sourceHead = true := by decide
def e2419153102562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2419153102562 : Closed e2419153102562 ∧ code e2419153102562 = 11215246124770 := by decide
theorem cert_e2419153102562 : check e2419153102562 [[],[]] .sourceHead = true := by decide
def e2419153102574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2419153102574 : Closed e2419153102574 ∧ code e2419153102574 = 11215246124782 := by decide
theorem cert_e2419153102574 : check e2419153102574 [[],[]] .sourceHead = true := by decide
def e2419153102730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419153102730 : Closed e2419153102730 ∧ code e2419153102730 = 11215246124938 := by decide
theorem cert_e2419153102730 : check e2419153102730 [[],[]] .sourceHead = true := by decide
def e2419153102754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419153102754 : Closed e2419153102754 ∧ code e2419153102754 = 11215246124962 := by decide
theorem cert_e2419153102754 : check e2419153102754 [[],[]] .sourceHead = true := by decide
def e2419153102766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2419153102766 : Closed e2419153102766 ∧ code e2419153102766 = 11215246124974 := by decide
theorem cert_e2419153102766 : check e2419153102766 [[],[]] .sourceHead = true := by decide
def e2419153102778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2419153102778 : Closed e2419153102778 ∧ code e2419153102778 = 11215246124986 := by decide
theorem cert_e2419153102778 : check e2419153102778 [[],[]] .sourceHead = true := by decide
def e2419153102910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2419153102910 : Closed e2419153102910 ∧ code e2419153102910 = 11215246125118 := by decide
theorem cert_e2419153102910 : check e2419153102910 [[],[]] .sourceHead = true := by decide
def e2419153103330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419153103330 : Closed e2419153103330 ∧ code e2419153103330 = 11215246125538 := by decide
theorem cert_e2419153103330 : check e2419153103330 [[],[]] .sourceHead = true := by decide
def e2419153103342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2419153103342 : Closed e2419153103342 ∧ code e2419153103342 = 11215246125550 := by decide
theorem cert_e2419153103342 : check e2419153103342 [[],[]] .sourceHead = true := by decide
def e2419153104398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419153104398 : Closed e2419153104398 ∧ code e2419153104398 = 11215246126606 := by decide
theorem cert_e2419153104398 : check e2419153104398 [[],[]] .sourceHead = true := by decide
def e2419153104482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419153104482 : Closed e2419153104482 ∧ code e2419153104482 = 11215246126690 := by decide
theorem cert_e2419153104482 : check e2419153104482 [[],[]] .sourceHead = true := by decide
def e2419153104494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419153104494 : Closed e2419153104494 ∧ code e2419153104494 = 11215246126702 := by decide
theorem cert_e2419153104494 : check e2419153104494 [[],[]] .sourceHead = true := by decide
def e2419153104506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419153104506 : Closed e2419153104506 ∧ code e2419153104506 = 11215246126714 := by decide
theorem cert_e2419153104506 : check e2419153104506 [[],[]] .sourceHead = true := by decide
def e2419153105014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2419153105014 : Closed e2419153105014 ∧ code e2419153105014 = 11215246127222 := by decide
theorem cert_e2419153105014 : check e2419153105014 [[],[]] .sourceHead = true := by decide
def e2419153105018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2419153105018 : Closed e2419153105018 ∧ code e2419153105018 = 11215246127226 := by decide
theorem cert_e2419153105018 : check e2419153105018 [[],[]] .sourceHead = true := by decide
def e2419153105206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419153105206 : Closed e2419153105206 ∧ code e2419153105206 = 11215246127414 := by decide
theorem cert_e2419153105206 : check e2419153105206 [[],[]] .sourceHead = true := by decide
def e2419153105210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419153105210 : Closed e2419153105210 ∧ code e2419153105210 = 11215246127418 := by decide
theorem cert_e2419153105210 : check e2419153105210 [[],[]] .sourceHead = true := by decide
def e2419153105294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2419153105294 : Closed e2419153105294 ∧ code e2419153105294 = 11215246127502 := by decide
theorem cert_e2419153105294 : check e2419153105294 [[],[]] .sourceHead = true := by decide
def e2419153105350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2419153105350 : Closed e2419153105350 ∧ code e2419153105350 = 11215246127558 := by decide
theorem cert_e2419153105350 : check e2419153105350 [[],[]] .sourceHead = true := by decide
def e2419153105686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2419153105686 : Closed e2419153105686 ∧ code e2419153105686 = 11215246127894 := by decide
theorem cert_e2419153105686 : check e2419153105686 [[],[]] .sourceHead = true := by decide
def e2419153105762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2419153105762 : Closed e2419153105762 ∧ code e2419153105762 = 11215246127970 := by decide
theorem cert_e2419153105762 : check e2419153105762 [[],[]] .sourceHead = true := by decide
def e2419153105774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2419153105774 : Closed e2419153105774 ∧ code e2419153105774 = 11215246127982 := by decide
theorem cert_e2419153105774 : check e2419153105774 [[],[]] .sourceHead = true := by decide
def e2419153105782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2419153105782 : Closed e2419153105782 ∧ code e2419153105782 = 11215246127990 := by decide
theorem cert_e2419153105782 : check e2419153105782 [[],[]] .sourceHead = true := by decide
def e2419153105802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419153105802 : Closed e2419153105802 ∧ code e2419153105802 = 11215246128010 := by decide
theorem cert_e2419153105802 : check e2419153105802 [[],[]] .sourceHead = true := by decide
def e2419153105826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419153105826 : Closed e2419153105826 ∧ code e2419153105826 = 11215246128034 := by decide
theorem cert_e2419153105826 : check e2419153105826 [[],[]] .sourceHead = true := by decide
def e2419153105838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2419153105838 : Closed e2419153105838 ∧ code e2419153105838 = 11215246128046 := by decide
theorem cert_e2419153105838 : check e2419153105838 [[],[]] .sourceHead = true := by decide
def e2419153105850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2419153105850 : Closed e2419153105850 ∧ code e2419153105850 = 11215246128058 := by decide
theorem cert_e2419153105850 : check e2419153105850 [[],[]] .sourceHead = true := by decide
def e2419153105878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2419153105878 : Closed e2419153105878 ∧ code e2419153105878 = 11215246128086 := by decide
theorem cert_e2419153105878 : check e2419153105878 [[],[]] .sourceHead = true := by decide
def e2419153105882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2419153105882 : Closed e2419153105882 ∧ code e2419153105882 = 11215246128090 := by decide
theorem cert_e2419153105882 : check e2419153105882 [[],[]] .sourceHead = true := by decide
def e2419153105950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2419153105950 : Closed e2419153105950 ∧ code e2419153105950 = 11215246128158 := by decide
theorem cert_e2419153105950 : check e2419153105950 [[],[]] .sourceHead = true := by decide
def e2419153106146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419153106146 : Closed e2419153106146 ∧ code e2419153106146 = 11215246128354 := by decide
theorem cert_e2419153106146 : check e2419153106146 [[],[]] .sourceHead = true := by decide
def e2419153106158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419153106158 : Closed e2419153106158 ∧ code e2419153106158 = 11215246128366 := by decide
theorem cert_e2419153106158 : check e2419153106158 [[],[]] .sourceHead = true := by decide
def e2419153106166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419153106166 : Closed e2419153106166 ∧ code e2419153106166 = 11215246128374 := by decide
theorem cert_e2419153106166 : check e2419153106166 [[],[]] .sourceHead = true := by decide
def e2419153106446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419153106446 : Closed e2419153106446 ∧ code e2419153106446 = 11215246128654 := by decide
theorem cert_e2419153106446 : check e2419153106446 [[],[]] .sourceHead = true := by decide
def e2419153106530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419153106530 : Closed e2419153106530 ∧ code e2419153106530 = 11215246128738 := by decide
theorem cert_e2419153106530 : check e2419153106530 [[],[]] .sourceHead = true := by decide
def e2419153106542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419153106542 : Closed e2419153106542 ∧ code e2419153106542 = 11215246128750 := by decide
theorem cert_e2419153106542 : check e2419153106542 [[],[]] .sourceHead = true := by decide
def e2419153106554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419153106554 : Closed e2419153106554 ∧ code e2419153106554 = 11215246128762 := by decide
theorem cert_e2419153106554 : check e2419153106554 [[],[]] .sourceHead = true := by decide
def e2419153106742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419153106742 : Closed e2419153106742 ∧ code e2419153106742 = 11215246128950 := by decide
theorem cert_e2419153106742 : check e2419153106742 [[],[]] .sourceHead = true := by decide
def e2419153106746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419153106746 : Closed e2419153106746 ∧ code e2419153106746 = 11215246128954 := by decide
theorem cert_e2419153106746 : check e2419153106746 [[],[]] .sourceHead = true := by decide
def e2419153111918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419153111918 : Closed e2419153111918 ∧ code e2419153111918 = 11215246134126 := by decide
theorem cert_e2419153111918 : check e2419153111918 [[],[]] .smaller = true := by decide
def e2419153111926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419153111926 : Closed e2419153111926 ∧ code e2419153111926 = 11215246134134 := by decide
theorem cert_e2419153111926 : check e2419153111926 [[],[]] .smaller = true := by decide
def e2419153111982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419153111982 : Closed e2419153111982 ∧ code e2419153111982 = 11215246134190 := by decide
theorem cert_e2419153111982 : check e2419153111982 [[],[]] .smaller = true := by decide
def e2419153111994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419153111994 : Closed e2419153111994 ∧ code e2419153111994 = 11215246134202 := by decide
theorem cert_e2419153111994 : check e2419153111994 [[],[]] .smaller = true := by decide
def e2419153112022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419153112022 : Closed e2419153112022 ∧ code e2419153112022 = 11215246134230 := by decide
theorem cert_e2419153112022 : check e2419153112022 [[],[]] .smaller = true := by decide
def e2419153112026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419153112026 : Closed e2419153112026 ∧ code e2419153112026 = 11215246134234 := by decide
theorem cert_e2419153112026 : check e2419153112026 [[],[]] .smaller = true := by decide
def e2419153112302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419153112302 : Closed e2419153112302 ∧ code e2419153112302 = 11215246134510 := by decide
theorem cert_e2419153112302 : check e2419153112302 [[],[]] .smaller = true := by decide
def e2419153112310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419153112310 : Closed e2419153112310 ∧ code e2419153112310 = 11215246134518 := by decide
theorem cert_e2419153112310 : check e2419153112310 [[],[]] .smaller = true := by decide
def e2419153112686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419153112686 : Closed e2419153112686 ∧ code e2419153112686 = 11215246134894 := by decide
theorem cert_e2419153112686 : check e2419153112686 [[],[]] .smaller = true := by decide
def e2419153112698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419153112698 : Closed e2419153112698 ∧ code e2419153112698 = 11215246134906 := by decide
theorem cert_e2419153112698 : check e2419153112698 [[],[]] .smaller = true := by decide
def e2419153112886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419153112886 : Closed e2419153112886 ∧ code e2419153112886 = 11215246135094 := by decide
theorem cert_e2419153112886 : check e2419153112886 [[],[]] .smaller = true := by decide
def e2419153112890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419153112890 : Closed e2419153112890 ∧ code e2419153112890 = 11215246135098 := by decide
theorem cert_e2419153112890 : check e2419153112890 [[],[]] .smaller = true := by decide
def e2419153120814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2419153120814 : Closed e2419153120814 ∧ code e2419153120814 = 11215246143022 := by decide
theorem cert_e2419153120814 : check e2419153120814 [[],[]] .sourceHead = true := by decide
def e2419153120994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2419153120994 : Closed e2419153120994 ∧ code e2419153120994 = 11215246143202 := by decide
theorem cert_e2419153120994 : check e2419153120994 [[],[]] .sourceHead = true := by decide
def e2419153121006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2419153121006 : Closed e2419153121006 ∧ code e2419153121006 = 11215246143214 := by decide
theorem cert_e2419153121006 : check e2419153121006 [[],[]] .sourceHead = true := by decide
def e2419153121046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2419153121046 : Closed e2419153121046 ∧ code e2419153121046 = 11215246143254 := by decide
theorem cert_e2419153121046 : check e2419153121046 [[],[]] .sourceHead = true := by decide
def e2419153121122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2419153121122 : Closed e2419153121122 ∧ code e2419153121122 = 11215246143330 := by decide
theorem cert_e2419153121122 : check e2419153121122 [[],[]] .sourceHead = true := by decide
def e2419153121134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2419153121134 : Closed e2419153121134 ∧ code e2419153121134 = 11215246143342 := by decide
theorem cert_e2419153121134 : check e2419153121134 [[],[]] .sourceHead = true := by decide
def e2419153121142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2419153121142 : Closed e2419153121142 ∧ code e2419153121142 = 11215246143350 := by decide
theorem cert_e2419153121142 : check e2419153121142 [[],[]] .sourceHead = true := by decide
def e2419153123390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2419153123390 : Closed e2419153123390 ∧ code e2419153123390 = 11215246145598 := by decide
theorem cert_e2419153123390 : check e2419153123390 [[],[]] .sourceHead = true := by decide
def e2419153123810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2419153123810 : Closed e2419153123810 ∧ code e2419153123810 = 11215246146018 := by decide
theorem cert_e2419153123810 : check e2419153123810 [[],[]] .sourceHead = true := by decide
def e2419153123822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419153123822 : Closed e2419153123822 ∧ code e2419153123822 = 11215246146030 := by decide
theorem cert_e2419153123822 : check e2419153123822 [[],[]] .sourceHead = true := by decide
def e2419153124382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2419153124382 : Closed e2419153124382 ∧ code e2419153124382 = 11215246146590 := by decide
theorem cert_e2419153124382 : check e2419153124382 [[],[]] .sourceHead = true := by decide
def e2419153124578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2419153124578 : Closed e2419153124578 ∧ code e2419153124578 = 11215246146786 := by decide
theorem cert_e2419153124578 : check e2419153124578 [[],[]] .sourceHead = true := by decide
def e2419153124590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419153124590 : Closed e2419153124590 ∧ code e2419153124590 = 11215246146798 := by decide
theorem cert_e2419153124590 : check e2419153124590 [[],[]] .sourceHead = true := by decide
def e2419153124598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419153124598 : Closed e2419153124598 ∧ code e2419153124598 = 11215246146806 := by decide
theorem cert_e2419153124598 : check e2419153124598 [[],[]] .sourceHead = true := by decide
def e2419153147438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2419153147438 : Closed e2419153147438 ∧ code e2419153147438 = 11215246169646 := by decide
theorem cert_e2419153147438 : check e2419153147438 [[],[]] .sourceHead = true := by decide
def e2419153147618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2419153147618 : Closed e2419153147618 ∧ code e2419153147618 = 11215246169826 := by decide
theorem cert_e2419153147618 : check e2419153147618 [[],[]] .sourceHead = true := by decide
def e2419153147630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2419153147630 : Closed e2419153147630 ∧ code e2419153147630 = 11215246169838 := by decide
theorem cert_e2419153147630 : check e2419153147630 [[],[]] .sourceHead = true := by decide
def e2419153147786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419153147786 : Closed e2419153147786 ∧ code e2419153147786 = 11215246169994 := by decide
theorem cert_e2419153147786 : check e2419153147786 [[],[]] .sourceHead = true := by decide
def e2419153147810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419153147810 : Closed e2419153147810 ∧ code e2419153147810 = 11215246170018 := by decide
theorem cert_e2419153147810 : check e2419153147810 [[],[]] .sourceHead = true := by decide
def e2419153147822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2419153147822 : Closed e2419153147822 ∧ code e2419153147822 = 11215246170030 := by decide
theorem cert_e2419153147822 : check e2419153147822 [[],[]] .sourceHead = true := by decide
def e2419153147834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2419153147834 : Closed e2419153147834 ∧ code e2419153147834 = 11215246170042 := by decide
theorem cert_e2419153147834 : check e2419153147834 [[],[]] .sourceHead = true := by decide
def e2419153147966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2419153147966 : Closed e2419153147966 ∧ code e2419153147966 = 11215246170174 := by decide
theorem cert_e2419153147966 : check e2419153147966 [[],[]] .sourceHead = true := by decide
def e2419153148386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2419153148386 : Closed e2419153148386 ∧ code e2419153148386 = 11215246170594 := by decide
theorem cert_e2419153148386 : check e2419153148386 [[],[]] .sourceHead = true := by decide
def e2419153148398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419153148398 : Closed e2419153148398 ∧ code e2419153148398 = 11215246170606 := by decide
theorem cert_e2419153148398 : check e2419153148398 [[],[]] .sourceHead = true := by decide
def e2419153149454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2419153149454 : Closed e2419153149454 ∧ code e2419153149454 = 11215246171662 := by decide
theorem cert_e2419153149454 : check e2419153149454 [[],[]] .sourceHead = true := by decide
def e2419153149538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419153149538 : Closed e2419153149538 ∧ code e2419153149538 = 11215246171746 := by decide
theorem cert_e2419153149538 : check e2419153149538 [[],[]] .sourceHead = true := by decide
def e2419153149550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419153149550 : Closed e2419153149550 ∧ code e2419153149550 = 11215246171758 := by decide
theorem cert_e2419153149550 : check e2419153149550 [[],[]] .sourceHead = true := by decide
def e2419153149562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419153149562 : Closed e2419153149562 ∧ code e2419153149562 = 11215246171770 := by decide
theorem cert_e2419153149562 : check e2419153149562 [[],[]] .sourceHead = true := by decide
def e2419153160982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2419153160982 : Closed e2419153160982 ∧ code e2419153160982 = 11215246183190 := by decide
theorem cert_e2419153160982 : check e2419153160982 [[],[]] .sourceHead = true := by decide
def e2419153161058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2419153161058 : Closed e2419153161058 ∧ code e2419153161058 = 11215246183266 := by decide
theorem cert_e2419153161058 : check e2419153161058 [[],[]] .sourceHead = true := by decide
def e2419153161070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419153161070 : Closed e2419153161070 ∧ code e2419153161070 = 11215246183278 := by decide
theorem cert_e2419153161070 : check e2419153161070 [[],[]] .sourceHead = true := by decide
def e2419153161078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419153161078 : Closed e2419153161078 ∧ code e2419153161078 = 11215246183286 := by decide
theorem cert_e2419153161078 : check e2419153161078 [[],[]] .sourceHead = true := by decide
def e2419153161098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419153161098 : Closed e2419153161098 ∧ code e2419153161098 = 11215246183306 := by decide
theorem cert_e2419153161098 : check e2419153161098 [[],[]] .sourceHead = true := by decide
def e2419153161122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419153161122 : Closed e2419153161122 ∧ code e2419153161122 = 11215246183330 := by decide
theorem cert_e2419153161122 : check e2419153161122 [[],[]] .sourceHead = true := by decide
def e2419153161134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419153161134 : Closed e2419153161134 ∧ code e2419153161134 = 11215246183342 := by decide
theorem cert_e2419153161134 : check e2419153161134 [[],[]] .sourceHead = true := by decide
def e2419153161146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419153161146 : Closed e2419153161146 ∧ code e2419153161146 = 11215246183354 := by decide
theorem cert_e2419153161146 : check e2419153161146 [[],[]] .sourceHead = true := by decide
def e2419153161174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419153161174 : Closed e2419153161174 ∧ code e2419153161174 = 11215246183382 := by decide
theorem cert_e2419153161174 : check e2419153161174 [[],[]] .sourceHead = true := by decide
def e2419153161178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419153161178 : Closed e2419153161178 ∧ code e2419153161178 = 11215246183386 := by decide
theorem cert_e2419153161178 : check e2419153161178 [[],[]] .sourceHead = true := by decide
def e2419153161246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2419153161246 : Closed e2419153161246 ∧ code e2419153161246 = 11215246183454 := by decide
theorem cert_e2419153161246 : check e2419153161246 [[],[]] .sourceHead = true := by decide
def e2419153161442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2419153161442 : Closed e2419153161442 ∧ code e2419153161442 = 11215246183650 := by decide
theorem cert_e2419153161442 : check e2419153161442 [[],[]] .sourceHead = true := by decide
def e2419153161454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419153161454 : Closed e2419153161454 ∧ code e2419153161454 = 11215246183662 := by decide
theorem cert_e2419153161454 : check e2419153161454 [[],[]] .sourceHead = true := by decide
def e2419153161462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419153161462 : Closed e2419153161462 ∧ code e2419153161462 = 11215246183670 := by decide
theorem cert_e2419153161462 : check e2419153161462 [[],[]] .sourceHead = true := by decide
def e2419153161742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2419153161742 : Closed e2419153161742 ∧ code e2419153161742 = 11215246183950 := by decide
theorem cert_e2419153161742 : check e2419153161742 [[],[]] .sourceHead = true := by decide
def e2419153161826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419153161826 : Closed e2419153161826 ∧ code e2419153161826 = 11215246184034 := by decide
theorem cert_e2419153161826 : check e2419153161826 [[],[]] .sourceHead = true := by decide
def e2419153161838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419153161838 : Closed e2419153161838 ∧ code e2419153161838 = 11215246184046 := by decide
theorem cert_e2419153161838 : check e2419153161838 [[],[]] .sourceHead = true := by decide
def e2419153161850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419153161850 : Closed e2419153161850 ∧ code e2419153161850 = 11215246184058 := by decide
theorem cert_e2419153161850 : check e2419153161850 [[],[]] .sourceHead = true := by decide
def e2419153162038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419153162038 : Closed e2419153162038 ∧ code e2419153162038 = 11215246184246 := by decide
theorem cert_e2419153162038 : check e2419153162038 [[],[]] .sourceHead = true := by decide
def e2419153162042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419153162042 : Closed e2419153162042 ∧ code e2419153162042 = 11215246184250 := by decide
theorem cert_e2419153162042 : check e2419153162042 [[],[]] .sourceHead = true := by decide
def e2419153701742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419153701742 : Closed e2419153701742 ∧ code e2419153701742 = 11215246723950 := by decide
theorem cert_e2419153701742 : check e2419153701742 [[],[]] .smaller = true := by decide
def e2419153701750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419153701750 : Closed e2419153701750 ∧ code e2419153701750 = 11215246723958 := by decide
theorem cert_e2419153701750 : check e2419153701750 [[],[]] .smaller = true := by decide
def e2419153701806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419153701806 : Closed e2419153701806 ∧ code e2419153701806 = 11215246724014 := by decide
theorem cert_e2419153701806 : check e2419153701806 [[],[]] .smaller = true := by decide
def e2419153701818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419153701818 : Closed e2419153701818 ∧ code e2419153701818 = 11215246724026 := by decide
theorem cert_e2419153701818 : check e2419153701818 [[],[]] .smaller = true := by decide
def e2419153701846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419153701846 : Closed e2419153701846 ∧ code e2419153701846 = 11215246724054 := by decide
theorem cert_e2419153701846 : check e2419153701846 [[],[]] .smaller = true := by decide
def e2419153701850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419153701850 : Closed e2419153701850 ∧ code e2419153701850 = 11215246724058 := by decide
theorem cert_e2419153701850 : check e2419153701850 [[],[]] .smaller = true := by decide
def e2419153702126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419153702126 : Closed e2419153702126 ∧ code e2419153702126 = 11215246724334 := by decide
theorem cert_e2419153702126 : check e2419153702126 [[],[]] .smaller = true := by decide
def e2419153702134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419153702134 : Closed e2419153702134 ∧ code e2419153702134 = 11215246724342 := by decide
theorem cert_e2419153702134 : check e2419153702134 [[],[]] .smaller = true := by decide
def e2419153702510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419153702510 : Closed e2419153702510 ∧ code e2419153702510 = 11215246724718 := by decide
theorem cert_e2419153702510 : check e2419153702510 [[],[]] .smaller = true := by decide
def e2419153702522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419153702522 : Closed e2419153702522 ∧ code e2419153702522 = 11215246724730 := by decide
theorem cert_e2419153702522 : check e2419153702522 [[],[]] .smaller = true := by decide
def e2419153702710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419153702710 : Closed e2419153702710 ∧ code e2419153702710 = 11215246724918 := by decide
theorem cert_e2419153702710 : check e2419153702710 [[],[]] .smaller = true := by decide
def e2419153702714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419153702714 : Closed e2419153702714 ∧ code e2419153702714 = 11215246724922 := by decide
theorem cert_e2419153702714 : check e2419153702714 [[],[]] .smaller = true := by decide
def e2419155033566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2419155033566 : Closed e2419155033566 ∧ code e2419155033566 = 11215248055774 := by decide
theorem cert_e2419155033566 : check e2419155033566 [[],[],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e2419155033582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2419155033582 : Closed e2419155033582 ∧ code e2419155033582 = 11215248055790 := by decide
private def t_e2419155033582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem cert_e2419155033582 : ¬ IsSelfInterpreter e2419155033582 :=
  wSource (t := t_e2419155033582) (replay_sound (ps := []) (t := e2419155033582) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419155033582
