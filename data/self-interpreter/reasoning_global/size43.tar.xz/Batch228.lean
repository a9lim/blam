import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393371259834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2393371259834 : Closed e2393371259834 ∧ code e2393371259834 = 11189464282042 := by decide
theorem cert_e2393371259834 : check e2393371259834 [[],[.left],[]] .chain = true := by decide
def e2393371259862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2393371259862 : Closed e2393371259862 ∧ code e2393371259862 = 11189464282070 := by decide
theorem cert_e2393371259862 : check e2393371259862 [[],[.left],[]] .chain = true := by decide
def e2393371259866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2393371259866 : Closed e2393371259866 ∧ code e2393371259866 = 11189464282074 := by decide
theorem cert_e2393371259866 : check e2393371259866 [[],[.left],[]] .chain = true := by decide
def e2393371260142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2393371260142 : Closed e2393371260142 ∧ code e2393371260142 = 11189464282350 := by decide
theorem cert_e2393371260142 : check e2393371260142 [[],[.left],[]] .chain = true := by decide
def e2393371260150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2393371260150 : Closed e2393371260150 ∧ code e2393371260150 = 11189464282358 := by decide
theorem cert_e2393371260150 : check e2393371260150 [[],[.left],[]] .chain = true := by decide
def e2393371260478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 4))))))))
theorem wire_e2393371260478 : Closed e2393371260478 ∧ code e2393371260478 = 11189464282686 := by decide
theorem cert_e2393371260478 : check e2393371260478 [[],[.left],[]] .chain = true := by decide
def e2393371260526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2393371260526 : Closed e2393371260526 ∧ code e2393371260526 = 11189464282734 := by decide
theorem cert_e2393371260526 : check e2393371260526 [[],[.left],[]] .chain = true := by decide
def e2393371260538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2393371260538 : Closed e2393371260538 ∧ code e2393371260538 = 11189464282746 := by decide
theorem cert_e2393371260538 : check e2393371260538 [[],[.left],[]] .chain = true := by decide
def e2393371260726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371260726 : Closed e2393371260726 ∧ code e2393371260726 = 11189464282934 := by decide
theorem cert_e2393371260726 : check e2393371260726 [[],[.left],[]] .chain = true := by decide
def e2393371260730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371260730 : Closed e2393371260730 ∧ code e2393371260730 = 11189464282938 := by decide
theorem cert_e2393371260730 : check e2393371260730 [[],[.left],[]] .chain = true := by decide
def e2393371260814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 2))))))))
theorem wire_e2393371260814 : Closed e2393371260814 ∧ code e2393371260814 = 11189464283022 := by decide
theorem cert_e2393371260814 : check e2393371260814 [[],[.left],[]] .chain = true := by decide
def e2393371261150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2393371261150 : Closed e2393371261150 ∧ code e2393371261150 = 11189464283358 := by decide
theorem cert_e2393371261150 : check e2393371261150 [[],[.left],[]] .chain = true := by decide
def e2393371261166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2393371261166 : Closed e2393371261166 ∧ code e2393371261166 = 11189464283374 := by decide
theorem cert_e2393371261166 : check e2393371261166 [[],[.left],[]] .chain = true := by decide
def e2393371261174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2393371261174 : Closed e2393371261174 ∧ code e2393371261174 = 11189464283382 := by decide
theorem cert_e2393371261174 : check e2393371261174 [[],[.left],[]] .chain = true := by decide
def e2393371261178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2393371261178 : Closed e2393371261178 ∧ code e2393371261178 = 11189464283386 := by decide
theorem cert_e2393371261178 : check e2393371261178 [[],[.left],[]] .chain = true := by decide
def e2393371261358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2393371261358 : Closed e2393371261358 ∧ code e2393371261358 = 11189464283566 := by decide
theorem cert_e2393371261358 : check e2393371261358 [[],[.left],[]] .chain = true := by decide
def e2393371261370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2393371261370 : Closed e2393371261370 ∧ code e2393371261370 = 11189464283578 := by decide
theorem cert_e2393371261370 : check e2393371261370 [[],[.left],[]] .chain = true := by decide
def e2393371261418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2393371261418 : Closed e2393371261418 ∧ code e2393371261418 = 11189464283626 := by decide
theorem cert_e2393371261418 : check e2393371261418 [[],[.left],[]] .chain = true := by decide
def e2393371261502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2393371261502 : Closed e2393371261502 ∧ code e2393371261502 = 11189464283710 := by decide
theorem cert_e2393371261502 : check e2393371261502 [[],[.left],[]] .chain = true := by decide
def e2393371261550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2393371261550 : Closed e2393371261550 ∧ code e2393371261550 = 11189464283758 := by decide
theorem cert_e2393371261550 : check e2393371261550 [[],[.left],[]] .chain = true := by decide
def e2393371261562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2393371261562 : Closed e2393371261562 ∧ code e2393371261562 = 11189464283770 := by decide
theorem cert_e2393371261562 : check e2393371261562 [[],[.left],[]] .chain = true := by decide
def e2393371261726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2393371261726 : Closed e2393371261726 ∧ code e2393371261726 = 11189464283934 := by decide
theorem cert_e2393371261726 : check e2393371261726 [[],[.left],[]] .chain = true := by decide
def e2393371261838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2393371261838 : Closed e2393371261838 ∧ code e2393371261838 = 11189464284046 := by decide
theorem cert_e2393371261838 : check e2393371261838 [[],[.left],[]] .chain = true := by decide
def e2393371261850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371261850 : Closed e2393371261850 ∧ code e2393371261850 = 11189464284058 := by decide
theorem cert_e2393371261850 : check e2393371261850 [[],[.left],[]] .chain = true := by decide
def e2393371261894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2393371261894 : Closed e2393371261894 ∧ code e2393371261894 = 11189464284102 := by decide
theorem cert_e2393371261894 : check e2393371261894 [[],[.left],[]] .chain = true := by decide
def e2393371261918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 3)))))))
theorem wire_e2393371261918 : Closed e2393371261918 ∧ code e2393371261918 = 11189464284126 := by decide
theorem cert_e2393371261918 : check e2393371261918 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2393371262070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2393371262070 : Closed e2393371262070 ∧ code e2393371262070 = 11189464284278 := by decide
theorem cert_e2393371262070 : check e2393371262070 [[],[.left],[]] .chain = true := by decide
def e2393371262166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2393371262166 : Closed e2393371262166 ∧ code e2393371262166 = 11189464284374 := by decide
theorem cert_e2393371262166 : check e2393371262166 [[],[.left],[]] .chain = true := by decide
def e2393371262170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2393371262170 : Closed e2393371262170 ∧ code e2393371262170 = 11189464284378 := by decide
theorem cert_e2393371262170 : check e2393371262170 [[],[.left],[]] .chain = true := by decide
def e2393371262186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2393371262186 : Closed e2393371262186 ∧ code e2393371262186 = 11189464284394 := by decide
theorem cert_e2393371262186 : check e2393371262186 [[],[.left],[]] .chain = true := by decide
def e2393371262262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371262262 : Closed e2393371262262 ∧ code e2393371262262 = 11189464284470 := by decide
theorem cert_e2393371262262 : check e2393371262262 [[],[.left],[]] .chain = true := by decide
def e2393371262266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371262266 : Closed e2393371262266 ∧ code e2393371262266 = 11189464284474 := by decide
theorem cert_e2393371262266 : check e2393371262266 [[],[.left],[]] .chain = true := by decide
def e2393371262350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2393371262350 : Closed e2393371262350 ∧ code e2393371262350 = 11189464284558 := by decide
theorem cert_e2393371262350 : check e2393371262350 [[],[.left],[]] .chain = true := by decide
def e2393371262362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371262362 : Closed e2393371262362 ∧ code e2393371262362 = 11189464284570 := by decide
theorem cert_e2393371262362 : check e2393371262362 [[],[.left],[]] .chain = true := by decide
def e2393371262430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 3)))))))
theorem wire_e2393371262430 : Closed e2393371262430 ∧ code e2393371262430 = 11189464284638 := by decide
theorem cert_e2393371262430 : check e2393371262430 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2393371262446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 2)))))))
theorem wire_e2393371262446 : Closed e2393371262446 ∧ code e2393371262446 = 11189464284654 := by decide
theorem cert_e2393371262446 : check e2393371262446 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2393371262518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2393371262518 : Closed e2393371262518 ∧ code e2393371262518 = 11189464284726 := by decide
theorem cert_e2393371262518 : check e2393371262518 [[],[.left],[]] .chain = true := by decide
def e2393371262522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2393371262522 : Closed e2393371262522 ∧ code e2393371262522 = 11189464284730 := by decide
theorem cert_e2393371262522 : check e2393371262522 [[],[.left],[]] .chain = true := by decide
def e2393371262606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2393371262606 : Closed e2393371262606 ∧ code e2393371262606 = 11189464284814 := by decide
theorem cert_e2393371262606 : check e2393371262606 [[],[.left],[]] .chain = true := by decide
def e2393371262662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2393371262662 : Closed e2393371262662 ∧ code e2393371262662 = 11189464284870 := by decide
theorem cert_e2393371262662 : check e2393371262662 [[],[.left],[]] .chain = true := by decide
def e2393371262686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 3)))))))
theorem wire_e2393371262686 : Closed e2393371262686 ∧ code e2393371262686 = 11189464284894 := by decide
theorem cert_e2393371262686 : check e2393371262686 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2393371262702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 2)))))))
theorem wire_e2393371262702 : Closed e2393371262702 ∧ code e2393371262702 = 11189464284910 := by decide
theorem cert_e2393371262702 : check e2393371262702 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2393371262710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 1)))))))
theorem wire_e2393371262710 : Closed e2393371262710 ∧ code e2393371262710 = 11189464284918 := by decide
theorem cert_e2393371262710 : checkPay e2393371262710 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2393371263966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2393371263966 : Closed e2393371263966 ∧ code e2393371263966 = 11189464286174 := by decide
theorem cert_e2393371263966 : check e2393371263966 [[],[.left],[]] .chain = true := by decide
def e2393371263982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2393371263982 : Closed e2393371263982 ∧ code e2393371263982 = 11189464286190 := by decide
theorem cert_e2393371263982 : check e2393371263982 [[],[.left],[]] .chain = true := by decide
def e2393371265902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393371265902 : Closed e2393371265902 ∧ code e2393371265902 = 11189464288110 := by decide
theorem cert_e2393371265902 : check e2393371265902 [[],[.left],[]] .chain = true := by decide
def e2393371265910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393371265910 : Closed e2393371265910 ∧ code e2393371265910 = 11189464288118 := by decide
theorem cert_e2393371265910 : check e2393371265910 [[],[.left],[]] .chain = true := by decide
def e2393371265966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393371265966 : Closed e2393371265966 ∧ code e2393371265966 = 11189464288174 := by decide
theorem cert_e2393371265966 : check e2393371265966 [[],[.left],[]] .chain = true := by decide
def e2393371265978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393371265978 : Closed e2393371265978 ∧ code e2393371265978 = 11189464288186 := by decide
theorem cert_e2393371265978 : check e2393371265978 [[],[.left],[]] .chain = true := by decide
def e2393371266006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393371266006 : Closed e2393371266006 ∧ code e2393371266006 = 11189464288214 := by decide
theorem cert_e2393371266006 : check e2393371266006 [[],[.left],[]] .chain = true := by decide
def e2393371266010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393371266010 : Closed e2393371266010 ∧ code e2393371266010 = 11189464288218 := by decide
theorem cert_e2393371266010 : check e2393371266010 [[],[.left],[]] .chain = true := by decide
def e2393371266286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393371266286 : Closed e2393371266286 ∧ code e2393371266286 = 11189464288494 := by decide
theorem cert_e2393371266286 : check e2393371266286 [[],[.left],[]] .chain = true := by decide
def e2393371266294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393371266294 : Closed e2393371266294 ∧ code e2393371266294 = 11189464288502 := by decide
theorem cert_e2393371266294 : check e2393371266294 [[],[.left],[]] .chain = true := by decide
def e2393371266622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2393371266622 : Closed e2393371266622 ∧ code e2393371266622 = 11189464288830 := by decide
theorem cert_e2393371266622 : check e2393371266622 [[],[.left],[]] .chain = true := by decide
def e2393371266670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393371266670 : Closed e2393371266670 ∧ code e2393371266670 = 11189464288878 := by decide
theorem cert_e2393371266670 : check e2393371266670 [[],[.left],[]] .chain = true := by decide
def e2393371266682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393371266682 : Closed e2393371266682 ∧ code e2393371266682 = 11189464288890 := by decide
theorem cert_e2393371266682 : check e2393371266682 [[],[.left],[]] .chain = true := by decide
def e2393371266870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393371266870 : Closed e2393371266870 ∧ code e2393371266870 = 11189464289078 := by decide
theorem cert_e2393371266870 : check e2393371266870 [[],[.left],[]] .chain = true := by decide
def e2393371266874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393371266874 : Closed e2393371266874 ∧ code e2393371266874 = 11189464289082 := by decide
theorem cert_e2393371266874 : check e2393371266874 [[],[.left],[]] .chain = true := by decide
def e2393371266958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2393371266958 : Closed e2393371266958 ∧ code e2393371266958 = 11189464289166 := by decide
theorem cert_e2393371266958 : check e2393371266958 [[],[.left],[]] .chain = true := by decide
def e2393371271646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2393371271646 : Closed e2393371271646 ∧ code e2393371271646 = 11189464293854 := by decide
theorem cert_e2393371271646 : check e2393371271646 [[],[.left],[]] .chain = true := by decide
def e2393371271670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2393371271670 : Closed e2393371271670 ∧ code e2393371271670 = 11189464293878 := by decide
theorem cert_e2393371271670 : check e2393371271670 [[],[.left],[]] .chain = true := by decide
def e2393371272622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2393371272622 : Closed e2393371272622 ∧ code e2393371272622 = 11189464294830 := by decide
theorem cert_e2393371272622 : check e2393371272622 [[],[.left],[]] .chain = true := by decide
def e2393371272634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2393371272634 : Closed e2393371272634 ∧ code e2393371272634 = 11189464294842 := by decide
theorem cert_e2393371272634 : check e2393371272634 [[],[.left],[]] .chain = true := by decide
def e2393371272682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2393371272682 : Closed e2393371272682 ∧ code e2393371272682 = 11189464294890 := by decide
theorem cert_e2393371272682 : check e2393371272682 [[],[.left],[]] .chain = true := by decide
def e2393371272766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2393371272766 : Closed e2393371272766 ∧ code e2393371272766 = 11189464294974 := by decide
theorem cert_e2393371272766 : check e2393371272766 [[],[.left],[]] .chain = true := by decide
def e2393371272814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393371272814 : Closed e2393371272814 ∧ code e2393371272814 = 11189464295022 := by decide
theorem cert_e2393371272814 : check e2393371272814 [[],[.left],[]] .chain = true := by decide
def e2393371272826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393371272826 : Closed e2393371272826 ∧ code e2393371272826 = 11189464295034 := by decide
theorem cert_e2393371272826 : check e2393371272826 [[],[.left],[]] .chain = true := by decide
def e2393371272990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2393371272990 : Closed e2393371272990 ∧ code e2393371272990 = 11189464295198 := by decide
theorem cert_e2393371272990 : check e2393371272990 [[],[.left],[]] .chain = true := by decide
def e2393371273102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2393371273102 : Closed e2393371273102 ∧ code e2393371273102 = 11189464295310 := by decide
theorem cert_e2393371273102 : check e2393371273102 [[],[.left],[]] .chain = true := by decide
def e2393371273114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371273114 : Closed e2393371273114 ∧ code e2393371273114 = 11189464295322 := by decide
theorem cert_e2393371273114 : check e2393371273114 [[],[.left],[]] .chain = true := by decide
def e2393371273158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2393371273158 : Closed e2393371273158 ∧ code e2393371273158 = 11189464295366 := by decide
theorem cert_e2393371273158 : check e2393371273158 [[],[.left],[]] .chain = true := by decide
def e2393371273182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 3))))))))
theorem wire_e2393371273182 : Closed e2393371273182 ∧ code e2393371273182 = 11189464295390 := by decide
theorem cert_e2393371273182 : check e2393371273182 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2393371275502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2393371275502 : Closed e2393371275502 ∧ code e2393371275502 = 11189464297710 := by decide
theorem cert_e2393371275502 : check e2393371275502 [[],[.left],[]] .chain = true := by decide
def e2393371275510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2393371275510 : Closed e2393371275510 ∧ code e2393371275510 = 11189464297718 := by decide
theorem cert_e2393371275510 : check e2393371275510 [[],[.left],[]] .chain = true := by decide
def e2393371275990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2393371275990 : Closed e2393371275990 ∧ code e2393371275990 = 11189464298198 := by decide
theorem cert_e2393371275990 : check e2393371275990 [[],[.left],[]] .chain = true := by decide
def e2393371275994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2393371275994 : Closed e2393371275994 ∧ code e2393371275994 = 11189464298202 := by decide
theorem cert_e2393371275994 : check e2393371275994 [[],[.left],[]] .chain = true := by decide
def e2393371276010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2393371276010 : Closed e2393371276010 ∧ code e2393371276010 = 11189464298218 := by decide
theorem cert_e2393371276010 : check e2393371276010 [[],[.left],[]] .chain = true := by decide
def e2393371276086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393371276086 : Closed e2393371276086 ∧ code e2393371276086 = 11189464298294 := by decide
theorem cert_e2393371276086 : check e2393371276086 [[],[.left],[]] .chain = true := by decide
def e2393371276090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393371276090 : Closed e2393371276090 ∧ code e2393371276090 = 11189464298298 := by decide
theorem cert_e2393371276090 : check e2393371276090 [[],[.left],[]] .chain = true := by decide
def e2393371276174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2393371276174 : Closed e2393371276174 ∧ code e2393371276174 = 11189464298382 := by decide
theorem cert_e2393371276174 : check e2393371276174 [[],[.left],[]] .chain = true := by decide
def e2393371276186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371276186 : Closed e2393371276186 ∧ code e2393371276186 = 11189464298394 := by decide
theorem cert_e2393371276186 : check e2393371276186 [[],[.left],[]] .chain = true := by decide
def e2393371276254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 3))))))))
theorem wire_e2393371276254 : Closed e2393371276254 ∧ code e2393371276254 = 11189464298462 := by decide
theorem cert_e2393371276254 : check e2393371276254 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371276270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 2))))))))
theorem wire_e2393371276270 : Closed e2393371276270 ∧ code e2393371276270 = 11189464298478 := by decide
theorem cert_e2393371276270 : check e2393371276270 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371277710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2393371277710 : Closed e2393371277710 ∧ code e2393371277710 = 11189464299918 := by decide
theorem cert_e2393371277710 : check e2393371277710 [[],[.left],[]] .chain = true := by decide
def e2393371277766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2393371277766 : Closed e2393371277766 ∧ code e2393371277766 = 11189464299974 := by decide
theorem cert_e2393371277766 : check e2393371277766 [[],[.left],[]] .chain = true := by decide
def e2393371277790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 3))))))))
theorem wire_e2393371277790 : Closed e2393371277790 ∧ code e2393371277790 = 11189464299998 := by decide
theorem cert_e2393371277790 : check e2393371277790 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371277806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 2))))))))
theorem wire_e2393371277806 : Closed e2393371277806 ∧ code e2393371277806 = 11189464300014 := by decide
theorem cert_e2393371277806 : check e2393371277806 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371277814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 1))))))))
theorem wire_e2393371277814 : Closed e2393371277814 ∧ code e2393371277814 = 11189464300022 := by decide
theorem cert_e2393371277814 : check e2393371277814 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393371281262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e2393371281262 : Closed e2393371281262 ∧ code e2393371281262 = 11189464303470 := by decide
theorem cert_e2393371281262 : check e2393371281262 [[],[.left],[]] .chain = true := by decide
def e2393371281274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2393371281274 : Closed e2393371281274 ∧ code e2393371281274 = 11189464303482 := by decide
theorem cert_e2393371281274 : check e2393371281274 [[],[.left],[]] .chain = true := by decide
def e2393371281370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2393371281370 : Closed e2393371281370 ∧ code e2393371281370 = 11189464303578 := by decide
theorem cert_e2393371281370 : check e2393371281370 [[],[.left],[]] .chain = true := by decide
def e2393371282654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2393371282654 : Closed e2393371282654 ∧ code e2393371282654 = 11189464304862 := by decide
theorem cert_e2393371282654 : check e2393371282654 [[],[.left],[]] .chain = true := by decide
def e2393371282670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2393371282670 : Closed e2393371282670 ∧ code e2393371282670 = 11189464304878 := by decide
theorem cert_e2393371282670 : check e2393371282670 [[],[.left],[]] .chain = true := by decide
def e2393371282678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2393371282678 : Closed e2393371282678 ∧ code e2393371282678 = 11189464304886 := by decide
theorem cert_e2393371282678 : check e2393371282678 [[],[.left],[]] .chain = true := by decide
def e2393371282682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2393371282682 : Closed e2393371282682 ∧ code e2393371282682 = 11189464304890 := by decide
theorem cert_e2393371282682 : check e2393371282682 [[],[.left],[]] .chain = true := by decide
def e2393371283054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2393371283054 : Closed e2393371283054 ∧ code e2393371283054 = 11189464305262 := by decide
theorem cert_e2393371283054 : check e2393371283054 [[],[.left],[]] .chain = true := by decide
def e2393371283066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2393371283066 : Closed e2393371283066 ∧ code e2393371283066 = 11189464305274 := by decide
theorem cert_e2393371283066 : check e2393371283066 [[],[.left],[]] .chain = true := by decide
def e2393371283254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371283254 : Closed e2393371283254 ∧ code e2393371283254 = 11189464305462 := by decide
theorem cert_e2393371283254 : check e2393371283254 [[],[.left],[]] .chain = true := by decide
def e2393371283258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371283258 : Closed e2393371283258 ∧ code e2393371283258 = 11189464305466 := by decide
theorem cert_e2393371283258 : check e2393371283258 [[],[.left],[]] .chain = true := by decide
def e2393371283354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371283354 : Closed e2393371283354 ∧ code e2393371283354 = 11189464305562 := by decide
theorem cert_e2393371283354 : check e2393371283354 [[],[.left],[]] .chain = true := by decide
def e2393371285166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2393371285166 : Closed e2393371285166 ∧ code e2393371285166 = 11189464307374 := by decide
theorem cert_e2393371285166 : check e2393371285166 [[],[.left],[]] .chain = true := by decide
def e2393371285178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2393371285178 : Closed e2393371285178 ∧ code e2393371285178 = 11189464307386 := by decide
theorem cert_e2393371285178 : check e2393371285178 [[],[.left],[]] .chain = true := by decide
def e2393371285226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2393371285226 : Closed e2393371285226 ∧ code e2393371285226 = 11189464307434 := by decide
theorem cert_e2393371285226 : check e2393371285226 [[],[.left],[]] .chain = true := by decide
def e2393371285418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2393371285418 : Closed e2393371285418 ∧ code e2393371285418 = 11189464307626 := by decide
theorem cert_e2393371285418 : check e2393371285418 [[],[.left],[]] .chain = true := by decide
def e2393371285726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2393371285726 : Closed e2393371285726 ∧ code e2393371285726 = 11189464307934 := by decide
theorem cert_e2393371285726 : check e2393371285726 [[],[.left],[]] .chain = true := by decide
def e2393371285742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2393371285742 : Closed e2393371285742 ∧ code e2393371285742 = 11189464307950 := by decide
theorem cert_e2393371285742 : check e2393371285742 [[],[.left],[]] .chain = true := by decide
def e2393371285750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2393371285750 : Closed e2393371285750 ∧ code e2393371285750 = 11189464307958 := by decide
theorem cert_e2393371285750 : check e2393371285750 [[],[.left],[]] .chain = true := by decide
def e2393371285754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2393371285754 : Closed e2393371285754 ∧ code e2393371285754 = 11189464307962 := by decide
theorem cert_e2393371285754 : check e2393371285754 [[],[.left],[]] .chain = true := by decide
def e2393371285934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2393371285934 : Closed e2393371285934 ∧ code e2393371285934 = 11189464308142 := by decide
theorem cert_e2393371285934 : check e2393371285934 [[],[.left],[]] .chain = true := by decide
def e2393371285946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2393371285946 : Closed e2393371285946 ∧ code e2393371285946 = 11189464308154 := by decide
theorem cert_e2393371285946 : check e2393371285946 [[],[.left],[]] .chain = true := by decide
def e2393371285994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2393371285994 : Closed e2393371285994 ∧ code e2393371285994 = 11189464308202 := by decide
theorem cert_e2393371285994 : check e2393371285994 [[],[.left],[]] .chain = true := by decide
def e2393371286078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2393371286078 : Closed e2393371286078 ∧ code e2393371286078 = 11189464308286 := by decide
theorem cert_e2393371286078 : check e2393371286078 [[],[.left],[]] .chain = true := by decide
def e2393371286126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2393371286126 : Closed e2393371286126 ∧ code e2393371286126 = 11189464308334 := by decide
theorem cert_e2393371286126 : check e2393371286126 [[],[.left],[]] .chain = true := by decide
def e2393371286138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2393371286138 : Closed e2393371286138 ∧ code e2393371286138 = 11189464308346 := by decide
theorem cert_e2393371286138 : check e2393371286138 [[],[.left],[]] .chain = true := by decide
def e2393371286302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2393371286302 : Closed e2393371286302 ∧ code e2393371286302 = 11189464308510 := by decide
theorem cert_e2393371286302 : check e2393371286302 [[],[.left],[]] .chain = true := by decide
def e2393371286414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2393371286414 : Closed e2393371286414 ∧ code e2393371286414 = 11189464308622 := by decide
theorem cert_e2393371286414 : check e2393371286414 [[],[.left],[]] .chain = true := by decide
def e2393371286426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371286426 : Closed e2393371286426 ∧ code e2393371286426 = 11189464308634 := by decide
theorem cert_e2393371286426 : check e2393371286426 [[],[.left],[]] .chain = true := by decide
def e2393371286470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2393371286470 : Closed e2393371286470 ∧ code e2393371286470 = 11189464308678 := by decide
theorem cert_e2393371286470 : check e2393371286470 [[],[.left],[]] .chain = true := by decide
def e2393371286494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 3)))))))
theorem wire_e2393371286494 : Closed e2393371286494 ∧ code e2393371286494 = 11189464308702 := by decide
theorem cert_e2393371286494 : checkPay e2393371286494 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e2393371286638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2393371286638 : Closed e2393371286638 ∧ code e2393371286638 = 11189464308846 := by decide
theorem cert_e2393371286638 : check e2393371286638 [[],[.left],[]] .chain = true := by decide
def e2393371286650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2393371286650 : Closed e2393371286650 ∧ code e2393371286650 = 11189464308858 := by decide
theorem cert_e2393371286650 : check e2393371286650 [[],[.left],[]] .chain = true := by decide
def e2393371286814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2393371286814 : Closed e2393371286814 ∧ code e2393371286814 = 11189464309022 := by decide
theorem cert_e2393371286814 : check e2393371286814 [[],[.left],[]] .chain = true := by decide
def e2393371286982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2393371286982 : Closed e2393371286982 ∧ code e2393371286982 = 11189464309190 := by decide
theorem cert_e2393371286982 : check e2393371286982 [[],[.left],[]] .chain = true := by decide
def e2393371287006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e2393371287006 : Closed e2393371287006 ∧ code e2393371287006 = 11189464309214 := by decide
theorem cert_e2393371287006 : checkPay e2393371287006 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371287022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e2393371287022 : Closed e2393371287022 ∧ code e2393371287022 = 11189464309230 := by decide
theorem cert_e2393371287022 : checkPay e2393371287022 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371287094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2393371287094 : Closed e2393371287094 ∧ code e2393371287094 = 11189464309302 := by decide
theorem cert_e2393371287094 : check e2393371287094 [[],[.left],[]] .chain = true := by decide
def e2393371287098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2393371287098 : Closed e2393371287098 ∧ code e2393371287098 = 11189464309306 := by decide
theorem cert_e2393371287098 : check e2393371287098 [[],[.left],[]] .chain = true := by decide
def e2393371287146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2393371287146 : Closed e2393371287146 ∧ code e2393371287146 = 11189464309354 := by decide
theorem cert_e2393371287146 : check e2393371287146 [[],[.left],[]] .chain = true := by decide
def e2393371287182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2393371287182 : Closed e2393371287182 ∧ code e2393371287182 = 11189464309390 := by decide
theorem cert_e2393371287182 : check e2393371287182 [[],[.left],[]] .chain = true := by decide
def e2393371287194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371287194 : Closed e2393371287194 ∧ code e2393371287194 = 11189464309402 := by decide
theorem cert_e2393371287194 : check e2393371287194 [[],[.left],[]] .chain = true := by decide
def e2393371287238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2393371287238 : Closed e2393371287238 ∧ code e2393371287238 = 11189464309446 := by decide
theorem cert_e2393371287238 : check e2393371287238 [[],[.left],[]] .chain = true := by decide
def e2393371287262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e2393371287262 : Closed e2393371287262 ∧ code e2393371287262 = 11189464309470 := by decide
theorem cert_e2393371287262 : checkPay e2393371287262 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2393371287286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e2393371287286 : Closed e2393371287286 ∧ code e2393371287286 = 11189464309494 := by decide
theorem cert_e2393371287286 : checkPay e2393371287286 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2393371287322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2393371287322 : Closed e2393371287322 ∧ code e2393371287322 = 11189464309530 := by decide
theorem cert_e2393371287322 : check e2393371287322 [[],[.left],[]] .chain = true := by decide
def e2393371287366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2393371287366 : Closed e2393371287366 ∧ code e2393371287366 = 11189464309574 := by decide
theorem cert_e2393371287366 : check e2393371287366 [[],[.left],[]] .chain = true := by decide
def e2393371287390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 3)))))))
theorem wire_e2393371287390 : Closed e2393371287390 ∧ code e2393371287390 = 11189464309598 := by decide
theorem cert_e2393371287390 : checkPay e2393371287390 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.under,.left,.right]] = true := by decide
def e2393371287406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e2393371287406 : Closed e2393371287406 ∧ code e2393371287406 = 11189464309614 := by decide
theorem cert_e2393371287406 : checkPay e2393371287406 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2393371287414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e2393371287414 : Closed e2393371287414 ∧ code e2393371287414 = 11189464309622 := by decide
theorem cert_e2393371287414 : checkPay e2393371287414 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.under,.left,.right]] = true := by decide
def e2393371287418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 0)))))))
theorem wire_e2393371287418 : Closed e2393371287418 ∧ code e2393371287418 = 11189464309626 := by decide
theorem cert_e2393371287418 : checkPay e2393371287418 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2393371288030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2393371288030 : Closed e2393371288030 ∧ code e2393371288030 = 11189464310238 := by decide
theorem cert_e2393371288030 : check e2393371288030 [[],[.left],[]] .chain = true := by decide
def e2393371288054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2393371288054 : Closed e2393371288054 ∧ code e2393371288054 = 11189464310262 := by decide
theorem cert_e2393371288054 : check e2393371288054 [[],[.left],[]] .chain = true := by decide
def e2393371289006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2393371289006 : Closed e2393371289006 ∧ code e2393371289006 = 11189464311214 := by decide
theorem cert_e2393371289006 : check e2393371289006 [[],[.left],[]] .chain = true := by decide
def e2393371289018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2393371289018 : Closed e2393371289018 ∧ code e2393371289018 = 11189464311226 := by decide
theorem cert_e2393371289018 : check e2393371289018 [[],[.left],[]] .chain = true := by decide
def e2393371289066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2393371289066 : Closed e2393371289066 ∧ code e2393371289066 = 11189464311274 := by decide
theorem cert_e2393371289066 : check e2393371289066 [[],[.left],[]] .chain = true := by decide
def e2393371289150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2393371289150 : Closed e2393371289150 ∧ code e2393371289150 = 11189464311358 := by decide
theorem cert_e2393371289150 : check e2393371289150 [[],[.left],[]] .chain = true := by decide
def e2393371289198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393371289198 : Closed e2393371289198 ∧ code e2393371289198 = 11189464311406 := by decide
theorem cert_e2393371289198 : check e2393371289198 [[],[.left],[]] .chain = true := by decide
def e2393371289210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393371289210 : Closed e2393371289210 ∧ code e2393371289210 = 11189464311418 := by decide
theorem cert_e2393371289210 : check e2393371289210 [[],[.left],[]] .chain = true := by decide
def e2393371289374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2393371289374 : Closed e2393371289374 ∧ code e2393371289374 = 11189464311582 := by decide
theorem cert_e2393371289374 : check e2393371289374 [[],[.left],[]] .chain = true := by decide
def e2393371289486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2393371289486 : Closed e2393371289486 ∧ code e2393371289486 = 11189464311694 := by decide
theorem cert_e2393371289486 : check e2393371289486 [[],[.left],[]] .chain = true := by decide
def e2393371289498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371289498 : Closed e2393371289498 ∧ code e2393371289498 = 11189464311706 := by decide
theorem cert_e2393371289498 : check e2393371289498 [[],[.left],[]] .chain = true := by decide
def e2393371289542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2393371289542 : Closed e2393371289542 ∧ code e2393371289542 = 11189464311750 := by decide
theorem cert_e2393371289542 : check e2393371289542 [[],[.left],[]] .chain = true := by decide
def e2393371289566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 3))))))))
theorem wire_e2393371289566 : Closed e2393371289566 ∧ code e2393371289566 = 11189464311774 := by decide
theorem cert_e2393371289566 : checkPay e2393371289566 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371292446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2393371292446 : Closed e2393371292446 ∧ code e2393371292446 = 11189464314654 := by decide
theorem cert_e2393371292446 : check e2393371292446 [[],[.left],[]] .chain = true := by decide
def e2393371292614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2393371292614 : Closed e2393371292614 ∧ code e2393371292614 = 11189464314822 := by decide
theorem cert_e2393371292614 : check e2393371292614 [[],[.left],[]] .chain = true := by decide
def e2393371292638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e2393371292638 : Closed e2393371292638 ∧ code e2393371292638 = 11189464314846 := by decide
theorem cert_e2393371292638 : checkPay e2393371292638 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371292654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e2393371292654 : Closed e2393371292654 ∧ code e2393371292654 = 11189464314862 := by decide
theorem cert_e2393371292654 : checkPay e2393371292654 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371293814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2393371293814 : Closed e2393371293814 ∧ code e2393371293814 = 11189464316022 := by decide
theorem cert_e2393371293814 : check e2393371293814 [[],[.left],[]] .chain = true := by decide
def e2393371294058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2393371294058 : Closed e2393371294058 ∧ code e2393371294058 = 11189464316266 := by decide
theorem cert_e2393371294058 : check e2393371294058 [[],[.left],[]] .chain = true := by decide
def e2393371294094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2393371294094 : Closed e2393371294094 ∧ code e2393371294094 = 11189464316302 := by decide
theorem cert_e2393371294094 : check e2393371294094 [[],[.left],[]] .chain = true := by decide
def e2393371294106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371294106 : Closed e2393371294106 ∧ code e2393371294106 = 11189464316314 := by decide
theorem cert_e2393371294106 : check e2393371294106 [[],[.left],[]] .chain = true := by decide
end Blc.Floor43
