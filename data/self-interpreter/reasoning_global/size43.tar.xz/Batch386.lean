import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364949270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))))
theorem wire_e2422364949270 : Closed e2422364949270 ∧ code e2422364949270 = 11218457971478 := by decide
theorem cert_e2422364949270 : check e2422364949270 [[],[]] .smaller = true := by decide
def e2422364949342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e2422364949342 : Closed e2422364949342 ∧ code e2422364949342 = 11218457971550 := by decide
theorem cert_e2422364949342 : check e2422364949342 [[],[]] .smaller = true := by decide
def e2422364949346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))))
theorem wire_e2422364949346 : Closed e2422364949346 ∧ code e2422364949346 = 11218457971554 := by decide
theorem cert_e2422364949346 : check e2422364949346 [[],[]] .smaller = true := by decide
def e2422364949358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422364949358 : Closed e2422364949358 ∧ code e2422364949358 = 11218457971566 := by decide
theorem cert_e2422364949358 : check e2422364949358 [[],[]] .smaller = true := by decide
def e2422364949366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422364949366 : Closed e2422364949366 ∧ code e2422364949366 = 11218457971574 := by decide
theorem cert_e2422364949366 : check e2422364949366 [[],[]] .smaller = true := by decide
def e2422364949370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e2422364949370 : Closed e2422364949370 ∧ code e2422364949370 = 11218457971578 := by decide
theorem cert_e2422364949370 : check e2422364949370 [[],[]] .smaller = true := by decide
def e2422364949386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))))
theorem wire_e2422364949386 : Closed e2422364949386 ∧ code e2422364949386 = 11218457971594 := by decide
theorem cert_e2422364949386 : check e2422364949386 [[],[]] .smaller = true := by decide
def e2422364949410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))))
theorem wire_e2422364949410 : Closed e2422364949410 ∧ code e2422364949410 = 11218457971618 := by decide
theorem cert_e2422364949410 : check e2422364949410 [[],[]] .smaller = true := by decide
def e2422364949422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422364949422 : Closed e2422364949422 ∧ code e2422364949422 = 11218457971630 := by decide
theorem cert_e2422364949422 : check e2422364949422 [[],[]] .smaller = true := by decide
def e2422364949430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))))))))))
theorem wire_e2422364949430 : Closed e2422364949430 ∧ code e2422364949430 = 11218457971638 := by decide
theorem cert_e2422364949430 : check e2422364949430 [[],[]] .smaller = true := by decide
def e2422364949434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422364949434 : Closed e2422364949434 ∧ code e2422364949434 = 11218457971642 := by decide
theorem cert_e2422364949434 : check e2422364949434 [[],[]] .smaller = true := by decide
def e2422364949462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422364949462 : Closed e2422364949462 ∧ code e2422364949462 = 11218457971670 := by decide
theorem cert_e2422364949462 : check e2422364949462 [[],[]] .smaller = true := by decide
def e2422364949466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422364949466 : Closed e2422364949466 ∧ code e2422364949466 = 11218457971674 := by decide
theorem cert_e2422364949466 : check e2422364949466 [[],[]] .smaller = true := by decide
def e2422364949482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e2422364949482 : Closed e2422364949482 ∧ code e2422364949482 = 11218457971690 := by decide
theorem cert_e2422364949482 : check e2422364949482 [[],[]] .smaller = true := by decide
def e2422364949534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))))
theorem wire_e2422364949534 : Closed e2422364949534 ∧ code e2422364949534 = 11218457971742 := by decide
theorem cert_e2422364949534 : check e2422364949534 [[],[]] .smaller = true := by decide
def e2422364949630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 5)))))))))))
theorem wire_e2422364949630 : Closed e2422364949630 ∧ code e2422364949630 = 11218457971838 := by decide
theorem cert_e2422364949630 : check e2422364949630 [[],[]] .three = true := by decide
def e2422364949726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422364949726 : Closed e2422364949726 ∧ code e2422364949726 = 11218457971934 := by decide
theorem cert_e2422364949726 : check e2422364949726 [[],[]] .smaller = true := by decide
def e2422364949730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))))
theorem wire_e2422364949730 : Closed e2422364949730 ∧ code e2422364949730 = 11218457971938 := by decide
theorem cert_e2422364949730 : check e2422364949730 [[],[]] .smaller = true := by decide
def e2422364949742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422364949742 : Closed e2422364949742 ∧ code e2422364949742 = 11218457971950 := by decide
theorem cert_e2422364949742 : check e2422364949742 [[],[]] .smaller = true := by decide
def e2422364949750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422364949750 : Closed e2422364949750 ∧ code e2422364949750 = 11218457971958 := by decide
theorem cert_e2422364949750 : check e2422364949750 [[],[]] .smaller = true := by decide
def e2422364949754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422364949754 : Closed e2422364949754 ∧ code e2422364949754 = 11218457971962 := by decide
theorem cert_e2422364949754 : check e2422364949754 [[],[]] .smaller = true := by decide
def e2422364950030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))))
theorem wire_e2422364950030 : Closed e2422364950030 ∧ code e2422364950030 = 11218457972238 := by decide
theorem cert_e2422364950030 : check e2422364950030 [[],[]] .smaller = true := by decide
def e2422364950042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422364950042 : Closed e2422364950042 ∧ code e2422364950042 = 11218457972250 := by decide
theorem cert_e2422364950042 : check e2422364950042 [[],[]] .smaller = true := by decide
def e2422364950114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))))
theorem wire_e2422364950114 : Closed e2422364950114 ∧ code e2422364950114 = 11218457972322 := by decide
theorem cert_e2422364950114 : check e2422364950114 [[],[]] .smaller = true := by decide
def e2422364950126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422364950126 : Closed e2422364950126 ∧ code e2422364950126 = 11218457972334 := by decide
theorem cert_e2422364950126 : check e2422364950126 [[],[]] .smaller = true := by decide
def e2422364950134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422364950134 : Closed e2422364950134 ∧ code e2422364950134 = 11218457972342 := by decide
theorem cert_e2422364950134 : check e2422364950134 [[],[]] .smaller = true := by decide
def e2422364950138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422364950138 : Closed e2422364950138 ∧ code e2422364950138 = 11218457972346 := by decide
theorem cert_e2422364950138 : check e2422364950138 [[],[]] .smaller = true := by decide
def e2422364950326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422364950326 : Closed e2422364950326 ∧ code e2422364950326 = 11218457972534 := by decide
theorem cert_e2422364950326 : check e2422364950326 [[],[]] .smaller = true := by decide
def e2422364950330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422364950330 : Closed e2422364950330 ∧ code e2422364950330 = 11218457972538 := by decide
theorem cert_e2422364950330 : check e2422364950330 [[],[]] .smaller = true := by decide
def e2422364950426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364950426 : Closed e2422364950426 ∧ code e2422364950426 = 11218457972634 := by decide
theorem cert_e2422364950426 : check e2422364950426 [[],[]] .smaller = true := by decide
def e2422364950470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 4) (.lam (.var 1)))))))))))
theorem wire_e2422364950470 : Closed e2422364950470 ∧ code e2422364950470 = 11218457972678 := by decide
theorem cert_e2422364950470 : check e2422364950470 [[],[]] .three = true := by decide
def e2422364955102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422364955102 : Closed e2422364955102 ∧ code e2422364955102 = 11218457977310 := by decide
theorem cert_e2422364955102 : check e2422364955102 [[],[]] .smaller = true := by decide
def e2422364955118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422364955118 : Closed e2422364955118 ∧ code e2422364955118 = 11218457977326 := by decide
theorem cert_e2422364955118 : check e2422364955118 [[],[]] .smaller = true := by decide
def e2422364955126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422364955126 : Closed e2422364955126 ∧ code e2422364955126 = 11218457977334 := by decide
theorem cert_e2422364955126 : check e2422364955126 [[],[]] .smaller = true := by decide
def e2422364956078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422364956078 : Closed e2422364956078 ∧ code e2422364956078 = 11218457978286 := by decide
theorem cert_e2422364956078 : check e2422364956078 [[],[]] .smaller = true := by decide
def e2422364956086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2422364956086 : Closed e2422364956086 ∧ code e2422364956086 = 11218457978294 := by decide
theorem cert_e2422364956086 : check e2422364956086 [[],[]] .smaller = true := by decide
def e2422364956090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422364956090 : Closed e2422364956090 ∧ code e2422364956090 = 11218457978298 := by decide
theorem cert_e2422364956090 : check e2422364956090 [[],[]] .smaller = true := by decide
def e2422364956118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2422364956118 : Closed e2422364956118 ∧ code e2422364956118 = 11218457978326 := by decide
theorem cert_e2422364956118 : check e2422364956118 [[],[]] .smaller = true := by decide
def e2422364956122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2422364956122 : Closed e2422364956122 ∧ code e2422364956122 = 11218457978330 := by decide
theorem cert_e2422364956122 : check e2422364956122 [[],[]] .smaller = true := by decide
def e2422364956138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422364956138 : Closed e2422364956138 ∧ code e2422364956138 = 11218457978346 := by decide
theorem cert_e2422364956138 : check e2422364956138 [[],[]] .smaller = true := by decide
def e2422364956270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422364956270 : Closed e2422364956270 ∧ code e2422364956270 = 11218457978478 := by decide
theorem cert_e2422364956270 : check e2422364956270 [[],[]] .smaller = true := by decide
def e2422364956278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422364956278 : Closed e2422364956278 ∧ code e2422364956278 = 11218457978486 := by decide
theorem cert_e2422364956278 : check e2422364956278 [[],[]] .smaller = true := by decide
def e2422364956282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422364956282 : Closed e2422364956282 ∧ code e2422364956282 = 11218457978490 := by decide
theorem cert_e2422364956282 : check e2422364956282 [[],[]] .smaller = true := by decide
def e2422364956470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422364956470 : Closed e2422364956470 ∧ code e2422364956470 = 11218457978678 := by decide
theorem cert_e2422364956470 : check e2422364956470 [[],[]] .smaller = true := by decide
def e2422364956474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422364956474 : Closed e2422364956474 ∧ code e2422364956474 = 11218457978682 := by decide
theorem cert_e2422364956474 : check e2422364956474 [[],[]] .smaller = true := by decide
def e2422364956570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364956570 : Closed e2422364956570 ∧ code e2422364956570 = 11218457978778 := by decide
theorem cert_e2422364956570 : check e2422364956570 [[],[]] .smaller = true := by decide
def e2422364958958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422364958958 : Closed e2422364958958 ∧ code e2422364958958 = 11218457981166 := by decide
theorem cert_e2422364958958 : check e2422364958958 [[],[]] .three = true := by decide
def e2422364958966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422364958966 : Closed e2422364958966 ∧ code e2422364958966 = 11218457981174 := by decide
theorem cert_e2422364958966 : check e2422364958966 [[],[]] .three = true := by decide
def e2422364959446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422364959446 : Closed e2422364959446 ∧ code e2422364959446 = 11218457981654 := by decide
theorem cert_e2422364959446 : check e2422364959446 [[],[]] .three = true := by decide
def e2422364959450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422364959450 : Closed e2422364959450 ∧ code e2422364959450 = 11218457981658 := by decide
theorem cert_e2422364959450 : check e2422364959450 [[],[]] .three = true := by decide
def e2422364959466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422364959466 : Closed e2422364959466 ∧ code e2422364959466 = 11218457981674 := by decide
theorem cert_e2422364959466 : check e2422364959466 [[],[]] .three = true := by decide
def e2422364959518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2422364959518 : Closed e2422364959518 ∧ code e2422364959518 = 11218457981726 := by decide
theorem cert_e2422364959518 : check e2422364959518 [[],[]] .three = true := by decide
def e2422364959542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422364959542 : Closed e2422364959542 ∧ code e2422364959542 = 11218457981750 := by decide
theorem cert_e2422364959542 : check e2422364959542 [[],[]] .three = true := by decide
def e2422364959546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422364959546 : Closed e2422364959546 ∧ code e2422364959546 = 11218457981754 := by decide
theorem cert_e2422364959546 : check e2422364959546 [[],[]] .three = true := by decide
def e2422364959630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422364959630 : Closed e2422364959630 ∧ code e2422364959630 = 11218457981838 := by decide
theorem cert_e2422364959630 : check e2422364959630 [[],[]] .three = true := by decide
def e2422364959642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364959642 : Closed e2422364959642 ∧ code e2422364959642 = 11218457981850 := by decide
theorem cert_e2422364959642 : check e2422364959642 [[],[]] .three = true := by decide
def e2422364959678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422364959678 : Closed e2422364959678 ∧ code e2422364959678 = 11218457981886 := by decide
theorem cert_e2422364959678 : check e2422364959678 [[],[]] .three = true := by decide
def e2422364959686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2422364959686 : Closed e2422364959686 ∧ code e2422364959686 = 11218457981894 := by decide
theorem cert_e2422364959686 : check e2422364959686 [[],[]] .three = true := by decide
def e2422364959734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422364959734 : Closed e2422364959734 ∧ code e2422364959734 = 11218457981942 := by decide
theorem cert_e2422364959734 : check e2422364959734 [[],[]] .three = true := by decide
def e2422365230814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))))
theorem wire_e2422365230814 : Closed e2422365230814 ∧ code e2422365230814 = 11218458253022 := by decide
theorem cert_e2422365230814 : check e2422365230814 [[],[]] .smaller = true := by decide
def e2422365230838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))))
theorem wire_e2422365230838 : Closed e2422365230838 ∧ code e2422365230838 = 11218458253046 := by decide
theorem cert_e2422365230838 : check e2422365230838 [[],[]] .smaller = true := by decide
def e2422365230942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))))
theorem wire_e2422365230942 : Closed e2422365230942 ∧ code e2422365230942 = 11218458253150 := by decide
theorem cert_e2422365230942 : check e2422365230942 [[],[]] .smaller = true := by decide
def e2422365230970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))))
theorem wire_e2422365230970 : Closed e2422365230970 ∧ code e2422365230970 = 11218458253178 := by decide
theorem cert_e2422365230970 : check e2422365230970 [[],[]] .smaller = true := by decide
def e2422365231062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))))
theorem wire_e2422365231062 : Closed e2422365231062 ∧ code e2422365231062 = 11218458253270 := by decide
theorem cert_e2422365231062 : check e2422365231062 [[],[]] .smaller = true := by decide
def e2422365231066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))))
theorem wire_e2422365231066 : Closed e2422365231066 ∧ code e2422365231066 = 11218458253274 := by decide
theorem cert_e2422365231066 : check e2422365231066 [[],[]] .smaller = true := by decide
def e2422365231582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))))
theorem wire_e2422365231582 : Closed e2422365231582 ∧ code e2422365231582 = 11218458253790 := by decide
theorem cert_e2422365231582 : check e2422365231582 [[],[]] .smaller = true := by decide
def e2422365231606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))))
theorem wire_e2422365231606 : Closed e2422365231606 ∧ code e2422365231606 = 11218458253814 := by decide
theorem cert_e2422365231606 : check e2422365231606 [[],[]] .smaller = true := by decide
def e2422365232350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))))
theorem wire_e2422365232350 : Closed e2422365232350 ∧ code e2422365232350 = 11218458254558 := by decide
theorem cert_e2422365232350 : check e2422365232350 [[],[]] .smaller = true := by decide
def e2422365232378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))))
theorem wire_e2422365232378 : Closed e2422365232378 ∧ code e2422365232378 = 11218458254586 := by decide
theorem cert_e2422365232378 : check e2422365232378 [[],[]] .smaller = true := by decide
def e2422365232950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422365232950 : Closed e2422365232950 ∧ code e2422365232950 = 11218458255158 := by decide
theorem cert_e2422365232950 : check e2422365232950 [[],[]] .smaller = true := by decide
def e2422365232954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422365232954 : Closed e2422365232954 ∧ code e2422365232954 = 11218458255162 := by decide
theorem cert_e2422365232954 : check e2422365232954 [[],[]] .smaller = true := by decide
def e2422365247726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))))
theorem wire_e2422365247726 : Closed e2422365247726 ∧ code e2422365247726 = 11218458269934 := by decide
theorem cert_e2422365247726 : check e2422365247726 [[],[]] .smaller = true := by decide
def e2422365247734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))))
theorem wire_e2422365247734 : Closed e2422365247734 ∧ code e2422365247734 = 11218458269942 := by decide
theorem cert_e2422365247734 : check e2422365247734 [[],[]] .smaller = true := by decide
def e2422365248286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))))
theorem wire_e2422365248286 : Closed e2422365248286 ∧ code e2422365248286 = 11218458270494 := by decide
theorem cert_e2422365248286 : check e2422365248286 [[],[]] .smaller = true := by decide
def e2422365248398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))))
theorem wire_e2422365248398 : Closed e2422365248398 ∧ code e2422365248398 = 11218458270606 := by decide
theorem cert_e2422365248398 : check e2422365248398 [[],[]] .smaller = true := by decide
def e2422365248446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 4))))))))))
theorem wire_e2422365248446 : Closed e2422365248446 ∧ code e2422365248446 = 11218458270654 := by decide
theorem cert_e2422365248446 : check e2422365248446 [[],[]] .smaller = true := by decide
def e2422365248494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 4)) (.var 2))))))))))
theorem wire_e2422365248494 : Closed e2422365248494 ∧ code e2422365248494 = 11218458270702 := by decide
theorem cert_e2422365248494 : check e2422365248494 [[],[]] .smaller = true := by decide
def e2422365248622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))))
theorem wire_e2422365248622 : Closed e2422365248622 ∧ code e2422365248622 = 11218458270830 := by decide
theorem cert_e2422365248622 : check e2422365248622 [[],[]] .smaller = true := by decide
def e2422365248634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))))
theorem wire_e2422365248634 : Closed e2422365248634 ∧ code e2422365248634 = 11218458270842 := by decide
theorem cert_e2422365248634 : check e2422365248634 [[],[]] .smaller = true := by decide
def e2422365248798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))))
theorem wire_e2422365248798 : Closed e2422365248798 ∧ code e2422365248798 = 11218458271006 := by decide
theorem cert_e2422365248798 : check e2422365248798 [[],[]] .smaller = true := by decide
def e2422365248958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 4))))))))))
theorem wire_e2422365248958 : Closed e2422365248958 ∧ code e2422365248958 = 11218458271166 := by decide
theorem cert_e2422365248958 : check e2422365248958 [[],[]] .smaller = true := by decide
def e2422365248966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))))
theorem wire_e2422365248966 : Closed e2422365248966 ∧ code e2422365248966 = 11218458271174 := by decide
theorem cert_e2422365248966 : check e2422365248966 [[],[]] .smaller = true := by decide
def e2422365248990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))))
theorem wire_e2422365248990 : Closed e2422365248990 ∧ code e2422365248990 = 11218458271198 := by decide
theorem cert_e2422365248990 : check e2422365248990 [[],[]] .smaller = true := by decide
def e2422365249006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))))
theorem wire_e2422365249006 : Closed e2422365249006 ∧ code e2422365249006 = 11218458271214 := by decide
theorem cert_e2422365249006 : check e2422365249006 [[],[]] .smaller = true := by decide
def e2422365249014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 4)) (.var 1))))))))))
theorem wire_e2422365249014 : Closed e2422365249014 ∧ code e2422365249014 = 11218458271222 := by decide
theorem cert_e2422365249014 : check e2422365249014 [[],[]] .smaller = true := by decide
def e2422365249078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e2422365249078 : Closed e2422365249078 ∧ code e2422365249078 = 11218458271286 := by decide
theorem cert_e2422365249078 : check e2422365249078 [[],[]] .smaller = true := by decide
def e2422365249082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e2422365249082 : Closed e2422365249082 ∧ code e2422365249082 = 11218458271290 := by decide
theorem cert_e2422365249082 : check e2422365249082 [[],[]] .smaller = true := by decide
def e2422365249166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e2422365249166 : Closed e2422365249166 ∧ code e2422365249166 = 11218458271374 := by decide
theorem cert_e2422365249166 : check e2422365249166 [[],[]] .smaller = true := by decide
def e2422365249214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 4))))))))))
theorem wire_e2422365249214 : Closed e2422365249214 ∧ code e2422365249214 = 11218458271422 := by decide
theorem cert_e2422365249214 : check e2422365249214 [[],[]] .smaller = true := by decide
def e2422365249222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e2422365249222 : Closed e2422365249222 ∧ code e2422365249222 = 11218458271430 := by decide
theorem cert_e2422365249222 : check e2422365249222 [[],[]] .smaller = true := by decide
def e2422365249246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))))
theorem wire_e2422365249246 : Closed e2422365249246 ∧ code e2422365249246 = 11218458271454 := by decide
theorem cert_e2422365249246 : check e2422365249246 [[],[]] .smaller = true := by decide
def e2422365249270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))))
theorem wire_e2422365249270 : Closed e2422365249270 ∧ code e2422365249270 = 11218458271478 := by decide
theorem cert_e2422365249270 : check e2422365249270 [[],[]] .smaller = true := by decide
def e2422365249274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 4)) (.var 0))))))))))
theorem wire_e2422365249274 : Closed e2422365249274 ∧ code e2422365249274 = 11218458271482 := by decide
theorem cert_e2422365249274 : check e2422365249274 [[],[]] .smaller = true := by decide
def e2422365249390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))))
theorem wire_e2422365249390 : Closed e2422365249390 ∧ code e2422365249390 = 11218458271598 := by decide
theorem cert_e2422365249390 : check e2422365249390 [[],[]] .smaller = true := by decide
def e2422365249398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))))
theorem wire_e2422365249398 : Closed e2422365249398 ∧ code e2422365249398 = 11218458271606 := by decide
theorem cert_e2422365249398 : check e2422365249398 [[],[]] .smaller = true := by decide
def e2422365249454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 4) (.var 0)) (.var 2))))))))))
theorem wire_e2422365249454 : Closed e2422365249454 ∧ code e2422365249454 = 11218458271662 := by decide
theorem cert_e2422365249454 : check e2422365249454 [[],[]] .smaller = true := by decide
def e2422365249462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 4) (.var 1)) (.var 1))))))))))
theorem wire_e2422365249462 : Closed e2422365249462 ∧ code e2422365249462 = 11218458271670 := by decide
theorem cert_e2422365249462 : check e2422365249462 [[],[]] .smaller = true := by decide
def e2422365249466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 4) (.var 2)) (.var 0))))))))))
theorem wire_e2422365249466 : Closed e2422365249466 ∧ code e2422365249466 = 11218458271674 := by decide
theorem cert_e2422365249466 : check e2422365249466 [[],[]] .smaller = true := by decide
def e2422365251358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))))
theorem wire_e2422365251358 : Closed e2422365251358 ∧ code e2422365251358 = 11218458273566 := by decide
theorem cert_e2422365251358 : check e2422365251358 [[],[]] .smaller = true := by decide
def e2422365251470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))))
theorem wire_e2422365251470 : Closed e2422365251470 ∧ code e2422365251470 = 11218458273678 := by decide
theorem cert_e2422365251470 : check e2422365251470 [[],[]] .smaller = true := by decide
def e2422365251518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 4)))))))))))
theorem wire_e2422365251518 : Closed e2422365251518 ∧ code e2422365251518 = 11218458273726 := by decide
theorem cert_e2422365251518 : check e2422365251518 [[],[]] .smaller = true := by decide
def e2422365251566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 4) (.var 2)))))))))))
theorem wire_e2422365251566 : Closed e2422365251566 ∧ code e2422365251566 = 11218458273774 := by decide
theorem cert_e2422365251566 : check e2422365251566 [[],[]] .smaller = true := by decide
def e2422365254430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))))
theorem wire_e2422365254430 : Closed e2422365254430 ∧ code e2422365254430 = 11218458276638 := by decide
theorem cert_e2422365254430 : check e2422365254430 [[],[]] .smaller = true := by decide
def e2422365254590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422365254590 : Closed e2422365254590 ∧ code e2422365254590 = 11218458276798 := by decide
theorem cert_e2422365254590 : check e2422365254590 [[],[]] .smaller = true := by decide
def e2422365254598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))))
theorem wire_e2422365254598 : Closed e2422365254598 ∧ code e2422365254598 = 11218458276806 := by decide
theorem cert_e2422365254598 : check e2422365254598 [[],[]] .smaller = true := by decide
def e2422365254622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422365254622 : Closed e2422365254622 ∧ code e2422365254622 = 11218458276830 := by decide
theorem cert_e2422365254622 : check e2422365254622 [[],[]] .smaller = true := by decide
def e2422365254638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422365254638 : Closed e2422365254638 ∧ code e2422365254638 = 11218458276846 := by decide
theorem cert_e2422365254638 : check e2422365254638 [[],[]] .smaller = true := by decide
def e2422365254646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422365254646 : Closed e2422365254646 ∧ code e2422365254646 = 11218458276854 := by decide
theorem cert_e2422365254646 : check e2422365254646 [[],[]] .smaller = true := by decide
def e2422365256078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e2422365256078 : Closed e2422365256078 ∧ code e2422365256078 = 11218458278286 := by decide
theorem cert_e2422365256078 : check e2422365256078 [[],[]] .smaller = true := by decide
def e2422365256126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422365256126 : Closed e2422365256126 ∧ code e2422365256126 = 11218458278334 := by decide
theorem cert_e2422365256126 : check e2422365256126 [[],[]] .smaller = true := by decide
def e2422365256134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e2422365256134 : Closed e2422365256134 ∧ code e2422365256134 = 11218458278342 := by decide
theorem cert_e2422365256134 : check e2422365256134 [[],[]] .smaller = true := by decide
def e2422365256158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422365256158 : Closed e2422365256158 ∧ code e2422365256158 = 11218458278366 := by decide
theorem cert_e2422365256158 : check e2422365256158 [[],[]] .smaller = true := by decide
def e2422365256182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422365256182 : Closed e2422365256182 ∧ code e2422365256182 = 11218458278390 := by decide
theorem cert_e2422365256182 : check e2422365256182 [[],[]] .smaller = true := by decide
def e2422365256186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422365256186 : Closed e2422365256186 ∧ code e2422365256186 = 11218458278394 := by decide
theorem cert_e2422365256186 : check e2422365256186 [[],[]] .smaller = true := by decide
def e2422365256942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365256942 : Closed e2422365256942 ∧ code e2422365256942 = 11218458279150 := by decide
theorem cert_e2422365256942 : check e2422365256942 [[],[]] .smaller = true := by decide
def e2422365256950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365256950 : Closed e2422365256950 ∧ code e2422365256950 = 11218458279158 := by decide
theorem cert_e2422365256950 : check e2422365256950 [[],[]] .smaller = true := by decide
def e2422365257326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422365257326 : Closed e2422365257326 ∧ code e2422365257326 = 11218458279534 := by decide
theorem cert_e2422365257326 : check e2422365257326 [[],[]] .smaller = true := by decide
def e2422365257334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365257334 : Closed e2422365257334 ∧ code e2422365257334 = 11218458279542 := by decide
theorem cert_e2422365257334 : check e2422365257334 [[],[]] .smaller = true := by decide
def e2422365257338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422365257338 : Closed e2422365257338 ∧ code e2422365257338 = 11218458279546 := by decide
theorem cert_e2422365257338 : check e2422365257338 [[],[]] .smaller = true := by decide
def e2422365297262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422365297262 : Closed e2422365297262 ∧ code e2422365297262 = 11218458319470 := by decide
theorem cert_e2422365297262 : check e2422365297262 [[],[]] .smaller = true := by decide
def e2422365297274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422365297274 : Closed e2422365297274 ∧ code e2422365297274 = 11218458319482 := by decide
theorem cert_e2422365297274 : check e2422365297274 [[],[]] .smaller = true := by decide
def e2422365313198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)))))))))
theorem wire_e2422365313198 : Closed e2422365313198 ∧ code e2422365313198 = 11218458335406 := by decide
theorem cert_e2422365313198 : check e2422365313198 [[],[]] .smaller = true := by decide
def e2422365313210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)))))))))
theorem wire_e2422365313210 : Closed e2422365313210 ∧ code e2422365313210 = 11218458335418 := by decide
theorem cert_e2422365313210 : check e2422365313210 [[],[]] .smaller = true := by decide
def e2422365313582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422365313582 : Closed e2422365313582 ∧ code e2422365313582 = 11218458335790 := by decide
theorem cert_e2422365313582 : check e2422365313582 [[],[]] .smaller = true := by decide
def e2422365313726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 4)))))))))
theorem wire_e2422365313726 : Closed e2422365313726 ∧ code e2422365313726 = 11218458335934 := by decide
theorem cert_e2422365313726 : check e2422365313726 [[],[]] .three = true := by decide
def e2422365313758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e2422365313758 : Closed e2422365313758 ∧ code e2422365313758 = 11218458335966 := by decide
theorem cert_e2422365313758 : check e2422365313758 [[],[]] .smaller = true := by decide
def e2422365313762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422365313762 : Closed e2422365313762 ∧ code e2422365313762 = 11218458335970 := by decide
theorem cert_e2422365313762 : check e2422365313762 [[],[]] .smaller = true := by decide
def e2422365313774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)))))))))
theorem wire_e2422365313774 : Closed e2422365313774 ∧ code e2422365313774 = 11218458335982 := by decide
theorem cert_e2422365313774 : check e2422365313774 [[],[]] .smaller = true := by decide
def e2422365313782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e2422365313782 : Closed e2422365313782 ∧ code e2422365313782 = 11218458335990 := by decide
theorem cert_e2422365313782 : check e2422365313782 [[],[]] .smaller = true := by decide
def e2422365313786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 0)))))))))
theorem wire_e2422365313786 : Closed e2422365313786 ∧ code e2422365313786 = 11218458335994 := by decide
theorem cert_e2422365313786 : check e2422365313786 [[],[]] .three = true := by decide
def e2422365313886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e2422365313886 : Closed e2422365313886 ∧ code e2422365313886 = 11218458336094 := by decide
theorem cert_e2422365313886 : check e2422365313886 [[],[]] .smaller = true := by decide
def e2422365313902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e2422365313902 : Closed e2422365313902 ∧ code e2422365313902 = 11218458336110 := by decide
theorem cert_e2422365313902 : check e2422365313902 [[],[]] .smaller = true := by decide
def e2422365313910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e2422365313910 : Closed e2422365313910 ∧ code e2422365313910 = 11218458336118 := by decide
theorem cert_e2422365313910 : check e2422365313910 [[],[]] .smaller = true := by decide
def e2422365313914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e2422365313914 : Closed e2422365313914 ∧ code e2422365313914 = 11218458336122 := by decide
theorem cert_e2422365313914 : check e2422365313914 [[],[]] .smaller = true := by decide
def e2422365313930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422365313930 : Closed e2422365313930 ∧ code e2422365313930 = 11218458336138 := by decide
theorem cert_e2422365313930 : check e2422365313930 [[],[]] .smaller = true := by decide
def e2422365313954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422365313954 : Closed e2422365313954 ∧ code e2422365313954 = 11218458336162 := by decide
theorem cert_e2422365313954 : check e2422365313954 [[],[]] .smaller = true := by decide
def e2422365313966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)))))))))
theorem wire_e2422365313966 : Closed e2422365313966 ∧ code e2422365313966 = 11218458336174 := by decide
theorem cert_e2422365313966 : check e2422365313966 [[],[]] .smaller = true := by decide
def e2422365313974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e2422365313974 : Closed e2422365313974 ∧ code e2422365313974 = 11218458336182 := by decide
theorem cert_e2422365313974 : check e2422365313974 [[],[]] .smaller = true := by decide
def e2422365313978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)))))))))
theorem wire_e2422365313978 : Closed e2422365313978 ∧ code e2422365313978 = 11218458336186 := by decide
theorem cert_e2422365313978 : check e2422365313978 [[],[]] .smaller = true := by decide
def e2422365314006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365314006 : Closed e2422365314006 ∧ code e2422365314006 = 11218458336214 := by decide
theorem cert_e2422365314006 : check e2422365314006 [[],[]] .smaller = true := by decide
def e2422365314010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365314010 : Closed e2422365314010 ∧ code e2422365314010 = 11218458336218 := by decide
theorem cert_e2422365314010 : check e2422365314010 [[],[]] .smaller = true := by decide
def e2422365314026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365314026 : Closed e2422365314026 ∧ code e2422365314026 = 11218458336234 := by decide
theorem cert_e2422365314026 : check e2422365314026 [[],[]] .three = true := by decide
def e2422365314398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e2422365314398 : Closed e2422365314398 ∧ code e2422365314398 = 11218458336606 := by decide
theorem cert_e2422365314398 : check e2422365314398 [[],[]] .smaller = true := by decide
def e2422365314414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2422365314414 : Closed e2422365314414 ∧ code e2422365314414 = 11218458336622 := by decide
theorem cert_e2422365314414 : check e2422365314414 [[],[]] .smaller = true := by decide
def e2422365314422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2422365314422 : Closed e2422365314422 ∧ code e2422365314422 = 11218458336630 := by decide
theorem cert_e2422365314422 : check e2422365314422 [[],[]] .smaller = true := by decide
def e2422365314426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e2422365314426 : Closed e2422365314426 ∧ code e2422365314426 = 11218458336634 := by decide
theorem cert_e2422365314426 : check e2422365314426 [[],[]] .smaller = true := by decide
def e2422365314478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2422365314478 : Closed e2422365314478 ∧ code e2422365314478 = 11218458336686 := by decide
theorem cert_e2422365314478 : check e2422365314478 [[],[]] .smaller = true := by decide
def e2422365314490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2422365314490 : Closed e2422365314490 ∧ code e2422365314490 = 11218458336698 := by decide
theorem cert_e2422365314490 : check e2422365314490 [[],[]] .smaller = true := by decide
def e2422365314518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365314518 : Closed e2422365314518 ∧ code e2422365314518 = 11218458336726 := by decide
theorem cert_e2422365314518 : check e2422365314518 [[],[]] .smaller = true := by decide
def e2422365314522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365314522 : Closed e2422365314522 ∧ code e2422365314522 = 11218458336730 := by decide
theorem cert_e2422365314522 : check e2422365314522 [[],[]] .smaller = true := by decide
def e2422365314538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365314538 : Closed e2422365314538 ∧ code e2422365314538 = 11218458336746 := by decide
theorem cert_e2422365314538 : check e2422365314538 [[],[]] .smaller = true := by decide
def e2422365314602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)))))))))
theorem wire_e2422365314602 : Closed e2422365314602 ∧ code e2422365314602 = 11218458336810 := by decide
theorem cert_e2422365314602 : check e2422365314602 [[],[]] .smaller = true := by decide
def e2422365314698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422365314698 : Closed e2422365314698 ∧ code e2422365314698 = 11218458336906 := by decide
theorem cert_e2422365314698 : check e2422365314698 [[],[]] .smaller = true := by decide
def e2422365314722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422365314722 : Closed e2422365314722 ∧ code e2422365314722 = 11218458336930 := by decide
theorem cert_e2422365314722 : check e2422365314722 [[],[]] .smaller = true := by decide
def e2422365314734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422365314734 : Closed e2422365314734 ∧ code e2422365314734 = 11218458336942 := by decide
theorem cert_e2422365314734 : check e2422365314734 [[],[]] .smaller = true := by decide
def e2422365314742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e2422365314742 : Closed e2422365314742 ∧ code e2422365314742 = 11218458336950 := by decide
theorem cert_e2422365314742 : check e2422365314742 [[],[]] .smaller = true := by decide
def e2422365314746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422365314746 : Closed e2422365314746 ∧ code e2422365314746 = 11218458336954 := by decide
theorem cert_e2422365314746 : check e2422365314746 [[],[]] .smaller = true := by decide
def e2422365314774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365314774 : Closed e2422365314774 ∧ code e2422365314774 = 11218458336982 := by decide
theorem cert_e2422365314774 : check e2422365314774 [[],[]] .smaller = true := by decide
def e2422365314778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365314778 : Closed e2422365314778 ∧ code e2422365314778 = 11218458336986 := by decide
theorem cert_e2422365314778 : check e2422365314778 [[],[]] .smaller = true := by decide
def e2422365314794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365314794 : Closed e2422365314794 ∧ code e2422365314794 = 11218458337002 := by decide
theorem cert_e2422365314794 : check e2422365314794 [[],[]] .smaller = true := by decide
end Blc.Floor43
