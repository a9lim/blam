import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e739623626218 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e739623626218 : Closed e739623626218 ∧ code e739623626218 = 9535716648426 := by decide
theorem cert_e739623626218 : check e739623626218 [] .sourceHead = true := by decide
def e739623626350 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e739623626350 : Closed e739623626350 ∧ code e739623626350 = 9535716648558 := by decide
theorem cert_e739623626350 : check e739623626350 [] .sourceHead = true := by decide
def e739623626362 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e739623626362 : Closed e739623626362 ∧ code e739623626362 = 9535716648570 := by decide
theorem cert_e739623626362 : check e739623626362 [] .sourceHead = true := by decide
def e739623626650 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e739623626650 : Closed e739623626650 ∧ code e739623626650 = 9535716648858 := by decide
theorem cert_e739623626650 : check e739623626650 [] .sourceHead = true := by decide
def e739623629526 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e739623629526 : Closed e739623629526 ∧ code e739623629526 = 9535716651734 := by decide
theorem cert_e739623629526 : check e739623629526 [] .sourceHead = true := by decide
def e739623629530 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e739623629530 : Closed e739623629530 ∧ code e739623629530 = 9535716651738 := by decide
theorem cert_e739623629530 : check e739623629530 [] .sourceHead = true := by decide
def e739623629546 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e739623629546 : Closed e739623629546 ∧ code e739623629546 = 9535716651754 := by decide
theorem cert_e739623629546 : check e739623629546 [] .sourceHead = true := by decide
def e739623629622 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e739623629622 : Closed e739623629622 ∧ code e739623629622 = 9535716651830 := by decide
theorem cert_e739623629622 : check e739623629622 [] .sourceHead = true := by decide
def e739623629626 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e739623629626 : Closed e739623629626 ∧ code e739623629626 = 9535716651834 := by decide
theorem cert_e739623629626 : check e739623629626 [] .sourceHead = true := by decide
def e739623629722 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e739623629722 : Closed e739623629722 ∧ code e739623629722 = 9535716651930 := by decide
theorem cert_e739623629722 : check e739623629722 [] .sourceHead = true := by decide
def e739623766894 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e739623766894 : Closed e739623766894 ∧ code e739623766894 = 9535716789102 := by decide
theorem cert_e739623766894 : check e739623766894 [] .sourceHead = true := by decide
def e739623766902 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e739623766902 : Closed e739623766902 ∧ code e739623766902 = 9535716789110 := by decide
theorem cert_e739623766902 : check e739623766902 [] .sourceHead = true := by decide
def e739623766958 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e739623766958 : Closed e739623766958 ∧ code e739623766958 = 9535716789166 := by decide
theorem cert_e739623766958 : check e739623766958 [] .sourceHead = true := by decide
def e739623766970 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e739623766970 : Closed e739623766970 ∧ code e739623766970 = 9535716789178 := by decide
theorem cert_e739623766970 : check e739623766970 [] .sourceHead = true := by decide
def e739623766998 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e739623766998 : Closed e739623766998 ∧ code e739623766998 = 9535716789206 := by decide
theorem cert_e739623766998 : check e739623766998 [] .sourceHead = true := by decide
def e739623767002 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e739623767002 : Closed e739623767002 ∧ code e739623767002 = 9535716789210 := by decide
theorem cert_e739623767002 : check e739623767002 [] .sourceHead = true := by decide
def e739623767278 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e739623767278 : Closed e739623767278 ∧ code e739623767278 = 9535716789486 := by decide
theorem cert_e739623767278 : check e739623767278 [] .sourceHead = true := by decide
def e739623767286 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e739623767286 : Closed e739623767286 ∧ code e739623767286 = 9535716789494 := by decide
theorem cert_e739623767286 : check e739623767286 [] .sourceHead = true := by decide
def e739623767662 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e739623767662 : Closed e739623767662 ∧ code e739623767662 = 9535716789870 := by decide
theorem cert_e739623767662 : check e739623767662 [] .sourceHead = true := by decide
def e739623767674 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e739623767674 : Closed e739623767674 ∧ code e739623767674 = 9535716789882 := by decide
theorem cert_e739623767674 : check e739623767674 [] .sourceHead = true := by decide
def e739623767862 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e739623767862 : Closed e739623767862 ∧ code e739623767862 = 9535716790070 := by decide
theorem cert_e739623767862 : check e739623767862 [] .sourceHead = true := by decide
def e739623767866 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e739623767866 : Closed e739623767866 ∧ code e739623767866 = 9535716790074 := by decide
theorem cert_e739623767866 : check e739623767866 [] .sourceHead = true := by decide
def e739624356718 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e739624356718 : Closed e739624356718 ∧ code e739624356718 = 9535717378926 := by decide
theorem cert_e739624356718 : check e739624356718 [] .sourceHead = true := by decide
def e739624356726 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e739624356726 : Closed e739624356726 ∧ code e739624356726 = 9535717378934 := by decide
theorem cert_e739624356726 : check e739624356726 [] .sourceHead = true := by decide
def e739624356782 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e739624356782 : Closed e739624356782 ∧ code e739624356782 = 9535717378990 := by decide
theorem cert_e739624356782 : check e739624356782 [] .sourceHead = true := by decide
def e739624356794 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e739624356794 : Closed e739624356794 ∧ code e739624356794 = 9535717379002 := by decide
theorem cert_e739624356794 : check e739624356794 [] .sourceHead = true := by decide
def e739624356822 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e739624356822 : Closed e739624356822 ∧ code e739624356822 = 9535717379030 := by decide
theorem cert_e739624356822 : check e739624356822 [] .sourceHead = true := by decide
def e739624356826 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e739624356826 : Closed e739624356826 ∧ code e739624356826 = 9535717379034 := by decide
theorem cert_e739624356826 : check e739624356826 [] .sourceHead = true := by decide
def e739624357102 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e739624357102 : Closed e739624357102 ∧ code e739624357102 = 9535717379310 := by decide
theorem cert_e739624357102 : check e739624357102 [] .sourceHead = true := by decide
def e739624357110 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e739624357110 : Closed e739624357110 ∧ code e739624357110 = 9535717379318 := by decide
theorem cert_e739624357110 : check e739624357110 [] .sourceHead = true := by decide
def e739624357486 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e739624357486 : Closed e739624357486 ∧ code e739624357486 = 9535717379694 := by decide
theorem cert_e739624357486 : check e739624357486 [] .sourceHead = true := by decide
def e739624357498 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e739624357498 : Closed e739624357498 ∧ code e739624357498 = 9535717379706 := by decide
theorem cert_e739624357498 : check e739624357498 [] .sourceHead = true := by decide
def e739624357686 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e739624357686 : Closed e739624357686 ∧ code e739624357686 = 9535717379894 := by decide
theorem cert_e739624357686 : check e739624357686 [] .sourceHead = true := by decide
def e739624357690 : Term := (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e739624357690 : Closed e739624357690 ∧ code e739624357690 = 9535717379898 := by decide
theorem cert_e739624357690 : check e739624357690 [] .sourceHead = true := by decide
def e743040708122 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040708122 : Closed e743040708122 ∧ code e743040708122 = 9539133730330 := by decide
theorem cert_e743040708122 : check e743040708122 [] .sourceHead = true := by decide
def e743040710170 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040710170 : Closed e743040710170 ∧ code e743040710170 = 9539133732378 := by decide
theorem cert_e743040710170 : check e743040710170 [] .sourceHead = true := by decide
def e743040724506 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040724506 : Closed e743040724506 ∧ code e743040724506 = 9539133746714 := by decide
theorem cert_e743040724506 : check e743040724506 [] .sourceHead = true := by decide
def e743040727578 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040727578 : Closed e743040727578 ∧ code e743040727578 = 9539133749786 := by decide
theorem cert_e743040727578 : check e743040727578 [] .sourceHead = true := by decide
def e743040734746 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040734746 : Closed e743040734746 ∧ code e743040734746 = 9539133756954 := by decide
theorem cert_e743040734746 : check e743040734746 [] .sourceHead = true := by decide
def e743040735770 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040735770 : Closed e743040735770 ∧ code e743040735770 = 9539133757978 := by decide
theorem cert_e743040735770 : check e743040735770 [] .sourceHead = true := by decide
def e743040790042 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040790042 : Closed e743040790042 ∧ code e743040790042 = 9539133812250 := by decide
theorem cert_e743040790042 : check e743040790042 [] .sourceHead = true := by decide
def e743040793114 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040793114 : Closed e743040793114 ∧ code e743040793114 = 9539133815322 := by decide
theorem cert_e743040793114 : check e743040793114 [] .sourceHead = true := by decide
def e743040805402 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040805402 : Closed e743040805402 ∧ code e743040805402 = 9539133827610 := by decide
theorem cert_e743040805402 : check e743040805402 [] .sourceHead = true := by decide
def e743040833050 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040833050 : Closed e743040833050 ∧ code e743040833050 = 9539133855258 := by decide
theorem cert_e743040833050 : check e743040833050 [] .sourceHead = true := by decide
def e743040834074 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040834074 : Closed e743040834074 ∧ code e743040834074 = 9539133856282 := by decide
theorem cert_e743040834074 : check e743040834074 [] .sourceHead = true := by decide
def e743040838170 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743040838170 : Closed e743040838170 ∧ code e743040838170 = 9539133860378 := by decide
theorem cert_e743040838170 : check e743040838170 [] .sourceHead = true := by decide
def e743041101338 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041101338 : Closed e743041101338 ∧ code e743041101338 = 9539134123546 := by decide
theorem cert_e743041101338 : check e743041101338 [] .sourceHead = true := by decide
def e743041103386 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041103386 : Closed e743041103386 ∧ code e743041103386 = 9539134125594 := by decide
theorem cert_e743041103386 : check e743041103386 [] .sourceHead = true := by decide
def e743041117722 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041117722 : Closed e743041117722 ∧ code e743041117722 = 9539134139930 := by decide
theorem cert_e743041117722 : check e743041117722 [] .sourceHead = true := by decide
def e743041120794 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041120794 : Closed e743041120794 ∧ code e743041120794 = 9539134143002 := by decide
theorem cert_e743041120794 : check e743041120794 [] .sourceHead = true := by decide
def e743041127962 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041127962 : Closed e743041127962 ∧ code e743041127962 = 9539134150170 := by decide
theorem cert_e743041127962 : check e743041127962 [] .sourceHead = true := by decide
def e743041128986 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041128986 : Closed e743041128986 ∧ code e743041128986 = 9539134151194 := by decide
theorem cert_e743041128986 : check e743041128986 [] .sourceHead = true := by decide
def e743041199642 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041199642 : Closed e743041199642 ∧ code e743041199642 = 9539134221850 := by decide
theorem cert_e743041199642 : check e743041199642 [] .sourceHead = true := by decide
def e743041201690 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041201690 : Closed e743041201690 ∧ code e743041201690 = 9539134223898 := by decide
theorem cert_e743041201690 : check e743041201690 [] .sourceHead = true := by decide
def e743041297946 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041297946 : Closed e743041297946 ∧ code e743041297946 = 9539134320154 := by decide
theorem cert_e743041297946 : check e743041297946 [] .sourceHead = true := by decide
def e743041301018 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041301018 : Closed e743041301018 ∧ code e743041301018 = 9539134323226 := by decide
theorem cert_e743041301018 : check e743041301018 [] .sourceHead = true := by decide
def e743041349146 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041349146 : Closed e743041349146 ∧ code e743041349146 = 9539134371354 := by decide
theorem cert_e743041349146 : check e743041349146 [] .sourceHead = true := by decide
def e743041350170 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041350170 : Closed e743041350170 ∧ code e743041350170 = 9539134372378 := by decide
theorem cert_e743041350170 : check e743041350170 [] .sourceHead = true := by decide
def e743041510938 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041510938 : Closed e743041510938 ∧ code e743041510938 = 9539134533146 := by decide
theorem cert_e743041510938 : check e743041510938 [] .sourceHead = true := by decide
def e743041514010 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041514010 : Closed e743041514010 ∧ code e743041514010 = 9539134536218 := by decide
theorem cert_e743041514010 : check e743041514010 [] .sourceHead = true := by decide
def e743041526298 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041526298 : Closed e743041526298 ∧ code e743041526298 = 9539134548506 := by decide
theorem cert_e743041526298 : check e743041526298 [] .sourceHead = true := by decide
def e743041560090 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041560090 : Closed e743041560090 ∧ code e743041560090 = 9539134582298 := by decide
theorem cert_e743041560090 : check e743041560090 [] .sourceHead = true := by decide
def e743041563162 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041563162 : Closed e743041563162 ∧ code e743041563162 = 9539134585370 := by decide
theorem cert_e743041563162 : check e743041563162 [] .sourceHead = true := by decide
def e743041636890 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041636890 : Closed e743041636890 ∧ code e743041636890 = 9539134659098 := by decide
theorem cert_e743041636890 : check e743041636890 [] .sourceHead = true := by decide
def e743041717786 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041717786 : Closed e743041717786 ∧ code e743041717786 = 9539134739994 := by decide
theorem cert_e743041717786 : check e743041717786 [] .sourceHead = true := by decide
def e743041718810 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041718810 : Closed e743041718810 ∧ code e743041718810 = 9539134741018 := by decide
theorem cert_e743041718810 : check e743041718810 [] .sourceHead = true := by decide
def e743041722906 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041722906 : Closed e743041722906 ∧ code e743041722906 = 9539134745114 := by decide
theorem cert_e743041722906 : check e743041722906 [] .sourceHead = true := by decide
def e743041742362 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041742362 : Closed e743041742362 ∧ code e743041742362 = 9539134764570 := by decide
theorem cert_e743041742362 : check e743041742362 [] .sourceHead = true := by decide
def e743041743386 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041743386 : Closed e743041743386 ∧ code e743041743386 = 9539134765594 := by decide
theorem cert_e743041743386 : check e743041743386 [] .sourceHead = true := by decide
def e743041767962 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743041767962 : Closed e743041767962 ∧ code e743041767962 = 9539134790170 := by decide
theorem cert_e743041767962 : check e743041767962 [] .sourceHead = true := by decide
def e743042674202 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042674202 : Closed e743042674202 ∧ code e743042674202 = 9539135696410 := by decide
theorem cert_e743042674202 : check e743042674202 [] .sourceHead = true := by decide
def e743042676250 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042676250 : Closed e743042676250 ∧ code e743042676250 = 9539135698458 := by decide
theorem cert_e743042676250 : check e743042676250 [] .sourceHead = true := by decide
def e743042690586 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042690586 : Closed e743042690586 ∧ code e743042690586 = 9539135712794 := by decide
theorem cert_e743042690586 : check e743042690586 [] .sourceHead = true := by decide
def e743042693658 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042693658 : Closed e743042693658 ∧ code e743042693658 = 9539135715866 := by decide
theorem cert_e743042693658 : check e743042693658 [] .sourceHead = true := by decide
def e743042700826 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042700826 : Closed e743042700826 ∧ code e743042700826 = 9539135723034 := by decide
theorem cert_e743042700826 : check e743042700826 [] .sourceHead = true := by decide
def e743042701850 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042701850 : Closed e743042701850 ∧ code e743042701850 = 9539135724058 := by decide
theorem cert_e743042701850 : check e743042701850 [] .sourceHead = true := by decide
def e743042772506 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042772506 : Closed e743042772506 ∧ code e743042772506 = 9539135794714 := by decide
theorem cert_e743042772506 : check e743042772506 [] .sourceHead = true := by decide
def e743042774554 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042774554 : Closed e743042774554 ∧ code e743042774554 = 9539135796762 := by decide
theorem cert_e743042774554 : check e743042774554 [] .sourceHead = true := by decide
def e743042870810 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042870810 : Closed e743042870810 ∧ code e743042870810 = 9539135893018 := by decide
theorem cert_e743042870810 : check e743042870810 [] .sourceHead = true := by decide
def e743042873882 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042873882 : Closed e743042873882 ∧ code e743042873882 = 9539135896090 := by decide
theorem cert_e743042873882 : check e743042873882 [] .sourceHead = true := by decide
def e743042922010 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042922010 : Closed e743042922010 ∧ code e743042922010 = 9539135944218 := by decide
theorem cert_e743042922010 : check e743042922010 [] .sourceHead = true := by decide
def e743042923034 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743042923034 : Closed e743042923034 ∧ code e743042923034 = 9539135945242 := by decide
theorem cert_e743042923034 : check e743042923034 [] .sourceHead = true := by decide
def e743044394522 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743044394522 : Closed e743044394522 ∧ code e743044394522 = 9539137416730 := by decide
theorem cert_e743044394522 : check e743044394522 [] .sourceHead = true := by decide
def e743044397594 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743044397594 : Closed e743044397594 ∧ code e743044397594 = 9539137419802 := by decide
theorem cert_e743044397594 : check e743044397594 [] .sourceHead = true := by decide
def e743044409882 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743044409882 : Closed e743044409882 ∧ code e743044409882 = 9539137432090 := by decide
theorem cert_e743044409882 : check e743044409882 [] .sourceHead = true := by decide
def e743044443674 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743044443674 : Closed e743044443674 ∧ code e743044443674 = 9539137465882 := by decide
theorem cert_e743044443674 : check e743044443674 [] .sourceHead = true := by decide
def e743044446746 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743044446746 : Closed e743044446746 ∧ code e743044446746 = 9539137468954 := by decide
theorem cert_e743044446746 : check e743044446746 [] .sourceHead = true := by decide
def e743044520474 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743044520474 : Closed e743044520474 ∧ code e743044520474 = 9539137542682 := by decide
theorem cert_e743044520474 : check e743044520474 [] .sourceHead = true := by decide
def e743045256730 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743045256730 : Closed e743045256730 ∧ code e743045256730 = 9539138278938 := by decide
theorem cert_e743045256730 : check e743045256730 [] .sourceHead = true := by decide
def e743045257754 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743045257754 : Closed e743045257754 ∧ code e743045257754 = 9539138279962 := by decide
theorem cert_e743045257754 : check e743045257754 [] .sourceHead = true := by decide
def e743045261850 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743045261850 : Closed e743045261850 ∧ code e743045261850 = 9539138284058 := by decide
theorem cert_e743045261850 : check e743045261850 [] .sourceHead = true := by decide
def e743045281306 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743045281306 : Closed e743045281306 ∧ code e743045281306 = 9539138303514 := by decide
theorem cert_e743045281306 : check e743045281306 [] .sourceHead = true := by decide
def e743045282330 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743045282330 : Closed e743045282330 ∧ code e743045282330 = 9539138304538 := by decide
theorem cert_e743045282330 : check e743045282330 [] .sourceHead = true := by decide
def e743045306906 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743045306906 : Closed e743045306906 ∧ code e743045306906 = 9539138329114 := by decide
theorem cert_e743045306906 : check e743045306906 [] .sourceHead = true := by decide
def e743080422938 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080422938 : Closed e743080422938 ∧ code e743080422938 = 9539173445146 := by decide
theorem cert_e743080422938 : check e743080422938 [] .sourceHead = true := by decide
def e743080424986 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080424986 : Closed e743080424986 ∧ code e743080424986 = 9539173447194 := by decide
theorem cert_e743080424986 : check e743080424986 [] .sourceHead = true := by decide
def e743080439322 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080439322 : Closed e743080439322 ∧ code e743080439322 = 9539173461530 := by decide
theorem cert_e743080439322 : check e743080439322 [] .sourceHead = true := by decide
def e743080442394 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080442394 : Closed e743080442394 ∧ code e743080442394 = 9539173464602 := by decide
theorem cert_e743080442394 : check e743080442394 [] .sourceHead = true := by decide
def e743080449562 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080449562 : Closed e743080449562 ∧ code e743080449562 = 9539173471770 := by decide
theorem cert_e743080449562 : check e743080449562 [] .sourceHead = true := by decide
def e743080450586 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080450586 : Closed e743080450586 ∧ code e743080450586 = 9539173472794 := by decide
theorem cert_e743080450586 : check e743080450586 [] .sourceHead = true := by decide
def e743080521242 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080521242 : Closed e743080521242 ∧ code e743080521242 = 9539173543450 := by decide
theorem cert_e743080521242 : check e743080521242 [] .sourceHead = true := by decide
def e743080523290 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080523290 : Closed e743080523290 ∧ code e743080523290 = 9539173545498 := by decide
theorem cert_e743080523290 : check e743080523290 [] .sourceHead = true := by decide
def e743080619546 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080619546 : Closed e743080619546 ∧ code e743080619546 = 9539173641754 := by decide
theorem cert_e743080619546 : check e743080619546 [] .sourceHead = true := by decide
def e743080622618 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080622618 : Closed e743080622618 ∧ code e743080622618 = 9539173644826 := by decide
theorem cert_e743080622618 : check e743080622618 [] .sourceHead = true := by decide
def e743080670746 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080670746 : Closed e743080670746 ∧ code e743080670746 = 9539173692954 := by decide
theorem cert_e743080670746 : check e743080670746 [] .sourceHead = true := by decide
def e743080671770 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743080671770 : Closed e743080671770 ∧ code e743080671770 = 9539173693978 := by decide
theorem cert_e743080671770 : check e743080671770 [] .sourceHead = true := by decide
def e743231417882 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231417882 : Closed e743231417882 ∧ code e743231417882 = 9539324440090 := by decide
theorem cert_e743231417882 : check e743231417882 [] .sourceHead = true := by decide
def e743231419930 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231419930 : Closed e743231419930 ∧ code e743231419930 = 9539324442138 := by decide
theorem cert_e743231419930 : check e743231419930 [] .sourceHead = true := by decide
def e743231434266 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231434266 : Closed e743231434266 ∧ code e743231434266 = 9539324456474 := by decide
theorem cert_e743231434266 : check e743231434266 [] .sourceHead = true := by decide
def e743231437338 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231437338 : Closed e743231437338 ∧ code e743231437338 = 9539324459546 := by decide
theorem cert_e743231437338 : check e743231437338 [] .sourceHead = true := by decide
def e743231444506 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231444506 : Closed e743231444506 ∧ code e743231444506 = 9539324466714 := by decide
theorem cert_e743231444506 : check e743231444506 [] .sourceHead = true := by decide
def e743231445530 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231445530 : Closed e743231445530 ∧ code e743231445530 = 9539324467738 := by decide
theorem cert_e743231445530 : check e743231445530 [] .sourceHead = true := by decide
def e743231516186 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231516186 : Closed e743231516186 ∧ code e743231516186 = 9539324538394 := by decide
theorem cert_e743231516186 : check e743231516186 [] .sourceHead = true := by decide
def e743231518234 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231518234 : Closed e743231518234 ∧ code e743231518234 = 9539324540442 := by decide
theorem cert_e743231518234 : check e743231518234 [] .sourceHead = true := by decide
def e743231614490 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231614490 : Closed e743231614490 ∧ code e743231614490 = 9539324636698 := by decide
theorem cert_e743231614490 : check e743231614490 [] .sourceHead = true := by decide
def e743231617562 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231617562 : Closed e743231617562 ∧ code e743231617562 = 9539324639770 := by decide
theorem cert_e743231617562 : check e743231617562 [] .sourceHead = true := by decide
def e743231665690 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231665690 : Closed e743231665690 ∧ code e743231665690 = 9539324687898 := by decide
theorem cert_e743231665690 : check e743231665690 [] .sourceHead = true := by decide
def e743231666714 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e743231666714 : Closed e743231666714 ∧ code e743231666714 = 9539324688922 := by decide
theorem cert_e743231666714 : check e743231666714 [] .sourceHead = true := by decide
def e743247490414 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e743247490414 : Closed e743247490414 ∧ code e743247490414 = 9539340512622 := by decide
theorem cert_e743247490414 : check e743247490414 [] .sourceHead = true := by decide
def e743247490422 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e743247490422 : Closed e743247490422 ∧ code e743247490422 = 9539340512630 := by decide
theorem cert_e743247490422 : check e743247490422 [] .sourceHead = true := by decide
def e743247490478 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e743247490478 : Closed e743247490478 ∧ code e743247490478 = 9539340512686 := by decide
theorem cert_e743247490478 : check e743247490478 [] .sourceHead = true := by decide
def e743247490490 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e743247490490 : Closed e743247490490 ∧ code e743247490490 = 9539340512698 := by decide
theorem cert_e743247490490 : check e743247490490 [] .sourceHead = true := by decide
def e743247490518 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e743247490518 : Closed e743247490518 ∧ code e743247490518 = 9539340512726 := by decide
theorem cert_e743247490518 : check e743247490518 [] .sourceHead = true := by decide
def e743247490522 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e743247490522 : Closed e743247490522 ∧ code e743247490522 = 9539340512730 := by decide
theorem cert_e743247490522 : check e743247490522 [] .sourceHead = true := by decide
def e743247490734 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e743247490734 : Closed e743247490734 ∧ code e743247490734 = 9539340512942 := by decide
theorem cert_e743247490734 : check e743247490734 [] .sourceHead = true := by decide
def e743247490746 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e743247490746 : Closed e743247490746 ∧ code e743247490746 = 9539340512954 := by decide
theorem cert_e743247490746 : check e743247490746 [] .sourceHead = true := by decide
def e743247490794 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e743247490794 : Closed e743247490794 ∧ code e743247490794 = 9539340513002 := by decide
theorem cert_e743247490794 : check e743247490794 [] .sourceHead = true := by decide
def e743247490902 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e743247490902 : Closed e743247490902 ∧ code e743247490902 = 9539340513110 := by decide
theorem cert_e743247490902 : check e743247490902 [] .sourceHead = true := by decide
def e743247490906 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e743247490906 : Closed e743247490906 ∧ code e743247490906 = 9539340513114 := by decide
theorem cert_e743247490906 : check e743247490906 [] .sourceHead = true := by decide
def e743247490922 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e743247490922 : Closed e743247490922 ∧ code e743247490922 = 9539340513130 := by decide
theorem cert_e743247490922 : check e743247490922 [] .sourceHead = true := by decide
def e743247491950 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e743247491950 : Closed e743247491950 ∧ code e743247491950 = 9539340514158 := by decide
theorem cert_e743247491950 : check e743247491950 [] .sourceHead = true := by decide
def e743247491958 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e743247491958 : Closed e743247491958 ∧ code e743247491958 = 9539340514166 := by decide
theorem cert_e743247491958 : check e743247491958 [] .sourceHead = true := by decide
def e743247492014 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e743247492014 : Closed e743247492014 ∧ code e743247492014 = 9539340514222 := by decide
theorem cert_e743247492014 : check e743247492014 [] .sourceHead = true := by decide
def e743247492026 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e743247492026 : Closed e743247492026 ∧ code e743247492026 = 9539340514234 := by decide
theorem cert_e743247492026 : check e743247492026 [] .sourceHead = true := by decide
def e743247492054 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e743247492054 : Closed e743247492054 ∧ code e743247492054 = 9539340514262 := by decide
theorem cert_e743247492054 : check e743247492054 [] .sourceHead = true := by decide
def e743247492058 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e743247492058 : Closed e743247492058 ∧ code e743247492058 = 9539340514266 := by decide
theorem cert_e743247492058 : check e743247492058 [] .sourceHead = true := by decide
def e743247492334 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e743247492334 : Closed e743247492334 ∧ code e743247492334 = 9539340514542 := by decide
theorem cert_e743247492334 : check e743247492334 [] .sourceHead = true := by decide
def e743247492342 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e743247492342 : Closed e743247492342 ∧ code e743247492342 = 9539340514550 := by decide
theorem cert_e743247492342 : check e743247492342 [] .sourceHead = true := by decide
def e743247492718 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e743247492718 : Closed e743247492718 ∧ code e743247492718 = 9539340514926 := by decide
theorem cert_e743247492718 : check e743247492718 [] .sourceHead = true := by decide
def e743247492730 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e743247492730 : Closed e743247492730 ∧ code e743247492730 = 9539340514938 := by decide
theorem cert_e743247492730 : check e743247492730 [] .sourceHead = true := by decide
def e743247492918 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e743247492918 : Closed e743247492918 ∧ code e743247492918 = 9539340515126 := by decide
theorem cert_e743247492918 : check e743247492918 [] .sourceHead = true := by decide
def e743247492922 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e743247492922 : Closed e743247492922 ∧ code e743247492922 = 9539340515130 := by decide
theorem cert_e743247492922 : check e743247492922 [] .sourceHead = true := by decide
def e743247493550 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e743247493550 : Closed e743247493550 ∧ code e743247493550 = 9539340515758 := by decide
theorem cert_e743247493550 : check e743247493550 [] .sourceHead = true := by decide
def e743247493562 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e743247493562 : Closed e743247493562 ∧ code e743247493562 = 9539340515770 := by decide
theorem cert_e743247493562 : check e743247493562 [] .sourceHead = true := by decide
def e743247493610 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e743247493610 : Closed e743247493610 ∧ code e743247493610 = 9539340515818 := by decide
theorem cert_e743247493610 : check e743247493610 [] .sourceHead = true := by decide
def e743247493742 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e743247493742 : Closed e743247493742 ∧ code e743247493742 = 9539340515950 := by decide
theorem cert_e743247493742 : check e743247493742 [] .sourceHead = true := by decide
def e743247493754 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e743247493754 : Closed e743247493754 ∧ code e743247493754 = 9539340515962 := by decide
theorem cert_e743247493754 : check e743247493754 [] .sourceHead = true := by decide
def e743247494042 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e743247494042 : Closed e743247494042 ∧ code e743247494042 = 9539340516250 := by decide
theorem cert_e743247494042 : check e743247494042 [] .sourceHead = true := by decide
def e743247494358 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e743247494358 : Closed e743247494358 ∧ code e743247494358 = 9539340516566 := by decide
theorem cert_e743247494358 : check e743247494358 [] .sourceHead = true := by decide
def e743247494362 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e743247494362 : Closed e743247494362 ∧ code e743247494362 = 9539340516570 := by decide
theorem cert_e743247494362 : check e743247494362 [] .sourceHead = true := by decide
def e743247494378 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e743247494378 : Closed e743247494378 ∧ code e743247494378 = 9539340516586 := by decide
theorem cert_e743247494378 : check e743247494378 [] .sourceHead = true := by decide
def e743247494454 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e743247494454 : Closed e743247494454 ∧ code e743247494454 = 9539340516662 := by decide
theorem cert_e743247494454 : check e743247494454 [] .sourceHead = true := by decide
def e743247494458 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e743247494458 : Closed e743247494458 ∧ code e743247494458 = 9539340516666 := by decide
theorem cert_e743247494458 : check e743247494458 [] .sourceHead = true := by decide
def e743247494554 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e743247494554 : Closed e743247494554 ∧ code e743247494554 = 9539340516762 := by decide
theorem cert_e743247494554 : check e743247494554 [] .sourceHead = true := by decide
def e743247498094 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e743247498094 : Closed e743247498094 ∧ code e743247498094 = 9539340520302 := by decide
theorem cert_e743247498094 : check e743247498094 [] .sourceHead = true := by decide
def e743247498102 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e743247498102 : Closed e743247498102 ∧ code e743247498102 = 9539340520310 := by decide
theorem cert_e743247498102 : check e743247498102 [] .sourceHead = true := by decide
def e743247498158 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e743247498158 : Closed e743247498158 ∧ code e743247498158 = 9539340520366 := by decide
theorem cert_e743247498158 : check e743247498158 [] .sourceHead = true := by decide
def e743247498170 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e743247498170 : Closed e743247498170 ∧ code e743247498170 = 9539340520378 := by decide
theorem cert_e743247498170 : check e743247498170 [] .sourceHead = true := by decide
def e743247498198 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e743247498198 : Closed e743247498198 ∧ code e743247498198 = 9539340520406 := by decide
theorem cert_e743247498198 : check e743247498198 [] .sourceHead = true := by decide
def e743247498202 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e743247498202 : Closed e743247498202 ∧ code e743247498202 = 9539340520410 := by decide
theorem cert_e743247498202 : check e743247498202 [] .sourceHead = true := by decide
end Blc.Floor43
