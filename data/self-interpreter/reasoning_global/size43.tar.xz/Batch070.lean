import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e759337571866 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337571866 : Closed e759337571866 ∧ code e759337571866 = 9555430594074 := by decide
theorem cert_e759337571866 : check e759337571866 [] .sourceHead = true := by decide
def e759337572890 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337572890 : Closed e759337572890 ∧ code e759337572890 = 9555430595098 := by decide
theorem cert_e759337572890 : check e759337572890 [] .sourceHead = true := by decide
def e759337643546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337643546 : Closed e759337643546 ∧ code e759337643546 = 9555430665754 := by decide
theorem cert_e759337643546 : check e759337643546 [] .sourceHead = true := by decide
def e759337645594 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337645594 : Closed e759337645594 ∧ code e759337645594 = 9555430667802 := by decide
theorem cert_e759337645594 : check e759337645594 [] .sourceHead = true := by decide
def e759337741850 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337741850 : Closed e759337741850 ∧ code e759337741850 = 9555430764058 := by decide
theorem cert_e759337741850 : check e759337741850 [] .sourceHead = true := by decide
def e759337744922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337744922 : Closed e759337744922 ∧ code e759337744922 = 9555430767130 := by decide
theorem cert_e759337744922 : check e759337744922 [] .sourceHead = true := by decide
def e759337793050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337793050 : Closed e759337793050 ∧ code e759337793050 = 9555430815258 := by decide
theorem cert_e759337793050 : check e759337793050 [] .sourceHead = true := by decide
def e759337794074 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337794074 : Closed e759337794074 ∧ code e759337794074 = 9555430816282 := by decide
theorem cert_e759337794074 : check e759337794074 [] .sourceHead = true := by decide
def e759353617774 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e759353617774 : Closed e759353617774 ∧ code e759353617774 = 9555446639982 := by decide
theorem cert_e759353617774 : check e759353617774 [] .sourceHead = true := by decide
def e759353617782 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e759353617782 : Closed e759353617782 ∧ code e759353617782 = 9555446639990 := by decide
theorem cert_e759353617782 : check e759353617782 [] .sourceHead = true := by decide
def e759353617838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e759353617838 : Closed e759353617838 ∧ code e759353617838 = 9555446640046 := by decide
theorem cert_e759353617838 : check e759353617838 [] .sourceHead = true := by decide
def e759353617850 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e759353617850 : Closed e759353617850 ∧ code e759353617850 = 9555446640058 := by decide
theorem cert_e759353617850 : check e759353617850 [] .sourceHead = true := by decide
def e759353617878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e759353617878 : Closed e759353617878 ∧ code e759353617878 = 9555446640086 := by decide
theorem cert_e759353617878 : check e759353617878 [] .sourceHead = true := by decide
def e759353617882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e759353617882 : Closed e759353617882 ∧ code e759353617882 = 9555446640090 := by decide
theorem cert_e759353617882 : check e759353617882 [] .sourceHead = true := by decide
def e759353618094 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e759353618094 : Closed e759353618094 ∧ code e759353618094 = 9555446640302 := by decide
theorem cert_e759353618094 : check e759353618094 [] .sourceHead = true := by decide
def e759353618106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e759353618106 : Closed e759353618106 ∧ code e759353618106 = 9555446640314 := by decide
theorem cert_e759353618106 : check e759353618106 [] .sourceHead = true := by decide
def e759353618154 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e759353618154 : Closed e759353618154 ∧ code e759353618154 = 9555446640362 := by decide
theorem cert_e759353618154 : check e759353618154 [] .sourceHead = true := by decide
def e759353618262 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e759353618262 : Closed e759353618262 ∧ code e759353618262 = 9555446640470 := by decide
theorem cert_e759353618262 : check e759353618262 [] .sourceHead = true := by decide
def e759353618266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e759353618266 : Closed e759353618266 ∧ code e759353618266 = 9555446640474 := by decide
theorem cert_e759353618266 : check e759353618266 [] .sourceHead = true := by decide
def e759353618282 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e759353618282 : Closed e759353618282 ∧ code e759353618282 = 9555446640490 := by decide
theorem cert_e759353618282 : check e759353618282 [] .sourceHead = true := by decide
def e759353619310 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e759353619310 : Closed e759353619310 ∧ code e759353619310 = 9555446641518 := by decide
theorem cert_e759353619310 : check e759353619310 [] .sourceHead = true := by decide
def e759353619318 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e759353619318 : Closed e759353619318 ∧ code e759353619318 = 9555446641526 := by decide
theorem cert_e759353619318 : check e759353619318 [] .sourceHead = true := by decide
def e759353619374 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e759353619374 : Closed e759353619374 ∧ code e759353619374 = 9555446641582 := by decide
theorem cert_e759353619374 : check e759353619374 [] .sourceHead = true := by decide
def e759353619386 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e759353619386 : Closed e759353619386 ∧ code e759353619386 = 9555446641594 := by decide
theorem cert_e759353619386 : check e759353619386 [] .sourceHead = true := by decide
def e759353619414 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e759353619414 : Closed e759353619414 ∧ code e759353619414 = 9555446641622 := by decide
theorem cert_e759353619414 : check e759353619414 [] .sourceHead = true := by decide
def e759353619418 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e759353619418 : Closed e759353619418 ∧ code e759353619418 = 9555446641626 := by decide
theorem cert_e759353619418 : check e759353619418 [] .sourceHead = true := by decide
def e759353619694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e759353619694 : Closed e759353619694 ∧ code e759353619694 = 9555446641902 := by decide
theorem cert_e759353619694 : check e759353619694 [] .sourceHead = true := by decide
def e759353619702 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e759353619702 : Closed e759353619702 ∧ code e759353619702 = 9555446641910 := by decide
theorem cert_e759353619702 : check e759353619702 [] .sourceHead = true := by decide
def e759353620078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e759353620078 : Closed e759353620078 ∧ code e759353620078 = 9555446642286 := by decide
theorem cert_e759353620078 : check e759353620078 [] .sourceHead = true := by decide
def e759353620090 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e759353620090 : Closed e759353620090 ∧ code e759353620090 = 9555446642298 := by decide
theorem cert_e759353620090 : check e759353620090 [] .sourceHead = true := by decide
def e759353620278 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e759353620278 : Closed e759353620278 ∧ code e759353620278 = 9555446642486 := by decide
theorem cert_e759353620278 : check e759353620278 [] .sourceHead = true := by decide
def e759353620282 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e759353620282 : Closed e759353620282 ∧ code e759353620282 = 9555446642490 := by decide
theorem cert_e759353620282 : check e759353620282 [] .sourceHead = true := by decide
def e759353620910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e759353620910 : Closed e759353620910 ∧ code e759353620910 = 9555446643118 := by decide
theorem cert_e759353620910 : check e759353620910 [] .sourceHead = true := by decide
def e759353620922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e759353620922 : Closed e759353620922 ∧ code e759353620922 = 9555446643130 := by decide
theorem cert_e759353620922 : check e759353620922 [] .sourceHead = true := by decide
def e759353620970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e759353620970 : Closed e759353620970 ∧ code e759353620970 = 9555446643178 := by decide
theorem cert_e759353620970 : check e759353620970 [] .sourceHead = true := by decide
def e759353621102 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e759353621102 : Closed e759353621102 ∧ code e759353621102 = 9555446643310 := by decide
theorem cert_e759353621102 : check e759353621102 [] .sourceHead = true := by decide
def e759353621114 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e759353621114 : Closed e759353621114 ∧ code e759353621114 = 9555446643322 := by decide
theorem cert_e759353621114 : check e759353621114 [] .sourceHead = true := by decide
def e759353621402 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e759353621402 : Closed e759353621402 ∧ code e759353621402 = 9555446643610 := by decide
theorem cert_e759353621402 : check e759353621402 [] .sourceHead = true := by decide
def e759353621718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e759353621718 : Closed e759353621718 ∧ code e759353621718 = 9555446643926 := by decide
theorem cert_e759353621718 : check e759353621718 [] .sourceHead = true := by decide
def e759353621722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e759353621722 : Closed e759353621722 ∧ code e759353621722 = 9555446643930 := by decide
theorem cert_e759353621722 : check e759353621722 [] .sourceHead = true := by decide
def e759353621738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e759353621738 : Closed e759353621738 ∧ code e759353621738 = 9555446643946 := by decide
theorem cert_e759353621738 : check e759353621738 [] .sourceHead = true := by decide
def e759353621814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e759353621814 : Closed e759353621814 ∧ code e759353621814 = 9555446644022 := by decide
theorem cert_e759353621814 : check e759353621814 [] .sourceHead = true := by decide
def e759353621818 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e759353621818 : Closed e759353621818 ∧ code e759353621818 = 9555446644026 := by decide
theorem cert_e759353621818 : check e759353621818 [] .sourceHead = true := by decide
def e759353621914 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e759353621914 : Closed e759353621914 ∧ code e759353621914 = 9555446644122 := by decide
theorem cert_e759353621914 : check e759353621914 [] .sourceHead = true := by decide
def e759353625454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e759353625454 : Closed e759353625454 ∧ code e759353625454 = 9555446647662 := by decide
theorem cert_e759353625454 : check e759353625454 [] .sourceHead = true := by decide
def e759353625462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e759353625462 : Closed e759353625462 ∧ code e759353625462 = 9555446647670 := by decide
theorem cert_e759353625462 : check e759353625462 [] .sourceHead = true := by decide
def e759353625518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e759353625518 : Closed e759353625518 ∧ code e759353625518 = 9555446647726 := by decide
theorem cert_e759353625518 : check e759353625518 [] .sourceHead = true := by decide
def e759353625530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e759353625530 : Closed e759353625530 ∧ code e759353625530 = 9555446647738 := by decide
theorem cert_e759353625530 : check e759353625530 [] .sourceHead = true := by decide
def e759353625558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e759353625558 : Closed e759353625558 ∧ code e759353625558 = 9555446647766 := by decide
theorem cert_e759353625558 : check e759353625558 [] .sourceHead = true := by decide
def e759353625562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e759353625562 : Closed e759353625562 ∧ code e759353625562 = 9555446647770 := by decide
theorem cert_e759353625562 : check e759353625562 [] .sourceHead = true := by decide
def e759353625838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e759353625838 : Closed e759353625838 ∧ code e759353625838 = 9555446648046 := by decide
theorem cert_e759353625838 : check e759353625838 [] .sourceHead = true := by decide
def e759353625846 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e759353625846 : Closed e759353625846 ∧ code e759353625846 = 9555446648054 := by decide
theorem cert_e759353625846 : check e759353625846 [] .sourceHead = true := by decide
def e759353626222 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e759353626222 : Closed e759353626222 ∧ code e759353626222 = 9555446648430 := by decide
theorem cert_e759353626222 : check e759353626222 [] .sourceHead = true := by decide
def e759353626234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e759353626234 : Closed e759353626234 ∧ code e759353626234 = 9555446648442 := by decide
theorem cert_e759353626234 : check e759353626234 [] .sourceHead = true := by decide
def e759353626422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e759353626422 : Closed e759353626422 ∧ code e759353626422 = 9555446648630 := by decide
theorem cert_e759353626422 : check e759353626422 [] .sourceHead = true := by decide
def e759353626426 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e759353626426 : Closed e759353626426 ∧ code e759353626426 = 9555446648634 := by decide
theorem cert_e759353626426 : check e759353626426 [] .sourceHead = true := by decide
def e759353632174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e759353632174 : Closed e759353632174 ∧ code e759353632174 = 9555446654382 := by decide
theorem cert_e759353632174 : check e759353632174 [] .sourceHead = true := by decide
def e759353632186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e759353632186 : Closed e759353632186 ∧ code e759353632186 = 9555446654394 := by decide
theorem cert_e759353632186 : check e759353632186 [] .sourceHead = true := by decide
def e759353632234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e759353632234 : Closed e759353632234 ∧ code e759353632234 = 9555446654442 := by decide
theorem cert_e759353632234 : check e759353632234 [] .sourceHead = true := by decide
def e759353632366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e759353632366 : Closed e759353632366 ∧ code e759353632366 = 9555446654574 := by decide
theorem cert_e759353632366 : check e759353632366 [] .sourceHead = true := by decide
def e759353632378 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e759353632378 : Closed e759353632378 ∧ code e759353632378 = 9555446654586 := by decide
theorem cert_e759353632378 : check e759353632378 [] .sourceHead = true := by decide
def e759353632666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e759353632666 : Closed e759353632666 ∧ code e759353632666 = 9555446654874 := by decide
theorem cert_e759353632666 : check e759353632666 [] .sourceHead = true := by decide
def e759353635542 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e759353635542 : Closed e759353635542 ∧ code e759353635542 = 9555446657750 := by decide
theorem cert_e759353635542 : check e759353635542 [] .sourceHead = true := by decide
def e759353635546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e759353635546 : Closed e759353635546 ∧ code e759353635546 = 9555446657754 := by decide
theorem cert_e759353635546 : check e759353635546 [] .sourceHead = true := by decide
def e759353635562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e759353635562 : Closed e759353635562 ∧ code e759353635562 = 9555446657770 := by decide
theorem cert_e759353635562 : check e759353635562 [] .sourceHead = true := by decide
def e759353635638 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e759353635638 : Closed e759353635638 ∧ code e759353635638 = 9555446657846 := by decide
theorem cert_e759353635638 : check e759353635638 [] .sourceHead = true := by decide
def e759353635642 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e759353635642 : Closed e759353635642 ∧ code e759353635642 = 9555446657850 := by decide
theorem cert_e759353635642 : check e759353635642 [] .sourceHead = true := by decide
def e759353635738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e759353635738 : Closed e759353635738 ∧ code e759353635738 = 9555446657946 := by decide
theorem cert_e759353635738 : check e759353635738 [] .sourceHead = true := by decide
def e759353772910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e759353772910 : Closed e759353772910 ∧ code e759353772910 = 9555446795118 := by decide
theorem cert_e759353772910 : check e759353772910 [] .sourceHead = true := by decide
def e759353772918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e759353772918 : Closed e759353772918 ∧ code e759353772918 = 9555446795126 := by decide
theorem cert_e759353772918 : check e759353772918 [] .sourceHead = true := by decide
def e759353772974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e759353772974 : Closed e759353772974 ∧ code e759353772974 = 9555446795182 := by decide
theorem cert_e759353772974 : check e759353772974 [] .sourceHead = true := by decide
def e759353772986 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e759353772986 : Closed e759353772986 ∧ code e759353772986 = 9555446795194 := by decide
theorem cert_e759353772986 : check e759353772986 [] .sourceHead = true := by decide
def e759353773014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e759353773014 : Closed e759353773014 ∧ code e759353773014 = 9555446795222 := by decide
theorem cert_e759353773014 : check e759353773014 [] .sourceHead = true := by decide
def e759353773018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e759353773018 : Closed e759353773018 ∧ code e759353773018 = 9555446795226 := by decide
theorem cert_e759353773018 : check e759353773018 [] .sourceHead = true := by decide
def e759353773294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e759353773294 : Closed e759353773294 ∧ code e759353773294 = 9555446795502 := by decide
theorem cert_e759353773294 : check e759353773294 [] .sourceHead = true := by decide
def e759353773302 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e759353773302 : Closed e759353773302 ∧ code e759353773302 = 9555446795510 := by decide
theorem cert_e759353773302 : check e759353773302 [] .sourceHead = true := by decide
def e759353773678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e759353773678 : Closed e759353773678 ∧ code e759353773678 = 9555446795886 := by decide
theorem cert_e759353773678 : check e759353773678 [] .sourceHead = true := by decide
def e759353773690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e759353773690 : Closed e759353773690 ∧ code e759353773690 = 9555446795898 := by decide
theorem cert_e759353773690 : check e759353773690 [] .sourceHead = true := by decide
def e759353773878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e759353773878 : Closed e759353773878 ∧ code e759353773878 = 9555446796086 := by decide
theorem cert_e759353773878 : check e759353773878 [] .sourceHead = true := by decide
def e759353773882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e759353773882 : Closed e759353773882 ∧ code e759353773882 = 9555446796090 := by decide
theorem cert_e759353773882 : check e759353773882 [] .sourceHead = true := by decide
def e759354362734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e759354362734 : Closed e759354362734 ∧ code e759354362734 = 9555447384942 := by decide
theorem cert_e759354362734 : check e759354362734 [] .sourceHead = true := by decide
def e759354362742 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e759354362742 : Closed e759354362742 ∧ code e759354362742 = 9555447384950 := by decide
theorem cert_e759354362742 : check e759354362742 [] .sourceHead = true := by decide
def e759354362798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e759354362798 : Closed e759354362798 ∧ code e759354362798 = 9555447385006 := by decide
theorem cert_e759354362798 : check e759354362798 [] .sourceHead = true := by decide
def e759354362810 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e759354362810 : Closed e759354362810 ∧ code e759354362810 = 9555447385018 := by decide
theorem cert_e759354362810 : check e759354362810 [] .sourceHead = true := by decide
def e759354362838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e759354362838 : Closed e759354362838 ∧ code e759354362838 = 9555447385046 := by decide
theorem cert_e759354362838 : check e759354362838 [] .sourceHead = true := by decide
def e759354362842 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e759354362842 : Closed e759354362842 ∧ code e759354362842 = 9555447385050 := by decide
theorem cert_e759354362842 : check e759354362842 [] .sourceHead = true := by decide
def e759354363118 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e759354363118 : Closed e759354363118 ∧ code e759354363118 = 9555447385326 := by decide
theorem cert_e759354363118 : check e759354363118 [] .sourceHead = true := by decide
def e759354363126 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e759354363126 : Closed e759354363126 ∧ code e759354363126 = 9555447385334 := by decide
theorem cert_e759354363126 : check e759354363126 [] .sourceHead = true := by decide
def e759354363502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e759354363502 : Closed e759354363502 ∧ code e759354363502 = 9555447385710 := by decide
theorem cert_e759354363502 : check e759354363502 [] .sourceHead = true := by decide
def e759354363514 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e759354363514 : Closed e759354363514 ∧ code e759354363514 = 9555447385722 := by decide
theorem cert_e759354363514 : check e759354363514 [] .sourceHead = true := by decide
def e759354363702 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e759354363702 : Closed e759354363702 ∧ code e759354363702 = 9555447385910 := by decide
theorem cert_e759354363702 : check e759354363702 [] .sourceHead = true := by decide
def e759354363706 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e759354363706 : Closed e759354363706 ∧ code e759354363706 = 9555447385914 := by decide
theorem cert_e759354363706 : check e759354363706 [] .sourceHead = true := by decide
def e759403949422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e759403949422 : Closed e759403949422 ∧ code e759403949422 = 9555496971630 := by decide
theorem cert_e759403949422 : check e759403949422 [] .sourceHead = true := by decide
def e759403949430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e759403949430 : Closed e759403949430 ∧ code e759403949430 = 9555496971638 := by decide
theorem cert_e759403949430 : check e759403949430 [] .sourceHead = true := by decide
def e759403949486 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e759403949486 : Closed e759403949486 ∧ code e759403949486 = 9555496971694 := by decide
theorem cert_e759403949486 : check e759403949486 [] .sourceHead = true := by decide
def e759403949498 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e759403949498 : Closed e759403949498 ∧ code e759403949498 = 9555496971706 := by decide
theorem cert_e759403949498 : check e759403949498 [] .sourceHead = true := by decide
def e759403949526 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e759403949526 : Closed e759403949526 ∧ code e759403949526 = 9555496971734 := by decide
theorem cert_e759403949526 : check e759403949526 [] .sourceHead = true := by decide
def e759403949530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e759403949530 : Closed e759403949530 ∧ code e759403949530 = 9555496971738 := by decide
theorem cert_e759403949530 : check e759403949530 [] .sourceHead = true := by decide
def e759403949742 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e759403949742 : Closed e759403949742 ∧ code e759403949742 = 9555496971950 := by decide
theorem cert_e759403949742 : check e759403949742 [] .sourceHead = true := by decide
def e759403949754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e759403949754 : Closed e759403949754 ∧ code e759403949754 = 9555496971962 := by decide
theorem cert_e759403949754 : check e759403949754 [] .sourceHead = true := by decide
def e759403949802 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e759403949802 : Closed e759403949802 ∧ code e759403949802 = 9555496972010 := by decide
theorem cert_e759403949802 : check e759403949802 [] .sourceHead = true := by decide
def e759403949910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e759403949910 : Closed e759403949910 ∧ code e759403949910 = 9555496972118 := by decide
theorem cert_e759403949910 : check e759403949910 [] .sourceHead = true := by decide
def e759403949914 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e759403949914 : Closed e759403949914 ∧ code e759403949914 = 9555496972122 := by decide
theorem cert_e759403949914 : check e759403949914 [] .sourceHead = true := by decide
def e759403949930 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e759403949930 : Closed e759403949930 ∧ code e759403949930 = 9555496972138 := by decide
theorem cert_e759403949930 : check e759403949930 [] .sourceHead = true := by decide
def e759403950958 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e759403950958 : Closed e759403950958 ∧ code e759403950958 = 9555496973166 := by decide
theorem cert_e759403950958 : check e759403950958 [] .sourceHead = true := by decide
def e759403950966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e759403950966 : Closed e759403950966 ∧ code e759403950966 = 9555496973174 := by decide
theorem cert_e759403950966 : check e759403950966 [] .sourceHead = true := by decide
def e759403951022 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e759403951022 : Closed e759403951022 ∧ code e759403951022 = 9555496973230 := by decide
theorem cert_e759403951022 : check e759403951022 [] .sourceHead = true := by decide
def e759403951034 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e759403951034 : Closed e759403951034 ∧ code e759403951034 = 9555496973242 := by decide
theorem cert_e759403951034 : check e759403951034 [] .sourceHead = true := by decide
def e759403951062 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e759403951062 : Closed e759403951062 ∧ code e759403951062 = 9555496973270 := by decide
theorem cert_e759403951062 : check e759403951062 [] .sourceHead = true := by decide
def e759403951066 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e759403951066 : Closed e759403951066 ∧ code e759403951066 = 9555496973274 := by decide
theorem cert_e759403951066 : check e759403951066 [] .sourceHead = true := by decide
def e759403951342 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e759403951342 : Closed e759403951342 ∧ code e759403951342 = 9555496973550 := by decide
theorem cert_e759403951342 : check e759403951342 [] .sourceHead = true := by decide
def e759403951350 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e759403951350 : Closed e759403951350 ∧ code e759403951350 = 9555496973558 := by decide
theorem cert_e759403951350 : check e759403951350 [] .sourceHead = true := by decide
def e759403951726 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e759403951726 : Closed e759403951726 ∧ code e759403951726 = 9555496973934 := by decide
theorem cert_e759403951726 : check e759403951726 [] .sourceHead = true := by decide
def e759403951738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e759403951738 : Closed e759403951738 ∧ code e759403951738 = 9555496973946 := by decide
theorem cert_e759403951738 : check e759403951738 [] .sourceHead = true := by decide
def e759403951926 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e759403951926 : Closed e759403951926 ∧ code e759403951926 = 9555496974134 := by decide
theorem cert_e759403951926 : check e759403951926 [] .sourceHead = true := by decide
def e759403951930 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e759403951930 : Closed e759403951930 ∧ code e759403951930 = 9555496974138 := by decide
theorem cert_e759403951930 : check e759403951930 [] .sourceHead = true := by decide
def e759403952558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e759403952558 : Closed e759403952558 ∧ code e759403952558 = 9555496974766 := by decide
theorem cert_e759403952558 : check e759403952558 [] .sourceHead = true := by decide
def e759403952570 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e759403952570 : Closed e759403952570 ∧ code e759403952570 = 9555496974778 := by decide
theorem cert_e759403952570 : check e759403952570 [] .sourceHead = true := by decide
def e759403952618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e759403952618 : Closed e759403952618 ∧ code e759403952618 = 9555496974826 := by decide
theorem cert_e759403952618 : check e759403952618 [] .sourceHead = true := by decide
def e759403952750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e759403952750 : Closed e759403952750 ∧ code e759403952750 = 9555496974958 := by decide
theorem cert_e759403952750 : check e759403952750 [] .sourceHead = true := by decide
def e759403952762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e759403952762 : Closed e759403952762 ∧ code e759403952762 = 9555496974970 := by decide
theorem cert_e759403952762 : check e759403952762 [] .sourceHead = true := by decide
def e759403953050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e759403953050 : Closed e759403953050 ∧ code e759403953050 = 9555496975258 := by decide
theorem cert_e759403953050 : check e759403953050 [] .sourceHead = true := by decide
def e759403953366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e759403953366 : Closed e759403953366 ∧ code e759403953366 = 9555496975574 := by decide
theorem cert_e759403953366 : check e759403953366 [] .sourceHead = true := by decide
def e759403953370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e759403953370 : Closed e759403953370 ∧ code e759403953370 = 9555496975578 := by decide
theorem cert_e759403953370 : check e759403953370 [] .sourceHead = true := by decide
def e759403953386 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e759403953386 : Closed e759403953386 ∧ code e759403953386 = 9555496975594 := by decide
theorem cert_e759403953386 : check e759403953386 [] .sourceHead = true := by decide
def e759403953462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e759403953462 : Closed e759403953462 ∧ code e759403953462 = 9555496975670 := by decide
theorem cert_e759403953462 : check e759403953462 [] .sourceHead = true := by decide
def e759403953466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e759403953466 : Closed e759403953466 ∧ code e759403953466 = 9555496975674 := by decide
theorem cert_e759403953466 : check e759403953466 [] .sourceHead = true := by decide
def e759403953562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e759403953562 : Closed e759403953562 ∧ code e759403953562 = 9555496975770 := by decide
theorem cert_e759403953562 : check e759403953562 [] .sourceHead = true := by decide
def e759403957102 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e759403957102 : Closed e759403957102 ∧ code e759403957102 = 9555496979310 := by decide
theorem cert_e759403957102 : check e759403957102 [] .sourceHead = true := by decide
def e759403957110 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e759403957110 : Closed e759403957110 ∧ code e759403957110 = 9555496979318 := by decide
theorem cert_e759403957110 : check e759403957110 [] .sourceHead = true := by decide
def e759403957166 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e759403957166 : Closed e759403957166 ∧ code e759403957166 = 9555496979374 := by decide
theorem cert_e759403957166 : check e759403957166 [] .sourceHead = true := by decide
def e759403957178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e759403957178 : Closed e759403957178 ∧ code e759403957178 = 9555496979386 := by decide
theorem cert_e759403957178 : check e759403957178 [] .sourceHead = true := by decide
def e759403957206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e759403957206 : Closed e759403957206 ∧ code e759403957206 = 9555496979414 := by decide
theorem cert_e759403957206 : check e759403957206 [] .sourceHead = true := by decide
def e759403957210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e759403957210 : Closed e759403957210 ∧ code e759403957210 = 9555496979418 := by decide
theorem cert_e759403957210 : check e759403957210 [] .sourceHead = true := by decide
def e759403957486 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e759403957486 : Closed e759403957486 ∧ code e759403957486 = 9555496979694 := by decide
theorem cert_e759403957486 : check e759403957486 [] .sourceHead = true := by decide
def e759403957494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e759403957494 : Closed e759403957494 ∧ code e759403957494 = 9555496979702 := by decide
theorem cert_e759403957494 : check e759403957494 [] .sourceHead = true := by decide
def e759403957870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e759403957870 : Closed e759403957870 ∧ code e759403957870 = 9555496980078 := by decide
theorem cert_e759403957870 : check e759403957870 [] .sourceHead = true := by decide
def e759403957882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e759403957882 : Closed e759403957882 ∧ code e759403957882 = 9555496980090 := by decide
theorem cert_e759403957882 : check e759403957882 [] .sourceHead = true := by decide
def e759403958070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e759403958070 : Closed e759403958070 ∧ code e759403958070 = 9555496980278 := by decide
theorem cert_e759403958070 : check e759403958070 [] .sourceHead = true := by decide
def e759403958074 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e759403958074 : Closed e759403958074 ∧ code e759403958074 = 9555496980282 := by decide
theorem cert_e759403958074 : check e759403958074 [] .sourceHead = true := by decide
def e759403963822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e759403963822 : Closed e759403963822 ∧ code e759403963822 = 9555496986030 := by decide
theorem cert_e759403963822 : check e759403963822 [] .sourceHead = true := by decide
def e759403963834 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e759403963834 : Closed e759403963834 ∧ code e759403963834 = 9555496986042 := by decide
theorem cert_e759403963834 : check e759403963834 [] .sourceHead = true := by decide
def e759403963882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e759403963882 : Closed e759403963882 ∧ code e759403963882 = 9555496986090 := by decide
theorem cert_e759403963882 : check e759403963882 [] .sourceHead = true := by decide
def e759403964014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e759403964014 : Closed e759403964014 ∧ code e759403964014 = 9555496986222 := by decide
theorem cert_e759403964014 : check e759403964014 [] .sourceHead = true := by decide
def e759403964026 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e759403964026 : Closed e759403964026 ∧ code e759403964026 = 9555496986234 := by decide
theorem cert_e759403964026 : check e759403964026 [] .sourceHead = true := by decide
def e759403964314 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e759403964314 : Closed e759403964314 ∧ code e759403964314 = 9555496986522 := by decide
theorem cert_e759403964314 : check e759403964314 [] .sourceHead = true := by decide
def e759403967190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e759403967190 : Closed e759403967190 ∧ code e759403967190 = 9555496989398 := by decide
theorem cert_e759403967190 : check e759403967190 [] .sourceHead = true := by decide
def e759403967194 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e759403967194 : Closed e759403967194 ∧ code e759403967194 = 9555496989402 := by decide
theorem cert_e759403967194 : check e759403967194 [] .sourceHead = true := by decide
def e759403967210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e759403967210 : Closed e759403967210 ∧ code e759403967210 = 9555496989418 := by decide
theorem cert_e759403967210 : check e759403967210 [] .sourceHead = true := by decide
def e759403967286 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e759403967286 : Closed e759403967286 ∧ code e759403967286 = 9555496989494 := by decide
theorem cert_e759403967286 : check e759403967286 [] .sourceHead = true := by decide
def e759403967290 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e759403967290 : Closed e759403967290 ∧ code e759403967290 = 9555496989498 := by decide
theorem cert_e759403967290 : check e759403967290 [] .sourceHead = true := by decide
def e759403967386 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e759403967386 : Closed e759403967386 ∧ code e759403967386 = 9555496989594 := by decide
theorem cert_e759403967386 : check e759403967386 [] .sourceHead = true := by decide
def e759404082654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e759404082654 : Closed e759404082654 ∧ code e759404082654 = 9555497104862 := by decide
theorem cert_e759404082654 : check e759404082654 [] .sourceHead = true := by decide
def e759404082670 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e759404082670 : Closed e759404082670 ∧ code e759404082670 = 9555497104878 := by decide
theorem cert_e759404082670 : check e759404082670 [] .sourceHead = true := by decide
def e759404082910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e759404082910 : Closed e759404082910 ∧ code e759404082910 = 9555497105118 := by decide
theorem cert_e759404082910 : check e759404082910 [] .sourceHead = true := by decide
def e759404082926 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e759404082926 : Closed e759404082926 ∧ code e759404082926 = 9555497105134 := by decide
theorem cert_e759404082926 : check e759404082926 [] .sourceHead = true := by decide
def e759404082934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e759404082934 : Closed e759404082934 ∧ code e759404082934 = 9555497105142 := by decide
theorem cert_e759404082934 : check e759404082934 [] .sourceHead = true := by decide
def e759404083038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e759404083038 : Closed e759404083038 ∧ code e759404083038 = 9555497105246 := by decide
theorem cert_e759404083038 : check e759404083038 [] .sourceHead = true := by decide
def e759404083054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e759404083054 : Closed e759404083054 ∧ code e759404083054 = 9555497105262 := by decide
theorem cert_e759404083054 : check e759404083054 [] .sourceHead = true := by decide
def e759404083062 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e759404083062 : Closed e759404083062 ∧ code e759404083062 = 9555497105270 := by decide
theorem cert_e759404083062 : check e759404083062 [] .sourceHead = true := by decide
end Blc.Floor43
