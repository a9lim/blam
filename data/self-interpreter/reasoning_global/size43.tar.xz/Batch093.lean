import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e833983024366 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e833983024366 : Closed e833983024366 ∧ code e833983024366 = 9630076046574 := by decide
theorem cert_e833983024366 : check e833983024366 [] .sourceHead = true := by decide
def e833983024374 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e833983024374 : Closed e833983024374 ∧ code e833983024374 = 9630076046582 := by decide
theorem cert_e833983024374 : check e833983024374 [] .sourceHead = true := by decide
def e833983024750 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e833983024750 : Closed e833983024750 ∧ code e833983024750 = 9630076046958 := by decide
theorem cert_e833983024750 : check e833983024750 [] .sourceHead = true := by decide
def e833983024762 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e833983024762 : Closed e833983024762 ∧ code e833983024762 = 9630076046970 := by decide
theorem cert_e833983024762 : check e833983024762 [] .sourceHead = true := by decide
def e833983024950 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e833983024950 : Closed e833983024950 ∧ code e833983024950 = 9630076047158 := by decide
theorem cert_e833983024950 : check e833983024950 [] .sourceHead = true := by decide
def e833983024954 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e833983024954 : Closed e833983024954 ∧ code e833983024954 = 9630076047162 := by decide
theorem cert_e833983024954 : check e833983024954 [] .sourceHead = true := by decide
def e834031958042 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834031958042 : Closed e834031958042 ∧ code e834031958042 = 9630124980250 := by decide
theorem cert_e834031958042 : check e834031958042 [] .sourceHead = true := by decide
def e834031966234 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834031966234 : Closed e834031966234 ∧ code e834031966234 = 9630124988442 := by decide
theorem cert_e834031966234 : check e834031966234 [] .sourceHead = true := by decide
def e834032023578 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032023578 : Closed e834032023578 ∧ code e834032023578 = 9630125045786 := by decide
theorem cert_e834032023578 : check e834032023578 [] .sourceHead = true := by decide
def e834032035866 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032035866 : Closed e834032035866 ∧ code e834032035866 = 9630125058074 := by decide
theorem cert_e834032035866 : check e834032035866 [] .sourceHead = true := by decide
def e834032064538 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032064538 : Closed e834032064538 ∧ code e834032064538 = 9630125086746 := by decide
theorem cert_e834032064538 : check e834032064538 [] .sourceHead = true := by decide
def e834032068634 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032068634 : Closed e834032068634 ∧ code e834032068634 = 9630125090842 := by decide
theorem cert_e834032068634 : check e834032068634 [] .sourceHead = true := by decide
def e834032351258 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032351258 : Closed e834032351258 ∧ code e834032351258 = 9630125373466 := by decide
theorem cert_e834032351258 : check e834032351258 [] .sourceHead = true := by decide
def e834032359450 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032359450 : Closed e834032359450 ∧ code e834032359450 = 9630125381658 := by decide
theorem cert_e834032359450 : check e834032359450 [] .sourceHead = true := by decide
def e834032744474 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032744474 : Closed e834032744474 ∧ code e834032744474 = 9630125766682 := by decide
theorem cert_e834032744474 : check e834032744474 [] .sourceHead = true := by decide
def e834032756762 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032756762 : Closed e834032756762 ∧ code e834032756762 = 9630125778970 := by decide
theorem cert_e834032756762 : check e834032756762 [] .sourceHead = true := by decide
def e834032949274 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032949274 : Closed e834032949274 ∧ code e834032949274 = 9630125971482 := by decide
theorem cert_e834032949274 : check e834032949274 [] .sourceHead = true := by decide
def e834032953370 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834032953370 : Closed e834032953370 ∧ code e834032953370 = 9630125975578 := by decide
theorem cert_e834032953370 : check e834032953370 [] .sourceHead = true := by decide
def e834040946714 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834040946714 : Closed e834040946714 ∧ code e834040946714 = 9630133968922 := by decide
theorem cert_e834040946714 : check e834040946714 [] .sourceHead = true := by decide
def e834040946806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834040946806 : Closed e834040946806 ∧ code e834040946806 = 9630133969014 := by decide
theorem cert_e834040946806 : check e834040946806 [] .sourceHead = true := by decide
def e834040947050 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834040947050 : Closed e834040947050 ∧ code e834040947050 = 9630133969258 := by decide
theorem cert_e834040947050 : check e834040947050 [] .sourceHead = true := by decide
def e834040947098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834040947098 : Closed e834040947098 ∧ code e834040947098 = 9630133969306 := by decide
theorem cert_e834040947098 : check e834040947098 [] .sourceHead = true := by decide
def e834040948250 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834040948250 : Closed e834040948250 ∧ code e834040948250 = 9630133970458 := by decide
theorem cert_e834040948250 : check e834040948250 [] .sourceHead = true := by decide
def e834040979482 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834040979482 : Closed e834040979482 ∧ code e834040979482 = 9630134001690 := by decide
theorem cert_e834040979482 : check e834040979482 [] .sourceHead = true := by decide
def e834040979574 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834040979574 : Closed e834040979574 ∧ code e834040979574 = 9630134001782 := by decide
theorem cert_e834040979574 : check e834040979574 [] .sourceHead = true := by decide
def e834040979818 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834040979818 : Closed e834040979818 ∧ code e834040979818 = 9630134002026 := by decide
theorem cert_e834040979818 : check e834040979818 [] .sourceHead = true := by decide
def e834040979866 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834040979866 : Closed e834040979866 ∧ code e834040979866 = 9630134002074 := by decide
theorem cert_e834040979866 : check e834040979866 [] .sourceHead = true := by decide
def e834040981018 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834040981018 : Closed e834040981018 ∧ code e834040981018 = 9630134003226 := by decide
theorem cert_e834040981018 : check e834040981018 [] .sourceHead = true := by decide
def e834041208858 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834041208858 : Closed e834041208858 ∧ code e834041208858 = 9630134231066 := by decide
theorem cert_e834041208858 : check e834041208858 [] .sourceHead = true := by decide
def e834041208950 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834041208950 : Closed e834041208950 ∧ code e834041208950 = 9630134231158 := by decide
theorem cert_e834041208950 : check e834041208950 [] .sourceHead = true := by decide
def e834041209194 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834041209194 : Closed e834041209194 ∧ code e834041209194 = 9630134231402 := by decide
theorem cert_e834041209194 : check e834041209194 [] .sourceHead = true := by decide
def e834041209242 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834041209242 : Closed e834041209242 ∧ code e834041209242 = 9630134231450 := by decide
theorem cert_e834041209242 : check e834041209242 [] .sourceHead = true := by decide
def e834041210394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834041210394 : Closed e834041210394 ∧ code e834041210394 = 9630134232602 := by decide
theorem cert_e834041210394 : check e834041210394 [] .sourceHead = true := by decide
def e834041258010 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834041258010 : Closed e834041258010 ∧ code e834041258010 = 9630134280218 := by decide
theorem cert_e834041258010 : check e834041258010 [] .sourceHead = true := by decide
def e834041258102 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834041258102 : Closed e834041258102 ∧ code e834041258102 = 9630134280310 := by decide
theorem cert_e834041258102 : check e834041258102 [] .sourceHead = true := by decide
def e834041258346 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834041258346 : Closed e834041258346 ∧ code e834041258346 = 9630134280554 := by decide
theorem cert_e834041258346 : check e834041258346 [] .sourceHead = true := by decide
def e834041258394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834041258394 : Closed e834041258394 ∧ code e834041258394 = 9630134280602 := by decide
theorem cert_e834041258394 : check e834041258394 [] .sourceHead = true := by decide
def e834041259546 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834041259546 : Closed e834041259546 ∧ code e834041259546 = 9630134281754 := by decide
theorem cert_e834041259546 : check e834041259546 [] .sourceHead = true := by decide
def e834041372698 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834041372698 : Closed e834041372698 ∧ code e834041372698 = 9630134394906 := by decide
theorem cert_e834041372698 : check e834041372698 [] .sourceHead = true := by decide
def e834041372790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834041372790 : Closed e834041372790 ∧ code e834041372790 = 9630134394998 := by decide
theorem cert_e834041372790 : check e834041372790 [] .sourceHead = true := by decide
def e834041373034 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834041373034 : Closed e834041373034 ∧ code e834041373034 = 9630134395242 := by decide
theorem cert_e834041373034 : check e834041373034 [] .sourceHead = true := by decide
def e834041373082 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834041373082 : Closed e834041373082 ∧ code e834041373082 = 9630134395290 := by decide
theorem cert_e834041373082 : check e834041373082 [] .sourceHead = true := by decide
def e834041374234 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834041374234 : Closed e834041374234 ∧ code e834041374234 = 9630134396442 := by decide
theorem cert_e834041374234 : check e834041374234 [] .sourceHead = true := by decide
def e834041389082 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834041389082 : Closed e834041389082 ∧ code e834041389082 = 9630134411290 := by decide
theorem cert_e834041389082 : check e834041389082 [] .sourceHead = true := by decide
def e834041389174 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834041389174 : Closed e834041389174 ∧ code e834041389174 = 9630134411382 := by decide
theorem cert_e834041389174 : check e834041389174 [] .sourceHead = true := by decide
def e834041389418 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834041389418 : Closed e834041389418 ∧ code e834041389418 = 9630134411626 := by decide
theorem cert_e834041389418 : check e834041389418 [] .sourceHead = true := by decide
def e834041389466 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834041389466 : Closed e834041389466 ∧ code e834041389466 = 9630134411674 := by decide
theorem cert_e834041389466 : check e834041389466 [] .sourceHead = true := by decide
def e834041390618 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834041390618 : Closed e834041390618 ∧ code e834041390618 = 9630134412826 := by decide
theorem cert_e834041390618 : check e834041390618 [] .sourceHead = true := by decide
def e834042519578 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834042519578 : Closed e834042519578 ∧ code e834042519578 = 9630135541786 := by decide
theorem cert_e834042519578 : check e834042519578 [] .sourceHead = true := by decide
def e834042519670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834042519670 : Closed e834042519670 ∧ code e834042519670 = 9630135541878 := by decide
theorem cert_e834042519670 : check e834042519670 [] .sourceHead = true := by decide
def e834042519914 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834042519914 : Closed e834042519914 ∧ code e834042519914 = 9630135542122 := by decide
theorem cert_e834042519914 : check e834042519914 [] .sourceHead = true := by decide
def e834042519962 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834042519962 : Closed e834042519962 ∧ code e834042519962 = 9630135542170 := by decide
theorem cert_e834042519962 : check e834042519962 [] .sourceHead = true := by decide
def e834042521114 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834042521114 : Closed e834042521114 ∧ code e834042521114 = 9630135543322 := by decide
theorem cert_e834042521114 : check e834042521114 [] .sourceHead = true := by decide
def e834042552346 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834042552346 : Closed e834042552346 ∧ code e834042552346 = 9630135574554 := by decide
theorem cert_e834042552346 : check e834042552346 [] .sourceHead = true := by decide
def e834042552438 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834042552438 : Closed e834042552438 ∧ code e834042552438 = 9630135574646 := by decide
theorem cert_e834042552438 : check e834042552438 [] .sourceHead = true := by decide
def e834042552682 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834042552682 : Closed e834042552682 ∧ code e834042552682 = 9630135574890 := by decide
theorem cert_e834042552682 : check e834042552682 [] .sourceHead = true := by decide
def e834042552730 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834042552730 : Closed e834042552730 ∧ code e834042552730 = 9630135574938 := by decide
theorem cert_e834042552730 : check e834042552730 [] .sourceHead = true := by decide
def e834042553882 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834042553882 : Closed e834042553882 ∧ code e834042553882 = 9630135576090 := by decide
theorem cert_e834042553882 : check e834042553882 [] .sourceHead = true := by decide
def e834044092442 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834044092442 : Closed e834044092442 ∧ code e834044092442 = 9630137114650 := by decide
theorem cert_e834044092442 : check e834044092442 [] .sourceHead = true := by decide
def e834044092534 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834044092534 : Closed e834044092534 ∧ code e834044092534 = 9630137114742 := by decide
theorem cert_e834044092534 : check e834044092534 [] .sourceHead = true := by decide
def e834044092778 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834044092778 : Closed e834044092778 ∧ code e834044092778 = 9630137114986 := by decide
theorem cert_e834044092778 : check e834044092778 [] .sourceHead = true := by decide
def e834044092826 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834044092826 : Closed e834044092826 ∧ code e834044092826 = 9630137115034 := by decide
theorem cert_e834044092826 : check e834044092826 [] .sourceHead = true := by decide
def e834044093978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834044093978 : Closed e834044093978 ∧ code e834044093978 = 9630137116186 := by decide
theorem cert_e834044093978 : check e834044093978 [] .sourceHead = true := by decide
def e834044141594 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834044141594 : Closed e834044141594 ∧ code e834044141594 = 9630137163802 := by decide
theorem cert_e834044141594 : check e834044141594 [] .sourceHead = true := by decide
def e834044141686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834044141686 : Closed e834044141686 ∧ code e834044141686 = 9630137163894 := by decide
theorem cert_e834044141686 : check e834044141686 [] .sourceHead = true := by decide
def e834044141930 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834044141930 : Closed e834044141930 ∧ code e834044141930 = 9630137164138 := by decide
theorem cert_e834044141930 : check e834044141930 [] .sourceHead = true := by decide
def e834044141978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834044141978 : Closed e834044141978 ∧ code e834044141978 = 9630137164186 := by decide
theorem cert_e834044141978 : check e834044141978 [] .sourceHead = true := by decide
def e834044143130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834044143130 : Closed e834044143130 ∧ code e834044143130 = 9630137165338 := by decide
theorem cert_e834044143130 : check e834044143130 [] .sourceHead = true := by decide
def e834044911642 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834044911642 : Closed e834044911642 ∧ code e834044911642 = 9630137933850 := by decide
theorem cert_e834044911642 : check e834044911642 [] .sourceHead = true := by decide
def e834044911734 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834044911734 : Closed e834044911734 ∧ code e834044911734 = 9630137933942 := by decide
theorem cert_e834044911734 : check e834044911734 [] .sourceHead = true := by decide
def e834044911978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834044911978 : Closed e834044911978 ∧ code e834044911978 = 9630137934186 := by decide
theorem cert_e834044911978 : check e834044911978 [] .sourceHead = true := by decide
def e834044912026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834044912026 : Closed e834044912026 ∧ code e834044912026 = 9630137934234 := by decide
theorem cert_e834044912026 : check e834044912026 [] .sourceHead = true := by decide
def e834044913178 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834044913178 : Closed e834044913178 ∧ code e834044913178 = 9630137935386 := by decide
theorem cert_e834044913178 : check e834044913178 [] .sourceHead = true := by decide
def e834044928026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e834044928026 : Closed e834044928026 ∧ code e834044928026 = 9630137950234 := by decide
theorem cert_e834044928026 : check e834044928026 [] .sourceHead = true := by decide
def e834044928118 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e834044928118 : Closed e834044928118 ∧ code e834044928118 = 9630137950326 := by decide
theorem cert_e834044928118 : check e834044928118 [] .sourceHead = true := by decide
def e834044928362 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e834044928362 : Closed e834044928362 ∧ code e834044928362 = 9630137950570 := by decide
theorem cert_e834044928362 : check e834044928362 [] .sourceHead = true := by decide
def e834044928410 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e834044928410 : Closed e834044928410 ∧ code e834044928410 = 9630137950618 := by decide
theorem cert_e834044928410 : check e834044928410 [] .sourceHead = true := by decide
def e834044929562 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e834044929562 : Closed e834044929562 ∧ code e834044929562 = 9630137951770 := by decide
theorem cert_e834044929562 : check e834044929562 [] .sourceHead = true := by decide
def e834054216558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e834054216558 : Closed e834054216558 ∧ code e834054216558 = 9630147238766 := by decide
theorem cert_e834054216558 : check e834054216558 [] .sourceHead = true := by decide
def e834054216566 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e834054216566 : Closed e834054216566 ∧ code e834054216566 = 9630147238774 := by decide
theorem cert_e834054216566 : check e834054216566 [] .sourceHead = true := by decide
def e834054216630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e834054216630 : Closed e834054216630 ∧ code e834054216630 = 9630147238838 := by decide
theorem cert_e834054216630 : check e834054216630 [] .sourceHead = true := by decide
def e834054217070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e834054217070 : Closed e834054217070 ∧ code e834054217070 = 9630147239278 := by decide
theorem cert_e834054217070 : check e834054217070 [] .sourceHead = true := by decide
def e834054217078 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e834054217078 : Closed e834054217078 ∧ code e834054217078 = 9630147239286 := by decide
theorem cert_e834054217078 : check e834054217078 [] .sourceHead = true := by decide
def e834054217134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e834054217134 : Closed e834054217134 ∧ code e834054217134 = 9630147239342 := by decide
theorem cert_e834054217134 : check e834054217134 [] .sourceHead = true := by decide
def e834054217146 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e834054217146 : Closed e834054217146 ∧ code e834054217146 = 9630147239354 := by decide
theorem cert_e834054217146 : check e834054217146 [] .sourceHead = true := by decide
def e834054217174 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e834054217174 : Closed e834054217174 ∧ code e834054217174 = 9630147239382 := by decide
theorem cert_e834054217174 : check e834054217174 [] .sourceHead = true := by decide
def e834054217178 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e834054217178 : Closed e834054217178 ∧ code e834054217178 = 9630147239386 := by decide
theorem cert_e834054217178 : check e834054217178 [] .sourceHead = true := by decide
def e834054217398 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e834054217398 : Closed e834054217398 ∧ code e834054217398 = 9630147239606 := by decide
theorem cert_e834054217398 : check e834054217398 [] .sourceHead = true := by decide
def e834054217430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e834054217430 : Closed e834054217430 ∧ code e834054217430 = 9630147239638 := by decide
theorem cert_e834054217430 : check e834054217430 [] .sourceHead = true := by decide
def e834054217434 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e834054217434 : Closed e834054217434 ∧ code e834054217434 = 9630147239642 := by decide
theorem cert_e834054217434 : check e834054217434 [] .sourceHead = true := by decide
def e834054219630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e834054219630 : Closed e834054219630 ∧ code e834054219630 = 9630147241838 := by decide
theorem cert_e834054219630 : check e834054219630 [] .sourceHead = true := by decide
def e834054219638 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e834054219638 : Closed e834054219638 ∧ code e834054219638 = 9630147241846 := by decide
theorem cert_e834054219638 : check e834054219638 [] .sourceHead = true := by decide
def e834054219702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e834054219702 : Closed e834054219702 ∧ code e834054219702 = 9630147241910 := by decide
theorem cert_e834054219702 : check e834054219702 [] .sourceHead = true := by decide
def e834054221038 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e834054221038 : Closed e834054221038 ∧ code e834054221038 = 9630147243246 := by decide
theorem cert_e834054221038 : check e834054221038 [] .sourceHead = true := by decide
def e834054221046 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e834054221046 : Closed e834054221046 ∧ code e834054221046 = 9630147243254 := by decide
theorem cert_e834054221046 : check e834054221046 [] .sourceHead = true := by decide
def e834054221430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e834054221430 : Closed e834054221430 ∧ code e834054221430 = 9630147243638 := by decide
theorem cert_e834054221430 : check e834054221430 [] .sourceHead = true := by decide
def e834054222702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e834054222702 : Closed e834054222702 ∧ code e834054222702 = 9630147244910 := by decide
theorem cert_e834054222702 : check e834054222702 [] .sourceHead = true := by decide
def e834054222710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e834054222710 : Closed e834054222710 ∧ code e834054222710 = 9630147244918 := by decide
theorem cert_e834054222710 : check e834054222710 [] .sourceHead = true := by decide
def e834054222766 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e834054222766 : Closed e834054222766 ∧ code e834054222766 = 9630147244974 := by decide
theorem cert_e834054222766 : check e834054222766 [] .sourceHead = true := by decide
def e834054222778 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e834054222778 : Closed e834054222778 ∧ code e834054222778 = 9630147244986 := by decide
theorem cert_e834054222778 : check e834054222778 [] .sourceHead = true := by decide
def e834054222806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e834054222806 : Closed e834054222806 ∧ code e834054222806 = 9630147245014 := by decide
theorem cert_e834054222806 : check e834054222806 [] .sourceHead = true := by decide
def e834054222810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e834054222810 : Closed e834054222810 ∧ code e834054222810 = 9630147245018 := by decide
theorem cert_e834054222810 : check e834054222810 [] .sourceHead = true := by decide
def e834054223086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e834054223086 : Closed e834054223086 ∧ code e834054223086 = 9630147245294 := by decide
theorem cert_e834054223086 : check e834054223086 [] .sourceHead = true := by decide
def e834054223094 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e834054223094 : Closed e834054223094 ∧ code e834054223094 = 9630147245302 := by decide
theorem cert_e834054223094 : check e834054223094 [] .sourceHead = true := by decide
def e834054223470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e834054223470 : Closed e834054223470 ∧ code e834054223470 = 9630147245678 := by decide
theorem cert_e834054223470 : check e834054223470 [] .sourceHead = true := by decide
def e834054223482 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e834054223482 : Closed e834054223482 ∧ code e834054223482 = 9630147245690 := by decide
theorem cert_e834054223482 : check e834054223482 [] .sourceHead = true := by decide
def e834054223670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e834054223670 : Closed e834054223670 ∧ code e834054223670 = 9630147245878 := by decide
theorem cert_e834054223670 : check e834054223670 [] .sourceHead = true := by decide
def e834054223674 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e834054223674 : Closed e834054223674 ∧ code e834054223674 = 9630147245882 := by decide
theorem cert_e834054223674 : check e834054223674 [] .sourceHead = true := by decide
def e834054224310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e834054224310 : Closed e834054224310 ∧ code e834054224310 = 9630147246518 := by decide
theorem cert_e834054224310 : check e834054224310 [] .sourceHead = true := by decide
def e834054224342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e834054224342 : Closed e834054224342 ∧ code e834054224342 = 9630147246550 := by decide
theorem cert_e834054224342 : check e834054224342 [] .sourceHead = true := by decide
def e834054224346 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e834054224346 : Closed e834054224346 ∧ code e834054224346 = 9630147246554 := by decide
theorem cert_e834054224346 : check e834054224346 [] .sourceHead = true := by decide
def e834054224502 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e834054224502 : Closed e834054224502 ∧ code e834054224502 = 9630147246710 := by decide
theorem cert_e834054224502 : check e834054224502 [] .sourceHead = true := by decide
def e834054224694 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e834054224694 : Closed e834054224694 ∧ code e834054224694 = 9630147246902 := by decide
theorem cert_e834054224694 : check e834054224694 [] .sourceHead = true := by decide
def e834054224698 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e834054224698 : Closed e834054224698 ∧ code e834054224698 = 9630147246906 := by decide
theorem cert_e834054224698 : check e834054224698 [] .sourceHead = true := by decide
def e834054231918 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e834054231918 : Closed e834054231918 ∧ code e834054231918 = 9630147254126 := by decide
theorem cert_e834054231918 : check e834054231918 [] .sourceHead = true := by decide
def e834054231926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e834054231926 : Closed e834054231926 ∧ code e834054231926 = 9630147254134 := by decide
theorem cert_e834054231926 : check e834054231926 [] .sourceHead = true := by decide
def e834054231990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e834054231990 : Closed e834054231990 ∧ code e834054231990 = 9630147254198 := by decide
theorem cert_e834054231990 : check e834054231990 [] .sourceHead = true := by decide
def e834054233326 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e834054233326 : Closed e834054233326 ∧ code e834054233326 = 9630147255534 := by decide
theorem cert_e834054233326 : check e834054233326 [] .sourceHead = true := by decide
def e834054233334 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e834054233334 : Closed e834054233334 ∧ code e834054233334 = 9630147255542 := by decide
theorem cert_e834054233334 : check e834054233334 [] .sourceHead = true := by decide
def e834054233718 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e834054233718 : Closed e834054233718 ∧ code e834054233718 = 9630147255926 := by decide
theorem cert_e834054233718 : check e834054233718 [] .sourceHead = true := by decide
def e834054245230 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e834054245230 : Closed e834054245230 ∧ code e834054245230 = 9630147267438 := by decide
theorem cert_e834054245230 : check e834054245230 [] .sourceHead = true := by decide
def e834054245238 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e834054245238 : Closed e834054245238 ∧ code e834054245238 = 9630147267446 := by decide
theorem cert_e834054245238 : check e834054245238 [] .sourceHead = true := by decide
def e834054245294 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e834054245294 : Closed e834054245294 ∧ code e834054245294 = 9630147267502 := by decide
theorem cert_e834054245294 : check e834054245294 [] .sourceHead = true := by decide
def e834054245306 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e834054245306 : Closed e834054245306 ∧ code e834054245306 = 9630147267514 := by decide
theorem cert_e834054245306 : check e834054245306 [] .sourceHead = true := by decide
def e834054245334 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e834054245334 : Closed e834054245334 ∧ code e834054245334 = 9630147267542 := by decide
theorem cert_e834054245334 : check e834054245334 [] .sourceHead = true := by decide
def e834054245338 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e834054245338 : Closed e834054245338 ∧ code e834054245338 = 9630147267546 := by decide
theorem cert_e834054245338 : check e834054245338 [] .sourceHead = true := by decide
def e834054245614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e834054245614 : Closed e834054245614 ∧ code e834054245614 = 9630147267822 := by decide
theorem cert_e834054245614 : check e834054245614 [] .sourceHead = true := by decide
def e834054245622 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e834054245622 : Closed e834054245622 ∧ code e834054245622 = 9630147267830 := by decide
theorem cert_e834054245622 : check e834054245622 [] .sourceHead = true := by decide
def e834054245998 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e834054245998 : Closed e834054245998 ∧ code e834054245998 = 9630147268206 := by decide
theorem cert_e834054245998 : check e834054245998 [] .sourceHead = true := by decide
def e834054246010 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e834054246010 : Closed e834054246010 ∧ code e834054246010 = 9630147268218 := by decide
theorem cert_e834054246010 : check e834054246010 [] .sourceHead = true := by decide
def e834054246198 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e834054246198 : Closed e834054246198 ∧ code e834054246198 = 9630147268406 := by decide
theorem cert_e834054246198 : check e834054246198 [] .sourceHead = true := by decide
def e834054246202 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e834054246202 : Closed e834054246202 ∧ code e834054246202 = 9630147268410 := by decide
theorem cert_e834054246202 : check e834054246202 [] .sourceHead = true := by decide
def e834054251958 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e834054251958 : Closed e834054251958 ∧ code e834054251958 = 9630147274166 := by decide
theorem cert_e834054251958 : check e834054251958 [] .sourceHead = true := by decide
def e834054251990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e834054251990 : Closed e834054251990 ∧ code e834054251990 = 9630147274198 := by decide
theorem cert_e834054251990 : check e834054251990 [] .sourceHead = true := by decide
def e834054251994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e834054251994 : Closed e834054251994 ∧ code e834054251994 = 9630147274202 := by decide
theorem cert_e834054251994 : check e834054251994 [] .sourceHead = true := by decide
def e834054252150 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e834054252150 : Closed e834054252150 ∧ code e834054252150 = 9630147274358 := by decide
theorem cert_e834054252150 : check e834054252150 [] .sourceHead = true := by decide
def e834054252342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e834054252342 : Closed e834054252342 ∧ code e834054252342 = 9630147274550 := by decide
theorem cert_e834054252342 : check e834054252342 [] .sourceHead = true := by decide
def e834054252346 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e834054252346 : Closed e834054252346 ∧ code e834054252346 = 9630147274554 := by decide
theorem cert_e834054252346 : check e834054252346 [] .sourceHead = true := by decide
def e834080042522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080042522 : Closed e834080042522 ∧ code e834080042522 = 9630173064730 := by decide
theorem cert_e834080042522 : check e834080042522 [] .sourceHead = true := by decide
def e834080044570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080044570 : Closed e834080044570 ∧ code e834080044570 = 9630173066778 := by decide
theorem cert_e834080044570 : check e834080044570 [] .sourceHead = true := by decide
def e834080058906 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080058906 : Closed e834080058906 ∧ code e834080058906 = 9630173081114 := by decide
theorem cert_e834080058906 : check e834080058906 [] .sourceHead = true := by decide
def e834080061978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080061978 : Closed e834080061978 ∧ code e834080061978 = 9630173084186 := by decide
theorem cert_e834080061978 : check e834080061978 [] .sourceHead = true := by decide
def e834080069146 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080069146 : Closed e834080069146 ∧ code e834080069146 = 9630173091354 := by decide
theorem cert_e834080069146 : check e834080069146 [] .sourceHead = true := by decide
def e834080070170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080070170 : Closed e834080070170 ∧ code e834080070170 = 9630173092378 := by decide
theorem cert_e834080070170 : check e834080070170 [] .sourceHead = true := by decide
def e834080140826 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080140826 : Closed e834080140826 ∧ code e834080140826 = 9630173163034 := by decide
theorem cert_e834080140826 : check e834080140826 [] .sourceHead = true := by decide
def e834080142874 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080142874 : Closed e834080142874 ∧ code e834080142874 = 9630173165082 := by decide
theorem cert_e834080142874 : check e834080142874 [] .sourceHead = true := by decide
def e834080239130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080239130 : Closed e834080239130 ∧ code e834080239130 = 9630173261338 := by decide
theorem cert_e834080239130 : check e834080239130 [] .sourceHead = true := by decide
def e834080242202 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080242202 : Closed e834080242202 ∧ code e834080242202 = 9630173264410 := by decide
theorem cert_e834080242202 : check e834080242202 [] .sourceHead = true := by decide
def e834080290330 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080290330 : Closed e834080290330 ∧ code e834080290330 = 9630173312538 := by decide
theorem cert_e834080290330 : check e834080290330 [] .sourceHead = true := by decide
def e834080291354 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e834080291354 : Closed e834080291354 ∧ code e834080291354 = 9630173313562 := by decide
theorem cert_e834080291354 : check e834080291354 [] .sourceHead = true := by decide
def e834083532142 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e834083532142 : Closed e834083532142 ∧ code e834083532142 = 9630176554350 := by decide
theorem cert_e834083532142 : check e834083532142 [] .sourceHead = true := by decide
def e834083532150 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e834083532150 : Closed e834083532150 ∧ code e834083532150 = 9630176554358 := by decide
theorem cert_e834083532150 : check e834083532150 [] .sourceHead = true := by decide
def e834083532206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e834083532206 : Closed e834083532206 ∧ code e834083532206 = 9630176554414 := by decide
theorem cert_e834083532206 : check e834083532206 [] .sourceHead = true := by decide
def e834083532218 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e834083532218 : Closed e834083532218 ∧ code e834083532218 = 9630176554426 := by decide
theorem cert_e834083532218 : check e834083532218 [] .sourceHead = true := by decide
def e834083532246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e834083532246 : Closed e834083532246 ∧ code e834083532246 = 9630176554454 := by decide
theorem cert_e834083532246 : check e834083532246 [] .sourceHead = true := by decide
def e834083532250 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e834083532250 : Closed e834083532250 ∧ code e834083532250 = 9630176554458 := by decide
theorem cert_e834083532250 : check e834083532250 [] .sourceHead = true := by decide
def e834083532462 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e834083532462 : Closed e834083532462 ∧ code e834083532462 = 9630176554670 := by decide
theorem cert_e834083532462 : check e834083532462 [] .sourceHead = true := by decide
def e834083532474 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e834083532474 : Closed e834083532474 ∧ code e834083532474 = 9630176554682 := by decide
theorem cert_e834083532474 : check e834083532474 [] .sourceHead = true := by decide
def e834083532522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e834083532522 : Closed e834083532522 ∧ code e834083532522 = 9630176554730 := by decide
theorem cert_e834083532522 : check e834083532522 [] .sourceHead = true := by decide
def e834083532630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e834083532630 : Closed e834083532630 ∧ code e834083532630 = 9630176554838 := by decide
theorem cert_e834083532630 : check e834083532630 [] .sourceHead = true := by decide
end Blc.Floor43
