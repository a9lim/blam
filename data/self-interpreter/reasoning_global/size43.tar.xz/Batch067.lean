import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e756904144730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e756904144730 : Closed e756904144730 ∧ code e756904144730 = 9552997166938 := by decide
theorem cert_e756904144730 : check e756904144730 [] .sourceHead = true := by decide
def e756904144746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e756904144746 : Closed e756904144746 ∧ code e756904144746 = 9552997166954 := by decide
theorem cert_e756904144746 : check e756904144746 [] .sourceHead = true := by decide
def e756904145774 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e756904145774 : Closed e756904145774 ∧ code e756904145774 = 9552997167982 := by decide
theorem cert_e756904145774 : check e756904145774 [] .sourceHead = true := by decide
def e756904145782 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e756904145782 : Closed e756904145782 ∧ code e756904145782 = 9552997167990 := by decide
theorem cert_e756904145782 : check e756904145782 [] .sourceHead = true := by decide
def e756904145838 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e756904145838 : Closed e756904145838 ∧ code e756904145838 = 9552997168046 := by decide
theorem cert_e756904145838 : check e756904145838 [] .sourceHead = true := by decide
def e756904145850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e756904145850 : Closed e756904145850 ∧ code e756904145850 = 9552997168058 := by decide
theorem cert_e756904145850 : check e756904145850 [] .sourceHead = true := by decide
def e756904145878 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e756904145878 : Closed e756904145878 ∧ code e756904145878 = 9552997168086 := by decide
theorem cert_e756904145878 : check e756904145878 [] .sourceHead = true := by decide
def e756904145882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e756904145882 : Closed e756904145882 ∧ code e756904145882 = 9552997168090 := by decide
theorem cert_e756904145882 : check e756904145882 [] .sourceHead = true := by decide
def e756904146158 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e756904146158 : Closed e756904146158 ∧ code e756904146158 = 9552997168366 := by decide
theorem cert_e756904146158 : check e756904146158 [] .sourceHead = true := by decide
def e756904146166 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e756904146166 : Closed e756904146166 ∧ code e756904146166 = 9552997168374 := by decide
theorem cert_e756904146166 : check e756904146166 [] .sourceHead = true := by decide
def e756904146542 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e756904146542 : Closed e756904146542 ∧ code e756904146542 = 9552997168750 := by decide
theorem cert_e756904146542 : check e756904146542 [] .sourceHead = true := by decide
def e756904146554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e756904146554 : Closed e756904146554 ∧ code e756904146554 = 9552997168762 := by decide
theorem cert_e756904146554 : check e756904146554 [] .sourceHead = true := by decide
def e756904146742 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e756904146742 : Closed e756904146742 ∧ code e756904146742 = 9552997168950 := by decide
theorem cert_e756904146742 : check e756904146742 [] .sourceHead = true := by decide
def e756904146746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e756904146746 : Closed e756904146746 ∧ code e756904146746 = 9552997168954 := by decide
theorem cert_e756904146746 : check e756904146746 [] .sourceHead = true := by decide
def e756904147374 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e756904147374 : Closed e756904147374 ∧ code e756904147374 = 9552997169582 := by decide
theorem cert_e756904147374 : check e756904147374 [] .sourceHead = true := by decide
def e756904147386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e756904147386 : Closed e756904147386 ∧ code e756904147386 = 9552997169594 := by decide
theorem cert_e756904147386 : check e756904147386 [] .sourceHead = true := by decide
def e756904147434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e756904147434 : Closed e756904147434 ∧ code e756904147434 = 9552997169642 := by decide
theorem cert_e756904147434 : check e756904147434 [] .sourceHead = true := by decide
def e756904147566 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e756904147566 : Closed e756904147566 ∧ code e756904147566 = 9552997169774 := by decide
theorem cert_e756904147566 : check e756904147566 [] .sourceHead = true := by decide
def e756904147578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e756904147578 : Closed e756904147578 ∧ code e756904147578 = 9552997169786 := by decide
theorem cert_e756904147578 : check e756904147578 [] .sourceHead = true := by decide
def e756904147866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e756904147866 : Closed e756904147866 ∧ code e756904147866 = 9552997170074 := by decide
theorem cert_e756904147866 : check e756904147866 [] .sourceHead = true := by decide
def e756904148182 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e756904148182 : Closed e756904148182 ∧ code e756904148182 = 9552997170390 := by decide
theorem cert_e756904148182 : check e756904148182 [] .sourceHead = true := by decide
def e756904148186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e756904148186 : Closed e756904148186 ∧ code e756904148186 = 9552997170394 := by decide
theorem cert_e756904148186 : check e756904148186 [] .sourceHead = true := by decide
def e756904148202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e756904148202 : Closed e756904148202 ∧ code e756904148202 = 9552997170410 := by decide
theorem cert_e756904148202 : check e756904148202 [] .sourceHead = true := by decide
def e756904148278 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e756904148278 : Closed e756904148278 ∧ code e756904148278 = 9552997170486 := by decide
theorem cert_e756904148278 : check e756904148278 [] .sourceHead = true := by decide
def e756904148282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e756904148282 : Closed e756904148282 ∧ code e756904148282 = 9552997170490 := by decide
theorem cert_e756904148282 : check e756904148282 [] .sourceHead = true := by decide
def e756904148378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e756904148378 : Closed e756904148378 ∧ code e756904148378 = 9552997170586 := by decide
theorem cert_e756904148378 : check e756904148378 [] .sourceHead = true := by decide
def e756904151918 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e756904151918 : Closed e756904151918 ∧ code e756904151918 = 9552997174126 := by decide
theorem cert_e756904151918 : check e756904151918 [] .sourceHead = true := by decide
def e756904151926 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e756904151926 : Closed e756904151926 ∧ code e756904151926 = 9552997174134 := by decide
theorem cert_e756904151926 : check e756904151926 [] .sourceHead = true := by decide
def e756904151982 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e756904151982 : Closed e756904151982 ∧ code e756904151982 = 9552997174190 := by decide
theorem cert_e756904151982 : check e756904151982 [] .sourceHead = true := by decide
def e756904151994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e756904151994 : Closed e756904151994 ∧ code e756904151994 = 9552997174202 := by decide
theorem cert_e756904151994 : check e756904151994 [] .sourceHead = true := by decide
def e756904152022 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e756904152022 : Closed e756904152022 ∧ code e756904152022 = 9552997174230 := by decide
theorem cert_e756904152022 : check e756904152022 [] .sourceHead = true := by decide
def e756904152026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e756904152026 : Closed e756904152026 ∧ code e756904152026 = 9552997174234 := by decide
theorem cert_e756904152026 : check e756904152026 [] .sourceHead = true := by decide
def e756904152302 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e756904152302 : Closed e756904152302 ∧ code e756904152302 = 9552997174510 := by decide
theorem cert_e756904152302 : check e756904152302 [] .sourceHead = true := by decide
def e756904152310 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e756904152310 : Closed e756904152310 ∧ code e756904152310 = 9552997174518 := by decide
theorem cert_e756904152310 : check e756904152310 [] .sourceHead = true := by decide
def e756904152686 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e756904152686 : Closed e756904152686 ∧ code e756904152686 = 9552997174894 := by decide
theorem cert_e756904152686 : check e756904152686 [] .sourceHead = true := by decide
def e756904152698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e756904152698 : Closed e756904152698 ∧ code e756904152698 = 9552997174906 := by decide
theorem cert_e756904152698 : check e756904152698 [] .sourceHead = true := by decide
def e756904152886 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e756904152886 : Closed e756904152886 ∧ code e756904152886 = 9552997175094 := by decide
theorem cert_e756904152886 : check e756904152886 [] .sourceHead = true := by decide
def e756904152890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e756904152890 : Closed e756904152890 ∧ code e756904152890 = 9552997175098 := by decide
theorem cert_e756904152890 : check e756904152890 [] .sourceHead = true := by decide
def e756904158638 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e756904158638 : Closed e756904158638 ∧ code e756904158638 = 9552997180846 := by decide
theorem cert_e756904158638 : check e756904158638 [] .sourceHead = true := by decide
def e756904158650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e756904158650 : Closed e756904158650 ∧ code e756904158650 = 9552997180858 := by decide
theorem cert_e756904158650 : check e756904158650 [] .sourceHead = true := by decide
def e756904158698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e756904158698 : Closed e756904158698 ∧ code e756904158698 = 9552997180906 := by decide
theorem cert_e756904158698 : check e756904158698 [] .sourceHead = true := by decide
def e756904158830 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e756904158830 : Closed e756904158830 ∧ code e756904158830 = 9552997181038 := by decide
theorem cert_e756904158830 : check e756904158830 [] .sourceHead = true := by decide
def e756904158842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e756904158842 : Closed e756904158842 ∧ code e756904158842 = 9552997181050 := by decide
theorem cert_e756904158842 : check e756904158842 [] .sourceHead = true := by decide
def e756904159130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e756904159130 : Closed e756904159130 ∧ code e756904159130 = 9552997181338 := by decide
theorem cert_e756904159130 : check e756904159130 [] .sourceHead = true := by decide
def e756904162006 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e756904162006 : Closed e756904162006 ∧ code e756904162006 = 9552997184214 := by decide
theorem cert_e756904162006 : check e756904162006 [] .sourceHead = true := by decide
def e756904162010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e756904162010 : Closed e756904162010 ∧ code e756904162010 = 9552997184218 := by decide
theorem cert_e756904162010 : check e756904162010 [] .sourceHead = true := by decide
def e756904162026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e756904162026 : Closed e756904162026 ∧ code e756904162026 = 9552997184234 := by decide
theorem cert_e756904162026 : check e756904162026 [] .sourceHead = true := by decide
def e756904162102 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e756904162102 : Closed e756904162102 ∧ code e756904162102 = 9552997184310 := by decide
theorem cert_e756904162102 : check e756904162102 [] .sourceHead = true := by decide
def e756904162106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e756904162106 : Closed e756904162106 ∧ code e756904162106 = 9552997184314 := by decide
theorem cert_e756904162106 : check e756904162106 [] .sourceHead = true := by decide
def e756904162202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e756904162202 : Closed e756904162202 ∧ code e756904162202 = 9552997184410 := by decide
theorem cert_e756904162202 : check e756904162202 [] .sourceHead = true := by decide
def e756904299374 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e756904299374 : Closed e756904299374 ∧ code e756904299374 = 9552997321582 := by decide
theorem cert_e756904299374 : check e756904299374 [] .sourceHead = true := by decide
def e756904299382 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e756904299382 : Closed e756904299382 ∧ code e756904299382 = 9552997321590 := by decide
theorem cert_e756904299382 : check e756904299382 [] .sourceHead = true := by decide
def e756904299438 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e756904299438 : Closed e756904299438 ∧ code e756904299438 = 9552997321646 := by decide
theorem cert_e756904299438 : check e756904299438 [] .sourceHead = true := by decide
def e756904299450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e756904299450 : Closed e756904299450 ∧ code e756904299450 = 9552997321658 := by decide
theorem cert_e756904299450 : check e756904299450 [] .sourceHead = true := by decide
def e756904299478 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e756904299478 : Closed e756904299478 ∧ code e756904299478 = 9552997321686 := by decide
theorem cert_e756904299478 : check e756904299478 [] .sourceHead = true := by decide
def e756904299482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e756904299482 : Closed e756904299482 ∧ code e756904299482 = 9552997321690 := by decide
theorem cert_e756904299482 : check e756904299482 [] .sourceHead = true := by decide
def e756904299758 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e756904299758 : Closed e756904299758 ∧ code e756904299758 = 9552997321966 := by decide
theorem cert_e756904299758 : check e756904299758 [] .sourceHead = true := by decide
def e756904299766 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e756904299766 : Closed e756904299766 ∧ code e756904299766 = 9552997321974 := by decide
theorem cert_e756904299766 : check e756904299766 [] .sourceHead = true := by decide
def e756904300142 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e756904300142 : Closed e756904300142 ∧ code e756904300142 = 9552997322350 := by decide
theorem cert_e756904300142 : check e756904300142 [] .sourceHead = true := by decide
def e756904300154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e756904300154 : Closed e756904300154 ∧ code e756904300154 = 9552997322362 := by decide
theorem cert_e756904300154 : check e756904300154 [] .sourceHead = true := by decide
def e756904300342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e756904300342 : Closed e756904300342 ∧ code e756904300342 = 9552997322550 := by decide
theorem cert_e756904300342 : check e756904300342 [] .sourceHead = true := by decide
def e756904300346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e756904300346 : Closed e756904300346 ∧ code e756904300346 = 9552997322554 := by decide
theorem cert_e756904300346 : check e756904300346 [] .sourceHead = true := by decide
def e756904889198 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e756904889198 : Closed e756904889198 ∧ code e756904889198 = 9552997911406 := by decide
theorem cert_e756904889198 : check e756904889198 [] .sourceHead = true := by decide
def e756904889206 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e756904889206 : Closed e756904889206 ∧ code e756904889206 = 9552997911414 := by decide
theorem cert_e756904889206 : check e756904889206 [] .sourceHead = true := by decide
def e756904889262 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e756904889262 : Closed e756904889262 ∧ code e756904889262 = 9552997911470 := by decide
theorem cert_e756904889262 : check e756904889262 [] .sourceHead = true := by decide
def e756904889274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e756904889274 : Closed e756904889274 ∧ code e756904889274 = 9552997911482 := by decide
theorem cert_e756904889274 : check e756904889274 [] .sourceHead = true := by decide
def e756904889302 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e756904889302 : Closed e756904889302 ∧ code e756904889302 = 9552997911510 := by decide
theorem cert_e756904889302 : check e756904889302 [] .sourceHead = true := by decide
def e756904889306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e756904889306 : Closed e756904889306 ∧ code e756904889306 = 9552997911514 := by decide
theorem cert_e756904889306 : check e756904889306 [] .sourceHead = true := by decide
def e756904889582 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e756904889582 : Closed e756904889582 ∧ code e756904889582 = 9552997911790 := by decide
theorem cert_e756904889582 : check e756904889582 [] .sourceHead = true := by decide
def e756904889590 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e756904889590 : Closed e756904889590 ∧ code e756904889590 = 9552997911798 := by decide
theorem cert_e756904889590 : check e756904889590 [] .sourceHead = true := by decide
def e756904889966 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e756904889966 : Closed e756904889966 ∧ code e756904889966 = 9552997912174 := by decide
theorem cert_e756904889966 : check e756904889966 [] .sourceHead = true := by decide
def e756904889978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e756904889978 : Closed e756904889978 ∧ code e756904889978 = 9552997912186 := by decide
theorem cert_e756904889978 : check e756904889978 [] .sourceHead = true := by decide
def e756904890166 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e756904890166 : Closed e756904890166 ∧ code e756904890166 = 9552997912374 := by decide
theorem cert_e756904890166 : check e756904890166 [] .sourceHead = true := by decide
def e756904890170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e756904890170 : Closed e756904890170 ∧ code e756904890170 = 9552997912378 := by decide
theorem cert_e756904890170 : check e756904890170 [] .sourceHead = true := by decide
def e758280009146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e758280009146 : Closed e758280009146 ∧ code e758280009146 = 9554373031354 := by decide
theorem cert_e758280009146 : check e758280009146 [] .sourceHead = true := by decide
def e758280009178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e758280009178 : Closed e758280009178 ∧ code e758280009178 = 9554373031386 := by decide
theorem cert_e758280009178 : check e758280009178 [] .sourceHead = true := by decide
def e758280009402 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e758280009402 : Closed e758280009402 ∧ code e758280009402 = 9554373031610 := by decide
theorem cert_e758280009402 : check e758280009402 [] .sourceHead = true := by decide
def e758280009450 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e758280009450 : Closed e758280009450 ∧ code e758280009450 = 9554373031658 := by decide
theorem cert_e758280009450 : check e758280009450 [] .sourceHead = true := by decide
def e758280009562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e758280009562 : Closed e758280009562 ∧ code e758280009562 = 9554373031770 := by decide
theorem cert_e758280009562 : check e758280009562 [] .sourceHead = true := by decide
def e758280009578 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e758280009578 : Closed e758280009578 ∧ code e758280009578 = 9554373031786 := by decide
theorem cert_e758280009578 : check e758280009578 [] .sourceHead = true := by decide
def e758280010426 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e758280010426 : Closed e758280010426 ∧ code e758280010426 = 9554373032634 := by decide
theorem cert_e758280010426 : check e758280010426 [] .sourceHead = true := by decide
def e758280010474 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e758280010474 : Closed e758280010474 ∧ code e758280010474 = 9554373032682 := by decide
theorem cert_e758280010474 : check e758280010474 [] .sourceHead = true := by decide
def e758280010666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e758280010666 : Closed e758280010666 ∧ code e758280010666 = 9554373032874 := by decide
theorem cert_e758280010666 : check e758280010666 [] .sourceHead = true := by decide
def e758280011098 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e758280011098 : Closed e758280011098 ∧ code e758280011098 = 9554373033306 := by decide
theorem cert_e758280011098 : check e758280011098 [] .sourceHead = true := by decide
def e758280011114 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e758280011114 : Closed e758280011114 ∧ code e758280011114 = 9554373033322 := by decide
theorem cert_e758280011114 : check e758280011114 [] .sourceHead = true := by decide
def e758280011178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e758280011178 : Closed e758280011178 ∧ code e758280011178 = 9554373033386 := by decide
theorem cert_e758280011178 : check e758280011178 [] .sourceHead = true := by decide
def e758280015290 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e758280015290 : Closed e758280015290 ∧ code e758280015290 = 9554373037498 := by decide
theorem cert_e758280015290 : check e758280015290 [] .sourceHead = true := by decide
def e758280015322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e758280015322 : Closed e758280015322 ∧ code e758280015322 = 9554373037530 := by decide
theorem cert_e758280015322 : check e758280015322 [] .sourceHead = true := by decide
def e758280015546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e758280015546 : Closed e758280015546 ∧ code e758280015546 = 9554373037754 := by decide
theorem cert_e758280015546 : check e758280015546 [] .sourceHead = true := by decide
def e758280015594 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e758280015594 : Closed e758280015594 ∧ code e758280015594 = 9554373037802 := by decide
theorem cert_e758280015594 : check e758280015594 [] .sourceHead = true := by decide
def e758280015706 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e758280015706 : Closed e758280015706 ∧ code e758280015706 = 9554373037914 := by decide
theorem cert_e758280015706 : check e758280015706 [] .sourceHead = true := by decide
def e758280015722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e758280015722 : Closed e758280015722 ∧ code e758280015722 = 9554373037930 := by decide
theorem cert_e758280015722 : check e758280015722 [] .sourceHead = true := by decide
def e758280016826 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e758280016826 : Closed e758280016826 ∧ code e758280016826 = 9554373039034 := by decide
theorem cert_e758280016826 : check e758280016826 [] .sourceHead = true := by decide
def e758280016858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e758280016858 : Closed e758280016858 ∧ code e758280016858 = 9554373039066 := by decide
theorem cert_e758280016858 : check e758280016858 [] .sourceHead = true := by decide
def e758280018362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e758280018362 : Closed e758280018362 ∧ code e758280018362 = 9554373040570 := by decide
theorem cert_e758280018362 : check e758280018362 [] .sourceHead = true := by decide
def e758280018410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e758280018410 : Closed e758280018410 ∧ code e758280018410 = 9554373040618 := by decide
theorem cert_e758280018410 : check e758280018410 [] .sourceHead = true := by decide
def e758280019162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e758280019162 : Closed e758280019162 ∧ code e758280019162 = 9554373041370 := by decide
theorem cert_e758280019162 : check e758280019162 [] .sourceHead = true := by decide
def e758280019178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e758280019178 : Closed e758280019178 ∧ code e758280019178 = 9554373041386 := by decide
theorem cert_e758280019178 : check e758280019178 [] .sourceHead = true := by decide
def e758280021690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e758280021690 : Closed e758280021690 ∧ code e758280021690 = 9554373043898 := by decide
theorem cert_e758280021690 : check e758280021690 [] .sourceHead = true := by decide
def e758280021738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e758280021738 : Closed e758280021738 ∧ code e758280021738 = 9554373043946 := by decide
theorem cert_e758280021738 : check e758280021738 [] .sourceHead = true := by decide
def e758280021930 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e758280021930 : Closed e758280021930 ∧ code e758280021930 = 9554373044138 := by decide
theorem cert_e758280021930 : check e758280021930 [] .sourceHead = true := by decide
def e758280022458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e758280022458 : Closed e758280022458 ∧ code e758280022458 = 9554373044666 := by decide
theorem cert_e758280022458 : check e758280022458 [] .sourceHead = true := by decide
def e758280022506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e758280022506 : Closed e758280022506 ∧ code e758280022506 = 9554373044714 := by decide
theorem cert_e758280022506 : check e758280022506 [] .sourceHead = true := by decide
def e758280023658 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e758280023658 : Closed e758280023658 ∧ code e758280023658 = 9554373045866 := by decide
theorem cert_e758280023658 : check e758280023658 [] .sourceHead = true := by decide
def e758280024922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e758280024922 : Closed e758280024922 ∧ code e758280024922 = 9554373047130 := by decide
theorem cert_e758280024922 : check e758280024922 [] .sourceHead = true := by decide
def e758280024938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e758280024938 : Closed e758280024938 ∧ code e758280024938 = 9554373047146 := by decide
theorem cert_e758280024938 : check e758280024938 [] .sourceHead = true := by decide
def e758280025002 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e758280025002 : Closed e758280025002 ∧ code e758280025002 = 9554373047210 := by decide
theorem cert_e758280025002 : check e758280025002 [] .sourceHead = true := by decide
def e758280025306 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e758280025306 : Closed e758280025306 ∧ code e758280025306 = 9554373047514 := by decide
theorem cert_e758280025306 : check e758280025306 [] .sourceHead = true := by decide
def e758280025322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e758280025322 : Closed e758280025322 ∧ code e758280025322 = 9554373047530 := by decide
theorem cert_e758280025322 : check e758280025322 [] .sourceHead = true := by decide
def e758280025706 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e758280025706 : Closed e758280025706 ∧ code e758280025706 = 9554373047914 := by decide
theorem cert_e758280025706 : check e758280025706 [] .sourceHead = true := by decide
def e758280039866 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e758280039866 : Closed e758280039866 ∧ code e758280039866 = 9554373062074 := by decide
theorem cert_e758280039866 : check e758280039866 [] .sourceHead = true := by decide
def e758280039898 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e758280039898 : Closed e758280039898 ∧ code e758280039898 = 9554373062106 := by decide
theorem cert_e758280039898 : check e758280039898 [] .sourceHead = true := by decide
def e758280040122 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e758280040122 : Closed e758280040122 ∧ code e758280040122 = 9554373062330 := by decide
theorem cert_e758280040122 : check e758280040122 [] .sourceHead = true := by decide
def e758280040170 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e758280040170 : Closed e758280040170 ∧ code e758280040170 = 9554373062378 := by decide
theorem cert_e758280040170 : check e758280040170 [] .sourceHead = true := by decide
def e758280040282 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e758280040282 : Closed e758280040282 ∧ code e758280040282 = 9554373062490 := by decide
theorem cert_e758280040282 : check e758280040282 [] .sourceHead = true := by decide
def e758280040298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e758280040298 : Closed e758280040298 ∧ code e758280040298 = 9554373062506 := by decide
theorem cert_e758280040298 : check e758280040298 [] .sourceHead = true := by decide
def e758280041402 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e758280041402 : Closed e758280041402 ∧ code e758280041402 = 9554373063610 := by decide
theorem cert_e758280041402 : check e758280041402 [] .sourceHead = true := by decide
def e758280041434 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e758280041434 : Closed e758280041434 ∧ code e758280041434 = 9554373063642 := by decide
theorem cert_e758280041434 : check e758280041434 [] .sourceHead = true := by decide
def e758280042938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e758280042938 : Closed e758280042938 ∧ code e758280042938 = 9554373065146 := by decide
theorem cert_e758280042938 : check e758280042938 [] .sourceHead = true := by decide
def e758280042986 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e758280042986 : Closed e758280042986 ∧ code e758280042986 = 9554373065194 := by decide
theorem cert_e758280042986 : check e758280042986 [] .sourceHead = true := by decide
def e758280043738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e758280043738 : Closed e758280043738 ∧ code e758280043738 = 9554373065946 := by decide
theorem cert_e758280043738 : check e758280043738 [] .sourceHead = true := by decide
def e758280043754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e758280043754 : Closed e758280043754 ∧ code e758280043754 = 9554373065962 := by decide
theorem cert_e758280043754 : check e758280043754 [] .sourceHead = true := by decide
def e758280066746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e758280066746 : Closed e758280066746 ∧ code e758280066746 = 9554373088954 := by decide
theorem cert_e758280066746 : check e758280066746 [] .sourceHead = true := by decide
def e758280066794 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e758280066794 : Closed e758280066794 ∧ code e758280066794 = 9554373089002 := by decide
theorem cert_e758280066794 : check e758280066794 [] .sourceHead = true := by decide
def e758280066986 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e758280066986 : Closed e758280066986 ∧ code e758280066986 = 9554373089194 := by decide
theorem cert_e758280066986 : check e758280066986 [] .sourceHead = true := by decide
def e758280067514 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e758280067514 : Closed e758280067514 ∧ code e758280067514 = 9554373089722 := by decide
theorem cert_e758280067514 : check e758280067514 [] .sourceHead = true := by decide
def e758280067562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e758280067562 : Closed e758280067562 ∧ code e758280067562 = 9554373089770 := by decide
theorem cert_e758280067562 : check e758280067562 [] .sourceHead = true := by decide
def e758280068714 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e758280068714 : Closed e758280068714 ∧ code e758280068714 = 9554373090922 := by decide
theorem cert_e758280068714 : check e758280068714 [] .sourceHead = true := by decide
def e758280080218 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e758280080218 : Closed e758280080218 ∧ code e758280080218 = 9554373102426 := by decide
theorem cert_e758280080218 : check e758280080218 [] .sourceHead = true := by decide
def e758280080234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e758280080234 : Closed e758280080234 ∧ code e758280080234 = 9554373102442 := by decide
theorem cert_e758280080234 : check e758280080234 [] .sourceHead = true := by decide
def e758280080298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e758280080298 : Closed e758280080298 ∧ code e758280080298 = 9554373102506 := by decide
theorem cert_e758280080298 : check e758280080298 [] .sourceHead = true := by decide
def e758280080602 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e758280080602 : Closed e758280080602 ∧ code e758280080602 = 9554373102810 := by decide
theorem cert_e758280080602 : check e758280080602 [] .sourceHead = true := by decide
def e758280080618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e758280080618 : Closed e758280080618 ∧ code e758280080618 = 9554373102826 := by decide
theorem cert_e758280080618 : check e758280080618 [] .sourceHead = true := by decide
def e758280081002 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e758280081002 : Closed e758280081002 ∧ code e758280081002 = 9554373103210 := by decide
theorem cert_e758280081002 : check e758280081002 [] .sourceHead = true := by decide
def e758280629690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e758280629690 : Closed e758280629690 ∧ code e758280629690 = 9554373651898 := by decide
theorem cert_e758280629690 : check e758280629690 [] .sourceHead = true := by decide
def e758280629722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e758280629722 : Closed e758280629722 ∧ code e758280629722 = 9554373651930 := by decide
theorem cert_e758280629722 : check e758280629722 [] .sourceHead = true := by decide
def e758280629946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e758280629946 : Closed e758280629946 ∧ code e758280629946 = 9554373652154 := by decide
theorem cert_e758280629946 : check e758280629946 [] .sourceHead = true := by decide
def e758280629994 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e758280629994 : Closed e758280629994 ∧ code e758280629994 = 9554373652202 := by decide
theorem cert_e758280629994 : check e758280629994 [] .sourceHead = true := by decide
def e758280630106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e758280630106 : Closed e758280630106 ∧ code e758280630106 = 9554373652314 := by decide
theorem cert_e758280630106 : check e758280630106 [] .sourceHead = true := by decide
def e758280630122 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e758280630122 : Closed e758280630122 ∧ code e758280630122 = 9554373652330 := by decide
theorem cert_e758280630122 : check e758280630122 [] .sourceHead = true := by decide
def e758280631226 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e758280631226 : Closed e758280631226 ∧ code e758280631226 = 9554373653434 := by decide
theorem cert_e758280631226 : check e758280631226 [] .sourceHead = true := by decide
def e758280631258 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e758280631258 : Closed e758280631258 ∧ code e758280631258 = 9554373653466 := by decide
theorem cert_e758280631258 : check e758280631258 [] .sourceHead = true := by decide
def e758280632762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e758280632762 : Closed e758280632762 ∧ code e758280632762 = 9554373654970 := by decide
theorem cert_e758280632762 : check e758280632762 [] .sourceHead = true := by decide
def e758280632810 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e758280632810 : Closed e758280632810 ∧ code e758280632810 = 9554373655018 := by decide
theorem cert_e758280632810 : check e758280632810 [] .sourceHead = true := by decide
def e758280633562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e758280633562 : Closed e758280633562 ∧ code e758280633562 = 9554373655770 := by decide
theorem cert_e758280633562 : check e758280633562 [] .sourceHead = true := by decide
def e758280633578 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e758280633578 : Closed e758280633578 ∧ code e758280633578 = 9554373655786 := by decide
theorem cert_e758280633578 : check e758280633578 [] .sourceHead = true := by decide
def e758870030874 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870030874 : Closed e758870030874 ∧ code e758870030874 = 9554963053082 := by decide
theorem cert_e758870030874 : check e758870030874 [] .sourceHead = true := by decide
def e758870039066 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870039066 : Closed e758870039066 ∧ code e758870039066 = 9554963061274 := by decide
theorem cert_e758870039066 : check e758870039066 [] .sourceHead = true := by decide
def e758870096410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870096410 : Closed e758870096410 ∧ code e758870096410 = 9554963118618 := by decide
theorem cert_e758870096410 : check e758870096410 [] .sourceHead = true := by decide
def e758870108698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870108698 : Closed e758870108698 ∧ code e758870108698 = 9554963130906 := by decide
theorem cert_e758870108698 : check e758870108698 [] .sourceHead = true := by decide
def e758870137370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870137370 : Closed e758870137370 ∧ code e758870137370 = 9554963159578 := by decide
theorem cert_e758870137370 : check e758870137370 [] .sourceHead = true := by decide
def e758870141466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870141466 : Closed e758870141466 ∧ code e758870141466 = 9554963163674 := by decide
theorem cert_e758870141466 : check e758870141466 [] .sourceHead = true := by decide
def e758870424090 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870424090 : Closed e758870424090 ∧ code e758870424090 = 9554963446298 := by decide
theorem cert_e758870424090 : check e758870424090 [] .sourceHead = true := by decide
def e758870432282 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870432282 : Closed e758870432282 ∧ code e758870432282 = 9554963454490 := by decide
theorem cert_e758870432282 : check e758870432282 [] .sourceHead = true := by decide
def e758870817306 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870817306 : Closed e758870817306 ∧ code e758870817306 = 9554963839514 := by decide
theorem cert_e758870817306 : check e758870817306 [] .sourceHead = true := by decide
def e758870829594 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758870829594 : Closed e758870829594 ∧ code e758870829594 = 9554963851802 := by decide
theorem cert_e758870829594 : check e758870829594 [] .sourceHead = true := by decide
def e758871022106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758871022106 : Closed e758871022106 ∧ code e758871022106 = 9554964044314 := by decide
theorem cert_e758871022106 : check e758871022106 [] .sourceHead = true := by decide
def e758871026202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758871026202 : Closed e758871026202 ∧ code e758871026202 = 9554964048410 := by decide
theorem cert_e758871026202 : check e758871026202 [] .sourceHead = true := by decide
def e758934892058 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758934892058 : Closed e758934892058 ∧ code e758934892058 = 9555027914266 := by decide
theorem cert_e758934892058 : check e758934892058 [] .sourceHead = true := by decide
def e758934894106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e758934894106 : Closed e758934894106 ∧ code e758934894106 = 9555027916314 := by decide
theorem cert_e758934894106 : check e758934894106 [] .sourceHead = true := by decide
end Blc.Floor43
