import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e759147870746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147870746 : Closed e759147870746 ∧ code e759147870746 = 9555240892954 := by decide
theorem cert_e759147870746 : check e759147870746 [] .sourceHead = true := by decide
def e759147880474 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759147880474 : Closed e759147880474 ∧ code e759147880474 = 9555240902682 := by decide
theorem cert_e759147880474 : check e759147880474 [] .sourceHead = true := by decide
def e759147880566 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759147880566 : Closed e759147880566 ∧ code e759147880566 = 9555240902774 := by decide
theorem cert_e759147880566 : check e759147880566 [] .sourceHead = true := by decide
def e759147880810 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759147880810 : Closed e759147880810 ∧ code e759147880810 = 9555240903018 := by decide
theorem cert_e759147880810 : check e759147880810 [] .sourceHead = true := by decide
def e759147880858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759147880858 : Closed e759147880858 ∧ code e759147880858 = 9555240903066 := by decide
theorem cert_e759147880858 : check e759147880858 [] .sourceHead = true := by decide
def e759147882010 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759147882010 : Closed e759147882010 ∧ code e759147882010 = 9555240904218 := by decide
theorem cert_e759147882010 : check e759147882010 [] .sourceHead = true := by decide
def e759147895322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759147895322 : Closed e759147895322 ∧ code e759147895322 = 9555240917530 := by decide
theorem cert_e759147895322 : check e759147895322 [] .sourceHead = true := by decide
def e759147896858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759147896858 : Closed e759147896858 ∧ code e759147896858 = 9555240919066 := by decide
theorem cert_e759147896858 : check e759147896858 [] .sourceHead = true := by decide
def e759147896950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759147896950 : Closed e759147896950 ∧ code e759147896950 = 9555240919158 := by decide
theorem cert_e759147896950 : check e759147896950 [] .sourceHead = true := by decide
def e759147897194 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759147897194 : Closed e759147897194 ∧ code e759147897194 = 9555240919402 := by decide
theorem cert_e759147897194 : check e759147897194 [] .sourceHead = true := by decide
def e759147897242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759147897242 : Closed e759147897242 ∧ code e759147897242 = 9555240919450 := by decide
theorem cert_e759147897242 : check e759147897242 [] .sourceHead = true := by decide
def e759147898394 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759147898394 : Closed e759147898394 ∧ code e759147898394 = 9555240920602 := by decide
theorem cert_e759147898394 : check e759147898394 [] .sourceHead = true := by decide
def e759148305946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148305946 : Closed e759148305946 ∧ code e759148305946 = 9555241328154 := by decide
theorem cert_e759148305946 : check e759148305946 [] .sourceHead = true := by decide
def e759148310042 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148310042 : Closed e759148310042 ∧ code e759148310042 = 9555241332250 := by decide
theorem cert_e759148310042 : check e759148310042 [] .sourceHead = true := by decide
def e759148801562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148801562 : Closed e759148801562 ∧ code e759148801562 = 9555241823770 := by decide
theorem cert_e759148801562 : check e759148801562 [] .sourceHead = true := by decide
def e759148803610 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148803610 : Closed e759148803610 ∧ code e759148803610 = 9555241825818 := by decide
theorem cert_e759148803610 : check e759148803610 [] .sourceHead = true := by decide
def e759148817946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148817946 : Closed e759148817946 ∧ code e759148817946 = 9555241840154 := by decide
theorem cert_e759148817946 : check e759148817946 [] .sourceHead = true := by decide
def e759148821018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148821018 : Closed e759148821018 ∧ code e759148821018 = 9555241843226 := by decide
theorem cert_e759148821018 : check e759148821018 [] .sourceHead = true := by decide
def e759148828186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148828186 : Closed e759148828186 ∧ code e759148828186 = 9555241850394 := by decide
theorem cert_e759148828186 : check e759148828186 [] .sourceHead = true := by decide
def e759148829210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148829210 : Closed e759148829210 ∧ code e759148829210 = 9555241851418 := by decide
theorem cert_e759148829210 : check e759148829210 [] .sourceHead = true := by decide
def e759148899866 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148899866 : Closed e759148899866 ∧ code e759148899866 = 9555241922074 := by decide
theorem cert_e759148899866 : check e759148899866 [] .sourceHead = true := by decide
def e759148901914 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148901914 : Closed e759148901914 ∧ code e759148901914 = 9555241924122 := by decide
theorem cert_e759148901914 : check e759148901914 [] .sourceHead = true := by decide
def e759148998170 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759148998170 : Closed e759148998170 ∧ code e759148998170 = 9555242020378 := by decide
theorem cert_e759148998170 : check e759148998170 [] .sourceHead = true := by decide
def e759149001242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759149001242 : Closed e759149001242 ∧ code e759149001242 = 9555242023450 := by decide
theorem cert_e759149001242 : check e759149001242 [] .sourceHead = true := by decide
def e759149027354 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759149027354 : Closed e759149027354 ∧ code e759149027354 = 9555242049562 := by decide
theorem cert_e759149027354 : check e759149027354 [] .sourceHead = true := by decide
def e759149027446 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759149027446 : Closed e759149027446 ∧ code e759149027446 = 9555242049654 := by decide
theorem cert_e759149027446 : check e759149027446 [] .sourceHead = true := by decide
def e759149027690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759149027690 : Closed e759149027690 ∧ code e759149027690 = 9555242049898 := by decide
theorem cert_e759149027690 : check e759149027690 [] .sourceHead = true := by decide
def e759149027738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759149027738 : Closed e759149027738 ∧ code e759149027738 = 9555242049946 := by decide
theorem cert_e759149027738 : check e759149027738 [] .sourceHead = true := by decide
def e759149028890 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759149028890 : Closed e759149028890 ∧ code e759149028890 = 9555242051098 := by decide
theorem cert_e759149028890 : check e759149028890 [] .sourceHead = true := by decide
def e759149049370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759149049370 : Closed e759149049370 ∧ code e759149049370 = 9555242071578 := by decide
theorem cert_e759149049370 : check e759149049370 [] .sourceHead = true := by decide
def e759149050394 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759149050394 : Closed e759149050394 ∧ code e759149050394 = 9555242072602 := by decide
theorem cert_e759149050394 : check e759149050394 [] .sourceHead = true := by decide
def e759149060122 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759149060122 : Closed e759149060122 ∧ code e759149060122 = 9555242082330 := by decide
theorem cert_e759149060122 : check e759149060122 [] .sourceHead = true := by decide
def e759149060214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759149060214 : Closed e759149060214 ∧ code e759149060214 = 9555242082422 := by decide
theorem cert_e759149060214 : check e759149060214 [] .sourceHead = true := by decide
def e759149060458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759149060458 : Closed e759149060458 ∧ code e759149060458 = 9555242082666 := by decide
theorem cert_e759149060458 : check e759149060458 [] .sourceHead = true := by decide
def e759149060506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759149060506 : Closed e759149060506 ∧ code e759149060506 = 9555242082714 := by decide
theorem cert_e759149060506 : check e759149060506 [] .sourceHead = true := by decide
def e759149061658 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759149061658 : Closed e759149061658 ∧ code e759149061658 = 9555242083866 := by decide
theorem cert_e759149061658 : check e759149061658 [] .sourceHead = true := by decide
def e759150272026 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759150272026 : Closed e759150272026 ∧ code e759150272026 = 9555243294234 := by decide
theorem cert_e759150272026 : check e759150272026 [] .sourceHead = true := by decide
def e759150278170 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759150278170 : Closed e759150278170 ∧ code e759150278170 = 9555243300378 := by decide
theorem cert_e759150278170 : check e759150278170 [] .sourceHead = true := by decide
def e759150521882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759150521882 : Closed e759150521882 ∧ code e759150521882 = 9555243544090 := by decide
theorem cert_e759150521882 : check e759150521882 [] .sourceHead = true := by decide
def e759150524954 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759150524954 : Closed e759150524954 ∧ code e759150524954 = 9555243547162 := by decide
theorem cert_e759150524954 : check e759150524954 [] .sourceHead = true := by decide
def e759150537242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759150537242 : Closed e759150537242 ∧ code e759150537242 = 9555243559450 := by decide
theorem cert_e759150537242 : check e759150537242 [] .sourceHead = true := by decide
def e759150571034 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759150571034 : Closed e759150571034 ∧ code e759150571034 = 9555243593242 := by decide
theorem cert_e759150571034 : check e759150571034 [] .sourceHead = true := by decide
def e759150574106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759150574106 : Closed e759150574106 ∧ code e759150574106 = 9555243596314 := by decide
theorem cert_e759150574106 : check e759150574106 [] .sourceHead = true := by decide
def e759150600218 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759150600218 : Closed e759150600218 ∧ code e759150600218 = 9555243622426 := by decide
theorem cert_e759150600218 : check e759150600218 [] .sourceHead = true := by decide
def e759150600310 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759150600310 : Closed e759150600310 ∧ code e759150600310 = 9555243622518 := by decide
theorem cert_e759150600310 : check e759150600310 [] .sourceHead = true := by decide
def e759150600554 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759150600554 : Closed e759150600554 ∧ code e759150600554 = 9555243622762 := by decide
theorem cert_e759150600554 : check e759150600554 [] .sourceHead = true := by decide
def e759150600602 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759150600602 : Closed e759150600602 ∧ code e759150600602 = 9555243622810 := by decide
theorem cert_e759150600602 : check e759150600602 [] .sourceHead = true := by decide
def e759150601754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759150601754 : Closed e759150601754 ∧ code e759150601754 = 9555243623962 := by decide
theorem cert_e759150601754 : check e759150601754 [] .sourceHead = true := by decide
def e759150647834 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759150647834 : Closed e759150647834 ∧ code e759150647834 = 9555243670042 := by decide
theorem cert_e759150647834 : check e759150647834 [] .sourceHead = true := by decide
def e759150649370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759150649370 : Closed e759150649370 ∧ code e759150649370 = 9555243671578 := by decide
theorem cert_e759150649370 : check e759150649370 [] .sourceHead = true := by decide
def e759150649462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759150649462 : Closed e759150649462 ∧ code e759150649462 = 9555243671670 := by decide
theorem cert_e759150649462 : check e759150649462 [] .sourceHead = true := by decide
def e759150649706 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759150649706 : Closed e759150649706 ∧ code e759150649706 = 9555243671914 := by decide
theorem cert_e759150649706 : check e759150649706 [] .sourceHead = true := by decide
def e759150649754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759150649754 : Closed e759150649754 ∧ code e759150649754 = 9555243671962 := by decide
theorem cert_e759150649754 : check e759150649754 [] .sourceHead = true := by decide
def e759150650906 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759150650906 : Closed e759150650906 ∧ code e759150650906 = 9555243673114 := by decide
theorem cert_e759150650906 : check e759150650906 [] .sourceHead = true := by decide
def e759151259162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759151259162 : Closed e759151259162 ∧ code e759151259162 = 9555244281370 := by decide
theorem cert_e759151259162 : check e759151259162 [] .sourceHead = true := by decide
def e759151261210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759151261210 : Closed e759151261210 ∧ code e759151261210 = 9555244283418 := by decide
theorem cert_e759151261210 : check e759151261210 [] .sourceHead = true := by decide
def e759151384090 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759151384090 : Closed e759151384090 ∧ code e759151384090 = 9555244406298 := by decide
theorem cert_e759151384090 : check e759151384090 [] .sourceHead = true := by decide
def e759151385114 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759151385114 : Closed e759151385114 ∧ code e759151385114 = 9555244407322 := by decide
theorem cert_e759151385114 : check e759151385114 [] .sourceHead = true := by decide
def e759151389210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759151389210 : Closed e759151389210 ∧ code e759151389210 = 9555244411418 := by decide
theorem cert_e759151389210 : check e759151389210 [] .sourceHead = true := by decide
def e759151408666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759151408666 : Closed e759151408666 ∧ code e759151408666 = 9555244430874 := by decide
theorem cert_e759151408666 : check e759151408666 [] .sourceHead = true := by decide
def e759151409690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759151409690 : Closed e759151409690 ∧ code e759151409690 = 9555244431898 := by decide
theorem cert_e759151409690 : check e759151409690 [] .sourceHead = true := by decide
def e759151419418 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759151419418 : Closed e759151419418 ∧ code e759151419418 = 9555244441626 := by decide
theorem cert_e759151419418 : check e759151419418 [] .sourceHead = true := by decide
def e759151419510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759151419510 : Closed e759151419510 ∧ code e759151419510 = 9555244441718 := by decide
theorem cert_e759151419510 : check e759151419510 [] .sourceHead = true := by decide
def e759151419754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759151419754 : Closed e759151419754 ∧ code e759151419754 = 9555244441962 := by decide
theorem cert_e759151419754 : check e759151419754 [] .sourceHead = true := by decide
def e759151419802 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759151419802 : Closed e759151419802 ∧ code e759151419802 = 9555244442010 := by decide
theorem cert_e759151419802 : check e759151419802 [] .sourceHead = true := by decide
def e759151420954 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759151420954 : Closed e759151420954 ∧ code e759151420954 = 9555244443162 := by decide
theorem cert_e759151420954 : check e759151420954 [] .sourceHead = true := by decide
def e759151434266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759151434266 : Closed e759151434266 ∧ code e759151434266 = 9555244456474 := by decide
theorem cert_e759151434266 : check e759151434266 [] .sourceHead = true := by decide
def e759151435802 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e759151435802 : Closed e759151435802 ∧ code e759151435802 = 9555244458010 := by decide
theorem cert_e759151435802 : check e759151435802 [] .sourceHead = true := by decide
def e759151435894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e759151435894 : Closed e759151435894 ∧ code e759151435894 = 9555244458102 := by decide
theorem cert_e759151435894 : check e759151435894 [] .sourceHead = true := by decide
def e759151436138 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e759151436138 : Closed e759151436138 ∧ code e759151436138 = 9555244458346 := by decide
theorem cert_e759151436138 : check e759151436138 [] .sourceHead = true := by decide
def e759151436186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e759151436186 : Closed e759151436186 ∧ code e759151436186 = 9555244458394 := by decide
theorem cert_e759151436186 : check e759151436186 [] .sourceHead = true := by decide
def e759151437338 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e759151437338 : Closed e759151437338 ∧ code e759151437338 = 9555244459546 := by decide
theorem cert_e759151437338 : check e759151437338 [] .sourceHead = true := by decide
def e759186550298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186550298 : Closed e759186550298 ∧ code e759186550298 = 9555279572506 := by decide
theorem cert_e759186550298 : check e759186550298 [] .sourceHead = true := by decide
def e759186552346 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186552346 : Closed e759186552346 ∧ code e759186552346 = 9555279574554 := by decide
theorem cert_e759186552346 : check e759186552346 [] .sourceHead = true := by decide
def e759186566682 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186566682 : Closed e759186566682 ∧ code e759186566682 = 9555279588890 := by decide
theorem cert_e759186566682 : check e759186566682 [] .sourceHead = true := by decide
def e759186569754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186569754 : Closed e759186569754 ∧ code e759186569754 = 9555279591962 := by decide
theorem cert_e759186569754 : check e759186569754 [] .sourceHead = true := by decide
def e759186576922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186576922 : Closed e759186576922 ∧ code e759186576922 = 9555279599130 := by decide
theorem cert_e759186576922 : check e759186576922 [] .sourceHead = true := by decide
def e759186577946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186577946 : Closed e759186577946 ∧ code e759186577946 = 9555279600154 := by decide
theorem cert_e759186577946 : check e759186577946 [] .sourceHead = true := by decide
def e759186648602 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186648602 : Closed e759186648602 ∧ code e759186648602 = 9555279670810 := by decide
theorem cert_e759186648602 : check e759186648602 [] .sourceHead = true := by decide
def e759186650650 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186650650 : Closed e759186650650 ∧ code e759186650650 = 9555279672858 := by decide
theorem cert_e759186650650 : check e759186650650 [] .sourceHead = true := by decide
def e759186746906 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186746906 : Closed e759186746906 ∧ code e759186746906 = 9555279769114 := by decide
theorem cert_e759186746906 : check e759186746906 [] .sourceHead = true := by decide
def e759186749978 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186749978 : Closed e759186749978 ∧ code e759186749978 = 9555279772186 := by decide
theorem cert_e759186749978 : check e759186749978 [] .sourceHead = true := by decide
def e759186798106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186798106 : Closed e759186798106 ∧ code e759186798106 = 9555279820314 := by decide
theorem cert_e759186798106 : check e759186798106 [] .sourceHead = true := by decide
def e759186799130 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759186799130 : Closed e759186799130 ∧ code e759186799130 = 9555279821338 := by decide
theorem cert_e759186799130 : check e759186799130 [] .sourceHead = true := by decide
def e759236221806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e759236221806 : Closed e759236221806 ∧ code e759236221806 = 9555329244014 := by decide
theorem cert_e759236221806 : check e759236221806 [] .sourceHead = true := by decide
def e759236221814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e759236221814 : Closed e759236221814 ∧ code e759236221814 = 9555329244022 := by decide
theorem cert_e759236221814 : check e759236221814 [] .sourceHead = true := by decide
def e759236221878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e759236221878 : Closed e759236221878 ∧ code e759236221878 = 9555329244086 := by decide
theorem cert_e759236221878 : check e759236221878 [] .sourceHead = true := by decide
def e759236222318 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e759236222318 : Closed e759236222318 ∧ code e759236222318 = 9555329244526 := by decide
theorem cert_e759236222318 : check e759236222318 [] .sourceHead = true := by decide
def e759236222326 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e759236222326 : Closed e759236222326 ∧ code e759236222326 = 9555329244534 := by decide
theorem cert_e759236222326 : check e759236222326 [] .sourceHead = true := by decide
def e759236222382 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e759236222382 : Closed e759236222382 ∧ code e759236222382 = 9555329244590 := by decide
theorem cert_e759236222382 : check e759236222382 [] .sourceHead = true := by decide
def e759236222394 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e759236222394 : Closed e759236222394 ∧ code e759236222394 = 9555329244602 := by decide
theorem cert_e759236222394 : check e759236222394 [] .sourceHead = true := by decide
def e759236222422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e759236222422 : Closed e759236222422 ∧ code e759236222422 = 9555329244630 := by decide
theorem cert_e759236222422 : check e759236222422 [] .sourceHead = true := by decide
def e759236222426 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e759236222426 : Closed e759236222426 ∧ code e759236222426 = 9555329244634 := by decide
theorem cert_e759236222426 : check e759236222426 [] .sourceHead = true := by decide
def e759236222646 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e759236222646 : Closed e759236222646 ∧ code e759236222646 = 9555329244854 := by decide
theorem cert_e759236222646 : check e759236222646 [] .sourceHead = true := by decide
def e759236222678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e759236222678 : Closed e759236222678 ∧ code e759236222678 = 9555329244886 := by decide
theorem cert_e759236222678 : check e759236222678 [] .sourceHead = true := by decide
def e759236222682 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e759236222682 : Closed e759236222682 ∧ code e759236222682 = 9555329244890 := by decide
theorem cert_e759236222682 : check e759236222682 [] .sourceHead = true := by decide
def e759236224878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e759236224878 : Closed e759236224878 ∧ code e759236224878 = 9555329247086 := by decide
theorem cert_e759236224878 : check e759236224878 [] .sourceHead = true := by decide
def e759236224886 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e759236224886 : Closed e759236224886 ∧ code e759236224886 = 9555329247094 := by decide
theorem cert_e759236224886 : check e759236224886 [] .sourceHead = true := by decide
def e759236224950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e759236224950 : Closed e759236224950 ∧ code e759236224950 = 9555329247158 := by decide
theorem cert_e759236224950 : check e759236224950 [] .sourceHead = true := by decide
def e759236226286 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e759236226286 : Closed e759236226286 ∧ code e759236226286 = 9555329248494 := by decide
theorem cert_e759236226286 : check e759236226286 [] .sourceHead = true := by decide
def e759236226294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e759236226294 : Closed e759236226294 ∧ code e759236226294 = 9555329248502 := by decide
theorem cert_e759236226294 : check e759236226294 [] .sourceHead = true := by decide
def e759236226678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e759236226678 : Closed e759236226678 ∧ code e759236226678 = 9555329248886 := by decide
theorem cert_e759236226678 : check e759236226678 [] .sourceHead = true := by decide
def e759236227950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e759236227950 : Closed e759236227950 ∧ code e759236227950 = 9555329250158 := by decide
theorem cert_e759236227950 : check e759236227950 [] .sourceHead = true := by decide
def e759236227958 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e759236227958 : Closed e759236227958 ∧ code e759236227958 = 9555329250166 := by decide
theorem cert_e759236227958 : check e759236227958 [] .sourceHead = true := by decide
def e759236228014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e759236228014 : Closed e759236228014 ∧ code e759236228014 = 9555329250222 := by decide
theorem cert_e759236228014 : check e759236228014 [] .sourceHead = true := by decide
def e759236228026 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e759236228026 : Closed e759236228026 ∧ code e759236228026 = 9555329250234 := by decide
theorem cert_e759236228026 : check e759236228026 [] .sourceHead = true := by decide
def e759236228054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e759236228054 : Closed e759236228054 ∧ code e759236228054 = 9555329250262 := by decide
theorem cert_e759236228054 : check e759236228054 [] .sourceHead = true := by decide
def e759236228058 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e759236228058 : Closed e759236228058 ∧ code e759236228058 = 9555329250266 := by decide
theorem cert_e759236228058 : check e759236228058 [] .sourceHead = true := by decide
def e759236228334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e759236228334 : Closed e759236228334 ∧ code e759236228334 = 9555329250542 := by decide
theorem cert_e759236228334 : check e759236228334 [] .sourceHead = true := by decide
def e759236228342 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e759236228342 : Closed e759236228342 ∧ code e759236228342 = 9555329250550 := by decide
theorem cert_e759236228342 : check e759236228342 [] .sourceHead = true := by decide
def e759236228718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e759236228718 : Closed e759236228718 ∧ code e759236228718 = 9555329250926 := by decide
theorem cert_e759236228718 : check e759236228718 [] .sourceHead = true := by decide
def e759236228730 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e759236228730 : Closed e759236228730 ∧ code e759236228730 = 9555329250938 := by decide
theorem cert_e759236228730 : check e759236228730 [] .sourceHead = true := by decide
def e759236228918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e759236228918 : Closed e759236228918 ∧ code e759236228918 = 9555329251126 := by decide
theorem cert_e759236228918 : check e759236228918 [] .sourceHead = true := by decide
def e759236228922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e759236228922 : Closed e759236228922 ∧ code e759236228922 = 9555329251130 := by decide
theorem cert_e759236228922 : check e759236228922 [] .sourceHead = true := by decide
def e759236229558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e759236229558 : Closed e759236229558 ∧ code e759236229558 = 9555329251766 := by decide
theorem cert_e759236229558 : check e759236229558 [] .sourceHead = true := by decide
def e759236229590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e759236229590 : Closed e759236229590 ∧ code e759236229590 = 9555329251798 := by decide
theorem cert_e759236229590 : check e759236229590 [] .sourceHead = true := by decide
def e759236229594 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e759236229594 : Closed e759236229594 ∧ code e759236229594 = 9555329251802 := by decide
theorem cert_e759236229594 : check e759236229594 [] .sourceHead = true := by decide
def e759236229750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e759236229750 : Closed e759236229750 ∧ code e759236229750 = 9555329251958 := by decide
theorem cert_e759236229750 : check e759236229750 [] .sourceHead = true := by decide
def e759236229942 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e759236229942 : Closed e759236229942 ∧ code e759236229942 = 9555329252150 := by decide
theorem cert_e759236229942 : check e759236229942 [] .sourceHead = true := by decide
def e759236229946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e759236229946 : Closed e759236229946 ∧ code e759236229946 = 9555329252154 := by decide
theorem cert_e759236229946 : check e759236229946 [] .sourceHead = true := by decide
def e759236237166 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e759236237166 : Closed e759236237166 ∧ code e759236237166 = 9555329259374 := by decide
theorem cert_e759236237166 : check e759236237166 [] .sourceHead = true := by decide
def e759236237174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e759236237174 : Closed e759236237174 ∧ code e759236237174 = 9555329259382 := by decide
theorem cert_e759236237174 : check e759236237174 [] .sourceHead = true := by decide
def e759236237238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e759236237238 : Closed e759236237238 ∧ code e759236237238 = 9555329259446 := by decide
theorem cert_e759236237238 : check e759236237238 [] .sourceHead = true := by decide
def e759236238574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e759236238574 : Closed e759236238574 ∧ code e759236238574 = 9555329260782 := by decide
theorem cert_e759236238574 : check e759236238574 [] .sourceHead = true := by decide
def e759236238582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e759236238582 : Closed e759236238582 ∧ code e759236238582 = 9555329260790 := by decide
theorem cert_e759236238582 : check e759236238582 [] .sourceHead = true := by decide
def e759236238966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e759236238966 : Closed e759236238966 ∧ code e759236238966 = 9555329261174 := by decide
theorem cert_e759236238966 : check e759236238966 [] .sourceHead = true := by decide
def e759236250478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e759236250478 : Closed e759236250478 ∧ code e759236250478 = 9555329272686 := by decide
theorem cert_e759236250478 : check e759236250478 [] .sourceHead = true := by decide
def e759236250486 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e759236250486 : Closed e759236250486 ∧ code e759236250486 = 9555329272694 := by decide
theorem cert_e759236250486 : check e759236250486 [] .sourceHead = true := by decide
def e759236250542 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e759236250542 : Closed e759236250542 ∧ code e759236250542 = 9555329272750 := by decide
theorem cert_e759236250542 : check e759236250542 [] .sourceHead = true := by decide
def e759236250554 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e759236250554 : Closed e759236250554 ∧ code e759236250554 = 9555329272762 := by decide
theorem cert_e759236250554 : check e759236250554 [] .sourceHead = true := by decide
def e759236250582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e759236250582 : Closed e759236250582 ∧ code e759236250582 = 9555329272790 := by decide
theorem cert_e759236250582 : check e759236250582 [] .sourceHead = true := by decide
def e759236250586 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e759236250586 : Closed e759236250586 ∧ code e759236250586 = 9555329272794 := by decide
theorem cert_e759236250586 : check e759236250586 [] .sourceHead = true := by decide
def e759236250862 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e759236250862 : Closed e759236250862 ∧ code e759236250862 = 9555329273070 := by decide
theorem cert_e759236250862 : check e759236250862 [] .sourceHead = true := by decide
def e759236250870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e759236250870 : Closed e759236250870 ∧ code e759236250870 = 9555329273078 := by decide
theorem cert_e759236250870 : check e759236250870 [] .sourceHead = true := by decide
def e759236251246 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e759236251246 : Closed e759236251246 ∧ code e759236251246 = 9555329273454 := by decide
theorem cert_e759236251246 : check e759236251246 [] .sourceHead = true := by decide
def e759236251258 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e759236251258 : Closed e759236251258 ∧ code e759236251258 = 9555329273466 := by decide
theorem cert_e759236251258 : check e759236251258 [] .sourceHead = true := by decide
def e759236251446 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e759236251446 : Closed e759236251446 ∧ code e759236251446 = 9555329273654 := by decide
theorem cert_e759236251446 : check e759236251446 [] .sourceHead = true := by decide
def e759236251450 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e759236251450 : Closed e759236251450 ∧ code e759236251450 = 9555329273658 := by decide
theorem cert_e759236251450 : check e759236251450 [] .sourceHead = true := by decide
def e759236257206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e759236257206 : Closed e759236257206 ∧ code e759236257206 = 9555329279414 := by decide
theorem cert_e759236257206 : check e759236257206 [] .sourceHead = true := by decide
def e759236257238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e759236257238 : Closed e759236257238 ∧ code e759236257238 = 9555329279446 := by decide
theorem cert_e759236257238 : check e759236257238 [] .sourceHead = true := by decide
def e759236257242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e759236257242 : Closed e759236257242 ∧ code e759236257242 = 9555329279450 := by decide
theorem cert_e759236257242 : check e759236257242 [] .sourceHead = true := by decide
def e759236257398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e759236257398 : Closed e759236257398 ∧ code e759236257398 = 9555329279606 := by decide
theorem cert_e759236257398 : check e759236257398 [] .sourceHead = true := by decide
def e759236257590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e759236257590 : Closed e759236257590 ∧ code e759236257590 = 9555329279798 := by decide
theorem cert_e759236257590 : check e759236257590 [] .sourceHead = true := by decide
def e759236257594 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e759236257594 : Closed e759236257594 ∧ code e759236257594 = 9555329279802 := by decide
theorem cert_e759236257594 : check e759236257594 [] .sourceHead = true := by decide
def e759236594542 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e759236594542 : Closed e759236594542 ∧ code e759236594542 = 9555329616750 := by decide
theorem cert_e759236594542 : check e759236594542 [] .sourceHead = true := by decide
def e759236594550 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e759236594550 : Closed e759236594550 ∧ code e759236594550 = 9555329616758 := by decide
theorem cert_e759236594550 : check e759236594550 [] .sourceHead = true := by decide
def e759236594606 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e759236594606 : Closed e759236594606 ∧ code e759236594606 = 9555329616814 := by decide
theorem cert_e759236594606 : check e759236594606 [] .sourceHead = true := by decide
def e759236594618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e759236594618 : Closed e759236594618 ∧ code e759236594618 = 9555329616826 := by decide
theorem cert_e759236594618 : check e759236594618 [] .sourceHead = true := by decide
def e759236594646 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e759236594646 : Closed e759236594646 ∧ code e759236594646 = 9555329616854 := by decide
theorem cert_e759236594646 : check e759236594646 [] .sourceHead = true := by decide
def e759236594650 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e759236594650 : Closed e759236594650 ∧ code e759236594650 = 9555329616858 := by decide
theorem cert_e759236594650 : check e759236594650 [] .sourceHead = true := by decide
def e759236594926 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e759236594926 : Closed e759236594926 ∧ code e759236594926 = 9555329617134 := by decide
theorem cert_e759236594926 : check e759236594926 [] .sourceHead = true := by decide
def e759236594934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e759236594934 : Closed e759236594934 ∧ code e759236594934 = 9555329617142 := by decide
theorem cert_e759236594934 : check e759236594934 [] .sourceHead = true := by decide
def e759236595310 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e759236595310 : Closed e759236595310 ∧ code e759236595310 = 9555329617518 := by decide
theorem cert_e759236595310 : check e759236595310 [] .sourceHead = true := by decide
def e759236595322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e759236595322 : Closed e759236595322 ∧ code e759236595322 = 9555329617530 := by decide
theorem cert_e759236595322 : check e759236595322 [] .sourceHead = true := by decide
def e759236595510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e759236595510 : Closed e759236595510 ∧ code e759236595510 = 9555329617718 := by decide
theorem cert_e759236595510 : check e759236595510 [] .sourceHead = true := by decide
def e759236595514 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e759236595514 : Closed e759236595514 ∧ code e759236595514 = 9555329617722 := by decide
theorem cert_e759236595514 : check e759236595514 [] .sourceHead = true := by decide
def e759337545242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337545242 : Closed e759337545242 ∧ code e759337545242 = 9555430567450 := by decide
theorem cert_e759337545242 : check e759337545242 [] .sourceHead = true := by decide
def e759337547290 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337547290 : Closed e759337547290 ∧ code e759337547290 = 9555430569498 := by decide
theorem cert_e759337547290 : check e759337547290 [] .sourceHead = true := by decide
def e759337561626 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337561626 : Closed e759337561626 ∧ code e759337561626 = 9555430583834 := by decide
theorem cert_e759337561626 : check e759337561626 [] .sourceHead = true := by decide
def e759337564698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e759337564698 : Closed e759337564698 ∧ code e759337564698 = 9555430586906 := by decide
theorem cert_e759337564698 : check e759337564698 [] .sourceHead = true := by decide
end Blc.Floor43
