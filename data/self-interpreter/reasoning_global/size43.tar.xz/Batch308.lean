import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411630327030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630327030 : Closed e2411630327030 ∧ code e2411630327030 = 11207723349238 := by decide
theorem cert_e2411630327030 : check e2411630327030 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630327310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2411630327310 : Closed e2411630327310 ∧ code e2411630327310 = 11207723349518 := by decide
theorem cert_e2411630327310 : check e2411630327310 [[],[]] .chain = true := by decide
def e2411630327394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2411630327394 : Closed e2411630327394 ∧ code e2411630327394 = 11207723349602 := by decide
theorem cert_e2411630327394 : check e2411630327394 [[],[]] .chain = true := by decide
def e2411630327406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630327406 : Closed e2411630327406 ∧ code e2411630327406 = 11207723349614 := by decide
theorem cert_e2411630327406 : check e2411630327406 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630327418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630327418 : Closed e2411630327418 ∧ code e2411630327418 = 11207723349626 := by decide
theorem cert_e2411630327418 : check e2411630327418 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630327606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630327606 : Closed e2411630327606 ∧ code e2411630327606 = 11207723349814 := by decide
theorem cert_e2411630327606 : check e2411630327606 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630327610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630327610 : Closed e2411630327610 ∧ code e2411630327610 = 11207723349818 := by decide
theorem cert_e2411630327610 : check e2411630327610 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630328246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2411630328246 : Closed e2411630328246 ∧ code e2411630328246 = 11207723350454 := by decide
theorem cert_e2411630328246 : check e2411630328246 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630328278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2411630328278 : Closed e2411630328278 ∧ code e2411630328278 = 11207723350486 := by decide
theorem cert_e2411630328278 : check e2411630328278 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630328282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2411630328282 : Closed e2411630328282 ∧ code e2411630328282 = 11207723350490 := by decide
theorem cert_e2411630328282 : check e2411630328282 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630328438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2411630328438 : Closed e2411630328438 ∧ code e2411630328438 = 11207723350646 := by decide
theorem cert_e2411630328438 : check e2411630328438 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630328630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630328630 : Closed e2411630328630 ∧ code e2411630328630 = 11207723350838 := by decide
theorem cert_e2411630328630 : check e2411630328630 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630328634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630328634 : Closed e2411630328634 ∧ code e2411630328634 = 11207723350842 := by decide
theorem cert_e2411630328634 : check e2411630328634 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630331310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2411630331310 : Closed e2411630331310 ∧ code e2411630331310 = 11207723353518 := by decide
theorem cert_e2411630331310 : check e2411630331310 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630331322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2411630331322 : Closed e2411630331322 ∧ code e2411630331322 = 11207723353530 := by decide
theorem cert_e2411630331322 : check e2411630331322 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630331370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2411630331370 : Closed e2411630331370 ∧ code e2411630331370 = 11207723353578 := by decide
theorem cert_e2411630331370 : check e2411630331370 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630331502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630331502 : Closed e2411630331502 ∧ code e2411630331502 = 11207723353710 := by decide
theorem cert_e2411630331502 : check e2411630331502 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630331514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630331514 : Closed e2411630331514 ∧ code e2411630331514 = 11207723353722 := by decide
theorem cert_e2411630331514 : check e2411630331514 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630331678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411630331678 : Closed e2411630331678 ∧ code e2411630331678 = 11207723353886 := by decide
theorem cert_e2411630331678 : check e2411630331678 [[],[]] .chain = true := by decide
def e2411630331790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411630331790 : Closed e2411630331790 ∧ code e2411630331790 = 11207723353998 := by decide
theorem cert_e2411630331790 : check e2411630331790 [[],[]] .chain = true := by decide
def e2411630331802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411630331802 : Closed e2411630331802 ∧ code e2411630331802 = 11207723354010 := by decide
theorem cert_e2411630331802 : check e2411630331802 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630335542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411630335542 : Closed e2411630335542 ∧ code e2411630335542 = 11207723357750 := by decide
theorem cert_e2411630335542 : check e2411630335542 [[],[]] .chain = true := by decide
def e2411630335546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411630335546 : Closed e2411630335546 ∧ code e2411630335546 = 11207723357754 := by decide
theorem cert_e2411630335546 : check e2411630335546 [[],[]] .chain = true := by decide
def e2411630335630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411630335630 : Closed e2411630335630 ∧ code e2411630335630 = 11207723357838 := by decide
theorem cert_e2411630335630 : check e2411630335630 [[],[]] .chain = true := by decide
def e2411630335686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411630335686 : Closed e2411630335686 ∧ code e2411630335686 = 11207723357894 := by decide
theorem cert_e2411630335686 : check e2411630335686 [[],[]] .chain = true := by decide
def e2411630335766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411630335766 : Closed e2411630335766 ∧ code e2411630335766 = 11207723357974 := by decide
theorem cert_e2411630335766 : check e2411630335766 [[],[]] .chain = true := by decide
def e2411630335770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411630335770 : Closed e2411630335770 ∧ code e2411630335770 = 11207723357978 := by decide
theorem cert_e2411630335770 : check e2411630335770 [[],[]] .chain = true := by decide
def e2411630335814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411630335814 : Closed e2411630335814 ∧ code e2411630335814 = 11207723358022 := by decide
theorem cert_e2411630335814 : check e2411630335814 [[],[]] .chain = true := by decide
def e2411630335842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411630335842 : Closed e2411630335842 ∧ code e2411630335842 = 11207723358050 := by decide
theorem cert_e2411630335842 : check e2411630335842 [[],[]] .chain = true := by decide
def e2411630335854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2411630335854 : Closed e2411630335854 ∧ code e2411630335854 = 11207723358062 := by decide
theorem cert_e2411630335854 : check e2411630335854 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630335862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2411630335862 : Closed e2411630335862 ∧ code e2411630335862 = 11207723358070 := by decide
theorem cert_e2411630335862 : check e2411630335862 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630335926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2411630335926 : Closed e2411630335926 ∧ code e2411630335926 = 11207723358134 := by decide
theorem cert_e2411630335926 : check e2411630335926 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630336110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630336110 : Closed e2411630336110 ∧ code e2411630336110 = 11207723358318 := by decide
theorem cert_e2411630336110 : check e2411630336110 [[],[]] .chain = true := by decide
def e2411630336122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630336122 : Closed e2411630336122 ∧ code e2411630336122 = 11207723358330 := by decide
theorem cert_e2411630336122 : check e2411630336122 [[],[]] .chain = true := by decide
def e2411630336398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411630336398 : Closed e2411630336398 ∧ code e2411630336398 = 11207723358606 := by decide
theorem cert_e2411630336398 : check e2411630336398 [[],[]] .chain = true := by decide
def e2411630336454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411630336454 : Closed e2411630336454 ∧ code e2411630336454 = 11207723358662 := by decide
theorem cert_e2411630336454 : check e2411630336454 [[],[]] .chain = true := by decide
def e2411630337054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 3)))))))))
theorem wire_e2411630337054 : Closed e2411630337054 ∧ code e2411630337054 = 11207723359262 := by decide
theorem cert_e2411630337054 : check e2411630337054 [[],[]] .chain = true := by decide
def e2411630337078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630337078 : Closed e2411630337078 ∧ code e2411630337078 = 11207723359286 := by decide
theorem cert_e2411630337078 : check e2411630337078 [[],[]] .chain = true := by decide
def e2411630337082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630337082 : Closed e2411630337082 ∧ code e2411630337082 = 11207723359290 := by decide
theorem cert_e2411630337082 : check e2411630337082 [[],[]] .chain = true := by decide
def e2411630337222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411630337222 : Closed e2411630337222 ∧ code e2411630337222 = 11207723359430 := by decide
theorem cert_e2411630337222 : check e2411630337222 [[],[]] .chain = true := by decide
def e2411630337250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411630337250 : Closed e2411630337250 ∧ code e2411630337250 = 11207723359458 := by decide
theorem cert_e2411630337250 : check e2411630337250 [[],[]] .chain = true := by decide
def e2411630337262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630337262 : Closed e2411630337262 ∧ code e2411630337262 = 11207723359470 := by decide
theorem cert_e2411630337262 : check e2411630337262 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630337270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630337270 : Closed e2411630337270 ∧ code e2411630337270 = 11207723359478 := by decide
theorem cert_e2411630337270 : check e2411630337270 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630337654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2411630337654 : Closed e2411630337654 ∧ code e2411630337654 = 11207723359862 := by decide
theorem cert_e2411630337654 : check e2411630337654 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630346966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2411630346966 : Closed e2411630346966 ∧ code e2411630346966 = 11207723369174 := by decide
theorem cert_e2411630346966 : check e2411630346966 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630346970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2411630346970 : Closed e2411630346970 ∧ code e2411630346970 = 11207723369178 := by decide
theorem cert_e2411630346970 : check e2411630346970 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630346986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2411630346986 : Closed e2411630346986 ∧ code e2411630346986 = 11207723369194 := by decide
theorem cert_e2411630346986 : check e2411630346986 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630347062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630347062 : Closed e2411630347062 ∧ code e2411630347062 = 11207723369270 := by decide
theorem cert_e2411630347062 : check e2411630347062 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630347066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630347066 : Closed e2411630347066 ∧ code e2411630347066 = 11207723369274 := by decide
theorem cert_e2411630347066 : check e2411630347066 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630347150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2411630347150 : Closed e2411630347150 ∧ code e2411630347150 = 11207723369358 := by decide
theorem cert_e2411630347150 : check e2411630347150 [[],[]] .chain = true := by decide
def e2411630347162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411630347162 : Closed e2411630347162 ∧ code e2411630347162 = 11207723369370 := by decide
theorem cert_e2411630347162 : check e2411630347162 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411630349078 : Closed e2411630349078 ∧ code e2411630349078 = 11207723371286 := by decide
theorem cert_e2411630349078 : check e2411630349078 [[],[]] .chain = true := by decide
def e2411630349082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411630349082 : Closed e2411630349082 ∧ code e2411630349082 = 11207723371290 := by decide
theorem cert_e2411630349082 : check e2411630349082 [[],[]] .chain = true := by decide
def e2411630349126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411630349126 : Closed e2411630349126 ∧ code e2411630349126 = 11207723371334 := by decide
theorem cert_e2411630349126 : check e2411630349126 [[],[]] .chain = true := by decide
def e2411630349154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411630349154 : Closed e2411630349154 ∧ code e2411630349154 = 11207723371362 := by decide
theorem cert_e2411630349154 : check e2411630349154 [[],[]] .chain = true := by decide
def e2411630349166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2411630349166 : Closed e2411630349166 ∧ code e2411630349166 = 11207723371374 := by decide
theorem cert_e2411630349166 : check e2411630349166 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2411630349174 : Closed e2411630349174 ∧ code e2411630349174 = 11207723371382 := by decide
theorem cert_e2411630349174 : check e2411630349174 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2411630349194 : Closed e2411630349194 ∧ code e2411630349194 = 11207723371402 := by decide
theorem cert_e2411630349194 : check e2411630349194 [[],[]] .chain = true := by decide
def e2411630349218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2411630349218 : Closed e2411630349218 ∧ code e2411630349218 = 11207723371426 := by decide
theorem cert_e2411630349218 : check e2411630349218 [[],[]] .chain = true := by decide
def e2411630349230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2411630349230 : Closed e2411630349230 ∧ code e2411630349230 = 11207723371438 := by decide
theorem cert_e2411630349230 : check e2411630349230 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2411630349242 : Closed e2411630349242 ∧ code e2411630349242 = 11207723371450 := by decide
theorem cert_e2411630349242 : check e2411630349242 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2411630349270 : Closed e2411630349270 ∧ code e2411630349270 = 11207723371478 := by decide
theorem cert_e2411630349270 : check e2411630349270 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2411630349274 : Closed e2411630349274 ∧ code e2411630349274 = 11207723371482 := by decide
theorem cert_e2411630349274 : check e2411630349274 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2411630349342 : Closed e2411630349342 ∧ code e2411630349342 = 11207723371550 := by decide
theorem cert_e2411630349342 : check e2411630349342 [[],[]] .chain = true := by decide
def e2411630349366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630349366 : Closed e2411630349366 ∧ code e2411630349366 = 11207723371574 := by decide
theorem cert_e2411630349366 : check e2411630349366 [[],[]] .chain = true := by decide
def e2411630349370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630349370 : Closed e2411630349370 ∧ code e2411630349370 = 11207723371578 := by decide
theorem cert_e2411630349370 : check e2411630349370 [[],[]] .chain = true := by decide
def e2411630349510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411630349510 : Closed e2411630349510 ∧ code e2411630349510 = 11207723371718 := by decide
theorem cert_e2411630349510 : check e2411630349510 [[],[]] .chain = true := by decide
def e2411630349538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411630349538 : Closed e2411630349538 ∧ code e2411630349538 = 11207723371746 := by decide
theorem cert_e2411630349538 : check e2411630349538 [[],[]] .chain = true := by decide
def e2411630349550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630349550 : Closed e2411630349550 ∧ code e2411630349550 = 11207723371758 := by decide
theorem cert_e2411630349550 : check e2411630349550 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630349558 : Closed e2411630349558 ∧ code e2411630349558 = 11207723371766 := by decide
theorem cert_e2411630349558 : check e2411630349558 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2411630349838 : Closed e2411630349838 ∧ code e2411630349838 = 11207723372046 := by decide
theorem cert_e2411630349838 : check e2411630349838 [[],[]] .chain = true := by decide
def e2411630349922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2411630349922 : Closed e2411630349922 ∧ code e2411630349922 = 11207723372130 := by decide
theorem cert_e2411630349922 : check e2411630349922 [[],[]] .chain = true := by decide
def e2411630349934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2411630349934 : Closed e2411630349934 ∧ code e2411630349934 = 11207723372142 := by decide
theorem cert_e2411630349934 : check e2411630349934 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630349946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2411630349946 : Closed e2411630349946 ∧ code e2411630349946 = 11207723372154 := by decide
theorem cert_e2411630349946 : check e2411630349946 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630350134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2411630350134 : Closed e2411630350134 ∧ code e2411630350134 = 11207723372342 := by decide
theorem cert_e2411630350134 : check e2411630350134 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630350138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2411630350138 : Closed e2411630350138 ∧ code e2411630350138 = 11207723372346 := by decide
theorem cert_e2411630350138 : check e2411630350138 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630355894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2411630355894 : Closed e2411630355894 ∧ code e2411630355894 = 11207723378102 := by decide
theorem cert_e2411630355894 : check e2411630355894 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630355926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2411630355926 : Closed e2411630355926 ∧ code e2411630355926 = 11207723378134 := by decide
theorem cert_e2411630355926 : check e2411630355926 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630355930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2411630355930 : Closed e2411630355930 ∧ code e2411630355930 = 11207723378138 := by decide
theorem cert_e2411630355930 : check e2411630355930 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630356086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2411630356086 : Closed e2411630356086 ∧ code e2411630356086 = 11207723378294 := by decide
theorem cert_e2411630356086 : check e2411630356086 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630356278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2411630356278 : Closed e2411630356278 ∧ code e2411630356278 = 11207723378486 := by decide
theorem cert_e2411630356278 : check e2411630356278 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630356282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2411630356282 : Closed e2411630356282 ∧ code e2411630356282 = 11207723378490 := by decide
theorem cert_e2411630356282 : check e2411630356282 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630434014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2411630434014 : Closed e2411630434014 ∧ code e2411630434014 = 11207723456222 := by decide
theorem cert_e2411630434014 : check e2411630434014 [[],[]] .smaller = true := by decide
def e2411630434038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2411630434038 : Closed e2411630434038 ∧ code e2411630434038 = 11207723456246 := by decide
theorem cert_e2411630434038 : check e2411630434038 [[],[]] .smaller = true := by decide
def e2411630434142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2411630434142 : Closed e2411630434142 ∧ code e2411630434142 = 11207723456350 := by decide
theorem cert_e2411630434142 : check e2411630434142 [[],[]] .smaller = true := by decide
def e2411630434170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2411630434170 : Closed e2411630434170 ∧ code e2411630434170 = 11207723456378 := by decide
theorem cert_e2411630434170 : check e2411630434170 [[],[]] .smaller = true := by decide
def e2411630434262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2411630434262 : Closed e2411630434262 ∧ code e2411630434262 = 11207723456470 := by decide
theorem cert_e2411630434262 : check e2411630434262 [[],[]] .smaller = true := by decide
def e2411630434266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2411630434266 : Closed e2411630434266 ∧ code e2411630434266 = 11207723456474 := by decide
theorem cert_e2411630434266 : check e2411630434266 [[],[]] .smaller = true := by decide
def e2411630434782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2411630434782 : Closed e2411630434782 ∧ code e2411630434782 = 11207723456990 := by decide
theorem cert_e2411630434782 : check e2411630434782 [[],[]] .smaller = true := by decide
def e2411630434806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2411630434806 : Closed e2411630434806 ∧ code e2411630434806 = 11207723457014 := by decide
theorem cert_e2411630434806 : check e2411630434806 [[],[]] .smaller = true := by decide
def e2411630435550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2411630435550 : Closed e2411630435550 ∧ code e2411630435550 = 11207723457758 := by decide
theorem cert_e2411630435550 : check e2411630435550 [[],[]] .smaller = true := by decide
def e2411630435578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2411630435578 : Closed e2411630435578 ∧ code e2411630435578 = 11207723457786 := by decide
theorem cert_e2411630435578 : check e2411630435578 [[],[]] .smaller = true := by decide
def e2411630436150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2411630436150 : Closed e2411630436150 ∧ code e2411630436150 = 11207723458358 := by decide
theorem cert_e2411630436150 : check e2411630436150 [[],[]] .smaller = true := by decide
def e2411630436154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2411630436154 : Closed e2411630436154 ∧ code e2411630436154 = 11207723458362 := by decide
theorem cert_e2411630436154 : check e2411630436154 [[],[]] .smaller = true := by decide
def e2411630450926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2411630450926 : Closed e2411630450926 ∧ code e2411630450926 = 11207723473134 := by decide
theorem cert_e2411630450926 : check e2411630450926 [[],[]] .smaller = true := by decide
def e2411630450934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2411630450934 : Closed e2411630450934 ∧ code e2411630450934 = 11207723473142 := by decide
theorem cert_e2411630450934 : check e2411630450934 [[],[]] .smaller = true := by decide
def e2411630451486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2411630451486 : Closed e2411630451486 ∧ code e2411630451486 = 11207723473694 := by decide
theorem cert_e2411630451486 : check e2411630451486 [[],[]] .smaller = true := by decide
def e2411630451598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2411630451598 : Closed e2411630451598 ∧ code e2411630451598 = 11207723473806 := by decide
theorem cert_e2411630451598 : check e2411630451598 [[],[]] .smaller = true := by decide
def e2411630451646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e2411630451646 : Closed e2411630451646 ∧ code e2411630451646 = 11207723473854 := by decide
theorem cert_e2411630451646 : check e2411630451646 [[],[]] .chain = true := by decide
def e2411630451694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e2411630451694 : Closed e2411630451694 ∧ code e2411630451694 = 11207723473902 := by decide
theorem cert_e2411630451694 : check e2411630451694 [[],[]] .chain = true := by decide
def e2411630451822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2411630451822 : Closed e2411630451822 ∧ code e2411630451822 = 11207723474030 := by decide
theorem cert_e2411630451822 : check e2411630451822 [[],[]] .smaller = true := by decide
def e2411630451834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2411630451834 : Closed e2411630451834 ∧ code e2411630451834 = 11207723474042 := by decide
theorem cert_e2411630451834 : check e2411630451834 [[],[]] .smaller = true := by decide
def e2411630451998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2411630451998 : Closed e2411630451998 ∧ code e2411630451998 = 11207723474206 := by decide
theorem cert_e2411630451998 : check e2411630451998 [[],[]] .smaller = true := by decide
def e2411630452166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2411630452166 : Closed e2411630452166 ∧ code e2411630452166 = 11207723474374 := by decide
theorem cert_e2411630452166 : check e2411630452166 [[],[]] .smaller = true := by decide
def e2411630452190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e2411630452190 : Closed e2411630452190 ∧ code e2411630452190 = 11207723474398 := by decide
theorem cert_e2411630452190 : check e2411630452190 [[],[]] .smaller = true := by decide
def e2411630452206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e2411630452206 : Closed e2411630452206 ∧ code e2411630452206 = 11207723474414 := by decide
theorem cert_e2411630452206 : check e2411630452206 [[],[]] .smaller = true := by decide
def e2411630452278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2411630452278 : Closed e2411630452278 ∧ code e2411630452278 = 11207723474486 := by decide
theorem cert_e2411630452278 : check e2411630452278 [[],[]] .smaller = true := by decide
def e2411630452282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2411630452282 : Closed e2411630452282 ∧ code e2411630452282 = 11207723474490 := by decide
theorem cert_e2411630452282 : check e2411630452282 [[],[]] .smaller = true := by decide
def e2411630452366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2411630452366 : Closed e2411630452366 ∧ code e2411630452366 = 11207723474574 := by decide
theorem cert_e2411630452366 : check e2411630452366 [[],[]] .smaller = true := by decide
def e2411630452414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e2411630452414 : Closed e2411630452414 ∧ code e2411630452414 = 11207723474622 := by decide
theorem cert_e2411630452414 : check e2411630452414 [[],[]] .chain = true := by decide
def e2411630452422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2411630452422 : Closed e2411630452422 ∧ code e2411630452422 = 11207723474630 := by decide
theorem cert_e2411630452422 : check e2411630452422 [[],[]] .smaller = true := by decide
def e2411630452446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e2411630452446 : Closed e2411630452446 ∧ code e2411630452446 = 11207723474654 := by decide
theorem cert_e2411630452446 : check e2411630452446 [[],[]] .smaller = true := by decide
def e2411630452470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e2411630452470 : Closed e2411630452470 ∧ code e2411630452470 = 11207723474678 := by decide
theorem cert_e2411630452470 : check e2411630452470 [[],[]] .smaller = true := by decide
def e2411630452474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e2411630452474 : Closed e2411630452474 ∧ code e2411630452474 = 11207723474682 := by decide
theorem cert_e2411630452474 : check e2411630452474 [[],[]] .chain = true := by decide
def e2411630452590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e2411630452590 : Closed e2411630452590 ∧ code e2411630452590 = 11207723474798 := by decide
theorem cert_e2411630452590 : check e2411630452590 [[],[]] .smaller = true := by decide
def e2411630452598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e2411630452598 : Closed e2411630452598 ∧ code e2411630452598 = 11207723474806 := by decide
theorem cert_e2411630452598 : check e2411630452598 [[],[]] .smaller = true := by decide
def e2411630452654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e2411630452654 : Closed e2411630452654 ∧ code e2411630452654 = 11207723474862 := by decide
theorem cert_e2411630452654 : check e2411630452654 [[],[]] .chain = true := by decide
def e2411630452666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e2411630452666 : Closed e2411630452666 ∧ code e2411630452666 = 11207723474874 := by decide
theorem cert_e2411630452666 : check e2411630452666 [[],[]] .chain = true := by decide
def e2411630454558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2411630454558 : Closed e2411630454558 ∧ code e2411630454558 = 11207723476766 := by decide
theorem cert_e2411630454558 : check e2411630454558 [[],[]] .smaller = true := by decide
def e2411630454670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2411630454670 : Closed e2411630454670 ∧ code e2411630454670 = 11207723476878 := by decide
theorem cert_e2411630454670 : check e2411630454670 [[],[]] .smaller = true := by decide
def e2411630454718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e2411630454718 : Closed e2411630454718 ∧ code e2411630454718 = 11207723476926 := by decide
theorem cert_e2411630454718 : check e2411630454718 [[],[]] .chain = true := by decide
def e2411630454766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e2411630454766 : Closed e2411630454766 ∧ code e2411630454766 = 11207723476974 := by decide
theorem cert_e2411630454766 : check e2411630454766 [[],[]] .chain = true := by decide
def e2411630457630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2411630457630 : Closed e2411630457630 ∧ code e2411630457630 = 11207723479838 := by decide
theorem cert_e2411630457630 : check e2411630457630 [[],[]] .smaller = true := by decide
def e2411630457798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2411630457798 : Closed e2411630457798 ∧ code e2411630457798 = 11207723480006 := by decide
theorem cert_e2411630457798 : check e2411630457798 [[],[]] .smaller = true := by decide
def e2411630457822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e2411630457822 : Closed e2411630457822 ∧ code e2411630457822 = 11207723480030 := by decide
theorem cert_e2411630457822 : check e2411630457822 [[],[]] .smaller = true := by decide
def e2411630457838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e2411630457838 : Closed e2411630457838 ∧ code e2411630457838 = 11207723480046 := by decide
theorem cert_e2411630457838 : check e2411630457838 [[],[]] .smaller = true := by decide
def e2411630459278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2411630459278 : Closed e2411630459278 ∧ code e2411630459278 = 11207723481486 := by decide
theorem cert_e2411630459278 : check e2411630459278 [[],[]] .smaller = true := by decide
def e2411630459326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e2411630459326 : Closed e2411630459326 ∧ code e2411630459326 = 11207723481534 := by decide
theorem cert_e2411630459326 : check e2411630459326 [[],[]] .chain = true := by decide
def e2411630459334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2411630459334 : Closed e2411630459334 ∧ code e2411630459334 = 11207723481542 := by decide
theorem cert_e2411630459334 : check e2411630459334 [[],[]] .smaller = true := by decide
def e2411630459358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411630459358 : Closed e2411630459358 ∧ code e2411630459358 = 11207723481566 := by decide
theorem cert_e2411630459358 : check e2411630459358 [[],[]] .smaller = true := by decide
def e2411630459382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411630459382 : Closed e2411630459382 ∧ code e2411630459382 = 11207723481590 := by decide
theorem cert_e2411630459382 : check e2411630459382 [[],[]] .smaller = true := by decide
def e2411630459386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e2411630459386 : Closed e2411630459386 ∧ code e2411630459386 = 11207723481594 := by decide
theorem cert_e2411630459386 : check e2411630459386 [[],[]] .chain = true := by decide
def e2411630460142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411630460142 : Closed e2411630460142 ∧ code e2411630460142 = 11207723482350 := by decide
theorem cert_e2411630460142 : check e2411630460142 [[],[]] .smaller = true := by decide
def e2411630460150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411630460150 : Closed e2411630460150 ∧ code e2411630460150 = 11207723482358 := by decide
theorem cert_e2411630460150 : check e2411630460150 [[],[]] .smaller = true := by decide
def e2411630460526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411630460526 : Closed e2411630460526 ∧ code e2411630460526 = 11207723482734 := by decide
theorem cert_e2411630460526 : check e2411630460526 [[],[]] .chain = true := by decide
def e2411630460538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411630460538 : Closed e2411630460538 ∧ code e2411630460538 = 11207723482746 := by decide
theorem cert_e2411630460538 : check e2411630460538 [[],[]] .chain = true := by decide
def e2411630516958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2411630516958 : Closed e2411630516958 ∧ code e2411630516958 = 11207723539166 := by decide
theorem cert_e2411630516958 : check e2411630516958 [[],[]] .chain = true := by decide
def e2411630516982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2411630516982 : Closed e2411630516982 ∧ code e2411630516982 = 11207723539190 := by decide
theorem cert_e2411630516982 : check e2411630516982 [[],[]] .chain = true := by decide
def e2411630517086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2411630517086 : Closed e2411630517086 ∧ code e2411630517086 = 11207723539294 := by decide
theorem cert_e2411630517086 : check e2411630517086 [[],[]] .chain = true := by decide
def e2411630517102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e2411630517102 : Closed e2411630517102 ∧ code e2411630517102 = 11207723539310 := by decide
theorem cert_e2411630517102 : check e2411630517102 [[],[]] .smaller = true := by decide
def e2411630517110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e2411630517110 : Closed e2411630517110 ∧ code e2411630517110 = 11207723539318 := by decide
theorem cert_e2411630517110 : check e2411630517110 [[],[]] .smaller = true := by decide
def e2411630517114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2411630517114 : Closed e2411630517114 ∧ code e2411630517114 = 11207723539322 := by decide
theorem cert_e2411630517114 : check e2411630517114 [[],[]] .chain = true := by decide
def e2411630517174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e2411630517174 : Closed e2411630517174 ∧ code e2411630517174 = 11207723539382 := by decide
theorem cert_e2411630517174 : check e2411630517174 [[],[]] .smaller = true := by decide
def e2411630517206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2411630517206 : Closed e2411630517206 ∧ code e2411630517206 = 11207723539414 := by decide
theorem cert_e2411630517206 : check e2411630517206 [[],[]] .chain = true := by decide
def e2411630517210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2411630517210 : Closed e2411630517210 ∧ code e2411630517210 = 11207723539418 := by decide
theorem cert_e2411630517210 : check e2411630517210 [[],[]] .chain = true := by decide
def e2411630517598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2411630517598 : Closed e2411630517598 ∧ code e2411630517598 = 11207723539806 := by decide
theorem cert_e2411630517598 : check e2411630517598 [[],[]] .chain = true := by decide
def e2411630517614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2411630517614 : Closed e2411630517614 ∧ code e2411630517614 = 11207723539822 := by decide
theorem cert_e2411630517614 : check e2411630517614 [[],[]] .smaller = true := by decide
def e2411630517622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2411630517622 : Closed e2411630517622 ∧ code e2411630517622 = 11207723539830 := by decide
theorem cert_e2411630517622 : check e2411630517622 [[],[]] .smaller = true := by decide
def e2411630517626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2411630517626 : Closed e2411630517626 ∧ code e2411630517626 = 11207723539834 := by decide
theorem cert_e2411630517626 : check e2411630517626 [[],[]] .chain = true := by decide
def e2411630517678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2411630517678 : Closed e2411630517678 ∧ code e2411630517678 = 11207723539886 := by decide
theorem cert_e2411630517678 : check e2411630517678 [[],[]] .smaller = true := by decide
def e2411630517690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2411630517690 : Closed e2411630517690 ∧ code e2411630517690 = 11207723539898 := by decide
theorem cert_e2411630517690 : check e2411630517690 [[],[]] .smaller = true := by decide
def e2411630517718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2411630517718 : Closed e2411630517718 ∧ code e2411630517718 = 11207723539926 := by decide
theorem cert_e2411630517718 : check e2411630517718 [[],[]] .smaller = true := by decide
def e2411630517722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2411630517722 : Closed e2411630517722 ∧ code e2411630517722 = 11207723539930 := by decide
theorem cert_e2411630517722 : check e2411630517722 [[],[]] .smaller = true := by decide
def e2411630517738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2411630517738 : Closed e2411630517738 ∧ code e2411630517738 = 11207723539946 := by decide
theorem cert_e2411630517738 : check e2411630517738 [[],[]] .chain = true := by decide
def e2411630517942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2411630517942 : Closed e2411630517942 ∧ code e2411630517942 = 11207723540150 := by decide
theorem cert_e2411630517942 : check e2411630517942 [[],[]] .smaller = true := by decide
def e2411630517974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2411630517974 : Closed e2411630517974 ∧ code e2411630517974 = 11207723540182 := by decide
theorem cert_e2411630517974 : check e2411630517974 [[],[]] .smaller = true := by decide
def e2411630517978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2411630517978 : Closed e2411630517978 ∧ code e2411630517978 = 11207723540186 := by decide
theorem cert_e2411630517978 : check e2411630517978 [[],[]] .smaller = true := by decide
def e2411630518102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2411630518102 : Closed e2411630518102 ∧ code e2411630518102 = 11207723540310 := by decide
theorem cert_e2411630518102 : check e2411630518102 [[],[]] .chain = true := by decide
def e2411630518106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2411630518106 : Closed e2411630518106 ∧ code e2411630518106 = 11207723540314 := by decide
theorem cert_e2411630518106 : check e2411630518106 [[],[]] .chain = true := by decide
def e2411630518122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2411630518122 : Closed e2411630518122 ∧ code e2411630518122 = 11207723540330 := by decide
theorem cert_e2411630518122 : check e2411630518122 [[],[]] .chain = true := by decide
end Blc.Floor43
