import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411630790390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2411630790390 : Closed e2411630790390 ∧ code e2411630790390 = 11207723812598 := by decide
theorem cert_e2411630790390 : check e2411630790390 [[],[]] .chain = true := by decide
def e2411630790574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e2411630790574 : Closed e2411630790574 ∧ code e2411630790574 = 11207723812782 := by decide
theorem cert_e2411630790574 : check e2411630790574 [[],[]] .chain = true := by decide
def e2411630790614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2411630790614 : Closed e2411630790614 ∧ code e2411630790614 = 11207723812822 := by decide
theorem cert_e2411630790614 : check e2411630790614 [[],[]] .chain = true := by decide
def e2411630791918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630791918 : Closed e2411630791918 ∧ code e2411630791918 = 11207723814126 := by decide
theorem cert_e2411630791918 : check e2411630791918 [[],[]] .chain = true := by decide
def e2411630791926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630791926 : Closed e2411630791926 ∧ code e2411630791926 = 11207723814134 := by decide
theorem cert_e2411630791926 : check e2411630791926 [[],[]] .chain = true := by decide
def e2411630792302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411630792302 : Closed e2411630792302 ∧ code e2411630792302 = 11207723814510 := by decide
theorem cert_e2411630792302 : check e2411630792302 [[],[]] .chain = true := by decide
def e2411630792314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411630792314 : Closed e2411630792314 ∧ code e2411630792314 = 11207723814522 := by decide
theorem cert_e2411630792314 : check e2411630792314 [[],[]] .chain = true := by decide
def e2411630792502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411630792502 : Closed e2411630792502 ∧ code e2411630792502 = 11207723814710 := by decide
theorem cert_e2411630792502 : check e2411630792502 [[],[]] .chain = true := by decide
def e2411630792506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411630792506 : Closed e2411630792506 ∧ code e2411630792506 = 11207723814714 := by decide
theorem cert_e2411630792506 : check e2411630792506 [[],[]] .chain = true := by decide
def e2411630794990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2411630794990 : Closed e2411630794990 ∧ code e2411630794990 = 11207723817198 := by decide
theorem cert_e2411630794990 : check e2411630794990 [[],[]] .chain = true := by decide
def e2411630794998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2411630794998 : Closed e2411630794998 ∧ code e2411630794998 = 11207723817206 := by decide
theorem cert_e2411630794998 : check e2411630794998 [[],[]] .chain = true := by decide
def e2411630795550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2411630795550 : Closed e2411630795550 ∧ code e2411630795550 = 11207723817758 := by decide
theorem cert_e2411630795550 : check e2411630795550 [[],[]] .chain = true := by decide
def e2411630795662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2411630795662 : Closed e2411630795662 ∧ code e2411630795662 = 11207723817870 := by decide
theorem cert_e2411630795662 : check e2411630795662 [[],[]] .chain = true := by decide
def e2411630795886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411630795886 : Closed e2411630795886 ∧ code e2411630795886 = 11207723818094 := by decide
theorem cert_e2411630795886 : check e2411630795886 [[],[]] .chain = true := by decide
def e2411630795898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411630795898 : Closed e2411630795898 ∧ code e2411630795898 = 11207723818106 := by decide
theorem cert_e2411630795898 : check e2411630795898 [[],[]] .chain = true := by decide
def e2411630796062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411630796062 : Closed e2411630796062 ∧ code e2411630796062 = 11207723818270 := by decide
theorem cert_e2411630796062 : check e2411630796062 [[],[]] .chain = true := by decide
def e2411630796230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411630796230 : Closed e2411630796230 ∧ code e2411630796230 = 11207723818438 := by decide
theorem cert_e2411630796230 : check e2411630796230 [[],[]] .chain = true := by decide
def e2411630796342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411630796342 : Closed e2411630796342 ∧ code e2411630796342 = 11207723818550 := by decide
theorem cert_e2411630796342 : check e2411630796342 [[],[]] .chain = true := by decide
def e2411630796346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411630796346 : Closed e2411630796346 ∧ code e2411630796346 = 11207723818554 := by decide
theorem cert_e2411630796346 : check e2411630796346 [[],[]] .chain = true := by decide
def e2411630796430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411630796430 : Closed e2411630796430 ∧ code e2411630796430 = 11207723818638 := by decide
theorem cert_e2411630796430 : check e2411630796430 [[],[]] .chain = true := by decide
def e2411630796486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411630796486 : Closed e2411630796486 ∧ code e2411630796486 = 11207723818694 := by decide
theorem cert_e2411630796486 : check e2411630796486 [[],[]] .chain = true := by decide
def e2411630798622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411630798622 : Closed e2411630798622 ∧ code e2411630798622 = 11207723820830 := by decide
theorem cert_e2411630798622 : check e2411630798622 [[],[]] .chain = true := by decide
def e2411630798734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411630798734 : Closed e2411630798734 ∧ code e2411630798734 = 11207723820942 := by decide
theorem cert_e2411630798734 : check e2411630798734 [[],[]] .chain = true := by decide
def e2411630801118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630801118 : Closed e2411630801118 ∧ code e2411630801118 = 11207723823326 := by decide
theorem cert_e2411630801118 : check e2411630801118 [[],[]] .chain = true := by decide
def e2411630801146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630801146 : Closed e2411630801146 ∧ code e2411630801146 = 11207723823354 := by decide
theorem cert_e2411630801146 : check e2411630801146 [[],[]] .chain = true := by decide
def e2411630801694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411630801694 : Closed e2411630801694 ∧ code e2411630801694 = 11207723823902 := by decide
theorem cert_e2411630801694 : check e2411630801694 [[],[]] .chain = true := by decide
def e2411630801862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411630801862 : Closed e2411630801862 ∧ code e2411630801862 = 11207723824070 := by decide
theorem cert_e2411630801862 : check e2411630801862 [[],[]] .chain = true := by decide
def e2411630803054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630803054 : Closed e2411630803054 ∧ code e2411630803054 = 11207723825262 := by decide
theorem cert_e2411630803054 : check e2411630803054 [[],[]] .chain = true := by decide
def e2411630803066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630803066 : Closed e2411630803066 ∧ code e2411630803066 = 11207723825274 := by decide
theorem cert_e2411630803066 : check e2411630803066 [[],[]] .chain = true := by decide
def e2411630803342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411630803342 : Closed e2411630803342 ∧ code e2411630803342 = 11207723825550 := by decide
theorem cert_e2411630803342 : check e2411630803342 [[],[]] .chain = true := by decide
def e2411630803398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411630803398 : Closed e2411630803398 ∧ code e2411630803398 = 11207723825606 := by decide
theorem cert_e2411630803398 : check e2411630803398 [[],[]] .chain = true := by decide
def e2411630805486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2411630805486 : Closed e2411630805486 ∧ code e2411630805486 = 11207723827694 := by decide
theorem cert_e2411630805486 : check e2411630805486 [[],[]] .chain = true := by decide
def e2411630805494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2411630805494 : Closed e2411630805494 ∧ code e2411630805494 = 11207723827702 := by decide
theorem cert_e2411630805494 : check e2411630805494 [[],[]] .chain = true := by decide
def e2411630805870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2411630805870 : Closed e2411630805870 ∧ code e2411630805870 = 11207723828078 := by decide
theorem cert_e2411630805870 : check e2411630805870 [[],[]] .chain = true := by decide
def e2411630805882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2411630805882 : Closed e2411630805882 ∧ code e2411630805882 = 11207723828090 := by decide
theorem cert_e2411630805882 : check e2411630805882 [[],[]] .chain = true := by decide
def e2411630805934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2411630805934 : Closed e2411630805934 ∧ code e2411630805934 = 11207723828142 := by decide
theorem cert_e2411630805934 : check e2411630805934 [[],[]] .chain = true := by decide
def e2411630805994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2411630805994 : Closed e2411630805994 ∧ code e2411630805994 = 11207723828202 := by decide
theorem cert_e2411630805994 : check e2411630805994 [[],[]] .chain = true := by decide
def e2411630806254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630806254 : Closed e2411630806254 ∧ code e2411630806254 = 11207723828462 := by decide
theorem cert_e2411630806254 : check e2411630806254 [[],[]] .chain = true := by decide
def e2411630806262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630806262 : Closed e2411630806262 ∧ code e2411630806262 = 11207723828470 := by decide
theorem cert_e2411630806262 : check e2411630806262 [[],[]] .chain = true := by decide
def e2411630806638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411630806638 : Closed e2411630806638 ∧ code e2411630806638 = 11207723828846 := by decide
theorem cert_e2411630806638 : check e2411630806638 [[],[]] .chain = true := by decide
def e2411630806650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411630806650 : Closed e2411630806650 ∧ code e2411630806650 = 11207723828858 := by decide
theorem cert_e2411630806650 : check e2411630806650 [[],[]] .chain = true := by decide
def e2411630806814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2411630806814 : Closed e2411630806814 ∧ code e2411630806814 = 11207723829022 := by decide
theorem cert_e2411630806814 : check e2411630806814 [[],[]] .chain = true := by decide
def e2411630806926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2411630806926 : Closed e2411630806926 ∧ code e2411630806926 = 11207723829134 := by decide
theorem cert_e2411630806926 : check e2411630806926 [[],[]] .chain = true := by decide
def e2411630806938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411630806938 : Closed e2411630806938 ∧ code e2411630806938 = 11207723829146 := by decide
theorem cert_e2411630806938 : check e2411630806938 [[],[]] .chain = true := by decide
def e2411630808174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411630808174 : Closed e2411630808174 ∧ code e2411630808174 = 11207723830382 := by decide
theorem cert_e2411630808174 : check e2411630808174 [[],[]] .chain = true := by decide
def e2411630808186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411630808186 : Closed e2411630808186 ∧ code e2411630808186 = 11207723830394 := by decide
theorem cert_e2411630808186 : check e2411630808186 [[],[]] .chain = true := by decide
def e2411630808350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411630808350 : Closed e2411630808350 ∧ code e2411630808350 = 11207723830558 := by decide
theorem cert_e2411630808350 : check e2411630808350 [[],[]] .chain = true := by decide
def e2411630808518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411630808518 : Closed e2411630808518 ∧ code e2411630808518 = 11207723830726 := by decide
theorem cert_e2411630808518 : check e2411630808518 [[],[]] .chain = true := by decide
def e2411630808622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2411630808622 : Closed e2411630808622 ∧ code e2411630808622 = 11207723830830 := by decide
theorem cert_e2411630808622 : check e2411630808622 [[],[]] .chain = true := by decide
def e2411630808802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2411630808802 : Closed e2411630808802 ∧ code e2411630808802 = 11207723831010 := by decide
theorem cert_e2411630808802 : check e2411630808802 [[],[]] .chain = true := by decide
def e2411630808814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2411630808814 : Closed e2411630808814 ∧ code e2411630808814 = 11207723831022 := by decide
theorem cert_e2411630808814 : check e2411630808814 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630808854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2411630808854 : Closed e2411630808854 ∧ code e2411630808854 = 11207723831062 := by decide
theorem cert_e2411630808854 : check e2411630808854 [[],[]] .chain = true := by decide
def e2411630808858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411630808858 : Closed e2411630808858 ∧ code e2411630808858 = 11207723831066 := by decide
theorem cert_e2411630808858 : check e2411630808858 [[],[]] .chain = true := by decide
def e2411630808902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411630808902 : Closed e2411630808902 ∧ code e2411630808902 = 11207723831110 := by decide
theorem cert_e2411630808902 : check e2411630808902 [[],[]] .chain = true := by decide
def e2411630808930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2411630808930 : Closed e2411630808930 ∧ code e2411630808930 = 11207723831138 := by decide
theorem cert_e2411630808930 : check e2411630808930 [[],[]] .chain = true := by decide
def e2411630808942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2411630808942 : Closed e2411630808942 ∧ code e2411630808942 = 11207723831150 := by decide
theorem cert_e2411630808942 : check e2411630808942 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630808950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2411630808950 : Closed e2411630808950 ∧ code e2411630808950 = 11207723831158 := by decide
theorem cert_e2411630808950 : check e2411630808950 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630809310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630809310 : Closed e2411630809310 ∧ code e2411630809310 = 11207723831518 := by decide
theorem cert_e2411630809310 : check e2411630809310 [[],[]] .chain = true := by decide
def e2411630809338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630809338 : Closed e2411630809338 ∧ code e2411630809338 = 11207723831546 := by decide
theorem cert_e2411630809338 : check e2411630809338 [[],[]] .chain = true := by decide
def e2411630809886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411630809886 : Closed e2411630809886 ∧ code e2411630809886 = 11207723832094 := by decide
theorem cert_e2411630809886 : check e2411630809886 [[],[]] .chain = true := by decide
def e2411630810054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411630810054 : Closed e2411630810054 ∧ code e2411630810054 = 11207723832262 := by decide
theorem cert_e2411630810054 : check e2411630810054 [[],[]] .chain = true := by decide
def e2411630811198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2411630811198 : Closed e2411630811198 ∧ code e2411630811198 = 11207723833406 := by decide
theorem cert_e2411630811198 : check e2411630811198 [[],[]] .chain = true := by decide
def e2411630811618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2411630811618 : Closed e2411630811618 ∧ code e2411630811618 = 11207723833826 := by decide
theorem cert_e2411630811618 : check e2411630811618 [[],[]] .chain = true := by decide
def e2411630811630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2411630811630 : Closed e2411630811630 ∧ code e2411630811630 = 11207723833838 := by decide
theorem cert_e2411630811630 : check e2411630811630 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630812190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2411630812190 : Closed e2411630812190 ∧ code e2411630812190 = 11207723834398 := by decide
theorem cert_e2411630812190 : check e2411630812190 [[],[]] .chain = true := by decide
def e2411630812214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630812214 : Closed e2411630812214 ∧ code e2411630812214 = 11207723834422 := by decide
theorem cert_e2411630812214 : check e2411630812214 [[],[]] .chain = true := by decide
def e2411630812218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630812218 : Closed e2411630812218 ∧ code e2411630812218 = 11207723834426 := by decide
theorem cert_e2411630812218 : check e2411630812218 [[],[]] .chain = true := by decide
def e2411630812358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411630812358 : Closed e2411630812358 ∧ code e2411630812358 = 11207723834566 := by decide
theorem cert_e2411630812358 : check e2411630812358 [[],[]] .chain = true := by decide
def e2411630812386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411630812386 : Closed e2411630812386 ∧ code e2411630812386 = 11207723834594 := by decide
theorem cert_e2411630812386 : check e2411630812386 [[],[]] .chain = true := by decide
def e2411630812398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630812398 : Closed e2411630812398 ∧ code e2411630812398 = 11207723834606 := by decide
theorem cert_e2411630812398 : check e2411630812398 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630812406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630812406 : Closed e2411630812406 ∧ code e2411630812406 = 11207723834614 := by decide
theorem cert_e2411630812406 : check e2411630812406 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630813430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2411630813430 : Closed e2411630813430 ∧ code e2411630813430 = 11207723835638 := by decide
theorem cert_e2411630813430 : check e2411630813430 [[],[]] .chain = true := by decide
def e2411630813622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2411630813622 : Closed e2411630813622 ∧ code e2411630813622 = 11207723835830 := by decide
theorem cert_e2411630813622 : check e2411630813622 [[],[]] .chain = true := by decide
def e2411630813626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2411630813626 : Closed e2411630813626 ∧ code e2411630813626 = 11207723835834 := by decide
theorem cert_e2411630813626 : check e2411630813626 [[],[]] .chain = true := by decide
def e2411630813654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2411630813654 : Closed e2411630813654 ∧ code e2411630813654 = 11207723835862 := by decide
theorem cert_e2411630813654 : check e2411630813654 [[],[]] .chain = true := by decide
def e2411630813674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2411630813674 : Closed e2411630813674 ∧ code e2411630813674 = 11207723835882 := by decide
theorem cert_e2411630813674 : check e2411630813674 [[],[]] .chain = true := by decide
def e2411630813814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e2411630813814 : Closed e2411630813814 ∧ code e2411630813814 = 11207723836022 := by decide
theorem cert_e2411630813814 : check e2411630813814 [[],[]] .chain = true := by decide
def e2411630814006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411630814006 : Closed e2411630814006 ∧ code e2411630814006 = 11207723836214 := by decide
theorem cert_e2411630814006 : check e2411630814006 [[],[]] .chain = true := by decide
def e2411630814010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411630814010 : Closed e2411630814010 ∧ code e2411630814010 = 11207723836218 := by decide
theorem cert_e2411630814010 : check e2411630814010 [[],[]] .chain = true := by decide
def e2411630814094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 2))))))))
theorem wire_e2411630814094 : Closed e2411630814094 ∧ code e2411630814094 = 11207723836302 := by decide
theorem cert_e2411630814094 : check e2411630814094 [[],[]] .chain = true := by decide
def e2411630814106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411630814106 : Closed e2411630814106 ∧ code e2411630814106 = 11207723836314 := by decide
theorem cert_e2411630814106 : check e2411630814106 [[],[]] .chain = true := by decide
def e2411630814774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411630814774 : Closed e2411630814774 ∧ code e2411630814774 = 11207723836982 := by decide
theorem cert_e2411630814774 : check e2411630814774 [[],[]] .chain = true := by decide
def e2411630814778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411630814778 : Closed e2411630814778 ∧ code e2411630814778 = 11207723836986 := by decide
theorem cert_e2411630814778 : check e2411630814778 [[],[]] .chain = true := by decide
def e2411630814862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411630814862 : Closed e2411630814862 ∧ code e2411630814862 = 11207723837070 := by decide
theorem cert_e2411630814862 : check e2411630814862 [[],[]] .chain = true := by decide
def e2411630814918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411630814918 : Closed e2411630814918 ∧ code e2411630814918 = 11207723837126 := by decide
theorem cert_e2411630814918 : check e2411630814918 [[],[]] .chain = true := by decide
def e2411630814998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2411630814998 : Closed e2411630814998 ∧ code e2411630814998 = 11207723837206 := by decide
theorem cert_e2411630814998 : check e2411630814998 [[],[]] .chain = true := by decide
def e2411630815002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411630815002 : Closed e2411630815002 ∧ code e2411630815002 = 11207723837210 := by decide
theorem cert_e2411630815002 : check e2411630815002 [[],[]] .chain = true := by decide
def e2411630815046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411630815046 : Closed e2411630815046 ∧ code e2411630815046 = 11207723837254 := by decide
theorem cert_e2411630815046 : check e2411630815046 [[],[]] .chain = true := by decide
def e2411630815074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2411630815074 : Closed e2411630815074 ∧ code e2411630815074 = 11207723837282 := by decide
theorem cert_e2411630815074 : check e2411630815074 [[],[]] .chain = true := by decide
def e2411630815086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2411630815086 : Closed e2411630815086 ∧ code e2411630815086 = 11207723837294 := by decide
theorem cert_e2411630815086 : check e2411630815086 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630815094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2411630815094 : Closed e2411630815094 ∧ code e2411630815094 = 11207723837302 := by decide
theorem cert_e2411630815094 : check e2411630815094 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630815158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2411630815158 : Closed e2411630815158 ∧ code e2411630815158 = 11207723837366 := by decide
theorem cert_e2411630815158 : check e2411630815158 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630815342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630815342 : Closed e2411630815342 ∧ code e2411630815342 = 11207723837550 := by decide
theorem cert_e2411630815342 : check e2411630815342 [[],[]] .chain = true := by decide
def e2411630815354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630815354 : Closed e2411630815354 ∧ code e2411630815354 = 11207723837562 := by decide
theorem cert_e2411630815354 : check e2411630815354 [[],[]] .chain = true := by decide
def e2411630815630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411630815630 : Closed e2411630815630 ∧ code e2411630815630 = 11207723837838 := by decide
theorem cert_e2411630815630 : check e2411630815630 [[],[]] .chain = true := by decide
def e2411630815686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411630815686 : Closed e2411630815686 ∧ code e2411630815686 = 11207723837894 := by decide
theorem cert_e2411630815686 : check e2411630815686 [[],[]] .chain = true := by decide
def e2411630816286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 3)))))))))
theorem wire_e2411630816286 : Closed e2411630816286 ∧ code e2411630816286 = 11207723838494 := by decide
theorem cert_e2411630816286 : check e2411630816286 [[],[]] .chain = true := by decide
def e2411630816310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630816310 : Closed e2411630816310 ∧ code e2411630816310 = 11207723838518 := by decide
theorem cert_e2411630816310 : check e2411630816310 [[],[]] .chain = true := by decide
def e2411630816314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630816314 : Closed e2411630816314 ∧ code e2411630816314 = 11207723838522 := by decide
theorem cert_e2411630816314 : check e2411630816314 [[],[]] .chain = true := by decide
def e2411630816454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411630816454 : Closed e2411630816454 ∧ code e2411630816454 = 11207723838662 := by decide
theorem cert_e2411630816454 : check e2411630816454 [[],[]] .chain = true := by decide
def e2411630816482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411630816482 : Closed e2411630816482 ∧ code e2411630816482 = 11207723838690 := by decide
theorem cert_e2411630816482 : check e2411630816482 [[],[]] .chain = true := by decide
def e2411630816494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630816494 : Closed e2411630816494 ∧ code e2411630816494 = 11207723838702 := by decide
theorem cert_e2411630816494 : check e2411630816494 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630816502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630816502 : Closed e2411630816502 ∧ code e2411630816502 = 11207723838710 := by decide
theorem cert_e2411630816502 : check e2411630816502 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e2411630816886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2411630816886 : Closed e2411630816886 ∧ code e2411630816886 = 11207723839094 := by decide
theorem cert_e2411630816886 : check e2411630816886 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630827230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411630827230 : Closed e2411630827230 ∧ code e2411630827230 = 11207723849438 := by decide
theorem cert_e2411630827230 : check e2411630827230 [[],[]] .chain = true := by decide
def e2411630827254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411630827254 : Closed e2411630827254 ∧ code e2411630827254 = 11207723849462 := by decide
theorem cert_e2411630827254 : check e2411630827254 [[],[]] .chain = true := by decide
def e2411630827358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411630827358 : Closed e2411630827358 ∧ code e2411630827358 = 11207723849566 := by decide
theorem cert_e2411630827358 : check e2411630827358 [[],[]] .chain = true := by decide
def e2411630827386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411630827386 : Closed e2411630827386 ∧ code e2411630827386 = 11207723849594 := by decide
theorem cert_e2411630827386 : check e2411630827386 [[],[]] .chain = true := by decide
def e2411630827478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411630827478 : Closed e2411630827478 ∧ code e2411630827478 = 11207723849686 := by decide
theorem cert_e2411630827478 : check e2411630827478 [[],[]] .chain = true := by decide
def e2411630827482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411630827482 : Closed e2411630827482 ∧ code e2411630827482 = 11207723849690 := by decide
theorem cert_e2411630827482 : check e2411630827482 [[],[]] .chain = true := by decide
def e2411630827998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411630827998 : Closed e2411630827998 ∧ code e2411630827998 = 11207723850206 := by decide
theorem cert_e2411630827998 : check e2411630827998 [[],[]] .chain = true := by decide
def e2411630828022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411630828022 : Closed e2411630828022 ∧ code e2411630828022 = 11207723850230 := by decide
theorem cert_e2411630828022 : check e2411630828022 [[],[]] .chain = true := by decide
def e2411630828766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411630828766 : Closed e2411630828766 ∧ code e2411630828766 = 11207723850974 := by decide
theorem cert_e2411630828766 : check e2411630828766 [[],[]] .chain = true := by decide
def e2411630828794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411630828794 : Closed e2411630828794 ∧ code e2411630828794 = 11207723851002 := by decide
theorem cert_e2411630828794 : check e2411630828794 [[],[]] .chain = true := by decide
def e2411630829118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2411630829118 : Closed e2411630829118 ∧ code e2411630829118 = 11207723851326 := by decide
theorem cert_e2411630829118 : check e2411630829118 [[],[]] .chain = true := by decide
def e2411630829342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2411630829342 : Closed e2411630829342 ∧ code e2411630829342 = 11207723851550 := by decide
theorem cert_e2411630829342 : check e2411630829342 [[],[]] .chain = true := by decide
def e2411630829366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411630829366 : Closed e2411630829366 ∧ code e2411630829366 = 11207723851574 := by decide
theorem cert_e2411630829366 : check e2411630829366 [[],[]] .chain = true := by decide
def e2411630829370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411630829370 : Closed e2411630829370 ∧ code e2411630829370 = 11207723851578 := by decide
theorem cert_e2411630829370 : check e2411630829370 [[],[]] .chain = true := by decide
def e2411630844142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2411630844142 : Closed e2411630844142 ∧ code e2411630844142 = 11207723866350 := by decide
theorem cert_e2411630844142 : check e2411630844142 [[],[]] .chain = true := by decide
def e2411630844150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2411630844150 : Closed e2411630844150 ∧ code e2411630844150 = 11207723866358 := by decide
theorem cert_e2411630844150 : check e2411630844150 [[],[]] .chain = true := by decide
def e2411630844702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2411630844702 : Closed e2411630844702 ∧ code e2411630844702 = 11207723866910 := by decide
theorem cert_e2411630844702 : check e2411630844702 [[],[]] .chain = true := by decide
def e2411630844814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2411630844814 : Closed e2411630844814 ∧ code e2411630844814 = 11207723867022 := by decide
theorem cert_e2411630844814 : check e2411630844814 [[],[]] .chain = true := by decide
def e2411630845038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411630845038 : Closed e2411630845038 ∧ code e2411630845038 = 11207723867246 := by decide
theorem cert_e2411630845038 : check e2411630845038 [[],[]] .chain = true := by decide
def e2411630845050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411630845050 : Closed e2411630845050 ∧ code e2411630845050 = 11207723867258 := by decide
theorem cert_e2411630845050 : check e2411630845050 [[],[]] .chain = true := by decide
def e2411630845214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411630845214 : Closed e2411630845214 ∧ code e2411630845214 = 11207723867422 := by decide
theorem cert_e2411630845214 : check e2411630845214 [[],[]] .chain = true := by decide
def e2411630845382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411630845382 : Closed e2411630845382 ∧ code e2411630845382 = 11207723867590 := by decide
theorem cert_e2411630845382 : check e2411630845382 [[],[]] .chain = true := by decide
def e2411630845494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411630845494 : Closed e2411630845494 ∧ code e2411630845494 = 11207723867702 := by decide
theorem cert_e2411630845494 : check e2411630845494 [[],[]] .chain = true := by decide
def e2411630845498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411630845498 : Closed e2411630845498 ∧ code e2411630845498 = 11207723867706 := by decide
theorem cert_e2411630845498 : check e2411630845498 [[],[]] .chain = true := by decide
def e2411630845582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411630845582 : Closed e2411630845582 ∧ code e2411630845582 = 11207723867790 := by decide
theorem cert_e2411630845582 : check e2411630845582 [[],[]] .chain = true := by decide
def e2411630845638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411630845638 : Closed e2411630845638 ∧ code e2411630845638 = 11207723867846 := by decide
theorem cert_e2411630845638 : check e2411630845638 [[],[]] .chain = true := by decide
def e2411630847774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411630847774 : Closed e2411630847774 ∧ code e2411630847774 = 11207723869982 := by decide
theorem cert_e2411630847774 : check e2411630847774 [[],[]] .chain = true := by decide
def e2411630847886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411630847886 : Closed e2411630847886 ∧ code e2411630847886 = 11207723870094 := by decide
theorem cert_e2411630847886 : check e2411630847886 [[],[]] .chain = true := by decide
def e2411630850270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2411630850270 : Closed e2411630850270 ∧ code e2411630850270 = 11207723872478 := by decide
theorem cert_e2411630850270 : check e2411630850270 [[],[]] .chain = true := by decide
def e2411630850298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2411630850298 : Closed e2411630850298 ∧ code e2411630850298 = 11207723872506 := by decide
theorem cert_e2411630850298 : check e2411630850298 [[],[]] .chain = true := by decide
def e2411630850846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411630850846 : Closed e2411630850846 ∧ code e2411630850846 = 11207723873054 := by decide
theorem cert_e2411630850846 : check e2411630850846 [[],[]] .chain = true := by decide
def e2411630851014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411630851014 : Closed e2411630851014 ∧ code e2411630851014 = 11207723873222 := by decide
theorem cert_e2411630851014 : check e2411630851014 [[],[]] .chain = true := by decide
def e2411630852206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2411630852206 : Closed e2411630852206 ∧ code e2411630852206 = 11207723874414 := by decide
theorem cert_e2411630852206 : check e2411630852206 [[],[]] .chain = true := by decide
def e2411630852218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2411630852218 : Closed e2411630852218 ∧ code e2411630852218 = 11207723874426 := by decide
theorem cert_e2411630852218 : check e2411630852218 [[],[]] .chain = true := by decide
def e2411630852494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411630852494 : Closed e2411630852494 ∧ code e2411630852494 = 11207723874702 := by decide
theorem cert_e2411630852494 : check e2411630852494 [[],[]] .chain = true := by decide
def e2411630852550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411630852550 : Closed e2411630852550 ∧ code e2411630852550 = 11207723874758 := by decide
theorem cert_e2411630852550 : check e2411630852550 [[],[]] .chain = true := by decide
def e2411630889822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2411630889822 : Closed e2411630889822 ∧ code e2411630889822 = 11207723912030 := by decide
theorem cert_e2411630889822 : check e2411630889822 [[],[]] .chain = true := by decide
def e2411630889838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411630889838 : Closed e2411630889838 ∧ code e2411630889838 = 11207723912046 := by decide
theorem cert_e2411630889838 : check e2411630889838 [[],[]] .smaller = true := by decide
def e2411630889846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411630889846 : Closed e2411630889846 ∧ code e2411630889846 = 11207723912054 := by decide
theorem cert_e2411630889846 : check e2411630889846 [[],[]] .smaller = true := by decide
def e2411630889850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2411630889850 : Closed e2411630889850 ∧ code e2411630889850 = 11207723912058 := by decide
theorem cert_e2411630889850 : check e2411630889850 [[],[]] .chain = true := by decide
def e2411630889902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411630889902 : Closed e2411630889902 ∧ code e2411630889902 = 11207723912110 := by decide
theorem cert_e2411630889902 : check e2411630889902 [[],[]] .smaller = true := by decide
def e2411630889914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411630889914 : Closed e2411630889914 ∧ code e2411630889914 = 11207723912122 := by decide
theorem cert_e2411630889914 : check e2411630889914 [[],[]] .smaller = true := by decide
def e2411630889942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411630889942 : Closed e2411630889942 ∧ code e2411630889942 = 11207723912150 := by decide
theorem cert_e2411630889942 : check e2411630889942 [[],[]] .smaller = true := by decide
def e2411630889946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411630889946 : Closed e2411630889946 ∧ code e2411630889946 = 11207723912154 := by decide
theorem cert_e2411630889946 : check e2411630889946 [[],[]] .smaller = true := by decide
def e2411630889962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2411630889962 : Closed e2411630889962 ∧ code e2411630889962 = 11207723912170 := by decide
theorem cert_e2411630889962 : check e2411630889962 [[],[]] .chain = true := by decide
def e2411630890206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411630890206 : Closed e2411630890206 ∧ code e2411630890206 = 11207723912414 := by decide
theorem cert_e2411630890206 : check e2411630890206 [[],[]] .chain = true := by decide
def e2411630890222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411630890222 : Closed e2411630890222 ∧ code e2411630890222 = 11207723912430 := by decide
theorem cert_e2411630890222 : check e2411630890222 [[],[]] .smaller = true := by decide
def e2411630890230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411630890230 : Closed e2411630890230 ∧ code e2411630890230 = 11207723912438 := by decide
theorem cert_e2411630890230 : check e2411630890230 [[],[]] .smaller = true := by decide
def e2411630890234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411630890234 : Closed e2411630890234 ∧ code e2411630890234 = 11207723912442 := by decide
theorem cert_e2411630890234 : check e2411630890234 [[],[]] .chain = true := by decide
def e2411630890558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2411630890558 : Closed e2411630890558 ∧ code e2411630890558 = 11207723912766 := by decide
theorem cert_e2411630890558 : check e2411630890558 [[],[]] .chain = true := by decide
def e2411630890606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411630890606 : Closed e2411630890606 ∧ code e2411630890606 = 11207723912814 := by decide
theorem cert_e2411630890606 : check e2411630890606 [[],[]] .smaller = true := by decide
def e2411630890618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411630890618 : Closed e2411630890618 ∧ code e2411630890618 = 11207723912826 := by decide
theorem cert_e2411630890618 : check e2411630890618 [[],[]] .smaller = true := by decide
def e2411630890806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411630890806 : Closed e2411630890806 ∧ code e2411630890806 = 11207723913014 := by decide
theorem cert_e2411630890806 : check e2411630890806 [[],[]] .smaller = true := by decide
def e2411630890810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411630890810 : Closed e2411630890810 ∧ code e2411630890810 = 11207723913018 := by decide
theorem cert_e2411630890810 : check e2411630890810 [[],[]] .smaller = true := by decide
def e2411630890894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2411630890894 : Closed e2411630890894 ∧ code e2411630890894 = 11207723913102 := by decide
theorem cert_e2411630890894 : check e2411630890894 [[],[]] .chain = true := by decide
def e2411630890906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411630890906 : Closed e2411630890906 ∧ code e2411630890906 = 11207723913114 := by decide
theorem cert_e2411630890906 : check e2411630890906 [[],[]] .chain = true := by decide
end Blc.Floor43
