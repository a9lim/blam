import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e606345563374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e606345563374 : Closed e606345563374 ∧ code e606345563374 = 9402438585582 := by decide
theorem cert_e606345563374 : check e606345563374 [[.under]] .sourceHead = true := by decide
def e606345563382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e606345563382 : Closed e606345563382 ∧ code e606345563382 = 9402438585590 := by decide
theorem cert_e606345563382 : check e606345563382 [[.under]] .sourceHead = true := by decide
def e606345563758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e606345563758 : Closed e606345563758 ∧ code e606345563758 = 9402438585966 := by decide
theorem cert_e606345563758 : check e606345563758 [[.under]] .sourceHead = true := by decide
def e606345563770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e606345563770 : Closed e606345563770 ∧ code e606345563770 = 9402438585978 := by decide
theorem cert_e606345563770 : check e606345563770 [[.under]] .sourceHead = true := by decide
def e606345563958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e606345563958 : Closed e606345563958 ∧ code e606345563958 = 9402438586166 := by decide
theorem cert_e606345563958 : check e606345563958 [[.under]] .sourceHead = true := by decide
def e606345563962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e606345563962 : Closed e606345563962 ∧ code e606345563962 = 9402438586170 := by decide
theorem cert_e606345563962 : check e606345563962 [[.under]] .sourceHead = true := by decide
def e606346152814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e606346152814 : Closed e606346152814 ∧ code e606346152814 = 9402439175022 := by decide
theorem cert_e606346152814 : check e606346152814 [[.under]] .sourceHead = true := by decide
def e606346152822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e606346152822 : Closed e606346152822 ∧ code e606346152822 = 9402439175030 := by decide
theorem cert_e606346152822 : check e606346152822 [[.under]] .sourceHead = true := by decide
def e606346152878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e606346152878 : Closed e606346152878 ∧ code e606346152878 = 9402439175086 := by decide
theorem cert_e606346152878 : check e606346152878 [[.under]] .sourceHead = true := by decide
def e606346152890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e606346152890 : Closed e606346152890 ∧ code e606346152890 = 9402439175098 := by decide
theorem cert_e606346152890 : check e606346152890 [[.under]] .sourceHead = true := by decide
def e606346152918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e606346152918 : Closed e606346152918 ∧ code e606346152918 = 9402439175126 := by decide
theorem cert_e606346152918 : check e606346152918 [[.under]] .sourceHead = true := by decide
def e606346152922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e606346152922 : Closed e606346152922 ∧ code e606346152922 = 9402439175130 := by decide
theorem cert_e606346152922 : check e606346152922 [[.under]] .sourceHead = true := by decide
def e606346153198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e606346153198 : Closed e606346153198 ∧ code e606346153198 = 9402439175406 := by decide
theorem cert_e606346153198 : check e606346153198 [[.under]] .sourceHead = true := by decide
def e606346153206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e606346153206 : Closed e606346153206 ∧ code e606346153206 = 9402439175414 := by decide
theorem cert_e606346153206 : check e606346153206 [[.under]] .sourceHead = true := by decide
def e606346153582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e606346153582 : Closed e606346153582 ∧ code e606346153582 = 9402439175790 := by decide
theorem cert_e606346153582 : check e606346153582 [[.under]] .sourceHead = true := by decide
def e606346153594 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e606346153594 : Closed e606346153594 ∧ code e606346153594 = 9402439175802 := by decide
theorem cert_e606346153594 : check e606346153594 [[.under]] .sourceHead = true := by decide
def e606346153782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e606346153782 : Closed e606346153782 ∧ code e606346153782 = 9402439175990 := by decide
theorem cert_e606346153782 : check e606346153782 [[.under]] .sourceHead = true := by decide
def e606346153786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e606346153786 : Closed e606346153786 ∧ code e606346153786 = 9402439175994 := by decide
theorem cert_e606346153786 : check e606346153786 [[.under]] .sourceHead = true := by decide
def e606395739502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e606395739502 : Closed e606395739502 ∧ code e606395739502 = 9402488761710 := by decide
theorem cert_e606395739502 : check e606395739502 [[.under]] .sourceHead = true := by decide
def e606395739510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e606395739510 : Closed e606395739510 ∧ code e606395739510 = 9402488761718 := by decide
theorem cert_e606395739510 : check e606395739510 [[.under]] .sourceHead = true := by decide
def e606395739566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e606395739566 : Closed e606395739566 ∧ code e606395739566 = 9402488761774 := by decide
theorem cert_e606395739566 : check e606395739566 [[.under]] .sourceHead = true := by decide
def e606395739578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e606395739578 : Closed e606395739578 ∧ code e606395739578 = 9402488761786 := by decide
theorem cert_e606395739578 : check e606395739578 [[.under]] .sourceHead = true := by decide
def e606395739606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e606395739606 : Closed e606395739606 ∧ code e606395739606 = 9402488761814 := by decide
theorem cert_e606395739606 : check e606395739606 [[.under]] .sourceHead = true := by decide
def e606395739610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e606395739610 : Closed e606395739610 ∧ code e606395739610 = 9402488761818 := by decide
theorem cert_e606395739610 : check e606395739610 [[.under]] .sourceHead = true := by decide
def e606395739822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e606395739822 : Closed e606395739822 ∧ code e606395739822 = 9402488762030 := by decide
theorem cert_e606395739822 : check e606395739822 [[.under]] .sourceHead = true := by decide
def e606395739834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e606395739834 : Closed e606395739834 ∧ code e606395739834 = 9402488762042 := by decide
theorem cert_e606395739834 : check e606395739834 [[.under]] .sourceHead = true := by decide
def e606395739882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e606395739882 : Closed e606395739882 ∧ code e606395739882 = 9402488762090 := by decide
theorem cert_e606395739882 : check e606395739882 [[.under]] .sourceHead = true := by decide
def e606395739990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e606395739990 : Closed e606395739990 ∧ code e606395739990 = 9402488762198 := by decide
theorem cert_e606395739990 : check e606395739990 [[.under]] .sourceHead = true := by decide
def e606395739994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e606395739994 : Closed e606395739994 ∧ code e606395739994 = 9402488762202 := by decide
theorem cert_e606395739994 : check e606395739994 [[.under]] .sourceHead = true := by decide
def e606395740010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e606395740010 : Closed e606395740010 ∧ code e606395740010 = 9402488762218 := by decide
theorem cert_e606395740010 : check e606395740010 [[.under]] .sourceHead = true := by decide
def e606395741038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e606395741038 : Closed e606395741038 ∧ code e606395741038 = 9402488763246 := by decide
theorem cert_e606395741038 : check e606395741038 [[.under]] .sourceHead = true := by decide
def e606395741046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e606395741046 : Closed e606395741046 ∧ code e606395741046 = 9402488763254 := by decide
theorem cert_e606395741046 : check e606395741046 [[.under]] .sourceHead = true := by decide
def e606395741102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e606395741102 : Closed e606395741102 ∧ code e606395741102 = 9402488763310 := by decide
theorem cert_e606395741102 : check e606395741102 [[.under]] .sourceHead = true := by decide
def e606395741114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e606395741114 : Closed e606395741114 ∧ code e606395741114 = 9402488763322 := by decide
theorem cert_e606395741114 : check e606395741114 [[.under]] .sourceHead = true := by decide
def e606395741142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e606395741142 : Closed e606395741142 ∧ code e606395741142 = 9402488763350 := by decide
theorem cert_e606395741142 : check e606395741142 [[.under]] .sourceHead = true := by decide
def e606395741146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e606395741146 : Closed e606395741146 ∧ code e606395741146 = 9402488763354 := by decide
theorem cert_e606395741146 : check e606395741146 [[.under]] .sourceHead = true := by decide
def e606395741422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606395741422 : Closed e606395741422 ∧ code e606395741422 = 9402488763630 := by decide
theorem cert_e606395741422 : check e606395741422 [[.under]] .sourceHead = true := by decide
def e606395741430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606395741430 : Closed e606395741430 ∧ code e606395741430 = 9402488763638 := by decide
theorem cert_e606395741430 : check e606395741430 [[.under]] .sourceHead = true := by decide
def e606395741806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606395741806 : Closed e606395741806 ∧ code e606395741806 = 9402488764014 := by decide
theorem cert_e606395741806 : check e606395741806 [[.under]] .sourceHead = true := by decide
def e606395741818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606395741818 : Closed e606395741818 ∧ code e606395741818 = 9402488764026 := by decide
theorem cert_e606395741818 : check e606395741818 [[.under]] .sourceHead = true := by decide
def e606395742006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606395742006 : Closed e606395742006 ∧ code e606395742006 = 9402488764214 := by decide
theorem cert_e606395742006 : check e606395742006 [[.under]] .sourceHead = true := by decide
def e606395742010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606395742010 : Closed e606395742010 ∧ code e606395742010 = 9402488764218 := by decide
theorem cert_e606395742010 : check e606395742010 [[.under]] .sourceHead = true := by decide
def e606395742638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e606395742638 : Closed e606395742638 ∧ code e606395742638 = 9402488764846 := by decide
theorem cert_e606395742638 : check e606395742638 [[.under]] .sourceHead = true := by decide
def e606395742650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e606395742650 : Closed e606395742650 ∧ code e606395742650 = 9402488764858 := by decide
theorem cert_e606395742650 : check e606395742650 [[.under]] .sourceHead = true := by decide
def e606395742698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e606395742698 : Closed e606395742698 ∧ code e606395742698 = 9402488764906 := by decide
theorem cert_e606395742698 : check e606395742698 [[.under]] .sourceHead = true := by decide
def e606395742830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606395742830 : Closed e606395742830 ∧ code e606395742830 = 9402488765038 := by decide
theorem cert_e606395742830 : check e606395742830 [[.under]] .sourceHead = true := by decide
def e606395742842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606395742842 : Closed e606395742842 ∧ code e606395742842 = 9402488765050 := by decide
theorem cert_e606395742842 : check e606395742842 [[.under]] .sourceHead = true := by decide
def e606395743130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606395743130 : Closed e606395743130 ∧ code e606395743130 = 9402488765338 := by decide
theorem cert_e606395743130 : check e606395743130 [[.under]] .sourceHead = true := by decide
def e606395743446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e606395743446 : Closed e606395743446 ∧ code e606395743446 = 9402488765654 := by decide
theorem cert_e606395743446 : check e606395743446 [[.under]] .sourceHead = true := by decide
def e606395743450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e606395743450 : Closed e606395743450 ∧ code e606395743450 = 9402488765658 := by decide
theorem cert_e606395743450 : check e606395743450 [[.under]] .sourceHead = true := by decide
def e606395743466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e606395743466 : Closed e606395743466 ∧ code e606395743466 = 9402488765674 := by decide
theorem cert_e606395743466 : check e606395743466 [[.under]] .sourceHead = true := by decide
def e606395743542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606395743542 : Closed e606395743542 ∧ code e606395743542 = 9402488765750 := by decide
theorem cert_e606395743542 : check e606395743542 [[.under]] .sourceHead = true := by decide
def e606395743546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606395743546 : Closed e606395743546 ∧ code e606395743546 = 9402488765754 := by decide
theorem cert_e606395743546 : check e606395743546 [[.under]] .sourceHead = true := by decide
def e606395743642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606395743642 : Closed e606395743642 ∧ code e606395743642 = 9402488765850 := by decide
theorem cert_e606395743642 : check e606395743642 [[.under]] .sourceHead = true := by decide
def e606395747182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e606395747182 : Closed e606395747182 ∧ code e606395747182 = 9402488769390 := by decide
theorem cert_e606395747182 : check e606395747182 [[.under]] .sourceHead = true := by decide
def e606395747190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e606395747190 : Closed e606395747190 ∧ code e606395747190 = 9402488769398 := by decide
theorem cert_e606395747190 : check e606395747190 [[.under]] .sourceHead = true := by decide
def e606395747246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e606395747246 : Closed e606395747246 ∧ code e606395747246 = 9402488769454 := by decide
theorem cert_e606395747246 : check e606395747246 [[.under]] .sourceHead = true := by decide
def e606395747258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e606395747258 : Closed e606395747258 ∧ code e606395747258 = 9402488769466 := by decide
theorem cert_e606395747258 : check e606395747258 [[.under]] .sourceHead = true := by decide
def e606395747286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e606395747286 : Closed e606395747286 ∧ code e606395747286 = 9402488769494 := by decide
theorem cert_e606395747286 : check e606395747286 [[.under]] .sourceHead = true := by decide
def e606395747290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e606395747290 : Closed e606395747290 ∧ code e606395747290 = 9402488769498 := by decide
theorem cert_e606395747290 : check e606395747290 [[.under]] .sourceHead = true := by decide
def e606395747566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e606395747566 : Closed e606395747566 ∧ code e606395747566 = 9402488769774 := by decide
theorem cert_e606395747566 : check e606395747566 [[.under]] .sourceHead = true := by decide
def e606395747574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e606395747574 : Closed e606395747574 ∧ code e606395747574 = 9402488769782 := by decide
theorem cert_e606395747574 : check e606395747574 [[.under]] .sourceHead = true := by decide
def e606395747950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e606395747950 : Closed e606395747950 ∧ code e606395747950 = 9402488770158 := by decide
theorem cert_e606395747950 : check e606395747950 [[.under]] .sourceHead = true := by decide
def e606395747962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e606395747962 : Closed e606395747962 ∧ code e606395747962 = 9402488770170 := by decide
theorem cert_e606395747962 : check e606395747962 [[.under]] .sourceHead = true := by decide
def e606395748150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e606395748150 : Closed e606395748150 ∧ code e606395748150 = 9402488770358 := by decide
theorem cert_e606395748150 : check e606395748150 [[.under]] .sourceHead = true := by decide
def e606395748154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e606395748154 : Closed e606395748154 ∧ code e606395748154 = 9402488770362 := by decide
theorem cert_e606395748154 : check e606395748154 [[.under]] .sourceHead = true := by decide
def e606395753902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e606395753902 : Closed e606395753902 ∧ code e606395753902 = 9402488776110 := by decide
theorem cert_e606395753902 : check e606395753902 [[.under]] .sourceHead = true := by decide
def e606395753914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e606395753914 : Closed e606395753914 ∧ code e606395753914 = 9402488776122 := by decide
theorem cert_e606395753914 : check e606395753914 [[.under]] .sourceHead = true := by decide
def e606395753962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e606395753962 : Closed e606395753962 ∧ code e606395753962 = 9402488776170 := by decide
theorem cert_e606395753962 : check e606395753962 [[.under]] .sourceHead = true := by decide
def e606395754094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e606395754094 : Closed e606395754094 ∧ code e606395754094 = 9402488776302 := by decide
theorem cert_e606395754094 : check e606395754094 [[.under]] .sourceHead = true := by decide
def e606395754106 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e606395754106 : Closed e606395754106 ∧ code e606395754106 = 9402488776314 := by decide
theorem cert_e606395754106 : check e606395754106 [[.under]] .sourceHead = true := by decide
def e606395754394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e606395754394 : Closed e606395754394 ∧ code e606395754394 = 9402488776602 := by decide
theorem cert_e606395754394 : check e606395754394 [[.under]] .sourceHead = true := by decide
def e606395757270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e606395757270 : Closed e606395757270 ∧ code e606395757270 = 9402488779478 := by decide
theorem cert_e606395757270 : check e606395757270 [[.under]] .sourceHead = true := by decide
def e606395757274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e606395757274 : Closed e606395757274 ∧ code e606395757274 = 9402488779482 := by decide
theorem cert_e606395757274 : check e606395757274 [[.under]] .sourceHead = true := by decide
def e606395757290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e606395757290 : Closed e606395757290 ∧ code e606395757290 = 9402488779498 := by decide
theorem cert_e606395757290 : check e606395757290 [[.under]] .sourceHead = true := by decide
def e606395757366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e606395757366 : Closed e606395757366 ∧ code e606395757366 = 9402488779574 := by decide
theorem cert_e606395757366 : check e606395757366 [[.under]] .sourceHead = true := by decide
def e606395757370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e606395757370 : Closed e606395757370 ∧ code e606395757370 = 9402488779578 := by decide
theorem cert_e606395757370 : check e606395757370 [[.under]] .sourceHead = true := by decide
def e606395757466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e606395757466 : Closed e606395757466 ∧ code e606395757466 = 9402488779674 := by decide
theorem cert_e606395757466 : check e606395757466 [[.under]] .sourceHead = true := by decide
def e606395872734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))))
theorem wire_e606395872734 : Closed e606395872734 ∧ code e606395872734 = 9402488894942 := by decide
theorem cert_e606395872734 : check e606395872734 [[.under]] .sourceHead = true := by decide
def e606395872750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))))
theorem wire_e606395872750 : Closed e606395872750 ∧ code e606395872750 = 9402488894958 := by decide
theorem cert_e606395872750 : check e606395872750 [[.under]] .sourceHead = true := by decide
def e606395872990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))))
theorem wire_e606395872990 : Closed e606395872990 ∧ code e606395872990 = 9402488895198 := by decide
theorem cert_e606395872990 : check e606395872990 [[.under]] .sourceHead = true := by decide
def e606395873006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))))
theorem wire_e606395873006 : Closed e606395873006 ∧ code e606395873006 = 9402488895214 := by decide
theorem cert_e606395873006 : check e606395873006 [[.under]] .sourceHead = true := by decide
def e606395873014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))))
theorem wire_e606395873014 : Closed e606395873014 ∧ code e606395873014 = 9402488895222 := by decide
theorem cert_e606395873014 : check e606395873014 [[.under]] .sourceHead = true := by decide
def e606395873118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))))
theorem wire_e606395873118 : Closed e606395873118 ∧ code e606395873118 = 9402488895326 := by decide
theorem cert_e606395873118 : check e606395873118 [[.under]] .sourceHead = true := by decide
def e606395873134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))))
theorem wire_e606395873134 : Closed e606395873134 ∧ code e606395873134 = 9402488895342 := by decide
theorem cert_e606395873134 : check e606395873134 [[.under]] .sourceHead = true := by decide
def e606395873142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))))
theorem wire_e606395873142 : Closed e606395873142 ∧ code e606395873142 = 9402488895350 := by decide
theorem cert_e606395873142 : check e606395873142 [[.under]] .sourceHead = true := by decide
def e606395873146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))))
theorem wire_e606395873146 : Closed e606395873146 ∧ code e606395873146 = 9402488895354 := by decide
theorem cert_e606395873146 : check e606395873146 [[.under]] .sourceHead = true := by decide
def e606395873198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))))
theorem wire_e606395873198 : Closed e606395873198 ∧ code e606395873198 = 9402488895406 := by decide
theorem cert_e606395873198 : check e606395873198 [[.under]] .sourceHead = true := by decide
def e606395873206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))))
theorem wire_e606395873206 : Closed e606395873206 ∧ code e606395873206 = 9402488895414 := by decide
theorem cert_e606395873206 : check e606395873206 [[.under]] .sourceHead = true := by decide
def e606395873210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))))
theorem wire_e606395873210 : Closed e606395873210 ∧ code e606395873210 = 9402488895418 := by decide
theorem cert_e606395873210 : check e606395873210 [[.under]] .sourceHead = true := by decide
def e606395874014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e606395874014 : Closed e606395874014 ∧ code e606395874014 = 9402488896222 := by decide
theorem cert_e606395874014 : check e606395874014 [[.under]] .sourceHead = true := by decide
def e606395874030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))))
theorem wire_e606395874030 : Closed e606395874030 ∧ code e606395874030 = 9402488896238 := by decide
theorem cert_e606395874030 : check e606395874030 [[.under]] .sourceHead = true := by decide
def e606395874038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e606395874038 : Closed e606395874038 ∧ code e606395874038 = 9402488896246 := by decide
theorem cert_e606395874038 : check e606395874038 [[.under]] .sourceHead = true := by decide
def e606395874142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e606395874142 : Closed e606395874142 ∧ code e606395874142 = 9402488896350 := by decide
theorem cert_e606395874142 : check e606395874142 [[.under]] .sourceHead = true := by decide
def e606395874170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e606395874170 : Closed e606395874170 ∧ code e606395874170 = 9402488896378 := by decide
theorem cert_e606395874170 : check e606395874170 [[.under]] .sourceHead = true := by decide
def e606395874222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))))
theorem wire_e606395874222 : Closed e606395874222 ∧ code e606395874222 = 9402488896430 := by decide
theorem cert_e606395874222 : check e606395874222 [[.under]] .sourceHead = true := by decide
def e606395874234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))))
theorem wire_e606395874234 : Closed e606395874234 ∧ code e606395874234 = 9402488896442 := by decide
theorem cert_e606395874234 : check e606395874234 [[.under]] .sourceHead = true := by decide
def e606395874262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e606395874262 : Closed e606395874262 ∧ code e606395874262 = 9402488896470 := by decide
theorem cert_e606395874262 : check e606395874262 [[.under]] .sourceHead = true := by decide
def e606395874266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e606395874266 : Closed e606395874266 ∧ code e606395874266 = 9402488896474 := by decide
theorem cert_e606395874266 : check e606395874266 [[.under]] .sourceHead = true := by decide
def e606395874654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e606395874654 : Closed e606395874654 ∧ code e606395874654 = 9402488896862 := by decide
theorem cert_e606395874654 : check e606395874654 [[.under]] .sourceHead = true := by decide
def e606395874670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e606395874670 : Closed e606395874670 ∧ code e606395874670 = 9402488896878 := by decide
theorem cert_e606395874670 : check e606395874670 [[.under]] .sourceHead = true := by decide
def e606395874678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e606395874678 : Closed e606395874678 ∧ code e606395874678 = 9402488896886 := by decide
theorem cert_e606395874678 : check e606395874678 [[.under]] .sourceHead = true := by decide
def e606395874682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e606395874682 : Closed e606395874682 ∧ code e606395874682 = 9402488896890 := by decide
theorem cert_e606395874682 : check e606395874682 [[.under]] .sourceHead = true := by decide
def e606395874734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e606395874734 : Closed e606395874734 ∧ code e606395874734 = 9402488896942 := by decide
theorem cert_e606395874734 : check e606395874734 [[.under]] .sourceHead = true := by decide
def e606395874746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e606395874746 : Closed e606395874746 ∧ code e606395874746 = 9402488896954 := by decide
theorem cert_e606395874746 : check e606395874746 [[.under]] .sourceHead = true := by decide
def e606395874774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e606395874774 : Closed e606395874774 ∧ code e606395874774 = 9402488896982 := by decide
theorem cert_e606395874774 : check e606395874774 [[.under]] .sourceHead = true := by decide
def e606395874778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e606395874778 : Closed e606395874778 ∧ code e606395874778 = 9402488896986 := by decide
theorem cert_e606395874778 : check e606395874778 [[.under]] .sourceHead = true := by decide
def e606395874794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e606395874794 : Closed e606395874794 ∧ code e606395874794 = 9402488897002 := by decide
theorem cert_e606395874794 : check e606395874794 [[.under]] .sourceHead = true := by decide
def e606395874990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e606395874990 : Closed e606395874990 ∧ code e606395874990 = 9402488897198 := by decide
theorem cert_e606395874990 : check e606395874990 [[.under]] .sourceHead = true := by decide
def e606395874998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e606395874998 : Closed e606395874998 ∧ code e606395874998 = 9402488897206 := by decide
theorem cert_e606395874998 : check e606395874998 [[.under]] .sourceHead = true := by decide
def e606395875002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e606395875002 : Closed e606395875002 ∧ code e606395875002 = 9402488897210 := by decide
theorem cert_e606395875002 : check e606395875002 [[.under]] .sourceHead = true := by decide
def e606395875030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e606395875030 : Closed e606395875030 ∧ code e606395875030 = 9402488897238 := by decide
theorem cert_e606395875030 : check e606395875030 [[.under]] .sourceHead = true := by decide
def e606395875034 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e606395875034 : Closed e606395875034 ∧ code e606395875034 = 9402488897242 := by decide
theorem cert_e606395875034 : check e606395875034 [[.under]] .sourceHead = true := by decide
def e606395875050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e606395875050 : Closed e606395875050 ∧ code e606395875050 = 9402488897258 := by decide
theorem cert_e606395875050 : check e606395875050 [[.under]] .sourceHead = true := by decide
def e606395878878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))))
theorem wire_e606395878878 : Closed e606395878878 ∧ code e606395878878 = 9402488901086 := by decide
theorem cert_e606395878878 : check e606395878878 [[.under]] .sourceHead = true := by decide
def e606395878894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))))
theorem wire_e606395878894 : Closed e606395878894 ∧ code e606395878894 = 9402488901102 := by decide
theorem cert_e606395878894 : check e606395878894 [[.under]] .sourceHead = true := by decide
def e606395879134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))))
theorem wire_e606395879134 : Closed e606395879134 ∧ code e606395879134 = 9402488901342 := by decide
theorem cert_e606395879134 : check e606395879134 [[.under]] .sourceHead = true := by decide
def e606395879150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))))
theorem wire_e606395879150 : Closed e606395879150 ∧ code e606395879150 = 9402488901358 := by decide
theorem cert_e606395879150 : check e606395879150 [[.under]] .sourceHead = true := by decide
def e606395879158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))))
theorem wire_e606395879158 : Closed e606395879158 ∧ code e606395879158 = 9402488901366 := by decide
theorem cert_e606395879158 : check e606395879158 [[.under]] .sourceHead = true := by decide
def e606395879262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))))
theorem wire_e606395879262 : Closed e606395879262 ∧ code e606395879262 = 9402488901470 := by decide
theorem cert_e606395879262 : check e606395879262 [[.under]] .sourceHead = true := by decide
def e606395879278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))))
theorem wire_e606395879278 : Closed e606395879278 ∧ code e606395879278 = 9402488901486 := by decide
theorem cert_e606395879278 : check e606395879278 [[.under]] .sourceHead = true := by decide
def e606395879286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))))
theorem wire_e606395879286 : Closed e606395879286 ∧ code e606395879286 = 9402488901494 := by decide
theorem cert_e606395879286 : check e606395879286 [[.under]] .sourceHead = true := by decide
def e606395879290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))))
theorem wire_e606395879290 : Closed e606395879290 ∧ code e606395879290 = 9402488901498 := by decide
theorem cert_e606395879290 : check e606395879290 [[.under]] .sourceHead = true := by decide
def e606395879342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))))
theorem wire_e606395879342 : Closed e606395879342 ∧ code e606395879342 = 9402488901550 := by decide
theorem cert_e606395879342 : check e606395879342 [[.under]] .sourceHead = true := by decide
def e606395879350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))))
theorem wire_e606395879350 : Closed e606395879350 ∧ code e606395879350 = 9402488901558 := by decide
theorem cert_e606395879350 : check e606395879350 [[.under]] .sourceHead = true := by decide
def e606395879354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))))
theorem wire_e606395879354 : Closed e606395879354 ∧ code e606395879354 = 9402488901562 := by decide
theorem cert_e606395879354 : check e606395879354 [[.under]] .sourceHead = true := by decide
def e606395880414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))))
theorem wire_e606395880414 : Closed e606395880414 ∧ code e606395880414 = 9402488902622 := by decide
theorem cert_e606395880414 : check e606395880414 [[.under]] .sourceHead = true := by decide
def e606395880430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))))
theorem wire_e606395880430 : Closed e606395880430 ∧ code e606395880430 = 9402488902638 := by decide
theorem cert_e606395880430 : check e606395880430 [[.under]] .sourceHead = true := by decide
def e606395881950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))))
theorem wire_e606395881950 : Closed e606395881950 ∧ code e606395881950 = 9402488904158 := by decide
theorem cert_e606395881950 : check e606395881950 [[.under]] .sourceHead = true := by decide
def e606395881966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))))
theorem wire_e606395881966 : Closed e606395881966 ∧ code e606395881966 = 9402488904174 := by decide
theorem cert_e606395881966 : check e606395881966 [[.under]] .sourceHead = true := by decide
def e606395881974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))))
theorem wire_e606395881974 : Closed e606395881974 ∧ code e606395881974 = 9402488904182 := by decide
theorem cert_e606395881974 : check e606395881974 [[.under]] .sourceHead = true := by decide
def e606395882718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))))
theorem wire_e606395882718 : Closed e606395882718 ∧ code e606395882718 = 9402488904926 := by decide
theorem cert_e606395882718 : check e606395882718 [[.under]] .sourceHead = true := by decide
def e606395882734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))))
theorem wire_e606395882734 : Closed e606395882734 ∧ code e606395882734 = 9402488904942 := by decide
theorem cert_e606395882734 : check e606395882734 [[.under]] .sourceHead = true := by decide
def e606395882742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))))
theorem wire_e606395882742 : Closed e606395882742 ∧ code e606395882742 = 9402488904950 := by decide
theorem cert_e606395882742 : check e606395882742 [[.under]] .sourceHead = true := by decide
def e606395882746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))))
theorem wire_e606395882746 : Closed e606395882746 ∧ code e606395882746 = 9402488904954 := by decide
theorem cert_e606395882746 : check e606395882746 [[.under]] .sourceHead = true := by decide
def e606395883118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606395883118 : Closed e606395883118 ∧ code e606395883118 = 9402488905326 := by decide
theorem cert_e606395883118 : check e606395883118 [[.under]] .sourceHead = true := by decide
def e606395883126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))))
theorem wire_e606395883126 : Closed e606395883126 ∧ code e606395883126 = 9402488905334 := by decide
theorem cert_e606395883126 : check e606395883126 [[.under]] .sourceHead = true := by decide
def e606395883130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606395883130 : Closed e606395883130 ∧ code e606395883130 = 9402488905338 := by decide
theorem cert_e606395883130 : check e606395883130 [[.under]] .sourceHead = true := by decide
def e606395885278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e606395885278 : Closed e606395885278 ∧ code e606395885278 = 9402488907486 := by decide
theorem cert_e606395885278 : check e606395885278 [[.under]] .sourceHead = true := by decide
def e606395885294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))))
theorem wire_e606395885294 : Closed e606395885294 ∧ code e606395885294 = 9402488907502 := by decide
theorem cert_e606395885294 : check e606395885294 [[.under]] .sourceHead = true := by decide
def e606395885302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e606395885302 : Closed e606395885302 ∧ code e606395885302 = 9402488907510 := by decide
theorem cert_e606395885302 : check e606395885302 [[.under]] .sourceHead = true := by decide
def e606395885406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e606395885406 : Closed e606395885406 ∧ code e606395885406 = 9402488907614 := by decide
theorem cert_e606395885406 : check e606395885406 [[.under]] .sourceHead = true := by decide
def e606395885434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e606395885434 : Closed e606395885434 ∧ code e606395885434 = 9402488907642 := by decide
theorem cert_e606395885434 : check e606395885434 [[.under]] .sourceHead = true := by decide
def e606395885486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))))
theorem wire_e606395885486 : Closed e606395885486 ∧ code e606395885486 = 9402488907694 := by decide
theorem cert_e606395885486 : check e606395885486 [[.under]] .sourceHead = true := by decide
def e606395885498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))))
theorem wire_e606395885498 : Closed e606395885498 ∧ code e606395885498 = 9402488907706 := by decide
theorem cert_e606395885498 : check e606395885498 [[.under]] .sourceHead = true := by decide
def e606395885526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e606395885526 : Closed e606395885526 ∧ code e606395885526 = 9402488907734 := by decide
theorem cert_e606395885526 : check e606395885526 [[.under]] .sourceHead = true := by decide
def e606395885530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e606395885530 : Closed e606395885530 ∧ code e606395885530 = 9402488907738 := by decide
theorem cert_e606395885530 : check e606395885530 [[.under]] .sourceHead = true := by decide
def e606395886046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e606395886046 : Closed e606395886046 ∧ code e606395886046 = 9402488908254 := by decide
theorem cert_e606395886046 : check e606395886046 [[.under]] .sourceHead = true := by decide
def e606395886062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))))
theorem wire_e606395886062 : Closed e606395886062 ∧ code e606395886062 = 9402488908270 := by decide
theorem cert_e606395886062 : check e606395886062 [[.under]] .sourceHead = true := by decide
def e606395886070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e606395886070 : Closed e606395886070 ∧ code e606395886070 = 9402488908278 := by decide
theorem cert_e606395886070 : check e606395886070 [[.under]] .sourceHead = true := by decide
def e606395886814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e606395886814 : Closed e606395886814 ∧ code e606395886814 = 9402488909022 := by decide
theorem cert_e606395886814 : check e606395886814 [[.under]] .sourceHead = true := by decide
def e606395886842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e606395886842 : Closed e606395886842 ∧ code e606395886842 = 9402488909050 := by decide
theorem cert_e606395886842 : check e606395886842 [[.under]] .sourceHead = true := by decide
def e606395887214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606395887214 : Closed e606395887214 ∧ code e606395887214 = 9402488909422 := by decide
theorem cert_e606395887214 : check e606395887214 [[.under]] .sourceHead = true := by decide
def e606395887226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606395887226 : Closed e606395887226 ∧ code e606395887226 = 9402488909434 := by decide
theorem cert_e606395887226 : check e606395887226 [[.under]] .sourceHead = true := by decide
def e606395887414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606395887414 : Closed e606395887414 ∧ code e606395887414 = 9402488909622 := by decide
theorem cert_e606395887414 : check e606395887414 [[.under]] .sourceHead = true := by decide
def e606395887418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606395887418 : Closed e606395887418 ∧ code e606395887418 = 9402488909626 := by decide
theorem cert_e606395887418 : check e606395887418 [[.under]] .sourceHead = true := by decide
def e606395888478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e606395888478 : Closed e606395888478 ∧ code e606395888478 = 9402488910686 := by decide
theorem cert_e606395888478 : check e606395888478 [[.under]] .sourceHead = true := by decide
def e606395888494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e606395888494 : Closed e606395888494 ∧ code e606395888494 = 9402488910702 := by decide
theorem cert_e606395888494 : check e606395888494 [[.under]] .sourceHead = true := by decide
def e606395888502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e606395888502 : Closed e606395888502 ∧ code e606395888502 = 9402488910710 := by decide
theorem cert_e606395888502 : check e606395888502 [[.under]] .sourceHead = true := by decide
def e606395888506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e606395888506 : Closed e606395888506 ∧ code e606395888506 = 9402488910714 := by decide
theorem cert_e606395888506 : check e606395888506 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
