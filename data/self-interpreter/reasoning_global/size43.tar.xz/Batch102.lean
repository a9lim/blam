import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e838110081770 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e838110081770 : Closed e838110081770 ∧ code e838110081770 = 9634203103978 := by decide
theorem cert_e838110081770 : check e838110081770 [] .sourceHead = true := by decide
def e838110081846 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e838110081846 : Closed e838110081846 ∧ code e838110081846 = 9634203104054 := by decide
theorem cert_e838110081846 : check e838110081846 [] .sourceHead = true := by decide
def e838110081850 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e838110081850 : Closed e838110081850 ∧ code e838110081850 = 9634203104058 := by decide
theorem cert_e838110081850 : check e838110081850 [] .sourceHead = true := by decide
def e838110081946 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e838110081946 : Closed e838110081946 ∧ code e838110081946 = 9634203104154 := by decide
theorem cert_e838110081946 : check e838110081946 [] .sourceHead = true := by decide
def e838110219118 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e838110219118 : Closed e838110219118 ∧ code e838110219118 = 9634203241326 := by decide
theorem cert_e838110219118 : check e838110219118 [] .sourceHead = true := by decide
def e838110219126 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e838110219126 : Closed e838110219126 ∧ code e838110219126 = 9634203241334 := by decide
theorem cert_e838110219126 : check e838110219126 [] .sourceHead = true := by decide
def e838110219182 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e838110219182 : Closed e838110219182 ∧ code e838110219182 = 9634203241390 := by decide
theorem cert_e838110219182 : check e838110219182 [] .sourceHead = true := by decide
def e838110219194 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e838110219194 : Closed e838110219194 ∧ code e838110219194 = 9634203241402 := by decide
theorem cert_e838110219194 : check e838110219194 [] .sourceHead = true := by decide
def e838110219222 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e838110219222 : Closed e838110219222 ∧ code e838110219222 = 9634203241430 := by decide
theorem cert_e838110219222 : check e838110219222 [] .sourceHead = true := by decide
def e838110219226 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e838110219226 : Closed e838110219226 ∧ code e838110219226 = 9634203241434 := by decide
theorem cert_e838110219226 : check e838110219226 [] .sourceHead = true := by decide
def e838110219502 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e838110219502 : Closed e838110219502 ∧ code e838110219502 = 9634203241710 := by decide
theorem cert_e838110219502 : check e838110219502 [] .sourceHead = true := by decide
def e838110219510 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e838110219510 : Closed e838110219510 ∧ code e838110219510 = 9634203241718 := by decide
theorem cert_e838110219510 : check e838110219510 [] .sourceHead = true := by decide
def e838110219886 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e838110219886 : Closed e838110219886 ∧ code e838110219886 = 9634203242094 := by decide
theorem cert_e838110219886 : check e838110219886 [] .sourceHead = true := by decide
def e838110219898 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e838110219898 : Closed e838110219898 ∧ code e838110219898 = 9634203242106 := by decide
theorem cert_e838110219898 : check e838110219898 [] .sourceHead = true := by decide
def e838110220086 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e838110220086 : Closed e838110220086 ∧ code e838110220086 = 9634203242294 := by decide
theorem cert_e838110220086 : check e838110220086 [] .sourceHead = true := by decide
def e838110220090 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e838110220090 : Closed e838110220090 ∧ code e838110220090 = 9634203242298 := by decide
theorem cert_e838110220090 : check e838110220090 [] .sourceHead = true := by decide
def e859938975942 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859938975942 : Closed e859938975942 ∧ code e859938975942 = 9656031998150 := by decide
theorem cert_e859938975942 : check e859938975942 [] .sourceHead = true := by decide
def e859938992326 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859938992326 : Closed e859938992326 ∧ code e859938992326 = 9656032014534 := by decide
theorem cert_e859938992326 : check e859938992326 [] .sourceHead = true := by decide
def e859939107014 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859939107014 : Closed e859939107014 ∧ code e859939107014 = 9656032129222 := by decide
theorem cert_e859939107014 : check e859939107014 [] .sourceHead = true := by decide
def e859939131590 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859939131590 : Closed e859939131590 ∧ code e859939131590 = 9656032153798 := by decide
theorem cert_e859939131590 : check e859939131590 [] .sourceHead = true := by decide
def e859939188934 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859939188934 : Closed e859939188934 ∧ code e859939188934 = 9656032211142 := by decide
theorem cert_e859939188934 : check e859939188934 [] .sourceHead = true := by decide
def e859939197126 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859939197126 : Closed e859939197126 ∧ code e859939197126 = 9656032219334 := by decide
theorem cert_e859939197126 : check e859939197126 [] .sourceHead = true := by decide
def e859939762374 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859939762374 : Closed e859939762374 ∧ code e859939762374 = 9656032784582 := by decide
theorem cert_e859939762374 : check e859939762374 [] .sourceHead = true := by decide
def e859939778758 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859939778758 : Closed e859939778758 ∧ code e859939778758 = 9656032800966 := by decide
theorem cert_e859939778758 : check e859939778758 [] .sourceHead = true := by decide
def e859940548806 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859940548806 : Closed e859940548806 ∧ code e859940548806 = 9656033571014 := by decide
theorem cert_e859940548806 : check e859940548806 [] .sourceHead = true := by decide
def e859940573382 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859940573382 : Closed e859940573382 ∧ code e859940573382 = 9656033595590 := by decide
theorem cert_e859940573382 : check e859940573382 [] .sourceHead = true := by decide
def e859940958406 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859940958406 : Closed e859940958406 ∧ code e859940958406 = 9656033980614 := by decide
theorem cert_e859940958406 : check e859940958406 [] .sourceHead = true := by decide
def e859940966598 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e859940966598 : Closed e859940966598 ∧ code e859940966598 = 9656033988806 := by decide
theorem cert_e859940966598 : check e859940966598 [] .sourceHead = true := by decide
def e859983359342 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e859983359342 : Closed e859983359342 ∧ code e859983359342 = 9656076381550 := by decide
theorem cert_e859983359342 : check e859983359342 [] .sourceHead = true := by decide
def e859983359350 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e859983359350 : Closed e859983359350 ∧ code e859983359350 = 9656076381558 := by decide
theorem cert_e859983359350 : check e859983359350 [] .sourceHead = true := by decide
def e859983359406 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e859983359406 : Closed e859983359406 ∧ code e859983359406 = 9656076381614 := by decide
theorem cert_e859983359406 : check e859983359406 [] .sourceHead = true := by decide
def e859983359418 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e859983359418 : Closed e859983359418 ∧ code e859983359418 = 9656076381626 := by decide
theorem cert_e859983359418 : check e859983359418 [] .sourceHead = true := by decide
def e859983359446 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e859983359446 : Closed e859983359446 ∧ code e859983359446 = 9656076381654 := by decide
theorem cert_e859983359446 : check e859983359446 [] .sourceHead = true := by decide
def e859983359450 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e859983359450 : Closed e859983359450 ∧ code e859983359450 = 9656076381658 := by decide
theorem cert_e859983359450 : check e859983359450 [] .sourceHead = true := by decide
def e859983359662 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e859983359662 : Closed e859983359662 ∧ code e859983359662 = 9656076381870 := by decide
theorem cert_e859983359662 : check e859983359662 [] .sourceHead = true := by decide
def e859983359674 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e859983359674 : Closed e859983359674 ∧ code e859983359674 = 9656076381882 := by decide
theorem cert_e859983359674 : check e859983359674 [] .sourceHead = true := by decide
def e859983359722 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e859983359722 : Closed e859983359722 ∧ code e859983359722 = 9656076381930 := by decide
theorem cert_e859983359722 : check e859983359722 [] .sourceHead = true := by decide
def e859983359830 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e859983359830 : Closed e859983359830 ∧ code e859983359830 = 9656076382038 := by decide
theorem cert_e859983359830 : check e859983359830 [] .sourceHead = true := by decide
def e859983359834 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e859983359834 : Closed e859983359834 ∧ code e859983359834 = 9656076382042 := by decide
theorem cert_e859983359834 : check e859983359834 [] .sourceHead = true := by decide
def e859983359850 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e859983359850 : Closed e859983359850 ∧ code e859983359850 = 9656076382058 := by decide
theorem cert_e859983359850 : check e859983359850 [] .sourceHead = true := by decide
def e859983360878 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e859983360878 : Closed e859983360878 ∧ code e859983360878 = 9656076383086 := by decide
theorem cert_e859983360878 : check e859983360878 [] .sourceHead = true := by decide
def e859983360886 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e859983360886 : Closed e859983360886 ∧ code e859983360886 = 9656076383094 := by decide
theorem cert_e859983360886 : check e859983360886 [] .sourceHead = true := by decide
def e859983360942 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e859983360942 : Closed e859983360942 ∧ code e859983360942 = 9656076383150 := by decide
theorem cert_e859983360942 : check e859983360942 [] .sourceHead = true := by decide
def e859983360954 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e859983360954 : Closed e859983360954 ∧ code e859983360954 = 9656076383162 := by decide
theorem cert_e859983360954 : check e859983360954 [] .sourceHead = true := by decide
def e859983360982 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e859983360982 : Closed e859983360982 ∧ code e859983360982 = 9656076383190 := by decide
theorem cert_e859983360982 : check e859983360982 [] .sourceHead = true := by decide
def e859983360986 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e859983360986 : Closed e859983360986 ∧ code e859983360986 = 9656076383194 := by decide
theorem cert_e859983360986 : check e859983360986 [] .sourceHead = true := by decide
def e859983361262 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e859983361262 : Closed e859983361262 ∧ code e859983361262 = 9656076383470 := by decide
theorem cert_e859983361262 : check e859983361262 [] .sourceHead = true := by decide
def e859983361270 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e859983361270 : Closed e859983361270 ∧ code e859983361270 = 9656076383478 := by decide
theorem cert_e859983361270 : check e859983361270 [] .sourceHead = true := by decide
def e859983361646 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e859983361646 : Closed e859983361646 ∧ code e859983361646 = 9656076383854 := by decide
theorem cert_e859983361646 : check e859983361646 [] .sourceHead = true := by decide
def e859983361658 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e859983361658 : Closed e859983361658 ∧ code e859983361658 = 9656076383866 := by decide
theorem cert_e859983361658 : check e859983361658 [] .sourceHead = true := by decide
def e859983361846 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e859983361846 : Closed e859983361846 ∧ code e859983361846 = 9656076384054 := by decide
theorem cert_e859983361846 : check e859983361846 [] .sourceHead = true := by decide
def e859983361850 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e859983361850 : Closed e859983361850 ∧ code e859983361850 = 9656076384058 := by decide
theorem cert_e859983361850 : check e859983361850 [] .sourceHead = true := by decide
def e859983362478 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e859983362478 : Closed e859983362478 ∧ code e859983362478 = 9656076384686 := by decide
theorem cert_e859983362478 : check e859983362478 [] .sourceHead = true := by decide
def e859983362490 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e859983362490 : Closed e859983362490 ∧ code e859983362490 = 9656076384698 := by decide
theorem cert_e859983362490 : check e859983362490 [] .sourceHead = true := by decide
def e859983362538 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e859983362538 : Closed e859983362538 ∧ code e859983362538 = 9656076384746 := by decide
theorem cert_e859983362538 : check e859983362538 [] .sourceHead = true := by decide
def e859983362670 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e859983362670 : Closed e859983362670 ∧ code e859983362670 = 9656076384878 := by decide
theorem cert_e859983362670 : check e859983362670 [] .sourceHead = true := by decide
def e859983362682 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e859983362682 : Closed e859983362682 ∧ code e859983362682 = 9656076384890 := by decide
theorem cert_e859983362682 : check e859983362682 [] .sourceHead = true := by decide
def e859983362970 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e859983362970 : Closed e859983362970 ∧ code e859983362970 = 9656076385178 := by decide
theorem cert_e859983362970 : check e859983362970 [] .sourceHead = true := by decide
def e859983363286 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e859983363286 : Closed e859983363286 ∧ code e859983363286 = 9656076385494 := by decide
theorem cert_e859983363286 : check e859983363286 [] .sourceHead = true := by decide
def e859983363290 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e859983363290 : Closed e859983363290 ∧ code e859983363290 = 9656076385498 := by decide
theorem cert_e859983363290 : check e859983363290 [] .sourceHead = true := by decide
def e859983363306 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e859983363306 : Closed e859983363306 ∧ code e859983363306 = 9656076385514 := by decide
theorem cert_e859983363306 : check e859983363306 [] .sourceHead = true := by decide
def e859983363382 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e859983363382 : Closed e859983363382 ∧ code e859983363382 = 9656076385590 := by decide
theorem cert_e859983363382 : check e859983363382 [] .sourceHead = true := by decide
def e859983363386 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e859983363386 : Closed e859983363386 ∧ code e859983363386 = 9656076385594 := by decide
theorem cert_e859983363386 : check e859983363386 [] .sourceHead = true := by decide
def e859983363482 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e859983363482 : Closed e859983363482 ∧ code e859983363482 = 9656076385690 := by decide
theorem cert_e859983363482 : check e859983363482 [] .sourceHead = true := by decide
def e859983367022 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e859983367022 : Closed e859983367022 ∧ code e859983367022 = 9656076389230 := by decide
theorem cert_e859983367022 : check e859983367022 [] .sourceHead = true := by decide
def e859983367030 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e859983367030 : Closed e859983367030 ∧ code e859983367030 = 9656076389238 := by decide
theorem cert_e859983367030 : check e859983367030 [] .sourceHead = true := by decide
def e859983367086 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e859983367086 : Closed e859983367086 ∧ code e859983367086 = 9656076389294 := by decide
theorem cert_e859983367086 : check e859983367086 [] .sourceHead = true := by decide
def e859983367098 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e859983367098 : Closed e859983367098 ∧ code e859983367098 = 9656076389306 := by decide
theorem cert_e859983367098 : check e859983367098 [] .sourceHead = true := by decide
def e859983367126 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e859983367126 : Closed e859983367126 ∧ code e859983367126 = 9656076389334 := by decide
theorem cert_e859983367126 : check e859983367126 [] .sourceHead = true := by decide
def e859983367130 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e859983367130 : Closed e859983367130 ∧ code e859983367130 = 9656076389338 := by decide
theorem cert_e859983367130 : check e859983367130 [] .sourceHead = true := by decide
def e859983367406 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e859983367406 : Closed e859983367406 ∧ code e859983367406 = 9656076389614 := by decide
theorem cert_e859983367406 : check e859983367406 [] .sourceHead = true := by decide
def e859983367414 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e859983367414 : Closed e859983367414 ∧ code e859983367414 = 9656076389622 := by decide
theorem cert_e859983367414 : check e859983367414 [] .sourceHead = true := by decide
def e859983367790 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e859983367790 : Closed e859983367790 ∧ code e859983367790 = 9656076389998 := by decide
theorem cert_e859983367790 : check e859983367790 [] .sourceHead = true := by decide
def e859983367802 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e859983367802 : Closed e859983367802 ∧ code e859983367802 = 9656076390010 := by decide
theorem cert_e859983367802 : check e859983367802 [] .sourceHead = true := by decide
def e859983367990 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e859983367990 : Closed e859983367990 ∧ code e859983367990 = 9656076390198 := by decide
theorem cert_e859983367990 : check e859983367990 [] .sourceHead = true := by decide
def e859983367994 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e859983367994 : Closed e859983367994 ∧ code e859983367994 = 9656076390202 := by decide
theorem cert_e859983367994 : check e859983367994 [] .sourceHead = true := by decide
def e859983373742 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e859983373742 : Closed e859983373742 ∧ code e859983373742 = 9656076395950 := by decide
theorem cert_e859983373742 : check e859983373742 [] .sourceHead = true := by decide
def e859983373754 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e859983373754 : Closed e859983373754 ∧ code e859983373754 = 9656076395962 := by decide
theorem cert_e859983373754 : check e859983373754 [] .sourceHead = true := by decide
def e859983373802 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e859983373802 : Closed e859983373802 ∧ code e859983373802 = 9656076396010 := by decide
theorem cert_e859983373802 : check e859983373802 [] .sourceHead = true := by decide
def e859983373934 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e859983373934 : Closed e859983373934 ∧ code e859983373934 = 9656076396142 := by decide
theorem cert_e859983373934 : check e859983373934 [] .sourceHead = true := by decide
def e859983373946 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e859983373946 : Closed e859983373946 ∧ code e859983373946 = 9656076396154 := by decide
theorem cert_e859983373946 : check e859983373946 [] .sourceHead = true := by decide
def e859983374234 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e859983374234 : Closed e859983374234 ∧ code e859983374234 = 9656076396442 := by decide
theorem cert_e859983374234 : check e859983374234 [] .sourceHead = true := by decide
def e859983377110 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e859983377110 : Closed e859983377110 ∧ code e859983377110 = 9656076399318 := by decide
theorem cert_e859983377110 : check e859983377110 [] .sourceHead = true := by decide
def e859983377114 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e859983377114 : Closed e859983377114 ∧ code e859983377114 = 9656076399322 := by decide
theorem cert_e859983377114 : check e859983377114 [] .sourceHead = true := by decide
def e859983377130 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e859983377130 : Closed e859983377130 ∧ code e859983377130 = 9656076399338 := by decide
theorem cert_e859983377130 : check e859983377130 [] .sourceHead = true := by decide
def e859983377206 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e859983377206 : Closed e859983377206 ∧ code e859983377206 = 9656076399414 := by decide
theorem cert_e859983377206 : check e859983377206 [] .sourceHead = true := by decide
def e859983377210 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e859983377210 : Closed e859983377210 ∧ code e859983377210 = 9656076399418 := by decide
theorem cert_e859983377210 : check e859983377210 [] .sourceHead = true := by decide
def e859983377306 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e859983377306 : Closed e859983377306 ∧ code e859983377306 = 9656076399514 := by decide
theorem cert_e859983377306 : check e859983377306 [] .sourceHead = true := by decide
def e859983514478 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e859983514478 : Closed e859983514478 ∧ code e859983514478 = 9656076536686 := by decide
theorem cert_e859983514478 : check e859983514478 [] .sourceHead = true := by decide
def e859983514486 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e859983514486 : Closed e859983514486 ∧ code e859983514486 = 9656076536694 := by decide
theorem cert_e859983514486 : check e859983514486 [] .sourceHead = true := by decide
def e859983514542 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e859983514542 : Closed e859983514542 ∧ code e859983514542 = 9656076536750 := by decide
theorem cert_e859983514542 : check e859983514542 [] .sourceHead = true := by decide
def e859983514554 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e859983514554 : Closed e859983514554 ∧ code e859983514554 = 9656076536762 := by decide
theorem cert_e859983514554 : check e859983514554 [] .sourceHead = true := by decide
def e859983514582 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e859983514582 : Closed e859983514582 ∧ code e859983514582 = 9656076536790 := by decide
theorem cert_e859983514582 : check e859983514582 [] .sourceHead = true := by decide
def e859983514586 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e859983514586 : Closed e859983514586 ∧ code e859983514586 = 9656076536794 := by decide
theorem cert_e859983514586 : check e859983514586 [] .sourceHead = true := by decide
def e859983514862 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e859983514862 : Closed e859983514862 ∧ code e859983514862 = 9656076537070 := by decide
theorem cert_e859983514862 : check e859983514862 [] .sourceHead = true := by decide
def e859983514870 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e859983514870 : Closed e859983514870 ∧ code e859983514870 = 9656076537078 := by decide
theorem cert_e859983514870 : check e859983514870 [] .sourceHead = true := by decide
def e859983515246 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e859983515246 : Closed e859983515246 ∧ code e859983515246 = 9656076537454 := by decide
theorem cert_e859983515246 : check e859983515246 [] .sourceHead = true := by decide
def e859983515258 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e859983515258 : Closed e859983515258 ∧ code e859983515258 = 9656076537466 := by decide
theorem cert_e859983515258 : check e859983515258 [] .sourceHead = true := by decide
def e859983515446 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e859983515446 : Closed e859983515446 ∧ code e859983515446 = 9656076537654 := by decide
theorem cert_e859983515446 : check e859983515446 [] .sourceHead = true := by decide
def e859983515450 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e859983515450 : Closed e859983515450 ∧ code e859983515450 = 9656076537658 := by decide
theorem cert_e859983515450 : check e859983515450 [] .sourceHead = true := by decide
def e859984104302 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e859984104302 : Closed e859984104302 ∧ code e859984104302 = 9656077126510 := by decide
theorem cert_e859984104302 : check e859984104302 [] .sourceHead = true := by decide
def e859984104310 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e859984104310 : Closed e859984104310 ∧ code e859984104310 = 9656077126518 := by decide
theorem cert_e859984104310 : check e859984104310 [] .sourceHead = true := by decide
def e859984104366 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e859984104366 : Closed e859984104366 ∧ code e859984104366 = 9656077126574 := by decide
theorem cert_e859984104366 : check e859984104366 [] .sourceHead = true := by decide
def e859984104378 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e859984104378 : Closed e859984104378 ∧ code e859984104378 = 9656077126586 := by decide
theorem cert_e859984104378 : check e859984104378 [] .sourceHead = true := by decide
def e859984104406 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e859984104406 : Closed e859984104406 ∧ code e859984104406 = 9656077126614 := by decide
theorem cert_e859984104406 : check e859984104406 [] .sourceHead = true := by decide
def e859984104410 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e859984104410 : Closed e859984104410 ∧ code e859984104410 = 9656077126618 := by decide
theorem cert_e859984104410 : check e859984104410 [] .sourceHead = true := by decide
def e859984104686 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e859984104686 : Closed e859984104686 ∧ code e859984104686 = 9656077126894 := by decide
theorem cert_e859984104686 : check e859984104686 [] .sourceHead = true := by decide
def e859984104694 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e859984104694 : Closed e859984104694 ∧ code e859984104694 = 9656077126902 := by decide
theorem cert_e859984104694 : check e859984104694 [] .sourceHead = true := by decide
def e859984105070 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e859984105070 : Closed e859984105070 ∧ code e859984105070 = 9656077127278 := by decide
theorem cert_e859984105070 : check e859984105070 [] .sourceHead = true := by decide
def e859984105082 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e859984105082 : Closed e859984105082 ∧ code e859984105082 = 9656077127290 := by decide
theorem cert_e859984105082 : check e859984105082 [] .sourceHead = true := by decide
def e859984105270 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e859984105270 : Closed e859984105270 ∧ code e859984105270 = 9656077127478 := by decide
theorem cert_e859984105270 : check e859984105270 [] .sourceHead = true := by decide
def e859984105274 : Term := (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e859984105274 : Closed e859984105274 ∧ code e859984105274 = 9656077127482 := by decide
theorem cert_e859984105274 : check e859984105274 [] .sourceHead = true := by decide
def e861949245978 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861949245978 : Closed e861949245978 ∧ code e861949245978 = 9658042268186 := by decide
theorem cert_e861949245978 : check e861949245978 [] .sourceHead = true := by decide
def e861949254170 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861949254170 : Closed e861949254170 ∧ code e861949254170 = 9658042276378 := by decide
theorem cert_e861949254170 : check e861949254170 [] .sourceHead = true := by decide
def e861949311514 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861949311514 : Closed e861949311514 ∧ code e861949311514 = 9658042333722 := by decide
theorem cert_e861949311514 : check e861949311514 [] .sourceHead = true := by decide
def e861949323802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861949323802 : Closed e861949323802 ∧ code e861949323802 = 9658042346010 := by decide
theorem cert_e861949323802 : check e861949323802 [] .sourceHead = true := by decide
def e861949352474 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861949352474 : Closed e861949352474 ∧ code e861949352474 = 9658042374682 := by decide
theorem cert_e861949352474 : check e861949352474 [] .sourceHead = true := by decide
def e861949356570 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861949356570 : Closed e861949356570 ∧ code e861949356570 = 9658042378778 := by decide
theorem cert_e861949356570 : check e861949356570 [] .sourceHead = true := by decide
def e861949639194 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861949639194 : Closed e861949639194 ∧ code e861949639194 = 9658042661402 := by decide
theorem cert_e861949639194 : check e861949639194 [] .sourceHead = true := by decide
def e861949647386 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861949647386 : Closed e861949647386 ∧ code e861949647386 = 9658042669594 := by decide
theorem cert_e861949647386 : check e861949647386 [] .sourceHead = true := by decide
def e861950032410 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861950032410 : Closed e861950032410 ∧ code e861950032410 = 9658043054618 := by decide
theorem cert_e861950032410 : check e861950032410 [] .sourceHead = true := by decide
def e861950044698 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861950044698 : Closed e861950044698 ∧ code e861950044698 = 9658043066906 := by decide
theorem cert_e861950044698 : check e861950044698 [] .sourceHead = true := by decide
def e861950237210 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861950237210 : Closed e861950237210 ∧ code e861950237210 = 9658043259418 := by decide
theorem cert_e861950237210 : check e861950237210 [] .sourceHead = true := by decide
def e861950241306 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e861950241306 : Closed e861950241306 ∧ code e861950241306 = 9658043263514 := by decide
theorem cert_e861950241306 : check e861950241306 [] .sourceHead = true := by decide
def e862014107162 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014107162 : Closed e862014107162 ∧ code e862014107162 = 9658107129370 := by decide
theorem cert_e862014107162 : check e862014107162 [] .sourceHead = true := by decide
def e862014109210 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014109210 : Closed e862014109210 ∧ code e862014109210 = 9658107131418 := by decide
theorem cert_e862014109210 : check e862014109210 [] .sourceHead = true := by decide
def e862014123546 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014123546 : Closed e862014123546 ∧ code e862014123546 = 9658107145754 := by decide
theorem cert_e862014123546 : check e862014123546 [] .sourceHead = true := by decide
def e862014126618 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014126618 : Closed e862014126618 ∧ code e862014126618 = 9658107148826 := by decide
theorem cert_e862014126618 : check e862014126618 [] .sourceHead = true := by decide
def e862014133786 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014133786 : Closed e862014133786 ∧ code e862014133786 = 9658107155994 := by decide
theorem cert_e862014133786 : check e862014133786 [] .sourceHead = true := by decide
def e862014134810 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014134810 : Closed e862014134810 ∧ code e862014134810 = 9658107157018 := by decide
theorem cert_e862014134810 : check e862014134810 [] .sourceHead = true := by decide
def e862014205466 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014205466 : Closed e862014205466 ∧ code e862014205466 = 9658107227674 := by decide
theorem cert_e862014205466 : check e862014205466 [] .sourceHead = true := by decide
def e862014207514 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014207514 : Closed e862014207514 ∧ code e862014207514 = 9658107229722 := by decide
theorem cert_e862014207514 : check e862014207514 [] .sourceHead = true := by decide
def e862014303770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014303770 : Closed e862014303770 ∧ code e862014303770 = 9658107325978 := by decide
theorem cert_e862014303770 : check e862014303770 [] .sourceHead = true := by decide
def e862014306842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014306842 : Closed e862014306842 ∧ code e862014306842 = 9658107329050 := by decide
theorem cert_e862014306842 : check e862014306842 [] .sourceHead = true := by decide
def e862014354970 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014354970 : Closed e862014354970 ∧ code e862014354970 = 9658107377178 := by decide
theorem cert_e862014354970 : check e862014354970 [] .sourceHead = true := by decide
def e862014355994 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e862014355994 : Closed e862014355994 ∧ code e862014355994 = 9658107378202 := by decide
theorem cert_e862014355994 : check e862014355994 [] .sourceHead = true := by decide
def e862030179694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e862030179694 : Closed e862030179694 ∧ code e862030179694 = 9658123201902 := by decide
theorem cert_e862030179694 : check e862030179694 [] .sourceHead = true := by decide
def e862030179702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e862030179702 : Closed e862030179702 ∧ code e862030179702 = 9658123201910 := by decide
theorem cert_e862030179702 : check e862030179702 [] .sourceHead = true := by decide
def e862030179758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e862030179758 : Closed e862030179758 ∧ code e862030179758 = 9658123201966 := by decide
theorem cert_e862030179758 : check e862030179758 [] .sourceHead = true := by decide
def e862030179770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e862030179770 : Closed e862030179770 ∧ code e862030179770 = 9658123201978 := by decide
theorem cert_e862030179770 : check e862030179770 [] .sourceHead = true := by decide
def e862030179798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e862030179798 : Closed e862030179798 ∧ code e862030179798 = 9658123202006 := by decide
theorem cert_e862030179798 : check e862030179798 [] .sourceHead = true := by decide
def e862030179802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e862030179802 : Closed e862030179802 ∧ code e862030179802 = 9658123202010 := by decide
theorem cert_e862030179802 : check e862030179802 [] .sourceHead = true := by decide
def e862030180014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e862030180014 : Closed e862030180014 ∧ code e862030180014 = 9658123202222 := by decide
theorem cert_e862030180014 : check e862030180014 [] .sourceHead = true := by decide
def e862030180026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e862030180026 : Closed e862030180026 ∧ code e862030180026 = 9658123202234 := by decide
theorem cert_e862030180026 : check e862030180026 [] .sourceHead = true := by decide
def e862030180074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e862030180074 : Closed e862030180074 ∧ code e862030180074 = 9658123202282 := by decide
theorem cert_e862030180074 : check e862030180074 [] .sourceHead = true := by decide
def e862030180182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e862030180182 : Closed e862030180182 ∧ code e862030180182 = 9658123202390 := by decide
theorem cert_e862030180182 : check e862030180182 [] .sourceHead = true := by decide
def e862030180186 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e862030180186 : Closed e862030180186 ∧ code e862030180186 = 9658123202394 := by decide
theorem cert_e862030180186 : check e862030180186 [] .sourceHead = true := by decide
def e862030180202 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e862030180202 : Closed e862030180202 ∧ code e862030180202 = 9658123202410 := by decide
theorem cert_e862030180202 : check e862030180202 [] .sourceHead = true := by decide
def e862030181230 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e862030181230 : Closed e862030181230 ∧ code e862030181230 = 9658123203438 := by decide
theorem cert_e862030181230 : check e862030181230 [] .sourceHead = true := by decide
def e862030181238 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e862030181238 : Closed e862030181238 ∧ code e862030181238 = 9658123203446 := by decide
theorem cert_e862030181238 : check e862030181238 [] .sourceHead = true := by decide
def e862030181294 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e862030181294 : Closed e862030181294 ∧ code e862030181294 = 9658123203502 := by decide
theorem cert_e862030181294 : check e862030181294 [] .sourceHead = true := by decide
def e862030181306 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e862030181306 : Closed e862030181306 ∧ code e862030181306 = 9658123203514 := by decide
theorem cert_e862030181306 : check e862030181306 [] .sourceHead = true := by decide
def e862030181334 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e862030181334 : Closed e862030181334 ∧ code e862030181334 = 9658123203542 := by decide
theorem cert_e862030181334 : check e862030181334 [] .sourceHead = true := by decide
def e862030181338 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e862030181338 : Closed e862030181338 ∧ code e862030181338 = 9658123203546 := by decide
theorem cert_e862030181338 : check e862030181338 [] .sourceHead = true := by decide
def e862030181614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e862030181614 : Closed e862030181614 ∧ code e862030181614 = 9658123203822 := by decide
theorem cert_e862030181614 : check e862030181614 [] .sourceHead = true := by decide
def e862030181622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e862030181622 : Closed e862030181622 ∧ code e862030181622 = 9658123203830 := by decide
theorem cert_e862030181622 : check e862030181622 [] .sourceHead = true := by decide
def e862030181998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e862030181998 : Closed e862030181998 ∧ code e862030181998 = 9658123204206 := by decide
theorem cert_e862030181998 : check e862030181998 [] .sourceHead = true := by decide
def e862030182010 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e862030182010 : Closed e862030182010 ∧ code e862030182010 = 9658123204218 := by decide
theorem cert_e862030182010 : check e862030182010 [] .sourceHead = true := by decide
def e862030182198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e862030182198 : Closed e862030182198 ∧ code e862030182198 = 9658123204406 := by decide
theorem cert_e862030182198 : check e862030182198 [] .sourceHead = true := by decide
def e862030182202 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e862030182202 : Closed e862030182202 ∧ code e862030182202 = 9658123204410 := by decide
theorem cert_e862030182202 : check e862030182202 [] .sourceHead = true := by decide
end Blc.Floor43
