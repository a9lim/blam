import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e606408340202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e606408340202 : Closed e606408340202 ∧ code e606408340202 = 9402501362410 := by decide
theorem cert_e606408340202 : check e606408340202 [[.under]] .sourceHead = true := by decide
def e606408340278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606408340278 : Closed e606408340278 ∧ code e606408340278 = 9402501362486 := by decide
theorem cert_e606408340278 : check e606408340278 [[.under]] .sourceHead = true := by decide
def e606408340282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606408340282 : Closed e606408340282 ∧ code e606408340282 = 9402501362490 := by decide
theorem cert_e606408340282 : check e606408340282 [[.under]] .sourceHead = true := by decide
def e606408340378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606408340378 : Closed e606408340378 ∧ code e606408340378 = 9402501362586 := by decide
theorem cert_e606408340378 : check e606408340378 [[.under]] .sourceHead = true := by decide
def e606408477550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606408477550 : Closed e606408477550 ∧ code e606408477550 = 9402501499758 := by decide
theorem cert_e606408477550 : check e606408477550 [[.under]] .sourceHead = true := by decide
def e606408477558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606408477558 : Closed e606408477558 ∧ code e606408477558 = 9402501499766 := by decide
theorem cert_e606408477558 : check e606408477558 [[.under]] .sourceHead = true := by decide
def e606408477614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606408477614 : Closed e606408477614 ∧ code e606408477614 = 9402501499822 := by decide
theorem cert_e606408477614 : check e606408477614 [[.under]] .sourceHead = true := by decide
def e606408477626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606408477626 : Closed e606408477626 ∧ code e606408477626 = 9402501499834 := by decide
theorem cert_e606408477626 : check e606408477626 [[.under]] .sourceHead = true := by decide
def e606408477654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606408477654 : Closed e606408477654 ∧ code e606408477654 = 9402501499862 := by decide
theorem cert_e606408477654 : check e606408477654 [[.under]] .sourceHead = true := by decide
def e606408477658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606408477658 : Closed e606408477658 ∧ code e606408477658 = 9402501499866 := by decide
theorem cert_e606408477658 : check e606408477658 [[.under]] .sourceHead = true := by decide
def e606408477934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606408477934 : Closed e606408477934 ∧ code e606408477934 = 9402501500142 := by decide
theorem cert_e606408477934 : check e606408477934 [[.under]] .sourceHead = true := by decide
def e606408477942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606408477942 : Closed e606408477942 ∧ code e606408477942 = 9402501500150 := by decide
theorem cert_e606408477942 : check e606408477942 [[.under]] .sourceHead = true := by decide
def e606408478318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606408478318 : Closed e606408478318 ∧ code e606408478318 = 9402501500526 := by decide
theorem cert_e606408478318 : check e606408478318 [[.under]] .sourceHead = true := by decide
def e606408478330 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606408478330 : Closed e606408478330 ∧ code e606408478330 = 9402501500538 := by decide
theorem cert_e606408478330 : check e606408478330 [[.under]] .sourceHead = true := by decide
def e606408478518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606408478518 : Closed e606408478518 ∧ code e606408478518 = 9402501500726 := by decide
theorem cert_e606408478518 : check e606408478518 [[.under]] .sourceHead = true := by decide
def e606408478522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606408478522 : Closed e606408478522 ∧ code e606408478522 = 9402501500730 := by decide
theorem cert_e606408478522 : check e606408478522 [[.under]] .sourceHead = true := by decide
def e606409067374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606409067374 : Closed e606409067374 ∧ code e606409067374 = 9402502089582 := by decide
theorem cert_e606409067374 : check e606409067374 [[.under]] .sourceHead = true := by decide
def e606409067382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606409067382 : Closed e606409067382 ∧ code e606409067382 = 9402502089590 := by decide
theorem cert_e606409067382 : check e606409067382 [[.under]] .sourceHead = true := by decide
def e606409067438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606409067438 : Closed e606409067438 ∧ code e606409067438 = 9402502089646 := by decide
theorem cert_e606409067438 : check e606409067438 [[.under]] .sourceHead = true := by decide
def e606409067450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606409067450 : Closed e606409067450 ∧ code e606409067450 = 9402502089658 := by decide
theorem cert_e606409067450 : check e606409067450 [[.under]] .sourceHead = true := by decide
def e606409067478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606409067478 : Closed e606409067478 ∧ code e606409067478 = 9402502089686 := by decide
theorem cert_e606409067478 : check e606409067478 [[.under]] .sourceHead = true := by decide
def e606409067482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606409067482 : Closed e606409067482 ∧ code e606409067482 = 9402502089690 := by decide
theorem cert_e606409067482 : check e606409067482 [[.under]] .sourceHead = true := by decide
def e606409067758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606409067758 : Closed e606409067758 ∧ code e606409067758 = 9402502089966 := by decide
theorem cert_e606409067758 : check e606409067758 [[.under]] .sourceHead = true := by decide
def e606409067766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606409067766 : Closed e606409067766 ∧ code e606409067766 = 9402502089974 := by decide
theorem cert_e606409067766 : check e606409067766 [[.under]] .sourceHead = true := by decide
def e606409068142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606409068142 : Closed e606409068142 ∧ code e606409068142 = 9402502090350 := by decide
theorem cert_e606409068142 : check e606409068142 [[.under]] .sourceHead = true := by decide
def e606409068154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606409068154 : Closed e606409068154 ∧ code e606409068154 = 9402502090362 := by decide
theorem cert_e606409068154 : check e606409068154 [[.under]] .sourceHead = true := by decide
def e606409068342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606409068342 : Closed e606409068342 ∧ code e606409068342 = 9402502090550 := by decide
theorem cert_e606409068342 : check e606409068342 [[.under]] .sourceHead = true := by decide
def e606409068346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606409068346 : Closed e606409068346 ∧ code e606409068346 = 9402502090554 := by decide
theorem cert_e606409068346 : check e606409068346 [[.under]] .sourceHead = true := by decide
def e606446071150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e606446071150 : Closed e606446071150 ∧ code e606446071150 = 9402539093358 := by decide
theorem cert_e606446071150 : check e606446071150 [[.under]] .sourceHead = true := by decide
def e606446071158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e606446071158 : Closed e606446071158 ∧ code e606446071158 = 9402539093366 := by decide
theorem cert_e606446071158 : check e606446071158 [[.under]] .sourceHead = true := by decide
def e606446071214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e606446071214 : Closed e606446071214 ∧ code e606446071214 = 9402539093422 := by decide
theorem cert_e606446071214 : check e606446071214 [[.under]] .sourceHead = true := by decide
def e606446071226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e606446071226 : Closed e606446071226 ∧ code e606446071226 = 9402539093434 := by decide
theorem cert_e606446071226 : check e606446071226 [[.under]] .sourceHead = true := by decide
def e606446071254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e606446071254 : Closed e606446071254 ∧ code e606446071254 = 9402539093462 := by decide
theorem cert_e606446071254 : check e606446071254 [[.under]] .sourceHead = true := by decide
def e606446071258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e606446071258 : Closed e606446071258 ∧ code e606446071258 = 9402539093466 := by decide
theorem cert_e606446071258 : check e606446071258 [[.under]] .sourceHead = true := by decide
def e606446071470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e606446071470 : Closed e606446071470 ∧ code e606446071470 = 9402539093678 := by decide
theorem cert_e606446071470 : check e606446071470 [[.under]] .sourceHead = true := by decide
def e606446071482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e606446071482 : Closed e606446071482 ∧ code e606446071482 = 9402539093690 := by decide
theorem cert_e606446071482 : check e606446071482 [[.under]] .sourceHead = true := by decide
def e606446071530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e606446071530 : Closed e606446071530 ∧ code e606446071530 = 9402539093738 := by decide
theorem cert_e606446071530 : check e606446071530 [[.under]] .sourceHead = true := by decide
def e606446071638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e606446071638 : Closed e606446071638 ∧ code e606446071638 = 9402539093846 := by decide
theorem cert_e606446071638 : check e606446071638 [[.under]] .sourceHead = true := by decide
def e606446071642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e606446071642 : Closed e606446071642 ∧ code e606446071642 = 9402539093850 := by decide
theorem cert_e606446071642 : check e606446071642 [[.under]] .sourceHead = true := by decide
def e606446071658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e606446071658 : Closed e606446071658 ∧ code e606446071658 = 9402539093866 := by decide
theorem cert_e606446071658 : check e606446071658 [[.under]] .sourceHead = true := by decide
def e606446072686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e606446072686 : Closed e606446072686 ∧ code e606446072686 = 9402539094894 := by decide
theorem cert_e606446072686 : check e606446072686 [[.under]] .sourceHead = true := by decide
def e606446072694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e606446072694 : Closed e606446072694 ∧ code e606446072694 = 9402539094902 := by decide
theorem cert_e606446072694 : check e606446072694 [[.under]] .sourceHead = true := by decide
def e606446072750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e606446072750 : Closed e606446072750 ∧ code e606446072750 = 9402539094958 := by decide
theorem cert_e606446072750 : check e606446072750 [[.under]] .sourceHead = true := by decide
def e606446072762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e606446072762 : Closed e606446072762 ∧ code e606446072762 = 9402539094970 := by decide
theorem cert_e606446072762 : check e606446072762 [[.under]] .sourceHead = true := by decide
def e606446072790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e606446072790 : Closed e606446072790 ∧ code e606446072790 = 9402539094998 := by decide
theorem cert_e606446072790 : check e606446072790 [[.under]] .sourceHead = true := by decide
def e606446072794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e606446072794 : Closed e606446072794 ∧ code e606446072794 = 9402539095002 := by decide
theorem cert_e606446072794 : check e606446072794 [[.under]] .sourceHead = true := by decide
def e606446073070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e606446073070 : Closed e606446073070 ∧ code e606446073070 = 9402539095278 := by decide
theorem cert_e606446073070 : check e606446073070 [[.under]] .sourceHead = true := by decide
def e606446073078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e606446073078 : Closed e606446073078 ∧ code e606446073078 = 9402539095286 := by decide
theorem cert_e606446073078 : check e606446073078 [[.under]] .sourceHead = true := by decide
def e606446073454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606446073454 : Closed e606446073454 ∧ code e606446073454 = 9402539095662 := by decide
theorem cert_e606446073454 : check e606446073454 [[.under]] .sourceHead = true := by decide
def e606446073466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606446073466 : Closed e606446073466 ∧ code e606446073466 = 9402539095674 := by decide
theorem cert_e606446073466 : check e606446073466 [[.under]] .sourceHead = true := by decide
def e606446073654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606446073654 : Closed e606446073654 ∧ code e606446073654 = 9402539095862 := by decide
theorem cert_e606446073654 : check e606446073654 [[.under]] .sourceHead = true := by decide
def e606446073658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606446073658 : Closed e606446073658 ∧ code e606446073658 = 9402539095866 := by decide
theorem cert_e606446073658 : check e606446073658 [[.under]] .sourceHead = true := by decide
def e606446074286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e606446074286 : Closed e606446074286 ∧ code e606446074286 = 9402539096494 := by decide
theorem cert_e606446074286 : check e606446074286 [[.under]] .sourceHead = true := by decide
def e606446074298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e606446074298 : Closed e606446074298 ∧ code e606446074298 = 9402539096506 := by decide
theorem cert_e606446074298 : check e606446074298 [[.under]] .sourceHead = true := by decide
def e606446074346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e606446074346 : Closed e606446074346 ∧ code e606446074346 = 9402539096554 := by decide
theorem cert_e606446074346 : check e606446074346 [[.under]] .sourceHead = true := by decide
def e606446074478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606446074478 : Closed e606446074478 ∧ code e606446074478 = 9402539096686 := by decide
theorem cert_e606446074478 : check e606446074478 [[.under]] .sourceHead = true := by decide
def e606446074490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606446074490 : Closed e606446074490 ∧ code e606446074490 = 9402539096698 := by decide
theorem cert_e606446074490 : check e606446074490 [[.under]] .sourceHead = true := by decide
def e606446074778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606446074778 : Closed e606446074778 ∧ code e606446074778 = 9402539096986 := by decide
theorem cert_e606446074778 : check e606446074778 [[.under]] .sourceHead = true := by decide
def e606446075094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e606446075094 : Closed e606446075094 ∧ code e606446075094 = 9402539097302 := by decide
theorem cert_e606446075094 : check e606446075094 [[.under]] .sourceHead = true := by decide
def e606446075098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e606446075098 : Closed e606446075098 ∧ code e606446075098 = 9402539097306 := by decide
theorem cert_e606446075098 : check e606446075098 [[.under]] .sourceHead = true := by decide
def e606446075114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e606446075114 : Closed e606446075114 ∧ code e606446075114 = 9402539097322 := by decide
theorem cert_e606446075114 : check e606446075114 [[.under]] .sourceHead = true := by decide
def e606446075190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606446075190 : Closed e606446075190 ∧ code e606446075190 = 9402539097398 := by decide
theorem cert_e606446075190 : check e606446075190 [[.under]] .sourceHead = true := by decide
def e606446075194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606446075194 : Closed e606446075194 ∧ code e606446075194 = 9402539097402 := by decide
theorem cert_e606446075194 : check e606446075194 [[.under]] .sourceHead = true := by decide
def e606446075290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606446075290 : Closed e606446075290 ∧ code e606446075290 = 9402539097498 := by decide
theorem cert_e606446075290 : check e606446075290 [[.under]] .sourceHead = true := by decide
def e606446078830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606446078830 : Closed e606446078830 ∧ code e606446078830 = 9402539101038 := by decide
theorem cert_e606446078830 : check e606446078830 [[.under]] .sourceHead = true := by decide
def e606446078838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606446078838 : Closed e606446078838 ∧ code e606446078838 = 9402539101046 := by decide
theorem cert_e606446078838 : check e606446078838 [[.under]] .sourceHead = true := by decide
def e606446078894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606446078894 : Closed e606446078894 ∧ code e606446078894 = 9402539101102 := by decide
theorem cert_e606446078894 : check e606446078894 [[.under]] .sourceHead = true := by decide
def e606446078906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606446078906 : Closed e606446078906 ∧ code e606446078906 = 9402539101114 := by decide
theorem cert_e606446078906 : check e606446078906 [[.under]] .sourceHead = true := by decide
def e606446078934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606446078934 : Closed e606446078934 ∧ code e606446078934 = 9402539101142 := by decide
theorem cert_e606446078934 : check e606446078934 [[.under]] .sourceHead = true := by decide
def e606446078938 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606446078938 : Closed e606446078938 ∧ code e606446078938 = 9402539101146 := by decide
theorem cert_e606446078938 : check e606446078938 [[.under]] .sourceHead = true := by decide
def e606446079214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606446079214 : Closed e606446079214 ∧ code e606446079214 = 9402539101422 := by decide
theorem cert_e606446079214 : check e606446079214 [[.under]] .sourceHead = true := by decide
def e606446079222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606446079222 : Closed e606446079222 ∧ code e606446079222 = 9402539101430 := by decide
theorem cert_e606446079222 : check e606446079222 [[.under]] .sourceHead = true := by decide
def e606446079598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606446079598 : Closed e606446079598 ∧ code e606446079598 = 9402539101806 := by decide
theorem cert_e606446079598 : check e606446079598 [[.under]] .sourceHead = true := by decide
def e606446079610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606446079610 : Closed e606446079610 ∧ code e606446079610 = 9402539101818 := by decide
theorem cert_e606446079610 : check e606446079610 [[.under]] .sourceHead = true := by decide
def e606446079798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606446079798 : Closed e606446079798 ∧ code e606446079798 = 9402539102006 := by decide
theorem cert_e606446079798 : check e606446079798 [[.under]] .sourceHead = true := by decide
def e606446079802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606446079802 : Closed e606446079802 ∧ code e606446079802 = 9402539102010 := by decide
theorem cert_e606446079802 : check e606446079802 [[.under]] .sourceHead = true := by decide
def e606446085550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e606446085550 : Closed e606446085550 ∧ code e606446085550 = 9402539107758 := by decide
theorem cert_e606446085550 : check e606446085550 [[.under]] .sourceHead = true := by decide
def e606446085562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e606446085562 : Closed e606446085562 ∧ code e606446085562 = 9402539107770 := by decide
theorem cert_e606446085562 : check e606446085562 [[.under]] .sourceHead = true := by decide
def e606446085610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e606446085610 : Closed e606446085610 ∧ code e606446085610 = 9402539107818 := by decide
theorem cert_e606446085610 : check e606446085610 [[.under]] .sourceHead = true := by decide
def e606446085742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606446085742 : Closed e606446085742 ∧ code e606446085742 = 9402539107950 := by decide
theorem cert_e606446085742 : check e606446085742 [[.under]] .sourceHead = true := by decide
def e606446085754 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606446085754 : Closed e606446085754 ∧ code e606446085754 = 9402539107962 := by decide
theorem cert_e606446085754 : check e606446085754 [[.under]] .sourceHead = true := by decide
def e606446086042 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606446086042 : Closed e606446086042 ∧ code e606446086042 = 9402539108250 := by decide
theorem cert_e606446086042 : check e606446086042 [[.under]] .sourceHead = true := by decide
def e606446088918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e606446088918 : Closed e606446088918 ∧ code e606446088918 = 9402539111126 := by decide
theorem cert_e606446088918 : check e606446088918 [[.under]] .sourceHead = true := by decide
def e606446088922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e606446088922 : Closed e606446088922 ∧ code e606446088922 = 9402539111130 := by decide
theorem cert_e606446088922 : check e606446088922 [[.under]] .sourceHead = true := by decide
def e606446088938 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e606446088938 : Closed e606446088938 ∧ code e606446088938 = 9402539111146 := by decide
theorem cert_e606446088938 : check e606446088938 [[.under]] .sourceHead = true := by decide
def e606446089014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606446089014 : Closed e606446089014 ∧ code e606446089014 = 9402539111222 := by decide
theorem cert_e606446089014 : check e606446089014 [[.under]] .sourceHead = true := by decide
def e606446089018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606446089018 : Closed e606446089018 ∧ code e606446089018 = 9402539111226 := by decide
theorem cert_e606446089018 : check e606446089018 [[.under]] .sourceHead = true := by decide
def e606446089114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606446089114 : Closed e606446089114 ∧ code e606446089114 = 9402539111322 := by decide
theorem cert_e606446089114 : check e606446089114 [[.under]] .sourceHead = true := by decide
def e606446226286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606446226286 : Closed e606446226286 ∧ code e606446226286 = 9402539248494 := by decide
theorem cert_e606446226286 : check e606446226286 [[.under]] .sourceHead = true := by decide
def e606446226294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606446226294 : Closed e606446226294 ∧ code e606446226294 = 9402539248502 := by decide
theorem cert_e606446226294 : check e606446226294 [[.under]] .sourceHead = true := by decide
def e606446226350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606446226350 : Closed e606446226350 ∧ code e606446226350 = 9402539248558 := by decide
theorem cert_e606446226350 : check e606446226350 [[.under]] .sourceHead = true := by decide
def e606446226362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606446226362 : Closed e606446226362 ∧ code e606446226362 = 9402539248570 := by decide
theorem cert_e606446226362 : check e606446226362 [[.under]] .sourceHead = true := by decide
def e606446226390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606446226390 : Closed e606446226390 ∧ code e606446226390 = 9402539248598 := by decide
theorem cert_e606446226390 : check e606446226390 [[.under]] .sourceHead = true := by decide
def e606446226394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606446226394 : Closed e606446226394 ∧ code e606446226394 = 9402539248602 := by decide
theorem cert_e606446226394 : check e606446226394 [[.under]] .sourceHead = true := by decide
def e606446226670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606446226670 : Closed e606446226670 ∧ code e606446226670 = 9402539248878 := by decide
theorem cert_e606446226670 : check e606446226670 [[.under]] .sourceHead = true := by decide
def e606446226678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606446226678 : Closed e606446226678 ∧ code e606446226678 = 9402539248886 := by decide
theorem cert_e606446226678 : check e606446226678 [[.under]] .sourceHead = true := by decide
def e606446227054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606446227054 : Closed e606446227054 ∧ code e606446227054 = 9402539249262 := by decide
theorem cert_e606446227054 : check e606446227054 [[.under]] .sourceHead = true := by decide
def e606446227066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606446227066 : Closed e606446227066 ∧ code e606446227066 = 9402539249274 := by decide
theorem cert_e606446227066 : check e606446227066 [[.under]] .sourceHead = true := by decide
def e606446227254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606446227254 : Closed e606446227254 ∧ code e606446227254 = 9402539249462 := by decide
theorem cert_e606446227254 : check e606446227254 [[.under]] .sourceHead = true := by decide
def e606446227258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606446227258 : Closed e606446227258 ∧ code e606446227258 = 9402539249466 := by decide
theorem cert_e606446227258 : check e606446227258 [[.under]] .sourceHead = true := by decide
def e606446816110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606446816110 : Closed e606446816110 ∧ code e606446816110 = 9402539838318 := by decide
theorem cert_e606446816110 : check e606446816110 [[.under]] .sourceHead = true := by decide
def e606446816118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606446816118 : Closed e606446816118 ∧ code e606446816118 = 9402539838326 := by decide
theorem cert_e606446816118 : check e606446816118 [[.under]] .sourceHead = true := by decide
def e606446816174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606446816174 : Closed e606446816174 ∧ code e606446816174 = 9402539838382 := by decide
theorem cert_e606446816174 : check e606446816174 [[.under]] .sourceHead = true := by decide
def e606446816186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606446816186 : Closed e606446816186 ∧ code e606446816186 = 9402539838394 := by decide
theorem cert_e606446816186 : check e606446816186 [[.under]] .sourceHead = true := by decide
def e606446816214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606446816214 : Closed e606446816214 ∧ code e606446816214 = 9402539838422 := by decide
theorem cert_e606446816214 : check e606446816214 [[.under]] .sourceHead = true := by decide
def e606446816218 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606446816218 : Closed e606446816218 ∧ code e606446816218 = 9402539838426 := by decide
theorem cert_e606446816218 : check e606446816218 [[.under]] .sourceHead = true := by decide
def e606446816494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606446816494 : Closed e606446816494 ∧ code e606446816494 = 9402539838702 := by decide
theorem cert_e606446816494 : check e606446816494 [[.under]] .sourceHead = true := by decide
def e606446816502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606446816502 : Closed e606446816502 ∧ code e606446816502 = 9402539838710 := by decide
theorem cert_e606446816502 : check e606446816502 [[.under]] .sourceHead = true := by decide
def e606446816878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606446816878 : Closed e606446816878 ∧ code e606446816878 = 9402539839086 := by decide
theorem cert_e606446816878 : check e606446816878 [[.under]] .sourceHead = true := by decide
def e606446816890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606446816890 : Closed e606446816890 ∧ code e606446816890 = 9402539839098 := by decide
theorem cert_e606446816890 : check e606446816890 [[.under]] .sourceHead = true := by decide
def e606446817078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606446817078 : Closed e606446817078 ∧ code e606446817078 = 9402539839286 := by decide
theorem cert_e606446817078 : check e606446817078 [[.under]] .sourceHead = true := by decide
def e606446817082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606446817082 : Closed e606446817082 ∧ code e606446817082 = 9402539839290 := by decide
theorem cert_e606446817082 : check e606446817082 [[.under]] .sourceHead = true := by decide
def e611501961414 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611501961414 : Closed e611501961414 ∧ code e611501961414 = 9407594983622 := by decide
theorem cert_e611501961414 : check e611501961414 [[.under]] .width = true := by decide
def e611501977798 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611501977798 : Closed e611501977798 ∧ code e611501977798 = 9407595000006 := by decide
theorem cert_e611501977798 : check e611501977798 [[.under]] .width = true := by decide
def e611502092486 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611502092486 : Closed e611502092486 ∧ code e611502092486 = 9407595114694 := by decide
theorem cert_e611502092486 : check e611502092486 [[.under]] .width = true := by decide
def e611502117062 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611502117062 : Closed e611502117062 ∧ code e611502117062 = 9407595139270 := by decide
theorem cert_e611502117062 : check e611502117062 [[.under]] .width = true := by decide
def e611502174406 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611502174406 : Closed e611502174406 ∧ code e611502174406 = 9407595196614 := by decide
theorem cert_e611502174406 : check e611502174406 [[.under]] .width = true := by decide
def e611502182598 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611502182598 : Closed e611502182598 ∧ code e611502182598 = 9407595204806 := by decide
theorem cert_e611502182598 : check e611502182598 [[.under]] .width = true := by decide
def e611502747846 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611502747846 : Closed e611502747846 ∧ code e611502747846 = 9407595770054 := by decide
theorem cert_e611502747846 : check e611502747846 [[.under]] .width = true := by decide
def e611502764230 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611502764230 : Closed e611502764230 ∧ code e611502764230 = 9407595786438 := by decide
theorem cert_e611502764230 : check e611502764230 [[.under]] .width = true := by decide
def e611503534278 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611503534278 : Closed e611503534278 ∧ code e611503534278 = 9407596556486 := by decide
theorem cert_e611503534278 : check e611503534278 [[.under]] .width = true := by decide
def e611503558854 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611503558854 : Closed e611503558854 ∧ code e611503558854 = 9407596581062 := by decide
theorem cert_e611503558854 : check e611503558854 [[.under]] .width = true := by decide
def e611503943878 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611503943878 : Closed e611503943878 ∧ code e611503943878 = 9407596966086 := by decide
theorem cert_e611503943878 : check e611503943878 [[.under]] .width = true := by decide
def e611503952070 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e611503952070 : Closed e611503952070 ∧ code e611503952070 = 9407596974278 := by decide
theorem cert_e611503952070 : check e611503952070 [[.under]] .width = true := by decide
def e611546344814 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e611546344814 : Closed e611546344814 ∧ code e611546344814 = 9407639367022 := by decide
theorem cert_e611546344814 : check e611546344814 [[.under]] .sourceHead = true := by decide
def e611546344822 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e611546344822 : Closed e611546344822 ∧ code e611546344822 = 9407639367030 := by decide
theorem cert_e611546344822 : check e611546344822 [[.under]] .sourceHead = true := by decide
def e611546344878 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e611546344878 : Closed e611546344878 ∧ code e611546344878 = 9407639367086 := by decide
theorem cert_e611546344878 : check e611546344878 [[.under]] .sourceHead = true := by decide
def e611546344890 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e611546344890 : Closed e611546344890 ∧ code e611546344890 = 9407639367098 := by decide
theorem cert_e611546344890 : check e611546344890 [[.under]] .sourceHead = true := by decide
def e611546344918 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e611546344918 : Closed e611546344918 ∧ code e611546344918 = 9407639367126 := by decide
theorem cert_e611546344918 : check e611546344918 [[.under]] .sourceHead = true := by decide
def e611546344922 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e611546344922 : Closed e611546344922 ∧ code e611546344922 = 9407639367130 := by decide
theorem cert_e611546344922 : check e611546344922 [[.under]] .sourceHead = true := by decide
def e611546345134 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e611546345134 : Closed e611546345134 ∧ code e611546345134 = 9407639367342 := by decide
theorem cert_e611546345134 : check e611546345134 [[.under]] .sourceHead = true := by decide
def e611546345146 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e611546345146 : Closed e611546345146 ∧ code e611546345146 = 9407639367354 := by decide
theorem cert_e611546345146 : check e611546345146 [[.under]] .sourceHead = true := by decide
def e611546345194 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e611546345194 : Closed e611546345194 ∧ code e611546345194 = 9407639367402 := by decide
theorem cert_e611546345194 : check e611546345194 [[.under]] .sourceHead = true := by decide
def e611546345302 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e611546345302 : Closed e611546345302 ∧ code e611546345302 = 9407639367510 := by decide
theorem cert_e611546345302 : check e611546345302 [[.under]] .sourceHead = true := by decide
def e611546345306 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e611546345306 : Closed e611546345306 ∧ code e611546345306 = 9407639367514 := by decide
theorem cert_e611546345306 : check e611546345306 [[.under]] .sourceHead = true := by decide
def e611546345322 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e611546345322 : Closed e611546345322 ∧ code e611546345322 = 9407639367530 := by decide
theorem cert_e611546345322 : check e611546345322 [[.under]] .sourceHead = true := by decide
def e611546346350 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e611546346350 : Closed e611546346350 ∧ code e611546346350 = 9407639368558 := by decide
theorem cert_e611546346350 : check e611546346350 [[.under]] .sourceHead = true := by decide
def e611546346358 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e611546346358 : Closed e611546346358 ∧ code e611546346358 = 9407639368566 := by decide
theorem cert_e611546346358 : check e611546346358 [[.under]] .sourceHead = true := by decide
def e611546346414 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e611546346414 : Closed e611546346414 ∧ code e611546346414 = 9407639368622 := by decide
theorem cert_e611546346414 : check e611546346414 [[.under]] .sourceHead = true := by decide
def e611546346426 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e611546346426 : Closed e611546346426 ∧ code e611546346426 = 9407639368634 := by decide
theorem cert_e611546346426 : check e611546346426 [[.under]] .sourceHead = true := by decide
def e611546346454 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e611546346454 : Closed e611546346454 ∧ code e611546346454 = 9407639368662 := by decide
theorem cert_e611546346454 : check e611546346454 [[.under]] .sourceHead = true := by decide
def e611546346458 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e611546346458 : Closed e611546346458 ∧ code e611546346458 = 9407639368666 := by decide
theorem cert_e611546346458 : check e611546346458 [[.under]] .sourceHead = true := by decide
def e611546346734 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e611546346734 : Closed e611546346734 ∧ code e611546346734 = 9407639368942 := by decide
theorem cert_e611546346734 : check e611546346734 [[.under]] .sourceHead = true := by decide
def e611546346742 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e611546346742 : Closed e611546346742 ∧ code e611546346742 = 9407639368950 := by decide
theorem cert_e611546346742 : check e611546346742 [[.under]] .sourceHead = true := by decide
def e611546347118 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e611546347118 : Closed e611546347118 ∧ code e611546347118 = 9407639369326 := by decide
theorem cert_e611546347118 : check e611546347118 [[.under]] .sourceHead = true := by decide
def e611546347130 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e611546347130 : Closed e611546347130 ∧ code e611546347130 = 9407639369338 := by decide
theorem cert_e611546347130 : check e611546347130 [[.under]] .sourceHead = true := by decide
def e611546347318 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e611546347318 : Closed e611546347318 ∧ code e611546347318 = 9407639369526 := by decide
theorem cert_e611546347318 : check e611546347318 [[.under]] .sourceHead = true := by decide
def e611546347322 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e611546347322 : Closed e611546347322 ∧ code e611546347322 = 9407639369530 := by decide
theorem cert_e611546347322 : check e611546347322 [[.under]] .sourceHead = true := by decide
def e611546347950 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e611546347950 : Closed e611546347950 ∧ code e611546347950 = 9407639370158 := by decide
theorem cert_e611546347950 : check e611546347950 [[.under]] .sourceHead = true := by decide
def e611546347962 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e611546347962 : Closed e611546347962 ∧ code e611546347962 = 9407639370170 := by decide
theorem cert_e611546347962 : check e611546347962 [[.under]] .sourceHead = true := by decide
def e611546348010 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e611546348010 : Closed e611546348010 ∧ code e611546348010 = 9407639370218 := by decide
theorem cert_e611546348010 : check e611546348010 [[.under]] .sourceHead = true := by decide
def e611546348142 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e611546348142 : Closed e611546348142 ∧ code e611546348142 = 9407639370350 := by decide
theorem cert_e611546348142 : check e611546348142 [[.under]] .sourceHead = true := by decide
def e611546348154 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e611546348154 : Closed e611546348154 ∧ code e611546348154 = 9407639370362 := by decide
theorem cert_e611546348154 : check e611546348154 [[.under]] .sourceHead = true := by decide
def e611546348442 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e611546348442 : Closed e611546348442 ∧ code e611546348442 = 9407639370650 := by decide
theorem cert_e611546348442 : check e611546348442 [[.under]] .sourceHead = true := by decide
def e611546348758 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e611546348758 : Closed e611546348758 ∧ code e611546348758 = 9407639370966 := by decide
theorem cert_e611546348758 : check e611546348758 [[.under]] .sourceHead = true := by decide
def e611546348762 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e611546348762 : Closed e611546348762 ∧ code e611546348762 = 9407639370970 := by decide
theorem cert_e611546348762 : check e611546348762 [[.under]] .sourceHead = true := by decide
def e611546348778 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e611546348778 : Closed e611546348778 ∧ code e611546348778 = 9407639370986 := by decide
theorem cert_e611546348778 : check e611546348778 [[.under]] .sourceHead = true := by decide
def e611546348854 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e611546348854 : Closed e611546348854 ∧ code e611546348854 = 9407639371062 := by decide
theorem cert_e611546348854 : check e611546348854 [[.under]] .sourceHead = true := by decide
def e611546348858 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e611546348858 : Closed e611546348858 ∧ code e611546348858 = 9407639371066 := by decide
theorem cert_e611546348858 : check e611546348858 [[.under]] .sourceHead = true := by decide
def e611546348954 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e611546348954 : Closed e611546348954 ∧ code e611546348954 = 9407639371162 := by decide
theorem cert_e611546348954 : check e611546348954 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
