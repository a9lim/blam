import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411724826558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e2411724826558 : Closed e2411724826558 ∧ code e2411724826558 = 11207817848766 := by decide
theorem cert_e2411724826558 : check e2411724826558 [[],[],[]] .smaller = true := by decide
def e2411724826606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e2411724826606 : Closed e2411724826606 ∧ code e2411724826606 = 11207817848814 := by decide
theorem cert_e2411724826606 : check e2411724826606 [[],[],[]] .smaller = true := by decide
def e2411724831166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e2411724831166 : Closed e2411724831166 ∧ code e2411724831166 = 11207817853374 := by decide
theorem cert_e2411724831166 : check e2411724831166 [[],[],[]] .smaller = true := by decide
def e2411724831226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e2411724831226 : Closed e2411724831226 ∧ code e2411724831226 = 11207817853434 := by decide
theorem cert_e2411724831226 : check e2411724831226 [[],[],[]] .smaller = true := by decide
def e2411724832366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411724832366 : Closed e2411724832366 ∧ code e2411724832366 = 11207817854574 := by decide
theorem cert_e2411724832366 : check e2411724832366 [[],[],[]] .smaller = true := by decide
def e2411724832378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411724832378 : Closed e2411724832378 ∧ code e2411724832378 = 11207817854586 := by decide
theorem cert_e2411724832378 : check e2411724832378 [[],[],[]] .smaller = true := by decide
def e2411724888798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2411724888798 : Closed e2411724888798 ∧ code e2411724888798 = 11207817911006 := by decide
theorem cert_e2411724888798 : check e2411724888798 [[],[],[]] .smaller = true := by decide
def e2411724888822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2411724888822 : Closed e2411724888822 ∧ code e2411724888822 = 11207817911030 := by decide
theorem cert_e2411724888822 : check e2411724888822 [[],[],[]] .smaller = true := by decide
def e2411724888926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2411724888926 : Closed e2411724888926 ∧ code e2411724888926 = 11207817911134 := by decide
theorem cert_e2411724888926 : check e2411724888926 [[],[],[]] .smaller = true := by decide
def e2411724888942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e2411724888942 : Closed e2411724888942 ∧ code e2411724888942 = 11207817911150 := by decide
theorem cert_e2411724888942 : check e2411724888942 [[],[],[]] .smaller = true := by decide
def e2411724888950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e2411724888950 : Closed e2411724888950 ∧ code e2411724888950 = 11207817911158 := by decide
theorem cert_e2411724888950 : check e2411724888950 [[],[],[]] .smaller = true := by decide
def e2411724888954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2411724888954 : Closed e2411724888954 ∧ code e2411724888954 = 11207817911162 := by decide
theorem cert_e2411724888954 : check e2411724888954 [[],[],[]] .smaller = true := by decide
def e2411724889014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e2411724889014 : Closed e2411724889014 ∧ code e2411724889014 = 11207817911222 := by decide
theorem cert_e2411724889014 : check e2411724889014 [[],[],[]] .smaller = true := by decide
def e2411724889046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2411724889046 : Closed e2411724889046 ∧ code e2411724889046 = 11207817911254 := by decide
theorem cert_e2411724889046 : check e2411724889046 [[],[],[]] .smaller = true := by decide
def e2411724889050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2411724889050 : Closed e2411724889050 ∧ code e2411724889050 = 11207817911258 := by decide
theorem cert_e2411724889050 : check e2411724889050 [[],[],[]] .smaller = true := by decide
def e2411724889438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2411724889438 : Closed e2411724889438 ∧ code e2411724889438 = 11207817911646 := by decide
theorem cert_e2411724889438 : check e2411724889438 [[],[],[]] .smaller = true := by decide
def e2411724889454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2411724889454 : Closed e2411724889454 ∧ code e2411724889454 = 11207817911662 := by decide
theorem cert_e2411724889454 : check e2411724889454 [[],[],[]] .smaller = true := by decide
def e2411724889462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2411724889462 : Closed e2411724889462 ∧ code e2411724889462 = 11207817911670 := by decide
theorem cert_e2411724889462 : check e2411724889462 [[],[],[]] .smaller = true := by decide
def e2411724889466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2411724889466 : Closed e2411724889466 ∧ code e2411724889466 = 11207817911674 := by decide
theorem cert_e2411724889466 : check e2411724889466 [[],[],[]] .smaller = true := by decide
def e2411724889518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2411724889518 : Closed e2411724889518 ∧ code e2411724889518 = 11207817911726 := by decide
theorem cert_e2411724889518 : check e2411724889518 [[],[],[]] .smaller = true := by decide
def e2411724889530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2411724889530 : Closed e2411724889530 ∧ code e2411724889530 = 11207817911738 := by decide
theorem cert_e2411724889530 : check e2411724889530 [[],[],[]] .smaller = true := by decide
def e2411724889558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2411724889558 : Closed e2411724889558 ∧ code e2411724889558 = 11207817911766 := by decide
theorem cert_e2411724889558 : check e2411724889558 [[],[],[]] .smaller = true := by decide
def e2411724889562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2411724889562 : Closed e2411724889562 ∧ code e2411724889562 = 11207817911770 := by decide
theorem cert_e2411724889562 : check e2411724889562 [[],[],[]] .smaller = true := by decide
def e2411724889578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2411724889578 : Closed e2411724889578 ∧ code e2411724889578 = 11207817911786 := by decide
theorem cert_e2411724889578 : check e2411724889578 [[],[],[]] .smaller = true := by decide
def e2411724889782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2411724889782 : Closed e2411724889782 ∧ code e2411724889782 = 11207817911990 := by decide
theorem cert_e2411724889782 : check e2411724889782 [[],[],[]] .smaller = true := by decide
def e2411724889814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2411724889814 : Closed e2411724889814 ∧ code e2411724889814 = 11207817912022 := by decide
theorem cert_e2411724889814 : check e2411724889814 [[],[],[]] .smaller = true := by decide
def e2411724889818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2411724889818 : Closed e2411724889818 ∧ code e2411724889818 = 11207817912026 := by decide
theorem cert_e2411724889818 : check e2411724889818 [[],[],[]] .smaller = true := by decide
def e2411724889942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2411724889942 : Closed e2411724889942 ∧ code e2411724889942 = 11207817912150 := by decide
theorem cert_e2411724889942 : check e2411724889942 [[],[],[]] .smaller = true := by decide
def e2411724889946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2411724889946 : Closed e2411724889946 ∧ code e2411724889946 = 11207817912154 := by decide
theorem cert_e2411724889946 : check e2411724889946 [[],[],[]] .smaller = true := by decide
def e2411724889962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2411724889962 : Closed e2411724889962 ∧ code e2411724889962 = 11207817912170 := by decide
theorem cert_e2411724889962 : check e2411724889962 [[],[],[]] .smaller = true := by decide
def e2411724891102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e2411724891102 : Closed e2411724891102 ∧ code e2411724891102 = 11207817913310 := by decide
theorem cert_e2411724891102 : check e2411724891102 [[],[],[]] .smaller = true := by decide
def e2411724891118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e2411724891118 : Closed e2411724891118 ∧ code e2411724891118 = 11207817913326 := by decide
theorem cert_e2411724891118 : check e2411724891118 [[],[],[]] .smaller = true := by decide
def e2411724891870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2411724891870 : Closed e2411724891870 ∧ code e2411724891870 = 11207817914078 := by decide
theorem cert_e2411724891870 : check e2411724891870 [[],[],[]] .smaller = true := by decide
def e2411724891894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2411724891894 : Closed e2411724891894 ∧ code e2411724891894 = 11207817914102 := by decide
theorem cert_e2411724891894 : check e2411724891894 [[],[],[]] .smaller = true := by decide
def e2411724891998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2411724891998 : Closed e2411724891998 ∧ code e2411724891998 = 11207817914206 := by decide
theorem cert_e2411724891998 : check e2411724891998 [[],[],[]] .smaller = true := by decide
def e2411724892014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e2411724892014 : Closed e2411724892014 ∧ code e2411724892014 = 11207817914222 := by decide
theorem cert_e2411724892014 : check e2411724892014 [[],[],[]] .smaller = true := by decide
def e2411724892022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e2411724892022 : Closed e2411724892022 ∧ code e2411724892022 = 11207817914230 := by decide
theorem cert_e2411724892022 : check e2411724892022 [[],[],[]] .smaller = true := by decide
def e2411724892026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2411724892026 : Closed e2411724892026 ∧ code e2411724892026 = 11207817914234 := by decide
theorem cert_e2411724892026 : check e2411724892026 [[],[],[]] .smaller = true := by decide
def e2411724892086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e2411724892086 : Closed e2411724892086 ∧ code e2411724892086 = 11207817914294 := by decide
theorem cert_e2411724892086 : check e2411724892086 [[],[],[]] .smaller = true := by decide
def e2411724892118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2411724892118 : Closed e2411724892118 ∧ code e2411724892118 = 11207817914326 := by decide
theorem cert_e2411724892118 : check e2411724892118 [[],[],[]] .smaller = true := by decide
def e2411724892122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2411724892122 : Closed e2411724892122 ∧ code e2411724892122 = 11207817914330 := by decide
theorem cert_e2411724892122 : check e2411724892122 [[],[],[]] .smaller = true := by decide
def e2411724892638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411724892638 : Closed e2411724892638 ∧ code e2411724892638 = 11207817914846 := by decide
theorem cert_e2411724892638 : check e2411724892638 [[],[],[]] .smaller = true := by decide
def e2411724892662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411724892662 : Closed e2411724892662 ∧ code e2411724892662 = 11207817914870 := by decide
theorem cert_e2411724892662 : check e2411724892662 [[],[],[]] .smaller = true := by decide
def e2411724893406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411724893406 : Closed e2411724893406 ∧ code e2411724893406 = 11207817915614 := by decide
theorem cert_e2411724893406 : check e2411724893406 [[],[],[]] .smaller = true := by decide
def e2411724893422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411724893422 : Closed e2411724893422 ∧ code e2411724893422 = 11207817915630 := by decide
theorem cert_e2411724893422 : check e2411724893422 [[],[],[]] .smaller = true := by decide
def e2411724893430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411724893430 : Closed e2411724893430 ∧ code e2411724893430 = 11207817915638 := by decide
theorem cert_e2411724893430 : check e2411724893430 [[],[],[]] .smaller = true := by decide
def e2411724893434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411724893434 : Closed e2411724893434 ∧ code e2411724893434 = 11207817915642 := by decide
theorem cert_e2411724893434 : check e2411724893434 [[],[],[]] .smaller = true := by decide
def e2411724893758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e2411724893758 : Closed e2411724893758 ∧ code e2411724893758 = 11207817915966 := by decide
theorem cert_e2411724893758 : check e2411724893758 [[],[],[]] .smaller = true := by decide
def e2411724893814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411724893814 : Closed e2411724893814 ∧ code e2411724893814 = 11207817916022 := by decide
theorem cert_e2411724893814 : check e2411724893814 [[],[],[]] .smaller = true := by decide
def e2411724893982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e2411724893982 : Closed e2411724893982 ∧ code e2411724893982 = 11207817916190 := by decide
theorem cert_e2411724893982 : check e2411724893982 [[],[],[]] .smaller = true := by decide
def e2411724894006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411724894006 : Closed e2411724894006 ∧ code e2411724894006 = 11207817916214 := by decide
theorem cert_e2411724894006 : check e2411724894006 [[],[],[]] .smaller = true := by decide
def e2411724894010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411724894010 : Closed e2411724894010 ∧ code e2411724894010 = 11207817916218 := by decide
theorem cert_e2411724894010 : check e2411724894010 [[],[],[]] .smaller = true := by decide
def e2411724895070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2411724895070 : Closed e2411724895070 ∧ code e2411724895070 = 11207817917278 := by decide
theorem cert_e2411724895070 : check e2411724895070 [[],[],[]] .smaller = true := by decide
def e2411724895086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2411724895086 : Closed e2411724895086 ∧ code e2411724895086 = 11207817917294 := by decide
theorem cert_e2411724895086 : check e2411724895086 [[],[],[]] .smaller = true := by decide
def e2411724895094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2411724895094 : Closed e2411724895094 ∧ code e2411724895094 = 11207817917302 := by decide
theorem cert_e2411724895094 : check e2411724895094 [[],[],[]] .smaller = true := by decide
def e2411724895098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2411724895098 : Closed e2411724895098 ∧ code e2411724895098 = 11207817917306 := by decide
theorem cert_e2411724895098 : check e2411724895098 [[],[],[]] .smaller = true := by decide
def e2411724895150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2411724895150 : Closed e2411724895150 ∧ code e2411724895150 = 11207817917358 := by decide
theorem cert_e2411724895150 : check e2411724895150 [[],[],[]] .smaller = true := by decide
def e2411724895162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2411724895162 : Closed e2411724895162 ∧ code e2411724895162 = 11207817917370 := by decide
theorem cert_e2411724895162 : check e2411724895162 [[],[],[]] .smaller = true := by decide
def e2411724895190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2411724895190 : Closed e2411724895190 ∧ code e2411724895190 = 11207817917398 := by decide
theorem cert_e2411724895190 : check e2411724895190 [[],[],[]] .smaller = true := by decide
def e2411724895194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2411724895194 : Closed e2411724895194 ∧ code e2411724895194 = 11207817917402 := by decide
theorem cert_e2411724895194 : check e2411724895194 [[],[],[]] .smaller = true := by decide
def e2411724895210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2411724895210 : Closed e2411724895210 ∧ code e2411724895210 = 11207817917418 := by decide
theorem cert_e2411724895210 : check e2411724895210 [[],[],[]] .smaller = true := by decide
def e2411724895454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411724895454 : Closed e2411724895454 ∧ code e2411724895454 = 11207817917662 := by decide
theorem cert_e2411724895454 : check e2411724895454 [[],[],[]] .smaller = true := by decide
def e2411724895470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411724895470 : Closed e2411724895470 ∧ code e2411724895470 = 11207817917678 := by decide
theorem cert_e2411724895470 : check e2411724895470 [[],[],[]] .smaller = true := by decide
def e2411724895478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411724895478 : Closed e2411724895478 ∧ code e2411724895478 = 11207817917686 := by decide
theorem cert_e2411724895478 : check e2411724895478 [[],[],[]] .smaller = true := by decide
def e2411724895482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411724895482 : Closed e2411724895482 ∧ code e2411724895482 = 11207817917690 := by decide
theorem cert_e2411724895482 : check e2411724895482 [[],[],[]] .smaller = true := by decide
def e2411724895854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411724895854 : Closed e2411724895854 ∧ code e2411724895854 = 11207817918062 := by decide
theorem cert_e2411724895854 : check e2411724895854 [[],[],[]] .smaller = true := by decide
def e2411724895866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411724895866 : Closed e2411724895866 ∧ code e2411724895866 = 11207817918074 := by decide
theorem cert_e2411724895866 : check e2411724895866 [[],[],[]] .smaller = true := by decide
def e2411724896054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411724896054 : Closed e2411724896054 ∧ code e2411724896054 = 11207817918262 := by decide
theorem cert_e2411724896054 : check e2411724896054 [[],[],[]] .smaller = true := by decide
def e2411724896058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411724896058 : Closed e2411724896058 ∧ code e2411724896058 = 11207817918266 := by decide
theorem cert_e2411724896058 : check e2411724896058 [[],[],[]] .smaller = true := by decide
def e2411724896154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411724896154 : Closed e2411724896154 ∧ code e2411724896154 = 11207817918362 := by decide
theorem cert_e2411724896154 : check e2411724896154 [[],[],[]] .smaller = true := by decide
def e2411724896478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2411724896478 : Closed e2411724896478 ∧ code e2411724896478 = 11207817918686 := by decide
theorem cert_e2411724896478 : check e2411724896478 [[],[],[]] .smaller = true := by decide
def e2411724896506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2411724896506 : Closed e2411724896506 ∧ code e2411724896506 = 11207817918714 := by decide
theorem cert_e2411724896506 : check e2411724896506 [[],[],[]] .smaller = true := by decide
def e2411724896694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2411724896694 : Closed e2411724896694 ∧ code e2411724896694 = 11207817918902 := by decide
theorem cert_e2411724896694 : check e2411724896694 [[],[],[]] .smaller = true := by decide
def e2411724896726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2411724896726 : Closed e2411724896726 ∧ code e2411724896726 = 11207817918934 := by decide
theorem cert_e2411724896726 : check e2411724896726 [[],[],[]] .smaller = true := by decide
def e2411724896730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2411724896730 : Closed e2411724896730 ∧ code e2411724896730 = 11207817918938 := by decide
theorem cert_e2411724896730 : check e2411724896730 [[],[],[]] .smaller = true := by decide
def e2411724896830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2411724896830 : Closed e2411724896830 ∧ code e2411724896830 = 11207817919038 := by decide
theorem cert_e2411724896830 : check e2411724896830 [[],[],[]] .smaller = true := by decide
def e2411724896886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411724896886 : Closed e2411724896886 ∧ code e2411724896886 = 11207817919094 := by decide
theorem cert_e2411724896886 : check e2411724896886 [[],[],[]] .smaller = true := by decide
def e2411724897078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411724897078 : Closed e2411724897078 ∧ code e2411724897078 = 11207817919286 := by decide
theorem cert_e2411724897078 : check e2411724897078 [[],[],[]] .smaller = true := by decide
def e2411724897082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411724897082 : Closed e2411724897082 ∧ code e2411724897082 = 11207817919290 := by decide
theorem cert_e2411724897082 : check e2411724897082 [[],[],[]] .smaller = true := by decide
def e2411724897222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2411724897222 : Closed e2411724897222 ∧ code e2411724897222 = 11207817919430 := by decide
theorem cert_e2411724897222 : check e2411724897222 [[],[],[]] .smaller = true := by decide
def e2411724897390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411724897390 : Closed e2411724897390 ∧ code e2411724897390 = 11207817919598 := by decide
theorem cert_e2411724897390 : check e2411724897390 [[],[],[]] .smaller = true := by decide
def e2411724897402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411724897402 : Closed e2411724897402 ∧ code e2411724897402 = 11207817919610 := by decide
theorem cert_e2411724897402 : check e2411724897402 [[],[],[]] .smaller = true := by decide
def e2411724897494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2411724897494 : Closed e2411724897494 ∧ code e2411724897494 = 11207817919702 := by decide
theorem cert_e2411724897494 : check e2411724897494 [[],[],[]] .smaller = true := by decide
def e2411724897498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2411724897498 : Closed e2411724897498 ∧ code e2411724897498 = 11207817919706 := by decide
theorem cert_e2411724897498 : check e2411724897498 [[],[],[]] .smaller = true := by decide
def e2411724897514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2411724897514 : Closed e2411724897514 ∧ code e2411724897514 = 11207817919722 := by decide
theorem cert_e2411724897514 : check e2411724897514 [[],[],[]] .smaller = true := by decide
def e2411724897566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411724897566 : Closed e2411724897566 ∧ code e2411724897566 = 11207817919774 := by decide
theorem cert_e2411724897566 : check e2411724897566 [[],[],[]] .smaller = true := by decide
def e2411724897590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411724897590 : Closed e2411724897590 ∧ code e2411724897590 = 11207817919798 := by decide
theorem cert_e2411724897590 : check e2411724897590 [[],[],[]] .smaller = true := by decide
def e2411724897594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411724897594 : Closed e2411724897594 ∧ code e2411724897594 = 11207817919802 := by decide
theorem cert_e2411724897594 : check e2411724897594 [[],[],[]] .smaller = true := by decide
def e2411724897690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411724897690 : Closed e2411724897690 ∧ code e2411724897690 = 11207817919898 := by decide
theorem cert_e2411724897690 : check e2411724897690 [[],[],[]] .smaller = true := by decide
def e2411724897734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411724897734 : Closed e2411724897734 ∧ code e2411724897734 = 11207817919942 := by decide
theorem cert_e2411724897734 : check e2411724897734 [[],[],[]] .smaller = true := by decide
def e2411724900286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2411724900286 : Closed e2411724900286 ∧ code e2411724900286 = 11207817922494 := by decide
theorem cert_e2411724900286 : check e2411724900286 [[],[],[]] .smaller = true := by decide
def e2411724900334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2411724900334 : Closed e2411724900334 ∧ code e2411724900334 = 11207817922542 := by decide
theorem cert_e2411724900334 : check e2411724900334 [[],[],[]] .smaller = true := by decide
def e2411724904158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411724904158 : Closed e2411724904158 ∧ code e2411724904158 = 11207817926366 := by decide
theorem cert_e2411724904158 : check e2411724904158 [[],[],[]] .smaller = true := by decide
def e2411724904182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411724904182 : Closed e2411724904182 ∧ code e2411724904182 = 11207817926390 := by decide
theorem cert_e2411724904182 : check e2411724904182 [[],[],[]] .smaller = true := by decide
def e2411724904286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411724904286 : Closed e2411724904286 ∧ code e2411724904286 = 11207817926494 := by decide
theorem cert_e2411724904286 : check e2411724904286 [[],[],[]] .smaller = true := by decide
def e2411724904302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e2411724904302 : Closed e2411724904302 ∧ code e2411724904302 = 11207817926510 := by decide
theorem cert_e2411724904302 : check e2411724904302 [[],[],[]] .smaller = true := by decide
def e2411724904310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e2411724904310 : Closed e2411724904310 ∧ code e2411724904310 = 11207817926518 := by decide
theorem cert_e2411724904310 : check e2411724904310 [[],[],[]] .smaller = true := by decide
def e2411724904314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411724904314 : Closed e2411724904314 ∧ code e2411724904314 = 11207817926522 := by decide
theorem cert_e2411724904314 : check e2411724904314 [[],[],[]] .smaller = true := by decide
def e2411724904374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e2411724904374 : Closed e2411724904374 ∧ code e2411724904374 = 11207817926582 := by decide
theorem cert_e2411724904374 : check e2411724904374 [[],[],[]] .smaller = true := by decide
def e2411724904406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411724904406 : Closed e2411724904406 ∧ code e2411724904406 = 11207817926614 := by decide
theorem cert_e2411724904406 : check e2411724904406 [[],[],[]] .smaller = true := by decide
def e2411724904410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411724904410 : Closed e2411724904410 ∧ code e2411724904410 = 11207817926618 := by decide
theorem cert_e2411724904410 : check e2411724904410 [[],[],[]] .smaller = true := by decide
def e2411724904926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411724904926 : Closed e2411724904926 ∧ code e2411724904926 = 11207817927134 := by decide
theorem cert_e2411724904926 : check e2411724904926 [[],[],[]] .smaller = true := by decide
def e2411724904950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411724904950 : Closed e2411724904950 ∧ code e2411724904950 = 11207817927158 := by decide
theorem cert_e2411724904950 : check e2411724904950 [[],[],[]] .smaller = true := by decide
def e2411724905694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411724905694 : Closed e2411724905694 ∧ code e2411724905694 = 11207817927902 := by decide
theorem cert_e2411724905694 : check e2411724905694 [[],[],[]] .smaller = true := by decide
def e2411724905710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411724905710 : Closed e2411724905710 ∧ code e2411724905710 = 11207817927918 := by decide
theorem cert_e2411724905710 : check e2411724905710 [[],[],[]] .smaller = true := by decide
def e2411724905718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411724905718 : Closed e2411724905718 ∧ code e2411724905718 = 11207817927926 := by decide
theorem cert_e2411724905718 : check e2411724905718 [[],[],[]] .smaller = true := by decide
def e2411724905722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411724905722 : Closed e2411724905722 ∧ code e2411724905722 = 11207817927930 := by decide
theorem cert_e2411724905722 : check e2411724905722 [[],[],[]] .smaller = true := by decide
def e2411724906046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2411724906046 : Closed e2411724906046 ∧ code e2411724906046 = 11207817928254 := by decide
theorem cert_e2411724906046 : check e2411724906046 [[],[],[]] .smaller = true := by decide
def e2411724906102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411724906102 : Closed e2411724906102 ∧ code e2411724906102 = 11207817928310 := by decide
theorem cert_e2411724906102 : check e2411724906102 [[],[],[]] .smaller = true := by decide
def e2411724906270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2411724906270 : Closed e2411724906270 ∧ code e2411724906270 = 11207817928478 := by decide
theorem cert_e2411724906270 : check e2411724906270 [[],[],[]] .smaller = true := by decide
def e2411724906294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411724906294 : Closed e2411724906294 ∧ code e2411724906294 = 11207817928502 := by decide
theorem cert_e2411724906294 : check e2411724906294 [[],[],[]] .smaller = true := by decide
def e2411724906298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411724906298 : Closed e2411724906298 ∧ code e2411724906298 = 11207817928506 := by decide
theorem cert_e2411724906298 : check e2411724906298 [[],[],[]] .smaller = true := by decide
def e2411724915646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2411724915646 : Closed e2411724915646 ∧ code e2411724915646 = 11207817937854 := by decide
theorem cert_e2411724915646 : check e2411724915646 [[],[],[]] .smaller = true := by decide
def e2411724915702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2411724915702 : Closed e2411724915702 ∧ code e2411724915702 = 11207817937910 := by decide
theorem cert_e2411724915702 : check e2411724915702 [[],[],[]] .smaller = true := by decide
def e2411724917598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2411724917598 : Closed e2411724917598 ∧ code e2411724917598 = 11207817939806 := by decide
theorem cert_e2411724917598 : check e2411724917598 [[],[],[]] .smaller = true := by decide
def e2411724917614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411724917614 : Closed e2411724917614 ∧ code e2411724917614 = 11207817939822 := by decide
theorem cert_e2411724917614 : check e2411724917614 [[],[],[]] .smaller = true := by decide
def e2411724917622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411724917622 : Closed e2411724917622 ∧ code e2411724917622 = 11207817939830 := by decide
theorem cert_e2411724917622 : check e2411724917622 [[],[],[]] .smaller = true := by decide
def e2411724917626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2411724917626 : Closed e2411724917626 ∧ code e2411724917626 = 11207817939834 := by decide
theorem cert_e2411724917626 : check e2411724917626 [[],[],[]] .smaller = true := by decide
def e2411724917678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411724917678 : Closed e2411724917678 ∧ code e2411724917678 = 11207817939886 := by decide
theorem cert_e2411724917678 : check e2411724917678 [[],[],[]] .smaller = true := by decide
def e2411724917690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411724917690 : Closed e2411724917690 ∧ code e2411724917690 = 11207817939898 := by decide
theorem cert_e2411724917690 : check e2411724917690 [[],[],[]] .smaller = true := by decide
def e2411724917718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411724917718 : Closed e2411724917718 ∧ code e2411724917718 = 11207817939926 := by decide
theorem cert_e2411724917718 : check e2411724917718 [[],[],[]] .smaller = true := by decide
def e2411724917722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411724917722 : Closed e2411724917722 ∧ code e2411724917722 = 11207817939930 := by decide
theorem cert_e2411724917722 : check e2411724917722 [[],[],[]] .smaller = true := by decide
def e2411724917738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2411724917738 : Closed e2411724917738 ∧ code e2411724917738 = 11207817939946 := by decide
theorem cert_e2411724917738 : check e2411724917738 [[],[],[]] .smaller = true := by decide
def e2411724917982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411724917982 : Closed e2411724917982 ∧ code e2411724917982 = 11207817940190 := by decide
theorem cert_e2411724917982 : check e2411724917982 [[],[],[]] .smaller = true := by decide
def e2411724917998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411724917998 : Closed e2411724917998 ∧ code e2411724917998 = 11207817940206 := by decide
theorem cert_e2411724917998 : check e2411724917998 [[],[],[]] .smaller = true := by decide
def e2411724918006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411724918006 : Closed e2411724918006 ∧ code e2411724918006 = 11207817940214 := by decide
theorem cert_e2411724918006 : check e2411724918006 [[],[],[]] .smaller = true := by decide
def e2411724918010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411724918010 : Closed e2411724918010 ∧ code e2411724918010 = 11207817940218 := by decide
theorem cert_e2411724918010 : check e2411724918010 [[],[],[]] .smaller = true := by decide
def e2411724918382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411724918382 : Closed e2411724918382 ∧ code e2411724918382 = 11207817940590 := by decide
theorem cert_e2411724918382 : check e2411724918382 [[],[],[]] .smaller = true := by decide
def e2411724918394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411724918394 : Closed e2411724918394 ∧ code e2411724918394 = 11207817940602 := by decide
theorem cert_e2411724918394 : check e2411724918394 [[],[],[]] .smaller = true := by decide
def e2411724918582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411724918582 : Closed e2411724918582 ∧ code e2411724918582 = 11207817940790 := by decide
theorem cert_e2411724918582 : check e2411724918582 [[],[],[]] .smaller = true := by decide
def e2411724918586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411724918586 : Closed e2411724918586 ∧ code e2411724918586 = 11207817940794 := by decide
theorem cert_e2411724918586 : check e2411724918586 [[],[],[]] .smaller = true := by decide
def e2411724918682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411724918682 : Closed e2411724918682 ∧ code e2411724918682 = 11207817940890 := by decide
theorem cert_e2411724918682 : check e2411724918682 [[],[],[]] .smaller = true := by decide
def e2411724924342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2411724924342 : Closed e2411724924342 ∧ code e2411724924342 = 11207817946550 := by decide
theorem cert_e2411724924342 : check e2411724924342 [[],[],[]] .smaller = true := by decide
def e2411724924374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2411724924374 : Closed e2411724924374 ∧ code e2411724924374 = 11207817946582 := by decide
theorem cert_e2411724924374 : check e2411724924374 [[],[],[]] .smaller = true := by decide
def e2411724924378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2411724924378 : Closed e2411724924378 ∧ code e2411724924378 = 11207817946586 := by decide
theorem cert_e2411724924378 : check e2411724924378 [[],[],[]] .smaller = true := by decide
def e2411724924478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2411724924478 : Closed e2411724924478 ∧ code e2411724924478 = 11207817946686 := by decide
theorem cert_e2411724924478 : check e2411724924478 [[],[],[]] .smaller = true := by decide
def e2411724924534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411724924534 : Closed e2411724924534 ∧ code e2411724924534 = 11207817946742 := by decide
theorem cert_e2411724924534 : check e2411724924534 [[],[],[]] .smaller = true := by decide
def e2411724924726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411724924726 : Closed e2411724924726 ∧ code e2411724924726 = 11207817946934 := by decide
theorem cert_e2411724924726 : check e2411724924726 [[],[],[]] .smaller = true := by decide
def e2411724924730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411724924730 : Closed e2411724924730 ∧ code e2411724924730 = 11207817946938 := by decide
theorem cert_e2411724924730 : check e2411724924730 [[],[],[]] .smaller = true := by decide
def e2411724924870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2411724924870 : Closed e2411724924870 ∧ code e2411724924870 = 11207817947078 := by decide
theorem cert_e2411724924870 : check e2411724924870 [[],[],[]] .smaller = true := by decide
def e2411724927214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2411724927214 : Closed e2411724927214 ∧ code e2411724927214 = 11207817949422 := by decide
theorem cert_e2411724927214 : check e2411724927214 [[],[],[]] .smaller = true := by decide
def e2411724927222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2411724927222 : Closed e2411724927222 ∧ code e2411724927222 = 11207817949430 := by decide
theorem cert_e2411724927222 : check e2411724927222 [[],[],[]] .smaller = true := by decide
def e2411724927702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411724927702 : Closed e2411724927702 ∧ code e2411724927702 = 11207817949910 := by decide
theorem cert_e2411724927702 : check e2411724927702 [[],[],[]] .smaller = true := by decide
def e2411724927706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411724927706 : Closed e2411724927706 ∧ code e2411724927706 = 11207817949914 := by decide
theorem cert_e2411724927706 : check e2411724927706 [[],[],[]] .smaller = true := by decide
def e2411724927722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411724927722 : Closed e2411724927722 ∧ code e2411724927722 = 11207817949930 := by decide
theorem cert_e2411724927722 : check e2411724927722 [[],[],[]] .smaller = true := by decide
def e2411724927774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411724927774 : Closed e2411724927774 ∧ code e2411724927774 = 11207817949982 := by decide
theorem cert_e2411724927774 : check e2411724927774 [[],[],[]] .smaller = true := by decide
def e2411724927798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411724927798 : Closed e2411724927798 ∧ code e2411724927798 = 11207817950006 := by decide
theorem cert_e2411724927798 : check e2411724927798 [[],[],[]] .smaller = true := by decide
def e2411724927802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411724927802 : Closed e2411724927802 ∧ code e2411724927802 = 11207817950010 := by decide
theorem cert_e2411724927802 : check e2411724927802 [[],[],[]] .smaller = true := by decide
def e2411724927898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411724927898 : Closed e2411724927898 ∧ code e2411724927898 = 11207817950106 := by decide
theorem cert_e2411724927898 : check e2411724927898 [[],[],[]] .smaller = true := by decide
def e2411724927942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411724927942 : Closed e2411724927942 ∧ code e2411724927942 = 11207817950150 := by decide
theorem cert_e2411724927942 : check e2411724927942 [[],[],[]] .smaller = true := by decide
def e2411725153134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2411725153134 : Closed e2411725153134 ∧ code e2411725153134 = 11207818175342 := by decide
theorem cert_e2411725153134 : check e2411725153134 [[],[],[]] .smaller = true := by decide
def e2411725153142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2411725153142 : Closed e2411725153142 ∧ code e2411725153142 = 11207818175350 := by decide
theorem cert_e2411725153142 : check e2411725153142 [[],[],[]] .smaller = true := by decide
def e2411725153198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2411725153198 : Closed e2411725153198 ∧ code e2411725153198 = 11207818175406 := by decide
theorem cert_e2411725153198 : check e2411725153198 [[],[],[]] .smaller = true := by decide
def e2411725153210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2411725153210 : Closed e2411725153210 ∧ code e2411725153210 = 11207818175418 := by decide
theorem cert_e2411725153210 : check e2411725153210 [[],[],[]] .smaller = true := by decide
def e2411725153238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2411725153238 : Closed e2411725153238 ∧ code e2411725153238 = 11207818175446 := by decide
theorem cert_e2411725153238 : check e2411725153238 [[],[],[]] .smaller = true := by decide
def e2411725153242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2411725153242 : Closed e2411725153242 ∧ code e2411725153242 = 11207818175450 := by decide
theorem cert_e2411725153242 : check e2411725153242 [[],[],[]] .smaller = true := by decide
def e2411725154542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2411725154542 : Closed e2411725154542 ∧ code e2411725154542 = 11207818176750 := by decide
theorem cert_e2411725154542 : check e2411725154542 [[],[],[]] .smaller = true := by decide
def e2411725154550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2411725154550 : Closed e2411725154550 ∧ code e2411725154550 = 11207818176758 := by decide
theorem cert_e2411725154550 : check e2411725154550 [[],[],[]] .smaller = true := by decide
def e2411725155102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2411725155102 : Closed e2411725155102 ∧ code e2411725155102 = 11207818177310 := by decide
theorem cert_e2411725155102 : check e2411725155102 [[],[],[]] .smaller = true := by decide
def e2411725155214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2411725155214 : Closed e2411725155214 ∧ code e2411725155214 = 11207818177422 := by decide
theorem cert_e2411725155214 : check e2411725155214 [[],[],[]] .smaller = true := by decide
end Blc.Floor43
