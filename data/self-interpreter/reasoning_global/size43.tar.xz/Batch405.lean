import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373038918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422373038918 : Closed e2422373038918 ∧ code e2422373038918 = 11218466061126 := by decide
theorem cert_e2422373038918 : check e2422373038918 [[],[]] .smaller = true := by decide
def e2422373038942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2422373038942 : Closed e2422373038942 ∧ code e2422373038942 = 11218466061150 := by decide
theorem cert_e2422373038942 : check e2422373038942 [[],[]] .three = true := by decide
def e2422373038970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2422373038970 : Closed e2422373038970 ∧ code e2422373038970 = 11218466061178 := by decide
theorem cert_e2422373038970 : check e2422373038970 [[],[]] .three = true := by decide
def e2422373038986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422373038986 : Closed e2422373038986 ∧ code e2422373038986 = 11218466061194 := by decide
theorem cert_e2422373038986 : check e2422373038986 [[],[]] .smaller = true := by decide
def e2422373039010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422373039010 : Closed e2422373039010 ∧ code e2422373039010 = 11218466061218 := by decide
theorem cert_e2422373039010 : check e2422373039010 [[],[]] .smaller = true := by decide
def e2422373039022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2422373039022 : Closed e2422373039022 ∧ code e2422373039022 = 11218466061230 := by decide
theorem cert_e2422373039022 : check e2422373039022 [[],[]] .smaller = true := by decide
def e2422373039034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2422373039034 : Closed e2422373039034 ∧ code e2422373039034 = 11218466061242 := by decide
theorem cert_e2422373039034 : check e2422373039034 [[],[]] .smaller = true := by decide
def e2422373039062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2422373039062 : Closed e2422373039062 ∧ code e2422373039062 = 11218466061270 := by decide
theorem cert_e2422373039062 : check e2422373039062 [[],[]] .three = true := by decide
def e2422373039066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2422373039066 : Closed e2422373039066 ∧ code e2422373039066 = 11218466061274 := by decide
theorem cert_e2422373039066 : check e2422373039066 [[],[]] .three = true := by decide
def e2422373039190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373039190 : Closed e2422373039190 ∧ code e2422373039190 = 11218466061398 := by decide
theorem cert_e2422373039190 : check e2422373039190 [[],[]] .smaller = true := by decide
def e2422373039194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373039194 : Closed e2422373039194 ∧ code e2422373039194 = 11218466061402 := by decide
theorem cert_e2422373039194 : check e2422373039194 [[],[]] .smaller = true := by decide
def e2422373039382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422373039382 : Closed e2422373039382 ∧ code e2422373039382 = 11218466061590 := by decide
theorem cert_e2422373039382 : check e2422373039382 [[],[]] .smaller = true := by decide
def e2422373039454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e2422373039454 : Closed e2422373039454 ∧ code e2422373039454 = 11218466061662 := by decide
theorem cert_e2422373039454 : check e2422373039454 [[],[]] .three = true := by decide
def e2422373039458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422373039458 : Closed e2422373039458 ∧ code e2422373039458 = 11218466061666 := by decide
theorem cert_e2422373039458 : check e2422373039458 [[],[]] .smaller = true := by decide
def e2422373039470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2422373039470 : Closed e2422373039470 ∧ code e2422373039470 = 11218466061678 := by decide
theorem cert_e2422373039470 : check e2422373039470 [[],[]] .smaller = true := by decide
def e2422373039478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2422373039478 : Closed e2422373039478 ∧ code e2422373039478 = 11218466061686 := by decide
theorem cert_e2422373039478 : check e2422373039478 [[],[]] .smaller = true := by decide
def e2422373039482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e2422373039482 : Closed e2422373039482 ∧ code e2422373039482 = 11218466061690 := by decide
theorem cert_e2422373039482 : check e2422373039482 [[],[]] .three = true := by decide
def e2422373039498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422373039498 : Closed e2422373039498 ∧ code e2422373039498 = 11218466061706 := by decide
theorem cert_e2422373039498 : check e2422373039498 [[],[]] .smaller = true := by decide
def e2422373039522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422373039522 : Closed e2422373039522 ∧ code e2422373039522 = 11218466061730 := by decide
theorem cert_e2422373039522 : check e2422373039522 [[],[]] .smaller = true := by decide
def e2422373039534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2422373039534 : Closed e2422373039534 ∧ code e2422373039534 = 11218466061742 := by decide
theorem cert_e2422373039534 : check e2422373039534 [[],[]] .smaller = true := by decide
def e2422373039546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2422373039546 : Closed e2422373039546 ∧ code e2422373039546 = 11218466061754 := by decide
theorem cert_e2422373039546 : check e2422373039546 [[],[]] .smaller = true := by decide
def e2422373039574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2422373039574 : Closed e2422373039574 ∧ code e2422373039574 = 11218466061782 := by decide
theorem cert_e2422373039574 : check e2422373039574 [[],[]] .smaller = true := by decide
def e2422373039578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2422373039578 : Closed e2422373039578 ∧ code e2422373039578 = 11218466061786 := by decide
theorem cert_e2422373039578 : check e2422373039578 [[],[]] .smaller = true := by decide
def e2422373039594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2422373039594 : Closed e2422373039594 ∧ code e2422373039594 = 11218466061802 := by decide
theorem cert_e2422373039594 : check e2422373039594 [[],[]] .three = true := by decide
def e2422373039658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373039658 : Closed e2422373039658 ∧ code e2422373039658 = 11218466061866 := by decide
theorem cert_e2422373039658 : check e2422373039658 [[],[]] .three = true := by decide
def e2422373039754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422373039754 : Closed e2422373039754 ∧ code e2422373039754 = 11218466061962 := by decide
theorem cert_e2422373039754 : check e2422373039754 [[],[]] .three = true := by decide
def e2422373039778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422373039778 : Closed e2422373039778 ∧ code e2422373039778 = 11218466061986 := by decide
theorem cert_e2422373039778 : check e2422373039778 [[],[]] .three = true := by decide
def e2422373039790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422373039790 : Closed e2422373039790 ∧ code e2422373039790 = 11218466061998 := by decide
theorem cert_e2422373039790 : check e2422373039790 [[],[]] .three = true := by decide
def e2422373039798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e2422373039798 : Closed e2422373039798 ∧ code e2422373039798 = 11218466062006 := by decide
theorem cert_e2422373039798 : check e2422373039798 [[],[]] .three = true := by decide
def e2422373039802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422373039802 : Closed e2422373039802 ∧ code e2422373039802 = 11218466062010 := by decide
theorem cert_e2422373039802 : check e2422373039802 [[],[]] .three = true := by decide
def e2422373039830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2422373039830 : Closed e2422373039830 ∧ code e2422373039830 = 11218466062038 := by decide
theorem cert_e2422373039830 : check e2422373039830 [[],[]] .three = true := by decide
def e2422373039834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2422373039834 : Closed e2422373039834 ∧ code e2422373039834 = 11218466062042 := by decide
theorem cert_e2422373039834 : check e2422373039834 [[],[]] .three = true := by decide
def e2422373039850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422373039850 : Closed e2422373039850 ∧ code e2422373039850 = 11218466062058 := by decide
theorem cert_e2422373039850 : check e2422373039850 [[],[]] .three = true := by decide
def e2422373040342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e2422373040342 : Closed e2422373040342 ∧ code e2422373040342 = 11218466062550 := by decide
theorem cert_e2422373040342 : check e2422373040342 [[],[]] .smaller = true := by decide
def e2422373040438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373040438 : Closed e2422373040438 ∧ code e2422373040438 = 11218466062646 := by decide
theorem cert_e2422373040438 : check e2422373040438 [[],[]] .smaller = true := by decide
def e2422373040442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373040442 : Closed e2422373040442 ∧ code e2422373040442 = 11218466062650 := by decide
theorem cert_e2422373040442 : check e2422373040442 [[],[]] .smaller = true := by decide
def e2422373040606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2422373040606 : Closed e2422373040606 ∧ code e2422373040606 = 11218466062814 := by decide
theorem cert_e2422373040606 : check e2422373040606 [[],[]] .three = true := by decide
def e2422373040622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2422373040622 : Closed e2422373040622 ∧ code e2422373040622 = 11218466062830 := by decide
theorem cert_e2422373040622 : check e2422373040622 [[],[]] .smaller = true := by decide
def e2422373040630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2422373040630 : Closed e2422373040630 ∧ code e2422373040630 = 11218466062838 := by decide
theorem cert_e2422373040630 : check e2422373040630 [[],[]] .smaller = true := by decide
def e2422373040634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 5)))) (.var 0)))))))
theorem wire_e2422373040634 : Closed e2422373040634 ∧ code e2422373040634 = 11218466062842 := by decide
theorem cert_e2422373040634 : check e2422373040634 [[],[]] .three = true := by decide
def e2422373040990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e2422373040990 : Closed e2422373040990 ∧ code e2422373040990 = 11218466063198 := by decide
theorem cert_e2422373040990 : check e2422373040990 [[],[]] .three = true := by decide
def e2422373041014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2422373041014 : Closed e2422373041014 ∧ code e2422373041014 = 11218466063222 := by decide
theorem cert_e2422373041014 : check e2422373041014 [[],[]] .smaller = true := by decide
def e2422373041078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e2422373041078 : Closed e2422373041078 ∧ code e2422373041078 = 11218466063286 := by decide
theorem cert_e2422373041078 : check e2422373041078 [[],[]] .smaller = true := by decide
def e2422373041082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2422373041082 : Closed e2422373041082 ∧ code e2422373041082 = 11218466063290 := by decide
theorem cert_e2422373041082 : check e2422373041082 [[],[]] .smaller = true := by decide
def e2422373041110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2422373041110 : Closed e2422373041110 ∧ code e2422373041110 = 11218466063318 := by decide
theorem cert_e2422373041110 : check e2422373041110 [[],[]] .smaller = true := by decide
def e2422373041114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2422373041114 : Closed e2422373041114 ∧ code e2422373041114 = 11218466063322 := by decide
theorem cert_e2422373041114 : check e2422373041114 [[],[]] .smaller = true := by decide
def e2422373041374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373041374 : Closed e2422373041374 ∧ code e2422373041374 = 11218466063582 := by decide
theorem cert_e2422373041374 : check e2422373041374 [[],[]] .three = true := by decide
def e2422373041390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373041390 : Closed e2422373041390 ∧ code e2422373041390 = 11218466063598 := by decide
theorem cert_e2422373041390 : check e2422373041390 [[],[]] .smaller = true := by decide
def e2422373041398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373041398 : Closed e2422373041398 ∧ code e2422373041398 = 11218466063606 := by decide
theorem cert_e2422373041398 : check e2422373041398 [[],[]] .smaller = true := by decide
def e2422373041402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373041402 : Closed e2422373041402 ∧ code e2422373041402 = 11218466063610 := by decide
theorem cert_e2422373041402 : check e2422373041402 [[],[]] .three = true := by decide
def e2422373041726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 4))))))))
theorem wire_e2422373041726 : Closed e2422373041726 ∧ code e2422373041726 = 11218466063934 := by decide
theorem cert_e2422373041726 : check e2422373041726 [[],[]] .three = true := by decide
def e2422373041782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373041782 : Closed e2422373041782 ∧ code e2422373041782 = 11218466063990 := by decide
theorem cert_e2422373041782 : check e2422373041782 [[],[]] .smaller = true := by decide
def e2422373041950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2422373041950 : Closed e2422373041950 ∧ code e2422373041950 = 11218466064158 := by decide
theorem cert_e2422373041950 : check e2422373041950 [[],[]] .smaller = true := by decide
def e2422373041974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373041974 : Closed e2422373041974 ∧ code e2422373041974 = 11218466064182 := by decide
theorem cert_e2422373041974 : check e2422373041974 [[],[]] .smaller = true := by decide
def e2422373041978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373041978 : Closed e2422373041978 ∧ code e2422373041978 = 11218466064186 := by decide
theorem cert_e2422373041978 : check e2422373041978 [[],[]] .smaller = true := by decide
def e2422373042062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2422373042062 : Closed e2422373042062 ∧ code e2422373042062 = 11218466064270 := by decide
theorem cert_e2422373042062 : check e2422373042062 [[],[]] .smaller = true := by decide
def e2422373042118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 4))) (.lam (.var 1))))))))
theorem wire_e2422373042118 : Closed e2422373042118 ∧ code e2422373042118 = 11218466064326 := by decide
theorem cert_e2422373042118 : check e2422373042118 [[],[]] .three = true := by decide
def e2422373042142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 4))) (.var 3)))))))
theorem wire_e2422373042142 : Closed e2422373042142 ∧ code e2422373042142 = 11218466064350 := by decide
theorem cert_e2422373042142 : check e2422373042142 [[],[]] .three = true := by decide
def e2422373043030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2422373043030 : Closed e2422373043030 ∧ code e2422373043030 = 11218466065238 := by decide
theorem cert_e2422373043030 : check e2422373043030 [[],[]] .smaller = true := by decide
def e2422373043034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2422373043034 : Closed e2422373043034 ∧ code e2422373043034 = 11218466065242 := by decide
theorem cert_e2422373043034 : check e2422373043034 [[],[]] .smaller = true := by decide
def e2422373043050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2422373043050 : Closed e2422373043050 ∧ code e2422373043050 = 11218466065258 := by decide
theorem cert_e2422373043050 : check e2422373043050 [[],[]] .smaller = true := by decide
def e2422373043114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422373043114 : Closed e2422373043114 ∧ code e2422373043114 = 11218466065322 := by decide
theorem cert_e2422373043114 : check e2422373043114 [[],[]] .smaller = true := by decide
def e2422373043222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373043222 : Closed e2422373043222 ∧ code e2422373043222 = 11218466065430 := by decide
theorem cert_e2422373043222 : check e2422373043222 [[],[]] .smaller = true := by decide
def e2422373043294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422373043294 : Closed e2422373043294 ∧ code e2422373043294 = 11218466065502 := by decide
theorem cert_e2422373043294 : check e2422373043294 [[],[]] .three = true := by decide
def e2422373043318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2422373043318 : Closed e2422373043318 ∧ code e2422373043318 = 11218466065526 := by decide
theorem cert_e2422373043318 : check e2422373043318 [[],[]] .smaller = true := by decide
def e2422373043414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2422373043414 : Closed e2422373043414 ∧ code e2422373043414 = 11218466065622 := by decide
theorem cert_e2422373043414 : check e2422373043414 [[],[]] .smaller = true := by decide
def e2422373043418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2422373043418 : Closed e2422373043418 ∧ code e2422373043418 = 11218466065626 := by decide
theorem cert_e2422373043418 : check e2422373043418 [[],[]] .smaller = true := by decide
def e2422373043434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2422373043434 : Closed e2422373043434 ∧ code e2422373043434 = 11218466065642 := by decide
theorem cert_e2422373043434 : check e2422373043434 [[],[]] .smaller = true := by decide
def e2422373043510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373043510 : Closed e2422373043510 ∧ code e2422373043510 = 11218466065718 := by decide
theorem cert_e2422373043510 : check e2422373043510 [[],[]] .smaller = true := by decide
def e2422373043514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373043514 : Closed e2422373043514 ∧ code e2422373043514 = 11218466065722 := by decide
theorem cert_e2422373043514 : check e2422373043514 [[],[]] .smaller = true := by decide
def e2422373043586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373043586 : Closed e2422373043586 ∧ code e2422373043586 = 11218466065794 := by decide
theorem cert_e2422373043586 : check e2422373043586 [[],[]] .smaller = true := by decide
def e2422373043598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2422373043598 : Closed e2422373043598 ∧ code e2422373043598 = 11218466065806 := by decide
theorem cert_e2422373043598 : check e2422373043598 [[],[]] .smaller = true := by decide
def e2422373043610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373043610 : Closed e2422373043610 ∧ code e2422373043610 = 11218466065818 := by decide
theorem cert_e2422373043610 : check e2422373043610 [[],[]] .smaller = true := by decide
def e2422373043678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2422373043678 : Closed e2422373043678 ∧ code e2422373043678 = 11218466065886 := by decide
theorem cert_e2422373043678 : check e2422373043678 [[],[]] .three = true := by decide
def e2422373043682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422373043682 : Closed e2422373043682 ∧ code e2422373043682 = 11218466065890 := by decide
theorem cert_e2422373043682 : check e2422373043682 [[],[]] .three = true := by decide
def e2422373043694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2422373043694 : Closed e2422373043694 ∧ code e2422373043694 = 11218466065902 := by decide
theorem cert_e2422373043694 : check e2422373043694 [[],[]] .three = true := by decide
def e2422373043722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373043722 : Closed e2422373043722 ∧ code e2422373043722 = 11218466065930 := by decide
theorem cert_e2422373043722 : check e2422373043722 [[],[]] .smaller = true := by decide
def e2422373043758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373043758 : Closed e2422373043758 ∧ code e2422373043758 = 11218466065966 := by decide
theorem cert_e2422373043758 : check e2422373043758 [[],[]] .smaller = true := by decide
def e2422373043766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373043766 : Closed e2422373043766 ∧ code e2422373043766 = 11218466065974 := by decide
theorem cert_e2422373043766 : check e2422373043766 [[],[]] .smaller = true := by decide
def e2422373043770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373043770 : Closed e2422373043770 ∧ code e2422373043770 = 11218466065978 := by decide
theorem cert_e2422373043770 : check e2422373043770 [[],[]] .smaller = true := by decide
def e2422373043818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373043818 : Closed e2422373043818 ∧ code e2422373043818 = 11218466066026 := by decide
theorem cert_e2422373043818 : check e2422373043818 [[],[]] .smaller = true := by decide
def e2422373043842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373043842 : Closed e2422373043842 ∧ code e2422373043842 = 11218466066050 := by decide
theorem cert_e2422373043842 : check e2422373043842 [[],[]] .smaller = true := by decide
def e2422373043854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373043854 : Closed e2422373043854 ∧ code e2422373043854 = 11218466066062 := by decide
theorem cert_e2422373043854 : check e2422373043854 [[],[]] .smaller = true := by decide
def e2422373043866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373043866 : Closed e2422373043866 ∧ code e2422373043866 = 11218466066074 := by decide
theorem cert_e2422373043866 : check e2422373043866 [[],[]] .smaller = true := by decide
def e2422373043910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373043910 : Closed e2422373043910 ∧ code e2422373043910 = 11218466066118 := by decide
theorem cert_e2422373043910 : check e2422373043910 [[],[]] .smaller = true := by decide
def e2422373043934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2422373043934 : Closed e2422373043934 ∧ code e2422373043934 = 11218466066142 := by decide
theorem cert_e2422373043934 : check e2422373043934 [[],[]] .three = true := by decide
def e2422373043938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373043938 : Closed e2422373043938 ∧ code e2422373043938 = 11218466066146 := by decide
theorem cert_e2422373043938 : check e2422373043938 [[],[]] .smaller = true := by decide
def e2422373043950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2422373043950 : Closed e2422373043950 ∧ code e2422373043950 = 11218466066158 := by decide
theorem cert_e2422373043950 : check e2422373043950 [[],[]] .smaller = true := by decide
def e2422373043958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2422373043958 : Closed e2422373043958 ∧ code e2422373043958 = 11218466066166 := by decide
theorem cert_e2422373043958 : check e2422373043958 [[],[]] .three = true := by decide
def e2422373043990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373043990 : Closed e2422373043990 ∧ code e2422373043990 = 11218466066198 := by decide
theorem cert_e2422373043990 : check e2422373043990 [[],[]] .smaller = true := by decide
def e2422373044062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2422373044062 : Closed e2422373044062 ∧ code e2422373044062 = 11218466066270 := by decide
theorem cert_e2422373044062 : check e2422373044062 [[],[]] .three = true := by decide
def e2422373044066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373044066 : Closed e2422373044066 ∧ code e2422373044066 = 11218466066274 := by decide
theorem cert_e2422373044066 : check e2422373044066 [[],[]] .smaller = true := by decide
def e2422373044078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2422373044078 : Closed e2422373044078 ∧ code e2422373044078 = 11218466066286 := by decide
theorem cert_e2422373044078 : check e2422373044078 [[],[]] .smaller = true := by decide
def e2422373044086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2422373044086 : Closed e2422373044086 ∧ code e2422373044086 = 11218466066294 := by decide
theorem cert_e2422373044086 : check e2422373044086 [[],[]] .smaller = true := by decide
def e2422373044090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2422373044090 : Closed e2422373044090 ∧ code e2422373044090 = 11218466066298 := by decide
theorem cert_e2422373044090 : check e2422373044090 [[],[]] .three = true := by decide
def e2422373044106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373044106 : Closed e2422373044106 ∧ code e2422373044106 = 11218466066314 := by decide
theorem cert_e2422373044106 : check e2422373044106 [[],[]] .three = true := by decide
def e2422373044130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373044130 : Closed e2422373044130 ∧ code e2422373044130 = 11218466066338 := by decide
theorem cert_e2422373044130 : check e2422373044130 [[],[]] .three = true := by decide
def e2422373044142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2422373044142 : Closed e2422373044142 ∧ code e2422373044142 = 11218466066350 := by decide
theorem cert_e2422373044142 : check e2422373044142 [[],[]] .three = true := by decide
def e2422373044150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2422373044150 : Closed e2422373044150 ∧ code e2422373044150 = 11218466066358 := by decide
theorem cert_e2422373044150 : check e2422373044150 [[],[]] .three = true := by decide
def e2422373044154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2422373044154 : Closed e2422373044154 ∧ code e2422373044154 = 11218466066362 := by decide
theorem cert_e2422373044154 : check e2422373044154 [[],[]] .three = true := by decide
def e2422373044350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 5)))))))))
theorem wire_e2422373044350 : Closed e2422373044350 ∧ code e2422373044350 = 11218466066558 := by decide
theorem cert_e2422373044350 : check e2422373044350 [[],[]] .three = true := by decide
def e2422373044462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373044462 : Closed e2422373044462 ∧ code e2422373044462 = 11218466066670 := by decide
theorem cert_e2422373044462 : check e2422373044462 [[],[]] .smaller = true := by decide
def e2422373044470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373044470 : Closed e2422373044470 ∧ code e2422373044470 = 11218466066678 := by decide
theorem cert_e2422373044470 : check e2422373044470 [[],[]] .smaller = true := by decide
def e2422373044950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422373044950 : Closed e2422373044950 ∧ code e2422373044950 = 11218466067158 := by decide
theorem cert_e2422373044950 : check e2422373044950 [[],[]] .smaller = true := by decide
def e2422373044954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422373044954 : Closed e2422373044954 ∧ code e2422373044954 = 11218466067162 := by decide
theorem cert_e2422373044954 : check e2422373044954 [[],[]] .smaller = true := by decide
def e2422373044970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422373044970 : Closed e2422373044970 ∧ code e2422373044970 = 11218466067178 := by decide
theorem cert_e2422373044970 : check e2422373044970 [[],[]] .smaller = true := by decide
def e2422373045046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373045046 : Closed e2422373045046 ∧ code e2422373045046 = 11218466067254 := by decide
theorem cert_e2422373045046 : check e2422373045046 [[],[]] .smaller = true := by decide
def e2422373045050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373045050 : Closed e2422373045050 ∧ code e2422373045050 = 11218466067258 := by decide
theorem cert_e2422373045050 : check e2422373045050 [[],[]] .smaller = true := by decide
def e2422373045122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373045122 : Closed e2422373045122 ∧ code e2422373045122 = 11218466067330 := by decide
theorem cert_e2422373045122 : check e2422373045122 [[],[]] .smaller = true := by decide
def e2422373045134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2422373045134 : Closed e2422373045134 ∧ code e2422373045134 = 11218466067342 := by decide
theorem cert_e2422373045134 : check e2422373045134 [[],[]] .smaller = true := by decide
def e2422373045146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373045146 : Closed e2422373045146 ∧ code e2422373045146 = 11218466067354 := by decide
theorem cert_e2422373045146 : check e2422373045146 [[],[]] .smaller = true := by decide
def e2422373045214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373045214 : Closed e2422373045214 ∧ code e2422373045214 = 11218466067422 := by decide
theorem cert_e2422373045214 : check e2422373045214 [[],[]] .three = true := by decide
def e2422373045218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422373045218 : Closed e2422373045218 ∧ code e2422373045218 = 11218466067426 := by decide
theorem cert_e2422373045218 : check e2422373045218 [[],[]] .three = true := by decide
def e2422373045230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373045230 : Closed e2422373045230 ∧ code e2422373045230 = 11218466067438 := by decide
theorem cert_e2422373045230 : check e2422373045230 [[],[]] .three = true := by decide
def e2422373046298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373046298 : Closed e2422373046298 ∧ code e2422373046298 = 11218466068506 := by decide
theorem cert_e2422373046298 : check e2422373046298 [[],[]] .smaller = true := by decide
def e2422373046334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373046334 : Closed e2422373046334 ∧ code e2422373046334 = 11218466068542 := by decide
theorem cert_e2422373046334 : check e2422373046334 [[],[]] .smaller = true := by decide
def e2422373046382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373046382 : Closed e2422373046382 ∧ code e2422373046382 = 11218466068590 := by decide
theorem cert_e2422373046382 : check e2422373046382 [[],[]] .smaller = true := by decide
def e2422373046390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373046390 : Closed e2422373046390 ∧ code e2422373046390 = 11218466068598 := by decide
theorem cert_e2422373046390 : check e2422373046390 [[],[]] .smaller = true := by decide
def e2422373046394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373046394 : Closed e2422373046394 ∧ code e2422373046394 = 11218466068602 := by decide
theorem cert_e2422373046394 : check e2422373046394 [[],[]] .smaller = true := by decide
def e2422373046634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373046634 : Closed e2422373046634 ∧ code e2422373046634 = 11218466068842 := by decide
theorem cert_e2422373046634 : check e2422373046634 [[],[]] .smaller = true := by decide
def e2422373046658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373046658 : Closed e2422373046658 ∧ code e2422373046658 = 11218466068866 := by decide
theorem cert_e2422373046658 : check e2422373046658 [[],[]] .smaller = true := by decide
def e2422373046670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373046670 : Closed e2422373046670 ∧ code e2422373046670 = 11218466068878 := by decide
theorem cert_e2422373046670 : check e2422373046670 [[],[]] .smaller = true := by decide
def e2422373046682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373046682 : Closed e2422373046682 ∧ code e2422373046682 = 11218466068890 := by decide
theorem cert_e2422373046682 : check e2422373046682 [[],[]] .smaller = true := by decide
def e2422373046726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373046726 : Closed e2422373046726 ∧ code e2422373046726 = 11218466068934 := by decide
theorem cert_e2422373046726 : check e2422373046726 [[],[]] .smaller = true := by decide
def e2422373046750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373046750 : Closed e2422373046750 ∧ code e2422373046750 = 11218466068958 := by decide
theorem cert_e2422373046750 : check e2422373046750 [[],[]] .three = true := by decide
def e2422373046754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373046754 : Closed e2422373046754 ∧ code e2422373046754 = 11218466068962 := by decide
theorem cert_e2422373046754 : check e2422373046754 [[],[]] .smaller = true := by decide
def e2422373046766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373046766 : Closed e2422373046766 ∧ code e2422373046766 = 11218466068974 := by decide
theorem cert_e2422373046766 : check e2422373046766 [[],[]] .smaller = true := by decide
def e2422373046774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373046774 : Closed e2422373046774 ∧ code e2422373046774 = 11218466068982 := by decide
theorem cert_e2422373046774 : check e2422373046774 [[],[]] .three = true := by decide
def e2422373047326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373047326 : Closed e2422373047326 ∧ code e2422373047326 = 11218466069534 := by decide
theorem cert_e2422373047326 : check e2422373047326 [[],[]] .smaller = true := by decide
def e2422373047518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373047518 : Closed e2422373047518 ∧ code e2422373047518 = 11218466069726 := by decide
theorem cert_e2422373047518 : check e2422373047518 [[],[]] .three = true := by decide
def e2422373047522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373047522 : Closed e2422373047522 ∧ code e2422373047522 = 11218466069730 := by decide
theorem cert_e2422373047522 : check e2422373047522 [[],[]] .smaller = true := by decide
def e2422373047534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373047534 : Closed e2422373047534 ∧ code e2422373047534 = 11218466069742 := by decide
theorem cert_e2422373047534 : check e2422373047534 [[],[]] .smaller = true := by decide
def e2422373047542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373047542 : Closed e2422373047542 ∧ code e2422373047542 = 11218466069750 := by decide
theorem cert_e2422373047542 : check e2422373047542 [[],[]] .smaller = true := by decide
def e2422373047546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373047546 : Closed e2422373047546 ∧ code e2422373047546 = 11218466069754 := by decide
theorem cert_e2422373047546 : check e2422373047546 [[],[]] .three = true := by decide
def e2422373047822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373047822 : Closed e2422373047822 ∧ code e2422373047822 = 11218466070030 := by decide
theorem cert_e2422373047822 : check e2422373047822 [[],[]] .three = true := by decide
def e2422373047834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373047834 : Closed e2422373047834 ∧ code e2422373047834 = 11218466070042 := by decide
theorem cert_e2422373047834 : check e2422373047834 [[],[]] .three = true := by decide
def e2422373047870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.lam (.var 4))))))))
theorem wire_e2422373047870 : Closed e2422373047870 ∧ code e2422373047870 = 11218466070078 := by decide
theorem cert_e2422373047870 : check e2422373047870 [[],[]] .three = true := by decide
def e2422373047906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373047906 : Closed e2422373047906 ∧ code e2422373047906 = 11218466070114 := by decide
theorem cert_e2422373047906 : check e2422373047906 [[],[]] .three = true := by decide
def e2422373047918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373047918 : Closed e2422373047918 ∧ code e2422373047918 = 11218466070126 := by decide
theorem cert_e2422373047918 : check e2422373047918 [[],[]] .three = true := by decide
def e2422373047926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373047926 : Closed e2422373047926 ∧ code e2422373047926 = 11218466070134 := by decide
theorem cert_e2422373047926 : check e2422373047926 [[],[]] .three = true := by decide
def e2422373047930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373047930 : Closed e2422373047930 ∧ code e2422373047930 = 11218466070138 := by decide
theorem cert_e2422373047930 : check e2422373047930 [[],[]] .three = true := by decide
def e2422373048426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373048426 : Closed e2422373048426 ∧ code e2422373048426 = 11218466070634 := by decide
theorem cert_e2422373048426 : check e2422373048426 [[],[]] .smaller = true := by decide
def e2422373048474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373048474 : Closed e2422373048474 ∧ code e2422373048474 = 11218466070682 := by decide
theorem cert_e2422373048474 : check e2422373048474 [[],[]] .smaller = true := by decide
def e2422373048558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422373048558 : Closed e2422373048558 ∧ code e2422373048558 = 11218466070766 := by decide
theorem cert_e2422373048558 : check e2422373048558 [[],[]] .smaller = true := by decide
def e2422373048570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422373048570 : Closed e2422373048570 ∧ code e2422373048570 = 11218466070778 := by decide
theorem cert_e2422373048570 : check e2422373048570 [[],[]] .smaller = true := by decide
def e2422373048758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2422373048758 : Closed e2422373048758 ∧ code e2422373048758 = 11218466070966 := by decide
theorem cert_e2422373048758 : check e2422373048758 [[],[]] .smaller = true := by decide
def e2422373048762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422373048762 : Closed e2422373048762 ∧ code e2422373048762 = 11218466070970 := by decide
theorem cert_e2422373048762 : check e2422373048762 [[],[]] .smaller = true := by decide
def e2422373048790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2422373048790 : Closed e2422373048790 ∧ code e2422373048790 = 11218466070998 := by decide
theorem cert_e2422373048790 : check e2422373048790 [[],[]] .smaller = true := by decide
def e2422373048794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e2422373048794 : Closed e2422373048794 ∧ code e2422373048794 = 11218466071002 := by decide
theorem cert_e2422373048794 : check e2422373048794 [[],[]] .smaller = true := by decide
def e2422373048810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422373048810 : Closed e2422373048810 ∧ code e2422373048810 = 11218466071018 := by decide
theorem cert_e2422373048810 : check e2422373048810 [[],[]] .smaller = true := by decide
def e2422373048942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373048942 : Closed e2422373048942 ∧ code e2422373048942 = 11218466071150 := by decide
theorem cert_e2422373048942 : check e2422373048942 [[],[]] .smaller = true := by decide
def e2422373048954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373048954 : Closed e2422373048954 ∧ code e2422373048954 = 11218466071162 := by decide
theorem cert_e2422373048954 : check e2422373048954 [[],[]] .smaller = true := by decide
def e2422373049118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422373049118 : Closed e2422373049118 ∧ code e2422373049118 = 11218466071326 := by decide
theorem cert_e2422373049118 : check e2422373049118 [[],[]] .smaller = true := by decide
def e2422373049142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373049142 : Closed e2422373049142 ∧ code e2422373049142 = 11218466071350 := by decide
theorem cert_e2422373049142 : check e2422373049142 [[],[]] .smaller = true := by decide
def e2422373049146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373049146 : Closed e2422373049146 ∧ code e2422373049146 = 11218466071354 := by decide
theorem cert_e2422373049146 : check e2422373049146 [[],[]] .smaller = true := by decide
def e2422373049242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373049242 : Closed e2422373049242 ∧ code e2422373049242 = 11218466071450 := by decide
theorem cert_e2422373049242 : check e2422373049242 [[],[]] .smaller = true := by decide
def e2422373049286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422373049286 : Closed e2422373049286 ∧ code e2422373049286 = 11218466071494 := by decide
theorem cert_e2422373049286 : check e2422373049286 [[],[]] .smaller = true := by decide
def e2422373049310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 3)))))))
theorem wire_e2422373049310 : Closed e2422373049310 ∧ code e2422373049310 = 11218466071518 := by decide
theorem cert_e2422373049310 : check e2422373049310 [[],[]] .three = true := by decide
def e2422373049326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 4))) (.var 2)))))))
theorem wire_e2422373049326 : Closed e2422373049326 ∧ code e2422373049326 = 11218466071534 := by decide
theorem cert_e2422373049326 : check e2422373049326 [[],[]] .three = true := by decide
def e2422373049770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422373049770 : Closed e2422373049770 ∧ code e2422373049770 = 11218466071978 := by decide
theorem cert_e2422373049770 : check e2422373049770 [[],[]] .smaller = true := by decide
end Blc.Floor43
