import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e759416499678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e759416499678 : Closed e759416499678 ∧ code e759416499678 = 9555509521886 := by decide
theorem cert_e759416499678 : check e759416499678 [] .sourceHead = true := by decide
def e759416499694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e759416499694 : Closed e759416499694 ∧ code e759416499694 = 9555509521902 := by decide
theorem cert_e759416499694 : check e759416499694 [] .sourceHead = true := by decide
def e759416500062 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e759416500062 : Closed e759416500062 ∧ code e759416500062 = 9555509522270 := by decide
theorem cert_e759416500062 : check e759416500062 [] .sourceHead = true := by decide
def e759416500090 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e759416500090 : Closed e759416500090 ∧ code e759416500090 = 9555509522298 := by decide
theorem cert_e759416500090 : check e759416500090 [] .sourceHead = true := by decide
def e759416500142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e759416500142 : Closed e759416500142 ∧ code e759416500142 = 9555509522350 := by decide
theorem cert_e759416500142 : check e759416500142 [] .sourceHead = true := by decide
def e759416500154 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e759416500154 : Closed e759416500154 ∧ code e759416500154 = 9555509522362 := by decide
theorem cert_e759416500154 : check e759416500154 [] .sourceHead = true := by decide
def e759416501214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e759416501214 : Closed e759416501214 ∧ code e759416501214 = 9555509523422 := by decide
theorem cert_e759416501214 : check e759416501214 [] .sourceHead = true := by decide
def e759416501230 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e759416501230 : Closed e759416501230 ∧ code e759416501230 = 9555509523438 := by decide
theorem cert_e759416501230 : check e759416501230 [] .sourceHead = true := by decide
def e759416503518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e759416503518 : Closed e759416503518 ∧ code e759416503518 = 9555509525726 := by decide
theorem cert_e759416503518 : check e759416503518 [] .sourceHead = true := by decide
def e759416503546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e759416503546 : Closed e759416503546 ∧ code e759416503546 = 9555509525754 := by decide
theorem cert_e759416503546 : check e759416503546 [] .sourceHead = true := by decide
def e759416503918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e759416503918 : Closed e759416503918 ∧ code e759416503918 = 9555509526126 := by decide
theorem cert_e759416503918 : check e759416503918 [] .sourceHead = true := by decide
def e759416503930 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e759416503930 : Closed e759416503930 ∧ code e759416503930 = 9555509526138 := by decide
theorem cert_e759416503930 : check e759416503930 [] .sourceHead = true := by decide
def e759416532334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e759416532334 : Closed e759416532334 ∧ code e759416532334 = 9555509554542 := by decide
theorem cert_e759416532334 : check e759416532334 [] .sourceHead = true := by decide
def e759416532342 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e759416532342 : Closed e759416532342 ∧ code e759416532342 = 9555509554550 := by decide
theorem cert_e759416532342 : check e759416532342 [] .sourceHead = true := by decide
def e759416532398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e759416532398 : Closed e759416532398 ∧ code e759416532398 = 9555509554606 := by decide
theorem cert_e759416532398 : check e759416532398 [] .sourceHead = true := by decide
def e759416532410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e759416532410 : Closed e759416532410 ∧ code e759416532410 = 9555509554618 := by decide
theorem cert_e759416532410 : check e759416532410 [] .sourceHead = true := by decide
def e759416532438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e759416532438 : Closed e759416532438 ∧ code e759416532438 = 9555509554646 := by decide
theorem cert_e759416532438 : check e759416532438 [] .sourceHead = true := by decide
def e759416532442 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e759416532442 : Closed e759416532442 ∧ code e759416532442 = 9555509554650 := by decide
theorem cert_e759416532442 : check e759416532442 [] .sourceHead = true := by decide
def e759416532654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e759416532654 : Closed e759416532654 ∧ code e759416532654 = 9555509554862 := by decide
theorem cert_e759416532654 : check e759416532654 [] .sourceHead = true := by decide
def e759416532666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e759416532666 : Closed e759416532666 ∧ code e759416532666 = 9555509554874 := by decide
theorem cert_e759416532666 : check e759416532666 [] .sourceHead = true := by decide
def e759416532714 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e759416532714 : Closed e759416532714 ∧ code e759416532714 = 9555509554922 := by decide
theorem cert_e759416532714 : check e759416532714 [] .sourceHead = true := by decide
def e759416532822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e759416532822 : Closed e759416532822 ∧ code e759416532822 = 9555509555030 := by decide
theorem cert_e759416532822 : check e759416532822 [] .sourceHead = true := by decide
def e759416532826 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e759416532826 : Closed e759416532826 ∧ code e759416532826 = 9555509555034 := by decide
theorem cert_e759416532826 : check e759416532826 [] .sourceHead = true := by decide
def e759416532842 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e759416532842 : Closed e759416532842 ∧ code e759416532842 = 9555509555050 := by decide
theorem cert_e759416532842 : check e759416532842 [] .sourceHead = true := by decide
def e759416533870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e759416533870 : Closed e759416533870 ∧ code e759416533870 = 9555509556078 := by decide
theorem cert_e759416533870 : check e759416533870 [] .sourceHead = true := by decide
def e759416533878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e759416533878 : Closed e759416533878 ∧ code e759416533878 = 9555509556086 := by decide
theorem cert_e759416533878 : check e759416533878 [] .sourceHead = true := by decide
def e759416533934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e759416533934 : Closed e759416533934 ∧ code e759416533934 = 9555509556142 := by decide
theorem cert_e759416533934 : check e759416533934 [] .sourceHead = true := by decide
def e759416533946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e759416533946 : Closed e759416533946 ∧ code e759416533946 = 9555509556154 := by decide
theorem cert_e759416533946 : check e759416533946 [] .sourceHead = true := by decide
def e759416533974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e759416533974 : Closed e759416533974 ∧ code e759416533974 = 9555509556182 := by decide
theorem cert_e759416533974 : check e759416533974 [] .sourceHead = true := by decide
def e759416533978 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e759416533978 : Closed e759416533978 ∧ code e759416533978 = 9555509556186 := by decide
theorem cert_e759416533978 : check e759416533978 [] .sourceHead = true := by decide
def e759416534254 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e759416534254 : Closed e759416534254 ∧ code e759416534254 = 9555509556462 := by decide
theorem cert_e759416534254 : check e759416534254 [] .sourceHead = true := by decide
def e759416534262 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e759416534262 : Closed e759416534262 ∧ code e759416534262 = 9555509556470 := by decide
theorem cert_e759416534262 : check e759416534262 [] .sourceHead = true := by decide
def e759416534638 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759416534638 : Closed e759416534638 ∧ code e759416534638 = 9555509556846 := by decide
theorem cert_e759416534638 : check e759416534638 [] .sourceHead = true := by decide
def e759416534650 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759416534650 : Closed e759416534650 ∧ code e759416534650 = 9555509556858 := by decide
theorem cert_e759416534650 : check e759416534650 [] .sourceHead = true := by decide
def e759416534838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759416534838 : Closed e759416534838 ∧ code e759416534838 = 9555509557046 := by decide
theorem cert_e759416534838 : check e759416534838 [] .sourceHead = true := by decide
def e759416534842 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759416534842 : Closed e759416534842 ∧ code e759416534842 = 9555509557050 := by decide
theorem cert_e759416534842 : check e759416534842 [] .sourceHead = true := by decide
def e759416535470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e759416535470 : Closed e759416535470 ∧ code e759416535470 = 9555509557678 := by decide
theorem cert_e759416535470 : check e759416535470 [] .sourceHead = true := by decide
def e759416535482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e759416535482 : Closed e759416535482 ∧ code e759416535482 = 9555509557690 := by decide
theorem cert_e759416535482 : check e759416535482 [] .sourceHead = true := by decide
def e759416535530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e759416535530 : Closed e759416535530 ∧ code e759416535530 = 9555509557738 := by decide
theorem cert_e759416535530 : check e759416535530 [] .sourceHead = true := by decide
def e759416535662 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759416535662 : Closed e759416535662 ∧ code e759416535662 = 9555509557870 := by decide
theorem cert_e759416535662 : check e759416535662 [] .sourceHead = true := by decide
def e759416535674 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759416535674 : Closed e759416535674 ∧ code e759416535674 = 9555509557882 := by decide
theorem cert_e759416535674 : check e759416535674 [] .sourceHead = true := by decide
def e759416535962 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759416535962 : Closed e759416535962 ∧ code e759416535962 = 9555509558170 := by decide
theorem cert_e759416535962 : check e759416535962 [] .sourceHead = true := by decide
def e759416536278 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e759416536278 : Closed e759416536278 ∧ code e759416536278 = 9555509558486 := by decide
theorem cert_e759416536278 : check e759416536278 [] .sourceHead = true := by decide
def e759416536282 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e759416536282 : Closed e759416536282 ∧ code e759416536282 = 9555509558490 := by decide
theorem cert_e759416536282 : check e759416536282 [] .sourceHead = true := by decide
def e759416536298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e759416536298 : Closed e759416536298 ∧ code e759416536298 = 9555509558506 := by decide
theorem cert_e759416536298 : check e759416536298 [] .sourceHead = true := by decide
def e759416536374 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759416536374 : Closed e759416536374 ∧ code e759416536374 = 9555509558582 := by decide
theorem cert_e759416536374 : check e759416536374 [] .sourceHead = true := by decide
def e759416536378 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759416536378 : Closed e759416536378 ∧ code e759416536378 = 9555509558586 := by decide
theorem cert_e759416536378 : check e759416536378 [] .sourceHead = true := by decide
def e759416536474 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759416536474 : Closed e759416536474 ∧ code e759416536474 = 9555509558682 := by decide
theorem cert_e759416536474 : check e759416536474 [] .sourceHead = true := by decide
def e759416538078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e759416538078 : Closed e759416538078 ∧ code e759416538078 = 9555509560286 := by decide
theorem cert_e759416538078 : check e759416538078 [] .sourceHead = true := by decide
def e759416538094 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e759416538094 : Closed e759416538094 ∧ code e759416538094 = 9555509560302 := by decide
theorem cert_e759416538094 : check e759416538094 [] .sourceHead = true := by decide
def e759416540014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759416540014 : Closed e759416540014 ∧ code e759416540014 = 9555509562222 := by decide
theorem cert_e759416540014 : check e759416540014 [] .sourceHead = true := by decide
def e759416540022 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759416540022 : Closed e759416540022 ∧ code e759416540022 = 9555509562230 := by decide
theorem cert_e759416540022 : check e759416540022 [] .sourceHead = true := by decide
def e759416540078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759416540078 : Closed e759416540078 ∧ code e759416540078 = 9555509562286 := by decide
theorem cert_e759416540078 : check e759416540078 [] .sourceHead = true := by decide
def e759416540090 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759416540090 : Closed e759416540090 ∧ code e759416540090 = 9555509562298 := by decide
theorem cert_e759416540090 : check e759416540090 [] .sourceHead = true := by decide
def e759416540118 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759416540118 : Closed e759416540118 ∧ code e759416540118 = 9555509562326 := by decide
theorem cert_e759416540118 : check e759416540118 [] .sourceHead = true := by decide
def e759416540122 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759416540122 : Closed e759416540122 ∧ code e759416540122 = 9555509562330 := by decide
theorem cert_e759416540122 : check e759416540122 [] .sourceHead = true := by decide
def e759416540398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759416540398 : Closed e759416540398 ∧ code e759416540398 = 9555509562606 := by decide
theorem cert_e759416540398 : check e759416540398 [] .sourceHead = true := by decide
def e759416540406 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759416540406 : Closed e759416540406 ∧ code e759416540406 = 9555509562614 := by decide
theorem cert_e759416540406 : check e759416540406 [] .sourceHead = true := by decide
def e759416540782 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759416540782 : Closed e759416540782 ∧ code e759416540782 = 9555509562990 := by decide
theorem cert_e759416540782 : check e759416540782 [] .sourceHead = true := by decide
def e759416540794 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759416540794 : Closed e759416540794 ∧ code e759416540794 = 9555509563002 := by decide
theorem cert_e759416540794 : check e759416540794 [] .sourceHead = true := by decide
def e759416540982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759416540982 : Closed e759416540982 ∧ code e759416540982 = 9555509563190 := by decide
theorem cert_e759416540982 : check e759416540982 [] .sourceHead = true := by decide
def e759416540986 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759416540986 : Closed e759416540986 ∧ code e759416540986 = 9555509563194 := by decide
theorem cert_e759416540986 : check e759416540986 [] .sourceHead = true := by decide
def e759416545758 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e759416545758 : Closed e759416545758 ∧ code e759416545758 = 9555509567966 := by decide
theorem cert_e759416545758 : check e759416545758 [] .sourceHead = true := by decide
def e759416545782 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e759416545782 : Closed e759416545782 ∧ code e759416545782 = 9555509567990 := by decide
theorem cert_e759416545782 : check e759416545782 [] .sourceHead = true := by decide
def e759416546734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e759416546734 : Closed e759416546734 ∧ code e759416546734 = 9555509568942 := by decide
theorem cert_e759416546734 : check e759416546734 [] .sourceHead = true := by decide
def e759416546746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e759416546746 : Closed e759416546746 ∧ code e759416546746 = 9555509568954 := by decide
theorem cert_e759416546746 : check e759416546746 [] .sourceHead = true := by decide
def e759416546794 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e759416546794 : Closed e759416546794 ∧ code e759416546794 = 9555509569002 := by decide
theorem cert_e759416546794 : check e759416546794 [] .sourceHead = true := by decide
def e759416546926 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e759416546926 : Closed e759416546926 ∧ code e759416546926 = 9555509569134 := by decide
theorem cert_e759416546926 : check e759416546926 [] .sourceHead = true := by decide
def e759416546938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e759416546938 : Closed e759416546938 ∧ code e759416546938 = 9555509569146 := by decide
theorem cert_e759416546938 : check e759416546938 [] .sourceHead = true := by decide
def e759416547226 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e759416547226 : Closed e759416547226 ∧ code e759416547226 = 9555509569434 := by decide
theorem cert_e759416547226 : check e759416547226 [] .sourceHead = true := by decide
def e759416549614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e759416549614 : Closed e759416549614 ∧ code e759416549614 = 9555509571822 := by decide
theorem cert_e759416549614 : check e759416549614 [] .sourceHead = true := by decide
def e759416549622 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e759416549622 : Closed e759416549622 ∧ code e759416549622 = 9555509571830 := by decide
theorem cert_e759416549622 : check e759416549622 [] .sourceHead = true := by decide
def e759416550102 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e759416550102 : Closed e759416550102 ∧ code e759416550102 = 9555509572310 := by decide
theorem cert_e759416550102 : check e759416550102 [] .sourceHead = true := by decide
def e759416550106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e759416550106 : Closed e759416550106 ∧ code e759416550106 = 9555509572314 := by decide
theorem cert_e759416550106 : check e759416550106 [] .sourceHead = true := by decide
def e759416550122 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e759416550122 : Closed e759416550122 ∧ code e759416550122 = 9555509572330 := by decide
theorem cert_e759416550122 : check e759416550122 [] .sourceHead = true := by decide
def e759416550198 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e759416550198 : Closed e759416550198 ∧ code e759416550198 = 9555509572406 := by decide
theorem cert_e759416550198 : check e759416550198 [] .sourceHead = true := by decide
def e759416550202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e759416550202 : Closed e759416550202 ∧ code e759416550202 = 9555509572410 := by decide
theorem cert_e759416550202 : check e759416550202 [] .sourceHead = true := by decide
def e759416550298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e759416550298 : Closed e759416550298 ∧ code e759416550298 = 9555509572506 := by decide
theorem cert_e759416550298 : check e759416550298 [] .sourceHead = true := by decide
def e759416687470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759416687470 : Closed e759416687470 ∧ code e759416687470 = 9555509709678 := by decide
theorem cert_e759416687470 : check e759416687470 [] .sourceHead = true := by decide
def e759416687478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759416687478 : Closed e759416687478 ∧ code e759416687478 = 9555509709686 := by decide
theorem cert_e759416687478 : check e759416687478 [] .sourceHead = true := by decide
def e759416687534 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759416687534 : Closed e759416687534 ∧ code e759416687534 = 9555509709742 := by decide
theorem cert_e759416687534 : check e759416687534 [] .sourceHead = true := by decide
def e759416687546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759416687546 : Closed e759416687546 ∧ code e759416687546 = 9555509709754 := by decide
theorem cert_e759416687546 : check e759416687546 [] .sourceHead = true := by decide
def e759416687574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759416687574 : Closed e759416687574 ∧ code e759416687574 = 9555509709782 := by decide
theorem cert_e759416687574 : check e759416687574 [] .sourceHead = true := by decide
def e759416687578 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759416687578 : Closed e759416687578 ∧ code e759416687578 = 9555509709786 := by decide
theorem cert_e759416687578 : check e759416687578 [] .sourceHead = true := by decide
def e759416687854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759416687854 : Closed e759416687854 ∧ code e759416687854 = 9555509710062 := by decide
theorem cert_e759416687854 : check e759416687854 [] .sourceHead = true := by decide
def e759416687862 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759416687862 : Closed e759416687862 ∧ code e759416687862 = 9555509710070 := by decide
theorem cert_e759416687862 : check e759416687862 [] .sourceHead = true := by decide
def e759416688238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759416688238 : Closed e759416688238 ∧ code e759416688238 = 9555509710446 := by decide
theorem cert_e759416688238 : check e759416688238 [] .sourceHead = true := by decide
def e759416688250 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759416688250 : Closed e759416688250 ∧ code e759416688250 = 9555509710458 := by decide
theorem cert_e759416688250 : check e759416688250 [] .sourceHead = true := by decide
def e759416688438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759416688438 : Closed e759416688438 ∧ code e759416688438 = 9555509710646 := by decide
theorem cert_e759416688438 : check e759416688438 [] .sourceHead = true := by decide
def e759416688442 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759416688442 : Closed e759416688442 ∧ code e759416688442 = 9555509710650 := by decide
theorem cert_e759416688442 : check e759416688442 [] .sourceHead = true := by decide
def e759417277294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759417277294 : Closed e759417277294 ∧ code e759417277294 = 9555510299502 := by decide
theorem cert_e759417277294 : check e759417277294 [] .sourceHead = true := by decide
def e759417277302 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759417277302 : Closed e759417277302 ∧ code e759417277302 = 9555510299510 := by decide
theorem cert_e759417277302 : check e759417277302 [] .sourceHead = true := by decide
def e759417277358 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759417277358 : Closed e759417277358 ∧ code e759417277358 = 9555510299566 := by decide
theorem cert_e759417277358 : check e759417277358 [] .sourceHead = true := by decide
def e759417277370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759417277370 : Closed e759417277370 ∧ code e759417277370 = 9555510299578 := by decide
theorem cert_e759417277370 : check e759417277370 [] .sourceHead = true := by decide
def e759417277398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759417277398 : Closed e759417277398 ∧ code e759417277398 = 9555510299606 := by decide
theorem cert_e759417277398 : check e759417277398 [] .sourceHead = true := by decide
def e759417277402 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759417277402 : Closed e759417277402 ∧ code e759417277402 = 9555510299610 := by decide
theorem cert_e759417277402 : check e759417277402 [] .sourceHead = true := by decide
def e759417277678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759417277678 : Closed e759417277678 ∧ code e759417277678 = 9555510299886 := by decide
theorem cert_e759417277678 : check e759417277678 [] .sourceHead = true := by decide
def e759417277686 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759417277686 : Closed e759417277686 ∧ code e759417277686 = 9555510299894 := by decide
theorem cert_e759417277686 : check e759417277686 [] .sourceHead = true := by decide
def e759417278062 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759417278062 : Closed e759417278062 ∧ code e759417278062 = 9555510300270 := by decide
theorem cert_e759417278062 : check e759417278062 [] .sourceHead = true := by decide
def e759417278074 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759417278074 : Closed e759417278074 ∧ code e759417278074 = 9555510300282 := by decide
theorem cert_e759417278074 : check e759417278074 [] .sourceHead = true := by decide
def e759417278262 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759417278262 : Closed e759417278262 ∧ code e759417278262 = 9555510300470 := by decide
theorem cert_e759417278262 : check e759417278262 [] .sourceHead = true := by decide
def e759417278266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759417278266 : Closed e759417278266 ∧ code e759417278266 = 9555510300474 := by decide
theorem cert_e759417278266 : check e759417278266 [] .sourceHead = true := by decide
def e759454281070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e759454281070 : Closed e759454281070 ∧ code e759454281070 = 9555547303278 := by decide
theorem cert_e759454281070 : check e759454281070 [] .sourceHead = true := by decide
def e759454281078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e759454281078 : Closed e759454281078 ∧ code e759454281078 = 9555547303286 := by decide
theorem cert_e759454281078 : check e759454281078 [] .sourceHead = true := by decide
def e759454281134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e759454281134 : Closed e759454281134 ∧ code e759454281134 = 9555547303342 := by decide
theorem cert_e759454281134 : check e759454281134 [] .sourceHead = true := by decide
def e759454281146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e759454281146 : Closed e759454281146 ∧ code e759454281146 = 9555547303354 := by decide
theorem cert_e759454281146 : check e759454281146 [] .sourceHead = true := by decide
def e759454281174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e759454281174 : Closed e759454281174 ∧ code e759454281174 = 9555547303382 := by decide
theorem cert_e759454281174 : check e759454281174 [] .sourceHead = true := by decide
def e759454281178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e759454281178 : Closed e759454281178 ∧ code e759454281178 = 9555547303386 := by decide
theorem cert_e759454281178 : check e759454281178 [] .sourceHead = true := by decide
def e759454281390 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e759454281390 : Closed e759454281390 ∧ code e759454281390 = 9555547303598 := by decide
theorem cert_e759454281390 : check e759454281390 [] .sourceHead = true := by decide
def e759454281402 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e759454281402 : Closed e759454281402 ∧ code e759454281402 = 9555547303610 := by decide
theorem cert_e759454281402 : check e759454281402 [] .sourceHead = true := by decide
def e759454281450 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e759454281450 : Closed e759454281450 ∧ code e759454281450 = 9555547303658 := by decide
theorem cert_e759454281450 : check e759454281450 [] .sourceHead = true := by decide
def e759454281558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e759454281558 : Closed e759454281558 ∧ code e759454281558 = 9555547303766 := by decide
theorem cert_e759454281558 : check e759454281558 [] .sourceHead = true := by decide
def e759454281562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e759454281562 : Closed e759454281562 ∧ code e759454281562 = 9555547303770 := by decide
theorem cert_e759454281562 : check e759454281562 [] .sourceHead = true := by decide
def e759454281578 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e759454281578 : Closed e759454281578 ∧ code e759454281578 = 9555547303786 := by decide
theorem cert_e759454281578 : check e759454281578 [] .sourceHead = true := by decide
def e759454282606 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e759454282606 : Closed e759454282606 ∧ code e759454282606 = 9555547304814 := by decide
theorem cert_e759454282606 : check e759454282606 [] .sourceHead = true := by decide
def e759454282614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e759454282614 : Closed e759454282614 ∧ code e759454282614 = 9555547304822 := by decide
theorem cert_e759454282614 : check e759454282614 [] .sourceHead = true := by decide
def e759454282670 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e759454282670 : Closed e759454282670 ∧ code e759454282670 = 9555547304878 := by decide
theorem cert_e759454282670 : check e759454282670 [] .sourceHead = true := by decide
def e759454282682 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e759454282682 : Closed e759454282682 ∧ code e759454282682 = 9555547304890 := by decide
theorem cert_e759454282682 : check e759454282682 [] .sourceHead = true := by decide
def e759454282710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e759454282710 : Closed e759454282710 ∧ code e759454282710 = 9555547304918 := by decide
theorem cert_e759454282710 : check e759454282710 [] .sourceHead = true := by decide
def e759454282714 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e759454282714 : Closed e759454282714 ∧ code e759454282714 = 9555547304922 := by decide
theorem cert_e759454282714 : check e759454282714 [] .sourceHead = true := by decide
def e759454282990 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e759454282990 : Closed e759454282990 ∧ code e759454282990 = 9555547305198 := by decide
theorem cert_e759454282990 : check e759454282990 [] .sourceHead = true := by decide
def e759454282998 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e759454282998 : Closed e759454282998 ∧ code e759454282998 = 9555547305206 := by decide
theorem cert_e759454282998 : check e759454282998 [] .sourceHead = true := by decide
def e759454283374 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759454283374 : Closed e759454283374 ∧ code e759454283374 = 9555547305582 := by decide
theorem cert_e759454283374 : check e759454283374 [] .sourceHead = true := by decide
def e759454283386 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759454283386 : Closed e759454283386 ∧ code e759454283386 = 9555547305594 := by decide
theorem cert_e759454283386 : check e759454283386 [] .sourceHead = true := by decide
def e759454283574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759454283574 : Closed e759454283574 ∧ code e759454283574 = 9555547305782 := by decide
theorem cert_e759454283574 : check e759454283574 [] .sourceHead = true := by decide
def e759454283578 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759454283578 : Closed e759454283578 ∧ code e759454283578 = 9555547305786 := by decide
theorem cert_e759454283578 : check e759454283578 [] .sourceHead = true := by decide
def e759454284206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e759454284206 : Closed e759454284206 ∧ code e759454284206 = 9555547306414 := by decide
theorem cert_e759454284206 : check e759454284206 [] .sourceHead = true := by decide
def e759454284218 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e759454284218 : Closed e759454284218 ∧ code e759454284218 = 9555547306426 := by decide
theorem cert_e759454284218 : check e759454284218 [] .sourceHead = true := by decide
def e759454284266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e759454284266 : Closed e759454284266 ∧ code e759454284266 = 9555547306474 := by decide
theorem cert_e759454284266 : check e759454284266 [] .sourceHead = true := by decide
def e759454284398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759454284398 : Closed e759454284398 ∧ code e759454284398 = 9555547306606 := by decide
theorem cert_e759454284398 : check e759454284398 [] .sourceHead = true := by decide
def e759454284410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759454284410 : Closed e759454284410 ∧ code e759454284410 = 9555547306618 := by decide
theorem cert_e759454284410 : check e759454284410 [] .sourceHead = true := by decide
def e759454284698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759454284698 : Closed e759454284698 ∧ code e759454284698 = 9555547306906 := by decide
theorem cert_e759454284698 : check e759454284698 [] .sourceHead = true := by decide
def e759454285014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e759454285014 : Closed e759454285014 ∧ code e759454285014 = 9555547307222 := by decide
theorem cert_e759454285014 : check e759454285014 [] .sourceHead = true := by decide
def e759454285018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e759454285018 : Closed e759454285018 ∧ code e759454285018 = 9555547307226 := by decide
theorem cert_e759454285018 : check e759454285018 [] .sourceHead = true := by decide
def e759454285034 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e759454285034 : Closed e759454285034 ∧ code e759454285034 = 9555547307242 := by decide
theorem cert_e759454285034 : check e759454285034 [] .sourceHead = true := by decide
def e759454285110 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759454285110 : Closed e759454285110 ∧ code e759454285110 = 9555547307318 := by decide
theorem cert_e759454285110 : check e759454285110 [] .sourceHead = true := by decide
def e759454285114 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759454285114 : Closed e759454285114 ∧ code e759454285114 = 9555547307322 := by decide
theorem cert_e759454285114 : check e759454285114 [] .sourceHead = true := by decide
def e759454285210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759454285210 : Closed e759454285210 ∧ code e759454285210 = 9555547307418 := by decide
theorem cert_e759454285210 : check e759454285210 [] .sourceHead = true := by decide
def e759454288750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759454288750 : Closed e759454288750 ∧ code e759454288750 = 9555547310958 := by decide
theorem cert_e759454288750 : check e759454288750 [] .sourceHead = true := by decide
def e759454288758 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759454288758 : Closed e759454288758 ∧ code e759454288758 = 9555547310966 := by decide
theorem cert_e759454288758 : check e759454288758 [] .sourceHead = true := by decide
def e759454288814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759454288814 : Closed e759454288814 ∧ code e759454288814 = 9555547311022 := by decide
theorem cert_e759454288814 : check e759454288814 [] .sourceHead = true := by decide
def e759454288826 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759454288826 : Closed e759454288826 ∧ code e759454288826 = 9555547311034 := by decide
theorem cert_e759454288826 : check e759454288826 [] .sourceHead = true := by decide
def e759454288854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759454288854 : Closed e759454288854 ∧ code e759454288854 = 9555547311062 := by decide
theorem cert_e759454288854 : check e759454288854 [] .sourceHead = true := by decide
def e759454288858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759454288858 : Closed e759454288858 ∧ code e759454288858 = 9555547311066 := by decide
theorem cert_e759454288858 : check e759454288858 [] .sourceHead = true := by decide
def e759454289134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759454289134 : Closed e759454289134 ∧ code e759454289134 = 9555547311342 := by decide
theorem cert_e759454289134 : check e759454289134 [] .sourceHead = true := by decide
def e759454289142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759454289142 : Closed e759454289142 ∧ code e759454289142 = 9555547311350 := by decide
theorem cert_e759454289142 : check e759454289142 [] .sourceHead = true := by decide
def e759454289518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759454289518 : Closed e759454289518 ∧ code e759454289518 = 9555547311726 := by decide
theorem cert_e759454289518 : check e759454289518 [] .sourceHead = true := by decide
def e759454289530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759454289530 : Closed e759454289530 ∧ code e759454289530 = 9555547311738 := by decide
theorem cert_e759454289530 : check e759454289530 [] .sourceHead = true := by decide
def e759454289718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759454289718 : Closed e759454289718 ∧ code e759454289718 = 9555547311926 := by decide
theorem cert_e759454289718 : check e759454289718 [] .sourceHead = true := by decide
def e759454289722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759454289722 : Closed e759454289722 ∧ code e759454289722 = 9555547311930 := by decide
theorem cert_e759454289722 : check e759454289722 [] .sourceHead = true := by decide
def e759454295470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e759454295470 : Closed e759454295470 ∧ code e759454295470 = 9555547317678 := by decide
theorem cert_e759454295470 : check e759454295470 [] .sourceHead = true := by decide
def e759454295482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e759454295482 : Closed e759454295482 ∧ code e759454295482 = 9555547317690 := by decide
theorem cert_e759454295482 : check e759454295482 [] .sourceHead = true := by decide
def e759454295530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e759454295530 : Closed e759454295530 ∧ code e759454295530 = 9555547317738 := by decide
theorem cert_e759454295530 : check e759454295530 [] .sourceHead = true := by decide
def e759454295662 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e759454295662 : Closed e759454295662 ∧ code e759454295662 = 9555547317870 := by decide
theorem cert_e759454295662 : check e759454295662 [] .sourceHead = true := by decide
def e759454295674 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e759454295674 : Closed e759454295674 ∧ code e759454295674 = 9555547317882 := by decide
theorem cert_e759454295674 : check e759454295674 [] .sourceHead = true := by decide
def e759454295962 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e759454295962 : Closed e759454295962 ∧ code e759454295962 = 9555547318170 := by decide
theorem cert_e759454295962 : check e759454295962 [] .sourceHead = true := by decide
def e759454298838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e759454298838 : Closed e759454298838 ∧ code e759454298838 = 9555547321046 := by decide
theorem cert_e759454298838 : check e759454298838 [] .sourceHead = true := by decide
def e759454298842 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e759454298842 : Closed e759454298842 ∧ code e759454298842 = 9555547321050 := by decide
theorem cert_e759454298842 : check e759454298842 [] .sourceHead = true := by decide
def e759454298858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e759454298858 : Closed e759454298858 ∧ code e759454298858 = 9555547321066 := by decide
theorem cert_e759454298858 : check e759454298858 [] .sourceHead = true := by decide
def e759454298934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e759454298934 : Closed e759454298934 ∧ code e759454298934 = 9555547321142 := by decide
theorem cert_e759454298934 : check e759454298934 [] .sourceHead = true := by decide
end Blc.Floor43
