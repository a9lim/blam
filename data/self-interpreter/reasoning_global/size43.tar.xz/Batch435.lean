import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374884794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422374884794 : Closed e2422374884794 ∧ code e2422374884794 = 11218467907002 := by decide
theorem cert_e2422374884794 : check e2422374884794 [[],[]] .smaller = true := by decide
def e2422374884842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422374884842 : Closed e2422374884842 ∧ code e2422374884842 = 11218467907050 := by decide
theorem cert_e2422374884842 : check e2422374884842 [[],[]] .smaller = true := by decide
def e2422374884926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2422374884926 : Closed e2422374884926 ∧ code e2422374884926 = 11218467907134 := by decide
theorem cert_e2422374884926 : check e2422374884926 [[],[]] .three = true := by decide
def e2422374884974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374884974 : Closed e2422374884974 ∧ code e2422374884974 = 11218467907182 := by decide
theorem cert_e2422374884974 : check e2422374884974 [[],[]] .smaller = true := by decide
def e2422374884986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374884986 : Closed e2422374884986 ∧ code e2422374884986 = 11218467907194 := by decide
theorem cert_e2422374884986 : check e2422374884986 [[],[]] .smaller = true := by decide
def e2422374885150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422374885150 : Closed e2422374885150 ∧ code e2422374885150 = 11218467907358 := by decide
theorem cert_e2422374885150 : check e2422374885150 [[],[]] .smaller = true := by decide
def e2422374885250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422374885250 : Closed e2422374885250 ∧ code e2422374885250 = 11218467907458 := by decide
theorem cert_e2422374885250 : check e2422374885250 [[],[]] .smaller = true := by decide
def e2422374885262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422374885262 : Closed e2422374885262 ∧ code e2422374885262 = 11218467907470 := by decide
theorem cert_e2422374885262 : check e2422374885262 [[],[]] .smaller = true := by decide
def e2422374885274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374885274 : Closed e2422374885274 ∧ code e2422374885274 = 11218467907482 := by decide
theorem cert_e2422374885274 : check e2422374885274 [[],[]] .smaller = true := by decide
def e2422374885318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2422374885318 : Closed e2422374885318 ∧ code e2422374885318 = 11218467907526 := by decide
theorem cert_e2422374885318 : check e2422374885318 [[],[]] .three = true := by decide
def e2422374885342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 3)))))))))
theorem wire_e2422374885342 : Closed e2422374885342 ∧ code e2422374885342 = 11218467907550 := by decide
theorem cert_e2422374885342 : check e2422374885342 [[],[]] .three = true := by decide
def e2422374887550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 5))))))))))
theorem wire_e2422374887550 : Closed e2422374887550 ∧ code e2422374887550 = 11218467909758 := by decide
theorem cert_e2422374887550 : check e2422374887550 [[],[]] .three = true := by decide
def e2422374887662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422374887662 : Closed e2422374887662 ∧ code e2422374887662 = 11218467909870 := by decide
theorem cert_e2422374887662 : check e2422374887662 [[],[]] .smaller = true := by decide
def e2422374887670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422374887670 : Closed e2422374887670 ∧ code e2422374887670 = 11218467909878 := by decide
theorem cert_e2422374887670 : check e2422374887670 [[],[]] .smaller = true := by decide
def e2422374888150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422374888150 : Closed e2422374888150 ∧ code e2422374888150 = 11218467910358 := by decide
theorem cert_e2422374888150 : check e2422374888150 [[],[]] .smaller = true := by decide
def e2422374888154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422374888154 : Closed e2422374888154 ∧ code e2422374888154 = 11218467910362 := by decide
theorem cert_e2422374888154 : check e2422374888154 [[],[]] .smaller = true := by decide
def e2422374888170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422374888170 : Closed e2422374888170 ∧ code e2422374888170 = 11218467910378 := by decide
theorem cert_e2422374888170 : check e2422374888170 [[],[]] .smaller = true := by decide
def e2422374888246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374888246 : Closed e2422374888246 ∧ code e2422374888246 = 11218467910454 := by decide
theorem cert_e2422374888246 : check e2422374888246 [[],[]] .smaller = true := by decide
def e2422374888250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374888250 : Closed e2422374888250 ∧ code e2422374888250 = 11218467910458 := by decide
theorem cert_e2422374888250 : check e2422374888250 [[],[]] .smaller = true := by decide
def e2422374888322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422374888322 : Closed e2422374888322 ∧ code e2422374888322 = 11218467910530 := by decide
theorem cert_e2422374888322 : check e2422374888322 [[],[]] .smaller = true := by decide
def e2422374888334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422374888334 : Closed e2422374888334 ∧ code e2422374888334 = 11218467910542 := by decide
theorem cert_e2422374888334 : check e2422374888334 [[],[]] .smaller = true := by decide
def e2422374888346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374888346 : Closed e2422374888346 ∧ code e2422374888346 = 11218467910554 := by decide
theorem cert_e2422374888346 : check e2422374888346 [[],[]] .smaller = true := by decide
def e2422374888414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422374888414 : Closed e2422374888414 ∧ code e2422374888414 = 11218467910622 := by decide
theorem cert_e2422374888414 : check e2422374888414 [[],[]] .three = true := by decide
def e2422374888418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422374888418 : Closed e2422374888418 ∧ code e2422374888418 = 11218467910626 := by decide
theorem cert_e2422374888418 : check e2422374888418 [[],[]] .three = true := by decide
def e2422374888430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422374888430 : Closed e2422374888430 ∧ code e2422374888430 = 11218467910638 := by decide
theorem cert_e2422374888430 : check e2422374888430 [[],[]] .three = true := by decide
def e2422374889534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422374889534 : Closed e2422374889534 ∧ code e2422374889534 = 11218467911742 := by decide
theorem cert_e2422374889534 : check e2422374889534 [[],[]] .three = true := by decide
def e2422374889582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374889582 : Closed e2422374889582 ∧ code e2422374889582 = 11218467911790 := by decide
theorem cert_e2422374889582 : check e2422374889582 [[],[]] .three = true := by decide
def e2422374889594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374889594 : Closed e2422374889594 ∧ code e2422374889594 = 11218467911802 := by decide
theorem cert_e2422374889594 : check e2422374889594 [[],[]] .three = true := by decide
def e2422374889870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422374889870 : Closed e2422374889870 ∧ code e2422374889870 = 11218467912078 := by decide
theorem cert_e2422374889870 : check e2422374889870 [[],[]] .three = true := by decide
def e2422374889926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422374889926 : Closed e2422374889926 ∧ code e2422374889926 = 11218467912134 := by decide
theorem cert_e2422374889926 : check e2422374889926 [[],[]] .three = true := by decide
def e2422374889950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422374889950 : Closed e2422374889950 ∧ code e2422374889950 = 11218467912158 := by decide
theorem cert_e2422374889950 : check e2422374889950 [[],[]] .three = true := by decide
def e2422374889954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422374889954 : Closed e2422374889954 ∧ code e2422374889954 = 11218467912162 := by decide
theorem cert_e2422374889954 : check e2422374889954 [[],[]] .three = true := by decide
def e2422374889966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422374889966 : Closed e2422374889966 ∧ code e2422374889966 = 11218467912174 := by decide
theorem cert_e2422374889966 : check e2422374889966 [[],[]] .three = true := by decide
def e2422374889974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422374889974 : Closed e2422374889974 ∧ code e2422374889974 = 11218467912182 := by decide
theorem cert_e2422374889974 : check e2422374889974 [[],[]] .three = true := by decide
def e2422374891950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2))))))))
theorem wire_e2422374891950 : Closed e2422374891950 ∧ code e2422374891950 = 11218467914158 := by decide
theorem cert_e2422374891950 : check e2422374891950 [[],[]] .smaller = true := by decide
def e2422374892142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374892142 : Closed e2422374892142 ∧ code e2422374892142 = 11218467914350 := by decide
theorem cert_e2422374892142 : check e2422374892142 [[],[]] .smaller = true := by decide
def e2422374892154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374892154 : Closed e2422374892154 ∧ code e2422374892154 = 11218467914362 := by decide
theorem cert_e2422374892154 : check e2422374892154 [[],[]] .smaller = true := by decide
def e2422374892510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 3))))))))
theorem wire_e2422374892510 : Closed e2422374892510 ∧ code e2422374892510 = 11218467914718 := by decide
theorem cert_e2422374892510 : check e2422374892510 [[],[]] .three = true := by decide
def e2422374892526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 2))))))))
theorem wire_e2422374892526 : Closed e2422374892526 ∧ code e2422374892526 = 11218467914734 := by decide
theorem cert_e2422374892526 : check e2422374892526 [[],[]] .smaller = true := by decide
def e2422374892534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.var 1))))))))
theorem wire_e2422374892534 : Closed e2422374892534 ∧ code e2422374892534 = 11218467914742 := by decide
theorem cert_e2422374892534 : check e2422374892534 [[],[]] .three = true := by decide
def e2422374893278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 3))))))))
theorem wire_e2422374893278 : Closed e2422374893278 ∧ code e2422374893278 = 11218467915486 := by decide
theorem cert_e2422374893278 : check e2422374893278 [[],[]] .three = true := by decide
def e2422374893294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))))
theorem wire_e2422374893294 : Closed e2422374893294 ∧ code e2422374893294 = 11218467915502 := by decide
theorem cert_e2422374893294 : check e2422374893294 [[],[]] .smaller = true := by decide
def e2422374893302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))))
theorem wire_e2422374893302 : Closed e2422374893302 ∧ code e2422374893302 = 11218467915510 := by decide
theorem cert_e2422374893302 : check e2422374893302 [[],[]] .smaller = true := by decide
def e2422374893306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 4)))) (.var 0))))))))
theorem wire_e2422374893306 : Closed e2422374893306 ∧ code e2422374893306 = 11218467915514 := by decide
theorem cert_e2422374893306 : check e2422374893306 [[],[]] .three = true := by decide
def e2422374893406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 3))))))))
theorem wire_e2422374893406 : Closed e2422374893406 ∧ code e2422374893406 = 11218467915614 := by decide
theorem cert_e2422374893406 : check e2422374893406 [[],[]] .three = true := by decide
def e2422374893422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e2422374893422 : Closed e2422374893422 ∧ code e2422374893422 = 11218467915630 := by decide
theorem cert_e2422374893422 : check e2422374893422 [[],[]] .smaller = true := by decide
def e2422374893434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e2422374893434 : Closed e2422374893434 ∧ code e2422374893434 = 11218467915642 := by decide
theorem cert_e2422374893434 : check e2422374893434 [[],[]] .smaller = true := by decide
def e2422374893486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))))
theorem wire_e2422374893486 : Closed e2422374893486 ∧ code e2422374893486 = 11218467915694 := by decide
theorem cert_e2422374893486 : check e2422374893486 [[],[]] .smaller = true := by decide
def e2422374893526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))))
theorem wire_e2422374893526 : Closed e2422374893526 ∧ code e2422374893526 = 11218467915734 := by decide
theorem cert_e2422374893526 : check e2422374893526 [[],[]] .smaller = true := by decide
def e2422374893530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e2422374893530 : Closed e2422374893530 ∧ code e2422374893530 = 11218467915738 := by decide
theorem cert_e2422374893530 : check e2422374893530 [[],[]] .smaller = true := by decide
def e2422374893546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 4) (.var 0)))) (.var 0))))))))
theorem wire_e2422374893546 : Closed e2422374893546 ∧ code e2422374893546 = 11218467915754 := by decide
theorem cert_e2422374893546 : check e2422374893546 [[],[]] .three = true := by decide
def e2422374894046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422374894046 : Closed e2422374894046 ∧ code e2422374894046 = 11218467916254 := by decide
theorem cert_e2422374894046 : check e2422374894046 [[],[]] .three = true := by decide
def e2422374894062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422374894062 : Closed e2422374894062 ∧ code e2422374894062 = 11218467916270 := by decide
theorem cert_e2422374894062 : check e2422374894062 [[],[]] .smaller = true := by decide
def e2422374894070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422374894070 : Closed e2422374894070 ∧ code e2422374894070 = 11218467916278 := by decide
theorem cert_e2422374894070 : check e2422374894070 [[],[]] .three = true := by decide
def e2422374894814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422374894814 : Closed e2422374894814 ∧ code e2422374894814 = 11218467917022 := by decide
theorem cert_e2422374894814 : check e2422374894814 [[],[]] .three = true := by decide
def e2422374894830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374894830 : Closed e2422374894830 ∧ code e2422374894830 = 11218467917038 := by decide
theorem cert_e2422374894830 : check e2422374894830 [[],[]] .smaller = true := by decide
def e2422374894838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374894838 : Closed e2422374894838 ∧ code e2422374894838 = 11218467917046 := by decide
theorem cert_e2422374894838 : check e2422374894838 [[],[]] .smaller = true := by decide
def e2422374894842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422374894842 : Closed e2422374894842 ∧ code e2422374894842 = 11218467917050 := by decide
theorem cert_e2422374894842 : check e2422374894842 [[],[]] .three = true := by decide
def e2422374895166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 4)))))))))
theorem wire_e2422374895166 : Closed e2422374895166 ∧ code e2422374895166 = 11218467917374 := by decide
theorem cert_e2422374895166 : check e2422374895166 [[],[]] .three = true := by decide
def e2422374895214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374895214 : Closed e2422374895214 ∧ code e2422374895214 = 11218467917422 := by decide
theorem cert_e2422374895214 : check e2422374895214 [[],[]] .smaller = true := by decide
def e2422374895226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374895226 : Closed e2422374895226 ∧ code e2422374895226 = 11218467917434 := by decide
theorem cert_e2422374895226 : check e2422374895226 [[],[]] .smaller = true := by decide
def e2422374895390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 3)))))))))
theorem wire_e2422374895390 : Closed e2422374895390 ∧ code e2422374895390 = 11218467917598 := by decide
theorem cert_e2422374895390 : check e2422374895390 [[],[]] .smaller = true := by decide
def e2422374895414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374895414 : Closed e2422374895414 ∧ code e2422374895414 = 11218467917622 := by decide
theorem cert_e2422374895414 : check e2422374895414 [[],[]] .smaller = true := by decide
def e2422374895418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374895418 : Closed e2422374895418 ∧ code e2422374895418 = 11218467917626 := by decide
theorem cert_e2422374895418 : check e2422374895418 [[],[]] .smaller = true := by decide
def e2422374895502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.lam (.var 2)))))))))
theorem wire_e2422374895502 : Closed e2422374895502 ∧ code e2422374895502 = 11218467917710 := by decide
theorem cert_e2422374895502 : check e2422374895502 [[],[]] .three = true := by decide
def e2422374895514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374895514 : Closed e2422374895514 ∧ code e2422374895514 = 11218467917722 := by decide
theorem cert_e2422374895514 : check e2422374895514 [[],[]] .three = true := by decide
def e2422374897326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e2422374897326 : Closed e2422374897326 ∧ code e2422374897326 = 11218467919534 := by decide
theorem cert_e2422374897326 : check e2422374897326 [[],[]] .smaller = true := by decide
def e2422374897338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e2422374897338 : Closed e2422374897338 ∧ code e2422374897338 = 11218467919546 := by decide
theorem cert_e2422374897338 : check e2422374897338 [[],[]] .smaller = true := by decide
def e2422374897386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e2422374897386 : Closed e2422374897386 ∧ code e2422374897386 = 11218467919594 := by decide
theorem cert_e2422374897386 : check e2422374897386 [[],[]] .smaller = true := by decide
def e2422374897578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422374897578 : Closed e2422374897578 ∧ code e2422374897578 = 11218467919786 := by decide
theorem cert_e2422374897578 : check e2422374897578 [[],[]] .smaller = true := by decide
def e2422374897710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2))))))))
theorem wire_e2422374897710 : Closed e2422374897710 ∧ code e2422374897710 = 11218467919918 := by decide
theorem cert_e2422374897710 : check e2422374897710 [[],[]] .smaller = true := by decide
def e2422374897886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 3))))))))
theorem wire_e2422374897886 : Closed e2422374897886 ∧ code e2422374897886 = 11218467920094 := by decide
theorem cert_e2422374897886 : check e2422374897886 [[],[]] .three = true := by decide
def e2422374897902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2422374897902 : Closed e2422374897902 ∧ code e2422374897902 = 11218467920110 := by decide
theorem cert_e2422374897902 : check e2422374897902 [[],[]] .smaller = true := by decide
def e2422374897910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e2422374897910 : Closed e2422374897910 ∧ code e2422374897910 = 11218467920118 := by decide
theorem cert_e2422374897910 : check e2422374897910 [[],[]] .smaller = true := by decide
def e2422374897914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 0))))))))
theorem wire_e2422374897914 : Closed e2422374897914 ∧ code e2422374897914 = 11218467920122 := by decide
theorem cert_e2422374897914 : check e2422374897914 [[],[]] .three = true := by decide
def e2422374898094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422374898094 : Closed e2422374898094 ∧ code e2422374898094 = 11218467920302 := by decide
theorem cert_e2422374898094 : check e2422374898094 [[],[]] .smaller = true := by decide
def e2422374898106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422374898106 : Closed e2422374898106 ∧ code e2422374898106 = 11218467920314 := by decide
theorem cert_e2422374898106 : check e2422374898106 [[],[]] .smaller = true := by decide
def e2422374898154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422374898154 : Closed e2422374898154 ∧ code e2422374898154 = 11218467920362 := by decide
theorem cert_e2422374898154 : check e2422374898154 [[],[]] .smaller = true := by decide
def e2422374898238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 4)))))))))
theorem wire_e2422374898238 : Closed e2422374898238 ∧ code e2422374898238 = 11218467920446 := by decide
theorem cert_e2422374898238 : check e2422374898238 [[],[]] .three = true := by decide
def e2422374898286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374898286 : Closed e2422374898286 ∧ code e2422374898286 = 11218467920494 := by decide
theorem cert_e2422374898286 : check e2422374898286 [[],[]] .smaller = true := by decide
def e2422374898298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374898298 : Closed e2422374898298 ∧ code e2422374898298 = 11218467920506 := by decide
theorem cert_e2422374898298 : check e2422374898298 [[],[]] .smaller = true := by decide
def e2422374898462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2422374898462 : Closed e2422374898462 ∧ code e2422374898462 = 11218467920670 := by decide
theorem cert_e2422374898462 : check e2422374898462 [[],[]] .smaller = true := by decide
def e2422374898562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374898562 : Closed e2422374898562 ∧ code e2422374898562 = 11218467920770 := by decide
theorem cert_e2422374898562 : check e2422374898562 [[],[]] .smaller = true := by decide
def e2422374898574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e2422374898574 : Closed e2422374898574 ∧ code e2422374898574 = 11218467920782 := by decide
theorem cert_e2422374898574 : check e2422374898574 [[],[]] .smaller = true := by decide
def e2422374898586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374898586 : Closed e2422374898586 ∧ code e2422374898586 = 11218467920794 := by decide
theorem cert_e2422374898586 : check e2422374898586 [[],[]] .smaller = true := by decide
def e2422374898630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 1)))))))))
theorem wire_e2422374898630 : Closed e2422374898630 ∧ code e2422374898630 = 11218467920838 := by decide
theorem cert_e2422374898630 : check e2422374898630 [[],[]] .three = true := by decide
def e2422374898654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 3))))))))
theorem wire_e2422374898654 : Closed e2422374898654 ∧ code e2422374898654 = 11218467920862 := by decide
theorem cert_e2422374898654 : check e2422374898654 [[],[]] .three = true := by decide
def e2422374898782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e2422374898782 : Closed e2422374898782 ∧ code e2422374898782 = 11218467920990 := by decide
theorem cert_e2422374898782 : check e2422374898782 [[],[]] .three = true := by decide
def e2422374898798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e2422374898798 : Closed e2422374898798 ∧ code e2422374898798 = 11218467921006 := by decide
theorem cert_e2422374898798 : check e2422374898798 [[],[]] .smaller = true := by decide
def e2422374898810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422374898810 : Closed e2422374898810 ∧ code e2422374898810 = 11218467921018 := by decide
theorem cert_e2422374898810 : check e2422374898810 [[],[]] .smaller = true := by decide
def e2422374898974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e2422374898974 : Closed e2422374898974 ∧ code e2422374898974 = 11218467921182 := by decide
theorem cert_e2422374898974 : check e2422374898974 [[],[]] .smaller = true := by decide
def e2422374899142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422374899142 : Closed e2422374899142 ∧ code e2422374899142 = 11218467921350 := by decide
theorem cert_e2422374899142 : check e2422374899142 [[],[]] .smaller = true := by decide
def e2422374899166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e2422374899166 : Closed e2422374899166 ∧ code e2422374899166 = 11218467921374 := by decide
theorem cert_e2422374899166 : check e2422374899166 [[],[]] .three = true := by decide
def e2422374899170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e2422374899170 : Closed e2422374899170 ∧ code e2422374899170 = 11218467921378 := by decide
theorem cert_e2422374899170 : check e2422374899170 [[],[]] .three = true := by decide
def e2422374899182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e2422374899182 : Closed e2422374899182 ∧ code e2422374899182 = 11218467921390 := by decide
theorem cert_e2422374899182 : check e2422374899182 [[],[]] .three = true := by decide
def e2422374899210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422374899210 : Closed e2422374899210 ∧ code e2422374899210 = 11218467921418 := by decide
theorem cert_e2422374899210 : check e2422374899210 [[],[]] .smaller = true := by decide
def e2422374899246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422374899246 : Closed e2422374899246 ∧ code e2422374899246 = 11218467921454 := by decide
theorem cert_e2422374899246 : check e2422374899246 [[],[]] .smaller = true := by decide
def e2422374899254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422374899254 : Closed e2422374899254 ∧ code e2422374899254 = 11218467921462 := by decide
theorem cert_e2422374899254 : check e2422374899254 [[],[]] .smaller = true := by decide
def e2422374899258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422374899258 : Closed e2422374899258 ∧ code e2422374899258 = 11218467921466 := by decide
theorem cert_e2422374899258 : check e2422374899258 [[],[]] .smaller = true := by decide
def e2422374899306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422374899306 : Closed e2422374899306 ∧ code e2422374899306 = 11218467921514 := by decide
theorem cert_e2422374899306 : check e2422374899306 [[],[]] .smaller = true := by decide
def e2422374899330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374899330 : Closed e2422374899330 ∧ code e2422374899330 = 11218467921538 := by decide
theorem cert_e2422374899330 : check e2422374899330 [[],[]] .smaller = true := by decide
def e2422374899342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422374899342 : Closed e2422374899342 ∧ code e2422374899342 = 11218467921550 := by decide
theorem cert_e2422374899342 : check e2422374899342 [[],[]] .smaller = true := by decide
def e2422374899354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374899354 : Closed e2422374899354 ∧ code e2422374899354 = 11218467921562 := by decide
theorem cert_e2422374899354 : check e2422374899354 [[],[]] .smaller = true := by decide
def e2422374899398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422374899398 : Closed e2422374899398 ∧ code e2422374899398 = 11218467921606 := by decide
theorem cert_e2422374899398 : check e2422374899398 [[],[]] .smaller = true := by decide
def e2422374899422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e2422374899422 : Closed e2422374899422 ∧ code e2422374899422 = 11218467921630 := by decide
theorem cert_e2422374899422 : check e2422374899422 [[],[]] .three = true := by decide
def e2422374899426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422374899426 : Closed e2422374899426 ∧ code e2422374899426 = 11218467921634 := by decide
theorem cert_e2422374899426 : check e2422374899426 [[],[]] .smaller = true := by decide
def e2422374899438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 2))))))))
theorem wire_e2422374899438 : Closed e2422374899438 ∧ code e2422374899438 = 11218467921646 := by decide
theorem cert_e2422374899438 : check e2422374899438 [[],[]] .smaller = true := by decide
def e2422374899446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e2422374899446 : Closed e2422374899446 ∧ code e2422374899446 = 11218467921654 := by decide
theorem cert_e2422374899446 : check e2422374899446 [[],[]] .three = true := by decide
def e2422374899478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422374899478 : Closed e2422374899478 ∧ code e2422374899478 = 11218467921686 := by decide
theorem cert_e2422374899478 : check e2422374899478 [[],[]] .three = true := by decide
def e2422374899482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422374899482 : Closed e2422374899482 ∧ code e2422374899482 = 11218467921690 := by decide
theorem cert_e2422374899482 : check e2422374899482 [[],[]] .three = true := by decide
def e2422374899526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422374899526 : Closed e2422374899526 ∧ code e2422374899526 = 11218467921734 := by decide
theorem cert_e2422374899526 : check e2422374899526 [[],[]] .three = true := by decide
def e2422374899550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 3))))))))
theorem wire_e2422374899550 : Closed e2422374899550 ∧ code e2422374899550 = 11218467921758 := by decide
theorem cert_e2422374899550 : check e2422374899550 [[],[]] .three = true := by decide
def e2422374899554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422374899554 : Closed e2422374899554 ∧ code e2422374899554 = 11218467921762 := by decide
theorem cert_e2422374899554 : check e2422374899554 [[],[]] .three = true := by decide
def e2422374899566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e2422374899566 : Closed e2422374899566 ∧ code e2422374899566 = 11218467921774 := by decide
theorem cert_e2422374899566 : check e2422374899566 [[],[]] .three = true := by decide
def e2422374899574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e2422374899574 : Closed e2422374899574 ∧ code e2422374899574 = 11218467921782 := by decide
theorem cert_e2422374899574 : check e2422374899574 [[],[]] .three = true := by decide
def e2422374899578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 0))))))))
theorem wire_e2422374899578 : Closed e2422374899578 ∧ code e2422374899578 = 11218467921786 := by decide
theorem cert_e2422374899578 : check e2422374899578 [[],[]] .three = true := by decide
def e2422374900158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 4))))))))))
theorem wire_e2422374900158 : Closed e2422374900158 ∧ code e2422374900158 = 11218467922366 := by decide
theorem cert_e2422374900158 : check e2422374900158 [[],[]] .three = true := by decide
def e2422374900190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422374900190 : Closed e2422374900190 ∧ code e2422374900190 = 11218467922398 := by decide
theorem cert_e2422374900190 : check e2422374900190 [[],[]] .smaller = true := by decide
def e2422374900214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422374900214 : Closed e2422374900214 ∧ code e2422374900214 = 11218467922422 := by decide
theorem cert_e2422374900214 : check e2422374900214 [[],[]] .smaller = true := by decide
def e2422374900218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 4) (.var 0))))))))))
theorem wire_e2422374900218 : Closed e2422374900218 ∧ code e2422374900218 = 11218467922426 := by decide
theorem cert_e2422374900218 : check e2422374900218 [[],[]] .three = true := by decide
def e2422374901166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422374901166 : Closed e2422374901166 ∧ code e2422374901166 = 11218467923374 := by decide
theorem cert_e2422374901166 : check e2422374901166 [[],[]] .smaller = true := by decide
def e2422374901178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422374901178 : Closed e2422374901178 ∧ code e2422374901178 = 11218467923386 := by decide
theorem cert_e2422374901178 : check e2422374901178 [[],[]] .smaller = true := by decide
def e2422374901226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422374901226 : Closed e2422374901226 ∧ code e2422374901226 = 11218467923434 := by decide
theorem cert_e2422374901226 : check e2422374901226 [[],[]] .smaller = true := by decide
def e2422374901310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2422374901310 : Closed e2422374901310 ∧ code e2422374901310 = 11218467923518 := by decide
theorem cert_e2422374901310 : check e2422374901310 [[],[]] .three = true := by decide
def e2422374901358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374901358 : Closed e2422374901358 ∧ code e2422374901358 = 11218467923566 := by decide
theorem cert_e2422374901358 : check e2422374901358 [[],[]] .smaller = true := by decide
def e2422374901370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374901370 : Closed e2422374901370 ∧ code e2422374901370 = 11218467923578 := by decide
theorem cert_e2422374901370 : check e2422374901370 [[],[]] .smaller = true := by decide
def e2422374901534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422374901534 : Closed e2422374901534 ∧ code e2422374901534 = 11218467923742 := by decide
theorem cert_e2422374901534 : check e2422374901534 [[],[]] .smaller = true := by decide
def e2422374901634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422374901634 : Closed e2422374901634 ∧ code e2422374901634 = 11218467923842 := by decide
theorem cert_e2422374901634 : check e2422374901634 [[],[]] .smaller = true := by decide
def e2422374901646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422374901646 : Closed e2422374901646 ∧ code e2422374901646 = 11218467923854 := by decide
theorem cert_e2422374901646 : check e2422374901646 [[],[]] .smaller = true := by decide
def e2422374901658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374901658 : Closed e2422374901658 ∧ code e2422374901658 = 11218467923866 := by decide
theorem cert_e2422374901658 : check e2422374901658 [[],[]] .smaller = true := by decide
def e2422374901702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2422374901702 : Closed e2422374901702 ∧ code e2422374901702 = 11218467923910 := by decide
theorem cert_e2422374901702 : check e2422374901702 [[],[]] .three = true := by decide
def e2422374901726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 3)))))))))
theorem wire_e2422374901726 : Closed e2422374901726 ∧ code e2422374901726 = 11218467923934 := by decide
theorem cert_e2422374901726 : check e2422374901726 [[],[]] .three = true := by decide
def e2422374903934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 5))))))))))
theorem wire_e2422374903934 : Closed e2422374903934 ∧ code e2422374903934 = 11218467926142 := by decide
theorem cert_e2422374903934 : check e2422374903934 [[],[]] .three = true := by decide
def e2422374904030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2422374904030 : Closed e2422374904030 ∧ code e2422374904030 = 11218467926238 := by decide
theorem cert_e2422374904030 : check e2422374904030 [[],[]] .smaller = true := by decide
def e2422374904058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2422374904058 : Closed e2422374904058 ∧ code e2422374904058 = 11218467926266 := by decide
theorem cert_e2422374904058 : check e2422374904058 [[],[]] .smaller = true := by decide
def e2422374904606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422374904606 : Closed e2422374904606 ∧ code e2422374904606 = 11218467926814 := by decide
theorem cert_e2422374904606 : check e2422374904606 [[],[]] .smaller = true := by decide
def e2422374904774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422374904774 : Closed e2422374904774 ∧ code e2422374904774 = 11218467926982 := by decide
theorem cert_e2422374904774 : check e2422374904774 [[],[]] .smaller = true := by decide
def e2422374904798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422374904798 : Closed e2422374904798 ∧ code e2422374904798 = 11218467927006 := by decide
theorem cert_e2422374904798 : check e2422374904798 [[],[]] .three = true := by decide
def e2422374904802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422374904802 : Closed e2422374904802 ∧ code e2422374904802 = 11218467927010 := by decide
theorem cert_e2422374904802 : check e2422374904802 [[],[]] .three = true := by decide
def e2422374904814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422374904814 : Closed e2422374904814 ∧ code e2422374904814 = 11218467927022 := by decide
theorem cert_e2422374904814 : check e2422374904814 [[],[]] .three = true := by decide
def e2422374905882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374905882 : Closed e2422374905882 ∧ code e2422374905882 = 11218467928090 := by decide
theorem cert_e2422374905882 : check e2422374905882 [[],[]] .smaller = true := by decide
def e2422374905918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422374905918 : Closed e2422374905918 ∧ code e2422374905918 = 11218467928126 := by decide
theorem cert_e2422374905918 : check e2422374905918 [[],[]] .smaller = true := by decide
def e2422374905966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374905966 : Closed e2422374905966 ∧ code e2422374905966 = 11218467928174 := by decide
theorem cert_e2422374905966 : check e2422374905966 [[],[]] .smaller = true := by decide
def e2422374905974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422374905974 : Closed e2422374905974 ∧ code e2422374905974 = 11218467928182 := by decide
theorem cert_e2422374905974 : check e2422374905974 [[],[]] .smaller = true := by decide
def e2422374905978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374905978 : Closed e2422374905978 ∧ code e2422374905978 = 11218467928186 := by decide
theorem cert_e2422374905978 : check e2422374905978 [[],[]] .smaller = true := by decide
def e2422374906218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422374906218 : Closed e2422374906218 ∧ code e2422374906218 = 11218467928426 := by decide
theorem cert_e2422374906218 : check e2422374906218 [[],[]] .smaller = true := by decide
def e2422374906242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422374906242 : Closed e2422374906242 ∧ code e2422374906242 = 11218467928450 := by decide
theorem cert_e2422374906242 : check e2422374906242 [[],[]] .smaller = true := by decide
def e2422374906254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422374906254 : Closed e2422374906254 ∧ code e2422374906254 = 11218467928462 := by decide
theorem cert_e2422374906254 : check e2422374906254 [[],[]] .smaller = true := by decide
def e2422374906266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374906266 : Closed e2422374906266 ∧ code e2422374906266 = 11218467928474 := by decide
theorem cert_e2422374906266 : check e2422374906266 [[],[]] .smaller = true := by decide
def e2422374906310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422374906310 : Closed e2422374906310 ∧ code e2422374906310 = 11218467928518 := by decide
theorem cert_e2422374906310 : check e2422374906310 [[],[]] .smaller = true := by decide
def e2422374906334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422374906334 : Closed e2422374906334 ∧ code e2422374906334 = 11218467928542 := by decide
theorem cert_e2422374906334 : check e2422374906334 [[],[]] .three = true := by decide
def e2422374906338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422374906338 : Closed e2422374906338 ∧ code e2422374906338 = 11218467928546 := by decide
theorem cert_e2422374906338 : check e2422374906338 [[],[]] .smaller = true := by decide
def e2422374906350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422374906350 : Closed e2422374906350 ∧ code e2422374906350 = 11218467928558 := by decide
theorem cert_e2422374906350 : check e2422374906350 [[],[]] .smaller = true := by decide
def e2422374906358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422374906358 : Closed e2422374906358 ∧ code e2422374906358 = 11218467928566 := by decide
theorem cert_e2422374906358 : check e2422374906358 [[],[]] .three = true := by decide
def e2422374906910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422374906910 : Closed e2422374906910 ∧ code e2422374906910 = 11218467929118 := by decide
theorem cert_e2422374906910 : check e2422374906910 [[],[]] .three = true := by decide
def e2422374906934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374906934 : Closed e2422374906934 ∧ code e2422374906934 = 11218467929142 := by decide
theorem cert_e2422374906934 : check e2422374906934 [[],[]] .three = true := by decide
def e2422374906938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374906938 : Closed e2422374906938 ∧ code e2422374906938 = 11218467929146 := by decide
theorem cert_e2422374906938 : check e2422374906938 [[],[]] .three = true := by decide
def e2422374907078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422374907078 : Closed e2422374907078 ∧ code e2422374907078 = 11218467929286 := by decide
theorem cert_e2422374907078 : check e2422374907078 [[],[]] .three = true := by decide
def e2422374907102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422374907102 : Closed e2422374907102 ∧ code e2422374907102 = 11218467929310 := by decide
theorem cert_e2422374907102 : check e2422374907102 [[],[]] .three = true := by decide
def e2422374907106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422374907106 : Closed e2422374907106 ∧ code e2422374907106 = 11218467929314 := by decide
theorem cert_e2422374907106 : check e2422374907106 [[],[]] .three = true := by decide
end Blc.Floor43
