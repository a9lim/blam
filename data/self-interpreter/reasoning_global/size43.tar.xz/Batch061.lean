import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e756110958954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756110958954 : Closed e756110958954 ∧ code e756110958954 = 9552203981162 := by decide
theorem cert_e756110958954 : check e756110958954 [] .sourceHead = true := by decide
def e756110959002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756110959002 : Closed e756110959002 ∧ code e756110959002 = 9552203981210 := by decide
theorem cert_e756110959002 : check e756110959002 [] .sourceHead = true := by decide
def e756110960154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756110960154 : Closed e756110960154 ∧ code e756110960154 = 9552203982362 := by decide
theorem cert_e756110960154 : check e756110960154 [] .sourceHead = true := by decide
def e756110962886 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756110962886 : Closed e756110962886 ∧ code e756110962886 = 9552203985094 := by decide
theorem cert_e756110962886 : check e756110962886 [] .sourceHead = true := by decide
def e756110964762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756110964762 : Closed e756110964762 ∧ code e756110964762 = 9552203986970 := by decide
theorem cert_e756110964762 : check e756110964762 [] .sourceHead = true := by decide
def e756110968346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756110968346 : Closed e756110968346 ∧ code e756110968346 = 9552203990554 := by decide
theorem cert_e756110968346 : check e756110968346 [] .sourceHead = true := by decide
def e756110971078 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756110971078 : Closed e756110971078 ∧ code e756110971078 = 9552203993286 := by decide
theorem cert_e756110971078 : check e756110971078 [] .sourceHead = true := by decide
def e756110977050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756110977050 : Closed e756110977050 ∧ code e756110977050 = 9552203999258 := by decide
theorem cert_e756110977050 : check e756110977050 [] .sourceHead = true := by decide
def e756111619610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756111619610 : Closed e756111619610 ∧ code e756111619610 = 9552204641818 := by decide
theorem cert_e756111619610 : check e756111619610 [] .sourceHead = true := by decide
def e756111620634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756111620634 : Closed e756111620634 ∧ code e756111620634 = 9552204642842 := by decide
theorem cert_e756111620634 : check e756111620634 [] .sourceHead = true := by decide
def e756111628826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756111628826 : Closed e756111628826 ∧ code e756111628826 = 9552204651034 := by decide
theorem cert_e756111628826 : check e756111628826 [] .sourceHead = true := by decide
def e756111799834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756111799834 : Closed e756111799834 ∧ code e756111799834 = 9552204822042 := by decide
theorem cert_e756111799834 : check e756111799834 [] .sourceHead = true := by decide
def e756111848986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756111848986 : Closed e756111848986 ∧ code e756111848986 = 9552204871194 := by decide
theorem cert_e756111848986 : check e756111848986 [] .sourceHead = true := by decide
def e756111850010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756111850010 : Closed e756111850010 ∧ code e756111850010 = 9552204872218 := by decide
theorem cert_e756111850010 : check e756111850010 [] .sourceHead = true := by decide
def e756112119322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112119322 : Closed e756112119322 ∧ code e756112119322 = 9552205141530 := by decide
theorem cert_e756112119322 : check e756112119322 [] .sourceHead = true := by decide
def e756112120346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112120346 : Closed e756112120346 ∧ code e756112120346 = 9552205142554 := by decide
theorem cert_e756112120346 : check e756112120346 [] .sourceHead = true := by decide
def e756112124442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112124442 : Closed e756112124442 ∧ code e756112124442 = 9552205146650 := by decide
theorem cert_e756112124442 : check e756112124442 [] .sourceHead = true := by decide
def e756112140826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112140826 : Closed e756112140826 ∧ code e756112140826 = 9552205163034 := by decide
theorem cert_e756112140826 : check e756112140826 [] .sourceHead = true := by decide
def e756112193050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112193050 : Closed e756112193050 ∧ code e756112193050 = 9552205215258 := by decide
theorem cert_e756112193050 : check e756112193050 [] .sourceHead = true := by decide
def e756112217626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112217626 : Closed e756112217626 ∧ code e756112217626 = 9552205239834 := by decide
theorem cert_e756112217626 : check e756112217626 [] .sourceHead = true := by decide
def e756112218650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112218650 : Closed e756112218650 ∧ code e756112218650 = 9552205240858 := by decide
theorem cert_e756112218650 : check e756112218650 [] .sourceHead = true := by decide
def e756112222746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112222746 : Closed e756112222746 ∧ code e756112222746 = 9552205244954 := by decide
theorem cert_e756112222746 : check e756112222746 [] .sourceHead = true := by decide
def e756112242202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112242202 : Closed e756112242202 ∧ code e756112242202 = 9552205264410 := by decide
theorem cert_e756112242202 : check e756112242202 [] .sourceHead = true := by decide
def e756112243226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112243226 : Closed e756112243226 ∧ code e756112243226 = 9552205265434 := by decide
theorem cert_e756112243226 : check e756112243226 [] .sourceHead = true := by decide
def e756112252954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756112252954 : Closed e756112252954 ∧ code e756112252954 = 9552205275162 := by decide
theorem cert_e756112252954 : check e756112252954 [] .sourceHead = true := by decide
def e756112253046 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756112253046 : Closed e756112253046 ∧ code e756112253046 = 9552205275254 := by decide
theorem cert_e756112253046 : check e756112253046 [] .sourceHead = true := by decide
def e756112253290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756112253290 : Closed e756112253290 ∧ code e756112253290 = 9552205275498 := by decide
theorem cert_e756112253290 : check e756112253290 [] .sourceHead = true := by decide
def e756112253338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756112253338 : Closed e756112253338 ∧ code e756112253338 = 9552205275546 := by decide
theorem cert_e756112253338 : check e756112253338 [] .sourceHead = true := by decide
def e756112254490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112254490 : Closed e756112254490 ∧ code e756112254490 = 9552205276698 := by decide
theorem cert_e756112254490 : check e756112254490 [] .sourceHead = true := by decide
def e756112264730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112264730 : Closed e756112264730 ∧ code e756112264730 = 9552205286938 := by decide
theorem cert_e756112264730 : check e756112264730 [] .sourceHead = true := by decide
def e756112267802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112267802 : Closed e756112267802 ∧ code e756112267802 = 9552205290010 := by decide
theorem cert_e756112267802 : check e756112267802 [] .sourceHead = true := by decide
def e756112269338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756112269338 : Closed e756112269338 ∧ code e756112269338 = 9552205291546 := by decide
theorem cert_e756112269338 : check e756112269338 [] .sourceHead = true := by decide
def e756112269430 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756112269430 : Closed e756112269430 ∧ code e756112269430 = 9552205291638 := by decide
theorem cert_e756112269430 : check e756112269430 [] .sourceHead = true := by decide
def e756112269674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756112269674 : Closed e756112269674 ∧ code e756112269674 = 9552205291882 := by decide
theorem cert_e756112269674 : check e756112269674 [] .sourceHead = true := by decide
def e756112269722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756112269722 : Closed e756112269722 ∧ code e756112269722 = 9552205291930 := by decide
theorem cert_e756112269722 : check e756112269722 [] .sourceHead = true := by decide
def e756112270874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112270874 : Closed e756112270874 ∧ code e756112270874 = 9552205293082 := by decide
theorem cert_e756112270874 : check e756112270874 [] .sourceHead = true := by decide
def e756112273606 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756112273606 : Closed e756112273606 ∧ code e756112273606 = 9552205295814 := by decide
theorem cert_e756112273606 : check e756112273606 [] .sourceHead = true := by decide
def e756112275482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112275482 : Closed e756112275482 ∧ code e756112275482 = 9552205297690 := by decide
theorem cert_e756112275482 : check e756112275482 [] .sourceHead = true := by decide
def e756112283674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112283674 : Closed e756112283674 ∧ code e756112283674 = 9552205305882 := by decide
theorem cert_e756112283674 : check e756112283674 [] .sourceHead = true := by decide
def e756112307738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112307738 : Closed e756112307738 ∧ code e756112307738 = 9552205329946 := by decide
theorem cert_e756112307738 : check e756112307738 [] .sourceHead = true := by decide
def e756112308762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112308762 : Closed e756112308762 ∧ code e756112308762 = 9552205330970 := by decide
theorem cert_e756112308762 : check e756112308762 [] .sourceHead = true := by decide
def e756112321050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112321050 : Closed e756112321050 ∧ code e756112321050 = 9552205343258 := by decide
theorem cert_e756112321050 : check e756112321050 [] .sourceHead = true := by decide
def e756112330266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112330266 : Closed e756112330266 ∧ code e756112330266 = 9552205352474 := by decide
theorem cert_e756112330266 : check e756112330266 [] .sourceHead = true := by decide
def e756112333338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112333338 : Closed e756112333338 ∧ code e756112333338 = 9552205355546 := by decide
theorem cert_e756112333338 : check e756112333338 [] .sourceHead = true := by decide
def e756112334874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756112334874 : Closed e756112334874 ∧ code e756112334874 = 9552205357082 := by decide
theorem cert_e756112334874 : check e756112334874 [] .sourceHead = true := by decide
def e756112334966 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756112334966 : Closed e756112334966 ∧ code e756112334966 = 9552205357174 := by decide
theorem cert_e756112334966 : check e756112334966 [] .sourceHead = true := by decide
def e756112335210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756112335210 : Closed e756112335210 ∧ code e756112335210 = 9552205357418 := by decide
theorem cert_e756112335210 : check e756112335210 [] .sourceHead = true := by decide
def e756112335258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756112335258 : Closed e756112335258 ∧ code e756112335258 = 9552205357466 := by decide
theorem cert_e756112335258 : check e756112335258 [] .sourceHead = true := by decide
def e756112336410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112336410 : Closed e756112336410 ∧ code e756112336410 = 9552205358618 := by decide
theorem cert_e756112336410 : check e756112336410 [] .sourceHead = true := by decide
def e756112339142 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756112339142 : Closed e756112339142 ∧ code e756112339142 = 9552205361350 := by decide
theorem cert_e756112339142 : check e756112339142 [] .sourceHead = true := by decide
def e756112341018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112341018 : Closed e756112341018 ∧ code e756112341018 = 9552205363226 := by decide
theorem cert_e756112341018 : check e756112341018 [] .sourceHead = true := by decide
def e756112344602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112344602 : Closed e756112344602 ∧ code e756112344602 = 9552205366810 := by decide
theorem cert_e756112344602 : check e756112344602 [] .sourceHead = true := by decide
def e756112347334 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756112347334 : Closed e756112347334 ∧ code e756112347334 = 9552205369542 := by decide
theorem cert_e756112347334 : check e756112347334 [] .sourceHead = true := by decide
def e756112353306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112353306 : Closed e756112353306 ∧ code e756112353306 = 9552205375514 := by decide
theorem cert_e756112353306 : check e756112353306 [] .sourceHead = true := by decide
def e756112381978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112381978 : Closed e756112381978 ∧ code e756112381978 = 9552205404186 := by decide
theorem cert_e756112381978 : check e756112381978 [] .sourceHead = true := by decide
def e756112386074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112386074 : Closed e756112386074 ∧ code e756112386074 = 9552205408282 := by decide
theorem cert_e756112386074 : check e756112386074 [] .sourceHead = true := by decide
def e756112485914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112485914 : Closed e756112485914 ∧ code e756112485914 = 9552205508122 := by decide
theorem cert_e756112485914 : check e756112485914 [] .sourceHead = true := by decide
def e756112487962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112487962 : Closed e756112487962 ∧ code e756112487962 = 9552205510170 := by decide
theorem cert_e756112487962 : check e756112487962 [] .sourceHead = true := by decide
def e756112610842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112610842 : Closed e756112610842 ∧ code e756112610842 = 9552205633050 := by decide
theorem cert_e756112610842 : check e756112610842 [] .sourceHead = true := by decide
def e756112611866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112611866 : Closed e756112611866 ∧ code e756112611866 = 9552205634074 := by decide
theorem cert_e756112611866 : check e756112611866 [] .sourceHead = true := by decide
def e756112615962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112615962 : Closed e756112615962 ∧ code e756112615962 = 9552205638170 := by decide
theorem cert_e756112615962 : check e756112615962 [] .sourceHead = true := by decide
def e756112635418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112635418 : Closed e756112635418 ∧ code e756112635418 = 9552205657626 := by decide
theorem cert_e756112635418 : check e756112635418 [] .sourceHead = true := by decide
def e756112636442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112636442 : Closed e756112636442 ∧ code e756112636442 = 9552205658650 := by decide
theorem cert_e756112636442 : check e756112636442 [] .sourceHead = true := by decide
def e756112646170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756112646170 : Closed e756112646170 ∧ code e756112646170 = 9552205668378 := by decide
theorem cert_e756112646170 : check e756112646170 [] .sourceHead = true := by decide
def e756112646262 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756112646262 : Closed e756112646262 ∧ code e756112646262 = 9552205668470 := by decide
theorem cert_e756112646262 : check e756112646262 [] .sourceHead = true := by decide
def e756112646506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756112646506 : Closed e756112646506 ∧ code e756112646506 = 9552205668714 := by decide
theorem cert_e756112646506 : check e756112646506 [] .sourceHead = true := by decide
def e756112646554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756112646554 : Closed e756112646554 ∧ code e756112646554 = 9552205668762 := by decide
theorem cert_e756112646554 : check e756112646554 [] .sourceHead = true := by decide
def e756112647706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112647706 : Closed e756112647706 ∧ code e756112647706 = 9552205669914 := by decide
theorem cert_e756112647706 : check e756112647706 [] .sourceHead = true := by decide
def e756112657946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112657946 : Closed e756112657946 ∧ code e756112657946 = 9552205680154 := by decide
theorem cert_e756112657946 : check e756112657946 [] .sourceHead = true := by decide
def e756112661018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112661018 : Closed e756112661018 ∧ code e756112661018 = 9552205683226 := by decide
theorem cert_e756112661018 : check e756112661018 [] .sourceHead = true := by decide
def e756112662554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756112662554 : Closed e756112662554 ∧ code e756112662554 = 9552205684762 := by decide
theorem cert_e756112662554 : check e756112662554 [] .sourceHead = true := by decide
def e756112662646 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756112662646 : Closed e756112662646 ∧ code e756112662646 = 9552205684854 := by decide
theorem cert_e756112662646 : check e756112662646 [] .sourceHead = true := by decide
def e756112662890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756112662890 : Closed e756112662890 ∧ code e756112662890 = 9552205685098 := by decide
theorem cert_e756112662890 : check e756112662890 [] .sourceHead = true := by decide
def e756112662938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756112662938 : Closed e756112662938 ∧ code e756112662938 = 9552205685146 := by decide
theorem cert_e756112662938 : check e756112662938 [] .sourceHead = true := by decide
def e756112664090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112664090 : Closed e756112664090 ∧ code e756112664090 = 9552205686298 := by decide
theorem cert_e756112664090 : check e756112664090 [] .sourceHead = true := by decide
def e756112666822 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756112666822 : Closed e756112666822 ∧ code e756112666822 = 9552205689030 := by decide
theorem cert_e756112666822 : check e756112666822 [] .sourceHead = true := by decide
def e756112668698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112668698 : Closed e756112668698 ∧ code e756112668698 = 9552205690906 := by decide
theorem cert_e756112668698 : check e756112668698 [] .sourceHead = true := by decide
def e756112676890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756112676890 : Closed e756112676890 ∧ code e756112676890 = 9552205699098 := by decide
theorem cert_e756112676890 : check e756112676890 [] .sourceHead = true := by decide
def e756112979482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756112979482 : Closed e756112979482 ∧ code e756112979482 = 9552206001690 := by decide
theorem cert_e756112979482 : check e756112979482 [] .sourceHead = true := by decide
def e756113041946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756113041946 : Closed e756113041946 ∧ code e756113041946 = 9552206064154 := by decide
theorem cert_e756113041946 : check e756113041946 [] .sourceHead = true := by decide
def e756113051162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756113051162 : Closed e756113051162 ∧ code e756113051162 = 9552206073370 := by decide
theorem cert_e756113051162 : check e756113051162 [] .sourceHead = true := by decide
def e756113054234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756113054234 : Closed e756113054234 ∧ code e756113054234 = 9552206076442 := by decide
theorem cert_e756113054234 : check e756113054234 [] .sourceHead = true := by decide
def e756113055770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756113055770 : Closed e756113055770 ∧ code e756113055770 = 9552206077978 := by decide
theorem cert_e756113055770 : check e756113055770 [] .sourceHead = true := by decide
def e756113055862 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756113055862 : Closed e756113055862 ∧ code e756113055862 = 9552206078070 := by decide
theorem cert_e756113055862 : check e756113055862 [] .sourceHead = true := by decide
def e756113056106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756113056106 : Closed e756113056106 ∧ code e756113056106 = 9552206078314 := by decide
theorem cert_e756113056106 : check e756113056106 [] .sourceHead = true := by decide
def e756113056154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756113056154 : Closed e756113056154 ∧ code e756113056154 = 9552206078362 := by decide
theorem cert_e756113056154 : check e756113056154 [] .sourceHead = true := by decide
def e756113057306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756113057306 : Closed e756113057306 ∧ code e756113057306 = 9552206079514 := by decide
theorem cert_e756113057306 : check e756113057306 [] .sourceHead = true := by decide
def e756113060038 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756113060038 : Closed e756113060038 ∧ code e756113060038 = 9552206082246 := by decide
theorem cert_e756113060038 : check e756113060038 [] .sourceHead = true := by decide
def e756113061914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756113061914 : Closed e756113061914 ∧ code e756113061914 = 9552206084122 := by decide
theorem cert_e756113061914 : check e756113061914 [] .sourceHead = true := by decide
def e756113065498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756113065498 : Closed e756113065498 ∧ code e756113065498 = 9552206087706 := by decide
theorem cert_e756113065498 : check e756113065498 [] .sourceHead = true := by decide
def e756113068230 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756113068230 : Closed e756113068230 ∧ code e756113068230 = 9552206090438 := by decide
theorem cert_e756113068230 : check e756113068230 [] .sourceHead = true := by decide
def e756113074202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756113074202 : Closed e756113074202 ∧ code e756113074202 = 9552206096410 := by decide
theorem cert_e756113074202 : check e756113074202 [] .sourceHead = true := by decide
def e756113266714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756113266714 : Closed e756113266714 ∧ code e756113266714 = 9552206288922 := by decide
theorem cert_e756113266714 : check e756113266714 [] .sourceHead = true := by decide
def e756113270810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756113270810 : Closed e756113270810 ∧ code e756113270810 = 9552206293018 := by decide
theorem cert_e756113270810 : check e756113270810 [] .sourceHead = true := by decide
def e756116319770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116319770 : Closed e756116319770 ∧ code e756116319770 = 9552209341978 := by decide
theorem cert_e756116319770 : check e756116319770 [] .sourceHead = true := by decide
def e756116321818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116321818 : Closed e756116321818 ∧ code e756116321818 = 9552209344026 := by decide
theorem cert_e756116321818 : check e756116321818 [] .sourceHead = true := by decide
def e756116336154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116336154 : Closed e756116336154 ∧ code e756116336154 = 9552209358362 := by decide
theorem cert_e756116336154 : check e756116336154 [] .sourceHead = true := by decide
def e756116339226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116339226 : Closed e756116339226 ∧ code e756116339226 = 9552209361434 := by decide
theorem cert_e756116339226 : check e756116339226 [] .sourceHead = true := by decide
def e756116346394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116346394 : Closed e756116346394 ∧ code e756116346394 = 9552209368602 := by decide
theorem cert_e756116346394 : check e756116346394 [] .sourceHead = true := by decide
def e756116347418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116347418 : Closed e756116347418 ∧ code e756116347418 = 9552209369626 := by decide
theorem cert_e756116347418 : check e756116347418 [] .sourceHead = true := by decide
def e756116418074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116418074 : Closed e756116418074 ∧ code e756116418074 = 9552209440282 := by decide
theorem cert_e756116418074 : check e756116418074 [] .sourceHead = true := by decide
def e756116420122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116420122 : Closed e756116420122 ∧ code e756116420122 = 9552209442330 := by decide
theorem cert_e756116420122 : check e756116420122 [] .sourceHead = true := by decide
def e756116516378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116516378 : Closed e756116516378 ∧ code e756116516378 = 9552209538586 := by decide
theorem cert_e756116516378 : check e756116516378 [] .sourceHead = true := by decide
def e756116519450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116519450 : Closed e756116519450 ∧ code e756116519450 = 9552209541658 := by decide
theorem cert_e756116519450 : check e756116519450 [] .sourceHead = true := by decide
def e756116567578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116567578 : Closed e756116567578 ∧ code e756116567578 = 9552209589786 := by decide
theorem cert_e756116567578 : check e756116567578 [] .sourceHead = true := by decide
def e756116568602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756116568602 : Closed e756116568602 ∧ code e756116568602 = 9552209590810 := by decide
theorem cert_e756116568602 : check e756116568602 [] .sourceHead = true := by decide
def e756118566938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756118566938 : Closed e756118566938 ∧ code e756118566938 = 9552211589146 := by decide
theorem cert_e756118566938 : check e756118566938 [] .sourceHead = true := by decide
def e756118575130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756118575130 : Closed e756118575130 ∧ code e756118575130 = 9552211597338 := by decide
theorem cert_e756118575130 : check e756118575130 [] .sourceHead = true := by decide
def e756118632474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756118632474 : Closed e756118632474 ∧ code e756118632474 = 9552211654682 := by decide
theorem cert_e756118632474 : check e756118632474 [] .sourceHead = true := by decide
def e756118644762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756118644762 : Closed e756118644762 ∧ code e756118644762 = 9552211666970 := by decide
theorem cert_e756118644762 : check e756118644762 [] .sourceHead = true := by decide
def e756118673434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756118673434 : Closed e756118673434 ∧ code e756118673434 = 9552211695642 := by decide
theorem cert_e756118673434 : check e756118673434 [] .sourceHead = true := by decide
def e756118677530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756118677530 : Closed e756118677530 ∧ code e756118677530 = 9552211699738 := by decide
theorem cert_e756118677530 : check e756118677530 [] .sourceHead = true := by decide
def e756118960154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756118960154 : Closed e756118960154 ∧ code e756118960154 = 9552211982362 := by decide
theorem cert_e756118960154 : check e756118960154 [] .sourceHead = true := by decide
def e756118968346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756118968346 : Closed e756118968346 ∧ code e756118968346 = 9552211990554 := by decide
theorem cert_e756118968346 : check e756118968346 [] .sourceHead = true := by decide
def e756119353370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756119353370 : Closed e756119353370 ∧ code e756119353370 = 9552212375578 := by decide
theorem cert_e756119353370 : check e756119353370 [] .sourceHead = true := by decide
def e756119365658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756119365658 : Closed e756119365658 ∧ code e756119365658 = 9552212387866 := by decide
theorem cert_e756119365658 : check e756119365658 [] .sourceHead = true := by decide
def e756119558170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756119558170 : Closed e756119558170 ∧ code e756119558170 = 9552212580378 := by decide
theorem cert_e756119558170 : check e756119558170 [] .sourceHead = true := by decide
def e756119562266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756119562266 : Closed e756119562266 ∧ code e756119562266 = 9552212584474 := by decide
theorem cert_e756119562266 : check e756119562266 [] .sourceHead = true := by decide
def e756126936602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756126936602 : Closed e756126936602 ∧ code e756126936602 = 9552219958810 := by decide
theorem cert_e756126936602 : check e756126936602 [] .sourceHead = true := by decide
def e756126938650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756126938650 : Closed e756126938650 ∧ code e756126938650 = 9552219960858 := by decide
theorem cert_e756126938650 : check e756126938650 [] .sourceHead = true := by decide
def e756126952986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756126952986 : Closed e756126952986 ∧ code e756126952986 = 9552219975194 := by decide
theorem cert_e756126952986 : check e756126952986 [] .sourceHead = true := by decide
def e756126956058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756126956058 : Closed e756126956058 ∧ code e756126956058 = 9552219978266 := by decide
theorem cert_e756126956058 : check e756126956058 [] .sourceHead = true := by decide
def e756126963226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756126963226 : Closed e756126963226 ∧ code e756126963226 = 9552219985434 := by decide
theorem cert_e756126963226 : check e756126963226 [] .sourceHead = true := by decide
def e756126964250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756126964250 : Closed e756126964250 ∧ code e756126964250 = 9552219986458 := by decide
theorem cert_e756126964250 : check e756126964250 [] .sourceHead = true := by decide
def e756127018522 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127018522 : Closed e756127018522 ∧ code e756127018522 = 9552220040730 := by decide
theorem cert_e756127018522 : check e756127018522 [] .sourceHead = true := by decide
def e756127021594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127021594 : Closed e756127021594 ∧ code e756127021594 = 9552220043802 := by decide
theorem cert_e756127021594 : check e756127021594 [] .sourceHead = true := by decide
def e756127033882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127033882 : Closed e756127033882 ∧ code e756127033882 = 9552220056090 := by decide
theorem cert_e756127033882 : check e756127033882 [] .sourceHead = true := by decide
def e756127061530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127061530 : Closed e756127061530 ∧ code e756127061530 = 9552220083738 := by decide
theorem cert_e756127061530 : check e756127061530 [] .sourceHead = true := by decide
def e756127062554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127062554 : Closed e756127062554 ∧ code e756127062554 = 9552220084762 := by decide
theorem cert_e756127062554 : check e756127062554 [] .sourceHead = true := by decide
def e756127066650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127066650 : Closed e756127066650 ∧ code e756127066650 = 9552220088858 := by decide
theorem cert_e756127066650 : check e756127066650 [] .sourceHead = true := by decide
def e756127329818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127329818 : Closed e756127329818 ∧ code e756127329818 = 9552220352026 := by decide
theorem cert_e756127329818 : check e756127329818 [] .sourceHead = true := by decide
def e756127331866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127331866 : Closed e756127331866 ∧ code e756127331866 = 9552220354074 := by decide
theorem cert_e756127331866 : check e756127331866 [] .sourceHead = true := by decide
def e756127346202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127346202 : Closed e756127346202 ∧ code e756127346202 = 9552220368410 := by decide
theorem cert_e756127346202 : check e756127346202 [] .sourceHead = true := by decide
def e756127349274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127349274 : Closed e756127349274 ∧ code e756127349274 = 9552220371482 := by decide
theorem cert_e756127349274 : check e756127349274 [] .sourceHead = true := by decide
def e756127356442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127356442 : Closed e756127356442 ∧ code e756127356442 = 9552220378650 := by decide
theorem cert_e756127356442 : check e756127356442 [] .sourceHead = true := by decide
def e756127357466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127357466 : Closed e756127357466 ∧ code e756127357466 = 9552220379674 := by decide
theorem cert_e756127357466 : check e756127357466 [] .sourceHead = true := by decide
def e756127428122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127428122 : Closed e756127428122 ∧ code e756127428122 = 9552220450330 := by decide
theorem cert_e756127428122 : check e756127428122 [] .sourceHead = true := by decide
def e756127430170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127430170 : Closed e756127430170 ∧ code e756127430170 = 9552220452378 := by decide
theorem cert_e756127430170 : check e756127430170 [] .sourceHead = true := by decide
def e756127526426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127526426 : Closed e756127526426 ∧ code e756127526426 = 9552220548634 := by decide
theorem cert_e756127526426 : check e756127526426 [] .sourceHead = true := by decide
def e756127529498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127529498 : Closed e756127529498 ∧ code e756127529498 = 9552220551706 := by decide
theorem cert_e756127529498 : check e756127529498 [] .sourceHead = true := by decide
def e756127555610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756127555610 : Closed e756127555610 ∧ code e756127555610 = 9552220577818 := by decide
theorem cert_e756127555610 : check e756127555610 [] .sourceHead = true := by decide
def e756127555702 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756127555702 : Closed e756127555702 ∧ code e756127555702 = 9552220577910 := by decide
theorem cert_e756127555702 : check e756127555702 [] .sourceHead = true := by decide
def e756127555946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756127555946 : Closed e756127555946 ∧ code e756127555946 = 9552220578154 := by decide
theorem cert_e756127555946 : check e756127555946 [] .sourceHead = true := by decide
def e756127555994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756127555994 : Closed e756127555994 ∧ code e756127555994 = 9552220578202 := by decide
theorem cert_e756127555994 : check e756127555994 [] .sourceHead = true := by decide
def e756127557146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756127557146 : Closed e756127557146 ∧ code e756127557146 = 9552220579354 := by decide
theorem cert_e756127557146 : check e756127557146 [] .sourceHead = true := by decide
def e756127577626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127577626 : Closed e756127577626 ∧ code e756127577626 = 9552220599834 := by decide
theorem cert_e756127577626 : check e756127577626 [] .sourceHead = true := by decide
def e756127578650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127578650 : Closed e756127578650 ∧ code e756127578650 = 9552220600858 := by decide
theorem cert_e756127578650 : check e756127578650 [] .sourceHead = true := by decide
def e756127588378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756127588378 : Closed e756127588378 ∧ code e756127588378 = 9552220610586 := by decide
theorem cert_e756127588378 : check e756127588378 [] .sourceHead = true := by decide
def e756127588470 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756127588470 : Closed e756127588470 ∧ code e756127588470 = 9552220610678 := by decide
theorem cert_e756127588470 : check e756127588470 [] .sourceHead = true := by decide
def e756127588714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756127588714 : Closed e756127588714 ∧ code e756127588714 = 9552220610922 := by decide
theorem cert_e756127588714 : check e756127588714 [] .sourceHead = true := by decide
def e756127588762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756127588762 : Closed e756127588762 ∧ code e756127588762 = 9552220610970 := by decide
theorem cert_e756127588762 : check e756127588762 [] .sourceHead = true := by decide
def e756127589914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756127589914 : Closed e756127589914 ∧ code e756127589914 = 9552220612122 := by decide
theorem cert_e756127589914 : check e756127589914 [] .sourceHead = true := by decide
def e756127690266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127690266 : Closed e756127690266 ∧ code e756127690266 = 9552220712474 := by decide
theorem cert_e756127690266 : check e756127690266 [] .sourceHead = true := by decide
def e756127692314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127692314 : Closed e756127692314 ∧ code e756127692314 = 9552220714522 := by decide
theorem cert_e756127692314 : check e756127692314 [] .sourceHead = true := by decide
def e756127739418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127739418 : Closed e756127739418 ∧ code e756127739418 = 9552220761626 := by decide
theorem cert_e756127739418 : check e756127739418 [] .sourceHead = true := by decide
def e756127742490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127742490 : Closed e756127742490 ∧ code e756127742490 = 9552220764698 := by decide
theorem cert_e756127742490 : check e756127742490 [] .sourceHead = true := by decide
def e756127754778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127754778 : Closed e756127754778 ∧ code e756127754778 = 9552220776986 := by decide
theorem cert_e756127754778 : check e756127754778 [] .sourceHead = true := by decide
def e756127788570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127788570 : Closed e756127788570 ∧ code e756127788570 = 9552220810778 := by decide
theorem cert_e756127788570 : check e756127788570 [] .sourceHead = true := by decide
def e756127791642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127791642 : Closed e756127791642 ∧ code e756127791642 = 9552220813850 := by decide
theorem cert_e756127791642 : check e756127791642 [] .sourceHead = true := by decide
def e756127817754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756127817754 : Closed e756127817754 ∧ code e756127817754 = 9552220839962 := by decide
theorem cert_e756127817754 : check e756127817754 [] .sourceHead = true := by decide
end Blc.Floor43
