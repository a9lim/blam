import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405374068238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405374068238 : Closed e2405374068238 ∧ code e2405374068238 = 11201467090446 := by decide
theorem cert_e2405374068238 : check e2405374068238 [[]] .width = true := by decide
def e2405374068250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405374068250 : Closed e2405374068250 ∧ code e2405374068250 = 11201467090458 := by decide
theorem cert_e2405374068250 : check e2405374068250 [[]] .width = true := by decide
def e2405374068322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405374068322 : Closed e2405374068322 ∧ code e2405374068322 = 11201467090530 := by decide
theorem cert_e2405374068322 : check e2405374068322 [[]] .width = true := by decide
def e2405374156826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405374156826 : Closed e2405374156826 ∧ code e2405374156826 = 11201467179034 := by decide
theorem cert_e2405374156826 : check e2405374156826 [[]] .width = true := by decide
def e2405374156918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405374156918 : Closed e2405374156918 ∧ code e2405374156918 = 11201467179126 := by decide
theorem cert_e2405374156918 : check e2405374156918 [[]] .width = true := by decide
def e2405374157162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405374157162 : Closed e2405374157162 ∧ code e2405374157162 = 11201467179370 := by decide
theorem cert_e2405374157162 : check e2405374157162 [[]] .width = true := by decide
def e2405374157210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405374157210 : Closed e2405374157210 ∧ code e2405374157210 = 11201467179418 := by decide
theorem cert_e2405374157210 : check e2405374157210 [[]] .width = true := by decide
def e2405374161094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405374161094 : Closed e2405374161094 ∧ code e2405374161094 = 11201467183302 := by decide
theorem cert_e2405374161094 : check e2405374161094 [[]] .width = true := by decide
def e2405374210246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405374210246 : Closed e2405374210246 ∧ code e2405374210246 = 11201467232454 := by decide
theorem cert_e2405374210246 : check e2405374210246 [[]] .width = true := by decide
def e2405374218438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405374218438 : Closed e2405374218438 ∧ code e2405374218438 = 11201467240646 := by decide
theorem cert_e2405374218438 : check e2405374218438 [[]] .width = true := by decide
def e2405374221850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405374221850 : Closed e2405374221850 ∧ code e2405374221850 = 11201467244058 := by decide
theorem cert_e2405374221850 : check e2405374221850 [[]] .width = true := by decide
def e2405374227994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405374227994 : Closed e2405374227994 ∧ code e2405374227994 = 11201467250202 := by decide
theorem cert_e2405374227994 : check e2405374227994 [[]] .width = true := by decide
def e2405374296262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405374296262 : Closed e2405374296262 ∧ code e2405374296262 = 11201467318470 := by decide
theorem cert_e2405374296262 : check e2405374296262 [[]] .width = true := by decide
def e2405374296790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405374296790 : Closed e2405374296790 ∧ code e2405374296790 = 11201467318998 := by decide
theorem cert_e2405374296790 : check e2405374296790 [[]] .width = true := by decide
def e2405374296794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405374296794 : Closed e2405374296794 ∧ code e2405374296794 = 11201467319002 := by decide
theorem cert_e2405374296794 : check e2405374296794 [[]] .width = true := by decide
def e2405374296810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405374296810 : Closed e2405374296810 ∧ code e2405374296810 = 11201467319018 := by decide
theorem cert_e2405374296810 : check e2405374296810 [[]] .width = true := by decide
def e2405374296886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405374296886 : Closed e2405374296886 ∧ code e2405374296886 = 11201467319094 := by decide
theorem cert_e2405374296886 : check e2405374296886 [[]] .width = true := by decide
def e2405374296890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405374296890 : Closed e2405374296890 ∧ code e2405374296890 = 11201467319098 := by decide
theorem cert_e2405374296890 : check e2405374296890 [[]] .width = true := by decide
def e2405374296974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405374296974 : Closed e2405374296974 ∧ code e2405374296974 = 11201467319182 := by decide
theorem cert_e2405374296974 : check e2405374296974 [[]] .width = true := by decide
def e2405374296986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405374296986 : Closed e2405374296986 ∧ code e2405374296986 = 11201467319194 := by decide
theorem cert_e2405374296986 : check e2405374296986 [[]] .width = true := by decide
def e2405374298906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405374298906 : Closed e2405374298906 ∧ code e2405374298906 = 11201467321114 := by decide
theorem cert_e2405374298906 : check e2405374298906 [[]] .width = true := by decide
def e2405374298950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405374298950 : Closed e2405374298950 ∧ code e2405374298950 = 11201467321158 := by decide
theorem cert_e2405374298950 : check e2405374298950 [[]] .width = true := by decide
def e2405374299190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405374299190 : Closed e2405374299190 ∧ code e2405374299190 = 11201467321398 := by decide
theorem cert_e2405374299190 : check e2405374299190 [[]] .width = true := by decide
def e2405374299194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405374299194 : Closed e2405374299194 ∧ code e2405374299194 = 11201467321402 := by decide
theorem cert_e2405374299194 : check e2405374299194 [[]] .width = true := by decide
def e2405374299334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405374299334 : Closed e2405374299334 ∧ code e2405374299334 = 11201467321542 := by decide
theorem cert_e2405374299334 : check e2405374299334 [[]] .width = true := by decide
def e2405374328858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405374328858 : Closed e2405374328858 ∧ code e2405374328858 = 11201467351066 := by decide
theorem cert_e2405374328858 : check e2405374328858 [[]] .width = true := by decide
def e2405374328950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405374328950 : Closed e2405374328950 ∧ code e2405374328950 = 11201467351158 := by decide
theorem cert_e2405374328950 : check e2405374328950 [[]] .width = true := by decide
def e2405374329194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405374329194 : Closed e2405374329194 ∧ code e2405374329194 = 11201467351402 := by decide
theorem cert_e2405374329194 : check e2405374329194 [[]] .width = true := by decide
def e2405374329242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405374329242 : Closed e2405374329242 ∧ code e2405374329242 = 11201467351450 := by decide
theorem cert_e2405374329242 : check e2405374329242 [[]] .width = true := by decide
def e2405374330250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405374330250 : Closed e2405374330250 ∧ code e2405374330250 = 11201467352458 := by decide
theorem cert_e2405374330250 : check e2405374330250 [[]] .width = true := by decide
def e2405374330274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405374330274 : Closed e2405374330274 ∧ code e2405374330274 = 11201467352482 := by decide
theorem cert_e2405374330274 : check e2405374330274 [[]] .width = true := by decide
def e2405374330382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405374330382 : Closed e2405374330382 ∧ code e2405374330382 = 11201467352590 := by decide
theorem cert_e2405374330382 : check e2405374330382 [[]] .width = true := by decide
def e2405374330394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405374330394 : Closed e2405374330394 ∧ code e2405374330394 = 11201467352602 := by decide
theorem cert_e2405374330394 : check e2405374330394 [[]] .width = true := by decide
def e2405374330466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405374330466 : Closed e2405374330466 ∧ code e2405374330466 = 11201467352674 := by decide
theorem cert_e2405374330466 : check e2405374330466 [[]] .width = true := by decide
def e2405375533082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405375533082 : Closed e2405375533082 ∧ code e2405375533082 = 11201468555290 := by decide
theorem cert_e2405375533082 : check e2405375533082 [[]] .width = true := by decide
def e2405375533174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405375533174 : Closed e2405375533174 ∧ code e2405375533174 = 11201468555382 := by decide
theorem cert_e2405375533174 : check e2405375533174 [[]] .width = true := by decide
def e2405375533418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405375533418 : Closed e2405375533418 ∧ code e2405375533418 = 11201468555626 := by decide
theorem cert_e2405375533418 : check e2405375533418 [[]] .width = true := by decide
def e2405375533466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405375533466 : Closed e2405375533466 ∧ code e2405375533466 = 11201468555674 := by decide
theorem cert_e2405375533466 : check e2405375533466 [[]] .width = true := by decide
def e2405375647770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405375647770 : Closed e2405375647770 ∧ code e2405375647770 = 11201468669978 := by decide
theorem cert_e2405375647770 : check e2405375647770 [[]] .width = true := by decide
def e2405375647862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405375647862 : Closed e2405375647862 ∧ code e2405375647862 = 11201468670070 := by decide
theorem cert_e2405375647862 : check e2405375647862 [[]] .width = true := by decide
def e2405375648106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405375648106 : Closed e2405375648106 ∧ code e2405375648106 = 11201468670314 := by decide
theorem cert_e2405375648106 : check e2405375648106 [[]] .width = true := by decide
def e2405375648154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405375648154 : Closed e2405375648154 ∧ code e2405375648154 = 11201468670362 := by decide
theorem cert_e2405375648154 : check e2405375648154 [[]] .width = true := by decide
def e2405376389318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405376389318 : Closed e2405376389318 ∧ code e2405376389318 = 11201469411526 := by decide
theorem cert_e2405376389318 : check e2405376389318 [[]] .width = true := by decide
def e2405376446662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405376446662 : Closed e2405376446662 ∧ code e2405376446662 = 11201469468870 := by decide
theorem cert_e2405376446662 : check e2405376446662 [[]] .width = true := by decide
def e2405376450074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405376450074 : Closed e2405376450074 ∧ code e2405376450074 = 11201469472282 := by decide
theorem cert_e2405376450074 : check e2405376450074 [[]] .width = true := by decide
def e2405376676038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405376676038 : Closed e2405376676038 ∧ code e2405376676038 = 11201469698246 := by decide
theorem cert_e2405376676038 : check e2405376676038 [[]] .width = true := by decide
def e2405376679450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405376679450 : Closed e2405376679450 ∧ code e2405376679450 = 11201469701658 := by decide
theorem cert_e2405376679450 : check e2405376679450 [[]] .width = true := by decide
def e2405376686618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405376686618 : Closed e2405376686618 ∧ code e2405376686618 = 11201469708826 := by decide
theorem cert_e2405376686618 : check e2405376686618 [[]] .width = true := by decide
def e2405376974874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405376974874 : Closed e2405376974874 ∧ code e2405376974874 = 11201469997082 := by decide
theorem cert_e2405376974874 : check e2405376974874 [[]] .width = true := by decide
def e2405376974966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405376974966 : Closed e2405376974966 ∧ code e2405376974966 = 11201469997174 := by decide
theorem cert_e2405376974966 : check e2405376974966 [[]] .width = true := by decide
def e2405376975210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405376975210 : Closed e2405376975210 ∧ code e2405376975210 = 11201469997418 := by decide
theorem cert_e2405376975210 : check e2405376975210 [[]] .width = true := by decide
def e2405376975258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405376975258 : Closed e2405376975258 ∧ code e2405376975258 = 11201469997466 := by decide
theorem cert_e2405376975258 : check e2405376975258 [[]] .width = true := by decide
def e2405377175750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405377175750 : Closed e2405377175750 ∧ code e2405377175750 = 11201470197958 := by decide
theorem cert_e2405377175750 : check e2405377175750 [[]] .width = true := by decide
def e2405377233094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405377233094 : Closed e2405377233094 ∧ code e2405377233094 = 11201470255302 := by decide
theorem cert_e2405377233094 : check e2405377233094 [[]] .width = true := by decide
def e2405377236506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405377236506 : Closed e2405377236506 ∧ code e2405377236506 = 11201470258714 := by decide
theorem cert_e2405377236506 : check e2405377236506 [[]] .width = true := by decide
def e2405377704134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405377704134 : Closed e2405377704134 ∧ code e2405377704134 = 11201470726342 := by decide
theorem cert_e2405377704134 : check e2405377704134 [[]] .width = true := by decide
def e2405377704662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405377704662 : Closed e2405377704662 ∧ code e2405377704662 = 11201470726870 := by decide
theorem cert_e2405377704662 : check e2405377704662 [[]] .width = true := by decide
def e2405377704666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405377704666 : Closed e2405377704666 ∧ code e2405377704666 = 11201470726874 := by decide
theorem cert_e2405377704666 : check e2405377704666 [[]] .width = true := by decide
def e2405377704682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405377704682 : Closed e2405377704682 ∧ code e2405377704682 = 11201470726890 := by decide
theorem cert_e2405377704682 : check e2405377704682 [[]] .width = true := by decide
def e2405377704758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405377704758 : Closed e2405377704758 ∧ code e2405377704758 = 11201470726966 := by decide
theorem cert_e2405377704758 : check e2405377704758 [[]] .width = true := by decide
def e2405377704762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405377704762 : Closed e2405377704762 ∧ code e2405377704762 = 11201470726970 := by decide
theorem cert_e2405377704762 : check e2405377704762 [[]] .width = true := by decide
def e2405377704846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405377704846 : Closed e2405377704846 ∧ code e2405377704846 = 11201470727054 := by decide
theorem cert_e2405377704846 : check e2405377704846 [[]] .width = true := by decide
def e2405377704858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405377704858 : Closed e2405377704858 ∧ code e2405377704858 = 11201470727066 := by decide
theorem cert_e2405377704858 : check e2405377704858 [[]] .width = true := by decide
def e2405377706778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405377706778 : Closed e2405377706778 ∧ code e2405377706778 = 11201470728986 := by decide
theorem cert_e2405377706778 : check e2405377706778 [[]] .width = true := by decide
def e2405377706822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405377706822 : Closed e2405377706822 ∧ code e2405377706822 = 11201470729030 := by decide
theorem cert_e2405377706822 : check e2405377706822 [[]] .width = true := by decide
def e2405377707062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405377707062 : Closed e2405377707062 ∧ code e2405377707062 = 11201470729270 := by decide
theorem cert_e2405377707062 : check e2405377707062 [[]] .width = true := by decide
def e2405377707066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405377707066 : Closed e2405377707066 ∧ code e2405377707066 = 11201470729274 := by decide
theorem cert_e2405377707066 : check e2405377707066 [[]] .width = true := by decide
def e2405377707206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405377707206 : Closed e2405377707206 ∧ code e2405377707206 = 11201470729414 := by decide
theorem cert_e2405377707206 : check e2405377707206 [[]] .width = true := by decide
def e2405378539718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405378539718 : Closed e2405378539718 ∧ code e2405378539718 = 11201471561926 := by decide
theorem cert_e2405378539718 : check e2405378539718 [[]] .width = true := by decide
def e2405378580506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405378580506 : Closed e2405378580506 ∧ code e2405378580506 = 11201471602714 := by decide
theorem cert_e2405378580506 : check e2405378580506 [[]] .width = true := by decide
def e2405378580598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405378580598 : Closed e2405378580598 ∧ code e2405378580598 = 11201471602806 := by decide
theorem cert_e2405378580598 : check e2405378580598 [[]] .width = true := by decide
def e2405378580842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405378580842 : Closed e2405378580842 ∧ code e2405378580842 = 11201471603050 := by decide
theorem cert_e2405378580842 : check e2405378580842 [[]] .width = true := by decide
def e2405378580890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405378580890 : Closed e2405378580890 ∧ code e2405378580890 = 11201471603098 := by decide
theorem cert_e2405378580890 : check e2405378580890 [[]] .width = true := by decide
def e2405378609350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405378609350 : Closed e2405378609350 ∧ code e2405378609350 = 11201471631558 := by decide
theorem cert_e2405378609350 : check e2405378609350 [[]] .width = true := by decide
def e2405378612762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405378612762 : Closed e2405378612762 ∧ code e2405378612762 = 11201471634970 := by decide
theorem cert_e2405378612762 : check e2405378612762 [[]] .width = true := by decide
def e2405378619930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405378619930 : Closed e2405378619930 ∧ code e2405378619930 = 11201471642138 := by decide
theorem cert_e2405378619930 : check e2405378619930 [[]] .width = true := by decide
def e2405378621638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405378621638 : Closed e2405378621638 ∧ code e2405378621638 = 11201471643846 := by decide
theorem cert_e2405378621638 : check e2405378621638 [[]] .width = true := by decide
def e2405378622166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405378622166 : Closed e2405378622166 ∧ code e2405378622166 = 11201471644374 := by decide
theorem cert_e2405378622166 : check e2405378622166 [[]] .width = true := by decide
def e2405378622170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405378622170 : Closed e2405378622170 ∧ code e2405378622170 = 11201471644378 := by decide
theorem cert_e2405378622170 : check e2405378622170 [[]] .width = true := by decide
def e2405378622186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405378622186 : Closed e2405378622186 ∧ code e2405378622186 = 11201471644394 := by decide
theorem cert_e2405378622186 : check e2405378622186 [[]] .width = true := by decide
def e2405378622262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405378622262 : Closed e2405378622262 ∧ code e2405378622262 = 11201471644470 := by decide
theorem cert_e2405378622262 : check e2405378622262 [[]] .width = true := by decide
def e2405378622266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405378622266 : Closed e2405378622266 ∧ code e2405378622266 = 11201471644474 := by decide
theorem cert_e2405378622266 : check e2405378622266 [[]] .width = true := by decide
def e2405378622350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405378622350 : Closed e2405378622350 ∧ code e2405378622350 = 11201471644558 := by decide
theorem cert_e2405378622350 : check e2405378622350 [[]] .width = true := by decide
def e2405378622362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405378622362 : Closed e2405378622362 ∧ code e2405378622362 = 11201471644570 := by decide
theorem cert_e2405378622362 : check e2405378622362 [[]] .width = true := by decide
def e2405378624282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405378624282 : Closed e2405378624282 ∧ code e2405378624282 = 11201471646490 := by decide
theorem cert_e2405378624282 : check e2405378624282 [[]] .width = true := by decide
def e2405378624326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405378624326 : Closed e2405378624326 ∧ code e2405378624326 = 11201471646534 := by decide
theorem cert_e2405378624326 : check e2405378624326 [[]] .width = true := by decide
def e2405378624566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405378624566 : Closed e2405378624566 ∧ code e2405378624566 = 11201471646774 := by decide
theorem cert_e2405378624566 : check e2405378624566 [[]] .width = true := by decide
def e2405378624570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405378624570 : Closed e2405378624570 ∧ code e2405378624570 = 11201471646778 := by decide
theorem cert_e2405378624570 : check e2405378624570 [[]] .width = true := by decide
def e2405378624710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405378624710 : Closed e2405378624710 ∧ code e2405378624710 = 11201471646918 := by decide
theorem cert_e2405378624710 : check e2405378624710 [[]] .width = true := by decide
def e2405378670790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405378670790 : Closed e2405378670790 ∧ code e2405378670790 = 11201471692998 := by decide
theorem cert_e2405378670790 : check e2405378670790 [[]] .width = true := by decide
def e2405379272902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405379272902 : Closed e2405379272902 ∧ code e2405379272902 = 11201472295110 := by decide
theorem cert_e2405379272902 : check e2405379272902 [[]] .width = true := by decide
def e2405380358170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405380358170 : Closed e2405380358170 ∧ code e2405380358170 = 11201473380378 := by decide
theorem cert_e2405380358170 : check e2405380358170 [[]] .width = true := by decide
def e2405380358262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405380358262 : Closed e2405380358262 ∧ code e2405380358262 = 11201473380470 := by decide
theorem cert_e2405380358262 : check e2405380358262 [[]] .width = true := by decide
def e2405380358506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405380358506 : Closed e2405380358506 ∧ code e2405380358506 = 11201473380714 := by decide
theorem cert_e2405380358506 : check e2405380358506 [[]] .width = true := by decide
def e2405380358554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405380358554 : Closed e2405380358554 ∧ code e2405380358554 = 11201473380762 := by decide
theorem cert_e2405380358554 : check e2405380358554 [[]] .width = true := by decide
def e2405380359562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405380359562 : Closed e2405380359562 ∧ code e2405380359562 = 11201473381770 := by decide
theorem cert_e2405380359562 : check e2405380359562 [[]] .width = true := by decide
def e2405380359586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405380359586 : Closed e2405380359586 ∧ code e2405380359586 = 11201473381794 := by decide
theorem cert_e2405380359586 : check e2405380359586 [[]] .width = true := by decide
def e2405380359694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405380359694 : Closed e2405380359694 ∧ code e2405380359694 = 11201473381902 := by decide
theorem cert_e2405380359694 : check e2405380359694 [[]] .width = true := by decide
def e2405380359706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405380359706 : Closed e2405380359706 ∧ code e2405380359706 = 11201473381914 := by decide
theorem cert_e2405380359706 : check e2405380359706 [[]] .width = true := by decide
def e2405380359778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405380359778 : Closed e2405380359778 ∧ code e2405380359778 = 11201473381986 := by decide
theorem cert_e2405380359778 : check e2405380359778 [[]] .width = true := by decide
def e2405380636870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405380636870 : Closed e2405380636870 ∧ code e2405380636870 = 11201473659078 := by decide
theorem cert_e2405380636870 : check e2405380636870 [[]] .width = true := by decide
def e2405380796614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405380796614 : Closed e2405380796614 ∧ code e2405380796614 = 11201473818822 := by decide
theorem cert_e2405380796614 : check e2405380796614 [[]] .width = true := by decide
def e2405380816922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405380816922 : Closed e2405380816922 ∧ code e2405380816922 = 11201473839130 := by decide
theorem cert_e2405380816922 : check e2405380816922 [[]] .width = true := by decide
def e2405380817014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405380817014 : Closed e2405380817014 ∧ code e2405380817014 = 11201473839222 := by decide
theorem cert_e2405380817014 : check e2405380817014 [[]] .width = true := by decide
def e2405380817258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405380817258 : Closed e2405380817258 ∧ code e2405380817258 = 11201473839466 := by decide
theorem cert_e2405380817258 : check e2405380817258 [[]] .width = true := by decide
def e2405380817306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405380817306 : Closed e2405380817306 ∧ code e2405380817306 = 11201473839514 := by decide
theorem cert_e2405380817306 : check e2405380817306 [[]] .width = true := by decide
def e2405380818314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405380818314 : Closed e2405380818314 ∧ code e2405380818314 = 11201473840522 := by decide
theorem cert_e2405380818314 : check e2405380818314 [[]] .width = true := by decide
def e2405380818338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405380818338 : Closed e2405380818338 ∧ code e2405380818338 = 11201473840546 := by decide
private def t_e2405380818338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2405380818338 : ¬ IsSelfInterpreter e2405380818338 :=
  wSource (t := t_e2405380818338) (replay_sound (ps := []) (t := e2405380818338) (by decide)) (by decide)
def e2405380818446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405380818446 : Closed e2405380818446 ∧ code e2405380818446 = 11201473840654 := by decide
theorem cert_e2405380818446 : check e2405380818446 [[]] .width = true := by decide
def e2405380818458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405380818458 : Closed e2405380818458 ∧ code e2405380818458 = 11201473840666 := by decide
private def t_e2405380818458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2405380818458 : ¬ IsSelfInterpreter e2405380818458 :=
  wSource (t := t_e2405380818458) (replay_sound (ps := []) (t := e2405380818458) (by decide)) (by decide)
def e2405380818530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405380818530 : Closed e2405380818530 ∧ code e2405380818530 = 11201473840738 := by decide
theorem cert_e2405380818530 : check e2405380818530 [[]] .width = true := by decide
def e2405380833478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405380833478 : Closed e2405380833478 ∧ code e2405380833478 = 11201473855686 := by decide
theorem cert_e2405380833478 : check e2405380833478 [[]] .width = true := by decide
def e2405381136410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405381136410 : Closed e2405381136410 ∧ code e2405381136410 = 11201474158618 := by decide
theorem cert_e2405381136410 : check e2405381136410 [[]] .width = true := by decide
def e2405381136502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405381136502 : Closed e2405381136502 ∧ code e2405381136502 = 11201474158710 := by decide
theorem cert_e2405381136502 : check e2405381136502 [[]] .width = true := by decide
def e2405381136746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405381136746 : Closed e2405381136746 ∧ code e2405381136746 = 11201474158954 := by decide
theorem cert_e2405381136746 : check e2405381136746 [[]] .width = true := by decide
def e2405381136794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405381136794 : Closed e2405381136794 ∧ code e2405381136794 = 11201474159002 := by decide
theorem cert_e2405381136794 : check e2405381136794 [[]] .width = true := by decide
def e2405381140678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381140678 : Closed e2405381140678 ∧ code e2405381140678 = 11201474162886 := by decide
theorem cert_e2405381140678 : check e2405381140678 [[]] .width = true := by decide
def e2405381152794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405381152794 : Closed e2405381152794 ∧ code e2405381152794 = 11201474175002 := by decide
theorem cert_e2405381152794 : check e2405381152794 [[]] .width = true := by decide
def e2405381152886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405381152886 : Closed e2405381152886 ∧ code e2405381152886 = 11201474175094 := by decide
theorem cert_e2405381152886 : check e2405381152886 [[]] .width = true := by decide
def e2405381153130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405381153130 : Closed e2405381153130 ∧ code e2405381153130 = 11201474175338 := by decide
theorem cert_e2405381153130 : check e2405381153130 [[]] .width = true := by decide
def e2405381153178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405381153178 : Closed e2405381153178 ∧ code e2405381153178 = 11201474175386 := by decide
theorem cert_e2405381153178 : check e2405381153178 [[]] .width = true := by decide
def e2405381165254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381165254 : Closed e2405381165254 ∧ code e2405381165254 = 11201474187462 := by decide
theorem cert_e2405381165254 : check e2405381165254 [[]] .width = true := by decide
def e2405381353670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381353670 : Closed e2405381353670 ∧ code e2405381353670 = 11201474375878 := by decide
theorem cert_e2405381353670 : check e2405381353670 [[]] .width = true := by decide
def e2405381361862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381361862 : Closed e2405381361862 ∧ code e2405381361862 = 11201474384070 := by decide
theorem cert_e2405381361862 : check e2405381361862 [[]] .width = true := by decide
def e2405381365274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381365274 : Closed e2405381365274 ∧ code e2405381365274 = 11201474387482 := by decide
theorem cert_e2405381365274 : check e2405381365274 [[]] .width = true := by decide
def e2405381371418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381371418 : Closed e2405381371418 ∧ code e2405381371418 = 11201474393626 := by decide
theorem cert_e2405381371418 : check e2405381371418 [[]] .width = true := by decide
def e2405381394630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381394630 : Closed e2405381394630 ∧ code e2405381394630 = 11201474416838 := by decide
theorem cert_e2405381394630 : check e2405381394630 [[]] .width = true := by decide
def e2405381398042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381398042 : Closed e2405381398042 ∧ code e2405381398042 = 11201474420250 := by decide
theorem cert_e2405381398042 : check e2405381398042 [[]] .width = true := by decide
def e2405381405210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381405210 : Closed e2405381405210 ∧ code e2405381405210 = 11201474427418 := by decide
theorem cert_e2405381405210 : check e2405381405210 [[]] .width = true := by decide
def e2405381428762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381428762 : Closed e2405381428762 ∧ code e2405381428762 = 11201474450970 := by decide
theorem cert_e2405381428762 : check e2405381428762 [[]] .width = true := by decide
def e2405381429786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381429786 : Closed e2405381429786 ∧ code e2405381429786 = 11201474451994 := by decide
theorem cert_e2405381429786 : check e2405381429786 [[]] .width = true := by decide
def e2405381496858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405381496858 : Closed e2405381496858 ∧ code e2405381496858 = 11201474519066 := by decide
theorem cert_e2405381496858 : check e2405381496858 [[]] .width = true := by decide
def e2405381496950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405381496950 : Closed e2405381496950 ∧ code e2405381496950 = 11201474519158 := by decide
theorem cert_e2405381496950 : check e2405381496950 [[]] .width = true := by decide
def e2405381497194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405381497194 : Closed e2405381497194 ∧ code e2405381497194 = 11201474519402 := by decide
theorem cert_e2405381497194 : check e2405381497194 [[]] .width = true := by decide
def e2405381497242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405381497242 : Closed e2405381497242 ∧ code e2405381497242 = 11201474519450 := by decide
theorem cert_e2405381497242 : check e2405381497242 [[]] .width = true := by decide
def e2405381501126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381501126 : Closed e2405381501126 ∧ code e2405381501126 = 11201474523334 := by decide
theorem cert_e2405381501126 : check e2405381501126 [[]] .width = true := by decide
def e2405381550278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381550278 : Closed e2405381550278 ∧ code e2405381550278 = 11201474572486 := by decide
theorem cert_e2405381550278 : check e2405381550278 [[]] .width = true := by decide
def e2405381558470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381558470 : Closed e2405381558470 ∧ code e2405381558470 = 11201474580678 := by decide
theorem cert_e2405381558470 : check e2405381558470 [[]] .width = true := by decide
def e2405381561882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381561882 : Closed e2405381561882 ∧ code e2405381561882 = 11201474584090 := by decide
theorem cert_e2405381561882 : check e2405381561882 [[]] .width = true := by decide
def e2405381568026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381568026 : Closed e2405381568026 ∧ code e2405381568026 = 11201474590234 := by decide
theorem cert_e2405381568026 : check e2405381568026 [[]] .width = true := by decide
def e2405381636294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405381636294 : Closed e2405381636294 ∧ code e2405381636294 = 11201474658502 := by decide
theorem cert_e2405381636294 : check e2405381636294 [[]] .width = true := by decide
def e2405381636822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405381636822 : Closed e2405381636822 ∧ code e2405381636822 = 11201474659030 := by decide
theorem cert_e2405381636822 : check e2405381636822 [[]] .width = true := by decide
def e2405381636826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405381636826 : Closed e2405381636826 ∧ code e2405381636826 = 11201474659034 := by decide
theorem cert_e2405381636826 : check e2405381636826 [[]] .width = true := by decide
def e2405381636842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405381636842 : Closed e2405381636842 ∧ code e2405381636842 = 11201474659050 := by decide
theorem cert_e2405381636842 : check e2405381636842 [[]] .width = true := by decide
def e2405381636918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405381636918 : Closed e2405381636918 ∧ code e2405381636918 = 11201474659126 := by decide
theorem cert_e2405381636918 : check e2405381636918 [[]] .width = true := by decide
def e2405381636922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405381636922 : Closed e2405381636922 ∧ code e2405381636922 = 11201474659130 := by decide
theorem cert_e2405381636922 : check e2405381636922 [[]] .width = true := by decide
def e2405381637006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405381637006 : Closed e2405381637006 ∧ code e2405381637006 = 11201474659214 := by decide
theorem cert_e2405381637006 : check e2405381637006 [[]] .width = true := by decide
def e2405381637018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405381637018 : Closed e2405381637018 ∧ code e2405381637018 = 11201474659226 := by decide
theorem cert_e2405381637018 : check e2405381637018 [[]] .width = true := by decide
def e2405381638938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405381638938 : Closed e2405381638938 ∧ code e2405381638938 = 11201474661146 := by decide
theorem cert_e2405381638938 : check e2405381638938 [[]] .width = true := by decide
def e2405381638982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405381638982 : Closed e2405381638982 ∧ code e2405381638982 = 11201474661190 := by decide
theorem cert_e2405381638982 : check e2405381638982 [[]] .width = true := by decide
def e2405381639222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405381639222 : Closed e2405381639222 ∧ code e2405381639222 = 11201474661430 := by decide
theorem cert_e2405381639222 : check e2405381639222 [[]] .width = true := by decide
def e2405381639226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405381639226 : Closed e2405381639226 ∧ code e2405381639226 = 11201474661434 := by decide
theorem cert_e2405381639226 : check e2405381639226 [[]] .width = true := by decide
def e2405381639366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405381639366 : Closed e2405381639366 ∧ code e2405381639366 = 11201474661574 := by decide
theorem cert_e2405381639366 : check e2405381639366 [[]] .width = true := by decide
def e2405381668890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405381668890 : Closed e2405381668890 ∧ code e2405381668890 = 11201474691098 := by decide
theorem cert_e2405381668890 : check e2405381668890 [[]] .width = true := by decide
def e2405381668982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405381668982 : Closed e2405381668982 ∧ code e2405381668982 = 11201474691190 := by decide
theorem cert_e2405381668982 : check e2405381668982 [[]] .width = true := by decide
def e2405381669226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405381669226 : Closed e2405381669226 ∧ code e2405381669226 = 11201474691434 := by decide
theorem cert_e2405381669226 : check e2405381669226 [[]] .width = true := by decide
def e2405381669274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405381669274 : Closed e2405381669274 ∧ code e2405381669274 = 11201474691482 := by decide
theorem cert_e2405381669274 : check e2405381669274 [[]] .width = true := by decide
def e2405381670282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405381670282 : Closed e2405381670282 ∧ code e2405381670282 = 11201474692490 := by decide
theorem cert_e2405381670282 : check e2405381670282 [[]] .width = true := by decide
def e2405381670306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405381670306 : Closed e2405381670306 ∧ code e2405381670306 = 11201474692514 := by decide
theorem cert_e2405381670306 : check e2405381670306 [[]] .width = true := by decide
def e2405381670414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405381670414 : Closed e2405381670414 ∧ code e2405381670414 = 11201474692622 := by decide
theorem cert_e2405381670414 : check e2405381670414 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405380818338
#print axioms Blc.Floor43.cert_e2405380818458
