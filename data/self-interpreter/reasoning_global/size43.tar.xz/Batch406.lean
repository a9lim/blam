import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373049866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373049866 : Closed e2422373049866 ∧ code e2422373049866 = 11218466072074 := by decide
theorem cert_e2422373049866 : check e2422373049866 [[],[]] .smaller = true := by decide
def e2422373049902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373049902 : Closed e2422373049902 ∧ code e2422373049902 = 11218466072110 := by decide
theorem cert_e2422373049902 : check e2422373049902 [[],[]] .smaller = true := by decide
def e2422373049910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373049910 : Closed e2422373049910 ∧ code e2422373049910 = 11218466072118 := by decide
theorem cert_e2422373049910 : check e2422373049910 [[],[]] .smaller = true := by decide
def e2422373049914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373049914 : Closed e2422373049914 ∧ code e2422373049914 = 11218466072122 := by decide
theorem cert_e2422373049914 : check e2422373049914 [[],[]] .smaller = true := by decide
def e2422373049962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373049962 : Closed e2422373049962 ∧ code e2422373049962 = 11218466072170 := by decide
theorem cert_e2422373049962 : check e2422373049962 [[],[]] .smaller = true := by decide
def e2422373049986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373049986 : Closed e2422373049986 ∧ code e2422373049986 = 11218466072194 := by decide
theorem cert_e2422373049986 : check e2422373049986 [[],[]] .smaller = true := by decide
def e2422373049998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373049998 : Closed e2422373049998 ∧ code e2422373049998 = 11218466072206 := by decide
theorem cert_e2422373049998 : check e2422373049998 [[],[]] .smaller = true := by decide
def e2422373050010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373050010 : Closed e2422373050010 ∧ code e2422373050010 = 11218466072218 := by decide
theorem cert_e2422373050010 : check e2422373050010 [[],[]] .smaller = true := by decide
def e2422373050054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373050054 : Closed e2422373050054 ∧ code e2422373050054 = 11218466072262 := by decide
theorem cert_e2422373050054 : check e2422373050054 [[],[]] .smaller = true := by decide
def e2422373050078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2422373050078 : Closed e2422373050078 ∧ code e2422373050078 = 11218466072286 := by decide
theorem cert_e2422373050078 : check e2422373050078 [[],[]] .three = true := by decide
def e2422373050082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373050082 : Closed e2422373050082 ∧ code e2422373050082 = 11218466072290 := by decide
theorem cert_e2422373050082 : check e2422373050082 [[],[]] .smaller = true := by decide
def e2422373050094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2422373050094 : Closed e2422373050094 ∧ code e2422373050094 = 11218466072302 := by decide
theorem cert_e2422373050094 : check e2422373050094 [[],[]] .smaller = true := by decide
def e2422373050102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2422373050102 : Closed e2422373050102 ∧ code e2422373050102 = 11218466072310 := by decide
theorem cert_e2422373050102 : check e2422373050102 [[],[]] .three = true := by decide
def e2422373050138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373050138 : Closed e2422373050138 ∧ code e2422373050138 = 11218466072346 := by decide
theorem cert_e2422373050138 : check e2422373050138 [[],[]] .smaller = true := by decide
def e2422373050182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373050182 : Closed e2422373050182 ∧ code e2422373050182 = 11218466072390 := by decide
theorem cert_e2422373050182 : check e2422373050182 [[],[]] .smaller = true := by decide
def e2422373050206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2422373050206 : Closed e2422373050206 ∧ code e2422373050206 = 11218466072414 := by decide
theorem cert_e2422373050206 : check e2422373050206 [[],[]] .three = true := by decide
def e2422373050234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2422373050234 : Closed e2422373050234 ∧ code e2422373050234 = 11218466072442 := by decide
theorem cert_e2422373050234 : check e2422373050234 [[],[]] .three = true := by decide
def e2422373050250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373050250 : Closed e2422373050250 ∧ code e2422373050250 = 11218466072458 := by decide
theorem cert_e2422373050250 : check e2422373050250 [[],[]] .smaller = true := by decide
def e2422373050274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373050274 : Closed e2422373050274 ∧ code e2422373050274 = 11218466072482 := by decide
theorem cert_e2422373050274 : check e2422373050274 [[],[]] .smaller = true := by decide
def e2422373050286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2422373050286 : Closed e2422373050286 ∧ code e2422373050286 = 11218466072494 := by decide
theorem cert_e2422373050286 : check e2422373050286 [[],[]] .smaller = true := by decide
def e2422373050298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2422373050298 : Closed e2422373050298 ∧ code e2422373050298 = 11218466072506 := by decide
theorem cert_e2422373050298 : check e2422373050298 [[],[]] .smaller = true := by decide
def e2422373050326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2422373050326 : Closed e2422373050326 ∧ code e2422373050326 = 11218466072534 := by decide
theorem cert_e2422373050326 : check e2422373050326 [[],[]] .three = true := by decide
def e2422373050330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2422373050330 : Closed e2422373050330 ∧ code e2422373050330 = 11218466072538 := by decide
theorem cert_e2422373050330 : check e2422373050330 [[],[]] .three = true := by decide
def e2422373050394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373050394 : Closed e2422373050394 ∧ code e2422373050394 = 11218466072602 := by decide
theorem cert_e2422373050394 : check e2422373050394 [[],[]] .smaller = true := by decide
def e2422373050430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373050430 : Closed e2422373050430 ∧ code e2422373050430 = 11218466072638 := by decide
theorem cert_e2422373050430 : check e2422373050430 [[],[]] .smaller = true := by decide
def e2422373050478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373050478 : Closed e2422373050478 ∧ code e2422373050478 = 11218466072686 := by decide
theorem cert_e2422373050478 : check e2422373050478 [[],[]] .smaller = true := by decide
def e2422373050486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373050486 : Closed e2422373050486 ∧ code e2422373050486 = 11218466072694 := by decide
theorem cert_e2422373050486 : check e2422373050486 [[],[]] .smaller = true := by decide
def e2422373050490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373050490 : Closed e2422373050490 ∧ code e2422373050490 = 11218466072698 := by decide
theorem cert_e2422373050490 : check e2422373050490 [[],[]] .smaller = true := by decide
def e2422373050730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373050730 : Closed e2422373050730 ∧ code e2422373050730 = 11218466072938 := by decide
theorem cert_e2422373050730 : check e2422373050730 [[],[]] .smaller = true := by decide
def e2422373050754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373050754 : Closed e2422373050754 ∧ code e2422373050754 = 11218466072962 := by decide
theorem cert_e2422373050754 : check e2422373050754 [[],[]] .smaller = true := by decide
def e2422373050766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373050766 : Closed e2422373050766 ∧ code e2422373050766 = 11218466072974 := by decide
theorem cert_e2422373050766 : check e2422373050766 [[],[]] .smaller = true := by decide
def e2422373050778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373050778 : Closed e2422373050778 ∧ code e2422373050778 = 11218466072986 := by decide
theorem cert_e2422373050778 : check e2422373050778 [[],[]] .smaller = true := by decide
def e2422373050822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373050822 : Closed e2422373050822 ∧ code e2422373050822 = 11218466073030 := by decide
theorem cert_e2422373050822 : check e2422373050822 [[],[]] .smaller = true := by decide
def e2422373050846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373050846 : Closed e2422373050846 ∧ code e2422373050846 = 11218466073054 := by decide
theorem cert_e2422373050846 : check e2422373050846 [[],[]] .three = true := by decide
def e2422373050850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373050850 : Closed e2422373050850 ∧ code e2422373050850 = 11218466073058 := by decide
theorem cert_e2422373050850 : check e2422373050850 [[],[]] .smaller = true := by decide
def e2422373050862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373050862 : Closed e2422373050862 ∧ code e2422373050862 = 11218466073070 := by decide
theorem cert_e2422373050862 : check e2422373050862 [[],[]] .smaller = true := by decide
def e2422373050870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373050870 : Closed e2422373050870 ∧ code e2422373050870 = 11218466073078 := by decide
theorem cert_e2422373050870 : check e2422373050870 [[],[]] .three = true := by decide
def e2422373051446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373051446 : Closed e2422373051446 ∧ code e2422373051446 = 11218466073654 := by decide
theorem cert_e2422373051446 : check e2422373051446 [[],[]] .smaller = true := by decide
def e2422373051450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373051450 : Closed e2422373051450 ∧ code e2422373051450 = 11218466073658 := by decide
theorem cert_e2422373051450 : check e2422373051450 [[],[]] .smaller = true := by decide
def e2422373051590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373051590 : Closed e2422373051590 ∧ code e2422373051590 = 11218466073798 := by decide
theorem cert_e2422373051590 : check e2422373051590 [[],[]] .smaller = true := by decide
def e2422373051614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373051614 : Closed e2422373051614 ∧ code e2422373051614 = 11218466073822 := by decide
theorem cert_e2422373051614 : check e2422373051614 [[],[]] .three = true := by decide
def e2422373051642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373051642 : Closed e2422373051642 ∧ code e2422373051642 = 11218466073850 := by decide
theorem cert_e2422373051642 : check e2422373051642 [[],[]] .three = true := by decide
def e2422373051918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373051918 : Closed e2422373051918 ∧ code e2422373051918 = 11218466074126 := by decide
theorem cert_e2422373051918 : check e2422373051918 [[],[]] .smaller = true := by decide
def e2422373051966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 4))))))))
theorem wire_e2422373051966 : Closed e2422373051966 ∧ code e2422373051966 = 11218466074174 := by decide
theorem cert_e2422373051966 : check e2422373051966 [[],[]] .three = true := by decide
def e2422373052002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373052002 : Closed e2422373052002 ∧ code e2422373052002 = 11218466074210 := by decide
theorem cert_e2422373052002 : check e2422373052002 [[],[]] .smaller = true := by decide
def e2422373052014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373052014 : Closed e2422373052014 ∧ code e2422373052014 = 11218466074222 := by decide
theorem cert_e2422373052014 : check e2422373052014 [[],[]] .smaller = true := by decide
def e2422373052026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373052026 : Closed e2422373052026 ∧ code e2422373052026 = 11218466074234 := by decide
theorem cert_e2422373052026 : check e2422373052026 [[],[]] .smaller = true := by decide
def e2422373052190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.lam (.var 3))))))))
theorem wire_e2422373052190 : Closed e2422373052190 ∧ code e2422373052190 = 11218466074398 := by decide
theorem cert_e2422373052190 : check e2422373052190 [[],[]] .three = true := by decide
def e2422373052214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373052214 : Closed e2422373052214 ∧ code e2422373052214 = 11218466074422 := by decide
theorem cert_e2422373052214 : check e2422373052214 [[],[]] .three = true := by decide
def e2422373052218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373052218 : Closed e2422373052218 ∧ code e2422373052218 = 11218466074426 := by decide
theorem cert_e2422373052218 : check e2422373052218 [[],[]] .three = true := by decide
def e2422373052534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2422373052534 : Closed e2422373052534 ∧ code e2422373052534 = 11218466074742 := by decide
theorem cert_e2422373052534 : check e2422373052534 [[],[]] .smaller = true := by decide
def e2422373052538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422373052538 : Closed e2422373052538 ∧ code e2422373052538 = 11218466074746 := by decide
theorem cert_e2422373052538 : check e2422373052538 [[],[]] .smaller = true := by decide
def e2422373052726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373052726 : Closed e2422373052726 ∧ code e2422373052726 = 11218466074934 := by decide
theorem cert_e2422373052726 : check e2422373052726 [[],[]] .smaller = true := by decide
def e2422373052730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373052730 : Closed e2422373052730 ∧ code e2422373052730 = 11218466074938 := by decide
theorem cert_e2422373052730 : check e2422373052730 [[],[]] .smaller = true := by decide
def e2422373052814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2422373052814 : Closed e2422373052814 ∧ code e2422373052814 = 11218466075022 := by decide
theorem cert_e2422373052814 : check e2422373052814 [[],[]] .smaller = true := by decide
def e2422373052870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422373052870 : Closed e2422373052870 ∧ code e2422373052870 = 11218466075078 := by decide
theorem cert_e2422373052870 : check e2422373052870 [[],[]] .smaller = true := by decide
def e2422373052894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2422373052894 : Closed e2422373052894 ∧ code e2422373052894 = 11218466075102 := by decide
theorem cert_e2422373052894 : check e2422373052894 [[],[]] .three = true := by decide
def e2422373052918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2422373052918 : Closed e2422373052918 ∧ code e2422373052918 = 11218466075126 := by decide
theorem cert_e2422373052918 : check e2422373052918 [[],[]] .three = true := by decide
def e2422373053206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373053206 : Closed e2422373053206 ∧ code e2422373053206 = 11218466075414 := by decide
theorem cert_e2422373053206 : check e2422373053206 [[],[]] .smaller = true := by decide
def e2422373053278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2422373053278 : Closed e2422373053278 ∧ code e2422373053278 = 11218466075486 := by decide
theorem cert_e2422373053278 : check e2422373053278 [[],[]] .three = true := by decide
def e2422373053282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373053282 : Closed e2422373053282 ∧ code e2422373053282 = 11218466075490 := by decide
theorem cert_e2422373053282 : check e2422373053282 [[],[]] .smaller = true := by decide
def e2422373053294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422373053294 : Closed e2422373053294 ∧ code e2422373053294 = 11218466075502 := by decide
theorem cert_e2422373053294 : check e2422373053294 [[],[]] .smaller = true := by decide
def e2422373053302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422373053302 : Closed e2422373053302 ∧ code e2422373053302 = 11218466075510 := by decide
theorem cert_e2422373053302 : check e2422373053302 [[],[]] .smaller = true := by decide
def e2422373053306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2422373053306 : Closed e2422373053306 ∧ code e2422373053306 = 11218466075514 := by decide
theorem cert_e2422373053306 : check e2422373053306 [[],[]] .three = true := by decide
def e2422373053322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373053322 : Closed e2422373053322 ∧ code e2422373053322 = 11218466075530 := by decide
theorem cert_e2422373053322 : check e2422373053322 [[],[]] .smaller = true := by decide
def e2422373053346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373053346 : Closed e2422373053346 ∧ code e2422373053346 = 11218466075554 := by decide
theorem cert_e2422373053346 : check e2422373053346 [[],[]] .smaller = true := by decide
def e2422373053358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422373053358 : Closed e2422373053358 ∧ code e2422373053358 = 11218466075566 := by decide
theorem cert_e2422373053358 : check e2422373053358 [[],[]] .smaller = true := by decide
def e2422373053370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422373053370 : Closed e2422373053370 ∧ code e2422373053370 = 11218466075578 := by decide
theorem cert_e2422373053370 : check e2422373053370 [[],[]] .smaller = true := by decide
def e2422373053398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422373053398 : Closed e2422373053398 ∧ code e2422373053398 = 11218466075606 := by decide
theorem cert_e2422373053398 : check e2422373053398 [[],[]] .smaller = true := by decide
def e2422373053402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422373053402 : Closed e2422373053402 ∧ code e2422373053402 = 11218466075610 := by decide
theorem cert_e2422373053402 : check e2422373053402 [[],[]] .smaller = true := by decide
def e2422373053418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2422373053418 : Closed e2422373053418 ∧ code e2422373053418 = 11218466075626 := by decide
theorem cert_e2422373053418 : check e2422373053418 [[],[]] .three = true := by decide
def e2422373053470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373053470 : Closed e2422373053470 ∧ code e2422373053470 = 11218466075678 := by decide
theorem cert_e2422373053470 : check e2422373053470 [[],[]] .smaller = true := by decide
def e2422373053662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373053662 : Closed e2422373053662 ∧ code e2422373053662 = 11218466075870 := by decide
theorem cert_e2422373053662 : check e2422373053662 [[],[]] .three = true := by decide
def e2422373053666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373053666 : Closed e2422373053666 ∧ code e2422373053666 = 11218466075874 := by decide
theorem cert_e2422373053666 : check e2422373053666 [[],[]] .smaller = true := by decide
def e2422373053678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373053678 : Closed e2422373053678 ∧ code e2422373053678 = 11218466075886 := by decide
theorem cert_e2422373053678 : check e2422373053678 [[],[]] .smaller = true := by decide
def e2422373053686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373053686 : Closed e2422373053686 ∧ code e2422373053686 = 11218466075894 := by decide
theorem cert_e2422373053686 : check e2422373053686 [[],[]] .smaller = true := by decide
def e2422373053690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373053690 : Closed e2422373053690 ∧ code e2422373053690 = 11218466075898 := by decide
theorem cert_e2422373053690 : check e2422373053690 [[],[]] .three = true := by decide
def e2422373053966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373053966 : Closed e2422373053966 ∧ code e2422373053966 = 11218466076174 := by decide
theorem cert_e2422373053966 : check e2422373053966 [[],[]] .smaller = true := by decide
def e2422373054014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2422373054014 : Closed e2422373054014 ∧ code e2422373054014 = 11218466076222 := by decide
theorem cert_e2422373054014 : check e2422373054014 [[],[]] .three = true := by decide
def e2422373054050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373054050 : Closed e2422373054050 ∧ code e2422373054050 = 11218466076258 := by decide
theorem cert_e2422373054050 : check e2422373054050 [[],[]] .smaller = true := by decide
def e2422373054062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373054062 : Closed e2422373054062 ∧ code e2422373054062 = 11218466076270 := by decide
theorem cert_e2422373054062 : check e2422373054062 [[],[]] .smaller = true := by decide
def e2422373054074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373054074 : Closed e2422373054074 ∧ code e2422373054074 = 11218466076282 := by decide
theorem cert_e2422373054074 : check e2422373054074 [[],[]] .smaller = true := by decide
def e2422373054262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373054262 : Closed e2422373054262 ∧ code e2422373054262 = 11218466076470 := by decide
theorem cert_e2422373054262 : check e2422373054262 [[],[]] .smaller = true := by decide
def e2422373054266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373054266 : Closed e2422373054266 ∧ code e2422373054266 = 11218466076474 := by decide
theorem cert_e2422373054266 : check e2422373054266 [[],[]] .smaller = true := by decide
def e2422373054350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2422373054350 : Closed e2422373054350 ∧ code e2422373054350 = 11218466076558 := by decide
theorem cert_e2422373054350 : check e2422373054350 [[],[]] .three = true := by decide
def e2422373054362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373054362 : Closed e2422373054362 ∧ code e2422373054362 = 11218466076570 := by decide
theorem cert_e2422373054362 : check e2422373054362 [[],[]] .three = true := by decide
def e2422373054522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373054522 : Closed e2422373054522 ∧ code e2422373054522 = 11218466076730 := by decide
theorem cert_e2422373054522 : check e2422373054522 [[],[]] .three = true := by decide
def e2422373054570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373054570 : Closed e2422373054570 ∧ code e2422373054570 = 11218466076778 := by decide
theorem cert_e2422373054570 : check e2422373054570 [[],[]] .three = true := by decide
def e2422373054618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373054618 : Closed e2422373054618 ∧ code e2422373054618 = 11218466076826 := by decide
theorem cert_e2422373054618 : check e2422373054618 [[],[]] .three = true := by decide
def e2422373054662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373054662 : Closed e2422373054662 ∧ code e2422373054662 = 11218466076870 := by decide
theorem cert_e2422373054662 : check e2422373054662 [[],[]] .three = true := by decide
def e2422373054686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422373054686 : Closed e2422373054686 ∧ code e2422373054686 = 11218466076894 := by decide
theorem cert_e2422373054686 : check e2422373054686 [[],[]] .three = true := by decide
def e2422373054702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422373054702 : Closed e2422373054702 ∧ code e2422373054702 = 11218466076910 := by decide
theorem cert_e2422373054702 : check e2422373054702 [[],[]] .three = true := by decide
def e2422373054710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422373054710 : Closed e2422373054710 ∧ code e2422373054710 = 11218466076918 := by decide
theorem cert_e2422373054710 : check e2422373054710 [[],[]] .three = true := by decide
def e2422373054714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422373054714 : Closed e2422373054714 ∧ code e2422373054714 = 11218466076922 := by decide
theorem cert_e2422373054714 : check e2422373054714 [[],[]] .three = true := by decide
def e2422373054858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373054858 : Closed e2422373054858 ∧ code e2422373054858 = 11218466077066 := by decide
theorem cert_e2422373054858 : check e2422373054858 [[],[]] .three = true := by decide
def e2422373054882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373054882 : Closed e2422373054882 ∧ code e2422373054882 = 11218466077090 := by decide
theorem cert_e2422373054882 : check e2422373054882 [[],[]] .three = true := by decide
def e2422373054894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422373054894 : Closed e2422373054894 ∧ code e2422373054894 = 11218466077102 := by decide
theorem cert_e2422373054894 : check e2422373054894 [[],[]] .three = true := by decide
def e2422373054902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2422373054902 : Closed e2422373054902 ∧ code e2422373054902 = 11218466077110 := by decide
theorem cert_e2422373054902 : check e2422373054902 [[],[]] .three = true := by decide
def e2422373054906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422373054906 : Closed e2422373054906 ∧ code e2422373054906 = 11218466077114 := by decide
theorem cert_e2422373054906 : check e2422373054906 [[],[]] .three = true := by decide
def e2422373054934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2422373054934 : Closed e2422373054934 ∧ code e2422373054934 = 11218466077142 := by decide
theorem cert_e2422373054934 : check e2422373054934 [[],[]] .three = true := by decide
def e2422373054938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2422373054938 : Closed e2422373054938 ∧ code e2422373054938 = 11218466077146 := by decide
theorem cert_e2422373054938 : check e2422373054938 [[],[]] .three = true := by decide
def e2422373054954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422373054954 : Closed e2422373054954 ∧ code e2422373054954 = 11218466077162 := by decide
theorem cert_e2422373054954 : check e2422373054954 [[],[]] .three = true := by decide
def e2422373054990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373054990 : Closed e2422373054990 ∧ code e2422373054990 = 11218466077198 := by decide
theorem cert_e2422373054990 : check e2422373054990 [[],[]] .three = true := by decide
def e2422373055002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373055002 : Closed e2422373055002 ∧ code e2422373055002 = 11218466077210 := by decide
theorem cert_e2422373055002 : check e2422373055002 [[],[]] .three = true := by decide
def e2422373055038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422373055038 : Closed e2422373055038 ∧ code e2422373055038 = 11218466077246 := by decide
theorem cert_e2422373055038 : check e2422373055038 [[],[]] .three = true := by decide
def e2422373055074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373055074 : Closed e2422373055074 ∧ code e2422373055074 = 11218466077282 := by decide
theorem cert_e2422373055074 : check e2422373055074 [[],[]] .three = true := by decide
def e2422373055086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373055086 : Closed e2422373055086 ∧ code e2422373055086 = 11218466077294 := by decide
theorem cert_e2422373055086 : check e2422373055086 [[],[]] .three = true := by decide
def e2422373055094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373055094 : Closed e2422373055094 ∧ code e2422373055094 = 11218466077302 := by decide
theorem cert_e2422373055094 : check e2422373055094 [[],[]] .three = true := by decide
def e2422373055098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373055098 : Closed e2422373055098 ∧ code e2422373055098 = 11218466077306 := by decide
theorem cert_e2422373055098 : check e2422373055098 [[],[]] .three = true := by decide
def e2422373055262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422373055262 : Closed e2422373055262 ∧ code e2422373055262 = 11218466077470 := by decide
theorem cert_e2422373055262 : check e2422373055262 [[],[]] .three = true := by decide
def e2422373055286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373055286 : Closed e2422373055286 ∧ code e2422373055286 = 11218466077494 := by decide
theorem cert_e2422373055286 : check e2422373055286 [[],[]] .three = true := by decide
def e2422373055290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373055290 : Closed e2422373055290 ∧ code e2422373055290 = 11218466077498 := by decide
theorem cert_e2422373055290 : check e2422373055290 [[],[]] .three = true := by decide
def e2422373055374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422373055374 : Closed e2422373055374 ∧ code e2422373055374 = 11218466077582 := by decide
theorem cert_e2422373055374 : check e2422373055374 [[],[]] .three = true := by decide
def e2422373055386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373055386 : Closed e2422373055386 ∧ code e2422373055386 = 11218466077594 := by decide
theorem cert_e2422373055386 : check e2422373055386 [[],[]] .three = true := by decide
def e2422373055430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422373055430 : Closed e2422373055430 ∧ code e2422373055430 = 11218466077638 := by decide
theorem cert_e2422373055430 : check e2422373055430 [[],[]] .three = true := by decide
def e2422373057454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 0)) (.var 2)))))))
theorem wire_e2422373057454 : Closed e2422373057454 ∧ code e2422373057454 = 11218466079662 := by decide
theorem cert_e2422373057454 : check e2422373057454 [[],[]] .three = true := by decide
def e2422373057462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 1)) (.var 1)))))))
theorem wire_e2422373057462 : Closed e2422373057462 ∧ code e2422373057462 = 11218466079670 := by decide
theorem cert_e2422373057462 : check e2422373057462 [[],[]] .three = true := by decide
def e2422373057466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 2)) (.var 0)))))))
theorem wire_e2422373057466 : Closed e2422373057466 ∧ code e2422373057466 = 11218466079674 := by decide
theorem cert_e2422373057466 : check e2422373057466 [[],[]] .three = true := by decide
def e2422373057494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373057494 : Closed e2422373057494 ∧ code e2422373057494 = 11218466079702 := by decide
theorem cert_e2422373057494 : check e2422373057494 [[],[]] .three = true := by decide
def e2422373057498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373057498 : Closed e2422373057498 ∧ code e2422373057498 = 11218466079706 := by decide
theorem cert_e2422373057498 : check e2422373057498 [[],[]] .three = true := by decide
def e2422373057514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.lam (.var 4)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373057514 : Closed e2422373057514 ∧ code e2422373057514 = 11218466079722 := by decide
theorem cert_e2422373057514 : check e2422373057514 [[],[]] .three = true := by decide
def e2422373058222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422373058222 : Closed e2422373058222 ∧ code e2422373058222 = 11218466080430 := by decide
private def t_e2422373058222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2)))))))
theorem cert_e2422373058222 : ¬ IsSelfInterpreter e2422373058222 :=
  wSource (t := t_e2422373058222) (replay_sound (ps := []) (t := e2422373058222) (by decide)) (by decide)
def e2422373058234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422373058234 : Closed e2422373058234 ∧ code e2422373058234 = 11218466080442 := by decide
private def t_e2422373058234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0)))))))
theorem cert_e2422373058234 : ¬ IsSelfInterpreter e2422373058234 :=
  wSource (t := t_e2422373058234) (replay_sound (ps := []) (t := e2422373058234) (by decide)) (by decide)
def e2422373058262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373058262 : Closed e2422373058262 ∧ code e2422373058262 = 11218466080470 := by decide
theorem cert_e2422373058262 : check e2422373058262 [[],[]] .three = true := by decide
def e2422373058266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373058266 : Closed e2422373058266 ∧ code e2422373058266 = 11218466080474 := by decide
theorem cert_e2422373058266 : check e2422373058266 [[],[]] .three = true := by decide
def e2422373058282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373058282 : Closed e2422373058282 ∧ code e2422373058282 = 11218466080490 := by decide
theorem cert_e2422373058282 : check e2422373058282 [[],[]] .three = true := by decide
def e2422373058390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373058390 : Closed e2422373058390 ∧ code e2422373058390 = 11218466080598 := by decide
theorem cert_e2422373058390 : check e2422373058390 [[],[]] .three = true := by decide
def e2422373058394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373058394 : Closed e2422373058394 ∧ code e2422373058394 = 11218466080602 := by decide
theorem cert_e2422373058394 : check e2422373058394 [[],[]] .three = true := by decide
def e2422373058474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373058474 : Closed e2422373058474 ∧ code e2422373058474 = 11218466080682 := by decide
theorem cert_e2422373058474 : check e2422373058474 [[],[]] .three = true := by decide
def e2422373058990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422373058990 : Closed e2422373058990 ∧ code e2422373058990 = 11218466081198 := by decide
theorem cert_e2422373058990 : check e2422373058990 [[],[]] .three = true := by decide
def e2422373058998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2422373058998 : Closed e2422373058998 ∧ code e2422373058998 = 11218466081206 := by decide
theorem cert_e2422373058998 : check e2422373058998 [[],[]] .three = true := by decide
def e2422373059002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422373059002 : Closed e2422373059002 ∧ code e2422373059002 = 11218466081210 := by decide
theorem cert_e2422373059002 : check e2422373059002 [[],[]] .three = true := by decide
def e2422373059030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2422373059030 : Closed e2422373059030 ∧ code e2422373059030 = 11218466081238 := by decide
theorem cert_e2422373059030 : check e2422373059030 [[],[]] .three = true := by decide
def e2422373059034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2422373059034 : Closed e2422373059034 ∧ code e2422373059034 = 11218466081242 := by decide
theorem cert_e2422373059034 : check e2422373059034 [[],[]] .three = true := by decide
def e2422373059050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422373059050 : Closed e2422373059050 ∧ code e2422373059050 = 11218466081258 := by decide
theorem cert_e2422373059050 : check e2422373059050 [[],[]] .three = true := by decide
def e2422373059182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373059182 : Closed e2422373059182 ∧ code e2422373059182 = 11218466081390 := by decide
theorem cert_e2422373059182 : check e2422373059182 [[],[]] .three = true := by decide
def e2422373059190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373059190 : Closed e2422373059190 ∧ code e2422373059190 = 11218466081398 := by decide
theorem cert_e2422373059190 : check e2422373059190 [[],[]] .three = true := by decide
def e2422373059194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373059194 : Closed e2422373059194 ∧ code e2422373059194 = 11218466081402 := by decide
theorem cert_e2422373059194 : check e2422373059194 [[],[]] .three = true := by decide
def e2422373059382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373059382 : Closed e2422373059382 ∧ code e2422373059382 = 11218466081590 := by decide
theorem cert_e2422373059382 : check e2422373059382 [[],[]] .three = true := by decide
def e2422373059386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373059386 : Closed e2422373059386 ∧ code e2422373059386 = 11218466081594 := by decide
theorem cert_e2422373059386 : check e2422373059386 [[],[]] .three = true := by decide
def e2422373059482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373059482 : Closed e2422373059482 ∧ code e2422373059482 = 11218466081690 := by decide
theorem cert_e2422373059482 : check e2422373059482 [[],[]] .three = true := by decide
def e2422373059694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422373059694 : Closed e2422373059694 ∧ code e2422373059694 = 11218466081902 := by decide
theorem cert_e2422373059694 : check e2422373059694 [[],[]] .three = true := by decide
def e2422373059702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2422373059702 : Closed e2422373059702 ∧ code e2422373059702 = 11218466081910 := by decide
theorem cert_e2422373059702 : check e2422373059702 [[],[]] .three = true := by decide
def e2422373059706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422373059706 : Closed e2422373059706 ∧ code e2422373059706 = 11218466081914 := by decide
theorem cert_e2422373059706 : check e2422373059706 [[],[]] .three = true := by decide
def e2422373059798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422373059798 : Closed e2422373059798 ∧ code e2422373059798 = 11218466082006 := by decide
theorem cert_e2422373059798 : check e2422373059798 [[],[]] .three = true := by decide
def e2422373059802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422373059802 : Closed e2422373059802 ∧ code e2422373059802 = 11218466082010 := by decide
theorem cert_e2422373059802 : check e2422373059802 [[],[]] .three = true := by decide
def e2422373059818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422373059818 : Closed e2422373059818 ∧ code e2422373059818 = 11218466082026 := by decide
theorem cert_e2422373059818 : check e2422373059818 [[],[]] .three = true := by decide
def e2422373059870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422373059870 : Closed e2422373059870 ∧ code e2422373059870 = 11218466082078 := by decide
theorem cert_e2422373059870 : check e2422373059870 [[],[]] .three = true := by decide
def e2422373059894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373059894 : Closed e2422373059894 ∧ code e2422373059894 = 11218466082102 := by decide
theorem cert_e2422373059894 : check e2422373059894 [[],[]] .three = true := by decide
def e2422373059898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373059898 : Closed e2422373059898 ∧ code e2422373059898 = 11218466082106 := by decide
theorem cert_e2422373059898 : check e2422373059898 [[],[]] .three = true := by decide
def e2422373059982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2422373059982 : Closed e2422373059982 ∧ code e2422373059982 = 11218466082190 := by decide
theorem cert_e2422373059982 : check e2422373059982 [[],[]] .three = true := by decide
def e2422373059994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373059994 : Closed e2422373059994 ∧ code e2422373059994 = 11218466082202 := by decide
theorem cert_e2422373059994 : check e2422373059994 [[],[]] .three = true := by decide
def e2422373060038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422373060038 : Closed e2422373060038 ∧ code e2422373060038 = 11218466082246 := by decide
theorem cert_e2422373060038 : check e2422373060038 [[],[]] .three = true := by decide
def e2422373060062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e2422373060062 : Closed e2422373060062 ∧ code e2422373060062 = 11218466082270 := by decide
theorem cert_e2422373060062 : check e2422373060062 [[],[]] .three = true := by decide
def e2422373060078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e2422373060078 : Closed e2422373060078 ∧ code e2422373060078 = 11218466082286 := by decide
theorem cert_e2422373060078 : check e2422373060078 [[],[]] .three = true := by decide
def e2422373060150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422373060150 : Closed e2422373060150 ∧ code e2422373060150 = 11218466082358 := by decide
theorem cert_e2422373060150 : check e2422373060150 [[],[]] .three = true := by decide
def e2422373060154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422373060154 : Closed e2422373060154 ∧ code e2422373060154 = 11218466082362 := by decide
theorem cert_e2422373060154 : check e2422373060154 [[],[]] .three = true := by decide
def e2422373060202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422373060202 : Closed e2422373060202 ∧ code e2422373060202 = 11218466082410 := by decide
theorem cert_e2422373060202 : check e2422373060202 [[],[]] .three = true := by decide
def e2422373060238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422373060238 : Closed e2422373060238 ∧ code e2422373060238 = 11218466082446 := by decide
theorem cert_e2422373060238 : check e2422373060238 [[],[]] .three = true := by decide
def e2422373060250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373060250 : Closed e2422373060250 ∧ code e2422373060250 = 11218466082458 := by decide
theorem cert_e2422373060250 : check e2422373060250 [[],[]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422373058222
#print axioms Blc.Floor43.cert_e2422373058234
