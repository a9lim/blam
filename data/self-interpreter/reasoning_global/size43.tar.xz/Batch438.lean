import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374983622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e2422374983622 : Closed e2422374983622 ∧ code e2422374983622 = 11218468005830 := by decide
theorem cert_e2422374983622 : check e2422374983622 [[],[]] .three = true := by decide
def e2422374983646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 3))))))))))
theorem wire_e2422374983646 : Closed e2422374983646 ∧ code e2422374983646 = 11218468005854 := by decide
theorem cert_e2422374983646 : check e2422374983646 [[],[]] .three = true := by decide
def e2422374985854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 5)))))))))))
theorem wire_e2422374985854 : Closed e2422374985854 ∧ code e2422374985854 = 11218468008062 := by decide
theorem cert_e2422374985854 : check e2422374985854 [[],[]] .three = true := by decide
def e2422374985966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422374985966 : Closed e2422374985966 ∧ code e2422374985966 = 11218468008174 := by decide
theorem cert_e2422374985966 : check e2422374985966 [[],[]] .smaller = true := by decide
def e2422374985974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422374985974 : Closed e2422374985974 ∧ code e2422374985974 = 11218468008182 := by decide
theorem cert_e2422374985974 : check e2422374985974 [[],[]] .smaller = true := by decide
def e2422374986454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422374986454 : Closed e2422374986454 ∧ code e2422374986454 = 11218468008662 := by decide
theorem cert_e2422374986454 : check e2422374986454 [[],[]] .smaller = true := by decide
def e2422374986458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422374986458 : Closed e2422374986458 ∧ code e2422374986458 = 11218468008666 := by decide
theorem cert_e2422374986458 : check e2422374986458 [[],[]] .smaller = true := by decide
def e2422374986474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422374986474 : Closed e2422374986474 ∧ code e2422374986474 = 11218468008682 := by decide
theorem cert_e2422374986474 : check e2422374986474 [[],[]] .smaller = true := by decide
def e2422374986550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374986550 : Closed e2422374986550 ∧ code e2422374986550 = 11218468008758 := by decide
theorem cert_e2422374986550 : check e2422374986550 [[],[]] .smaller = true := by decide
def e2422374986554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374986554 : Closed e2422374986554 ∧ code e2422374986554 = 11218468008762 := by decide
theorem cert_e2422374986554 : check e2422374986554 [[],[]] .smaller = true := by decide
def e2422374986626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422374986626 : Closed e2422374986626 ∧ code e2422374986626 = 11218468008834 := by decide
theorem cert_e2422374986626 : check e2422374986626 [[],[]] .smaller = true := by decide
def e2422374986638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422374986638 : Closed e2422374986638 ∧ code e2422374986638 = 11218468008846 := by decide
theorem cert_e2422374986638 : check e2422374986638 [[],[]] .smaller = true := by decide
def e2422374986650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374986650 : Closed e2422374986650 ∧ code e2422374986650 = 11218468008858 := by decide
theorem cert_e2422374986650 : check e2422374986650 [[],[]] .smaller = true := by decide
def e2422374986718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422374986718 : Closed e2422374986718 ∧ code e2422374986718 = 11218468008926 := by decide
theorem cert_e2422374986718 : check e2422374986718 [[],[]] .three = true := by decide
def e2422374986722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e2422374986722 : Closed e2422374986722 ∧ code e2422374986722 = 11218468008930 := by decide
theorem cert_e2422374986722 : check e2422374986722 [[],[]] .three = true := by decide
def e2422374986734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422374986734 : Closed e2422374986734 ∧ code e2422374986734 = 11218468008942 := by decide
theorem cert_e2422374986734 : check e2422374986734 [[],[]] .three = true := by decide
def e2422374987838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422374987838 : Closed e2422374987838 ∧ code e2422374987838 = 11218468010046 := by decide
theorem cert_e2422374987838 : check e2422374987838 [[],[]] .three = true := by decide
def e2422374987886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374987886 : Closed e2422374987886 ∧ code e2422374987886 = 11218468010094 := by decide
theorem cert_e2422374987886 : check e2422374987886 [[],[]] .three = true := by decide
def e2422374987898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374987898 : Closed e2422374987898 ∧ code e2422374987898 = 11218468010106 := by decide
theorem cert_e2422374987898 : check e2422374987898 [[],[]] .three = true := by decide
def e2422374988174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422374988174 : Closed e2422374988174 ∧ code e2422374988174 = 11218468010382 := by decide
theorem cert_e2422374988174 : check e2422374988174 [[],[]] .three = true := by decide
def e2422374988230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422374988230 : Closed e2422374988230 ∧ code e2422374988230 = 11218468010438 := by decide
theorem cert_e2422374988230 : check e2422374988230 [[],[]] .three = true := by decide
def e2422374988254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422374988254 : Closed e2422374988254 ∧ code e2422374988254 = 11218468010462 := by decide
theorem cert_e2422374988254 : check e2422374988254 [[],[]] .three = true := by decide
def e2422374988258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422374988258 : Closed e2422374988258 ∧ code e2422374988258 = 11218468010466 := by decide
theorem cert_e2422374988258 : check e2422374988258 [[],[]] .three = true := by decide
def e2422374988270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422374988270 : Closed e2422374988270 ∧ code e2422374988270 = 11218468010478 := by decide
theorem cert_e2422374988270 : check e2422374988270 [[],[]] .three = true := by decide
def e2422374988278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422374988278 : Closed e2422374988278 ∧ code e2422374988278 = 11218468010486 := by decide
theorem cert_e2422374988278 : check e2422374988278 [[],[]] .three = true := by decide
def e2422375057342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 4)))))))))))
theorem wire_e2422375057342 : Closed e2422375057342 ∧ code e2422375057342 = 11218468079550 := by decide
theorem cert_e2422375057342 : check e2422375057342 [[],[]] .smaller = true := by decide
def e2422375057390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 2)))))))))))
theorem wire_e2422375057390 : Closed e2422375057390 ∧ code e2422375057390 = 11218468079598 := by decide
theorem cert_e2422375057390 : check e2422375057390 [[],[]] .smaller = true := by decide
def e2422375061182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 4))))))))))
theorem wire_e2422375061182 : Closed e2422375061182 ∧ code e2422375061182 = 11218468083390 := by decide
theorem cert_e2422375061182 : check e2422375061182 [[],[]] .three = true := by decide
def e2422375061214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2422375061214 : Closed e2422375061214 ∧ code e2422375061214 = 11218468083422 := by decide
theorem cert_e2422375061214 : check e2422375061214 [[],[]] .smaller = true := by decide
def e2422375061238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2422375061238 : Closed e2422375061238 ∧ code e2422375061238 = 11218468083446 := by decide
theorem cert_e2422375061238 : check e2422375061238 [[],[]] .smaller = true := by decide
def e2422375061242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 4)) (.var 0))))))))))
theorem wire_e2422375061242 : Closed e2422375061242 ∧ code e2422375061242 = 11218468083450 := by decide
theorem cert_e2422375061242 : check e2422375061242 [[],[]] .three = true := by decide
def e2422375061342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2422375061342 : Closed e2422375061342 ∧ code e2422375061342 = 11218468083550 := by decide
theorem cert_e2422375061342 : check e2422375061342 [[],[]] .smaller = true := by decide
def e2422375061370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2422375061370 : Closed e2422375061370 ∧ code e2422375061370 = 11218468083578 := by decide
theorem cert_e2422375061370 : check e2422375061370 [[],[]] .smaller = true := by decide
def e2422375061462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2422375061462 : Closed e2422375061462 ∧ code e2422375061462 = 11218468083670 := by decide
theorem cert_e2422375061462 : check e2422375061462 [[],[]] .smaller = true := by decide
def e2422375061466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2422375061466 : Closed e2422375061466 ∧ code e2422375061466 = 11218468083674 := by decide
theorem cert_e2422375061466 : check e2422375061466 [[],[]] .smaller = true := by decide
def e2422375061482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 4) (.var 0)) (.var 0))))))))))
theorem wire_e2422375061482 : Closed e2422375061482 ∧ code e2422375061482 = 11218468083690 := by decide
theorem cert_e2422375061482 : check e2422375061482 [[],[]] .three = true := by decide
def e2422375061950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422375061950 : Closed e2422375061950 ∧ code e2422375061950 = 11218468084158 := by decide
theorem cert_e2422375061950 : check e2422375061950 [[],[]] .three = true := by decide
def e2422375061982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422375061982 : Closed e2422375061982 ∧ code e2422375061982 = 11218468084190 := by decide
theorem cert_e2422375061982 : check e2422375061982 [[],[]] .smaller = true := by decide
def e2422375062006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422375062006 : Closed e2422375062006 ∧ code e2422375062006 = 11218468084214 := by decide
theorem cert_e2422375062006 : check e2422375062006 [[],[]] .smaller = true := by decide
def e2422375062010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422375062010 : Closed e2422375062010 ∧ code e2422375062010 = 11218468084218 := by decide
theorem cert_e2422375062010 : check e2422375062010 [[],[]] .three = true := by decide
def e2422375062654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 5)))))))))))
theorem wire_e2422375062654 : Closed e2422375062654 ∧ code e2422375062654 = 11218468084862 := by decide
theorem cert_e2422375062654 : check e2422375062654 [[],[]] .three = true := by decide
def e2422375062750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422375062750 : Closed e2422375062750 ∧ code e2422375062750 = 11218468084958 := by decide
theorem cert_e2422375062750 : check e2422375062750 [[],[]] .smaller = true := by decide
def e2422375062778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422375062778 : Closed e2422375062778 ∧ code e2422375062778 = 11218468084986 := by decide
theorem cert_e2422375062778 : check e2422375062778 [[],[]] .smaller = true := by decide
def e2422375063102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e2422375063102 : Closed e2422375063102 ∧ code e2422375063102 = 11218468085310 := by decide
theorem cert_e2422375063102 : check e2422375063102 [[],[]] .smaller = true := by decide
def e2422375063326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e2422375063326 : Closed e2422375063326 ∧ code e2422375063326 = 11218468085534 := by decide
theorem cert_e2422375063326 : check e2422375063326 [[],[]] .smaller = true := by decide
def e2422375063350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422375063350 : Closed e2422375063350 ∧ code e2422375063350 = 11218468085558 := by decide
theorem cert_e2422375063350 : check e2422375063350 [[],[]] .smaller = true := by decide
def e2422375063354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422375063354 : Closed e2422375063354 ∧ code e2422375063354 = 11218468085562 := by decide
theorem cert_e2422375063354 : check e2422375063354 [[],[]] .smaller = true := by decide
def e2422375063438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.lam (.var 2)))))))))))
theorem wire_e2422375063438 : Closed e2422375063438 ∧ code e2422375063438 = 11218468085646 := by decide
theorem cert_e2422375063438 : check e2422375063438 [[],[]] .three = true := by decide
def e2422375063450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422375063450 : Closed e2422375063450 ∧ code e2422375063450 = 11218468085658 := by decide
theorem cert_e2422375063450 : check e2422375063450 [[],[]] .three = true := by decide
def e2422375063486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.var 4))))))))))
theorem wire_e2422375063486 : Closed e2422375063486 ∧ code e2422375063486 = 11218468085694 := by decide
theorem cert_e2422375063486 : check e2422375063486 [[],[]] .three = true := by decide
def e2422375077550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422375077550 : Closed e2422375077550 ∧ code e2422375077550 = 11218468099758 := by decide
theorem cert_e2422375077550 : check e2422375077550 [[],[]] .smaller = true := by decide
def e2422375077562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422375077562 : Closed e2422375077562 ∧ code e2422375077562 = 11218468099770 := by decide
theorem cert_e2422375077562 : check e2422375077562 [[],[]] .smaller = true := by decide
def e2422375077610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422375077610 : Closed e2422375077610 ∧ code e2422375077610 = 11218468099818 := by decide
theorem cert_e2422375077610 : check e2422375077610 [[],[]] .smaller = true := by decide
def e2422375077802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422375077802 : Closed e2422375077802 ∧ code e2422375077802 = 11218468100010 := by decide
theorem cert_e2422375077802 : check e2422375077802 [[],[]] .smaller = true := by decide
def e2422375077934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)))))))))
theorem wire_e2422375077934 : Closed e2422375077934 ∧ code e2422375077934 = 11218468100142 := by decide
theorem cert_e2422375077934 : check e2422375077934 [[],[]] .smaller = true := by decide
def e2422375078110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e2422375078110 : Closed e2422375078110 ∧ code e2422375078110 = 11218468100318 := by decide
theorem cert_e2422375078110 : check e2422375078110 [[],[]] .three = true := by decide
def e2422375078126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2422375078126 : Closed e2422375078126 ∧ code e2422375078126 = 11218468100334 := by decide
theorem cert_e2422375078126 : check e2422375078126 [[],[]] .smaller = true := by decide
def e2422375078134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2422375078134 : Closed e2422375078134 ∧ code e2422375078134 = 11218468100342 := by decide
theorem cert_e2422375078134 : check e2422375078134 [[],[]] .smaller = true := by decide
def e2422375078138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e2422375078138 : Closed e2422375078138 ∧ code e2422375078138 = 11218468100346 := by decide
theorem cert_e2422375078138 : check e2422375078138 [[],[]] .three = true := by decide
def e2422375078318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422375078318 : Closed e2422375078318 ∧ code e2422375078318 = 11218468100526 := by decide
theorem cert_e2422375078318 : check e2422375078318 [[],[]] .smaller = true := by decide
def e2422375078330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422375078330 : Closed e2422375078330 ∧ code e2422375078330 = 11218468100538 := by decide
theorem cert_e2422375078330 : check e2422375078330 [[],[]] .smaller = true := by decide
def e2422375078378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422375078378 : Closed e2422375078378 ∧ code e2422375078378 = 11218468100586 := by decide
theorem cert_e2422375078378 : check e2422375078378 [[],[]] .smaller = true := by decide
def e2422375078462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e2422375078462 : Closed e2422375078462 ∧ code e2422375078462 = 11218468100670 := by decide
theorem cert_e2422375078462 : check e2422375078462 [[],[]] .three = true := by decide
def e2422375078510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422375078510 : Closed e2422375078510 ∧ code e2422375078510 = 11218468100718 := by decide
theorem cert_e2422375078510 : check e2422375078510 [[],[]] .smaller = true := by decide
def e2422375078522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422375078522 : Closed e2422375078522 ∧ code e2422375078522 = 11218468100730 := by decide
theorem cert_e2422375078522 : check e2422375078522 [[],[]] .smaller = true := by decide
def e2422375078686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2422375078686 : Closed e2422375078686 ∧ code e2422375078686 = 11218468100894 := by decide
theorem cert_e2422375078686 : check e2422375078686 [[],[]] .smaller = true := by decide
def e2422375078786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422375078786 : Closed e2422375078786 ∧ code e2422375078786 = 11218468100994 := by decide
theorem cert_e2422375078786 : check e2422375078786 [[],[]] .smaller = true := by decide
def e2422375078798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2422375078798 : Closed e2422375078798 ∧ code e2422375078798 = 11218468101006 := by decide
theorem cert_e2422375078798 : check e2422375078798 [[],[]] .smaller = true := by decide
def e2422375078810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422375078810 : Closed e2422375078810 ∧ code e2422375078810 = 11218468101018 := by decide
theorem cert_e2422375078810 : check e2422375078810 [[],[]] .smaller = true := by decide
def e2422375078854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e2422375078854 : Closed e2422375078854 ∧ code e2422375078854 = 11218468101062 := by decide
theorem cert_e2422375078854 : check e2422375078854 [[],[]] .three = true := by decide
def e2422375078878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 3)))))))))
theorem wire_e2422375078878 : Closed e2422375078878 ∧ code e2422375078878 = 11218468101086 := by decide
theorem cert_e2422375078878 : check e2422375078878 [[],[]] .three = true := by decide
def e2422375079006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e2422375079006 : Closed e2422375079006 ∧ code e2422375079006 = 11218468101214 := by decide
theorem cert_e2422375079006 : check e2422375079006 [[],[]] .three = true := by decide
def e2422375079022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2422375079022 : Closed e2422375079022 ∧ code e2422375079022 = 11218468101230 := by decide
theorem cert_e2422375079022 : check e2422375079022 [[],[]] .smaller = true := by decide
def e2422375079034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2422375079034 : Closed e2422375079034 ∧ code e2422375079034 = 11218468101242 := by decide
theorem cert_e2422375079034 : check e2422375079034 [[],[]] .smaller = true := by decide
def e2422375079198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2422375079198 : Closed e2422375079198 ∧ code e2422375079198 = 11218468101406 := by decide
theorem cert_e2422375079198 : check e2422375079198 [[],[]] .smaller = true := by decide
def e2422375079366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2422375079366 : Closed e2422375079366 ∧ code e2422375079366 = 11218468101574 := by decide
theorem cert_e2422375079366 : check e2422375079366 [[],[]] .smaller = true := by decide
def e2422375079390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e2422375079390 : Closed e2422375079390 ∧ code e2422375079390 = 11218468101598 := by decide
theorem cert_e2422375079390 : check e2422375079390 [[],[]] .three = true := by decide
def e2422375079394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e2422375079394 : Closed e2422375079394 ∧ code e2422375079394 = 11218468101602 := by decide
theorem cert_e2422375079394 : check e2422375079394 [[],[]] .three = true := by decide
def e2422375079406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e2422375079406 : Closed e2422375079406 ∧ code e2422375079406 = 11218468101614 := by decide
theorem cert_e2422375079406 : check e2422375079406 [[],[]] .three = true := by decide
def e2422375079434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422375079434 : Closed e2422375079434 ∧ code e2422375079434 = 11218468101642 := by decide
theorem cert_e2422375079434 : check e2422375079434 [[],[]] .smaller = true := by decide
def e2422375079470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422375079470 : Closed e2422375079470 ∧ code e2422375079470 = 11218468101678 := by decide
theorem cert_e2422375079470 : check e2422375079470 [[],[]] .smaller = true := by decide
def e2422375079478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422375079478 : Closed e2422375079478 ∧ code e2422375079478 = 11218468101686 := by decide
theorem cert_e2422375079478 : check e2422375079478 [[],[]] .smaller = true := by decide
def e2422375079482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422375079482 : Closed e2422375079482 ∧ code e2422375079482 = 11218468101690 := by decide
theorem cert_e2422375079482 : check e2422375079482 [[],[]] .smaller = true := by decide
def e2422375079530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422375079530 : Closed e2422375079530 ∧ code e2422375079530 = 11218468101738 := by decide
theorem cert_e2422375079530 : check e2422375079530 [[],[]] .smaller = true := by decide
def e2422375079554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422375079554 : Closed e2422375079554 ∧ code e2422375079554 = 11218468101762 := by decide
theorem cert_e2422375079554 : check e2422375079554 [[],[]] .smaller = true := by decide
def e2422375079566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422375079566 : Closed e2422375079566 ∧ code e2422375079566 = 11218468101774 := by decide
theorem cert_e2422375079566 : check e2422375079566 [[],[]] .smaller = true := by decide
def e2422375079578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422375079578 : Closed e2422375079578 ∧ code e2422375079578 = 11218468101786 := by decide
theorem cert_e2422375079578 : check e2422375079578 [[],[]] .smaller = true := by decide
def e2422375079622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422375079622 : Closed e2422375079622 ∧ code e2422375079622 = 11218468101830 := by decide
theorem cert_e2422375079622 : check e2422375079622 [[],[]] .smaller = true := by decide
def e2422375079646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e2422375079646 : Closed e2422375079646 ∧ code e2422375079646 = 11218468101854 := by decide
theorem cert_e2422375079646 : check e2422375079646 [[],[]] .three = true := by decide
def e2422375079650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422375079650 : Closed e2422375079650 ∧ code e2422375079650 = 11218468101858 := by decide
theorem cert_e2422375079650 : check e2422375079650 [[],[]] .smaller = true := by decide
def e2422375079662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 2)))))))))
theorem wire_e2422375079662 : Closed e2422375079662 ∧ code e2422375079662 = 11218468101870 := by decide
theorem cert_e2422375079662 : check e2422375079662 [[],[]] .smaller = true := by decide
def e2422375079670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e2422375079670 : Closed e2422375079670 ∧ code e2422375079670 = 11218468101878 := by decide
theorem cert_e2422375079670 : check e2422375079670 [[],[]] .three = true := by decide
def e2422375079702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422375079702 : Closed e2422375079702 ∧ code e2422375079702 = 11218468101910 := by decide
theorem cert_e2422375079702 : check e2422375079702 [[],[]] .three = true := by decide
def e2422375079706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422375079706 : Closed e2422375079706 ∧ code e2422375079706 = 11218468101914 := by decide
theorem cert_e2422375079706 : check e2422375079706 [[],[]] .three = true := by decide
def e2422375079750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422375079750 : Closed e2422375079750 ∧ code e2422375079750 = 11218468101958 := by decide
theorem cert_e2422375079750 : check e2422375079750 [[],[]] .three = true := by decide
def e2422375079774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 3)))))))))
theorem wire_e2422375079774 : Closed e2422375079774 ∧ code e2422375079774 = 11218468101982 := by decide
theorem cert_e2422375079774 : check e2422375079774 [[],[]] .three = true := by decide
def e2422375079778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422375079778 : Closed e2422375079778 ∧ code e2422375079778 = 11218468101986 := by decide
theorem cert_e2422375079778 : check e2422375079778 [[],[]] .three = true := by decide
def e2422375079790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e2422375079790 : Closed e2422375079790 ∧ code e2422375079790 = 11218468101998 := by decide
theorem cert_e2422375079790 : check e2422375079790 [[],[]] .three = true := by decide
def e2422375079798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e2422375079798 : Closed e2422375079798 ∧ code e2422375079798 = 11218468102006 := by decide
theorem cert_e2422375079798 : check e2422375079798 [[],[]] .three = true := by decide
def e2422375079802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 0)))))))))
theorem wire_e2422375079802 : Closed e2422375079802 ∧ code e2422375079802 = 11218468102010 := by decide
theorem cert_e2422375079802 : check e2422375079802 [[],[]] .three = true := by decide
def e2422375080382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422375080382 : Closed e2422375080382 ∧ code e2422375080382 = 11218468102590 := by decide
theorem cert_e2422375080382 : check e2422375080382 [[],[]] .three = true := by decide
def e2422375080414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422375080414 : Closed e2422375080414 ∧ code e2422375080414 = 11218468102622 := by decide
theorem cert_e2422375080414 : check e2422375080414 [[],[]] .smaller = true := by decide
def e2422375080438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422375080438 : Closed e2422375080438 ∧ code e2422375080438 = 11218468102646 := by decide
theorem cert_e2422375080438 : check e2422375080438 [[],[]] .smaller = true := by decide
def e2422375080442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422375080442 : Closed e2422375080442 ∧ code e2422375080442 = 11218468102650 := by decide
theorem cert_e2422375080442 : check e2422375080442 [[],[]] .three = true := by decide
def e2422375081390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422375081390 : Closed e2422375081390 ∧ code e2422375081390 = 11218468103598 := by decide
theorem cert_e2422375081390 : check e2422375081390 [[],[]] .smaller = true := by decide
def e2422375081402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422375081402 : Closed e2422375081402 ∧ code e2422375081402 = 11218468103610 := by decide
theorem cert_e2422375081402 : check e2422375081402 [[],[]] .smaller = true := by decide
def e2422375081450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422375081450 : Closed e2422375081450 ∧ code e2422375081450 = 11218468103658 := by decide
theorem cert_e2422375081450 : check e2422375081450 [[],[]] .smaller = true := by decide
def e2422375081534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e2422375081534 : Closed e2422375081534 ∧ code e2422375081534 = 11218468103742 := by decide
theorem cert_e2422375081534 : check e2422375081534 [[],[]] .three = true := by decide
def e2422375081582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422375081582 : Closed e2422375081582 ∧ code e2422375081582 = 11218468103790 := by decide
theorem cert_e2422375081582 : check e2422375081582 [[],[]] .smaller = true := by decide
def e2422375081594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422375081594 : Closed e2422375081594 ∧ code e2422375081594 = 11218468103802 := by decide
theorem cert_e2422375081594 : check e2422375081594 [[],[]] .smaller = true := by decide
def e2422375081758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422375081758 : Closed e2422375081758 ∧ code e2422375081758 = 11218468103966 := by decide
theorem cert_e2422375081758 : check e2422375081758 [[],[]] .smaller = true := by decide
def e2422375081858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422375081858 : Closed e2422375081858 ∧ code e2422375081858 = 11218468104066 := by decide
theorem cert_e2422375081858 : check e2422375081858 [[],[]] .smaller = true := by decide
def e2422375081870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422375081870 : Closed e2422375081870 ∧ code e2422375081870 = 11218468104078 := by decide
theorem cert_e2422375081870 : check e2422375081870 [[],[]] .smaller = true := by decide
def e2422375081882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422375081882 : Closed e2422375081882 ∧ code e2422375081882 = 11218468104090 := by decide
theorem cert_e2422375081882 : check e2422375081882 [[],[]] .smaller = true := by decide
def e2422375081926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e2422375081926 : Closed e2422375081926 ∧ code e2422375081926 = 11218468104134 := by decide
theorem cert_e2422375081926 : check e2422375081926 [[],[]] .three = true := by decide
def e2422375081950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 3))))))))))
theorem wire_e2422375081950 : Closed e2422375081950 ∧ code e2422375081950 = 11218468104158 := by decide
theorem cert_e2422375081950 : check e2422375081950 [[],[]] .three = true := by decide
def e2422375084158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 5)))))))))))
theorem wire_e2422375084158 : Closed e2422375084158 ∧ code e2422375084158 = 11218468106366 := by decide
theorem cert_e2422375084158 : check e2422375084158 [[],[]] .three = true := by decide
def e2422375084254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422375084254 : Closed e2422375084254 ∧ code e2422375084254 = 11218468106462 := by decide
theorem cert_e2422375084254 : check e2422375084254 [[],[]] .smaller = true := by decide
def e2422375084282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422375084282 : Closed e2422375084282 ∧ code e2422375084282 = 11218468106490 := by decide
theorem cert_e2422375084282 : check e2422375084282 [[],[]] .smaller = true := by decide
def e2422375084830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2422375084830 : Closed e2422375084830 ∧ code e2422375084830 = 11218468107038 := by decide
theorem cert_e2422375084830 : check e2422375084830 [[],[]] .smaller = true := by decide
def e2422375084998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2422375084998 : Closed e2422375084998 ∧ code e2422375084998 = 11218468107206 := by decide
theorem cert_e2422375084998 : check e2422375084998 [[],[]] .smaller = true := by decide
def e2422375085022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422375085022 : Closed e2422375085022 ∧ code e2422375085022 = 11218468107230 := by decide
theorem cert_e2422375085022 : check e2422375085022 [[],[]] .three = true := by decide
def e2422375085026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e2422375085026 : Closed e2422375085026 ∧ code e2422375085026 = 11218468107234 := by decide
theorem cert_e2422375085026 : check e2422375085026 [[],[]] .three = true := by decide
def e2422375085038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422375085038 : Closed e2422375085038 ∧ code e2422375085038 = 11218468107246 := by decide
theorem cert_e2422375085038 : check e2422375085038 [[],[]] .three = true := by decide
def e2422375086106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422375086106 : Closed e2422375086106 ∧ code e2422375086106 = 11218468108314 := by decide
theorem cert_e2422375086106 : check e2422375086106 [[],[]] .smaller = true := by decide
def e2422375086142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422375086142 : Closed e2422375086142 ∧ code e2422375086142 = 11218468108350 := by decide
theorem cert_e2422375086142 : check e2422375086142 [[],[]] .smaller = true := by decide
def e2422375086190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422375086190 : Closed e2422375086190 ∧ code e2422375086190 = 11218468108398 := by decide
theorem cert_e2422375086190 : check e2422375086190 [[],[]] .smaller = true := by decide
def e2422375086198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422375086198 : Closed e2422375086198 ∧ code e2422375086198 = 11218468108406 := by decide
theorem cert_e2422375086198 : check e2422375086198 [[],[]] .smaller = true := by decide
def e2422375086202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422375086202 : Closed e2422375086202 ∧ code e2422375086202 = 11218468108410 := by decide
theorem cert_e2422375086202 : check e2422375086202 [[],[]] .smaller = true := by decide
def e2422375086442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422375086442 : Closed e2422375086442 ∧ code e2422375086442 = 11218468108650 := by decide
theorem cert_e2422375086442 : check e2422375086442 [[],[]] .smaller = true := by decide
def e2422375086466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422375086466 : Closed e2422375086466 ∧ code e2422375086466 = 11218468108674 := by decide
theorem cert_e2422375086466 : check e2422375086466 [[],[]] .smaller = true := by decide
def e2422375086478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422375086478 : Closed e2422375086478 ∧ code e2422375086478 = 11218468108686 := by decide
theorem cert_e2422375086478 : check e2422375086478 [[],[]] .smaller = true := by decide
def e2422375086490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422375086490 : Closed e2422375086490 ∧ code e2422375086490 = 11218468108698 := by decide
theorem cert_e2422375086490 : check e2422375086490 [[],[]] .smaller = true := by decide
def e2422375086534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422375086534 : Closed e2422375086534 ∧ code e2422375086534 = 11218468108742 := by decide
theorem cert_e2422375086534 : check e2422375086534 [[],[]] .smaller = true := by decide
def e2422375086558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422375086558 : Closed e2422375086558 ∧ code e2422375086558 = 11218468108766 := by decide
theorem cert_e2422375086558 : check e2422375086558 [[],[]] .three = true := by decide
def e2422375086562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422375086562 : Closed e2422375086562 ∧ code e2422375086562 = 11218468108770 := by decide
theorem cert_e2422375086562 : check e2422375086562 [[],[]] .smaller = true := by decide
def e2422375086574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422375086574 : Closed e2422375086574 ∧ code e2422375086574 = 11218468108782 := by decide
theorem cert_e2422375086574 : check e2422375086574 [[],[]] .smaller = true := by decide
def e2422375086582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422375086582 : Closed e2422375086582 ∧ code e2422375086582 = 11218468108790 := by decide
theorem cert_e2422375086582 : check e2422375086582 [[],[]] .three = true := by decide
def e2422375087134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422375087134 : Closed e2422375087134 ∧ code e2422375087134 = 11218468109342 := by decide
theorem cert_e2422375087134 : check e2422375087134 [[],[]] .three = true := by decide
def e2422375087158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422375087158 : Closed e2422375087158 ∧ code e2422375087158 = 11218468109366 := by decide
theorem cert_e2422375087158 : check e2422375087158 [[],[]] .three = true := by decide
def e2422375087162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422375087162 : Closed e2422375087162 ∧ code e2422375087162 = 11218468109370 := by decide
theorem cert_e2422375087162 : check e2422375087162 [[],[]] .three = true := by decide
def e2422375087302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422375087302 : Closed e2422375087302 ∧ code e2422375087302 = 11218468109510 := by decide
theorem cert_e2422375087302 : check e2422375087302 [[],[]] .three = true := by decide
def e2422375087326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422375087326 : Closed e2422375087326 ∧ code e2422375087326 = 11218468109534 := by decide
theorem cert_e2422375087326 : check e2422375087326 [[],[]] .three = true := by decide
def e2422375087330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422375087330 : Closed e2422375087330 ∧ code e2422375087330 = 11218468109538 := by decide
theorem cert_e2422375087330 : check e2422375087330 [[],[]] .three = true := by decide
def e2422375087342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422375087342 : Closed e2422375087342 ∧ code e2422375087342 = 11218468109550 := by decide
theorem cert_e2422375087342 : check e2422375087342 [[],[]] .three = true := by decide
def e2422375087350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422375087350 : Closed e2422375087350 ∧ code e2422375087350 = 11218468109558 := by decide
theorem cert_e2422375087350 : check e2422375087350 [[],[]] .three = true := by decide
def e2422375087354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422375087354 : Closed e2422375087354 ∧ code e2422375087354 = 11218468109562 := by decide
theorem cert_e2422375087354 : check e2422375087354 [[],[]] .three = true := by decide
def e2422375121886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422375121886 : Closed e2422375121886 ∧ code e2422375121886 = 11218468144094 := by decide
theorem cert_e2422375121886 : check e2422375121886 [[],[]] .smaller = true := by decide
def e2422375121902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422375121902 : Closed e2422375121902 ∧ code e2422375121902 = 11218468144110 := by decide
theorem cert_e2422375121902 : check e2422375121902 [[],[]] .smaller = true := by decide
def e2422375123822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422375123822 : Closed e2422375123822 ∧ code e2422375123822 = 11218468146030 := by decide
theorem cert_e2422375123822 : check e2422375123822 [[],[]] .smaller = true := by decide
def e2422375123830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422375123830 : Closed e2422375123830 ∧ code e2422375123830 = 11218468146038 := by decide
theorem cert_e2422375123830 : check e2422375123830 [[],[]] .smaller = true := by decide
def e2422375123886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422375123886 : Closed e2422375123886 ∧ code e2422375123886 = 11218468146094 := by decide
theorem cert_e2422375123886 : check e2422375123886 [[],[]] .smaller = true := by decide
def e2422375123898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422375123898 : Closed e2422375123898 ∧ code e2422375123898 = 11218468146106 := by decide
theorem cert_e2422375123898 : check e2422375123898 [[],[]] .smaller = true := by decide
def e2422375123926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422375123926 : Closed e2422375123926 ∧ code e2422375123926 = 11218468146134 := by decide
theorem cert_e2422375123926 : check e2422375123926 [[],[]] .smaller = true := by decide
def e2422375123930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422375123930 : Closed e2422375123930 ∧ code e2422375123930 = 11218468146138 := by decide
theorem cert_e2422375123930 : check e2422375123930 [[],[]] .smaller = true := by decide
def e2422375124206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422375124206 : Closed e2422375124206 ∧ code e2422375124206 = 11218468146414 := by decide
theorem cert_e2422375124206 : check e2422375124206 [[],[]] .smaller = true := by decide
def e2422375124214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422375124214 : Closed e2422375124214 ∧ code e2422375124214 = 11218468146422 := by decide
theorem cert_e2422375124214 : check e2422375124214 [[],[]] .smaller = true := by decide
def e2422375124590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422375124590 : Closed e2422375124590 ∧ code e2422375124590 = 11218468146798 := by decide
theorem cert_e2422375124590 : check e2422375124590 [[],[]] .smaller = true := by decide
def e2422375124602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422375124602 : Closed e2422375124602 ∧ code e2422375124602 = 11218468146810 := by decide
theorem cert_e2422375124602 : check e2422375124602 [[],[]] .smaller = true := by decide
def e2422375124766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 3)))))))))))
theorem wire_e2422375124766 : Closed e2422375124766 ∧ code e2422375124766 = 11218468146974 := by decide
theorem cert_e2422375124766 : check e2422375124766 [[],[]] .smaller = true := by decide
end Blc.Floor43
