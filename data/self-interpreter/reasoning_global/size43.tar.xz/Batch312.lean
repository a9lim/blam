import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411631655086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2411631655086 : Closed e2411631655086 ∧ code e2411631655086 = 11207724677294 := by decide
theorem cert_e2411631655086 : check e2411631655086 [[],[]] .chain = true := by decide
def e2411631655098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2411631655098 : Closed e2411631655098 ∧ code e2411631655098 = 11207724677306 := by decide
theorem cert_e2411631655098 : check e2411631655098 [[],[]] .chain = true := by decide
def e2411631655470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2411631655470 : Closed e2411631655470 ∧ code e2411631655470 = 11207724677678 := by decide
theorem cert_e2411631655470 : check e2411631655470 [[],[]] .chain = true := by decide
def e2411631655650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2411631655650 : Closed e2411631655650 ∧ code e2411631655650 = 11207724677858 := by decide
theorem cert_e2411631655650 : check e2411631655650 [[],[]] .chain = true := by decide
def e2411631655662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2411631655662 : Closed e2411631655662 ∧ code e2411631655662 = 11207724677870 := by decide
theorem cert_e2411631655662 : check e2411631655662 [[],[]] .sourceHead = true := by decide
def e2411631655818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2411631655818 : Closed e2411631655818 ∧ code e2411631655818 = 11207724678026 := by decide
theorem cert_e2411631655818 : check e2411631655818 [[],[]] .chain = true := by decide
def e2411631655842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2411631655842 : Closed e2411631655842 ∧ code e2411631655842 = 11207724678050 := by decide
theorem cert_e2411631655842 : check e2411631655842 [[],[]] .chain = true := by decide
def e2411631655854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2411631655854 : Closed e2411631655854 ∧ code e2411631655854 = 11207724678062 := by decide
theorem cert_e2411631655854 : check e2411631655854 [[],[]] .sourceHead = true := by decide
def e2411631655866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2411631655866 : Closed e2411631655866 ∧ code e2411631655866 = 11207724678074 := by decide
theorem cert_e2411631655866 : check e2411631655866 [[],[]] .sourceHead = true := by decide
def e2411631656022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2411631656022 : Closed e2411631656022 ∧ code e2411631656022 = 11207724678230 := by decide
theorem cert_e2411631656022 : check e2411631656022 [[],[]] .chain = true := by decide
def e2411631656026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2411631656026 : Closed e2411631656026 ∧ code e2411631656026 = 11207724678234 := by decide
theorem cert_e2411631656026 : check e2411631656026 [[],[]] .chain = true := by decide
def e2411631656042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2411631656042 : Closed e2411631656042 ∧ code e2411631656042 = 11207724678250 := by decide
theorem cert_e2411631656042 : check e2411631656042 [[],[]] .chain = true := by decide
def e2411631656214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411631656214 : Closed e2411631656214 ∧ code e2411631656214 = 11207724678422 := by decide
theorem cert_e2411631656214 : check e2411631656214 [[],[]] .chain = true := by decide
def e2411631656218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411631656218 : Closed e2411631656218 ∧ code e2411631656218 = 11207724678426 := by decide
theorem cert_e2411631656218 : check e2411631656218 [[],[]] .chain = true := by decide
def e2411631656262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411631656262 : Closed e2411631656262 ∧ code e2411631656262 = 11207724678470 := by decide
theorem cert_e2411631656262 : check e2411631656262 [[],[]] .chain = true := by decide
def e2411631656290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411631656290 : Closed e2411631656290 ∧ code e2411631656290 = 11207724678498 := by decide
theorem cert_e2411631656290 : check e2411631656290 [[],[]] .chain = true := by decide
def e2411631656302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2411631656302 : Closed e2411631656302 ∧ code e2411631656302 = 11207724678510 := by decide
theorem cert_e2411631656302 : check e2411631656302 [[],[]] .sourceHead = true := by decide
def e2411631656310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2411631656310 : Closed e2411631656310 ∧ code e2411631656310 = 11207724678518 := by decide
theorem cert_e2411631656310 : check e2411631656310 [[],[]] .sourceHead = true := by decide
def e2411631656330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2411631656330 : Closed e2411631656330 ∧ code e2411631656330 = 11207724678538 := by decide
theorem cert_e2411631656330 : check e2411631656330 [[],[]] .chain = true := by decide
def e2411631656354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2411631656354 : Closed e2411631656354 ∧ code e2411631656354 = 11207724678562 := by decide
theorem cert_e2411631656354 : check e2411631656354 [[],[]] .chain = true := by decide
def e2411631656366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2411631656366 : Closed e2411631656366 ∧ code e2411631656366 = 11207724678574 := by decide
theorem cert_e2411631656366 : check e2411631656366 [[],[]] .sourceHead = true := by decide
def e2411631656378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2411631656378 : Closed e2411631656378 ∧ code e2411631656378 = 11207724678586 := by decide
theorem cert_e2411631656378 : check e2411631656378 [[],[]] .sourceHead = true := by decide
def e2411631656406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2411631656406 : Closed e2411631656406 ∧ code e2411631656406 = 11207724678614 := by decide
theorem cert_e2411631656406 : check e2411631656406 [[],[]] .sourceHead = true := by decide
def e2411631656410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2411631656410 : Closed e2411631656410 ∧ code e2411631656410 = 11207724678618 := by decide
theorem cert_e2411631656410 : check e2411631656410 [[],[]] .sourceHead = true := by decide
def e2411631657454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2411631657454 : Closed e2411631657454 ∧ code e2411631657454 = 11207724679662 := by decide
theorem cert_e2411631657454 : check e2411631657454 [[],[]] .chain = true := by decide
def e2411631657462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2411631657462 : Closed e2411631657462 ∧ code e2411631657462 = 11207724679670 := by decide
theorem cert_e2411631657462 : check e2411631657462 [[],[]] .chain = true := by decide
def e2411631657838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2411631657838 : Closed e2411631657838 ∧ code e2411631657838 = 11207724680046 := by decide
theorem cert_e2411631657838 : check e2411631657838 [[],[]] .chain = true := by decide
def e2411631657850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2411631657850 : Closed e2411631657850 ∧ code e2411631657850 = 11207724680058 := by decide
theorem cert_e2411631657850 : check e2411631657850 [[],[]] .chain = true := by decide
def e2411631657902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2411631657902 : Closed e2411631657902 ∧ code e2411631657902 = 11207724680110 := by decide
theorem cert_e2411631657902 : check e2411631657902 [[],[]] .chain = true := by decide
def e2411631657962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2411631657962 : Closed e2411631657962 ∧ code e2411631657962 = 11207724680170 := by decide
theorem cert_e2411631657962 : check e2411631657962 [[],[]] .chain = true := by decide
def e2411631658222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411631658222 : Closed e2411631658222 ∧ code e2411631658222 = 11207724680430 := by decide
theorem cert_e2411631658222 : check e2411631658222 [[],[]] .chain = true := by decide
def e2411631658230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411631658230 : Closed e2411631658230 ∧ code e2411631658230 = 11207724680438 := by decide
theorem cert_e2411631658230 : check e2411631658230 [[],[]] .chain = true := by decide
def e2411631658606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411631658606 : Closed e2411631658606 ∧ code e2411631658606 = 11207724680814 := by decide
theorem cert_e2411631658606 : check e2411631658606 [[],[]] .chain = true := by decide
def e2411631658618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411631658618 : Closed e2411631658618 ∧ code e2411631658618 = 11207724680826 := by decide
theorem cert_e2411631658618 : check e2411631658618 [[],[]] .chain = true := by decide
def e2411631658782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2411631658782 : Closed e2411631658782 ∧ code e2411631658782 = 11207724680990 := by decide
theorem cert_e2411631658782 : check e2411631658782 [[],[]] .chain = true := by decide
def e2411631658894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2411631658894 : Closed e2411631658894 ∧ code e2411631658894 = 11207724681102 := by decide
theorem cert_e2411631658894 : check e2411631658894 [[],[]] .chain = true := by decide
def e2411631658906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411631658906 : Closed e2411631658906 ∧ code e2411631658906 = 11207724681114 := by decide
theorem cert_e2411631658906 : check e2411631658906 [[],[]] .chain = true := by decide
def e2411631660142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411631660142 : Closed e2411631660142 ∧ code e2411631660142 = 11207724682350 := by decide
theorem cert_e2411631660142 : check e2411631660142 [[],[]] .chain = true := by decide
def e2411631660154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411631660154 : Closed e2411631660154 ∧ code e2411631660154 = 11207724682362 := by decide
theorem cert_e2411631660154 : check e2411631660154 [[],[]] .chain = true := by decide
def e2411631660318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411631660318 : Closed e2411631660318 ∧ code e2411631660318 = 11207724682526 := by decide
theorem cert_e2411631660318 : check e2411631660318 [[],[]] .chain = true := by decide
def e2411631660486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411631660486 : Closed e2411631660486 ∧ code e2411631660486 = 11207724682694 := by decide
theorem cert_e2411631660486 : check e2411631660486 [[],[]] .chain = true := by decide
def e2411631660590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2411631660590 : Closed e2411631660590 ∧ code e2411631660590 = 11207724682798 := by decide
theorem cert_e2411631660590 : check e2411631660590 [[],[]] .chain = true := by decide
def e2411631660770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2411631660770 : Closed e2411631660770 ∧ code e2411631660770 = 11207724682978 := by decide
theorem cert_e2411631660770 : check e2411631660770 [[],[]] .chain = true := by decide
def e2411631660782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2411631660782 : Closed e2411631660782 ∧ code e2411631660782 = 11207724682990 := by decide
theorem cert_e2411631660782 : check e2411631660782 [[],[]] .sourceHead = true := by decide
def e2411631660822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2411631660822 : Closed e2411631660822 ∧ code e2411631660822 = 11207724683030 := by decide
theorem cert_e2411631660822 : check e2411631660822 [[],[]] .chain = true := by decide
def e2411631660826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411631660826 : Closed e2411631660826 ∧ code e2411631660826 = 11207724683034 := by decide
theorem cert_e2411631660826 : check e2411631660826 [[],[]] .chain = true := by decide
def e2411631660870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411631660870 : Closed e2411631660870 ∧ code e2411631660870 = 11207724683078 := by decide
theorem cert_e2411631660870 : check e2411631660870 [[],[]] .chain = true := by decide
def e2411631660898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2411631660898 : Closed e2411631660898 ∧ code e2411631660898 = 11207724683106 := by decide
theorem cert_e2411631660898 : check e2411631660898 [[],[]] .chain = true := by decide
def e2411631660910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2411631660910 : Closed e2411631660910 ∧ code e2411631660910 = 11207724683118 := by decide
theorem cert_e2411631660910 : check e2411631660910 [[],[]] .sourceHead = true := by decide
def e2411631660918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2411631660918 : Closed e2411631660918 ∧ code e2411631660918 = 11207724683126 := by decide
theorem cert_e2411631660918 : check e2411631660918 [[],[]] .sourceHead = true := by decide
def e2411631661278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411631661278 : Closed e2411631661278 ∧ code e2411631661278 = 11207724683486 := by decide
theorem cert_e2411631661278 : check e2411631661278 [[],[]] .chain = true := by decide
def e2411631661306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411631661306 : Closed e2411631661306 ∧ code e2411631661306 = 11207724683514 := by decide
theorem cert_e2411631661306 : check e2411631661306 [[],[]] .chain = true := by decide
def e2411631661854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411631661854 : Closed e2411631661854 ∧ code e2411631661854 = 11207724684062 := by decide
theorem cert_e2411631661854 : check e2411631661854 [[],[]] .chain = true := by decide
def e2411631662022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411631662022 : Closed e2411631662022 ∧ code e2411631662022 = 11207724684230 := by decide
theorem cert_e2411631662022 : check e2411631662022 [[],[]] .chain = true := by decide
def e2411631663166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2411631663166 : Closed e2411631663166 ∧ code e2411631663166 = 11207724685374 := by decide
theorem cert_e2411631663166 : check e2411631663166 [[],[]] .chain = true := by decide
def e2411631663586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2411631663586 : Closed e2411631663586 ∧ code e2411631663586 = 11207724685794 := by decide
theorem cert_e2411631663586 : check e2411631663586 [[],[]] .chain = true := by decide
def e2411631663598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2411631663598 : Closed e2411631663598 ∧ code e2411631663598 = 11207724685806 := by decide
theorem cert_e2411631663598 : check e2411631663598 [[],[]] .sourceHead = true := by decide
def e2411631664158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2411631664158 : Closed e2411631664158 ∧ code e2411631664158 = 11207724686366 := by decide
theorem cert_e2411631664158 : check e2411631664158 [[],[]] .chain = true := by decide
def e2411631664182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411631664182 : Closed e2411631664182 ∧ code e2411631664182 = 11207724686390 := by decide
theorem cert_e2411631664182 : check e2411631664182 [[],[]] .chain = true := by decide
def e2411631664186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411631664186 : Closed e2411631664186 ∧ code e2411631664186 = 11207724686394 := by decide
theorem cert_e2411631664186 : check e2411631664186 [[],[]] .chain = true := by decide
def e2411631664326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411631664326 : Closed e2411631664326 ∧ code e2411631664326 = 11207724686534 := by decide
theorem cert_e2411631664326 : check e2411631664326 [[],[]] .chain = true := by decide
def e2411631664354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411631664354 : Closed e2411631664354 ∧ code e2411631664354 = 11207724686562 := by decide
theorem cert_e2411631664354 : check e2411631664354 [[],[]] .chain = true := by decide
def e2411631664366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411631664366 : Closed e2411631664366 ∧ code e2411631664366 = 11207724686574 := by decide
theorem cert_e2411631664366 : check e2411631664366 [[],[]] .sourceHead = true := by decide
def e2411631664374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411631664374 : Closed e2411631664374 ∧ code e2411631664374 = 11207724686582 := by decide
theorem cert_e2411631664374 : check e2411631664374 [[],[]] .sourceHead = true := by decide
def e2411631665390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2411631665390 : Closed e2411631665390 ∧ code e2411631665390 = 11207724687598 := by decide
theorem cert_e2411631665390 : check e2411631665390 [[],[]] .chain = true := by decide
def e2411631665402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2411631665402 : Closed e2411631665402 ∧ code e2411631665402 = 11207724687610 := by decide
theorem cert_e2411631665402 : check e2411631665402 [[],[]] .chain = true := by decide
def e2411631665774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411631665774 : Closed e2411631665774 ∧ code e2411631665774 = 11207724687982 := by decide
theorem cert_e2411631665774 : check e2411631665774 [[],[]] .chain = true := by decide
def e2411631665786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411631665786 : Closed e2411631665786 ∧ code e2411631665786 = 11207724687994 := by decide
theorem cert_e2411631665786 : check e2411631665786 [[],[]] .chain = true := by decide
def e2411631665950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2411631665950 : Closed e2411631665950 ∧ code e2411631665950 = 11207724688158 := by decide
theorem cert_e2411631665950 : check e2411631665950 [[],[]] .chain = true := by decide
def e2411631666118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2411631666118 : Closed e2411631666118 ∧ code e2411631666118 = 11207724688326 := by decide
theorem cert_e2411631666118 : check e2411631666118 [[],[]] .chain = true := by decide
def e2411631666734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2411631666734 : Closed e2411631666734 ∧ code e2411631666734 = 11207724688942 := by decide
theorem cert_e2411631666734 : check e2411631666734 [[],[]] .chain = true := by decide
def e2411631666914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2411631666914 : Closed e2411631666914 ∧ code e2411631666914 = 11207724689122 := by decide
theorem cert_e2411631666914 : check e2411631666914 [[],[]] .chain = true := by decide
def e2411631666926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2411631666926 : Closed e2411631666926 ∧ code e2411631666926 = 11207724689134 := by decide
theorem cert_e2411631666926 : check e2411631666926 [[],[]] .sourceHead = true := by decide
def e2411631667082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2411631667082 : Closed e2411631667082 ∧ code e2411631667082 = 11207724689290 := by decide
theorem cert_e2411631667082 : check e2411631667082 [[],[]] .chain = true := by decide
def e2411631667106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2411631667106 : Closed e2411631667106 ∧ code e2411631667106 = 11207724689314 := by decide
theorem cert_e2411631667106 : check e2411631667106 [[],[]] .chain = true := by decide
def e2411631667118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2411631667118 : Closed e2411631667118 ∧ code e2411631667118 = 11207724689326 := by decide
theorem cert_e2411631667118 : check e2411631667118 [[],[]] .sourceHead = true := by decide
def e2411631667130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2411631667130 : Closed e2411631667130 ∧ code e2411631667130 = 11207724689338 := by decide
theorem cert_e2411631667130 : check e2411631667130 [[],[]] .sourceHead = true := by decide
def e2411631667262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2411631667262 : Closed e2411631667262 ∧ code e2411631667262 = 11207724689470 := by decide
theorem cert_e2411631667262 : check e2411631667262 [[],[]] .chain = true := by decide
def e2411631667682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2411631667682 : Closed e2411631667682 ∧ code e2411631667682 = 11207724689890 := by decide
theorem cert_e2411631667682 : check e2411631667682 [[],[]] .chain = true := by decide
def e2411631667694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2411631667694 : Closed e2411631667694 ∧ code e2411631667694 = 11207724689902 := by decide
theorem cert_e2411631667694 : check e2411631667694 [[],[]] .sourceHead = true := by decide
def e2411631668750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2411631668750 : Closed e2411631668750 ∧ code e2411631668750 = 11207724690958 := by decide
theorem cert_e2411631668750 : check e2411631668750 [[],[]] .chain = true := by decide
def e2411631668834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2411631668834 : Closed e2411631668834 ∧ code e2411631668834 = 11207724691042 := by decide
theorem cert_e2411631668834 : check e2411631668834 [[],[]] .chain = true := by decide
def e2411631668846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2411631668846 : Closed e2411631668846 ∧ code e2411631668846 = 11207724691054 := by decide
theorem cert_e2411631668846 : check e2411631668846 [[],[]] .sourceHead = true := by decide
def e2411631668858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2411631668858 : Closed e2411631668858 ∧ code e2411631668858 = 11207724691066 := by decide
theorem cert_e2411631668858 : check e2411631668858 [[],[]] .sourceHead = true := by decide
def e2411631669366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2411631669366 : Closed e2411631669366 ∧ code e2411631669366 = 11207724691574 := by decide
theorem cert_e2411631669366 : check e2411631669366 [[],[]] .chain = true := by decide
def e2411631669370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411631669370 : Closed e2411631669370 ∧ code e2411631669370 = 11207724691578 := by decide
theorem cert_e2411631669370 : check e2411631669370 [[],[]] .chain = true := by decide
def e2411631669466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2411631669466 : Closed e2411631669466 ∧ code e2411631669466 = 11207724691674 := by decide
theorem cert_e2411631669466 : check e2411631669466 [[],[]] .chain = true := by decide
def e2411631669482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2411631669482 : Closed e2411631669482 ∧ code e2411631669482 = 11207724691690 := by decide
theorem cert_e2411631669482 : check e2411631669482 [[],[]] .chain = true := by decide
def e2411631669558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411631669558 : Closed e2411631669558 ∧ code e2411631669558 = 11207724691766 := by decide
theorem cert_e2411631669558 : check e2411631669558 [[],[]] .chain = true := by decide
def e2411631669562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411631669562 : Closed e2411631669562 ∧ code e2411631669562 = 11207724691770 := by decide
theorem cert_e2411631669562 : check e2411631669562 [[],[]] .chain = true := by decide
def e2411631669646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2411631669646 : Closed e2411631669646 ∧ code e2411631669646 = 11207724691854 := by decide
theorem cert_e2411631669646 : check e2411631669646 [[],[]] .chain = true := by decide
def e2411631669658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411631669658 : Closed e2411631669658 ∧ code e2411631669658 = 11207724691866 := by decide
theorem cert_e2411631669658 : check e2411631669658 [[],[]] .chain = true := by decide
def e2411631669702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411631669702 : Closed e2411631669702 ∧ code e2411631669702 = 11207724691910 := by decide
theorem cert_e2411631669702 : check e2411631669702 [[],[]] .chain = true := by decide
def e2411631670038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2411631670038 : Closed e2411631670038 ∧ code e2411631670038 = 11207724692246 := by decide
theorem cert_e2411631670038 : check e2411631670038 [[],[]] .chain = true := by decide
def e2411631670042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411631670042 : Closed e2411631670042 ∧ code e2411631670042 = 11207724692250 := by decide
theorem cert_e2411631670042 : check e2411631670042 [[],[]] .chain = true := by decide
def e2411631670086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411631670086 : Closed e2411631670086 ∧ code e2411631670086 = 11207724692294 := by decide
theorem cert_e2411631670086 : check e2411631670086 [[],[]] .chain = true := by decide
def e2411631670114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2411631670114 : Closed e2411631670114 ∧ code e2411631670114 = 11207724692322 := by decide
theorem cert_e2411631670114 : check e2411631670114 [[],[]] .chain = true := by decide
def e2411631670126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2411631670126 : Closed e2411631670126 ∧ code e2411631670126 = 11207724692334 := by decide
theorem cert_e2411631670126 : check e2411631670126 [[],[]] .sourceHead = true := by decide
def e2411631670134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2411631670134 : Closed e2411631670134 ∧ code e2411631670134 = 11207724692342 := by decide
theorem cert_e2411631670134 : check e2411631670134 [[],[]] .sourceHead = true := by decide
def e2411631670154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2411631670154 : Closed e2411631670154 ∧ code e2411631670154 = 11207724692362 := by decide
theorem cert_e2411631670154 : check e2411631670154 [[],[]] .chain = true := by decide
def e2411631670178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2411631670178 : Closed e2411631670178 ∧ code e2411631670178 = 11207724692386 := by decide
theorem cert_e2411631670178 : check e2411631670178 [[],[]] .chain = true := by decide
def e2411631670190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2411631670190 : Closed e2411631670190 ∧ code e2411631670190 = 11207724692398 := by decide
theorem cert_e2411631670190 : check e2411631670190 [[],[]] .sourceHead = true := by decide
def e2411631670202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2411631670202 : Closed e2411631670202 ∧ code e2411631670202 = 11207724692410 := by decide
theorem cert_e2411631670202 : check e2411631670202 [[],[]] .sourceHead = true := by decide
def e2411631670230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2411631670230 : Closed e2411631670230 ∧ code e2411631670230 = 11207724692438 := by decide
theorem cert_e2411631670230 : check e2411631670230 [[],[]] .sourceHead = true := by decide
def e2411631670234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2411631670234 : Closed e2411631670234 ∧ code e2411631670234 = 11207724692442 := by decide
theorem cert_e2411631670234 : check e2411631670234 [[],[]] .sourceHead = true := by decide
def e2411631670302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2411631670302 : Closed e2411631670302 ∧ code e2411631670302 = 11207724692510 := by decide
theorem cert_e2411631670302 : check e2411631670302 [[],[]] .chain = true := by decide
def e2411631670326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411631670326 : Closed e2411631670326 ∧ code e2411631670326 = 11207724692534 := by decide
theorem cert_e2411631670326 : check e2411631670326 [[],[]] .chain = true := by decide
def e2411631670330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411631670330 : Closed e2411631670330 ∧ code e2411631670330 = 11207724692538 := by decide
theorem cert_e2411631670330 : check e2411631670330 [[],[]] .chain = true := by decide
def e2411631670470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411631670470 : Closed e2411631670470 ∧ code e2411631670470 = 11207724692678 := by decide
theorem cert_e2411631670470 : check e2411631670470 [[],[]] .chain = true := by decide
def e2411631670498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411631670498 : Closed e2411631670498 ∧ code e2411631670498 = 11207724692706 := by decide
theorem cert_e2411631670498 : check e2411631670498 [[],[]] .chain = true := by decide
def e2411631670510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411631670510 : Closed e2411631670510 ∧ code e2411631670510 = 11207724692718 := by decide
theorem cert_e2411631670510 : check e2411631670510 [[],[]] .sourceHead = true := by decide
def e2411631670518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411631670518 : Closed e2411631670518 ∧ code e2411631670518 = 11207724692726 := by decide
theorem cert_e2411631670518 : check e2411631670518 [[],[]] .sourceHead = true := by decide
def e2411631670798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2411631670798 : Closed e2411631670798 ∧ code e2411631670798 = 11207724693006 := by decide
theorem cert_e2411631670798 : check e2411631670798 [[],[]] .chain = true := by decide
def e2411631670882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2411631670882 : Closed e2411631670882 ∧ code e2411631670882 = 11207724693090 := by decide
theorem cert_e2411631670882 : check e2411631670882 [[],[]] .chain = true := by decide
def e2411631670894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2411631670894 : Closed e2411631670894 ∧ code e2411631670894 = 11207724693102 := by decide
theorem cert_e2411631670894 : check e2411631670894 [[],[]] .sourceHead = true := by decide
def e2411631670906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2411631670906 : Closed e2411631670906 ∧ code e2411631670906 = 11207724693114 := by decide
theorem cert_e2411631670906 : check e2411631670906 [[],[]] .sourceHead = true := by decide
def e2411631671094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411631671094 : Closed e2411631671094 ∧ code e2411631671094 = 11207724693302 := by decide
theorem cert_e2411631671094 : check e2411631671094 [[],[]] .sourceHead = true := by decide
def e2411631671098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411631671098 : Closed e2411631671098 ∧ code e2411631671098 = 11207724693306 := by decide
theorem cert_e2411631671098 : check e2411631671098 [[],[]] .sourceHead = true := by decide
def e2411631676254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2411631676254 : Closed e2411631676254 ∧ code e2411631676254 = 11207724698462 := by decide
theorem cert_e2411631676254 : check e2411631676254 [[],[]] .chain = true := by decide
def e2411631676270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411631676270 : Closed e2411631676270 ∧ code e2411631676270 = 11207724698478 := by decide
theorem cert_e2411631676270 : check e2411631676270 [[],[]] .smaller = true := by decide
def e2411631676278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411631676278 : Closed e2411631676278 ∧ code e2411631676278 = 11207724698486 := by decide
theorem cert_e2411631676278 : check e2411631676278 [[],[]] .smaller = true := by decide
def e2411631676282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2411631676282 : Closed e2411631676282 ∧ code e2411631676282 = 11207724698490 := by decide
theorem cert_e2411631676282 : check e2411631676282 [[],[]] .chain = true := by decide
def e2411631676334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411631676334 : Closed e2411631676334 ∧ code e2411631676334 = 11207724698542 := by decide
theorem cert_e2411631676334 : check e2411631676334 [[],[]] .smaller = true := by decide
def e2411631676346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411631676346 : Closed e2411631676346 ∧ code e2411631676346 = 11207724698554 := by decide
theorem cert_e2411631676346 : check e2411631676346 [[],[]] .smaller = true := by decide
def e2411631676374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411631676374 : Closed e2411631676374 ∧ code e2411631676374 = 11207724698582 := by decide
theorem cert_e2411631676374 : check e2411631676374 [[],[]] .smaller = true := by decide
def e2411631676378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411631676378 : Closed e2411631676378 ∧ code e2411631676378 = 11207724698586 := by decide
theorem cert_e2411631676378 : check e2411631676378 [[],[]] .smaller = true := by decide
def e2411631676394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2411631676394 : Closed e2411631676394 ∧ code e2411631676394 = 11207724698602 := by decide
theorem cert_e2411631676394 : check e2411631676394 [[],[]] .chain = true := by decide
def e2411631676638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411631676638 : Closed e2411631676638 ∧ code e2411631676638 = 11207724698846 := by decide
theorem cert_e2411631676638 : check e2411631676638 [[],[]] .chain = true := by decide
def e2411631676654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411631676654 : Closed e2411631676654 ∧ code e2411631676654 = 11207724698862 := by decide
theorem cert_e2411631676654 : check e2411631676654 [[],[]] .smaller = true := by decide
def e2411631676662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411631676662 : Closed e2411631676662 ∧ code e2411631676662 = 11207724698870 := by decide
theorem cert_e2411631676662 : check e2411631676662 [[],[]] .smaller = true := by decide
def e2411631676666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411631676666 : Closed e2411631676666 ∧ code e2411631676666 = 11207724698874 := by decide
theorem cert_e2411631676666 : check e2411631676666 [[],[]] .chain = true := by decide
def e2411631676990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2411631676990 : Closed e2411631676990 ∧ code e2411631676990 = 11207724699198 := by decide
theorem cert_e2411631676990 : check e2411631676990 [[],[]] .chain = true := by decide
def e2411631677038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411631677038 : Closed e2411631677038 ∧ code e2411631677038 = 11207724699246 := by decide
theorem cert_e2411631677038 : check e2411631677038 [[],[]] .smaller = true := by decide
def e2411631677050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411631677050 : Closed e2411631677050 ∧ code e2411631677050 = 11207724699258 := by decide
theorem cert_e2411631677050 : check e2411631677050 [[],[]] .smaller = true := by decide
def e2411631677238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411631677238 : Closed e2411631677238 ∧ code e2411631677238 = 11207724699446 := by decide
theorem cert_e2411631677238 : check e2411631677238 [[],[]] .smaller = true := by decide
def e2411631677242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411631677242 : Closed e2411631677242 ∧ code e2411631677242 = 11207724699450 := by decide
theorem cert_e2411631677242 : check e2411631677242 [[],[]] .smaller = true := by decide
def e2411631677326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2411631677326 : Closed e2411631677326 ∧ code e2411631677326 = 11207724699534 := by decide
theorem cert_e2411631677326 : check e2411631677326 [[],[]] .chain = true := by decide
def e2411631677338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411631677338 : Closed e2411631677338 ∧ code e2411631677338 = 11207724699546 := by decide
theorem cert_e2411631677338 : check e2411631677338 [[],[]] .chain = true := by decide
def e2411631684718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411631684718 : Closed e2411631684718 ∧ code e2411631684718 = 11207724706926 := by decide
theorem cert_e2411631684718 : check e2411631684718 [[],[]] .chain = true := by decide
def e2411631684730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411631684730 : Closed e2411631684730 ∧ code e2411631684730 = 11207724706938 := by decide
theorem cert_e2411631684730 : check e2411631684730 [[],[]] .chain = true := by decide
def e2411631684894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411631684894 : Closed e2411631684894 ∧ code e2411631684894 = 11207724707102 := by decide
theorem cert_e2411631684894 : check e2411631684894 [[],[]] .chain = true := by decide
def e2411631685062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411631685062 : Closed e2411631685062 ∧ code e2411631685062 = 11207724707270 := by decide
theorem cert_e2411631685062 : check e2411631685062 [[],[]] .chain = true := by decide
def e2411631685166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2411631685166 : Closed e2411631685166 ∧ code e2411631685166 = 11207724707374 := by decide
theorem cert_e2411631685166 : check e2411631685166 [[],[]] .chain = true := by decide
def e2411631685346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2411631685346 : Closed e2411631685346 ∧ code e2411631685346 = 11207724707554 := by decide
theorem cert_e2411631685346 : check e2411631685346 [[],[]] .chain = true := by decide
def e2411631685358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2411631685358 : Closed e2411631685358 ∧ code e2411631685358 = 11207724707566 := by decide
theorem cert_e2411631685358 : check e2411631685358 [[],[]] .sourceHead = true := by decide
def e2411631685398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2411631685398 : Closed e2411631685398 ∧ code e2411631685398 = 11207724707606 := by decide
theorem cert_e2411631685398 : check e2411631685398 [[],[]] .chain = true := by decide
def e2411631685402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411631685402 : Closed e2411631685402 ∧ code e2411631685402 = 11207724707610 := by decide
theorem cert_e2411631685402 : check e2411631685402 [[],[]] .chain = true := by decide
def e2411631685446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411631685446 : Closed e2411631685446 ∧ code e2411631685446 = 11207724707654 := by decide
theorem cert_e2411631685446 : check e2411631685446 [[],[]] .chain = true := by decide
def e2411631685474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2411631685474 : Closed e2411631685474 ∧ code e2411631685474 = 11207724707682 := by decide
theorem cert_e2411631685474 : check e2411631685474 [[],[]] .chain = true := by decide
def e2411631685486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2411631685486 : Closed e2411631685486 ∧ code e2411631685486 = 11207724707694 := by decide
theorem cert_e2411631685486 : check e2411631685486 [[],[]] .sourceHead = true := by decide
def e2411631685494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2411631685494 : Closed e2411631685494 ∧ code e2411631685494 = 11207724707702 := by decide
theorem cert_e2411631685494 : check e2411631685494 [[],[]] .sourceHead = true := by decide
def e2411631685854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2411631685854 : Closed e2411631685854 ∧ code e2411631685854 = 11207724708062 := by decide
theorem cert_e2411631685854 : check e2411631685854 [[],[]] .chain = true := by decide
def e2411631685882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2411631685882 : Closed e2411631685882 ∧ code e2411631685882 = 11207724708090 := by decide
theorem cert_e2411631685882 : check e2411631685882 [[],[]] .chain = true := by decide
def e2411631686430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411631686430 : Closed e2411631686430 ∧ code e2411631686430 = 11207724708638 := by decide
theorem cert_e2411631686430 : check e2411631686430 [[],[]] .chain = true := by decide
def e2411631686598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411631686598 : Closed e2411631686598 ∧ code e2411631686598 = 11207724708806 := by decide
theorem cert_e2411631686598 : check e2411631686598 [[],[]] .chain = true := by decide
def e2411631687742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2411631687742 : Closed e2411631687742 ∧ code e2411631687742 = 11207724709950 := by decide
theorem cert_e2411631687742 : check e2411631687742 [[],[]] .chain = true := by decide
def e2411631688162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2411631688162 : Closed e2411631688162 ∧ code e2411631688162 = 11207724710370 := by decide
theorem cert_e2411631688162 : check e2411631688162 [[],[]] .chain = true := by decide
def e2411631688174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2411631688174 : Closed e2411631688174 ∧ code e2411631688174 = 11207724710382 := by decide
theorem cert_e2411631688174 : check e2411631688174 [[],[]] .sourceHead = true := by decide
def e2411631688734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2411631688734 : Closed e2411631688734 ∧ code e2411631688734 = 11207724710942 := by decide
theorem cert_e2411631688734 : check e2411631688734 [[],[]] .chain = true := by decide
def e2411631688758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411631688758 : Closed e2411631688758 ∧ code e2411631688758 = 11207724710966 := by decide
theorem cert_e2411631688758 : check e2411631688758 [[],[]] .chain = true := by decide
end Blc.Floor43
