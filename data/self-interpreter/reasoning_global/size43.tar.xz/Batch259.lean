import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405968490010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405968490010 : Closed e2405968490010 ∧ code e2405968490010 = 11202061512218 := by decide
private def t_e2405968490010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405968490010 : ¬ IsSelfInterpreter e2405968490010 :=
  wSource (t := t_e2405968490010) (replay_sound (ps := []) (t := e2405968490010) (by decide)) (by decide)
def e2405968493082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405968493082 : Closed e2405968493082 ∧ code e2405968493082 = 11202061515290 := by decide
private def t_e2405968493082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405968493082 : ¬ IsSelfInterpreter e2405968493082 :=
  wSource (t := t_e2405968493082) (replay_sound (ps := []) (t := e2405968493082) (by decide)) (by decide)
def e2405968505370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405968505370 : Closed e2405968505370 ∧ code e2405968505370 = 11202061527578 := by decide
private def t_e2405968505370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405968505370 : ¬ IsSelfInterpreter e2405968505370 :=
  wSource (t := t_e2405968505370) (replay_sound (ps := []) (t := e2405968505370) (by decide)) (by decide)
def e2405968513050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405968513050 : Closed e2405968513050 ∧ code e2405968513050 = 11202061535258 := by decide
theorem cert_e2405968513050 : check e2405968513050 [[]] .width = true := by decide
def e2405968519194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405968519194 : Closed e2405968519194 ∧ code e2405968519194 = 11202061541402 := by decide
theorem cert_e2405968519194 : check e2405968519194 [[]] .width = true := by decide
def e2405968519286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405968519286 : Closed e2405968519286 ∧ code e2405968519286 = 11202061541494 := by decide
private def t_e2405968519286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405968519286 : ¬ IsSelfInterpreter e2405968519286 :=
  wSource (t := t_e2405968519286) (replay_sound (ps := []) (t := e2405968519286) (by decide)) (by decide)
def e2405968519530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405968519530 : Closed e2405968519530 ∧ code e2405968519530 = 11202061541738 := by decide
private def t_e2405968519530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405968519530 : ¬ IsSelfInterpreter e2405968519530 :=
  wSource (t := t_e2405968519530) (replay_sound (ps := []) (t := e2405968519530) (by decide)) (by decide)
def e2405968519578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405968519578 : Closed e2405968519578 ∧ code e2405968519578 = 11202061541786 := by decide
private def t_e2405968519578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405968519578 : ¬ IsSelfInterpreter e2405968519578 :=
  wSource (t := t_e2405968519578) (replay_sound (ps := []) (t := e2405968519578) (by decide)) (by decide)
def e2405968523462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405968523462 : Closed e2405968523462 ∧ code e2405968523462 = 11202061545670 := by decide
theorem cert_e2405968523462 : check e2405968523462 [[]] .width = true := by decide
def e2405968525338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405968525338 : Closed e2405968525338 ∧ code e2405968525338 = 11202061547546 := by decide
theorem cert_e2405968525338 : check e2405968525338 [[]] .width = true := by decide
def e2405968537626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405968537626 : Closed e2405968537626 ∧ code e2405968537626 = 11202061559834 := by decide
theorem cert_e2405968537626 : check e2405968537626 [[]] .width = true := by decide
def e2405968539162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405968539162 : Closed e2405968539162 ∧ code e2405968539162 = 11202061561370 := by decide
private def t_e2405968539162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405968539162 : ¬ IsSelfInterpreter e2405968539162 :=
  wSource (t := t_e2405968539162) (replay_sound (ps := []) (t := e2405968539162) (by decide)) (by decide)
def e2405968542234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405968542234 : Closed e2405968542234 ∧ code e2405968542234 = 11202061564442 := by decide
private def t_e2405968542234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405968542234 : ¬ IsSelfInterpreter e2405968542234 :=
  wSource (t := t_e2405968542234) (replay_sound (ps := []) (t := e2405968542234) (by decide)) (by decide)
def e2405968543770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405968543770 : Closed e2405968543770 ∧ code e2405968543770 = 11202061565978 := by decide
theorem cert_e2405968543770 : check e2405968543770 [[]] .width = true := by decide
def e2405968543862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405968543862 : Closed e2405968543862 ∧ code e2405968543862 = 11202061566070 := by decide
theorem cert_e2405968543862 : check e2405968543862 [[]] .width = true := by decide
def e2405968544106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405968544106 : Closed e2405968544106 ∧ code e2405968544106 = 11202061566314 := by decide
theorem cert_e2405968544106 : check e2405968544106 [[]] .width = true := by decide
def e2405968544154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405968544154 : Closed e2405968544154 ∧ code e2405968544154 = 11202061566362 := by decide
theorem cert_e2405968544154 : check e2405968544154 [[]] .width = true := by decide
def e2405968545162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405968545162 : Closed e2405968545162 ∧ code e2405968545162 = 11202061567370 := by decide
theorem cert_e2405968545162 : check e2405968545162 [[]] .width = true := by decide
def e2405968545186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405968545186 : Closed e2405968545186 ∧ code e2405968545186 = 11202061567394 := by decide
private def t_e2405968545186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2405968545186 : ¬ IsSelfInterpreter e2405968545186 :=
  wSource (t := t_e2405968545186) (replay_sound (ps := []) (t := e2405968545186) (by decide)) (by decide)
def e2405968545294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405968545294 : Closed e2405968545294 ∧ code e2405968545294 = 11202061567502 := by decide
theorem cert_e2405968545294 : check e2405968545294 [[]] .width = true := by decide
def e2405968545306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405968545306 : Closed e2405968545306 ∧ code e2405968545306 = 11202061567514 := by decide
private def t_e2405968545306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2405968545306 : ¬ IsSelfInterpreter e2405968545306 :=
  wSource (t := t_e2405968545306) (replay_sound (ps := []) (t := e2405968545306) (by decide)) (by decide)
def e2405968545378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405968545378 : Closed e2405968545378 ∧ code e2405968545378 = 11202061567586 := by decide
theorem cert_e2405968545378 : check e2405968545378 [[]] .width = true := by decide
def e2405968560326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405968560326 : Closed e2405968560326 ∧ code e2405968560326 = 11202061582534 := by decide
theorem cert_e2405968560326 : check e2405968560326 [[]] .width = true := by decide
def e2405968568346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405968568346 : Closed e2405968568346 ∧ code e2405968568346 = 11202061590554 := by decide
theorem cert_e2405968568346 : check e2405968568346 [[]] .width = true := by decide
def e2405968568438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405968568438 : Closed e2405968568438 ∧ code e2405968568438 = 11202061590646 := by decide
private def t_e2405968568438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405968568438 : ¬ IsSelfInterpreter e2405968568438 :=
  wSource (t := t_e2405968568438) (replay_sound (ps := []) (t := e2405968568438) (by decide)) (by decide)
def e2405968568682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405968568682 : Closed e2405968568682 ∧ code e2405968568682 = 11202061590890 := by decide
private def t_e2405968568682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405968568682 : ¬ IsSelfInterpreter e2405968568682 :=
  wSource (t := t_e2405968568682) (replay_sound (ps := []) (t := e2405968568682) (by decide)) (by decide)
def e2405968568730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405968568730 : Closed e2405968568730 ∧ code e2405968568730 = 11202061590938 := by decide
private def t_e2405968568730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405968568730 : ¬ IsSelfInterpreter e2405968568730 :=
  wSource (t := t_e2405968568730) (replay_sound (ps := []) (t := e2405968568730) (by decide)) (by decide)
def e2405968582682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405968582682 : Closed e2405968582682 ∧ code e2405968582682 = 11202061604890 := by decide
theorem cert_e2405968582682 : check e2405968582682 [[]] .width = true := by decide
def e2405968593094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405968593094 : Closed e2405968593094 ∧ code e2405968593094 = 11202061615302 := by decide
theorem cert_e2405968593094 : check e2405968593094 [[]] .width = true := by decide
def e2405968615962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405968615962 : Closed e2405968615962 ∧ code e2405968615962 = 11202061638170 := by decide
private def t_e2405968615962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405968615962 : ¬ IsSelfInterpreter e2405968615962 :=
  wSource (t := t_e2405968615962) (replay_sound (ps := []) (t := e2405968615962) (by decide)) (by decide)
def e2405968617498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405968617498 : Closed e2405968617498 ∧ code e2405968617498 = 11202061639706 := by decide
theorem cert_e2405968617498 : check e2405968617498 [[]] .width = true := by decide
def e2405968617590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405968617590 : Closed e2405968617590 ∧ code e2405968617590 = 11202061639798 := by decide
private def t_e2405968617590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405968617590 : ¬ IsSelfInterpreter e2405968617590 :=
  wSource (t := t_e2405968617590) (replay_sound (ps := []) (t := e2405968617590) (by decide)) (by decide)
def e2405968617834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405968617834 : Closed e2405968617834 ∧ code e2405968617834 = 11202061640042 := by decide
private def t_e2405968617834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405968617834 : ¬ IsSelfInterpreter e2405968617834 :=
  wSource (t := t_e2405968617834) (replay_sound (ps := []) (t := e2405968617834) (by decide)) (by decide)
def e2405968617882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405968617882 : Closed e2405968617882 ∧ code e2405968617882 = 11202061640090 := by decide
private def t_e2405968617882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405968617882 : ¬ IsSelfInterpreter e2405968617882 :=
  wSource (t := t_e2405968617882) (replay_sound (ps := []) (t := e2405968617882) (by decide)) (by decide)
def e2405968642074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2405968642074 : Closed e2405968642074 ∧ code e2405968642074 = 11202061664282 := by decide
theorem cert_e2405968642074 : check e2405968642074 [[]] .width = true := by decide
def e2405968642166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2405968642166 : Closed e2405968642166 ∧ code e2405968642166 = 11202061664374 := by decide
theorem cert_e2405968642166 : check e2405968642166 [[]] .width = true := by decide
def e2405968642410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2405968642410 : Closed e2405968642410 ∧ code e2405968642410 = 11202061664618 := by decide
theorem cert_e2405968642410 : check e2405968642410 [[]] .width = true := by decide
def e2405968642458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2405968642458 : Closed e2405968642458 ∧ code e2405968642458 = 11202061664666 := by decide
theorem cert_e2405968642458 : check e2405968642458 [[]] .width = true := by decide
def e2405968642542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2405968642542 : Closed e2405968642542 ∧ code e2405968642542 = 11202061664750 := by decide
theorem cert_e2405968642542 : check e2405968642542 [[]] .width = true := by decide
def e2405968643466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2405968643466 : Closed e2405968643466 ∧ code e2405968643466 = 11202061665674 := by decide
theorem cert_e2405968643466 : check e2405968643466 [[]] .width = true := by decide
def e2405968643490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2405968643490 : Closed e2405968643490 ∧ code e2405968643490 = 11202061665698 := by decide
theorem cert_e2405968643490 : check e2405968643490 [[]] .width = true := by decide
def e2405968643502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2405968643502 : Closed e2405968643502 ∧ code e2405968643502 = 11202061665710 := by decide
theorem cert_e2405968643502 : check e2405968643502 [[]] .width = true := by decide
def e2405968643510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2405968643510 : Closed e2405968643510 ∧ code e2405968643510 = 11202061665718 := by decide
theorem cert_e2405968643510 : check e2405968643510 [[]] .width = true := by decide
def e2405968643514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2405968643514 : Closed e2405968643514 ∧ code e2405968643514 = 11202061665722 := by decide
theorem cert_e2405968643514 : check e2405968643514 [[]] .width = true := by decide
def e2405968643542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2405968643542 : Closed e2405968643542 ∧ code e2405968643542 = 11202061665750 := by decide
theorem cert_e2405968643542 : check e2405968643542 [[]] .width = true := by decide
def e2405968643546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2405968643546 : Closed e2405968643546 ∧ code e2405968643546 = 11202061665754 := by decide
theorem cert_e2405968643546 : check e2405968643546 [[]] .width = true := by decide
def e2405968643562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2405968643562 : Closed e2405968643562 ∧ code e2405968643562 = 11202061665770 := by decide
theorem cert_e2405968643562 : check e2405968643562 [[]] .width = true := by decide
def e2405968643598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2405968643598 : Closed e2405968643598 ∧ code e2405968643598 = 11202061665806 := by decide
theorem cert_e2405968643598 : check e2405968643598 [[]] .width = true := by decide
def e2405968643610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405968643610 : Closed e2405968643610 ∧ code e2405968643610 = 11202061665818 := by decide
theorem cert_e2405968643610 : check e2405968643610 [[]] .width = true := by decide
def e2405968643682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2405968643682 : Closed e2405968643682 ∧ code e2405968643682 = 11202061665890 := by decide
theorem cert_e2405968643682 : check e2405968643682 [[]] .width = true := by decide
def e2405968643694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2405968643694 : Closed e2405968643694 ∧ code e2405968643694 = 11202061665902 := by decide
theorem cert_e2405968643694 : check e2405968643694 [[]] .width = true := by decide
def e2405968643702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2405968643702 : Closed e2405968643702 ∧ code e2405968643702 = 11202061665910 := by decide
theorem cert_e2405968643702 : check e2405968643702 [[]] .width = true := by decide
def e2405968643706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2405968643706 : Closed e2405968643706 ∧ code e2405968643706 = 11202061665914 := by decide
theorem cert_e2405968643706 : check e2405968643706 [[]] .width = true := by decide
def e2405968643894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2405968643894 : Closed e2405968643894 ∧ code e2405968643894 = 11202061666102 := by decide
theorem cert_e2405968643894 : check e2405968643894 [[]] .width = true := by decide
def e2405968643898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2405968643898 : Closed e2405968643898 ∧ code e2405968643898 = 11202061666106 := by decide
theorem cert_e2405968643898 : check e2405968643898 [[]] .width = true := by decide
def e2405968643994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2405968643994 : Closed e2405968643994 ∧ code e2405968643994 = 11202061666202 := by decide
theorem cert_e2405968643994 : check e2405968643994 [[]] .width = true := by decide
def e2405968647594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2405968647594 : Closed e2405968647594 ∧ code e2405968647594 = 11202061669802 := by decide
theorem cert_e2405968647594 : check e2405968647594 [[]] .width = true := by decide
def e2405968647690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2405968647690 : Closed e2405968647690 ∧ code e2405968647690 = 11202061669898 := by decide
theorem cert_e2405968647690 : check e2405968647690 [[]] .width = true := by decide
def e2405968647734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2405968647734 : Closed e2405968647734 ∧ code e2405968647734 = 11202061669942 := by decide
theorem cert_e2405968647734 : check e2405968647734 [[]] .width = true := by decide
def e2405968647738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2405968647738 : Closed e2405968647738 ∧ code e2405968647738 = 11202061669946 := by decide
theorem cert_e2405968647738 : check e2405968647738 [[]] .width = true := by decide
def e2405968647786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2405968647786 : Closed e2405968647786 ∧ code e2405968647786 = 11202061669994 := by decide
theorem cert_e2405968647786 : check e2405968647786 [[]] .width = true := by decide
def e2405968647810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2405968647810 : Closed e2405968647810 ∧ code e2405968647810 = 11202061670018 := by decide
theorem cert_e2405968647810 : check e2405968647810 [[]] .width = true := by decide
def e2405968647822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2405968647822 : Closed e2405968647822 ∧ code e2405968647822 = 11202061670030 := by decide
theorem cert_e2405968647822 : check e2405968647822 [[]] .width = true := by decide
def e2405968647834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2405968647834 : Closed e2405968647834 ∧ code e2405968647834 = 11202061670042 := by decide
theorem cert_e2405968647834 : check e2405968647834 [[]] .width = true := by decide
def e2405968647878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2405968647878 : Closed e2405968647878 ∧ code e2405968647878 = 11202061670086 := by decide
theorem cert_e2405968647878 : check e2405968647878 [[]] .width = true := by decide
def e2405968647958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2405968647958 : Closed e2405968647958 ∧ code e2405968647958 = 11202061670166 := by decide
theorem cert_e2405968647958 : check e2405968647958 [[]] .width = true := by decide
def e2405968647962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2405968647962 : Closed e2405968647962 ∧ code e2405968647962 = 11202061670170 := by decide
theorem cert_e2405968647962 : check e2405968647962 [[]] .width = true := by decide
def e2405968648006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2405968648006 : Closed e2405968648006 ∧ code e2405968648006 = 11202061670214 := by decide
theorem cert_e2405968648006 : check e2405968648006 [[]] .width = true := by decide
def e2405968648034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2405968648034 : Closed e2405968648034 ∧ code e2405968648034 = 11202061670242 := by decide
private def t_e2405968648034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem cert_e2405968648034 : ¬ IsSelfInterpreter e2405968648034 :=
  wSource (t := t_e2405968648034) (replay_sound (ps := []) (t := e2405968648034) (by decide)) (by decide)
def e2405968648218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405968648218 : Closed e2405968648218 ∧ code e2405968648218 = 11202061670426 := by decide
theorem cert_e2405968648218 : check e2405968648218 [[]] .width = true := by decide
def e2405968648310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405968648310 : Closed e2405968648310 ∧ code e2405968648310 = 11202061670518 := by decide
theorem cert_e2405968648310 : check e2405968648310 [[]] .width = true := by decide
def e2405968648554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405968648554 : Closed e2405968648554 ∧ code e2405968648554 = 11202061670762 := by decide
theorem cert_e2405968648554 : check e2405968648554 [[]] .width = true := by decide
def e2405968648578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2405968648578 : Closed e2405968648578 ∧ code e2405968648578 = 11202061670786 := by decide
theorem cert_e2405968648578 : check e2405968648578 [[]] .width = true := by decide
def e2405968648590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405968648590 : Closed e2405968648590 ∧ code e2405968648590 = 11202061670798 := by decide
theorem cert_e2405968648590 : check e2405968648590 [[]] .width = true := by decide
def e2405968648602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405968648602 : Closed e2405968648602 ∧ code e2405968648602 = 11202061670810 := by decide
theorem cert_e2405968648602 : check e2405968648602 [[]] .width = true := by decide
def e2405968648646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405968648646 : Closed e2405968648646 ∧ code e2405968648646 = 11202061670854 := by decide
theorem cert_e2405968648646 : check e2405968648646 [[]] .width = true := by decide
def e2405968649246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2405968649246 : Closed e2405968649246 ∧ code e2405968649246 = 11202061671454 := by decide
theorem cert_e2405968649246 : check e2405968649246 [[]] .width = true := by decide
def e2405968649414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405968649414 : Closed e2405968649414 ∧ code e2405968649414 = 11202061671622 := by decide
theorem cert_e2405968649414 : check e2405968649414 [[]] .width = true := by decide
def e2405968649442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2405968649442 : Closed e2405968649442 ∧ code e2405968649442 = 11202061671650 := by decide
theorem cert_e2405968649442 : check e2405968649442 [[]] .width = true := by decide
def e2405968664106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2405968664106 : Closed e2405968664106 ∧ code e2405968664106 = 11202061686314 := by decide
theorem cert_e2405968664106 : check e2405968664106 [[]] .width = true := by decide
def e2405968664202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2405968664202 : Closed e2405968664202 ∧ code e2405968664202 = 11202061686410 := by decide
private def t_e2405968664202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem cert_e2405968664202 : ¬ IsSelfInterpreter e2405968664202 :=
  wSource (t := t_e2405968664202) (replay_sound (ps := []) (t := e2405968664202) (by decide)) (by decide)
def e2405968664226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405968664226 : Closed e2405968664226 ∧ code e2405968664226 = 11202061686434 := by decide
private def t_e2405968664226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem cert_e2405968664226 : ¬ IsSelfInterpreter e2405968664226 :=
  wSource (t := t_e2405968664226) (replay_sound (ps := []) (t := e2405968664226) (by decide)) (by decide)
def e2405968664586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2405968664586 : Closed e2405968664586 ∧ code e2405968664586 = 11202061686794 := by decide
theorem cert_e2405968664586 : check e2405968664586 [[]] .width = true := by decide
def e2405968664634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2405968664634 : Closed e2405968664634 ∧ code e2405968664634 = 11202061686842 := by decide
theorem cert_e2405968664634 : check e2405968664634 [[]] .width = true := by decide
def e2405968664682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2405968664682 : Closed e2405968664682 ∧ code e2405968664682 = 11202061686890 := by decide
private def t_e2405968664682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem cert_e2405968664682 : ¬ IsSelfInterpreter e2405968664682 :=
  wSource (t := t_e2405968664682) (replay_sound (ps := []) (t := e2405968664682) (by decide)) (by decide)
def e2405968664730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2405968664730 : Closed e2405968664730 ∧ code e2405968664730 = 11202061686938 := by decide
theorem cert_e2405968664730 : check e2405968664730 [[]] .width = true := by decide
def e2405968664774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2405968664774 : Closed e2405968664774 ∧ code e2405968664774 = 11202061686982 := by decide
theorem cert_e2405968664774 : check e2405968664774 [[]] .width = true := by decide
def e2405968664970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2405968664970 : Closed e2405968664970 ∧ code e2405968664970 = 11202061687178 := by decide
theorem cert_e2405968664970 : check e2405968664970 [[]] .width = true := by decide
def e2405968664994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2405968664994 : Closed e2405968664994 ∧ code e2405968664994 = 11202061687202 := by decide
private def t_e2405968664994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem cert_e2405968664994 : ¬ IsSelfInterpreter e2405968664994 :=
  wSource (t := t_e2405968664994) (replay_sound (ps := []) (t := e2405968664994) (by decide)) (by decide)
def e2405968665090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2405968665090 : Closed e2405968665090 ∧ code e2405968665090 = 11202061687298 := by decide
private def t_e2405968665090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem cert_e2405968665090 : ¬ IsSelfInterpreter e2405968665090 :=
  wSource (t := t_e2405968665090) (replay_sound (ps := []) (t := e2405968665090) (by decide)) (by decide)
def e2405968665102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2405968665102 : Closed e2405968665102 ∧ code e2405968665102 = 11202061687310 := by decide
private def t_e2405968665102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem cert_e2405968665102 : ¬ IsSelfInterpreter e2405968665102 :=
  wSource (t := t_e2405968665102) (replay_sound (ps := []) (t := e2405968665102) (by decide)) (by decide)
def e2405968665114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405968665114 : Closed e2405968665114 ∧ code e2405968665114 = 11202061687322 := by decide
private def t_e2405968665114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2405968665114 : ¬ IsSelfInterpreter e2405968665114 :=
  wSource (t := t_e2405968665114) (replay_sound (ps := []) (t := e2405968665114) (by decide)) (by decide)
def e2405968665186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405968665186 : Closed e2405968665186 ∧ code e2405968665186 = 11202061687394 := by decide
private def t_e2405968665186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem cert_e2405968665186 : ¬ IsSelfInterpreter e2405968665186 :=
  wSource (t := t_e2405968665186) (replay_sound (ps := []) (t := e2405968665186) (by decide)) (by decide)
def e2405968666650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405968666650 : Closed e2405968666650 ∧ code e2405968666650 = 11202061688858 := by decide
theorem cert_e2405968666650 : check e2405968666650 [[]] .width = true := by decide
def e2405968666734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2405968666734 : Closed e2405968666734 ∧ code e2405968666734 = 11202061688942 := by decide
theorem cert_e2405968666734 : check e2405968666734 [[]] .width = true := by decide
def e2405968666742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405968666742 : Closed e2405968666742 ∧ code e2405968666742 = 11202061688950 := by decide
private def t_e2405968666742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem cert_e2405968666742 : ¬ IsSelfInterpreter e2405968666742 :=
  wSource (t := t_e2405968666742) (replay_sound (ps := []) (t := e2405968666742) (by decide)) (by decide)
def e2405968666746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2405968666746 : Closed e2405968666746 ∧ code e2405968666746 = 11202061688954 := by decide
theorem cert_e2405968666746 : check e2405968666746 [[]] .width = true := by decide
def e2405968666986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405968666986 : Closed e2405968666986 ∧ code e2405968666986 = 11202061689194 := by decide
private def t_e2405968666986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem cert_e2405968666986 : ¬ IsSelfInterpreter e2405968666986 :=
  wSource (t := t_e2405968666986) (replay_sound (ps := []) (t := e2405968666986) (by decide)) (by decide)
def e2405968667022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405968667022 : Closed e2405968667022 ∧ code e2405968667022 = 11202061689230 := by decide
theorem cert_e2405968667022 : check e2405968667022 [[]] .width = true := by decide
def e2405968667034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405968667034 : Closed e2405968667034 ∧ code e2405968667034 = 11202061689242 := by decide
private def t_e2405968667034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem cert_e2405968667034 : ¬ IsSelfInterpreter e2405968667034 :=
  wSource (t := t_e2405968667034) (replay_sound (ps := []) (t := e2405968667034) (by decide)) (by decide)
def e2405968667078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405968667078 : Closed e2405968667078 ∧ code e2405968667078 = 11202061689286 := by decide
theorem cert_e2405968667078 : check e2405968667078 [[]] .width = true := by decide
def e2405968668042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2405968668042 : Closed e2405968668042 ∧ code e2405968668042 = 11202061690250 := by decide
theorem cert_e2405968668042 : check e2405968668042 [[]] .width = true := by decide
def e2405968668066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2405968668066 : Closed e2405968668066 ∧ code e2405968668066 = 11202061690274 := by decide
private def t_e2405968668066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem cert_e2405968668066 : ¬ IsSelfInterpreter e2405968668066 :=
  wSource (t := t_e2405968668066) (replay_sound (ps := []) (t := e2405968668066) (by decide)) (by decide)
def e2405968668162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2405968668162 : Closed e2405968668162 ∧ code e2405968668162 = 11202061690370 := by decide
theorem cert_e2405968668162 : check e2405968668162 [[]] .width = true := by decide
def e2405968668174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2405968668174 : Closed e2405968668174 ∧ code e2405968668174 = 11202061690382 := by decide
theorem cert_e2405968668174 : check e2405968668174 [[]] .width = true := by decide
def e2405968668186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405968668186 : Closed e2405968668186 ∧ code e2405968668186 = 11202061690394 := by decide
private def t_e2405968668186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem cert_e2405968668186 : ¬ IsSelfInterpreter e2405968668186 :=
  wSource (t := t_e2405968668186) (replay_sound (ps := []) (t := e2405968668186) (by decide)) (by decide)
def e2405968668258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2405968668258 : Closed e2405968668258 ∧ code e2405968668258 = 11202061690466 := by decide
theorem cert_e2405968668258 : check e2405968668258 [[]] .width = true := by decide
def e2405968714242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2405968714242 : Closed e2405968714242 ∧ code e2405968714242 = 11202061736450 := by decide
theorem cert_e2405968714242 : check e2405968714242 [[]] .width = true := by decide
def e2405968714266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405968714266 : Closed e2405968714266 ∧ code e2405968714266 = 11202061736474 := by decide
private def t_e2405968714266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem cert_e2405968714266 : ¬ IsSelfInterpreter e2405968714266 :=
  wSource (t := t_e2405968714266) (replay_sound (ps := []) (t := e2405968714266) (by decide)) (by decide)
def e2405970532378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405970532378 : Closed e2405970532378 ∧ code e2405970532378 = 11202063554586 := by decide
theorem cert_e2405970532378 : check e2405970532378 [[]] .width = true := by decide
def e2405970536474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405970536474 : Closed e2405970536474 ∧ code e2405970536474 = 11202063558682 := by decide
theorem cert_e2405970536474 : check e2405970536474 [[]] .width = true := by decide
def e2405970698266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405970698266 : Closed e2405970698266 ∧ code e2405970698266 = 11202063720474 := by decide
theorem cert_e2405970698266 : check e2405970698266 [[]] .width = true := by decide
def e2405970698358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405970698358 : Closed e2405970698358 ∧ code e2405970698358 = 11202063720566 := by decide
theorem cert_e2405970698358 : check e2405970698358 [[]] .width = true := by decide
def e2405970698602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405970698602 : Closed e2405970698602 ∧ code e2405970698602 = 11202063720810 := by decide
theorem cert_e2405970698602 : check e2405970698602 [[]] .width = true := by decide
def e2405970698650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405970698650 : Closed e2405970698650 ∧ code e2405970698650 = 11202063720858 := by decide
theorem cert_e2405970698650 : check e2405970698650 [[]] .width = true := by decide
def e2405970714650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405970714650 : Closed e2405970714650 ∧ code e2405970714650 = 11202063736858 := by decide
theorem cert_e2405970714650 : check e2405970714650 [[]] .width = true := by decide
def e2405970714742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405970714742 : Closed e2405970714742 ∧ code e2405970714742 = 11202063736950 := by decide
theorem cert_e2405970714742 : check e2405970714742 [[]] .width = true := by decide
def e2405970714986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405970714986 : Closed e2405970714986 ∧ code e2405970714986 = 11202063737194 := by decide
theorem cert_e2405970714986 : check e2405970714986 [[]] .width = true := by decide
def e2405970715034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405970715034 : Closed e2405970715034 ∧ code e2405970715034 = 11202063737242 := by decide
theorem cert_e2405970715034 : check e2405970715034 [[]] .width = true := by decide
def e2405971112134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405971112134 : Closed e2405971112134 ∧ code e2405971112134 = 11202064134342 := by decide
theorem cert_e2405971112134 : check e2405971112134 [[]] .width = true := by decide
def e2405971120326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405971120326 : Closed e2405971120326 ∧ code e2405971120326 = 11202064142534 := by decide
theorem cert_e2405971120326 : check e2405971120326 [[]] .width = true := by decide
def e2405971177670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405971177670 : Closed e2405971177670 ∧ code e2405971177670 = 11202064199878 := by decide
theorem cert_e2405971177670 : check e2405971177670 [[]] .width = true := by decide
def e2405971187738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405971187738 : Closed e2405971187738 ∧ code e2405971187738 = 11202064209946 := by decide
theorem cert_e2405971187738 : check e2405971187738 [[]] .width = true := by decide
def e2405971191834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405971191834 : Closed e2405971191834 ∧ code e2405971191834 = 11202064214042 := by decide
theorem cert_e2405971191834 : check e2405971191834 [[]] .width = true := by decide
def e2405971193370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405971193370 : Closed e2405971193370 ∧ code e2405971193370 = 11202064215578 := by decide
theorem cert_e2405971193370 : check e2405971193370 [[]] .width = true := by decide
def e2405971195418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405971195418 : Closed e2405971195418 ∧ code e2405971195418 = 11202064217626 := by decide
theorem cert_e2405971195418 : check e2405971195418 [[]] .width = true := by decide
def e2405971218630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405971218630 : Closed e2405971218630 ∧ code e2405971218630 = 11202064240838 := by decide
theorem cert_e2405971218630 : check e2405971218630 [[]] .width = true := by decide
def e2405971224602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405971224602 : Closed e2405971224602 ∧ code e2405971224602 = 11202064246810 := by decide
theorem cert_e2405971224602 : check e2405971224602 [[]] .width = true := by decide
def e2405971226138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405971226138 : Closed e2405971226138 ∧ code e2405971226138 = 11202064248346 := by decide
theorem cert_e2405971226138 : check e2405971226138 [[]] .width = true := by decide
def e2405971229210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405971229210 : Closed e2405971229210 ∧ code e2405971229210 = 11202064251418 := by decide
private def t_e2405971229210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405971229210 : ¬ IsSelfInterpreter e2405971229210 :=
  wSource (t := t_e2405971229210) (replay_sound (ps := []) (t := e2405971229210) (by decide)) (by decide)
def e2405971244570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405971244570 : Closed e2405971244570 ∧ code e2405971244570 = 11202064266778 := by decide
theorem cert_e2405971244570 : check e2405971244570 [[]] .width = true := by decide
def e2405971245594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405971245594 : Closed e2405971245594 ∧ code e2405971245594 = 11202064267802 := by decide
private def t_e2405971245594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405971245594 : ¬ IsSelfInterpreter e2405971245594 :=
  wSource (t := t_e2405971245594) (replay_sound (ps := []) (t := e2405971245594) (by decide)) (by decide)
def e2405971484698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405971484698 : Closed e2405971484698 ∧ code e2405971484698 = 11202064506906 := by decide
theorem cert_e2405971484698 : check e2405971484698 [[]] .width = true := by decide
def e2405971484790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405971484790 : Closed e2405971484790 ∧ code e2405971484790 = 11202064506998 := by decide
theorem cert_e2405971484790 : check e2405971484790 [[]] .width = true := by decide
def e2405971485034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405971485034 : Closed e2405971485034 ∧ code e2405971485034 = 11202064507242 := by decide
theorem cert_e2405971485034 : check e2405971485034 [[]] .width = true := by decide
def e2405971485082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405971485082 : Closed e2405971485082 ∧ code e2405971485082 = 11202064507290 := by decide
theorem cert_e2405971485082 : check e2405971485082 [[]] .width = true := by decide
def e2405971501082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405971501082 : Closed e2405971501082 ∧ code e2405971501082 = 11202064523290 := by decide
theorem cert_e2405971501082 : check e2405971501082 [[]] .width = true := by decide
def e2405971501174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405971501174 : Closed e2405971501174 ∧ code e2405971501174 = 11202064523382 := by decide
theorem cert_e2405971501174 : check e2405971501174 [[]] .width = true := by decide
def e2405971501418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405971501418 : Closed e2405971501418 ∧ code e2405971501418 = 11202064523626 := by decide
theorem cert_e2405971501418 : check e2405971501418 [[]] .width = true := by decide
def e2405971501466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405971501466 : Closed e2405971501466 ∧ code e2405971501466 = 11202064523674 := by decide
theorem cert_e2405971501466 : check e2405971501466 [[]] .width = true := by decide
def e2405971845146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405971845146 : Closed e2405971845146 ∧ code e2405971845146 = 11202064867354 := by decide
theorem cert_e2405971845146 : check e2405971845146 [[]] .width = true := by decide
def e2405971845238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405971845238 : Closed e2405971845238 ∧ code e2405971845238 = 11202064867446 := by decide
theorem cert_e2405971845238 : check e2405971845238 [[]] .width = true := by decide
def e2405971845482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405971845482 : Closed e2405971845482 ∧ code e2405971845482 = 11202064867690 := by decide
theorem cert_e2405971845482 : check e2405971845482 [[]] .width = true := by decide
def e2405971845530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405971845530 : Closed e2405971845530 ∧ code e2405971845530 = 11202064867738 := by decide
theorem cert_e2405971845530 : check e2405971845530 [[]] .width = true := by decide
def e2405971898566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405971898566 : Closed e2405971898566 ∧ code e2405971898566 = 11202064920774 := by decide
theorem cert_e2405971898566 : check e2405971898566 [[]] .width = true := by decide
def e2405971906758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405971906758 : Closed e2405971906758 ∧ code e2405971906758 = 11202064928966 := by decide
theorem cert_e2405971906758 : check e2405971906758 [[]] .width = true := by decide
def e2405971908634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405971908634 : Closed e2405971908634 ∧ code e2405971908634 = 11202064930842 := by decide
theorem cert_e2405971908634 : check e2405971908634 [[]] .width = true := by decide
def e2405971984582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405971984582 : Closed e2405971984582 ∧ code e2405971984582 = 11202065006790 := by decide
theorem cert_e2405971984582 : check e2405971984582 [[]] .width = true := by decide
def e2405971985110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405971985110 : Closed e2405971985110 ∧ code e2405971985110 = 11202065007318 := by decide
theorem cert_e2405971985110 : check e2405971985110 [[]] .width = true := by decide
def e2405971985114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405971985114 : Closed e2405971985114 ∧ code e2405971985114 = 11202065007322 := by decide
theorem cert_e2405971985114 : check e2405971985114 [[]] .width = true := by decide
def e2405971985130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405971985130 : Closed e2405971985130 ∧ code e2405971985130 = 11202065007338 := by decide
theorem cert_e2405971985130 : check e2405971985130 [[]] .width = true := by decide
def e2405971985206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405971985206 : Closed e2405971985206 ∧ code e2405971985206 = 11202065007414 := by decide
theorem cert_e2405971985206 : check e2405971985206 [[]] .width = true := by decide
def e2405971985210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405971985210 : Closed e2405971985210 ∧ code e2405971985210 = 11202065007418 := by decide
theorem cert_e2405971985210 : check e2405971985210 [[]] .width = true := by decide
def e2405971985294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405971985294 : Closed e2405971985294 ∧ code e2405971985294 = 11202065007502 := by decide
theorem cert_e2405971985294 : check e2405971985294 [[]] .width = true := by decide
def e2405971985306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405971985306 : Closed e2405971985306 ∧ code e2405971985306 = 11202065007514 := by decide
theorem cert_e2405971985306 : check e2405971985306 [[]] .width = true := by decide
def e2405971987226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405971987226 : Closed e2405971987226 ∧ code e2405971987226 = 11202065009434 := by decide
theorem cert_e2405971987226 : check e2405971987226 [[]] .width = true := by decide
def e2405971987270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405971987270 : Closed e2405971987270 ∧ code e2405971987270 = 11202065009478 := by decide
theorem cert_e2405971987270 : check e2405971987270 [[]] .width = true := by decide
def e2405971987510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405971987510 : Closed e2405971987510 ∧ code e2405971987510 = 11202065009718 := by decide
theorem cert_e2405971987510 : check e2405971987510 [[]] .width = true := by decide
def e2405971987514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405971987514 : Closed e2405971987514 ∧ code e2405971987514 = 11202065009722 := by decide
theorem cert_e2405971987514 : check e2405971987514 [[]] .width = true := by decide
def e2405971987654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405971987654 : Closed e2405971987654 ∧ code e2405971987654 = 11202065009862 := by decide
theorem cert_e2405971987654 : check e2405971987654 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405968490010
#print axioms Blc.Floor43.cert_e2405968493082
#print axioms Blc.Floor43.cert_e2405968505370
#print axioms Blc.Floor43.cert_e2405968519286
#print axioms Blc.Floor43.cert_e2405968519530
#print axioms Blc.Floor43.cert_e2405968519578
#print axioms Blc.Floor43.cert_e2405968539162
#print axioms Blc.Floor43.cert_e2405968542234
#print axioms Blc.Floor43.cert_e2405968545186
#print axioms Blc.Floor43.cert_e2405968545306
#print axioms Blc.Floor43.cert_e2405968568438
#print axioms Blc.Floor43.cert_e2405968568682
#print axioms Blc.Floor43.cert_e2405968568730
#print axioms Blc.Floor43.cert_e2405968615962
#print axioms Blc.Floor43.cert_e2405968617590
#print axioms Blc.Floor43.cert_e2405968617834
#print axioms Blc.Floor43.cert_e2405968617882
#print axioms Blc.Floor43.cert_e2405968648034
#print axioms Blc.Floor43.cert_e2405968664202
#print axioms Blc.Floor43.cert_e2405968664226
#print axioms Blc.Floor43.cert_e2405968664682
#print axioms Blc.Floor43.cert_e2405968664994
#print axioms Blc.Floor43.cert_e2405968665090
#print axioms Blc.Floor43.cert_e2405968665102
#print axioms Blc.Floor43.cert_e2405968665114
#print axioms Blc.Floor43.cert_e2405968665186
#print axioms Blc.Floor43.cert_e2405968666742
#print axioms Blc.Floor43.cert_e2405968666986
#print axioms Blc.Floor43.cert_e2405968667034
#print axioms Blc.Floor43.cert_e2405968668066
#print axioms Blc.Floor43.cert_e2405968668186
#print axioms Blc.Floor43.cert_e2405968714266
#print axioms Blc.Floor43.cert_e2405971229210
#print axioms Blc.Floor43.cert_e2405971245594
