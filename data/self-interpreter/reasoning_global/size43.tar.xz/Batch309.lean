import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411630520030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2411630520030 : Closed e2411630520030 ∧ code e2411630520030 = 11207723542238 := by decide
theorem cert_e2411630520030 : check e2411630520030 [[],[]] .chain = true := by decide
def e2411630520054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2411630520054 : Closed e2411630520054 ∧ code e2411630520054 = 11207723542262 := by decide
theorem cert_e2411630520054 : check e2411630520054 [[],[]] .chain = true := by decide
def e2411630520158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2411630520158 : Closed e2411630520158 ∧ code e2411630520158 = 11207723542366 := by decide
theorem cert_e2411630520158 : check e2411630520158 [[],[]] .chain = true := by decide
def e2411630520174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e2411630520174 : Closed e2411630520174 ∧ code e2411630520174 = 11207723542382 := by decide
theorem cert_e2411630520174 : check e2411630520174 [[],[]] .smaller = true := by decide
def e2411630520182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e2411630520182 : Closed e2411630520182 ∧ code e2411630520182 = 11207723542390 := by decide
theorem cert_e2411630520182 : check e2411630520182 [[],[]] .smaller = true := by decide
def e2411630520186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2411630520186 : Closed e2411630520186 ∧ code e2411630520186 = 11207723542394 := by decide
theorem cert_e2411630520186 : check e2411630520186 [[],[]] .chain = true := by decide
def e2411630520246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e2411630520246 : Closed e2411630520246 ∧ code e2411630520246 = 11207723542454 := by decide
theorem cert_e2411630520246 : check e2411630520246 [[],[]] .smaller = true := by decide
def e2411630520278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2411630520278 : Closed e2411630520278 ∧ code e2411630520278 = 11207723542486 := by decide
theorem cert_e2411630520278 : check e2411630520278 [[],[]] .chain = true := by decide
def e2411630520282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2411630520282 : Closed e2411630520282 ∧ code e2411630520282 = 11207723542490 := by decide
theorem cert_e2411630520282 : check e2411630520282 [[],[]] .chain = true := by decide
def e2411630520798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411630520798 : Closed e2411630520798 ∧ code e2411630520798 = 11207723543006 := by decide
theorem cert_e2411630520798 : check e2411630520798 [[],[]] .chain = true := by decide
def e2411630520822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411630520822 : Closed e2411630520822 ∧ code e2411630520822 = 11207723543030 := by decide
theorem cert_e2411630520822 : check e2411630520822 [[],[]] .chain = true := by decide
def e2411630521566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630521566 : Closed e2411630521566 ∧ code e2411630521566 = 11207723543774 := by decide
theorem cert_e2411630521566 : check e2411630521566 [[],[]] .chain = true := by decide
def e2411630521582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411630521582 : Closed e2411630521582 ∧ code e2411630521582 = 11207723543790 := by decide
theorem cert_e2411630521582 : check e2411630521582 [[],[]] .smaller = true := by decide
def e2411630521590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411630521590 : Closed e2411630521590 ∧ code e2411630521590 = 11207723543798 := by decide
theorem cert_e2411630521590 : check e2411630521590 [[],[]] .smaller = true := by decide
def e2411630521594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630521594 : Closed e2411630521594 ∧ code e2411630521594 = 11207723543802 := by decide
theorem cert_e2411630521594 : check e2411630521594 [[],[]] .chain = true := by decide
def e2411630521974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411630521974 : Closed e2411630521974 ∧ code e2411630521974 = 11207723544182 := by decide
theorem cert_e2411630521974 : check e2411630521974 [[],[]] .smaller = true := by decide
def e2411630522166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630522166 : Closed e2411630522166 ∧ code e2411630522166 = 11207723544374 := by decide
theorem cert_e2411630522166 : check e2411630522166 [[],[]] .chain = true := by decide
def e2411630522170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630522170 : Closed e2411630522170 ∧ code e2411630522170 = 11207723544378 := by decide
theorem cert_e2411630522170 : check e2411630522170 [[],[]] .chain = true := by decide
def e2411630523230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2411630523230 : Closed e2411630523230 ∧ code e2411630523230 = 11207723545438 := by decide
theorem cert_e2411630523230 : check e2411630523230 [[],[]] .chain = true := by decide
def e2411630523246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2411630523246 : Closed e2411630523246 ∧ code e2411630523246 = 11207723545454 := by decide
theorem cert_e2411630523246 : check e2411630523246 [[],[]] .smaller = true := by decide
def e2411630523254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2411630523254 : Closed e2411630523254 ∧ code e2411630523254 = 11207723545462 := by decide
theorem cert_e2411630523254 : check e2411630523254 [[],[]] .smaller = true := by decide
def e2411630523258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2411630523258 : Closed e2411630523258 ∧ code e2411630523258 = 11207723545466 := by decide
theorem cert_e2411630523258 : check e2411630523258 [[],[]] .chain = true := by decide
def e2411630523310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2411630523310 : Closed e2411630523310 ∧ code e2411630523310 = 11207723545518 := by decide
theorem cert_e2411630523310 : check e2411630523310 [[],[]] .smaller = true := by decide
def e2411630523322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2411630523322 : Closed e2411630523322 ∧ code e2411630523322 = 11207723545530 := by decide
theorem cert_e2411630523322 : check e2411630523322 [[],[]] .smaller = true := by decide
def e2411630523350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2411630523350 : Closed e2411630523350 ∧ code e2411630523350 = 11207723545558 := by decide
theorem cert_e2411630523350 : check e2411630523350 [[],[]] .smaller = true := by decide
def e2411630523354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2411630523354 : Closed e2411630523354 ∧ code e2411630523354 = 11207723545562 := by decide
theorem cert_e2411630523354 : check e2411630523354 [[],[]] .smaller = true := by decide
def e2411630523370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2411630523370 : Closed e2411630523370 ∧ code e2411630523370 = 11207723545578 := by decide
theorem cert_e2411630523370 : check e2411630523370 [[],[]] .chain = true := by decide
def e2411630523614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630523614 : Closed e2411630523614 ∧ code e2411630523614 = 11207723545822 := by decide
theorem cert_e2411630523614 : check e2411630523614 [[],[]] .chain = true := by decide
def e2411630523630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411630523630 : Closed e2411630523630 ∧ code e2411630523630 = 11207723545838 := by decide
theorem cert_e2411630523630 : check e2411630523630 [[],[]] .smaller = true := by decide
def e2411630523638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411630523638 : Closed e2411630523638 ∧ code e2411630523638 = 11207723545846 := by decide
theorem cert_e2411630523638 : check e2411630523638 [[],[]] .smaller = true := by decide
def e2411630523642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630523642 : Closed e2411630523642 ∧ code e2411630523642 = 11207723545850 := by decide
theorem cert_e2411630523642 : check e2411630523642 [[],[]] .chain = true := by decide
def e2411630524014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630524014 : Closed e2411630524014 ∧ code e2411630524014 = 11207723546222 := by decide
theorem cert_e2411630524014 : check e2411630524014 [[],[]] .smaller = true := by decide
def e2411630524026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630524026 : Closed e2411630524026 ∧ code e2411630524026 = 11207723546234 := by decide
theorem cert_e2411630524026 : check e2411630524026 [[],[]] .smaller = true := by decide
def e2411630524214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630524214 : Closed e2411630524214 ∧ code e2411630524214 = 11207723546422 := by decide
theorem cert_e2411630524214 : check e2411630524214 [[],[]] .smaller = true := by decide
def e2411630524218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630524218 : Closed e2411630524218 ∧ code e2411630524218 = 11207723546426 := by decide
theorem cert_e2411630524218 : check e2411630524218 [[],[]] .smaller = true := by decide
def e2411630524314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411630524314 : Closed e2411630524314 ∧ code e2411630524314 = 11207723546522 := by decide
theorem cert_e2411630524314 : check e2411630524314 [[],[]] .chain = true := by decide
def e2411630524854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2411630524854 : Closed e2411630524854 ∧ code e2411630524854 = 11207723547062 := by decide
theorem cert_e2411630524854 : check e2411630524854 [[],[]] .smaller = true := by decide
def e2411630524886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2411630524886 : Closed e2411630524886 ∧ code e2411630524886 = 11207723547094 := by decide
theorem cert_e2411630524886 : check e2411630524886 [[],[]] .smaller = true := by decide
def e2411630524890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2411630524890 : Closed e2411630524890 ∧ code e2411630524890 = 11207723547098 := by decide
theorem cert_e2411630524890 : check e2411630524890 [[],[]] .smaller = true := by decide
def e2411630525046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411630525046 : Closed e2411630525046 ∧ code e2411630525046 = 11207723547254 := by decide
theorem cert_e2411630525046 : check e2411630525046 [[],[]] .smaller = true := by decide
def e2411630525238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630525238 : Closed e2411630525238 ∧ code e2411630525238 = 11207723547446 := by decide
theorem cert_e2411630525238 : check e2411630525238 [[],[]] .smaller = true := by decide
def e2411630525242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630525242 : Closed e2411630525242 ∧ code e2411630525242 = 11207723547450 := by decide
theorem cert_e2411630525242 : check e2411630525242 [[],[]] .smaller = true := by decide
def e2411630525406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 3))))))))
theorem wire_e2411630525406 : Closed e2411630525406 ∧ code e2411630525406 = 11207723547614 := by decide
theorem cert_e2411630525406 : check e2411630525406 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2411630525654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2411630525654 : Closed e2411630525654 ∧ code e2411630525654 = 11207723547862 := by decide
theorem cert_e2411630525654 : check e2411630525654 [[],[]] .chain = true := by decide
def e2411630525658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2411630525658 : Closed e2411630525658 ∧ code e2411630525658 = 11207723547866 := by decide
theorem cert_e2411630525658 : check e2411630525658 [[],[]] .chain = true := by decide
def e2411630525674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2411630525674 : Closed e2411630525674 ∧ code e2411630525674 = 11207723547882 := by decide
theorem cert_e2411630525674 : check e2411630525674 [[],[]] .chain = true := by decide
def e2411630525750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630525750 : Closed e2411630525750 ∧ code e2411630525750 = 11207723547958 := by decide
theorem cert_e2411630525750 : check e2411630525750 [[],[]] .chain = true := by decide
def e2411630525754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630525754 : Closed e2411630525754 ∧ code e2411630525754 = 11207723547962 := by decide
theorem cert_e2411630525754 : check e2411630525754 [[],[]] .chain = true := by decide
def e2411630525850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411630525850 : Closed e2411630525850 ∧ code e2411630525850 = 11207723548058 := by decide
theorem cert_e2411630525850 : check e2411630525850 [[],[]] .chain = true := by decide
def e2411630525918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 3))))))))
theorem wire_e2411630525918 : Closed e2411630525918 ∧ code e2411630525918 = 11207723548126 := by decide
theorem cert_e2411630525918 : check e2411630525918 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630525934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 3)) (.var 2))))))))
theorem wire_e2411630525934 : Closed e2411630525934 ∧ code e2411630525934 = 11207723548142 := by decide
theorem cert_e2411630525934 : check e2411630525934 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630528446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2411630528446 : Closed e2411630528446 ∧ code e2411630528446 = 11207723550654 := by decide
theorem cert_e2411630528446 : check e2411630528446 [[],[]] .chain = true := by decide
def e2411630528494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2411630528494 : Closed e2411630528494 ∧ code e2411630528494 = 11207723550702 := by decide
theorem cert_e2411630528494 : check e2411630528494 [[],[]] .chain = true := by decide
def e2411630532318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411630532318 : Closed e2411630532318 ∧ code e2411630532318 = 11207723554526 := by decide
theorem cert_e2411630532318 : check e2411630532318 [[],[]] .chain = true := by decide
def e2411630532342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411630532342 : Closed e2411630532342 ∧ code e2411630532342 = 11207723554550 := by decide
theorem cert_e2411630532342 : check e2411630532342 [[],[]] .chain = true := by decide
def e2411630532446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411630532446 : Closed e2411630532446 ∧ code e2411630532446 = 11207723554654 := by decide
theorem cert_e2411630532446 : check e2411630532446 [[],[]] .chain = true := by decide
def e2411630532462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e2411630532462 : Closed e2411630532462 ∧ code e2411630532462 = 11207723554670 := by decide
theorem cert_e2411630532462 : check e2411630532462 [[],[]] .smaller = true := by decide
def e2411630532470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e2411630532470 : Closed e2411630532470 ∧ code e2411630532470 = 11207723554678 := by decide
theorem cert_e2411630532470 : check e2411630532470 [[],[]] .smaller = true := by decide
def e2411630532474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411630532474 : Closed e2411630532474 ∧ code e2411630532474 = 11207723554682 := by decide
theorem cert_e2411630532474 : check e2411630532474 [[],[]] .chain = true := by decide
def e2411630532534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e2411630532534 : Closed e2411630532534 ∧ code e2411630532534 = 11207723554742 := by decide
theorem cert_e2411630532534 : check e2411630532534 [[],[]] .smaller = true := by decide
def e2411630532566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411630532566 : Closed e2411630532566 ∧ code e2411630532566 = 11207723554774 := by decide
theorem cert_e2411630532566 : check e2411630532566 [[],[]] .chain = true := by decide
def e2411630532570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411630532570 : Closed e2411630532570 ∧ code e2411630532570 = 11207723554778 := by decide
theorem cert_e2411630532570 : check e2411630532570 [[],[]] .chain = true := by decide
def e2411630533086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411630533086 : Closed e2411630533086 ∧ code e2411630533086 = 11207723555294 := by decide
theorem cert_e2411630533086 : check e2411630533086 [[],[]] .chain = true := by decide
def e2411630533110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411630533110 : Closed e2411630533110 ∧ code e2411630533110 = 11207723555318 := by decide
theorem cert_e2411630533110 : check e2411630533110 [[],[]] .chain = true := by decide
def e2411630533854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411630533854 : Closed e2411630533854 ∧ code e2411630533854 = 11207723556062 := by decide
theorem cert_e2411630533854 : check e2411630533854 [[],[]] .chain = true := by decide
def e2411630533870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411630533870 : Closed e2411630533870 ∧ code e2411630533870 = 11207723556078 := by decide
theorem cert_e2411630533870 : check e2411630533870 [[],[]] .smaller = true := by decide
def e2411630533878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411630533878 : Closed e2411630533878 ∧ code e2411630533878 = 11207723556086 := by decide
theorem cert_e2411630533878 : check e2411630533878 [[],[]] .smaller = true := by decide
def e2411630533882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411630533882 : Closed e2411630533882 ∧ code e2411630533882 = 11207723556090 := by decide
theorem cert_e2411630533882 : check e2411630533882 [[],[]] .chain = true := by decide
def e2411630534262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411630534262 : Closed e2411630534262 ∧ code e2411630534262 = 11207723556470 := by decide
theorem cert_e2411630534262 : check e2411630534262 [[],[]] .smaller = true := by decide
def e2411630534454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411630534454 : Closed e2411630534454 ∧ code e2411630534454 = 11207723556662 := by decide
theorem cert_e2411630534454 : check e2411630534454 [[],[]] .chain = true := by decide
def e2411630534458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411630534458 : Closed e2411630534458 ∧ code e2411630534458 = 11207723556666 := by decide
theorem cert_e2411630534458 : check e2411630534458 [[],[]] .chain = true := by decide
def e2411630543806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2411630543806 : Closed e2411630543806 ∧ code e2411630543806 = 11207723566014 := by decide
theorem cert_e2411630543806 : check e2411630543806 [[],[]] .chain = true := by decide
def e2411630543862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2411630543862 : Closed e2411630543862 ∧ code e2411630543862 = 11207723566070 := by decide
theorem cert_e2411630543862 : check e2411630543862 [[],[]] .chain = true := by decide
def e2411630545758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2411630545758 : Closed e2411630545758 ∧ code e2411630545758 = 11207723567966 := by decide
theorem cert_e2411630545758 : check e2411630545758 [[],[]] .chain = true := by decide
def e2411630545774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411630545774 : Closed e2411630545774 ∧ code e2411630545774 = 11207723567982 := by decide
theorem cert_e2411630545774 : check e2411630545774 [[],[]] .smaller = true := by decide
def e2411630545782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411630545782 : Closed e2411630545782 ∧ code e2411630545782 = 11207723567990 := by decide
theorem cert_e2411630545782 : check e2411630545782 [[],[]] .smaller = true := by decide
def e2411630545786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2411630545786 : Closed e2411630545786 ∧ code e2411630545786 = 11207723567994 := by decide
theorem cert_e2411630545786 : check e2411630545786 [[],[]] .chain = true := by decide
def e2411630545838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411630545838 : Closed e2411630545838 ∧ code e2411630545838 = 11207723568046 := by decide
theorem cert_e2411630545838 : check e2411630545838 [[],[]] .smaller = true := by decide
def e2411630545850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411630545850 : Closed e2411630545850 ∧ code e2411630545850 = 11207723568058 := by decide
theorem cert_e2411630545850 : check e2411630545850 [[],[]] .smaller = true := by decide
def e2411630545878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411630545878 : Closed e2411630545878 ∧ code e2411630545878 = 11207723568086 := by decide
theorem cert_e2411630545878 : check e2411630545878 [[],[]] .smaller = true := by decide
def e2411630545882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411630545882 : Closed e2411630545882 ∧ code e2411630545882 = 11207723568090 := by decide
theorem cert_e2411630545882 : check e2411630545882 [[],[]] .smaller = true := by decide
def e2411630545898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2411630545898 : Closed e2411630545898 ∧ code e2411630545898 = 11207723568106 := by decide
theorem cert_e2411630545898 : check e2411630545898 [[],[]] .chain = true := by decide
def e2411630546142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411630546142 : Closed e2411630546142 ∧ code e2411630546142 = 11207723568350 := by decide
theorem cert_e2411630546142 : check e2411630546142 [[],[]] .chain = true := by decide
def e2411630546158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411630546158 : Closed e2411630546158 ∧ code e2411630546158 = 11207723568366 := by decide
theorem cert_e2411630546158 : check e2411630546158 [[],[]] .smaller = true := by decide
def e2411630546166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411630546166 : Closed e2411630546166 ∧ code e2411630546166 = 11207723568374 := by decide
theorem cert_e2411630546166 : check e2411630546166 [[],[]] .smaller = true := by decide
def e2411630546170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411630546170 : Closed e2411630546170 ∧ code e2411630546170 = 11207723568378 := by decide
theorem cert_e2411630546170 : check e2411630546170 [[],[]] .chain = true := by decide
def e2411630546542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411630546542 : Closed e2411630546542 ∧ code e2411630546542 = 11207723568750 := by decide
theorem cert_e2411630546542 : check e2411630546542 [[],[]] .smaller = true := by decide
def e2411630546554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411630546554 : Closed e2411630546554 ∧ code e2411630546554 = 11207723568762 := by decide
theorem cert_e2411630546554 : check e2411630546554 [[],[]] .smaller = true := by decide
def e2411630546742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411630546742 : Closed e2411630546742 ∧ code e2411630546742 = 11207723568950 := by decide
theorem cert_e2411630546742 : check e2411630546742 [[],[]] .smaller = true := by decide
def e2411630546746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411630546746 : Closed e2411630546746 ∧ code e2411630546746 = 11207723568954 := by decide
theorem cert_e2411630546746 : check e2411630546746 [[],[]] .smaller = true := by decide
def e2411630546842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411630546842 : Closed e2411630546842 ∧ code e2411630546842 = 11207723569050 := by decide
theorem cert_e2411630546842 : check e2411630546842 [[],[]] .chain = true := by decide
def e2411630552502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2411630552502 : Closed e2411630552502 ∧ code e2411630552502 = 11207723574710 := by decide
theorem cert_e2411630552502 : check e2411630552502 [[],[]] .smaller = true := by decide
def e2411630552534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2411630552534 : Closed e2411630552534 ∧ code e2411630552534 = 11207723574742 := by decide
theorem cert_e2411630552534 : check e2411630552534 [[],[]] .smaller = true := by decide
def e2411630552538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2411630552538 : Closed e2411630552538 ∧ code e2411630552538 = 11207723574746 := by decide
theorem cert_e2411630552538 : check e2411630552538 [[],[]] .smaller = true := by decide
def e2411630552694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411630552694 : Closed e2411630552694 ∧ code e2411630552694 = 11207723574902 := by decide
theorem cert_e2411630552694 : check e2411630552694 [[],[]] .smaller = true := by decide
def e2411630552886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411630552886 : Closed e2411630552886 ∧ code e2411630552886 = 11207723575094 := by decide
theorem cert_e2411630552886 : check e2411630552886 [[],[]] .smaller = true := by decide
def e2411630552890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411630552890 : Closed e2411630552890 ∧ code e2411630552890 = 11207723575098 := by decide
theorem cert_e2411630552890 : check e2411630552890 [[],[]] .smaller = true := by decide
def e2411630553054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 3)))))))))
theorem wire_e2411630553054 : Closed e2411630553054 ∧ code e2411630553054 = 11207723575262 := by decide
theorem cert_e2411630553054 : checkPay e2411630553054 [[.left,.left],[.left,.left],[.left],[],[],[.left]] 0 [[]] = true := by decide
def e2411630555374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2411630555374 : Closed e2411630555374 ∧ code e2411630555374 = 11207723577582 := by decide
theorem cert_e2411630555374 : check e2411630555374 [[],[]] .chain = true := by decide
def e2411630555382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2411630555382 : Closed e2411630555382 ∧ code e2411630555382 = 11207723577590 := by decide
theorem cert_e2411630555382 : check e2411630555382 [[],[]] .chain = true := by decide
def e2411630555862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411630555862 : Closed e2411630555862 ∧ code e2411630555862 = 11207723578070 := by decide
theorem cert_e2411630555862 : check e2411630555862 [[],[]] .chain = true := by decide
def e2411630555866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411630555866 : Closed e2411630555866 ∧ code e2411630555866 = 11207723578074 := by decide
theorem cert_e2411630555866 : check e2411630555866 [[],[]] .chain = true := by decide
def e2411630555882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411630555882 : Closed e2411630555882 ∧ code e2411630555882 = 11207723578090 := by decide
theorem cert_e2411630555882 : check e2411630555882 [[],[]] .chain = true := by decide
def e2411630555958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411630555958 : Closed e2411630555958 ∧ code e2411630555958 = 11207723578166 := by decide
theorem cert_e2411630555958 : check e2411630555958 [[],[]] .chain = true := by decide
def e2411630555962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411630555962 : Closed e2411630555962 ∧ code e2411630555962 = 11207723578170 := by decide
theorem cert_e2411630555962 : check e2411630555962 [[],[]] .chain = true := by decide
def e2411630556058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411630556058 : Closed e2411630556058 ∧ code e2411630556058 = 11207723578266 := by decide
theorem cert_e2411630556058 : check e2411630556058 [[],[]] .chain = true := by decide
def e2411630556126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 3)))))))))
theorem wire_e2411630556126 : Closed e2411630556126 ∧ code e2411630556126 = 11207723578334 := by decide
theorem cert_e2411630556126 : check e2411630556126 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2411630556142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 3) (.var 2)))))))))
theorem wire_e2411630556142 : Closed e2411630556142 ∧ code e2411630556142 = 11207723578350 := by decide
theorem cert_e2411630556142 : check e2411630556142 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2411630781294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2411630781294 : Closed e2411630781294 ∧ code e2411630781294 = 11207723803502 := by decide
theorem cert_e2411630781294 : check e2411630781294 [[],[]] .chain = true := by decide
def e2411630781302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2411630781302 : Closed e2411630781302 ∧ code e2411630781302 = 11207723803510 := by decide
theorem cert_e2411630781302 : check e2411630781302 [[],[]] .chain = true := by decide
def e2411630781358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2411630781358 : Closed e2411630781358 ∧ code e2411630781358 = 11207723803566 := by decide
theorem cert_e2411630781358 : check e2411630781358 [[],[]] .chain = true := by decide
def e2411630781370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2411630781370 : Closed e2411630781370 ∧ code e2411630781370 = 11207723803578 := by decide
theorem cert_e2411630781370 : check e2411630781370 [[],[]] .chain = true := by decide
def e2411630781398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2411630781398 : Closed e2411630781398 ∧ code e2411630781398 = 11207723803606 := by decide
theorem cert_e2411630781398 : check e2411630781398 [[],[]] .chain = true := by decide
def e2411630781402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2411630781402 : Closed e2411630781402 ∧ code e2411630781402 = 11207723803610 := by decide
theorem cert_e2411630781402 : check e2411630781402 [[],[]] .chain = true := by decide
def e2411630782702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2411630782702 : Closed e2411630782702 ∧ code e2411630782702 = 11207723804910 := by decide
theorem cert_e2411630782702 : check e2411630782702 [[],[]] .chain = true := by decide
def e2411630782710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2411630782710 : Closed e2411630782710 ∧ code e2411630782710 = 11207723804918 := by decide
theorem cert_e2411630782710 : check e2411630782710 [[],[]] .chain = true := by decide
def e2411630783262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2411630783262 : Closed e2411630783262 ∧ code e2411630783262 = 11207723805470 := by decide
theorem cert_e2411630783262 : check e2411630783262 [[],[]] .chain = true := by decide
def e2411630783374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2411630783374 : Closed e2411630783374 ∧ code e2411630783374 = 11207723805582 := by decide
theorem cert_e2411630783374 : check e2411630783374 [[],[]] .chain = true := by decide
def e2411630783598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411630783598 : Closed e2411630783598 ∧ code e2411630783598 = 11207723805806 := by decide
theorem cert_e2411630783598 : check e2411630783598 [[],[]] .chain = true := by decide
def e2411630783610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411630783610 : Closed e2411630783610 ∧ code e2411630783610 = 11207723805818 := by decide
theorem cert_e2411630783610 : check e2411630783610 [[],[]] .chain = true := by decide
def e2411630783774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411630783774 : Closed e2411630783774 ∧ code e2411630783774 = 11207723805982 := by decide
theorem cert_e2411630783774 : check e2411630783774 [[],[]] .chain = true := by decide
def e2411630783942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411630783942 : Closed e2411630783942 ∧ code e2411630783942 = 11207723806150 := by decide
theorem cert_e2411630783942 : check e2411630783942 [[],[]] .chain = true := by decide
def e2411630784054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411630784054 : Closed e2411630784054 ∧ code e2411630784054 = 11207723806262 := by decide
theorem cert_e2411630784054 : check e2411630784054 [[],[]] .chain = true := by decide
def e2411630784058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411630784058 : Closed e2411630784058 ∧ code e2411630784058 = 11207723806266 := by decide
theorem cert_e2411630784058 : check e2411630784058 [[],[]] .chain = true := by decide
def e2411630784142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411630784142 : Closed e2411630784142 ∧ code e2411630784142 = 11207723806350 := by decide
theorem cert_e2411630784142 : check e2411630784142 [[],[]] .chain = true := by decide
def e2411630784198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411630784198 : Closed e2411630784198 ∧ code e2411630784198 = 11207723806406 := by decide
theorem cert_e2411630784198 : check e2411630784198 [[],[]] .chain = true := by decide
def e2411630784878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2411630784878 : Closed e2411630784878 ∧ code e2411630784878 = 11207723807086 := by decide
theorem cert_e2411630784878 : check e2411630784878 [[],[]] .chain = true := by decide
def e2411630784886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2411630784886 : Closed e2411630784886 ∧ code e2411630784886 = 11207723807094 := by decide
theorem cert_e2411630784886 : check e2411630784886 [[],[]] .chain = true := by decide
def e2411630784942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2411630784942 : Closed e2411630784942 ∧ code e2411630784942 = 11207723807150 := by decide
theorem cert_e2411630784942 : check e2411630784942 [[],[]] .chain = true := by decide
def e2411630784954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2411630784954 : Closed e2411630784954 ∧ code e2411630784954 = 11207723807162 := by decide
theorem cert_e2411630784954 : check e2411630784954 [[],[]] .chain = true := by decide
def e2411630785002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2411630785002 : Closed e2411630785002 ∧ code e2411630785002 = 11207723807210 := by decide
theorem cert_e2411630785002 : check e2411630785002 [[],[]] .chain = true := by decide
def e2411630785646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411630785646 : Closed e2411630785646 ∧ code e2411630785646 = 11207723807854 := by decide
theorem cert_e2411630785646 : check e2411630785646 [[],[]] .chain = true := by decide
def e2411630785658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411630785658 : Closed e2411630785658 ∧ code e2411630785658 = 11207723807866 := by decide
theorem cert_e2411630785658 : check e2411630785658 [[],[]] .chain = true := by decide
def e2411630785822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411630785822 : Closed e2411630785822 ∧ code e2411630785822 = 11207723808030 := by decide
theorem cert_e2411630785822 : check e2411630785822 [[],[]] .chain = true := by decide
def e2411630785990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411630785990 : Closed e2411630785990 ∧ code e2411630785990 = 11207723808198 := by decide
theorem cert_e2411630785990 : check e2411630785990 [[],[]] .chain = true := by decide
def e2411630786094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2411630786094 : Closed e2411630786094 ∧ code e2411630786094 = 11207723808302 := by decide
theorem cert_e2411630786094 : check e2411630786094 [[],[]] .chain = true := by decide
def e2411630786274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2411630786274 : Closed e2411630786274 ∧ code e2411630786274 = 11207723808482 := by decide
theorem cert_e2411630786274 : check e2411630786274 [[],[]] .chain = true := by decide
def e2411630786286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2411630786286 : Closed e2411630786286 ∧ code e2411630786286 = 11207723808494 := by decide
theorem cert_e2411630786286 : check e2411630786286 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630786326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411630786326 : Closed e2411630786326 ∧ code e2411630786326 = 11207723808534 := by decide
theorem cert_e2411630786326 : check e2411630786326 [[],[]] .chain = true := by decide
def e2411630786330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411630786330 : Closed e2411630786330 ∧ code e2411630786330 = 11207723808538 := by decide
theorem cert_e2411630786330 : check e2411630786330 [[],[]] .chain = true := by decide
def e2411630786374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411630786374 : Closed e2411630786374 ∧ code e2411630786374 = 11207723808582 := by decide
theorem cert_e2411630786374 : check e2411630786374 [[],[]] .chain = true := by decide
def e2411630786402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411630786402 : Closed e2411630786402 ∧ code e2411630786402 = 11207723808610 := by decide
theorem cert_e2411630786402 : check e2411630786402 [[],[]] .chain = true := by decide
def e2411630786414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2411630786414 : Closed e2411630786414 ∧ code e2411630786414 = 11207723808622 := by decide
theorem cert_e2411630786414 : check e2411630786414 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630786422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2411630786422 : Closed e2411630786422 ∧ code e2411630786422 = 11207723808630 := by decide
theorem cert_e2411630786422 : check e2411630786422 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2411630786742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e2411630786742 : Closed e2411630786742 ∧ code e2411630786742 = 11207723808950 := by decide
theorem cert_e2411630786742 : check e2411630786742 [[],[]] .chain = true := by decide
def e2411630786774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2411630786774 : Closed e2411630786774 ∧ code e2411630786774 = 11207723808982 := by decide
theorem cert_e2411630786774 : check e2411630786774 [[],[]] .chain = true := by decide
def e2411630786778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2411630786778 : Closed e2411630786778 ∧ code e2411630786778 = 11207723808986 := by decide
theorem cert_e2411630786778 : check e2411630786778 [[],[]] .chain = true := by decide
def e2411630786794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2411630786794 : Closed e2411630786794 ∧ code e2411630786794 = 11207723809002 := by decide
theorem cert_e2411630786794 : check e2411630786794 [[],[]] .chain = true := by decide
def e2411630787126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411630787126 : Closed e2411630787126 ∧ code e2411630787126 = 11207723809334 := by decide
theorem cert_e2411630787126 : check e2411630787126 [[],[]] .chain = true := by decide
def e2411630787130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411630787130 : Closed e2411630787130 ∧ code e2411630787130 = 11207723809338 := by decide
theorem cert_e2411630787130 : check e2411630787130 [[],[]] .chain = true := by decide
def e2411630787214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411630787214 : Closed e2411630787214 ∧ code e2411630787214 = 11207723809422 := by decide
theorem cert_e2411630787214 : check e2411630787214 [[],[]] .chain = true := by decide
def e2411630787270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411630787270 : Closed e2411630787270 ∧ code e2411630787270 = 11207723809478 := by decide
theorem cert_e2411630787270 : check e2411630787270 [[],[]] .chain = true := by decide
def e2411630787350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411630787350 : Closed e2411630787350 ∧ code e2411630787350 = 11207723809558 := by decide
theorem cert_e2411630787350 : check e2411630787350 [[],[]] .chain = true := by decide
def e2411630787354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411630787354 : Closed e2411630787354 ∧ code e2411630787354 = 11207723809562 := by decide
theorem cert_e2411630787354 : check e2411630787354 [[],[]] .chain = true := by decide
def e2411630787398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411630787398 : Closed e2411630787398 ∧ code e2411630787398 = 11207723809606 := by decide
theorem cert_e2411630787398 : check e2411630787398 [[],[]] .chain = true := by decide
def e2411630787426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411630787426 : Closed e2411630787426 ∧ code e2411630787426 = 11207723809634 := by decide
theorem cert_e2411630787426 : check e2411630787426 [[],[]] .chain = true := by decide
def e2411630787438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2411630787438 : Closed e2411630787438 ∧ code e2411630787438 = 11207723809646 := by decide
theorem cert_e2411630787438 : check e2411630787438 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2411630787446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2411630787446 : Closed e2411630787446 ∧ code e2411630787446 = 11207723809654 := by decide
theorem cert_e2411630787446 : check e2411630787446 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630787510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2411630787510 : Closed e2411630787510 ∧ code e2411630787510 = 11207723809718 := by decide
theorem cert_e2411630787510 : check e2411630787510 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2411630790382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e2411630790382 : Closed e2411630790382 ∧ code e2411630790382 = 11207723812590 := by decide
theorem cert_e2411630790382 : check e2411630790382 [[],[]] .chain = true := by decide
end Blc.Floor43
