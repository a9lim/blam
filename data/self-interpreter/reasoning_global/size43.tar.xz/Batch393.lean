import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372795114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372795114 : Closed e2422372795114 ∧ code e2422372795114 = 11218465817322 := by decide
theorem cert_e2422372795114 : check e2422372795114 [[],[]] .smaller = true := by decide
def e2422372797150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2422372797150 : Closed e2422372797150 ∧ code e2422372797150 = 11218465819358 := by decide
theorem cert_e2422372797150 : check e2422372797150 [[],[]] .three = true := by decide
def e2422372797166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2422372797166 : Closed e2422372797166 ∧ code e2422372797166 = 11218465819374 := by decide
theorem cert_e2422372797166 : check e2422372797166 [[],[]] .smaller = true := by decide
def e2422372797174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2422372797174 : Closed e2422372797174 ∧ code e2422372797174 = 11218465819382 := by decide
theorem cert_e2422372797174 : check e2422372797174 [[],[]] .three = true := by decide
def e2422372797278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2422372797278 : Closed e2422372797278 ∧ code e2422372797278 = 11218465819486 := by decide
theorem cert_e2422372797278 : check e2422372797278 [[],[]] .three = true := by decide
def e2422372797306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2422372797306 : Closed e2422372797306 ∧ code e2422372797306 = 11218465819514 := by decide
theorem cert_e2422372797306 : check e2422372797306 [[],[]] .three = true := by decide
def e2422372797358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2422372797358 : Closed e2422372797358 ∧ code e2422372797358 = 11218465819566 := by decide
theorem cert_e2422372797358 : check e2422372797358 [[],[]] .smaller = true := by decide
def e2422372797370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2422372797370 : Closed e2422372797370 ∧ code e2422372797370 = 11218465819578 := by decide
theorem cert_e2422372797370 : check e2422372797370 [[],[]] .smaller = true := by decide
def e2422372797398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2422372797398 : Closed e2422372797398 ∧ code e2422372797398 = 11218465819606 := by decide
theorem cert_e2422372797398 : check e2422372797398 [[],[]] .three = true := by decide
def e2422372797402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2422372797402 : Closed e2422372797402 ∧ code e2422372797402 = 11218465819610 := by decide
theorem cert_e2422372797402 : check e2422372797402 [[],[]] .three = true := by decide
def e2422372797790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2422372797790 : Closed e2422372797790 ∧ code e2422372797790 = 11218465819998 := by decide
theorem cert_e2422372797790 : check e2422372797790 [[],[]] .three = true := by decide
def e2422372797806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422372797806 : Closed e2422372797806 ∧ code e2422372797806 = 11218465820014 := by decide
theorem cert_e2422372797806 : check e2422372797806 [[],[]] .smaller = true := by decide
def e2422372797814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422372797814 : Closed e2422372797814 ∧ code e2422372797814 = 11218465820022 := by decide
theorem cert_e2422372797814 : check e2422372797814 [[],[]] .smaller = true := by decide
def e2422372797818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2422372797818 : Closed e2422372797818 ∧ code e2422372797818 = 11218465820026 := by decide
theorem cert_e2422372797818 : check e2422372797818 [[],[]] .three = true := by decide
def e2422372797870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422372797870 : Closed e2422372797870 ∧ code e2422372797870 = 11218465820078 := by decide
theorem cert_e2422372797870 : check e2422372797870 [[],[]] .smaller = true := by decide
def e2422372797882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2422372797882 : Closed e2422372797882 ∧ code e2422372797882 = 11218465820090 := by decide
theorem cert_e2422372797882 : check e2422372797882 [[],[]] .smaller = true := by decide
def e2422372797910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2422372797910 : Closed e2422372797910 ∧ code e2422372797910 = 11218465820118 := by decide
theorem cert_e2422372797910 : check e2422372797910 [[],[]] .smaller = true := by decide
def e2422372797914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2422372797914 : Closed e2422372797914 ∧ code e2422372797914 = 11218465820122 := by decide
theorem cert_e2422372797914 : check e2422372797914 [[],[]] .smaller = true := by decide
def e2422372797930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2422372797930 : Closed e2422372797930 ∧ code e2422372797930 = 11218465820138 := by decide
theorem cert_e2422372797930 : check e2422372797930 [[],[]] .three = true := by decide
def e2422372798126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372798126 : Closed e2422372798126 ∧ code e2422372798126 = 11218465820334 := by decide
theorem cert_e2422372798126 : check e2422372798126 [[],[]] .smaller = true := by decide
def e2422372798138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372798138 : Closed e2422372798138 ∧ code e2422372798138 = 11218465820346 := by decide
theorem cert_e2422372798138 : check e2422372798138 [[],[]] .smaller = true := by decide
def e2422372798186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372798186 : Closed e2422372798186 ∧ code e2422372798186 = 11218465820394 := by decide
theorem cert_e2422372798186 : check e2422372798186 [[],[]] .smaller = true := by decide
def e2422372798294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2422372798294 : Closed e2422372798294 ∧ code e2422372798294 = 11218465820502 := by decide
theorem cert_e2422372798294 : check e2422372798294 [[],[]] .smaller = true := by decide
def e2422372798298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2422372798298 : Closed e2422372798298 ∧ code e2422372798298 = 11218465820506 := by decide
theorem cert_e2422372798298 : check e2422372798298 [[],[]] .smaller = true := by decide
def e2422372798314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2422372798314 : Closed e2422372798314 ∧ code e2422372798314 = 11218465820522 := by decide
theorem cert_e2422372798314 : check e2422372798314 [[],[]] .smaller = true := by decide
def e2422372798378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372798378 : Closed e2422372798378 ∧ code e2422372798378 = 11218465820586 := by decide
theorem cert_e2422372798378 : check e2422372798378 [[],[]] .three = true := by decide
def e2422372801198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372801198 : Closed e2422372801198 ∧ code e2422372801198 = 11218465823406 := by decide
theorem cert_e2422372801198 : check e2422372801198 [[],[]] .smaller = true := by decide
def e2422372801210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372801210 : Closed e2422372801210 ∧ code e2422372801210 = 11218465823418 := by decide
theorem cert_e2422372801210 : check e2422372801210 [[],[]] .smaller = true := by decide
def e2422372801258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2422372801258 : Closed e2422372801258 ∧ code e2422372801258 = 11218465823466 := by decide
theorem cert_e2422372801258 : check e2422372801258 [[],[]] .smaller = true := by decide
def e2422372801450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372801450 : Closed e2422372801450 ∧ code e2422372801450 = 11218465823658 := by decide
theorem cert_e2422372801450 : check e2422372801450 [[],[]] .smaller = true := by decide
def e2422372802218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2422372802218 : Closed e2422372802218 ∧ code e2422372802218 = 11218465824426 := by decide
theorem cert_e2422372802218 : check e2422372802218 [[],[]] .smaller = true := by decide
def e2422372802734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372802734 : Closed e2422372802734 ∧ code e2422372802734 = 11218465824942 := by decide
theorem cert_e2422372802734 : check e2422372802734 [[],[]] .smaller = true := by decide
def e2422372802746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372802746 : Closed e2422372802746 ∧ code e2422372802746 = 11218465824954 := by decide
theorem cert_e2422372802746 : check e2422372802746 [[],[]] .smaller = true := by decide
def e2422372803294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e2422372803294 : Closed e2422372803294 ∧ code e2422372803294 = 11218465825502 := by decide
theorem cert_e2422372803294 : check e2422372803294 [[],[]] .three = true := by decide
def e2422372803310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e2422372803310 : Closed e2422372803310 ∧ code e2422372803310 = 11218465825518 := by decide
theorem cert_e2422372803310 : check e2422372803310 [[],[]] .smaller = true := by decide
def e2422372803318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e2422372803318 : Closed e2422372803318 ∧ code e2422372803318 = 11218465825526 := by decide
theorem cert_e2422372803318 : check e2422372803318 [[],[]] .three = true := by decide
def e2422372803422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2422372803422 : Closed e2422372803422 ∧ code e2422372803422 = 11218465825630 := by decide
theorem cert_e2422372803422 : check e2422372803422 [[],[]] .three = true := by decide
def e2422372803438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2422372803438 : Closed e2422372803438 ∧ code e2422372803438 = 11218465825646 := by decide
theorem cert_e2422372803438 : check e2422372803438 [[],[]] .smaller = true := by decide
def e2422372803446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2422372803446 : Closed e2422372803446 ∧ code e2422372803446 = 11218465825654 := by decide
theorem cert_e2422372803446 : check e2422372803446 [[],[]] .smaller = true := by decide
def e2422372803450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2422372803450 : Closed e2422372803450 ∧ code e2422372803450 = 11218465825658 := by decide
theorem cert_e2422372803450 : check e2422372803450 [[],[]] .three = true := by decide
def e2422372803502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2422372803502 : Closed e2422372803502 ∧ code e2422372803502 = 11218465825710 := by decide
theorem cert_e2422372803502 : check e2422372803502 [[],[]] .smaller = true := by decide
def e2422372803514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2422372803514 : Closed e2422372803514 ∧ code e2422372803514 = 11218465825722 := by decide
theorem cert_e2422372803514 : check e2422372803514 [[],[]] .smaller = true := by decide
def e2422372803542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2422372803542 : Closed e2422372803542 ∧ code e2422372803542 = 11218465825750 := by decide
theorem cert_e2422372803542 : check e2422372803542 [[],[]] .smaller = true := by decide
def e2422372803546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2422372803546 : Closed e2422372803546 ∧ code e2422372803546 = 11218465825754 := by decide
theorem cert_e2422372803546 : check e2422372803546 [[],[]] .smaller = true := by decide
def e2422372803562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 0)) (.var 0)))))))
theorem wire_e2422372803562 : Closed e2422372803562 ∧ code e2422372803562 = 11218465825770 := by decide
theorem cert_e2422372803562 : check e2422372803562 [[],[]] .three = true := by decide
def e2422372804270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372804270 : Closed e2422372804270 ∧ code e2422372804270 = 11218465826478 := by decide
theorem cert_e2422372804270 : check e2422372804270 [[],[]] .smaller = true := by decide
def e2422372804282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372804282 : Closed e2422372804282 ∧ code e2422372804282 = 11218465826490 := by decide
theorem cert_e2422372804282 : check e2422372804282 [[],[]] .smaller = true := by decide
def e2422372804330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372804330 : Closed e2422372804330 ∧ code e2422372804330 = 11218465826538 := by decide
theorem cert_e2422372804330 : check e2422372804330 [[],[]] .smaller = true := by decide
def e2422372804522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372804522 : Closed e2422372804522 ∧ code e2422372804522 = 11218465826730 := by decide
theorem cert_e2422372804522 : check e2422372804522 [[],[]] .smaller = true := by decide
def e2422372804654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372804654 : Closed e2422372804654 ∧ code e2422372804654 = 11218465826862 := by decide
theorem cert_e2422372804654 : check e2422372804654 [[],[]] .smaller = true := by decide
def e2422372804830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422372804830 : Closed e2422372804830 ∧ code e2422372804830 = 11218465827038 := by decide
theorem cert_e2422372804830 : check e2422372804830 [[],[]] .three = true := by decide
def e2422372804846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422372804846 : Closed e2422372804846 ∧ code e2422372804846 = 11218465827054 := by decide
theorem cert_e2422372804846 : check e2422372804846 [[],[]] .smaller = true := by decide
def e2422372804854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422372804854 : Closed e2422372804854 ∧ code e2422372804854 = 11218465827062 := by decide
theorem cert_e2422372804854 : check e2422372804854 [[],[]] .smaller = true := by decide
def e2422372804858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422372804858 : Closed e2422372804858 ∧ code e2422372804858 = 11218465827066 := by decide
theorem cert_e2422372804858 : check e2422372804858 [[],[]] .three = true := by decide
def e2422372805038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422372805038 : Closed e2422372805038 ∧ code e2422372805038 = 11218465827246 := by decide
theorem cert_e2422372805038 : check e2422372805038 [[],[]] .smaller = true := by decide
def e2422372805050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422372805050 : Closed e2422372805050 ∧ code e2422372805050 = 11218465827258 := by decide
theorem cert_e2422372805050 : check e2422372805050 [[],[]] .smaller = true := by decide
def e2422372805098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422372805098 : Closed e2422372805098 ∧ code e2422372805098 = 11218465827306 := by decide
theorem cert_e2422372805098 : check e2422372805098 [[],[]] .smaller = true := by decide
def e2422372805182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422372805182 : Closed e2422372805182 ∧ code e2422372805182 = 11218465827390 := by decide
theorem cert_e2422372805182 : check e2422372805182 [[],[]] .three = true := by decide
def e2422372805230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372805230 : Closed e2422372805230 ∧ code e2422372805230 = 11218465827438 := by decide
theorem cert_e2422372805230 : check e2422372805230 [[],[]] .smaller = true := by decide
def e2422372805242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372805242 : Closed e2422372805242 ∧ code e2422372805242 = 11218465827450 := by decide
theorem cert_e2422372805242 : check e2422372805242 [[],[]] .smaller = true := by decide
def e2422372805406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422372805406 : Closed e2422372805406 ∧ code e2422372805406 = 11218465827614 := by decide
theorem cert_e2422372805406 : check e2422372805406 [[],[]] .smaller = true := by decide
def e2422372805506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372805506 : Closed e2422372805506 ∧ code e2422372805506 = 11218465827714 := by decide
theorem cert_e2422372805506 : check e2422372805506 [[],[]] .smaller = true := by decide
def e2422372805518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422372805518 : Closed e2422372805518 ∧ code e2422372805518 = 11218465827726 := by decide
theorem cert_e2422372805518 : check e2422372805518 [[],[]] .smaller = true := by decide
def e2422372805530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372805530 : Closed e2422372805530 ∧ code e2422372805530 = 11218465827738 := by decide
theorem cert_e2422372805530 : check e2422372805530 [[],[]] .smaller = true := by decide
def e2422372805574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422372805574 : Closed e2422372805574 ∧ code e2422372805574 = 11218465827782 := by decide
theorem cert_e2422372805574 : check e2422372805574 [[],[]] .three = true := by decide
def e2422372805598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.var 3)))))))
theorem wire_e2422372805598 : Closed e2422372805598 ∧ code e2422372805598 = 11218465827806 := by decide
theorem cert_e2422372805598 : check e2422372805598 [[],[]] .three = true := by decide
def e2422372805726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372805726 : Closed e2422372805726 ∧ code e2422372805726 = 11218465827934 := by decide
theorem cert_e2422372805726 : check e2422372805726 [[],[]] .three = true := by decide
def e2422372805742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422372805742 : Closed e2422372805742 ∧ code e2422372805742 = 11218465827950 := by decide
theorem cert_e2422372805742 : check e2422372805742 [[],[]] .smaller = true := by decide
def e2422372805754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422372805754 : Closed e2422372805754 ∧ code e2422372805754 = 11218465827962 := by decide
theorem cert_e2422372805754 : check e2422372805754 [[],[]] .smaller = true := by decide
def e2422372805918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422372805918 : Closed e2422372805918 ∧ code e2422372805918 = 11218465828126 := by decide
theorem cert_e2422372805918 : check e2422372805918 [[],[]] .smaller = true := by decide
def e2422372806086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422372806086 : Closed e2422372806086 ∧ code e2422372806086 = 11218465828294 := by decide
theorem cert_e2422372806086 : check e2422372806086 [[],[]] .smaller = true := by decide
def e2422372806110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e2422372806110 : Closed e2422372806110 ∧ code e2422372806110 = 11218465828318 := by decide
theorem cert_e2422372806110 : check e2422372806110 [[],[]] .three = true := by decide
def e2422372806114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372806114 : Closed e2422372806114 ∧ code e2422372806114 = 11218465828322 := by decide
theorem cert_e2422372806114 : check e2422372806114 [[],[]] .three = true := by decide
def e2422372806126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e2422372806126 : Closed e2422372806126 ∧ code e2422372806126 = 11218465828334 := by decide
theorem cert_e2422372806126 : check e2422372806126 [[],[]] .three = true := by decide
def e2422372806154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372806154 : Closed e2422372806154 ∧ code e2422372806154 = 11218465828362 := by decide
theorem cert_e2422372806154 : check e2422372806154 [[],[]] .smaller = true := by decide
def e2422372806190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372806190 : Closed e2422372806190 ∧ code e2422372806190 = 11218465828398 := by decide
theorem cert_e2422372806190 : check e2422372806190 [[],[]] .smaller = true := by decide
def e2422372806198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372806198 : Closed e2422372806198 ∧ code e2422372806198 = 11218465828406 := by decide
theorem cert_e2422372806198 : check e2422372806198 [[],[]] .smaller = true := by decide
def e2422372806202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372806202 : Closed e2422372806202 ∧ code e2422372806202 = 11218465828410 := by decide
theorem cert_e2422372806202 : check e2422372806202 [[],[]] .smaller = true := by decide
def e2422372806250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372806250 : Closed e2422372806250 ∧ code e2422372806250 = 11218465828458 := by decide
theorem cert_e2422372806250 : check e2422372806250 [[],[]] .smaller = true := by decide
def e2422372806274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372806274 : Closed e2422372806274 ∧ code e2422372806274 = 11218465828482 := by decide
theorem cert_e2422372806274 : check e2422372806274 [[],[]] .smaller = true := by decide
def e2422372806286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372806286 : Closed e2422372806286 ∧ code e2422372806286 = 11218465828494 := by decide
theorem cert_e2422372806286 : check e2422372806286 [[],[]] .smaller = true := by decide
def e2422372806298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372806298 : Closed e2422372806298 ∧ code e2422372806298 = 11218465828506 := by decide
theorem cert_e2422372806298 : check e2422372806298 [[],[]] .smaller = true := by decide
def e2422372806342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372806342 : Closed e2422372806342 ∧ code e2422372806342 = 11218465828550 := by decide
theorem cert_e2422372806342 : check e2422372806342 [[],[]] .smaller = true := by decide
def e2422372806366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e2422372806366 : Closed e2422372806366 ∧ code e2422372806366 = 11218465828574 := by decide
theorem cert_e2422372806366 : check e2422372806366 [[],[]] .three = true := by decide
def e2422372806370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372806370 : Closed e2422372806370 ∧ code e2422372806370 = 11218465828578 := by decide
theorem cert_e2422372806370 : check e2422372806370 [[],[]] .smaller = true := by decide
def e2422372806382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 2)))))))
theorem wire_e2422372806382 : Closed e2422372806382 ∧ code e2422372806382 = 11218465828590 := by decide
theorem cert_e2422372806382 : check e2422372806382 [[],[]] .smaller = true := by decide
def e2422372806390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e2422372806390 : Closed e2422372806390 ∧ code e2422372806390 = 11218465828598 := by decide
theorem cert_e2422372806390 : check e2422372806390 [[],[]] .three = true := by decide
def e2422372806422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372806422 : Closed e2422372806422 ∧ code e2422372806422 = 11218465828630 := by decide
theorem cert_e2422372806422 : check e2422372806422 [[],[]] .three = true := by decide
def e2422372806426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372806426 : Closed e2422372806426 ∧ code e2422372806426 = 11218465828634 := by decide
theorem cert_e2422372806426 : check e2422372806426 [[],[]] .three = true := by decide
def e2422372806470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372806470 : Closed e2422372806470 ∧ code e2422372806470 = 11218465828678 := by decide
theorem cert_e2422372806470 : check e2422372806470 [[],[]] .three = true := by decide
def e2422372806494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.var 3)))))))
theorem wire_e2422372806494 : Closed e2422372806494 ∧ code e2422372806494 = 11218465828702 := by decide
theorem cert_e2422372806494 : check e2422372806494 [[],[]] .three = true := by decide
def e2422372806498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372806498 : Closed e2422372806498 ∧ code e2422372806498 = 11218465828706 := by decide
theorem cert_e2422372806498 : check e2422372806498 [[],[]] .three = true := by decide
def e2422372806510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e2422372806510 : Closed e2422372806510 ∧ code e2422372806510 = 11218465828718 := by decide
theorem cert_e2422372806510 : check e2422372806510 [[],[]] .three = true := by decide
def e2422372806518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e2422372806518 : Closed e2422372806518 ∧ code e2422372806518 = 11218465828726 := by decide
theorem cert_e2422372806518 : check e2422372806518 [[],[]] .three = true := by decide
def e2422372806522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 3)) (.var 0)))))))
theorem wire_e2422372806522 : Closed e2422372806522 ∧ code e2422372806522 = 11218465828730 := by decide
theorem cert_e2422372806522 : check e2422372806522 [[],[]] .three = true := by decide
def e2422372807006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e2422372807006 : Closed e2422372807006 ∧ code e2422372807006 = 11218465829214 := by decide
theorem cert_e2422372807006 : check e2422372807006 [[],[]] .three = true := by decide
def e2422372807034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e2422372807034 : Closed e2422372807034 ∧ code e2422372807034 = 11218465829242 := by decide
theorem cert_e2422372807034 : check e2422372807034 [[],[]] .three = true := by decide
def e2422372807086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2422372807086 : Closed e2422372807086 ∧ code e2422372807086 = 11218465829294 := by decide
theorem cert_e2422372807086 : check e2422372807086 [[],[]] .smaller = true := by decide
def e2422372807098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2422372807098 : Closed e2422372807098 ∧ code e2422372807098 = 11218465829306 := by decide
theorem cert_e2422372807098 : check e2422372807098 [[],[]] .smaller = true := by decide
def e2422372807146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2422372807146 : Closed e2422372807146 ∧ code e2422372807146 = 11218465829354 := by decide
theorem cert_e2422372807146 : check e2422372807146 [[],[]] .smaller = true := by decide
def e2422372807774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372807774 : Closed e2422372807774 ∧ code e2422372807774 = 11218465829982 := by decide
theorem cert_e2422372807774 : check e2422372807774 [[],[]] .three = true := by decide
def e2422372807790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422372807790 : Closed e2422372807790 ∧ code e2422372807790 = 11218465829998 := by decide
theorem cert_e2422372807790 : check e2422372807790 [[],[]] .smaller = true := by decide
def e2422372807802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422372807802 : Closed e2422372807802 ∧ code e2422372807802 = 11218465830010 := by decide
theorem cert_e2422372807802 : check e2422372807802 [[],[]] .smaller = true := by decide
def e2422372807966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422372807966 : Closed e2422372807966 ∧ code e2422372807966 = 11218465830174 := by decide
theorem cert_e2422372807966 : check e2422372807966 [[],[]] .smaller = true := by decide
def e2422372808134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422372808134 : Closed e2422372808134 ∧ code e2422372808134 = 11218465830342 := by decide
theorem cert_e2422372808134 : check e2422372808134 [[],[]] .smaller = true := by decide
def e2422372808158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2422372808158 : Closed e2422372808158 ∧ code e2422372808158 = 11218465830366 := by decide
theorem cert_e2422372808158 : check e2422372808158 [[],[]] .three = true := by decide
def e2422372808162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372808162 : Closed e2422372808162 ∧ code e2422372808162 = 11218465830370 := by decide
theorem cert_e2422372808162 : check e2422372808162 [[],[]] .three = true := by decide
def e2422372808174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2422372808174 : Closed e2422372808174 ∧ code e2422372808174 = 11218465830382 := by decide
theorem cert_e2422372808174 : check e2422372808174 [[],[]] .three = true := by decide
def e2422372808474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372808474 : Closed e2422372808474 ∧ code e2422372808474 = 11218465830682 := by decide
theorem cert_e2422372808474 : check e2422372808474 [[],[]] .smaller = true := by decide
def e2422372808518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372808518 : Closed e2422372808518 ∧ code e2422372808518 = 11218465830726 := by decide
theorem cert_e2422372808518 : check e2422372808518 [[],[]] .smaller = true := by decide
def e2422372808542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2422372808542 : Closed e2422372808542 ∧ code e2422372808542 = 11218465830750 := by decide
theorem cert_e2422372808542 : check e2422372808542 [[],[]] .three = true := by decide
def e2422372808570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2422372808570 : Closed e2422372808570 ∧ code e2422372808570 = 11218465830778 := by decide
theorem cert_e2422372808570 : check e2422372808570 [[],[]] .three = true := by decide
def e2422372808586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372808586 : Closed e2422372808586 ∧ code e2422372808586 = 11218465830794 := by decide
theorem cert_e2422372808586 : check e2422372808586 [[],[]] .three = true := by decide
def e2422372808610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372808610 : Closed e2422372808610 ∧ code e2422372808610 = 11218465830818 := by decide
theorem cert_e2422372808610 : check e2422372808610 [[],[]] .three = true := by decide
def e2422372808622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2422372808622 : Closed e2422372808622 ∧ code e2422372808622 = 11218465830830 := by decide
theorem cert_e2422372808622 : check e2422372808622 [[],[]] .three = true := by decide
def e2422372808634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2422372808634 : Closed e2422372808634 ∧ code e2422372808634 = 11218465830842 := by decide
theorem cert_e2422372808634 : check e2422372808634 [[],[]] .three = true := by decide
def e2422372808746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372808746 : Closed e2422372808746 ∧ code e2422372808746 = 11218465830954 := by decide
theorem cert_e2422372808746 : check e2422372808746 [[],[]] .smaller = true := by decide
def e2422372808878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372808878 : Closed e2422372808878 ∧ code e2422372808878 = 11218465831086 := by decide
theorem cert_e2422372808878 : check e2422372808878 [[],[]] .smaller = true := by decide
def e2422372808890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372808890 : Closed e2422372808890 ∧ code e2422372808890 = 11218465831098 := by decide
theorem cert_e2422372808890 : check e2422372808890 [[],[]] .smaller = true := by decide
def e2422372808918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2422372808918 : Closed e2422372808918 ∧ code e2422372808918 = 11218465831126 := by decide
theorem cert_e2422372808918 : check e2422372808918 [[],[]] .smaller = true := by decide
def e2422372808922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2422372808922 : Closed e2422372808922 ∧ code e2422372808922 = 11218465831130 := by decide
theorem cert_e2422372808922 : check e2422372808922 [[],[]] .smaller = true := by decide
def e2422372808938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372808938 : Closed e2422372808938 ∧ code e2422372808938 = 11218465831146 := by decide
theorem cert_e2422372808938 : check e2422372808938 [[],[]] .smaller = true := by decide
def e2422372809130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372809130 : Closed e2422372809130 ∧ code e2422372809130 = 11218465831338 := by decide
theorem cert_e2422372809130 : check e2422372809130 [[],[]] .smaller = true := by decide
def e2422372809226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372809226 : Closed e2422372809226 ∧ code e2422372809226 = 11218465831434 := by decide
theorem cert_e2422372809226 : check e2422372809226 [[],[]] .smaller = true := by decide
def e2422372809262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372809262 : Closed e2422372809262 ∧ code e2422372809262 = 11218465831470 := by decide
theorem cert_e2422372809262 : check e2422372809262 [[],[]] .smaller = true := by decide
def e2422372809270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372809270 : Closed e2422372809270 ∧ code e2422372809270 = 11218465831478 := by decide
theorem cert_e2422372809270 : check e2422372809270 [[],[]] .smaller = true := by decide
def e2422372809274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372809274 : Closed e2422372809274 ∧ code e2422372809274 = 11218465831482 := by decide
theorem cert_e2422372809274 : check e2422372809274 [[],[]] .smaller = true := by decide
def e2422372809322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372809322 : Closed e2422372809322 ∧ code e2422372809322 = 11218465831530 := by decide
theorem cert_e2422372809322 : check e2422372809322 [[],[]] .smaller = true := by decide
def e2422372809346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372809346 : Closed e2422372809346 ∧ code e2422372809346 = 11218465831554 := by decide
theorem cert_e2422372809346 : check e2422372809346 [[],[]] .smaller = true := by decide
def e2422372809358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372809358 : Closed e2422372809358 ∧ code e2422372809358 = 11218465831566 := by decide
theorem cert_e2422372809358 : check e2422372809358 [[],[]] .smaller = true := by decide
def e2422372809370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372809370 : Closed e2422372809370 ∧ code e2422372809370 = 11218465831578 := by decide
theorem cert_e2422372809370 : check e2422372809370 [[],[]] .smaller = true := by decide
def e2422372809414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372809414 : Closed e2422372809414 ∧ code e2422372809414 = 11218465831622 := by decide
theorem cert_e2422372809414 : check e2422372809414 [[],[]] .smaller = true := by decide
def e2422372809438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2422372809438 : Closed e2422372809438 ∧ code e2422372809438 = 11218465831646 := by decide
theorem cert_e2422372809438 : check e2422372809438 [[],[]] .three = true := by decide
def e2422372809442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372809442 : Closed e2422372809442 ∧ code e2422372809442 = 11218465831650 := by decide
theorem cert_e2422372809442 : check e2422372809442 [[],[]] .smaller = true := by decide
def e2422372809454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2422372809454 : Closed e2422372809454 ∧ code e2422372809454 = 11218465831662 := by decide
theorem cert_e2422372809454 : check e2422372809454 [[],[]] .smaller = true := by decide
def e2422372809462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2422372809462 : Closed e2422372809462 ∧ code e2422372809462 = 11218465831670 := by decide
theorem cert_e2422372809462 : check e2422372809462 [[],[]] .three = true := by decide
def e2422372809498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372809498 : Closed e2422372809498 ∧ code e2422372809498 = 11218465831706 := by decide
theorem cert_e2422372809498 : check e2422372809498 [[],[]] .smaller = true := by decide
def e2422372809542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372809542 : Closed e2422372809542 ∧ code e2422372809542 = 11218465831750 := by decide
theorem cert_e2422372809542 : check e2422372809542 [[],[]] .smaller = true := by decide
def e2422372809566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2422372809566 : Closed e2422372809566 ∧ code e2422372809566 = 11218465831774 := by decide
theorem cert_e2422372809566 : check e2422372809566 [[],[]] .three = true := by decide
def e2422372809594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2422372809594 : Closed e2422372809594 ∧ code e2422372809594 = 11218465831802 := by decide
theorem cert_e2422372809594 : check e2422372809594 [[],[]] .three = true := by decide
def e2422372809610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372809610 : Closed e2422372809610 ∧ code e2422372809610 = 11218465831818 := by decide
theorem cert_e2422372809610 : check e2422372809610 [[],[]] .smaller = true := by decide
def e2422372809634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372809634 : Closed e2422372809634 ∧ code e2422372809634 = 11218465831842 := by decide
theorem cert_e2422372809634 : check e2422372809634 [[],[]] .smaller = true := by decide
def e2422372809646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2422372809646 : Closed e2422372809646 ∧ code e2422372809646 = 11218465831854 := by decide
theorem cert_e2422372809646 : check e2422372809646 [[],[]] .smaller = true := by decide
def e2422372809658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2422372809658 : Closed e2422372809658 ∧ code e2422372809658 = 11218465831866 := by decide
theorem cert_e2422372809658 : check e2422372809658 [[],[]] .smaller = true := by decide
def e2422372809686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2422372809686 : Closed e2422372809686 ∧ code e2422372809686 = 11218465831894 := by decide
theorem cert_e2422372809686 : check e2422372809686 [[],[]] .three = true := by decide
def e2422372809690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2422372809690 : Closed e2422372809690 ∧ code e2422372809690 = 11218465831898 := by decide
theorem cert_e2422372809690 : check e2422372809690 [[],[]] .three = true := by decide
def e2422372809814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422372809814 : Closed e2422372809814 ∧ code e2422372809814 = 11218465832022 := by decide
theorem cert_e2422372809814 : check e2422372809814 [[],[]] .three = true := by decide
def e2422372809818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422372809818 : Closed e2422372809818 ∧ code e2422372809818 = 11218465832026 := by decide
theorem cert_e2422372809818 : check e2422372809818 [[],[]] .three = true := by decide
def e2422372809834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2422372809834 : Closed e2422372809834 ∧ code e2422372809834 = 11218465832042 := by decide
theorem cert_e2422372809834 : check e2422372809834 [[],[]] .three = true := by decide
def e2422372810006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372810006 : Closed e2422372810006 ∧ code e2422372810006 = 11218465832214 := by decide
theorem cert_e2422372810006 : check e2422372810006 [[],[]] .three = true := by decide
def e2422372810010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372810010 : Closed e2422372810010 ∧ code e2422372810010 = 11218465832218 := by decide
theorem cert_e2422372810010 : check e2422372810010 [[],[]] .three = true := by decide
def e2422372810054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372810054 : Closed e2422372810054 ∧ code e2422372810054 = 11218465832262 := by decide
theorem cert_e2422372810054 : check e2422372810054 [[],[]] .three = true := by decide
def e2422372810078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2422372810078 : Closed e2422372810078 ∧ code e2422372810078 = 11218465832286 := by decide
theorem cert_e2422372810078 : check e2422372810078 [[],[]] .three = true := by decide
def e2422372810082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372810082 : Closed e2422372810082 ∧ code e2422372810082 = 11218465832290 := by decide
theorem cert_e2422372810082 : check e2422372810082 [[],[]] .three = true := by decide
def e2422372810094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2422372810094 : Closed e2422372810094 ∧ code e2422372810094 = 11218465832302 := by decide
theorem cert_e2422372810094 : check e2422372810094 [[],[]] .three = true := by decide
def e2422372810102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2422372810102 : Closed e2422372810102 ∧ code e2422372810102 = 11218465832310 := by decide
theorem cert_e2422372810102 : check e2422372810102 [[],[]] .three = true := by decide
def e2422372810106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2422372810106 : Closed e2422372810106 ∧ code e2422372810106 = 11218465832314 := by decide
theorem cert_e2422372810106 : check e2422372810106 [[],[]] .three = true := by decide
def e2422372810122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372810122 : Closed e2422372810122 ∧ code e2422372810122 = 11218465832330 := by decide
theorem cert_e2422372810122 : check e2422372810122 [[],[]] .three = true := by decide
def e2422372810146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372810146 : Closed e2422372810146 ∧ code e2422372810146 = 11218465832354 := by decide
theorem cert_e2422372810146 : check e2422372810146 [[],[]] .three = true := by decide
def e2422372810158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2422372810158 : Closed e2422372810158 ∧ code e2422372810158 = 11218465832366 := by decide
theorem cert_e2422372810158 : check e2422372810158 [[],[]] .three = true := by decide
end Blc.Floor43
