import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392565930782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2392565930782 : Closed e2392565930782 ∧ code e2392565930782 = 11188658952990 := by decide
theorem cert_e2392565930782 : check e2392565930782 [[],[.left]] .chain = true := by decide
def e2392565930894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2392565930894 : Closed e2392565930894 ∧ code e2392565930894 = 11188658953102 := by decide
theorem cert_e2392565930894 : check e2392565930894 [[],[.left]] .chain = true := by decide
def e2392565930906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565930906 : Closed e2392565930906 ∧ code e2392565930906 = 11188658953114 := by decide
theorem cert_e2392565930906 : check e2392565930906 [[],[.left]] .chain = true := by decide
def e2392565931126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2392565931126 : Closed e2392565931126 ∧ code e2392565931126 = 11188658953334 := by decide
theorem cert_e2392565931126 : check e2392565931126 [[],[.left]] .chain = true := by decide
def e2392565931222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2392565931222 : Closed e2392565931222 ∧ code e2392565931222 = 11188658953430 := by decide
theorem cert_e2392565931222 : check e2392565931222 [[],[.left]] .chain = true := by decide
def e2392565931226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2392565931226 : Closed e2392565931226 ∧ code e2392565931226 = 11188658953434 := by decide
theorem cert_e2392565931226 : check e2392565931226 [[],[.left]] .chain = true := by decide
def e2392565931242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2392565931242 : Closed e2392565931242 ∧ code e2392565931242 = 11188658953450 := by decide
theorem cert_e2392565931242 : check e2392565931242 [[],[.left]] .chain = true := by decide
def e2392565931318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392565931318 : Closed e2392565931318 ∧ code e2392565931318 = 11188658953526 := by decide
theorem cert_e2392565931318 : check e2392565931318 [[],[.left]] .chain = true := by decide
def e2392565931322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392565931322 : Closed e2392565931322 ∧ code e2392565931322 = 11188658953530 := by decide
theorem cert_e2392565931322 : check e2392565931322 [[],[.left]] .chain = true := by decide
def e2392565931406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2392565931406 : Closed e2392565931406 ∧ code e2392565931406 = 11188658953614 := by decide
theorem cert_e2392565931406 : check e2392565931406 [[],[.left]] .chain = true := by decide
def e2392565931418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565931418 : Closed e2392565931418 ∧ code e2392565931418 = 11188658953626 := by decide
theorem cert_e2392565931418 : check e2392565931418 [[],[.left]] .chain = true := by decide
def e2392565932910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2392565932910 : Closed e2392565932910 ∧ code e2392565932910 = 11188658955118 := by decide
theorem cert_e2392565932910 : check e2392565932910 [[],[.left]] .chain = true := by decide
def e2392565932918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2392565932918 : Closed e2392565932918 ∧ code e2392565932918 = 11188658955126 := by decide
theorem cert_e2392565932918 : check e2392565932918 [[],[.left]] .chain = true := by decide
def e2392565932974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2392565932974 : Closed e2392565932974 ∧ code e2392565932974 = 11188658955182 := by decide
theorem cert_e2392565932974 : check e2392565932974 [[],[.left]] .chain = true := by decide
def e2392565932986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2392565932986 : Closed e2392565932986 ∧ code e2392565932986 = 11188658955194 := by decide
theorem cert_e2392565932986 : check e2392565932986 [[],[.left]] .chain = true := by decide
def e2392565933014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2392565933014 : Closed e2392565933014 ∧ code e2392565933014 = 11188658955222 := by decide
theorem cert_e2392565933014 : check e2392565933014 [[],[.left]] .chain = true := by decide
def e2392565933018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2392565933018 : Closed e2392565933018 ∧ code e2392565933018 = 11188658955226 := by decide
theorem cert_e2392565933018 : check e2392565933018 [[],[.left]] .chain = true := by decide
def e2392565933742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2392565933742 : Closed e2392565933742 ∧ code e2392565933742 = 11188658955950 := by decide
theorem cert_e2392565933742 : check e2392565933742 [[],[.left]] .chain = true := by decide
def e2392565933754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2392565933754 : Closed e2392565933754 ∧ code e2392565933754 = 11188658955962 := by decide
theorem cert_e2392565933754 : check e2392565933754 [[],[.left]] .chain = true := by decide
def e2392565933802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2392565933802 : Closed e2392565933802 ∧ code e2392565933802 = 11188658956010 := by decide
theorem cert_e2392565933802 : check e2392565933802 [[],[.left]] .chain = true := by decide
def e2392565933994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2392565933994 : Closed e2392565933994 ∧ code e2392565933994 = 11188658956202 := by decide
theorem cert_e2392565933994 : check e2392565933994 [[],[.left]] .chain = true := by decide
def e2392565934318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2392565934318 : Closed e2392565934318 ∧ code e2392565934318 = 11188658956526 := by decide
theorem cert_e2392565934318 : check e2392565934318 [[],[.left]] .chain = true := by decide
def e2392565934326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2392565934326 : Closed e2392565934326 ∧ code e2392565934326 = 11188658956534 := by decide
theorem cert_e2392565934326 : check e2392565934326 [[],[.left]] .chain = true := by decide
def e2392565934510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2392565934510 : Closed e2392565934510 ∧ code e2392565934510 = 11188658956718 := by decide
theorem cert_e2392565934510 : check e2392565934510 [[],[.left]] .chain = true := by decide
def e2392565934522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2392565934522 : Closed e2392565934522 ∧ code e2392565934522 = 11188658956730 := by decide
theorem cert_e2392565934522 : check e2392565934522 [[],[.left]] .chain = true := by decide
def e2392565934570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2392565934570 : Closed e2392565934570 ∧ code e2392565934570 = 11188658956778 := by decide
theorem cert_e2392565934570 : check e2392565934570 [[],[.left]] .chain = true := by decide
def e2392565934702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392565934702 : Closed e2392565934702 ∧ code e2392565934702 = 11188658956910 := by decide
theorem cert_e2392565934702 : check e2392565934702 [[],[.left]] .chain = true := by decide
def e2392565934714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392565934714 : Closed e2392565934714 ∧ code e2392565934714 = 11188658956922 := by decide
theorem cert_e2392565934714 : check e2392565934714 [[],[.left]] .chain = true := by decide
def e2392565934878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2392565934878 : Closed e2392565934878 ∧ code e2392565934878 = 11188658957086 := by decide
theorem cert_e2392565934878 : check e2392565934878 [[],[.left]] .chain = true := by decide
def e2392565934990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2392565934990 : Closed e2392565934990 ∧ code e2392565934990 = 11188658957198 := by decide
theorem cert_e2392565934990 : check e2392565934990 [[],[.left]] .chain = true := by decide
def e2392565935002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565935002 : Closed e2392565935002 ∧ code e2392565935002 = 11188658957210 := by decide
theorem cert_e2392565935002 : check e2392565935002 [[],[.left]] .chain = true := by decide
def e2392565935214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2392565935214 : Closed e2392565935214 ∧ code e2392565935214 = 11188658957422 := by decide
theorem cert_e2392565935214 : check e2392565935214 [[],[.left]] .chain = true := by decide
def e2392565935226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2392565935226 : Closed e2392565935226 ∧ code e2392565935226 = 11188658957434 := by decide
theorem cert_e2392565935226 : check e2392565935226 [[],[.left]] .chain = true := by decide
def e2392565935390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2392565935390 : Closed e2392565935390 ∧ code e2392565935390 = 11188658957598 := by decide
theorem cert_e2392565935390 : check e2392565935390 [[],[.left]] .chain = true := by decide
def e2392565935558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2392565935558 : Closed e2392565935558 ∧ code e2392565935558 = 11188658957766 := by decide
theorem cert_e2392565935558 : check e2392565935558 [[],[.left]] .chain = true := by decide
def e2392565935670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2392565935670 : Closed e2392565935670 ∧ code e2392565935670 = 11188658957878 := by decide
theorem cert_e2392565935670 : check e2392565935670 [[],[.left]] .chain = true := by decide
def e2392565935674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2392565935674 : Closed e2392565935674 ∧ code e2392565935674 = 11188658957882 := by decide
theorem cert_e2392565935674 : check e2392565935674 [[],[.left]] .chain = true := by decide
def e2392565935722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2392565935722 : Closed e2392565935722 ∧ code e2392565935722 = 11188658957930 := by decide
theorem cert_e2392565935722 : check e2392565935722 [[],[.left]] .chain = true := by decide
def e2392565935758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2392565935758 : Closed e2392565935758 ∧ code e2392565935758 = 11188658957966 := by decide
theorem cert_e2392565935758 : check e2392565935758 [[],[.left]] .chain = true := by decide
def e2392565935770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565935770 : Closed e2392565935770 ∧ code e2392565935770 = 11188658957978 := by decide
theorem cert_e2392565935770 : check e2392565935770 [[],[.left]] .chain = true := by decide
def e2392565935814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2392565935814 : Closed e2392565935814 ∧ code e2392565935814 = 11188658958022 := by decide
theorem cert_e2392565935814 : check e2392565935814 [[],[.left]] .chain = true := by decide
def e2392565936566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2392565936566 : Closed e2392565936566 ∧ code e2392565936566 = 11188658958774 := by decide
theorem cert_e2392565936566 : check e2392565936566 [[],[.left]] .chain = true := by decide
def e2392565936598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2392565936598 : Closed e2392565936598 ∧ code e2392565936598 = 11188658958806 := by decide
theorem cert_e2392565936598 : check e2392565936598 [[],[.left]] .chain = true := by decide
def e2392565936602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2392565936602 : Closed e2392565936602 ∧ code e2392565936602 = 11188658958810 := by decide
theorem cert_e2392565936602 : check e2392565936602 [[],[.left]] .chain = true := by decide
def e2392565936982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2392565936982 : Closed e2392565936982 ∧ code e2392565936982 = 11188658959190 := by decide
theorem cert_e2392565936982 : check e2392565936982 [[],[.left]] .chain = true := by decide
def e2392565936986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2392565936986 : Closed e2392565936986 ∧ code e2392565936986 = 11188658959194 := by decide
theorem cert_e2392565936986 : check e2392565936986 [[],[.left]] .chain = true := by decide
def e2392565937002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2392565937002 : Closed e2392565937002 ∧ code e2392565937002 = 11188658959210 := by decide
theorem cert_e2392565937002 : check e2392565937002 [[],[.left]] .chain = true := by decide
def e2392565937066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2392565937066 : Closed e2392565937066 ∧ code e2392565937066 = 11188658959274 := by decide
theorem cert_e2392565937066 : check e2392565937066 [[],[.left]] .chain = true := by decide
def e2392565937270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2392565937270 : Closed e2392565937270 ∧ code e2392565937270 = 11188658959478 := by decide
theorem cert_e2392565937270 : check e2392565937270 [[],[.left]] .chain = true := by decide
def e2392565937366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2392565937366 : Closed e2392565937366 ∧ code e2392565937366 = 11188658959574 := by decide
theorem cert_e2392565937366 : check e2392565937366 [[],[.left]] .chain = true := by decide
def e2392565937370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2392565937370 : Closed e2392565937370 ∧ code e2392565937370 = 11188658959578 := by decide
theorem cert_e2392565937370 : check e2392565937370 [[],[.left]] .chain = true := by decide
def e2392565937386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2392565937386 : Closed e2392565937386 ∧ code e2392565937386 = 11188658959594 := by decide
theorem cert_e2392565937386 : check e2392565937386 [[],[.left]] .chain = true := by decide
def e2392565937462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392565937462 : Closed e2392565937462 ∧ code e2392565937462 = 11188658959670 := by decide
theorem cert_e2392565937462 : check e2392565937462 [[],[.left]] .chain = true := by decide
def e2392565937466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392565937466 : Closed e2392565937466 ∧ code e2392565937466 = 11188658959674 := by decide
theorem cert_e2392565937466 : check e2392565937466 [[],[.left]] .chain = true := by decide
def e2392565937550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2392565937550 : Closed e2392565937550 ∧ code e2392565937550 = 11188658959758 := by decide
theorem cert_e2392565937550 : check e2392565937550 [[],[.left]] .chain = true := by decide
def e2392565937562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565937562 : Closed e2392565937562 ∧ code e2392565937562 = 11188658959770 := by decide
theorem cert_e2392565937562 : check e2392565937562 [[],[.left]] .chain = true := by decide
def e2392565937718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2392565937718 : Closed e2392565937718 ∧ code e2392565937718 = 11188658959926 := by decide
theorem cert_e2392565937718 : check e2392565937718 [[],[.left]] .chain = true := by decide
def e2392565937722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2392565937722 : Closed e2392565937722 ∧ code e2392565937722 = 11188658959930 := by decide
theorem cert_e2392565937722 : check e2392565937722 [[],[.left]] .chain = true := by decide
def e2392565937770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2392565937770 : Closed e2392565937770 ∧ code e2392565937770 = 11188658959978 := by decide
theorem cert_e2392565937770 : check e2392565937770 [[],[.left]] .chain = true := by decide
def e2392565937806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2392565937806 : Closed e2392565937806 ∧ code e2392565937806 = 11188658960014 := by decide
theorem cert_e2392565937806 : check e2392565937806 [[],[.left]] .chain = true := by decide
def e2392565937818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565937818 : Closed e2392565937818 ∧ code e2392565937818 = 11188658960026 := by decide
theorem cert_e2392565937818 : check e2392565937818 [[],[.left]] .chain = true := by decide
def e2392565937862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2392565937862 : Closed e2392565937862 ∧ code e2392565937862 = 11188658960070 := by decide
theorem cert_e2392565937862 : check e2392565937862 [[],[.left]] .chain = true := by decide
def e2392565944046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2392565944046 : Closed e2392565944046 ∧ code e2392565944046 = 11188658966254 := by decide
theorem cert_e2392565944046 : check e2392565944046 [[],[.left]] .chain = true := by decide
def e2392565944054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2392565944054 : Closed e2392565944054 ∧ code e2392565944054 = 11188658966262 := by decide
theorem cert_e2392565944054 : check e2392565944054 [[],[.left]] .chain = true := by decide
def e2392565944174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2392565944174 : Closed e2392565944174 ∧ code e2392565944174 = 11188658966382 := by decide
theorem cert_e2392565944174 : check e2392565944174 [[],[.left]] .chain = true := by decide
def e2392565944186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2392565944186 : Closed e2392565944186 ∧ code e2392565944186 = 11188658966394 := by decide
theorem cert_e2392565944186 : check e2392565944186 [[],[.left]] .chain = true := by decide
def e2392565944246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2392565944246 : Closed e2392565944246 ∧ code e2392565944246 = 11188658966454 := by decide
theorem cert_e2392565944246 : check e2392565944246 [[],[.left]] .chain = true := by decide
def e2392565944250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2392565944250 : Closed e2392565944250 ∧ code e2392565944250 = 11188658966458 := by decide
theorem cert_e2392565944250 : check e2392565944250 [[],[.left]] .chain = true := by decide
def e2392565947630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2392565947630 : Closed e2392565947630 ∧ code e2392565947630 = 11188658969838 := by decide
theorem cert_e2392565947630 : check e2392565947630 [[],[.left]] .chain = true := by decide
def e2392565947638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2392565947638 : Closed e2392565947638 ∧ code e2392565947638 = 11188658969846 := by decide
theorem cert_e2392565947638 : check e2392565947638 [[],[.left]] .chain = true := by decide
def e2392565948022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e2392565948022 : Closed e2392565948022 ∧ code e2392565948022 = 11188658970230 := by decide
theorem cert_e2392565948022 : check e2392565948022 [[],[.left]] .chain = true := by decide
def e2392565951854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2392565951854 : Closed e2392565951854 ∧ code e2392565951854 = 11188658974062 := by decide
theorem cert_e2392565951854 : check e2392565951854 [[],[.left]] .chain = true := by decide
def e2392565951862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2392565951862 : Closed e2392565951862 ∧ code e2392565951862 = 11188658974070 := by decide
theorem cert_e2392565951862 : check e2392565951862 [[],[.left]] .chain = true := by decide
def e2392565951918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2392565951918 : Closed e2392565951918 ∧ code e2392565951918 = 11188658974126 := by decide
theorem cert_e2392565951918 : check e2392565951918 [[],[.left]] .chain = true := by decide
def e2392565951930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2392565951930 : Closed e2392565951930 ∧ code e2392565951930 = 11188658974138 := by decide
theorem cert_e2392565951930 : check e2392565951930 [[],[.left]] .chain = true := by decide
def e2392565951958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2392565951958 : Closed e2392565951958 ∧ code e2392565951958 = 11188658974166 := by decide
theorem cert_e2392565951958 : check e2392565951958 [[],[.left]] .chain = true := by decide
def e2392565951962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2392565951962 : Closed e2392565951962 ∧ code e2392565951962 = 11188658974170 := by decide
theorem cert_e2392565951962 : check e2392565951962 [[],[.left]] .chain = true := by decide
def e2392565952174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2392565952174 : Closed e2392565952174 ∧ code e2392565952174 = 11188658974382 := by decide
theorem cert_e2392565952174 : check e2392565952174 [[],[.left]] .chain = true := by decide
def e2392565952186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2392565952186 : Closed e2392565952186 ∧ code e2392565952186 = 11188658974394 := by decide
theorem cert_e2392565952186 : check e2392565952186 [[],[.left]] .chain = true := by decide
def e2392565952234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2392565952234 : Closed e2392565952234 ∧ code e2392565952234 = 11188658974442 := by decide
theorem cert_e2392565952234 : check e2392565952234 [[],[.left]] .chain = true := by decide
def e2392565952342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2392565952342 : Closed e2392565952342 ∧ code e2392565952342 = 11188658974550 := by decide
theorem cert_e2392565952342 : check e2392565952342 [[],[.left]] .chain = true := by decide
def e2392565952346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2392565952346 : Closed e2392565952346 ∧ code e2392565952346 = 11188658974554 := by decide
theorem cert_e2392565952346 : check e2392565952346 [[],[.left]] .chain = true := by decide
def e2392565952362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2392565952362 : Closed e2392565952362 ∧ code e2392565952362 = 11188658974570 := by decide
theorem cert_e2392565952362 : check e2392565952362 [[],[.left]] .chain = true := by decide
def e2392565953390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2392565953390 : Closed e2392565953390 ∧ code e2392565953390 = 11188658975598 := by decide
theorem cert_e2392565953390 : check e2392565953390 [[],[.left]] .chain = true := by decide
def e2392565953398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2392565953398 : Closed e2392565953398 ∧ code e2392565953398 = 11188658975606 := by decide
theorem cert_e2392565953398 : check e2392565953398 [[],[.left]] .chain = true := by decide
def e2392565953454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2392565953454 : Closed e2392565953454 ∧ code e2392565953454 = 11188658975662 := by decide
theorem cert_e2392565953454 : check e2392565953454 [[],[.left]] .chain = true := by decide
def e2392565953466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2392565953466 : Closed e2392565953466 ∧ code e2392565953466 = 11188658975674 := by decide
theorem cert_e2392565953466 : check e2392565953466 [[],[.left]] .chain = true := by decide
def e2392565953494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2392565953494 : Closed e2392565953494 ∧ code e2392565953494 = 11188658975702 := by decide
theorem cert_e2392565953494 : check e2392565953494 [[],[.left]] .chain = true := by decide
def e2392565953498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2392565953498 : Closed e2392565953498 ∧ code e2392565953498 = 11188658975706 := by decide
theorem cert_e2392565953498 : check e2392565953498 [[],[.left]] .chain = true := by decide
def e2392565953774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2392565953774 : Closed e2392565953774 ∧ code e2392565953774 = 11188658975982 := by decide
theorem cert_e2392565953774 : check e2392565953774 [[],[.left]] .chain = true := by decide
def e2392565953782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2392565953782 : Closed e2392565953782 ∧ code e2392565953782 = 11188658975990 := by decide
theorem cert_e2392565953782 : check e2392565953782 [[],[.left]] .chain = true := by decide
def e2392565954158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2392565954158 : Closed e2392565954158 ∧ code e2392565954158 = 11188658976366 := by decide
theorem cert_e2392565954158 : check e2392565954158 [[],[.left]] .chain = true := by decide
def e2392565954170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2392565954170 : Closed e2392565954170 ∧ code e2392565954170 = 11188658976378 := by decide
theorem cert_e2392565954170 : check e2392565954170 [[],[.left]] .chain = true := by decide
def e2392565954358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2392565954358 : Closed e2392565954358 ∧ code e2392565954358 = 11188658976566 := by decide
theorem cert_e2392565954358 : check e2392565954358 [[],[.left]] .chain = true := by decide
def e2392565954362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2392565954362 : Closed e2392565954362 ∧ code e2392565954362 = 11188658976570 := by decide
theorem cert_e2392565954362 : check e2392565954362 [[],[.left]] .chain = true := by decide
def e2392565954798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2392565954798 : Closed e2392565954798 ∧ code e2392565954798 = 11188658977006 := by decide
theorem cert_e2392565954798 : check e2392565954798 [[],[.left]] .chain = true := by decide
def e2392565954806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2392565954806 : Closed e2392565954806 ∧ code e2392565954806 = 11188658977014 := by decide
theorem cert_e2392565954806 : check e2392565954806 [[],[.left]] .chain = true := by decide
def e2392565954990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2392565954990 : Closed e2392565954990 ∧ code e2392565954990 = 11188658977198 := by decide
theorem cert_e2392565954990 : check e2392565954990 [[],[.left]] .chain = true := by decide
def e2392565955002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2392565955002 : Closed e2392565955002 ∧ code e2392565955002 = 11188658977210 := by decide
theorem cert_e2392565955002 : check e2392565955002 [[],[.left]] .chain = true := by decide
def e2392565955050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2392565955050 : Closed e2392565955050 ∧ code e2392565955050 = 11188658977258 := by decide
theorem cert_e2392565955050 : check e2392565955050 [[],[.left]] .chain = true := by decide
def e2392565955182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2392565955182 : Closed e2392565955182 ∧ code e2392565955182 = 11188658977390 := by decide
theorem cert_e2392565955182 : check e2392565955182 [[],[.left]] .chain = true := by decide
def e2392565955194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2392565955194 : Closed e2392565955194 ∧ code e2392565955194 = 11188658977402 := by decide
theorem cert_e2392565955194 : check e2392565955194 [[],[.left]] .chain = true := by decide
def e2392565955358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2392565955358 : Closed e2392565955358 ∧ code e2392565955358 = 11188658977566 := by decide
theorem cert_e2392565955358 : check e2392565955358 [[],[.left]] .chain = true := by decide
def e2392565955470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2392565955470 : Closed e2392565955470 ∧ code e2392565955470 = 11188658977678 := by decide
theorem cert_e2392565955470 : check e2392565955470 [[],[.left]] .chain = true := by decide
def e2392565955482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565955482 : Closed e2392565955482 ∧ code e2392565955482 = 11188658977690 := by decide
theorem cert_e2392565955482 : check e2392565955482 [[],[.left]] .chain = true := by decide
def e2392565955702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2392565955702 : Closed e2392565955702 ∧ code e2392565955702 = 11188658977910 := by decide
theorem cert_e2392565955702 : check e2392565955702 [[],[.left]] .chain = true := by decide
def e2392565955798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2392565955798 : Closed e2392565955798 ∧ code e2392565955798 = 11188658978006 := by decide
theorem cert_e2392565955798 : check e2392565955798 [[],[.left]] .chain = true := by decide
def e2392565955802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2392565955802 : Closed e2392565955802 ∧ code e2392565955802 = 11188658978010 := by decide
theorem cert_e2392565955802 : check e2392565955802 [[],[.left]] .chain = true := by decide
def e2392565955818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2392565955818 : Closed e2392565955818 ∧ code e2392565955818 = 11188658978026 := by decide
theorem cert_e2392565955818 : check e2392565955818 [[],[.left]] .chain = true := by decide
def e2392565955894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2392565955894 : Closed e2392565955894 ∧ code e2392565955894 = 11188658978102 := by decide
theorem cert_e2392565955894 : check e2392565955894 [[],[.left]] .chain = true := by decide
def e2392565955898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2392565955898 : Closed e2392565955898 ∧ code e2392565955898 = 11188658978106 := by decide
theorem cert_e2392565955898 : check e2392565955898 [[],[.left]] .chain = true := by decide
def e2392565955982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2392565955982 : Closed e2392565955982 ∧ code e2392565955982 = 11188658978190 := by decide
theorem cert_e2392565955982 : check e2392565955982 [[],[.left]] .chain = true := by decide
def e2392565955994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565955994 : Closed e2392565955994 ∧ code e2392565955994 = 11188658978202 := by decide
theorem cert_e2392565955994 : check e2392565955994 [[],[.left]] .chain = true := by decide
def e2392565957598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2392565957598 : Closed e2392565957598 ∧ code e2392565957598 = 11188658979806 := by decide
theorem cert_e2392565957598 : check e2392565957598 [[],[.left]] .chain = true := by decide
def e2392565957614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2392565957614 : Closed e2392565957614 ∧ code e2392565957614 = 11188658979822 := by decide
theorem cert_e2392565957614 : check e2392565957614 [[],[.left]] .chain = true := by decide
def e2392565959534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392565959534 : Closed e2392565959534 ∧ code e2392565959534 = 11188658981742 := by decide
theorem cert_e2392565959534 : check e2392565959534 [[],[.left]] .chain = true := by decide
def e2392565959542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392565959542 : Closed e2392565959542 ∧ code e2392565959542 = 11188658981750 := by decide
theorem cert_e2392565959542 : check e2392565959542 [[],[.left]] .chain = true := by decide
def e2392565959598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392565959598 : Closed e2392565959598 ∧ code e2392565959598 = 11188658981806 := by decide
theorem cert_e2392565959598 : check e2392565959598 [[],[.left]] .chain = true := by decide
def e2392565959610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392565959610 : Closed e2392565959610 ∧ code e2392565959610 = 11188658981818 := by decide
theorem cert_e2392565959610 : check e2392565959610 [[],[.left]] .chain = true := by decide
def e2392565959638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392565959638 : Closed e2392565959638 ∧ code e2392565959638 = 11188658981846 := by decide
theorem cert_e2392565959638 : check e2392565959638 [[],[.left]] .chain = true := by decide
def e2392565959642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392565959642 : Closed e2392565959642 ∧ code e2392565959642 = 11188658981850 := by decide
theorem cert_e2392565959642 : check e2392565959642 [[],[.left]] .chain = true := by decide
def e2392565959918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392565959918 : Closed e2392565959918 ∧ code e2392565959918 = 11188658982126 := by decide
theorem cert_e2392565959918 : check e2392565959918 [[],[.left]] .chain = true := by decide
def e2392565959926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392565959926 : Closed e2392565959926 ∧ code e2392565959926 = 11188658982134 := by decide
theorem cert_e2392565959926 : check e2392565959926 [[],[.left]] .chain = true := by decide
def e2392565960302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392565960302 : Closed e2392565960302 ∧ code e2392565960302 = 11188658982510 := by decide
theorem cert_e2392565960302 : check e2392565960302 [[],[.left]] .chain = true := by decide
def e2392565960314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392565960314 : Closed e2392565960314 ∧ code e2392565960314 = 11188658982522 := by decide
theorem cert_e2392565960314 : check e2392565960314 [[],[.left]] .chain = true := by decide
def e2392565960502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392565960502 : Closed e2392565960502 ∧ code e2392565960502 = 11188658982710 := by decide
theorem cert_e2392565960502 : check e2392565960502 [[],[.left]] .chain = true := by decide
def e2392565960506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392565960506 : Closed e2392565960506 ∧ code e2392565960506 = 11188658982714 := by decide
theorem cert_e2392565960506 : check e2392565960506 [[],[.left]] .chain = true := by decide
def e2392565965278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2392565965278 : Closed e2392565965278 ∧ code e2392565965278 = 11188658987486 := by decide
theorem cert_e2392565965278 : check e2392565965278 [[],[.left]] .chain = true := by decide
def e2392565965302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2392565965302 : Closed e2392565965302 ∧ code e2392565965302 = 11188658987510 := by decide
theorem cert_e2392565965302 : check e2392565965302 [[],[.left]] .chain = true := by decide
def e2392565966254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2392565966254 : Closed e2392565966254 ∧ code e2392565966254 = 11188658988462 := by decide
theorem cert_e2392565966254 : check e2392565966254 [[],[.left]] .chain = true := by decide
def e2392565966266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2392565966266 : Closed e2392565966266 ∧ code e2392565966266 = 11188658988474 := by decide
theorem cert_e2392565966266 : check e2392565966266 [[],[.left]] .chain = true := by decide
def e2392565966314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2392565966314 : Closed e2392565966314 ∧ code e2392565966314 = 11188658988522 := by decide
theorem cert_e2392565966314 : check e2392565966314 [[],[.left]] .chain = true := by decide
def e2392565966446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2392565966446 : Closed e2392565966446 ∧ code e2392565966446 = 11188658988654 := by decide
theorem cert_e2392565966446 : check e2392565966446 [[],[.left]] .chain = true := by decide
def e2392565966458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2392565966458 : Closed e2392565966458 ∧ code e2392565966458 = 11188658988666 := by decide
theorem cert_e2392565966458 : check e2392565966458 [[],[.left]] .chain = true := by decide
def e2392565966622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2392565966622 : Closed e2392565966622 ∧ code e2392565966622 = 11188658988830 := by decide
theorem cert_e2392565966622 : check e2392565966622 [[],[.left]] .chain = true := by decide
def e2392565966734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2392565966734 : Closed e2392565966734 ∧ code e2392565966734 = 11188658988942 := by decide
theorem cert_e2392565966734 : check e2392565966734 [[],[.left]] .chain = true := by decide
def e2392565966746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2392565966746 : Closed e2392565966746 ∧ code e2392565966746 = 11188658988954 := by decide
theorem cert_e2392565966746 : check e2392565966746 [[],[.left]] .chain = true := by decide
def e2392565969134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2392565969134 : Closed e2392565969134 ∧ code e2392565969134 = 11188658991342 := by decide
theorem cert_e2392565969134 : check e2392565969134 [[],[.left]] .chain = true := by decide
def e2392565969142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2392565969142 : Closed e2392565969142 ∧ code e2392565969142 = 11188658991350 := by decide
theorem cert_e2392565969142 : check e2392565969142 [[],[.left]] .chain = true := by decide
def e2392565969622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2392565969622 : Closed e2392565969622 ∧ code e2392565969622 = 11188658991830 := by decide
theorem cert_e2392565969622 : check e2392565969622 [[],[.left]] .chain = true := by decide
def e2392565969626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2392565969626 : Closed e2392565969626 ∧ code e2392565969626 = 11188658991834 := by decide
theorem cert_e2392565969626 : check e2392565969626 [[],[.left]] .chain = true := by decide
def e2392565969642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2392565969642 : Closed e2392565969642 ∧ code e2392565969642 = 11188658991850 := by decide
theorem cert_e2392565969642 : check e2392565969642 [[],[.left]] .chain = true := by decide
def e2392565969718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2392565969718 : Closed e2392565969718 ∧ code e2392565969718 = 11188658991926 := by decide
theorem cert_e2392565969718 : check e2392565969718 [[],[.left]] .chain = true := by decide
def e2392565969722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2392565969722 : Closed e2392565969722 ∧ code e2392565969722 = 11188658991930 := by decide
theorem cert_e2392565969722 : check e2392565969722 [[],[.left]] .chain = true := by decide
def e2392565969806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2392565969806 : Closed e2392565969806 ∧ code e2392565969806 = 11188658992014 := by decide
theorem cert_e2392565969806 : check e2392565969806 [[],[.left]] .chain = true := by decide
def e2392565969818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2392565969818 : Closed e2392565969818 ∧ code e2392565969818 = 11188658992026 := by decide
theorem cert_e2392565969818 : check e2392565969818 [[],[.left]] .chain = true := by decide
def e2392565974894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2392565974894 : Closed e2392565974894 ∧ code e2392565974894 = 11188658997102 := by decide
theorem cert_e2392565974894 : check e2392565974894 [[],[.left]] .chain = true := by decide
def e2392565974906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e2392565974906 : Closed e2392565974906 ∧ code e2392565974906 = 11188658997114 := by decide
theorem cert_e2392565974906 : check e2392565974906 [[],[.left]] .chain = true := by decide
def e2392565975002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e2392565975002 : Closed e2392565975002 ∧ code e2392565975002 = 11188658997210 := by decide
theorem cert_e2392565975002 : check e2392565975002 [[],[.left]] .chain = true := by decide
def e2392565976302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2392565976302 : Closed e2392565976302 ∧ code e2392565976302 = 11188658998510 := by decide
theorem cert_e2392565976302 : check e2392565976302 [[],[.left]] .chain = true := by decide
def e2392565976310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2392565976310 : Closed e2392565976310 ∧ code e2392565976310 = 11188658998518 := by decide
theorem cert_e2392565976310 : check e2392565976310 [[],[.left]] .chain = true := by decide
def e2392565976686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2392565976686 : Closed e2392565976686 ∧ code e2392565976686 = 11188658998894 := by decide
theorem cert_e2392565976686 : check e2392565976686 [[],[.left]] .chain = true := by decide
def e2392565976698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2392565976698 : Closed e2392565976698 ∧ code e2392565976698 = 11188658998906 := by decide
theorem cert_e2392565976698 : check e2392565976698 [[],[.left]] .chain = true := by decide
def e2392565976886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2392565976886 : Closed e2392565976886 ∧ code e2392565976886 = 11188658999094 := by decide
theorem cert_e2392565976886 : check e2392565976886 [[],[.left]] .chain = true := by decide
def e2392565976890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2392565976890 : Closed e2392565976890 ∧ code e2392565976890 = 11188658999098 := by decide
theorem cert_e2392565976890 : check e2392565976890 [[],[.left]] .chain = true := by decide
def e2392565978798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2392565978798 : Closed e2392565978798 ∧ code e2392565978798 = 11188659001006 := by decide
theorem cert_e2392565978798 : check e2392565978798 [[],[.left]] .chain = true := by decide
def e2392565978810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2392565978810 : Closed e2392565978810 ∧ code e2392565978810 = 11188659001018 := by decide
theorem cert_e2392565978810 : check e2392565978810 [[],[.left]] .chain = true := by decide
def e2392565978858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2392565978858 : Closed e2392565978858 ∧ code e2392565978858 = 11188659001066 := by decide
theorem cert_e2392565978858 : check e2392565978858 [[],[.left]] .chain = true := by decide
def e2392565979050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2392565979050 : Closed e2392565979050 ∧ code e2392565979050 = 11188659001258 := by decide
theorem cert_e2392565979050 : check e2392565979050 [[],[.left]] .chain = true := by decide
def e2392565979374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2392565979374 : Closed e2392565979374 ∧ code e2392565979374 = 11188659001582 := by decide
theorem cert_e2392565979374 : check e2392565979374 [[],[.left]] .chain = true := by decide
end Blc.Floor43
