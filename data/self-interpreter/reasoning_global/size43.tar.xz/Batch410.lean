import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373213658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2422373213658 : Closed e2422373213658 ∧ code e2422373213658 = 11218466235866 := by decide
theorem cert_e2422373213658 : check e2422373213658 [[],[]] .smaller = true := by decide
def e2422373213758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422373213758 : Closed e2422373213758 ∧ code e2422373213758 = 11218466235966 := by decide
theorem cert_e2422373213758 : check e2422373213758 [[],[]] .three = true := by decide
def e2422373213814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373213814 : Closed e2422373213814 ∧ code e2422373213814 = 11218466236022 := by decide
theorem cert_e2422373213814 : check e2422373213814 [[],[]] .smaller = true := by decide
def e2422373213982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422373213982 : Closed e2422373213982 ∧ code e2422373213982 = 11218466236190 := by decide
theorem cert_e2422373213982 : check e2422373213982 [[],[]] .smaller = true := by decide
def e2422373214006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373214006 : Closed e2422373214006 ∧ code e2422373214006 = 11218466236214 := by decide
theorem cert_e2422373214006 : check e2422373214006 [[],[]] .smaller = true := by decide
def e2422373214010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373214010 : Closed e2422373214010 ∧ code e2422373214010 = 11218466236218 := by decide
theorem cert_e2422373214010 : check e2422373214010 [[],[]] .smaller = true := by decide
def e2422373214094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422373214094 : Closed e2422373214094 ∧ code e2422373214094 = 11218466236302 := by decide
theorem cert_e2422373214094 : check e2422373214094 [[],[]] .smaller = true := by decide
def e2422373214150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422373214150 : Closed e2422373214150 ∧ code e2422373214150 = 11218466236358 := by decide
theorem cert_e2422373214150 : check e2422373214150 [[],[]] .three = true := by decide
def e2422373214174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 3) (.var 3))))))))
theorem wire_e2422373214174 : Closed e2422373214174 ∧ code e2422373214174 = 11218466236382 := by decide
theorem cert_e2422373214174 : check e2422373214174 [[],[]] .three = true := by decide
def e2422373216494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373216494 : Closed e2422373216494 ∧ code e2422373216494 = 11218466238702 := by decide
theorem cert_e2422373216494 : check e2422373216494 [[],[]] .three = true := by decide
def e2422373216502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373216502 : Closed e2422373216502 ∧ code e2422373216502 = 11218466238710 := by decide
theorem cert_e2422373216502 : check e2422373216502 [[],[]] .three = true := by decide
def e2422373216982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422373216982 : Closed e2422373216982 ∧ code e2422373216982 = 11218466239190 := by decide
theorem cert_e2422373216982 : check e2422373216982 [[],[]] .three = true := by decide
def e2422373216986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422373216986 : Closed e2422373216986 ∧ code e2422373216986 = 11218466239194 := by decide
theorem cert_e2422373216986 : check e2422373216986 [[],[]] .three = true := by decide
def e2422373217002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422373217002 : Closed e2422373217002 ∧ code e2422373217002 = 11218466239210 := by decide
theorem cert_e2422373217002 : check e2422373217002 [[],[]] .three = true := by decide
def e2422373217054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422373217054 : Closed e2422373217054 ∧ code e2422373217054 = 11218466239262 := by decide
theorem cert_e2422373217054 : check e2422373217054 [[],[]] .three = true := by decide
def e2422373217078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373217078 : Closed e2422373217078 ∧ code e2422373217078 = 11218466239286 := by decide
theorem cert_e2422373217078 : check e2422373217078 [[],[]] .three = true := by decide
def e2422373217082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373217082 : Closed e2422373217082 ∧ code e2422373217082 = 11218466239290 := by decide
theorem cert_e2422373217082 : check e2422373217082 [[],[]] .three = true := by decide
def e2422373217166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2422373217166 : Closed e2422373217166 ∧ code e2422373217166 = 11218466239374 := by decide
theorem cert_e2422373217166 : check e2422373217166 [[],[]] .three = true := by decide
def e2422373217178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373217178 : Closed e2422373217178 ∧ code e2422373217178 = 11218466239386 := by decide
theorem cert_e2422373217178 : check e2422373217178 [[],[]] .three = true := by decide
def e2422373217222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422373217222 : Closed e2422373217222 ∧ code e2422373217222 = 11218466239430 := by decide
theorem cert_e2422373217222 : check e2422373217222 [[],[]] .three = true := by decide
def e2422373217246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373217246 : Closed e2422373217246 ∧ code e2422373217246 = 11218466239454 := by decide
theorem cert_e2422373217246 : check e2422373217246 [[],[]] .three = true := by decide
def e2422373217262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373217262 : Closed e2422373217262 ∧ code e2422373217262 = 11218466239470 := by decide
theorem cert_e2422373217262 : check e2422373217262 [[],[]] .three = true := by decide
def e2422373266798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2422373266798 : Closed e2422373266798 ∧ code e2422373266798 = 11218466289006 := by decide
theorem cert_e2422373266798 : check e2422373266798 [[],[]] .smaller = true := by decide
def e2422373266806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2422373266806 : Closed e2422373266806 ∧ code e2422373266806 = 11218466289014 := by decide
theorem cert_e2422373266806 : check e2422373266806 [[],[]] .smaller = true := by decide
def e2422373266862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2422373266862 : Closed e2422373266862 ∧ code e2422373266862 = 11218466289070 := by decide
theorem cert_e2422373266862 : check e2422373266862 [[],[]] .smaller = true := by decide
def e2422373266874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2422373266874 : Closed e2422373266874 ∧ code e2422373266874 = 11218466289082 := by decide
theorem cert_e2422373266874 : check e2422373266874 [[],[]] .smaller = true := by decide
def e2422373266902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2422373266902 : Closed e2422373266902 ∧ code e2422373266902 = 11218466289110 := by decide
theorem cert_e2422373266902 : check e2422373266902 [[],[]] .smaller = true := by decide
def e2422373266906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2422373266906 : Closed e2422373266906 ∧ code e2422373266906 = 11218466289114 := by decide
theorem cert_e2422373266906 : check e2422373266906 [[],[]] .smaller = true := by decide
def e2422373267118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2422373267118 : Closed e2422373267118 ∧ code e2422373267118 = 11218466289326 := by decide
theorem cert_e2422373267118 : check e2422373267118 [[],[]] .smaller = true := by decide
def e2422373267130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2422373267130 : Closed e2422373267130 ∧ code e2422373267130 = 11218466289338 := by decide
theorem cert_e2422373267130 : check e2422373267130 [[],[]] .smaller = true := by decide
def e2422373267178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2422373267178 : Closed e2422373267178 ∧ code e2422373267178 = 11218466289386 := by decide
theorem cert_e2422373267178 : check e2422373267178 [[],[]] .smaller = true := by decide
def e2422373267286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2422373267286 : Closed e2422373267286 ∧ code e2422373267286 = 11218466289494 := by decide
theorem cert_e2422373267286 : check e2422373267286 [[],[]] .smaller = true := by decide
def e2422373267290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2422373267290 : Closed e2422373267290 ∧ code e2422373267290 = 11218466289498 := by decide
theorem cert_e2422373267290 : check e2422373267290 [[],[]] .smaller = true := by decide
def e2422373267306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2422373267306 : Closed e2422373267306 ∧ code e2422373267306 = 11218466289514 := by decide
theorem cert_e2422373267306 : check e2422373267306 [[],[]] .smaller = true := by decide
def e2422373268142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2422373268142 : Closed e2422373268142 ∧ code e2422373268142 = 11218466290350 := by decide
theorem cert_e2422373268142 : check e2422373268142 [[],[]] .smaller = true := by decide
def e2422373268154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2422373268154 : Closed e2422373268154 ∧ code e2422373268154 = 11218466290362 := by decide
theorem cert_e2422373268154 : check e2422373268154 [[],[]] .smaller = true := by decide
def e2422373268202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2422373268202 : Closed e2422373268202 ∧ code e2422373268202 = 11218466290410 := by decide
theorem cert_e2422373268202 : check e2422373268202 [[],[]] .smaller = true := by decide
def e2422373268394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422373268394 : Closed e2422373268394 ∧ code e2422373268394 = 11218466290602 := by decide
theorem cert_e2422373268394 : check e2422373268394 [[],[]] .smaller = true := by decide
def e2422373268822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2422373268822 : Closed e2422373268822 ∧ code e2422373268822 = 11218466291030 := by decide
theorem cert_e2422373268822 : check e2422373268822 [[],[]] .smaller = true := by decide
def e2422373268826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2422373268826 : Closed e2422373268826 ∧ code e2422373268826 = 11218466291034 := by decide
theorem cert_e2422373268826 : check e2422373268826 [[],[]] .smaller = true := by decide
def e2422373268842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2422373268842 : Closed e2422373268842 ∧ code e2422373268842 = 11218466291050 := by decide
theorem cert_e2422373268842 : check e2422373268842 [[],[]] .smaller = true := by decide
def e2422373268906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422373268906 : Closed e2422373268906 ∧ code e2422373268906 = 11218466291114 := by decide
theorem cert_e2422373268906 : check e2422373268906 [[],[]] .smaller = true := by decide
def e2422373269870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))) (.var 2)))))))
theorem wire_e2422373269870 : Closed e2422373269870 ∧ code e2422373269870 = 11218466292078 := by decide
theorem cert_e2422373269870 : check e2422373269870 [[],[]] .smaller = true := by decide
def e2422373269878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))) (.var 1)))))))
theorem wire_e2422373269878 : Closed e2422373269878 ∧ code e2422373269878 = 11218466292086 := by decide
theorem cert_e2422373269878 : check e2422373269878 [[],[]] .smaller = true := by decide
def e2422373271006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 3)))))))
theorem wire_e2422373271006 : Closed e2422373271006 ∧ code e2422373271006 = 11218466293214 := by decide
theorem cert_e2422373271006 : check e2422373271006 [[],[]] .three = true := by decide
def e2422373271022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))) (.var 2)))))))
theorem wire_e2422373271022 : Closed e2422373271022 ∧ code e2422373271022 = 11218466293230 := by decide
theorem cert_e2422373271022 : check e2422373271022 [[],[]] .three = true := by decide
def e2422373271262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 3)))))))
theorem wire_e2422373271262 : Closed e2422373271262 ∧ code e2422373271262 = 11218466293470 := by decide
theorem cert_e2422373271262 : check e2422373271262 [[],[]] .three = true := by decide
def e2422373271286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))) (.var 1)))))))
theorem wire_e2422373271286 : Closed e2422373271286 ∧ code e2422373271286 = 11218466293494 := by decide
theorem cert_e2422373271286 : check e2422373271286 [[],[]] .three = true := by decide
def e2422373271390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 3)))))))
theorem wire_e2422373271390 : Closed e2422373271390 ∧ code e2422373271390 = 11218466293598 := by decide
theorem cert_e2422373271390 : check e2422373271390 [[],[]] .three = true := by decide
def e2422373271406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))) (.var 2)))))))
theorem wire_e2422373271406 : Closed e2422373271406 ∧ code e2422373271406 = 11218466293614 := by decide
theorem cert_e2422373271406 : check e2422373271406 [[],[]] .smaller = true := by decide
def e2422373271414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 1)))))))
theorem wire_e2422373271414 : Closed e2422373271414 ∧ code e2422373271414 = 11218466293622 := by decide
theorem cert_e2422373271414 : check e2422373271414 [[],[]] .smaller = true := by decide
def e2422373271418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))) (.var 0)))))))
theorem wire_e2422373271418 : Closed e2422373271418 ∧ code e2422373271418 = 11218466293626 := by decide
theorem cert_e2422373271418 : check e2422373271418 [[],[]] .three = true := by decide
def e2422373271478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 1)))))))
theorem wire_e2422373271478 : Closed e2422373271478 ∧ code e2422373271478 = 11218466293686 := by decide
theorem cert_e2422373271478 : check e2422373271478 [[],[]] .smaller = true := by decide
def e2422373271510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))) (.var 1)))))))
theorem wire_e2422373271510 : Closed e2422373271510 ∧ code e2422373271510 = 11218466293718 := by decide
theorem cert_e2422373271510 : check e2422373271510 [[],[]] .three = true := by decide
def e2422373271514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))) (.var 0)))))))
theorem wire_e2422373271514 : Closed e2422373271514 ∧ code e2422373271514 = 11218466293722 := by decide
theorem cert_e2422373271514 : check e2422373271514 [[],[]] .three = true := by decide
def e2422373272942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))) (.var 2)))))))
theorem wire_e2422373272942 : Closed e2422373272942 ∧ code e2422373272942 = 11218466295150 := by decide
theorem cert_e2422373272942 : check e2422373272942 [[],[]] .smaller = true := by decide
def e2422373272950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))) (.var 1)))))))
theorem wire_e2422373272950 : Closed e2422373272950 ∧ code e2422373272950 = 11218466295158 := by decide
theorem cert_e2422373272950 : check e2422373272950 [[],[]] .smaller = true := by decide
def e2422373273006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.var 2)))))))
theorem wire_e2422373273006 : Closed e2422373273006 ∧ code e2422373273006 = 11218466295214 := by decide
theorem cert_e2422373273006 : check e2422373273006 [[],[]] .smaller = true := by decide
def e2422373273018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.var 0)))))))
theorem wire_e2422373273018 : Closed e2422373273018 ∧ code e2422373273018 = 11218466295226 := by decide
theorem cert_e2422373273018 : check e2422373273018 [[],[]] .smaller = true := by decide
def e2422373273046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))) (.var 1)))))))
theorem wire_e2422373273046 : Closed e2422373273046 ∧ code e2422373273046 = 11218466295254 := by decide
theorem cert_e2422373273046 : check e2422373273046 [[],[]] .smaller = true := by decide
def e2422373273050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.var 0)))))))
theorem wire_e2422373273050 : Closed e2422373273050 ∧ code e2422373273050 = 11218466295258 := by decide
theorem cert_e2422373273050 : check e2422373273050 [[],[]] .smaller = true := by decide
def e2422373273262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e2422373273262 : Closed e2422373273262 ∧ code e2422373273262 = 11218466295470 := by decide
theorem cert_e2422373273262 : check e2422373273262 [[],[]] .smaller = true := by decide
def e2422373273274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e2422373273274 : Closed e2422373273274 ∧ code e2422373273274 = 11218466295482 := by decide
theorem cert_e2422373273274 : check e2422373273274 [[],[]] .smaller = true := by decide
def e2422373273322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.var 0)))))))
theorem wire_e2422373273322 : Closed e2422373273322 ∧ code e2422373273322 = 11218466295530 := by decide
theorem cert_e2422373273322 : check e2422373273322 [[],[]] .smaller = true := by decide
def e2422373273430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e2422373273430 : Closed e2422373273430 ∧ code e2422373273430 = 11218466295638 := by decide
theorem cert_e2422373273430 : check e2422373273430 [[],[]] .smaller = true := by decide
def e2422373273434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e2422373273434 : Closed e2422373273434 ∧ code e2422373273434 = 11218466295642 := by decide
theorem cert_e2422373273434 : check e2422373273434 [[],[]] .smaller = true := by decide
def e2422373273450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.var 0)))))))
theorem wire_e2422373273450 : Closed e2422373273450 ∧ code e2422373273450 = 11218466295658 := by decide
theorem cert_e2422373273450 : check e2422373273450 [[],[]] .smaller = true := by decide
def e2422373274078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2422373274078 : Closed e2422373274078 ∧ code e2422373274078 = 11218466296286 := by decide
theorem cert_e2422373274078 : check e2422373274078 [[],[]] .three = true := by decide
def e2422373274102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2422373274102 : Closed e2422373274102 ∧ code e2422373274102 = 11218466296310 := by decide
theorem cert_e2422373274102 : check e2422373274102 [[],[]] .three = true := by decide
def e2422373274478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2422373274478 : Closed e2422373274478 ∧ code e2422373274478 = 11218466296686 := by decide
theorem cert_e2422373274478 : check e2422373274478 [[],[]] .smaller = true := by decide
def e2422373274486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2422373274486 : Closed e2422373274486 ∧ code e2422373274486 = 11218466296694 := by decide
theorem cert_e2422373274486 : check e2422373274486 [[],[]] .smaller = true := by decide
def e2422373274542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2422373274542 : Closed e2422373274542 ∧ code e2422373274542 = 11218466296750 := by decide
theorem cert_e2422373274542 : check e2422373274542 [[],[]] .smaller = true := by decide
def e2422373274554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2422373274554 : Closed e2422373274554 ∧ code e2422373274554 = 11218466296762 := by decide
theorem cert_e2422373274554 : check e2422373274554 [[],[]] .smaller = true := by decide
def e2422373274582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2422373274582 : Closed e2422373274582 ∧ code e2422373274582 = 11218466296790 := by decide
theorem cert_e2422373274582 : check e2422373274582 [[],[]] .smaller = true := by decide
def e2422373274586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2422373274586 : Closed e2422373274586 ∧ code e2422373274586 = 11218466296794 := by decide
theorem cert_e2422373274586 : check e2422373274586 [[],[]] .smaller = true := by decide
def e2422373274862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373274862 : Closed e2422373274862 ∧ code e2422373274862 = 11218466297070 := by decide
theorem cert_e2422373274862 : check e2422373274862 [[],[]] .smaller = true := by decide
def e2422373274870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373274870 : Closed e2422373274870 ∧ code e2422373274870 = 11218466297078 := by decide
theorem cert_e2422373274870 : check e2422373274870 [[],[]] .smaller = true := by decide
def e2422373275198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 4))))))))
theorem wire_e2422373275198 : Closed e2422373275198 ∧ code e2422373275198 = 11218466297406 := by decide
theorem cert_e2422373275198 : check e2422373275198 [[],[]] .three = true := by decide
def e2422373275246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373275246 : Closed e2422373275246 ∧ code e2422373275246 = 11218466297454 := by decide
theorem cert_e2422373275246 : check e2422373275246 [[],[]] .smaller = true := by decide
def e2422373275258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373275258 : Closed e2422373275258 ∧ code e2422373275258 = 11218466297466 := by decide
theorem cert_e2422373275258 : check e2422373275258 [[],[]] .smaller = true := by decide
def e2422373275446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373275446 : Closed e2422373275446 ∧ code e2422373275446 = 11218466297654 := by decide
theorem cert_e2422373275446 : check e2422373275446 [[],[]] .smaller = true := by decide
def e2422373275450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373275450 : Closed e2422373275450 ∧ code e2422373275450 = 11218466297658 := by decide
theorem cert_e2422373275450 : check e2422373275450 [[],[]] .smaller = true := by decide
def e2422373275534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3))) (.lam (.var 2))))))))
theorem wire_e2422373275534 : Closed e2422373275534 ∧ code e2422373275534 = 11218466297742 := by decide
theorem cert_e2422373275534 : check e2422373275534 [[],[]] .three = true := by decide
def e2422373275694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373275694 : Closed e2422373275694 ∧ code e2422373275694 = 11218466297902 := by decide
theorem cert_e2422373275694 : check e2422373275694 [[],[]] .smaller = true := by decide
def e2422373275870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2422373275870 : Closed e2422373275870 ∧ code e2422373275870 = 11218466298078 := by decide
theorem cert_e2422373275870 : check e2422373275870 [[],[]] .three = true := by decide
def e2422373275886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422373275886 : Closed e2422373275886 ∧ code e2422373275886 = 11218466298094 := by decide
theorem cert_e2422373275886 : check e2422373275886 [[],[]] .smaller = true := by decide
def e2422373275894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422373275894 : Closed e2422373275894 ∧ code e2422373275894 = 11218466298102 := by decide
theorem cert_e2422373275894 : check e2422373275894 [[],[]] .smaller = true := by decide
def e2422373275898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422373275898 : Closed e2422373275898 ∧ code e2422373275898 = 11218466298106 := by decide
theorem cert_e2422373275898 : check e2422373275898 [[],[]] .three = true := by decide
def e2422373276078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422373276078 : Closed e2422373276078 ∧ code e2422373276078 = 11218466298286 := by decide
theorem cert_e2422373276078 : check e2422373276078 [[],[]] .smaller = true := by decide
def e2422373276090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422373276090 : Closed e2422373276090 ∧ code e2422373276090 = 11218466298298 := by decide
theorem cert_e2422373276090 : check e2422373276090 [[],[]] .smaller = true := by decide
def e2422373276138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422373276138 : Closed e2422373276138 ∧ code e2422373276138 = 11218466298346 := by decide
theorem cert_e2422373276138 : check e2422373276138 [[],[]] .smaller = true := by decide
def e2422373276222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2422373276222 : Closed e2422373276222 ∧ code e2422373276222 = 11218466298430 := by decide
theorem cert_e2422373276222 : check e2422373276222 [[],[]] .three = true := by decide
def e2422373276270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373276270 : Closed e2422373276270 ∧ code e2422373276270 = 11218466298478 := by decide
theorem cert_e2422373276270 : check e2422373276270 [[],[]] .smaller = true := by decide
def e2422373276282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373276282 : Closed e2422373276282 ∧ code e2422373276282 = 11218466298490 := by decide
theorem cert_e2422373276282 : check e2422373276282 [[],[]] .smaller = true := by decide
def e2422373276446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422373276446 : Closed e2422373276446 ∧ code e2422373276446 = 11218466298654 := by decide
theorem cert_e2422373276446 : check e2422373276446 [[],[]] .smaller = true := by decide
def e2422373276546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373276546 : Closed e2422373276546 ∧ code e2422373276546 = 11218466298754 := by decide
theorem cert_e2422373276546 : check e2422373276546 [[],[]] .smaller = true := by decide
def e2422373276558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422373276558 : Closed e2422373276558 ∧ code e2422373276558 = 11218466298766 := by decide
theorem cert_e2422373276558 : check e2422373276558 [[],[]] .smaller = true := by decide
def e2422373276570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373276570 : Closed e2422373276570 ∧ code e2422373276570 = 11218466298778 := by decide
theorem cert_e2422373276570 : check e2422373276570 [[],[]] .smaller = true := by decide
def e2422373276614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422373276614 : Closed e2422373276614 ∧ code e2422373276614 = 11218466298822 := by decide
theorem cert_e2422373276614 : check e2422373276614 [[],[]] .three = true := by decide
def e2422373276638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 3)))))))
theorem wire_e2422373276638 : Closed e2422373276638 ∧ code e2422373276638 = 11218466298846 := by decide
theorem cert_e2422373276638 : check e2422373276638 [[],[]] .three = true := by decide
def e2422373276694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373276694 : Closed e2422373276694 ∧ code e2422373276694 = 11218466298902 := by decide
theorem cert_e2422373276694 : check e2422373276694 [[],[]] .smaller = true := by decide
def e2422373276766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422373276766 : Closed e2422373276766 ∧ code e2422373276766 = 11218466298974 := by decide
theorem cert_e2422373276766 : check e2422373276766 [[],[]] .three = true := by decide
def e2422373276790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2422373276790 : Closed e2422373276790 ∧ code e2422373276790 = 11218466298998 := by decide
theorem cert_e2422373276790 : check e2422373276790 [[],[]] .smaller = true := by decide
def e2422373276886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2422373276886 : Closed e2422373276886 ∧ code e2422373276886 = 11218466299094 := by decide
theorem cert_e2422373276886 : check e2422373276886 [[],[]] .smaller = true := by decide
def e2422373276890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2422373276890 : Closed e2422373276890 ∧ code e2422373276890 = 11218466299098 := by decide
theorem cert_e2422373276890 : check e2422373276890 [[],[]] .smaller = true := by decide
def e2422373276906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2422373276906 : Closed e2422373276906 ∧ code e2422373276906 = 11218466299114 := by decide
theorem cert_e2422373276906 : check e2422373276906 [[],[]] .smaller = true := by decide
def e2422373276982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373276982 : Closed e2422373276982 ∧ code e2422373276982 = 11218466299190 := by decide
theorem cert_e2422373276982 : check e2422373276982 [[],[]] .smaller = true := by decide
def e2422373276986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373276986 : Closed e2422373276986 ∧ code e2422373276986 = 11218466299194 := by decide
theorem cert_e2422373276986 : check e2422373276986 [[],[]] .smaller = true := by decide
def e2422373277058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373277058 : Closed e2422373277058 ∧ code e2422373277058 = 11218466299266 := by decide
theorem cert_e2422373277058 : check e2422373277058 [[],[]] .smaller = true := by decide
def e2422373277070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2422373277070 : Closed e2422373277070 ∧ code e2422373277070 = 11218466299278 := by decide
theorem cert_e2422373277070 : check e2422373277070 [[],[]] .smaller = true := by decide
def e2422373277082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373277082 : Closed e2422373277082 ∧ code e2422373277082 = 11218466299290 := by decide
theorem cert_e2422373277082 : check e2422373277082 [[],[]] .smaller = true := by decide
def e2422373277150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 3)))))))
theorem wire_e2422373277150 : Closed e2422373277150 ∧ code e2422373277150 = 11218466299358 := by decide
theorem cert_e2422373277150 : check e2422373277150 [[],[]] .three = true := by decide
def e2422373277154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422373277154 : Closed e2422373277154 ∧ code e2422373277154 = 11218466299362 := by decide
theorem cert_e2422373277154 : check e2422373277154 [[],[]] .three = true := by decide
def e2422373277166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 2)))))))
theorem wire_e2422373277166 : Closed e2422373277166 ∧ code e2422373277166 = 11218466299374 := by decide
theorem cert_e2422373277166 : check e2422373277166 [[],[]] .three = true := by decide
def e2422373277230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373277230 : Closed e2422373277230 ∧ code e2422373277230 = 11218466299438 := by decide
theorem cert_e2422373277230 : check e2422373277230 [[],[]] .three = true := by decide
def e2422373277238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373277238 : Closed e2422373277238 ∧ code e2422373277238 = 11218466299446 := by decide
theorem cert_e2422373277238 : check e2422373277238 [[],[]] .three = true := by decide
def e2422373277242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373277242 : Closed e2422373277242 ∧ code e2422373277242 = 11218466299450 := by decide
theorem cert_e2422373277242 : check e2422373277242 [[],[]] .three = true := by decide
def e2422373277326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373277326 : Closed e2422373277326 ∧ code e2422373277326 = 11218466299534 := by decide
theorem cert_e2422373277326 : check e2422373277326 [[],[]] .three = true := by decide
def e2422373277382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373277382 : Closed e2422373277382 ∧ code e2422373277382 = 11218466299590 := by decide
theorem cert_e2422373277382 : check e2422373277382 [[],[]] .three = true := by decide
def e2422373277406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 3)))))))
theorem wire_e2422373277406 : Closed e2422373277406 ∧ code e2422373277406 = 11218466299614 := by decide
theorem cert_e2422373277406 : check e2422373277406 [[],[]] .three = true := by decide
def e2422373277410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373277410 : Closed e2422373277410 ∧ code e2422373277410 = 11218466299618 := by decide
theorem cert_e2422373277410 : check e2422373277410 [[],[]] .three = true := by decide
def e2422373277422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 2)))))))
theorem wire_e2422373277422 : Closed e2422373277422 ∧ code e2422373277422 = 11218466299630 := by decide
theorem cert_e2422373277422 : check e2422373277422 [[],[]] .three = true := by decide
def e2422373277430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 3))) (.var 1)))))))
theorem wire_e2422373277430 : Closed e2422373277430 ∧ code e2422373277430 = 11218466299638 := by decide
theorem cert_e2422373277430 : check e2422373277430 [[],[]] .three = true := by decide
def e2422373277870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))) (.var 2)))))))
theorem wire_e2422373277870 : Closed e2422373277870 ∧ code e2422373277870 = 11218466300078 := by decide
theorem cert_e2422373277870 : check e2422373277870 [[],[]] .smaller = true := by decide
def e2422373277882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))) (.var 0)))))))
theorem wire_e2422373277882 : Closed e2422373277882 ∧ code e2422373277882 = 11218466300090 := by decide
theorem cert_e2422373277882 : check e2422373277882 [[],[]] .smaller = true := by decide
def e2422373278430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.var 3)))))))
theorem wire_e2422373278430 : Closed e2422373278430 ∧ code e2422373278430 = 11218466300638 := by decide
theorem cert_e2422373278430 : check e2422373278430 [[],[]] .three = true := by decide
def e2422373278446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 2)))))))
theorem wire_e2422373278446 : Closed e2422373278446 ∧ code e2422373278446 = 11218466300654 := by decide
theorem cert_e2422373278446 : check e2422373278446 [[],[]] .smaller = true := by decide
def e2422373278454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 3))) (.var 1)))))))
theorem wire_e2422373278454 : Closed e2422373278454 ∧ code e2422373278454 = 11218466300662 := by decide
theorem cert_e2422373278454 : check e2422373278454 [[],[]] .three = true := by decide
def e2422373278558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 3)))))))
theorem wire_e2422373278558 : Closed e2422373278558 ∧ code e2422373278558 = 11218466300766 := by decide
theorem cert_e2422373278558 : check e2422373278558 [[],[]] .three = true := by decide
def e2422373278574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))) (.var 2)))))))
theorem wire_e2422373278574 : Closed e2422373278574 ∧ code e2422373278574 = 11218466300782 := by decide
theorem cert_e2422373278574 : check e2422373278574 [[],[]] .smaller = true := by decide
def e2422373278582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 1)))))))
theorem wire_e2422373278582 : Closed e2422373278582 ∧ code e2422373278582 = 11218466300790 := by decide
theorem cert_e2422373278582 : check e2422373278582 [[],[]] .smaller = true := by decide
def e2422373278586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))) (.var 0)))))))
theorem wire_e2422373278586 : Closed e2422373278586 ∧ code e2422373278586 = 11218466300794 := by decide
theorem cert_e2422373278586 : check e2422373278586 [[],[]] .three = true := by decide
def e2422373278638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))) (.var 2)))))))
theorem wire_e2422373278638 : Closed e2422373278638 ∧ code e2422373278638 = 11218466300846 := by decide
theorem cert_e2422373278638 : check e2422373278638 [[],[]] .smaller = true := by decide
def e2422373278650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))) (.var 0)))))))
theorem wire_e2422373278650 : Closed e2422373278650 ∧ code e2422373278650 = 11218466300858 := by decide
theorem cert_e2422373278650 : check e2422373278650 [[],[]] .smaller = true := by decide
def e2422373278678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 1)))))))
theorem wire_e2422373278678 : Closed e2422373278678 ∧ code e2422373278678 = 11218466300886 := by decide
theorem cert_e2422373278678 : check e2422373278678 [[],[]] .smaller = true := by decide
def e2422373278682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))) (.var 0)))))))
theorem wire_e2422373278682 : Closed e2422373278682 ∧ code e2422373278682 = 11218466300890 := by decide
theorem cert_e2422373278682 : check e2422373278682 [[],[]] .smaller = true := by decide
def e2422373278698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))) (.var 0)))))))
theorem wire_e2422373278698 : Closed e2422373278698 ∧ code e2422373278698 = 11218466300906 := by decide
theorem cert_e2422373278698 : check e2422373278698 [[],[]] .three = true := by decide
def e2422373279406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e2422373279406 : Closed e2422373279406 ∧ code e2422373279406 = 11218466301614 := by decide
theorem cert_e2422373279406 : check e2422373279406 [[],[]] .smaller = true := by decide
def e2422373279418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e2422373279418 : Closed e2422373279418 ∧ code e2422373279418 = 11218466301626 := by decide
theorem cert_e2422373279418 : check e2422373279418 [[],[]] .smaller = true := by decide
def e2422373279466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.var 0)))))))
theorem wire_e2422373279466 : Closed e2422373279466 ∧ code e2422373279466 = 11218466301674 := by decide
theorem cert_e2422373279466 : check e2422373279466 [[],[]] .smaller = true := by decide
def e2422373279658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e2422373279658 : Closed e2422373279658 ∧ code e2422373279658 = 11218466301866 := by decide
theorem cert_e2422373279658 : check e2422373279658 [[],[]] .smaller = true := by decide
def e2422373279790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373279790 : Closed e2422373279790 ∧ code e2422373279790 = 11218466301998 := by decide
theorem cert_e2422373279790 : check e2422373279790 [[],[]] .smaller = true := by decide
def e2422373279966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2422373279966 : Closed e2422373279966 ∧ code e2422373279966 = 11218466302174 := by decide
theorem cert_e2422373279966 : check e2422373279966 [[],[]] .three = true := by decide
def e2422373279982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422373279982 : Closed e2422373279982 ∧ code e2422373279982 = 11218466302190 := by decide
theorem cert_e2422373279982 : check e2422373279982 [[],[]] .smaller = true := by decide
def e2422373279990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422373279990 : Closed e2422373279990 ∧ code e2422373279990 = 11218466302198 := by decide
theorem cert_e2422373279990 : check e2422373279990 [[],[]] .smaller = true := by decide
def e2422373279994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422373279994 : Closed e2422373279994 ∧ code e2422373279994 = 11218466302202 := by decide
theorem cert_e2422373279994 : check e2422373279994 [[],[]] .three = true := by decide
def e2422373280174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422373280174 : Closed e2422373280174 ∧ code e2422373280174 = 11218466302382 := by decide
theorem cert_e2422373280174 : check e2422373280174 [[],[]] .smaller = true := by decide
def e2422373280186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422373280186 : Closed e2422373280186 ∧ code e2422373280186 = 11218466302394 := by decide
theorem cert_e2422373280186 : check e2422373280186 [[],[]] .smaller = true := by decide
def e2422373280234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422373280234 : Closed e2422373280234 ∧ code e2422373280234 = 11218466302442 := by decide
theorem cert_e2422373280234 : check e2422373280234 [[],[]] .smaller = true := by decide
def e2422373280318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2422373280318 : Closed e2422373280318 ∧ code e2422373280318 = 11218466302526 := by decide
theorem cert_e2422373280318 : check e2422373280318 [[],[]] .three = true := by decide
def e2422373280366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373280366 : Closed e2422373280366 ∧ code e2422373280366 = 11218466302574 := by decide
theorem cert_e2422373280366 : check e2422373280366 [[],[]] .smaller = true := by decide
def e2422373280378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373280378 : Closed e2422373280378 ∧ code e2422373280378 = 11218466302586 := by decide
theorem cert_e2422373280378 : check e2422373280378 [[],[]] .smaller = true := by decide
def e2422373280542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422373280542 : Closed e2422373280542 ∧ code e2422373280542 = 11218466302750 := by decide
theorem cert_e2422373280542 : check e2422373280542 [[],[]] .smaller = true := by decide
def e2422373280642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373280642 : Closed e2422373280642 ∧ code e2422373280642 = 11218466302850 := by decide
theorem cert_e2422373280642 : check e2422373280642 [[],[]] .smaller = true := by decide
def e2422373280654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422373280654 : Closed e2422373280654 ∧ code e2422373280654 = 11218466302862 := by decide
theorem cert_e2422373280654 : check e2422373280654 [[],[]] .smaller = true := by decide
def e2422373280666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373280666 : Closed e2422373280666 ∧ code e2422373280666 = 11218466302874 := by decide
theorem cert_e2422373280666 : check e2422373280666 [[],[]] .smaller = true := by decide
def e2422373280710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422373280710 : Closed e2422373280710 ∧ code e2422373280710 = 11218466302918 := by decide
theorem cert_e2422373280710 : check e2422373280710 [[],[]] .three = true := by decide
def e2422373280734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 3)))))))
theorem wire_e2422373280734 : Closed e2422373280734 ∧ code e2422373280734 = 11218466302942 := by decide
theorem cert_e2422373280734 : check e2422373280734 [[],[]] .three = true := by decide
def e2422373280862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422373280862 : Closed e2422373280862 ∧ code e2422373280862 = 11218466303070 := by decide
theorem cert_e2422373280862 : check e2422373280862 [[],[]] .three = true := by decide
def e2422373280878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2422373280878 : Closed e2422373280878 ∧ code e2422373280878 = 11218466303086 := by decide
theorem cert_e2422373280878 : check e2422373280878 [[],[]] .smaller = true := by decide
end Blc.Floor43
