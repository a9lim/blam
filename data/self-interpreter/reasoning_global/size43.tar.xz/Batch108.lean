import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e862483893366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e862483893366 : Closed e862483893366 ∧ code e862483893366 = 9658576915574 := by decide
theorem cert_e862483893366 : check e862483893366 [] .sourceHead = true := by decide
def e862483893462 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e862483893462 : Closed e862483893462 ∧ code e862483893462 = 9658576915670 := by decide
theorem cert_e862483893462 : check e862483893462 [] .sourceHead = true := by decide
def e862483893466 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e862483893466 : Closed e862483893466 ∧ code e862483893466 = 9658576915674 := by decide
theorem cert_e862483893466 : check e862483893466 [] .sourceHead = true := by decide
def e862483893482 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e862483893482 : Closed e862483893482 ∧ code e862483893482 = 9658576915690 := by decide
theorem cert_e862483893482 : check e862483893482 [] .sourceHead = true := by decide
def e862483893558 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e862483893558 : Closed e862483893558 ∧ code e862483893558 = 9658576915766 := by decide
theorem cert_e862483893558 : check e862483893558 [] .sourceHead = true := by decide
def e862483893562 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e862483893562 : Closed e862483893562 ∧ code e862483893562 = 9658576915770 := by decide
theorem cert_e862483893562 : check e862483893562 [] .sourceHead = true := by decide
def e862483893646 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e862483893646 : Closed e862483893646 ∧ code e862483893646 = 9658576915854 := by decide
theorem cert_e862483893646 : check e862483893646 [] .sourceHead = true := by decide
def e862483893658 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483893658 : Closed e862483893658 ∧ code e862483893658 = 9658576915866 := by decide
theorem cert_e862483893658 : check e862483893658 [] .sourceHead = true := by decide
def e862483893814 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e862483893814 : Closed e862483893814 ∧ code e862483893814 = 9658576916022 := by decide
theorem cert_e862483893814 : check e862483893814 [] .sourceHead = true := by decide
def e862483893818 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e862483893818 : Closed e862483893818 ∧ code e862483893818 = 9658576916026 := by decide
theorem cert_e862483893818 : check e862483893818 [] .sourceHead = true := by decide
def e862483893866 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e862483893866 : Closed e862483893866 ∧ code e862483893866 = 9658576916074 := by decide
theorem cert_e862483893866 : check e862483893866 [] .sourceHead = true := by decide
def e862483893902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e862483893902 : Closed e862483893902 ∧ code e862483893902 = 9658576916110 := by decide
theorem cert_e862483893902 : check e862483893902 [] .sourceHead = true := by decide
def e862483893914 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e862483893914 : Closed e862483893914 ∧ code e862483893914 = 9658576916122 := by decide
theorem cert_e862483893914 : check e862483893914 [] .sourceHead = true := by decide
def e862483893958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e862483893958 : Closed e862483893958 ∧ code e862483893958 = 9658576916166 := by decide
theorem cert_e862483893958 : check e862483893958 [] .sourceHead = true := by decide
def e862483894510 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e862483894510 : Closed e862483894510 ∧ code e862483894510 = 9658576916718 := by decide
theorem cert_e862483894510 : check e862483894510 [] .sourceHead = true := by decide
def e862483894518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e862483894518 : Closed e862483894518 ∧ code e862483894518 = 9658576916726 := by decide
theorem cert_e862483894518 : check e862483894518 [] .sourceHead = true := by decide
def e862483894998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e862483894998 : Closed e862483894998 ∧ code e862483894998 = 9658576917206 := by decide
theorem cert_e862483894998 : check e862483894998 [] .sourceHead = true := by decide
def e862483895002 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e862483895002 : Closed e862483895002 ∧ code e862483895002 = 9658576917210 := by decide
theorem cert_e862483895002 : check e862483895002 [] .sourceHead = true := by decide
def e862483895018 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e862483895018 : Closed e862483895018 ∧ code e862483895018 = 9658576917226 := by decide
theorem cert_e862483895018 : check e862483895018 [] .sourceHead = true := by decide
def e862483895094 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e862483895094 : Closed e862483895094 ∧ code e862483895094 = 9658576917302 := by decide
theorem cert_e862483895094 : check e862483895094 [] .sourceHead = true := by decide
def e862483895098 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e862483895098 : Closed e862483895098 ∧ code e862483895098 = 9658576917306 := by decide
theorem cert_e862483895098 : check e862483895098 [] .sourceHead = true := by decide
def e862483895182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e862483895182 : Closed e862483895182 ∧ code e862483895182 = 9658576917390 := by decide
theorem cert_e862483895182 : check e862483895182 [] .sourceHead = true := by decide
def e862483895194 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483895194 : Closed e862483895194 ∧ code e862483895194 = 9658576917402 := by decide
theorem cert_e862483895194 : check e862483895194 [] .sourceHead = true := by decide
def e862483896438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e862483896438 : Closed e862483896438 ∧ code e862483896438 = 9658576918646 := by decide
theorem cert_e862483896438 : check e862483896438 [] .sourceHead = true := by decide
def e862483896682 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e862483896682 : Closed e862483896682 ∧ code e862483896682 = 9658576918890 := by decide
theorem cert_e862483896682 : check e862483896682 [] .sourceHead = true := by decide
def e862483896718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e862483896718 : Closed e862483896718 ∧ code e862483896718 = 9658576918926 := by decide
theorem cert_e862483896718 : check e862483896718 [] .sourceHead = true := by decide
def e862483896730 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483896730 : Closed e862483896730 ∧ code e862483896730 = 9658576918938 := by decide
theorem cert_e862483896730 : check e862483896730 [] .sourceHead = true := by decide
def e862483896774 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e862483896774 : Closed e862483896774 ∧ code e862483896774 = 9658576918982 := by decide
theorem cert_e862483896774 : check e862483896774 [] .sourceHead = true := by decide
def e862483909486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e862483909486 : Closed e862483909486 ∧ code e862483909486 = 9658576931694 := by decide
theorem cert_e862483909486 : check e862483909486 [] .sourceHead = true := by decide
def e862483909494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e862483909494 : Closed e862483909494 ∧ code e862483909494 = 9658576931702 := by decide
theorem cert_e862483909494 : check e862483909494 [] .sourceHead = true := by decide
def e862483909550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e862483909550 : Closed e862483909550 ∧ code e862483909550 = 9658576931758 := by decide
theorem cert_e862483909550 : check e862483909550 [] .sourceHead = true := by decide
def e862483909562 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e862483909562 : Closed e862483909562 ∧ code e862483909562 = 9658576931770 := by decide
theorem cert_e862483909562 : check e862483909562 [] .sourceHead = true := by decide
def e862483909590 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e862483909590 : Closed e862483909590 ∧ code e862483909590 = 9658576931798 := by decide
theorem cert_e862483909590 : check e862483909590 [] .sourceHead = true := by decide
def e862483909594 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e862483909594 : Closed e862483909594 ∧ code e862483909594 = 9658576931802 := by decide
theorem cert_e862483909594 : check e862483909594 [] .sourceHead = true := by decide
def e862483909870 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e862483909870 : Closed e862483909870 ∧ code e862483909870 = 9658576932078 := by decide
theorem cert_e862483909870 : check e862483909870 [] .sourceHead = true := by decide
def e862483909878 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e862483909878 : Closed e862483909878 ∧ code e862483909878 = 9658576932086 := by decide
theorem cert_e862483909878 : check e862483909878 [] .sourceHead = true := by decide
def e862483910254 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e862483910254 : Closed e862483910254 ∧ code e862483910254 = 9658576932462 := by decide
theorem cert_e862483910254 : check e862483910254 [] .sourceHead = true := by decide
def e862483910266 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e862483910266 : Closed e862483910266 ∧ code e862483910266 = 9658576932474 := by decide
theorem cert_e862483910266 : check e862483910266 [] .sourceHead = true := by decide
def e862483910454 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e862483910454 : Closed e862483910454 ∧ code e862483910454 = 9658576932662 := by decide
theorem cert_e862483910454 : check e862483910454 [] .sourceHead = true := by decide
def e862483910458 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e862483910458 : Closed e862483910458 ∧ code e862483910458 = 9658576932666 := by decide
theorem cert_e862483910458 : check e862483910458 [] .sourceHead = true := by decide
def e862483950958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e862483950958 : Closed e862483950958 ∧ code e862483950958 = 9658576973166 := by decide
theorem cert_e862483950958 : check e862483950958 [] .sourceHead = true := by decide
def e862483950966 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e862483950966 : Closed e862483950966 ∧ code e862483950966 = 9658576973174 := by decide
theorem cert_e862483950966 : check e862483950966 [] .sourceHead = true := by decide
def e862483951022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e862483951022 : Closed e862483951022 ∧ code e862483951022 = 9658576973230 := by decide
theorem cert_e862483951022 : check e862483951022 [] .sourceHead = true := by decide
def e862483951034 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e862483951034 : Closed e862483951034 ∧ code e862483951034 = 9658576973242 := by decide
theorem cert_e862483951034 : check e862483951034 [] .sourceHead = true := by decide
def e862483951062 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e862483951062 : Closed e862483951062 ∧ code e862483951062 = 9658576973270 := by decide
theorem cert_e862483951062 : check e862483951062 [] .sourceHead = true := by decide
def e862483951066 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e862483951066 : Closed e862483951066 ∧ code e862483951066 = 9658576973274 := by decide
theorem cert_e862483951066 : check e862483951066 [] .sourceHead = true := by decide
def e862483951278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e862483951278 : Closed e862483951278 ∧ code e862483951278 = 9658576973486 := by decide
theorem cert_e862483951278 : check e862483951278 [] .sourceHead = true := by decide
def e862483951290 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e862483951290 : Closed e862483951290 ∧ code e862483951290 = 9658576973498 := by decide
theorem cert_e862483951290 : check e862483951290 [] .sourceHead = true := by decide
def e862483951338 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e862483951338 : Closed e862483951338 ∧ code e862483951338 = 9658576973546 := by decide
theorem cert_e862483951338 : check e862483951338 [] .sourceHead = true := by decide
def e862483951446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e862483951446 : Closed e862483951446 ∧ code e862483951446 = 9658576973654 := by decide
theorem cert_e862483951446 : check e862483951446 [] .sourceHead = true := by decide
def e862483951450 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e862483951450 : Closed e862483951450 ∧ code e862483951450 = 9658576973658 := by decide
theorem cert_e862483951450 : check e862483951450 [] .sourceHead = true := by decide
def e862483951466 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e862483951466 : Closed e862483951466 ∧ code e862483951466 = 9658576973674 := by decide
theorem cert_e862483951466 : check e862483951466 [] .sourceHead = true := by decide
def e862483952494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e862483952494 : Closed e862483952494 ∧ code e862483952494 = 9658576974702 := by decide
theorem cert_e862483952494 : check e862483952494 [] .sourceHead = true := by decide
def e862483952502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e862483952502 : Closed e862483952502 ∧ code e862483952502 = 9658576974710 := by decide
theorem cert_e862483952502 : check e862483952502 [] .sourceHead = true := by decide
def e862483952558 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e862483952558 : Closed e862483952558 ∧ code e862483952558 = 9658576974766 := by decide
theorem cert_e862483952558 : check e862483952558 [] .sourceHead = true := by decide
def e862483952570 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e862483952570 : Closed e862483952570 ∧ code e862483952570 = 9658576974778 := by decide
theorem cert_e862483952570 : check e862483952570 [] .sourceHead = true := by decide
def e862483952598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e862483952598 : Closed e862483952598 ∧ code e862483952598 = 9658576974806 := by decide
theorem cert_e862483952598 : check e862483952598 [] .sourceHead = true := by decide
def e862483952602 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e862483952602 : Closed e862483952602 ∧ code e862483952602 = 9658576974810 := by decide
theorem cert_e862483952602 : check e862483952602 [] .sourceHead = true := by decide
def e862483952878 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e862483952878 : Closed e862483952878 ∧ code e862483952878 = 9658576975086 := by decide
theorem cert_e862483952878 : check e862483952878 [] .sourceHead = true := by decide
def e862483952886 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e862483952886 : Closed e862483952886 ∧ code e862483952886 = 9658576975094 := by decide
theorem cert_e862483952886 : check e862483952886 [] .sourceHead = true := by decide
def e862483953262 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862483953262 : Closed e862483953262 ∧ code e862483953262 = 9658576975470 := by decide
theorem cert_e862483953262 : check e862483953262 [] .sourceHead = true := by decide
def e862483953274 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862483953274 : Closed e862483953274 ∧ code e862483953274 = 9658576975482 := by decide
theorem cert_e862483953274 : check e862483953274 [] .sourceHead = true := by decide
def e862483953462 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862483953462 : Closed e862483953462 ∧ code e862483953462 = 9658576975670 := by decide
theorem cert_e862483953462 : check e862483953462 [] .sourceHead = true := by decide
def e862483953466 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862483953466 : Closed e862483953466 ∧ code e862483953466 = 9658576975674 := by decide
theorem cert_e862483953466 : check e862483953466 [] .sourceHead = true := by decide
def e862483953902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e862483953902 : Closed e862483953902 ∧ code e862483953902 = 9658576976110 := by decide
theorem cert_e862483953902 : check e862483953902 [] .sourceHead = true := by decide
def e862483953910 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e862483953910 : Closed e862483953910 ∧ code e862483953910 = 9658576976118 := by decide
theorem cert_e862483953910 : check e862483953910 [] .sourceHead = true := by decide
def e862483954094 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e862483954094 : Closed e862483954094 ∧ code e862483954094 = 9658576976302 := by decide
theorem cert_e862483954094 : check e862483954094 [] .sourceHead = true := by decide
def e862483954106 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e862483954106 : Closed e862483954106 ∧ code e862483954106 = 9658576976314 := by decide
theorem cert_e862483954106 : check e862483954106 [] .sourceHead = true := by decide
def e862483954154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e862483954154 : Closed e862483954154 ∧ code e862483954154 = 9658576976362 := by decide
theorem cert_e862483954154 : check e862483954154 [] .sourceHead = true := by decide
def e862483954286 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862483954286 : Closed e862483954286 ∧ code e862483954286 = 9658576976494 := by decide
theorem cert_e862483954286 : check e862483954286 [] .sourceHead = true := by decide
def e862483954298 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862483954298 : Closed e862483954298 ∧ code e862483954298 = 9658576976506 := by decide
theorem cert_e862483954298 : check e862483954298 [] .sourceHead = true := by decide
def e862483954462 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e862483954462 : Closed e862483954462 ∧ code e862483954462 = 9658576976670 := by decide
theorem cert_e862483954462 : check e862483954462 [] .sourceHead = true := by decide
def e862483954574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e862483954574 : Closed e862483954574 ∧ code e862483954574 = 9658576976782 := by decide
theorem cert_e862483954574 : check e862483954574 [] .sourceHead = true := by decide
def e862483954586 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483954586 : Closed e862483954586 ∧ code e862483954586 = 9658576976794 := by decide
theorem cert_e862483954586 : check e862483954586 [] .sourceHead = true := by decide
def e862483954806 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e862483954806 : Closed e862483954806 ∧ code e862483954806 = 9658576977014 := by decide
theorem cert_e862483954806 : check e862483954806 [] .sourceHead = true := by decide
def e862483954902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e862483954902 : Closed e862483954902 ∧ code e862483954902 = 9658576977110 := by decide
theorem cert_e862483954902 : check e862483954902 [] .sourceHead = true := by decide
def e862483954906 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e862483954906 : Closed e862483954906 ∧ code e862483954906 = 9658576977114 := by decide
theorem cert_e862483954906 : check e862483954906 [] .sourceHead = true := by decide
def e862483954922 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e862483954922 : Closed e862483954922 ∧ code e862483954922 = 9658576977130 := by decide
theorem cert_e862483954922 : check e862483954922 [] .sourceHead = true := by decide
def e862483954998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862483954998 : Closed e862483954998 ∧ code e862483954998 = 9658576977206 := by decide
theorem cert_e862483954998 : check e862483954998 [] .sourceHead = true := by decide
def e862483955002 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862483955002 : Closed e862483955002 ∧ code e862483955002 = 9658576977210 := by decide
theorem cert_e862483955002 : check e862483955002 [] .sourceHead = true := by decide
def e862483955086 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e862483955086 : Closed e862483955086 ∧ code e862483955086 = 9658576977294 := by decide
theorem cert_e862483955086 : check e862483955086 [] .sourceHead = true := by decide
def e862483955098 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483955098 : Closed e862483955098 ∧ code e862483955098 = 9658576977306 := by decide
theorem cert_e862483955098 : check e862483955098 [] .sourceHead = true := by decide
def e862483956702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e862483956702 : Closed e862483956702 ∧ code e862483956702 = 9658576978910 := by decide
theorem cert_e862483956702 : check e862483956702 [] .sourceHead = true := by decide
def e862483956718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e862483956718 : Closed e862483956718 ∧ code e862483956718 = 9658576978926 := by decide
theorem cert_e862483956718 : check e862483956718 [] .sourceHead = true := by decide
def e862483958638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862483958638 : Closed e862483958638 ∧ code e862483958638 = 9658576980846 := by decide
theorem cert_e862483958638 : check e862483958638 [] .sourceHead = true := by decide
def e862483958646 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862483958646 : Closed e862483958646 ∧ code e862483958646 = 9658576980854 := by decide
theorem cert_e862483958646 : check e862483958646 [] .sourceHead = true := by decide
def e862483958702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862483958702 : Closed e862483958702 ∧ code e862483958702 = 9658576980910 := by decide
theorem cert_e862483958702 : check e862483958702 [] .sourceHead = true := by decide
def e862483958714 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862483958714 : Closed e862483958714 ∧ code e862483958714 = 9658576980922 := by decide
theorem cert_e862483958714 : check e862483958714 [] .sourceHead = true := by decide
def e862483958742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862483958742 : Closed e862483958742 ∧ code e862483958742 = 9658576980950 := by decide
theorem cert_e862483958742 : check e862483958742 [] .sourceHead = true := by decide
def e862483958746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862483958746 : Closed e862483958746 ∧ code e862483958746 = 9658576980954 := by decide
theorem cert_e862483958746 : check e862483958746 [] .sourceHead = true := by decide
def e862483959022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862483959022 : Closed e862483959022 ∧ code e862483959022 = 9658576981230 := by decide
theorem cert_e862483959022 : check e862483959022 [] .sourceHead = true := by decide
def e862483959030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862483959030 : Closed e862483959030 ∧ code e862483959030 = 9658576981238 := by decide
theorem cert_e862483959030 : check e862483959030 [] .sourceHead = true := by decide
def e862483959406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862483959406 : Closed e862483959406 ∧ code e862483959406 = 9658576981614 := by decide
theorem cert_e862483959406 : check e862483959406 [] .sourceHead = true := by decide
def e862483959418 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862483959418 : Closed e862483959418 ∧ code e862483959418 = 9658576981626 := by decide
theorem cert_e862483959418 : check e862483959418 [] .sourceHead = true := by decide
def e862483959606 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862483959606 : Closed e862483959606 ∧ code e862483959606 = 9658576981814 := by decide
theorem cert_e862483959606 : check e862483959606 [] .sourceHead = true := by decide
def e862483959610 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862483959610 : Closed e862483959610 ∧ code e862483959610 = 9658576981818 := by decide
theorem cert_e862483959610 : check e862483959610 [] .sourceHead = true := by decide
def e862483964382 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e862483964382 : Closed e862483964382 ∧ code e862483964382 = 9658576986590 := by decide
theorem cert_e862483964382 : check e862483964382 [] .sourceHead = true := by decide
def e862483964406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e862483964406 : Closed e862483964406 ∧ code e862483964406 = 9658576986614 := by decide
theorem cert_e862483964406 : check e862483964406 [] .sourceHead = true := by decide
def e862483965358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e862483965358 : Closed e862483965358 ∧ code e862483965358 = 9658576987566 := by decide
theorem cert_e862483965358 : check e862483965358 [] .sourceHead = true := by decide
def e862483965370 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e862483965370 : Closed e862483965370 ∧ code e862483965370 = 9658576987578 := by decide
theorem cert_e862483965370 : check e862483965370 [] .sourceHead = true := by decide
def e862483965418 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e862483965418 : Closed e862483965418 ∧ code e862483965418 = 9658576987626 := by decide
theorem cert_e862483965418 : check e862483965418 [] .sourceHead = true := by decide
def e862483965550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862483965550 : Closed e862483965550 ∧ code e862483965550 = 9658576987758 := by decide
theorem cert_e862483965550 : check e862483965550 [] .sourceHead = true := by decide
def e862483965562 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862483965562 : Closed e862483965562 ∧ code e862483965562 = 9658576987770 := by decide
theorem cert_e862483965562 : check e862483965562 [] .sourceHead = true := by decide
def e862483965726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e862483965726 : Closed e862483965726 ∧ code e862483965726 = 9658576987934 := by decide
theorem cert_e862483965726 : check e862483965726 [] .sourceHead = true := by decide
def e862483965838 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e862483965838 : Closed e862483965838 ∧ code e862483965838 = 9658576988046 := by decide
theorem cert_e862483965838 : check e862483965838 [] .sourceHead = true := by decide
def e862483965850 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862483965850 : Closed e862483965850 ∧ code e862483965850 = 9658576988058 := by decide
theorem cert_e862483965850 : check e862483965850 [] .sourceHead = true := by decide
def e862483968238 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e862483968238 : Closed e862483968238 ∧ code e862483968238 = 9658576990446 := by decide
theorem cert_e862483968238 : check e862483968238 [] .sourceHead = true := by decide
def e862483968246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e862483968246 : Closed e862483968246 ∧ code e862483968246 = 9658576990454 := by decide
theorem cert_e862483968246 : check e862483968246 [] .sourceHead = true := by decide
def e862483968726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e862483968726 : Closed e862483968726 ∧ code e862483968726 = 9658576990934 := by decide
theorem cert_e862483968726 : check e862483968726 [] .sourceHead = true := by decide
def e862483968730 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e862483968730 : Closed e862483968730 ∧ code e862483968730 = 9658576990938 := by decide
theorem cert_e862483968730 : check e862483968730 [] .sourceHead = true := by decide
def e862483968746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e862483968746 : Closed e862483968746 ∧ code e862483968746 = 9658576990954 := by decide
theorem cert_e862483968746 : check e862483968746 [] .sourceHead = true := by decide
def e862483968822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862483968822 : Closed e862483968822 ∧ code e862483968822 = 9658576991030 := by decide
theorem cert_e862483968822 : check e862483968822 [] .sourceHead = true := by decide
def e862483968826 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862483968826 : Closed e862483968826 ∧ code e862483968826 = 9658576991034 := by decide
theorem cert_e862483968826 : check e862483968826 [] .sourceHead = true := by decide
def e862483968910 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e862483968910 : Closed e862483968910 ∧ code e862483968910 = 9658576991118 := by decide
theorem cert_e862483968910 : check e862483968910 [] .sourceHead = true := by decide
def e862483968922 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862483968922 : Closed e862483968922 ∧ code e862483968922 = 9658576991130 := by decide
theorem cert_e862483968922 : check e862483968922 [] .sourceHead = true := by decide
def e862484059822 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e862484059822 : Closed e862484059822 ∧ code e862484059822 = 9658577082030 := by decide
theorem cert_e862484059822 : check e862484059822 [] .sourceHead = true := by decide
def e862484059834 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e862484059834 : Closed e862484059834 ∧ code e862484059834 = 9658577082042 := by decide
theorem cert_e862484059834 : check e862484059834 [] .sourceHead = true := by decide
def e862484059882 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e862484059882 : Closed e862484059882 ∧ code e862484059882 = 9658577082090 := by decide
theorem cert_e862484059882 : check e862484059882 [] .sourceHead = true := by decide
def e862484060074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e862484060074 : Closed e862484060074 ∧ code e862484060074 = 9658577082282 := by decide
theorem cert_e862484060074 : check e862484060074 [] .sourceHead = true := by decide
def e862484060398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e862484060398 : Closed e862484060398 ∧ code e862484060398 = 9658577082606 := by decide
theorem cert_e862484060398 : check e862484060398 [] .sourceHead = true := by decide
def e862484060406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e862484060406 : Closed e862484060406 ∧ code e862484060406 = 9658577082614 := by decide
theorem cert_e862484060406 : check e862484060406 [] .sourceHead = true := by decide
def e862484060590 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e862484060590 : Closed e862484060590 ∧ code e862484060590 = 9658577082798 := by decide
theorem cert_e862484060590 : check e862484060590 [] .sourceHead = true := by decide
def e862484060602 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e862484060602 : Closed e862484060602 ∧ code e862484060602 = 9658577082810 := by decide
theorem cert_e862484060602 : check e862484060602 [] .sourceHead = true := by decide
def e862484060650 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e862484060650 : Closed e862484060650 ∧ code e862484060650 = 9658577082858 := by decide
theorem cert_e862484060650 : check e862484060650 [] .sourceHead = true := by decide
def e862484060782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862484060782 : Closed e862484060782 ∧ code e862484060782 = 9658577082990 := by decide
theorem cert_e862484060782 : check e862484060782 [] .sourceHead = true := by decide
def e862484060794 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862484060794 : Closed e862484060794 ∧ code e862484060794 = 9658577083002 := by decide
theorem cert_e862484060794 : check e862484060794 [] .sourceHead = true := by decide
def e862484060958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e862484060958 : Closed e862484060958 ∧ code e862484060958 = 9658577083166 := by decide
theorem cert_e862484060958 : check e862484060958 [] .sourceHead = true := by decide
def e862484061070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e862484061070 : Closed e862484061070 ∧ code e862484061070 = 9658577083278 := by decide
theorem cert_e862484061070 : check e862484061070 [] .sourceHead = true := by decide
def e862484061082 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862484061082 : Closed e862484061082 ∧ code e862484061082 = 9658577083290 := by decide
theorem cert_e862484061082 : check e862484061082 [] .sourceHead = true := by decide
def e862484061294 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e862484061294 : Closed e862484061294 ∧ code e862484061294 = 9658577083502 := by decide
theorem cert_e862484061294 : check e862484061294 [] .sourceHead = true := by decide
def e862484061306 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e862484061306 : Closed e862484061306 ∧ code e862484061306 = 9658577083514 := by decide
theorem cert_e862484061306 : check e862484061306 [] .sourceHead = true := by decide
def e862484061470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e862484061470 : Closed e862484061470 ∧ code e862484061470 = 9658577083678 := by decide
theorem cert_e862484061470 : check e862484061470 [] .sourceHead = true := by decide
def e862484061638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e862484061638 : Closed e862484061638 ∧ code e862484061638 = 9658577083846 := by decide
theorem cert_e862484061638 : check e862484061638 [] .sourceHead = true := by decide
def e862484061750 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e862484061750 : Closed e862484061750 ∧ code e862484061750 = 9658577083958 := by decide
theorem cert_e862484061750 : check e862484061750 [] .sourceHead = true := by decide
def e862484061754 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e862484061754 : Closed e862484061754 ∧ code e862484061754 = 9658577083962 := by decide
theorem cert_e862484061754 : check e862484061754 [] .sourceHead = true := by decide
def e862484061802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e862484061802 : Closed e862484061802 ∧ code e862484061802 = 9658577084010 := by decide
theorem cert_e862484061802 : check e862484061802 [] .sourceHead = true := by decide
def e862484061838 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e862484061838 : Closed e862484061838 ∧ code e862484061838 = 9658577084046 := by decide
theorem cert_e862484061838 : check e862484061838 [] .sourceHead = true := by decide
def e862484061850 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862484061850 : Closed e862484061850 ∧ code e862484061850 = 9658577084058 := by decide
theorem cert_e862484061850 : check e862484061850 [] .sourceHead = true := by decide
def e862484061894 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e862484061894 : Closed e862484061894 ∧ code e862484061894 = 9658577084102 := by decide
theorem cert_e862484061894 : check e862484061894 [] .sourceHead = true := by decide
def e862484062686 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e862484062686 : Closed e862484062686 ∧ code e862484062686 = 9658577084894 := by decide
theorem cert_e862484062686 : check e862484062686 [] .sourceHead = true := by decide
def e862484062710 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e862484062710 : Closed e862484062710 ∧ code e862484062710 = 9658577084918 := by decide
theorem cert_e862484062710 : check e862484062710 [] .sourceHead = true := by decide
def e862484063662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e862484063662 : Closed e862484063662 ∧ code e862484063662 = 9658577085870 := by decide
theorem cert_e862484063662 : check e862484063662 [] .sourceHead = true := by decide
def e862484063674 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e862484063674 : Closed e862484063674 ∧ code e862484063674 = 9658577085882 := by decide
theorem cert_e862484063674 : check e862484063674 [] .sourceHead = true := by decide
def e862484063722 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e862484063722 : Closed e862484063722 ∧ code e862484063722 = 9658577085930 := by decide
theorem cert_e862484063722 : check e862484063722 [] .sourceHead = true := by decide
def e862484063854 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862484063854 : Closed e862484063854 ∧ code e862484063854 = 9658577086062 := by decide
theorem cert_e862484063854 : check e862484063854 [] .sourceHead = true := by decide
def e862484063866 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862484063866 : Closed e862484063866 ∧ code e862484063866 = 9658577086074 := by decide
theorem cert_e862484063866 : check e862484063866 [] .sourceHead = true := by decide
def e862484064030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e862484064030 : Closed e862484064030 ∧ code e862484064030 = 9658577086238 := by decide
theorem cert_e862484064030 : check e862484064030 [] .sourceHead = true := by decide
def e862484064142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e862484064142 : Closed e862484064142 ∧ code e862484064142 = 9658577086350 := by decide
theorem cert_e862484064142 : check e862484064142 [] .sourceHead = true := by decide
def e862484064154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862484064154 : Closed e862484064154 ∧ code e862484064154 = 9658577086362 := by decide
theorem cert_e862484064154 : check e862484064154 [] .sourceHead = true := by decide
def e862484067102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e862484067102 : Closed e862484067102 ∧ code e862484067102 = 9658577089310 := by decide
theorem cert_e862484067102 : check e862484067102 [] .sourceHead = true := by decide
def e862484067270 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e862484067270 : Closed e862484067270 ∧ code e862484067270 = 9658577089478 := by decide
theorem cert_e862484067270 : check e862484067270 [] .sourceHead = true := by decide
def e862484068470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e862484068470 : Closed e862484068470 ∧ code e862484068470 = 9658577090678 := by decide
theorem cert_e862484068470 : check e862484068470 [] .sourceHead = true := by decide
def e862484068714 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e862484068714 : Closed e862484068714 ∧ code e862484068714 = 9658577090922 := by decide
theorem cert_e862484068714 : check e862484068714 [] .sourceHead = true := by decide
def e862484068750 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e862484068750 : Closed e862484068750 ∧ code e862484068750 = 9658577090958 := by decide
theorem cert_e862484068750 : check e862484068750 [] .sourceHead = true := by decide
def e862484068762 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862484068762 : Closed e862484068762 ∧ code e862484068762 = 9658577090970 := by decide
theorem cert_e862484068762 : check e862484068762 [] .sourceHead = true := by decide
def e862484068806 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e862484068806 : Closed e862484068806 ∧ code e862484068806 = 9658577091014 := by decide
theorem cert_e862484068806 : check e862484068806 [] .sourceHead = true := by decide
def e862484114262 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e862484114262 : Closed e862484114262 ∧ code e862484114262 = 9658577136470 := by decide
theorem cert_e862484114262 : check e862484114262 [] .sourceHead = true := by decide
def e862484114266 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e862484114266 : Closed e862484114266 ∧ code e862484114266 = 9658577136474 := by decide
theorem cert_e862484114266 : check e862484114266 [] .sourceHead = true := by decide
def e862484114282 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e862484114282 : Closed e862484114282 ∧ code e862484114282 = 9658577136490 := by decide
theorem cert_e862484114282 : check e862484114282 [] .sourceHead = true := by decide
def e862484114346 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e862484114346 : Closed e862484114346 ∧ code e862484114346 = 9658577136554 := by decide
theorem cert_e862484114346 : check e862484114346 [] .sourceHead = true := by decide
end Blc.Floor43
