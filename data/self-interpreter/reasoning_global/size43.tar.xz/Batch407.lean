import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373060294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422373060294 : Closed e2422373060294 ∧ code e2422373060294 = 11218466082502 := by decide
theorem cert_e2422373060294 : check e2422373060294 [[],[]] .three = true := by decide
def e2422373060334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 2)) (.var 2)))))))
theorem wire_e2422373060334 : Closed e2422373060334 ∧ code e2422373060334 = 11218466082542 := by decide
theorem cert_e2422373060334 : check e2422373060334 [[],[]] .three = true := by decide
def e2422373060378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422373060378 : Closed e2422373060378 ∧ code e2422373060378 = 11218466082586 := by decide
theorem cert_e2422373060378 : check e2422373060378 [[],[]] .three = true := by decide
def e2422373060422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422373060422 : Closed e2422373060422 ∧ code e2422373060422 = 11218466082630 := by decide
theorem cert_e2422373060422 : check e2422373060422 [[],[]] .three = true := by decide
def e2422373060446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 0)) (.var 3)))))))
theorem wire_e2422373060446 : Closed e2422373060446 ∧ code e2422373060446 = 11218466082654 := by decide
theorem cert_e2422373060446 : check e2422373060446 [[],[]] .three = true := by decide
def e2422373060462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e2422373060462 : Closed e2422373060462 ∧ code e2422373060462 = 11218466082670 := by decide
theorem cert_e2422373060462 : check e2422373060462 [[],[]] .three = true := by decide
def e2422373060470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e2422373060470 : Closed e2422373060470 ∧ code e2422373060470 = 11218466082678 := by decide
theorem cert_e2422373060470 : check e2422373060470 [[],[]] .three = true := by decide
def e2422373060474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 3))) (.var 3)) (.var 0)))))))
theorem wire_e2422373060474 : Closed e2422373060474 ∧ code e2422373060474 = 11218466082682 := by decide
theorem cert_e2422373060474 : check e2422373060474 [[],[]] .three = true := by decide
def e2422373060526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 4))) (.var 0)) (.var 2)))))))
theorem wire_e2422373060526 : Closed e2422373060526 ∧ code e2422373060526 = 11218466082734 := by decide
theorem cert_e2422373060526 : check e2422373060526 [[],[]] .three = true := by decide
def e2422373060538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.lam (.var 4))) (.var 2)) (.var 0)))))))
theorem wire_e2422373060538 : Closed e2422373060538 ∧ code e2422373060538 = 11218466082746 := by decide
theorem cert_e2422373060538 : check e2422373060538 [[],[]] .three = true := by decide
def e2422373062830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422373062830 : Closed e2422373062830 ∧ code e2422373062830 = 11218466085038 := by decide
theorem cert_e2422373062830 : check e2422373062830 [[],[]] .three = true := by decide
def e2422373062838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 1)))))))
theorem wire_e2422373062838 : Closed e2422373062838 ∧ code e2422373062838 = 11218466085046 := by decide
theorem cert_e2422373062838 : check e2422373062838 [[],[]] .three = true := by decide
def e2422373062842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422373062842 : Closed e2422373062842 ∧ code e2422373062842 = 11218466085050 := by decide
theorem cert_e2422373062842 : check e2422373062842 [[],[]] .three = true := by decide
def e2422373062870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373062870 : Closed e2422373062870 ∧ code e2422373062870 = 11218466085078 := by decide
theorem cert_e2422373062870 : check e2422373062870 [[],[]] .three = true := by decide
def e2422373062874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373062874 : Closed e2422373062874 ∧ code e2422373062874 = 11218466085082 := by decide
theorem cert_e2422373062874 : check e2422373062874 [[],[]] .three = true := by decide
def e2422373062890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373062890 : Closed e2422373062890 ∧ code e2422373062890 = 11218466085098 := by decide
theorem cert_e2422373062890 : check e2422373062890 [[],[]] .three = true := by decide
def e2422373063214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422373063214 : Closed e2422373063214 ∧ code e2422373063214 = 11218466085422 := by decide
theorem cert_e2422373063214 : check e2422373063214 [[],[]] .three = true := by decide
def e2422373063222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422373063222 : Closed e2422373063222 ∧ code e2422373063222 = 11218466085430 := by decide
theorem cert_e2422373063222 : check e2422373063222 [[],[]] .three = true := by decide
def e2422373063226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422373063226 : Closed e2422373063226 ∧ code e2422373063226 = 11218466085434 := by decide
theorem cert_e2422373063226 : check e2422373063226 [[],[]] .three = true := by decide
def e2422373063310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422373063310 : Closed e2422373063310 ∧ code e2422373063310 = 11218466085518 := by decide
theorem cert_e2422373063310 : check e2422373063310 [[],[]] .three = true := by decide
def e2422373063366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422373063366 : Closed e2422373063366 ∧ code e2422373063366 = 11218466085574 := by decide
theorem cert_e2422373063366 : check e2422373063366 [[],[]] .three = true := by decide
def e2422373063390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e2422373063390 : Closed e2422373063390 ∧ code e2422373063390 = 11218466085598 := by decide
theorem cert_e2422373063390 : check e2422373063390 [[],[]] .three = true := by decide
def e2422373063394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422373063394 : Closed e2422373063394 ∧ code e2422373063394 = 11218466085602 := by decide
theorem cert_e2422373063394 : check e2422373063394 [[],[]] .three = true := by decide
def e2422373063406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e2422373063406 : Closed e2422373063406 ∧ code e2422373063406 = 11218466085614 := by decide
theorem cert_e2422373063406 : check e2422373063406 [[],[]] .three = true := by decide
def e2422373063414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e2422373063414 : Closed e2422373063414 ∧ code e2422373063414 = 11218466085622 := by decide
theorem cert_e2422373063414 : check e2422373063414 [[],[]] .three = true := by decide
def e2422373063446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422373063446 : Closed e2422373063446 ∧ code e2422373063446 = 11218466085654 := by decide
theorem cert_e2422373063446 : check e2422373063446 [[],[]] .three = true := by decide
def e2422373063450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422373063450 : Closed e2422373063450 ∧ code e2422373063450 = 11218466085658 := by decide
theorem cert_e2422373063450 : check e2422373063450 [[],[]] .three = true := by decide
def e2422373063494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422373063494 : Closed e2422373063494 ∧ code e2422373063494 = 11218466085702 := by decide
theorem cert_e2422373063494 : check e2422373063494 [[],[]] .three = true := by decide
def e2422373063518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2422373063518 : Closed e2422373063518 ∧ code e2422373063518 = 11218466085726 := by decide
theorem cert_e2422373063518 : check e2422373063518 [[],[]] .three = true := by decide
def e2422373063522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422373063522 : Closed e2422373063522 ∧ code e2422373063522 = 11218466085730 := by decide
theorem cert_e2422373063522 : check e2422373063522 [[],[]] .three = true := by decide
def e2422373063534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2422373063534 : Closed e2422373063534 ∧ code e2422373063534 = 11218466085742 := by decide
theorem cert_e2422373063534 : check e2422373063534 [[],[]] .three = true := by decide
def e2422373063542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2422373063542 : Closed e2422373063542 ∧ code e2422373063542 = 11218466085750 := by decide
theorem cert_e2422373063542 : check e2422373063542 [[],[]] .three = true := by decide
def e2422373063546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2422373063546 : Closed e2422373063546 ∧ code e2422373063546 = 11218466085754 := by decide
theorem cert_e2422373063546 : check e2422373063546 [[],[]] .three = true := by decide
def e2422373063562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422373063562 : Closed e2422373063562 ∧ code e2422373063562 = 11218466085770 := by decide
theorem cert_e2422373063562 : check e2422373063562 [[],[]] .three = true := by decide
def e2422373063586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422373063586 : Closed e2422373063586 ∧ code e2422373063586 = 11218466085794 := by decide
theorem cert_e2422373063586 : check e2422373063586 [[],[]] .three = true := by decide
def e2422373063598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2422373063598 : Closed e2422373063598 ∧ code e2422373063598 = 11218466085806 := by decide
theorem cert_e2422373063598 : check e2422373063598 [[],[]] .three = true := by decide
def e2422373063606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e2422373063606 : Closed e2422373063606 ∧ code e2422373063606 = 11218466085814 := by decide
theorem cert_e2422373063606 : check e2422373063606 [[],[]] .three = true := by decide
def e2422373063610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2422373063610 : Closed e2422373063610 ∧ code e2422373063610 = 11218466085818 := by decide
theorem cert_e2422373063610 : check e2422373063610 [[],[]] .three = true := by decide
def e2422373063638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2422373063638 : Closed e2422373063638 ∧ code e2422373063638 = 11218466085846 := by decide
theorem cert_e2422373063638 : check e2422373063638 [[],[]] .three = true := by decide
def e2422373063642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2422373063642 : Closed e2422373063642 ∧ code e2422373063642 = 11218466085850 := by decide
theorem cert_e2422373063642 : check e2422373063642 [[],[]] .three = true := by decide
def e2422373063766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422373063766 : Closed e2422373063766 ∧ code e2422373063766 = 11218466085974 := by decide
theorem cert_e2422373063766 : check e2422373063766 [[],[]] .three = true := by decide
def e2422373063770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422373063770 : Closed e2422373063770 ∧ code e2422373063770 = 11218466085978 := by decide
theorem cert_e2422373063770 : check e2422373063770 [[],[]] .three = true := by decide
def e2422373063786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373063786 : Closed e2422373063786 ∧ code e2422373063786 = 11218466085994 := by decide
theorem cert_e2422373063786 : check e2422373063786 [[],[]] .three = true := by decide
def e2422373063958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422373063958 : Closed e2422373063958 ∧ code e2422373063958 = 11218466086166 := by decide
theorem cert_e2422373063958 : check e2422373063958 [[],[]] .three = true := by decide
def e2422373063962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422373063962 : Closed e2422373063962 ∧ code e2422373063962 = 11218466086170 := by decide
theorem cert_e2422373063962 : check e2422373063962 [[],[]] .three = true := by decide
def e2422373064006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422373064006 : Closed e2422373064006 ∧ code e2422373064006 = 11218466086214 := by decide
theorem cert_e2422373064006 : check e2422373064006 [[],[]] .three = true := by decide
def e2422373064030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e2422373064030 : Closed e2422373064030 ∧ code e2422373064030 = 11218466086238 := by decide
theorem cert_e2422373064030 : check e2422373064030 [[],[]] .three = true := by decide
def e2422373064034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422373064034 : Closed e2422373064034 ∧ code e2422373064034 = 11218466086242 := by decide
theorem cert_e2422373064034 : check e2422373064034 [[],[]] .three = true := by decide
def e2422373064046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2422373064046 : Closed e2422373064046 ∧ code e2422373064046 = 11218466086254 := by decide
theorem cert_e2422373064046 : check e2422373064046 [[],[]] .three = true := by decide
def e2422373064054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2422373064054 : Closed e2422373064054 ∧ code e2422373064054 = 11218466086262 := by decide
theorem cert_e2422373064054 : check e2422373064054 [[],[]] .three = true := by decide
def e2422373064058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e2422373064058 : Closed e2422373064058 ∧ code e2422373064058 = 11218466086266 := by decide
theorem cert_e2422373064058 : check e2422373064058 [[],[]] .three = true := by decide
def e2422373064074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422373064074 : Closed e2422373064074 ∧ code e2422373064074 = 11218466086282 := by decide
theorem cert_e2422373064074 : check e2422373064074 [[],[]] .three = true := by decide
def e2422373064098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422373064098 : Closed e2422373064098 ∧ code e2422373064098 = 11218466086306 := by decide
theorem cert_e2422373064098 : check e2422373064098 [[],[]] .three = true := by decide
def e2422373064110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2422373064110 : Closed e2422373064110 ∧ code e2422373064110 = 11218466086318 := by decide
theorem cert_e2422373064110 : check e2422373064110 [[],[]] .three = true := by decide
def e2422373064122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2422373064122 : Closed e2422373064122 ∧ code e2422373064122 = 11218466086330 := by decide
theorem cert_e2422373064122 : check e2422373064122 [[],[]] .three = true := by decide
def e2422373064150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2422373064150 : Closed e2422373064150 ∧ code e2422373064150 = 11218466086358 := by decide
theorem cert_e2422373064150 : check e2422373064150 [[],[]] .three = true := by decide
def e2422373064154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2422373064154 : Closed e2422373064154 ∧ code e2422373064154 = 11218466086362 := by decide
theorem cert_e2422373064154 : check e2422373064154 [[],[]] .three = true := by decide
def e2422373064170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2422373064170 : Closed e2422373064170 ∧ code e2422373064170 = 11218466086378 := by decide
theorem cert_e2422373064170 : check e2422373064170 [[],[]] .three = true := by decide
def e2422373064234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422373064234 : Closed e2422373064234 ∧ code e2422373064234 = 11218466086442 := by decide
theorem cert_e2422373064234 : check e2422373064234 [[],[]] .three = true := by decide
def e2422373064330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422373064330 : Closed e2422373064330 ∧ code e2422373064330 = 11218466086538 := by decide
theorem cert_e2422373064330 : check e2422373064330 [[],[]] .three = true := by decide
def e2422373064354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422373064354 : Closed e2422373064354 ∧ code e2422373064354 = 11218466086562 := by decide
theorem cert_e2422373064354 : check e2422373064354 [[],[]] .three = true := by decide
def e2422373064366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422373064366 : Closed e2422373064366 ∧ code e2422373064366 = 11218466086574 := by decide
theorem cert_e2422373064366 : check e2422373064366 [[],[]] .three = true := by decide
def e2422373064374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e2422373064374 : Closed e2422373064374 ∧ code e2422373064374 = 11218466086582 := by decide
theorem cert_e2422373064374 : check e2422373064374 [[],[]] .three = true := by decide
def e2422373064378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422373064378 : Closed e2422373064378 ∧ code e2422373064378 = 11218466086586 := by decide
theorem cert_e2422373064378 : check e2422373064378 [[],[]] .three = true := by decide
def e2422373064406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2422373064406 : Closed e2422373064406 ∧ code e2422373064406 = 11218466086614 := by decide
theorem cert_e2422373064406 : check e2422373064406 [[],[]] .three = true := by decide
def e2422373064410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2422373064410 : Closed e2422373064410 ∧ code e2422373064410 = 11218466086618 := by decide
theorem cert_e2422373064410 : check e2422373064410 [[],[]] .three = true := by decide
def e2422373064426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422373064426 : Closed e2422373064426 ∧ code e2422373064426 = 11218466086634 := by decide
theorem cert_e2422373064426 : check e2422373064426 [[],[]] .three = true := by decide
def e2422373064534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422373064534 : Closed e2422373064534 ∧ code e2422373064534 = 11218466086742 := by decide
theorem cert_e2422373064534 : check e2422373064534 [[],[]] .three = true := by decide
def e2422373064538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422373064538 : Closed e2422373064538 ∧ code e2422373064538 = 11218466086746 := by decide
theorem cert_e2422373064538 : check e2422373064538 [[],[]] .three = true := by decide
def e2422373064554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2422373064554 : Closed e2422373064554 ∧ code e2422373064554 = 11218466086762 := by decide
theorem cert_e2422373064554 : check e2422373064554 [[],[]] .three = true := by decide
def e2422373064942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422373064942 : Closed e2422373064942 ∧ code e2422373064942 = 11218466087150 := by decide
theorem cert_e2422373064942 : check e2422373064942 [[],[]] .three = true := by decide
def e2422373064950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422373064950 : Closed e2422373064950 ∧ code e2422373064950 = 11218466087158 := by decide
theorem cert_e2422373064950 : check e2422373064950 [[],[]] .three = true := by decide
def e2422373064954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422373064954 : Closed e2422373064954 ∧ code e2422373064954 = 11218466087162 := by decide
theorem cert_e2422373064954 : check e2422373064954 [[],[]] .three = true := by decide
def e2422373065134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422373065134 : Closed e2422373065134 ∧ code e2422373065134 = 11218466087342 := by decide
theorem cert_e2422373065134 : check e2422373065134 [[],[]] .three = true := by decide
def e2422373065142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2422373065142 : Closed e2422373065142 ∧ code e2422373065142 = 11218466087350 := by decide
theorem cert_e2422373065142 : check e2422373065142 [[],[]] .three = true := by decide
def e2422373065146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422373065146 : Closed e2422373065146 ∧ code e2422373065146 = 11218466087354 := by decide
theorem cert_e2422373065146 : check e2422373065146 [[],[]] .three = true := by decide
def e2422373065174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2422373065174 : Closed e2422373065174 ∧ code e2422373065174 = 11218466087382 := by decide
theorem cert_e2422373065174 : check e2422373065174 [[],[]] .three = true := by decide
def e2422373065194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422373065194 : Closed e2422373065194 ∧ code e2422373065194 = 11218466087402 := by decide
theorem cert_e2422373065194 : check e2422373065194 [[],[]] .three = true := by decide
def e2422373065326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373065326 : Closed e2422373065326 ∧ code e2422373065326 = 11218466087534 := by decide
theorem cert_e2422373065326 : check e2422373065326 [[],[]] .three = true := by decide
def e2422373065334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373065334 : Closed e2422373065334 ∧ code e2422373065334 = 11218466087542 := by decide
theorem cert_e2422373065334 : check e2422373065334 [[],[]] .three = true := by decide
def e2422373065338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373065338 : Closed e2422373065338 ∧ code e2422373065338 = 11218466087546 := by decide
theorem cert_e2422373065338 : check e2422373065338 [[],[]] .three = true := by decide
def e2422373065502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422373065502 : Closed e2422373065502 ∧ code e2422373065502 = 11218466087710 := by decide
theorem cert_e2422373065502 : check e2422373065502 [[],[]] .three = true := by decide
def e2422373065526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373065526 : Closed e2422373065526 ∧ code e2422373065526 = 11218466087734 := by decide
theorem cert_e2422373065526 : check e2422373065526 [[],[]] .three = true := by decide
def e2422373065530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373065530 : Closed e2422373065530 ∧ code e2422373065530 = 11218466087738 := by decide
theorem cert_e2422373065530 : check e2422373065530 [[],[]] .three = true := by decide
def e2422373065614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422373065614 : Closed e2422373065614 ∧ code e2422373065614 = 11218466087822 := by decide
theorem cert_e2422373065614 : check e2422373065614 [[],[]] .three = true := by decide
def e2422373065626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373065626 : Closed e2422373065626 ∧ code e2422373065626 = 11218466087834 := by decide
theorem cert_e2422373065626 : check e2422373065626 [[],[]] .three = true := by decide
def e2422373065670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422373065670 : Closed e2422373065670 ∧ code e2422373065670 = 11218466087878 := by decide
theorem cert_e2422373065670 : check e2422373065670 [[],[]] .three = true := by decide
def e2422373065694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 3))) (.var 3)))))))
theorem wire_e2422373065694 : Closed e2422373065694 ∧ code e2422373065694 = 11218466087902 := by decide
theorem cert_e2422373065694 : check e2422373065694 [[],[]] .three = true := by decide
def e2422373065710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 4))) (.var 2)))))))
theorem wire_e2422373065710 : Closed e2422373065710 ∧ code e2422373065710 = 11218466087918 := by decide
theorem cert_e2422373065710 : check e2422373065710 [[],[]] .three = true := by decide
def e2422373066286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373066286 : Closed e2422373066286 ∧ code e2422373066286 = 11218466088494 := by decide
theorem cert_e2422373066286 : check e2422373066286 [[],[]] .three = true := by decide
def e2422373066294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373066294 : Closed e2422373066294 ∧ code e2422373066294 = 11218466088502 := by decide
theorem cert_e2422373066294 : check e2422373066294 [[],[]] .three = true := by decide
def e2422373066298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373066298 : Closed e2422373066298 ∧ code e2422373066298 = 11218466088506 := by decide
theorem cert_e2422373066298 : check e2422373066298 [[],[]] .three = true := by decide
def e2422373066382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373066382 : Closed e2422373066382 ∧ code e2422373066382 = 11218466088590 := by decide
theorem cert_e2422373066382 : check e2422373066382 [[],[]] .three = true := by decide
def e2422373066438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373066438 : Closed e2422373066438 ∧ code e2422373066438 = 11218466088646 := by decide
theorem cert_e2422373066438 : check e2422373066438 [[],[]] .three = true := by decide
def e2422373066462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2422373066462 : Closed e2422373066462 ∧ code e2422373066462 = 11218466088670 := by decide
theorem cert_e2422373066462 : check e2422373066462 [[],[]] .three = true := by decide
def e2422373066466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373066466 : Closed e2422373066466 ∧ code e2422373066466 = 11218466088674 := by decide
theorem cert_e2422373066466 : check e2422373066466 [[],[]] .three = true := by decide
def e2422373066478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2422373066478 : Closed e2422373066478 ∧ code e2422373066478 = 11218466088686 := by decide
theorem cert_e2422373066478 : check e2422373066478 [[],[]] .three = true := by decide
def e2422373066486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2422373066486 : Closed e2422373066486 ∧ code e2422373066486 = 11218466088694 := by decide
theorem cert_e2422373066486 : check e2422373066486 [[],[]] .three = true := by decide
def e2422373066518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373066518 : Closed e2422373066518 ∧ code e2422373066518 = 11218466088726 := by decide
theorem cert_e2422373066518 : check e2422373066518 [[],[]] .three = true := by decide
def e2422373066522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373066522 : Closed e2422373066522 ∧ code e2422373066522 = 11218466088730 := by decide
theorem cert_e2422373066522 : check e2422373066522 [[],[]] .three = true := by decide
def e2422373066566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373066566 : Closed e2422373066566 ∧ code e2422373066566 = 11218466088774 := by decide
theorem cert_e2422373066566 : check e2422373066566 [[],[]] .three = true := by decide
def e2422373066590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2422373066590 : Closed e2422373066590 ∧ code e2422373066590 = 11218466088798 := by decide
theorem cert_e2422373066590 : check e2422373066590 [[],[]] .three = true := by decide
def e2422373066594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373066594 : Closed e2422373066594 ∧ code e2422373066594 = 11218466088802 := by decide
theorem cert_e2422373066594 : check e2422373066594 [[],[]] .three = true := by decide
def e2422373066606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2422373066606 : Closed e2422373066606 ∧ code e2422373066606 = 11218466088814 := by decide
theorem cert_e2422373066606 : check e2422373066606 [[],[]] .three = true := by decide
def e2422373066614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2422373066614 : Closed e2422373066614 ∧ code e2422373066614 = 11218466088822 := by decide
theorem cert_e2422373066614 : check e2422373066614 [[],[]] .three = true := by decide
def e2422373066618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2422373066618 : Closed e2422373066618 ∧ code e2422373066618 = 11218466088826 := by decide
theorem cert_e2422373066618 : check e2422373066618 [[],[]] .three = true := by decide
def e2422373066634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373066634 : Closed e2422373066634 ∧ code e2422373066634 = 11218466088842 := by decide
theorem cert_e2422373066634 : check e2422373066634 [[],[]] .three = true := by decide
def e2422373066658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373066658 : Closed e2422373066658 ∧ code e2422373066658 = 11218466088866 := by decide
theorem cert_e2422373066658 : check e2422373066658 [[],[]] .three = true := by decide
def e2422373066670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2422373066670 : Closed e2422373066670 ∧ code e2422373066670 = 11218466088878 := by decide
theorem cert_e2422373066670 : check e2422373066670 [[],[]] .three = true := by decide
def e2422373066678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2422373066678 : Closed e2422373066678 ∧ code e2422373066678 = 11218466088886 := by decide
theorem cert_e2422373066678 : check e2422373066678 [[],[]] .three = true := by decide
def e2422373066682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2422373066682 : Closed e2422373066682 ∧ code e2422373066682 = 11218466088890 := by decide
theorem cert_e2422373066682 : check e2422373066682 [[],[]] .three = true := by decide
def e2422373066710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2422373066710 : Closed e2422373066710 ∧ code e2422373066710 = 11218466088918 := by decide
theorem cert_e2422373066710 : check e2422373066710 [[],[]] .three = true := by decide
def e2422373066714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2422373066714 : Closed e2422373066714 ∧ code e2422373066714 = 11218466088922 := by decide
theorem cert_e2422373066714 : check e2422373066714 [[],[]] .three = true := by decide
def e2422373066814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373066814 : Closed e2422373066814 ∧ code e2422373066814 = 11218466089022 := by decide
theorem cert_e2422373066814 : check e2422373066814 [[],[]] .three = true := by decide
def e2422373066862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373066862 : Closed e2422373066862 ∧ code e2422373066862 = 11218466089070 := by decide
theorem cert_e2422373066862 : check e2422373066862 [[],[]] .three = true := by decide
def e2422373066874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373066874 : Closed e2422373066874 ∧ code e2422373066874 = 11218466089082 := by decide
theorem cert_e2422373066874 : check e2422373066874 [[],[]] .three = true := by decide
def e2422373067150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373067150 : Closed e2422373067150 ∧ code e2422373067150 = 11218466089358 := by decide
theorem cert_e2422373067150 : check e2422373067150 [[],[]] .three = true := by decide
def e2422373067206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373067206 : Closed e2422373067206 ∧ code e2422373067206 = 11218466089414 := by decide
theorem cert_e2422373067206 : check e2422373067206 [[],[]] .three = true := by decide
def e2422373067230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373067230 : Closed e2422373067230 ∧ code e2422373067230 = 11218466089438 := by decide
theorem cert_e2422373067230 : check e2422373067230 [[],[]] .three = true := by decide
def e2422373067234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373067234 : Closed e2422373067234 ∧ code e2422373067234 = 11218466089442 := by decide
theorem cert_e2422373067234 : check e2422373067234 [[],[]] .three = true := by decide
def e2422373067246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373067246 : Closed e2422373067246 ∧ code e2422373067246 = 11218466089454 := by decide
theorem cert_e2422373067246 : check e2422373067246 [[],[]] .three = true := by decide
def e2422373067254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373067254 : Closed e2422373067254 ∧ code e2422373067254 = 11218466089462 := by decide
theorem cert_e2422373067254 : check e2422373067254 [[],[]] .three = true := by decide
def e2422373067806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373067806 : Closed e2422373067806 ∧ code e2422373067806 = 11218466090014 := by decide
theorem cert_e2422373067806 : check e2422373067806 [[],[]] .three = true := by decide
def e2422373067830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373067830 : Closed e2422373067830 ∧ code e2422373067830 = 11218466090038 := by decide
theorem cert_e2422373067830 : check e2422373067830 [[],[]] .three = true := by decide
def e2422373067834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373067834 : Closed e2422373067834 ∧ code e2422373067834 = 11218466090042 := by decide
theorem cert_e2422373067834 : check e2422373067834 [[],[]] .three = true := by decide
def e2422373067974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373067974 : Closed e2422373067974 ∧ code e2422373067974 = 11218466090182 := by decide
theorem cert_e2422373067974 : check e2422373067974 [[],[]] .three = true := by decide
def e2422373067998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373067998 : Closed e2422373067998 ∧ code e2422373067998 = 11218466090206 := by decide
theorem cert_e2422373067998 : check e2422373067998 [[],[]] .three = true := by decide
def e2422373068002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373068002 : Closed e2422373068002 ∧ code e2422373068002 = 11218466090210 := by decide
theorem cert_e2422373068002 : check e2422373068002 [[],[]] .three = true := by decide
def e2422373068014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373068014 : Closed e2422373068014 ∧ code e2422373068014 = 11218466090222 := by decide
theorem cert_e2422373068014 : check e2422373068014 [[],[]] .three = true := by decide
def e2422373068022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373068022 : Closed e2422373068022 ∧ code e2422373068022 = 11218466090230 := by decide
theorem cert_e2422373068022 : check e2422373068022 [[],[]] .three = true := by decide
def e2422373068026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373068026 : Closed e2422373068026 ∧ code e2422373068026 = 11218466090234 := by decide
theorem cert_e2422373068026 : check e2422373068026 [[],[]] .three = true := by decide
def e2422373068302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373068302 : Closed e2422373068302 ∧ code e2422373068302 = 11218466090510 := by decide
theorem cert_e2422373068302 : check e2422373068302 [[],[]] .three = true := by decide
def e2422373068314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373068314 : Closed e2422373068314 ∧ code e2422373068314 = 11218466090522 := by decide
theorem cert_e2422373068314 : check e2422373068314 [[],[]] .three = true := by decide
def e2422373068350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.lam (.var 4))))))))
theorem wire_e2422373068350 : Closed e2422373068350 ∧ code e2422373068350 = 11218466090558 := by decide
theorem cert_e2422373068350 : check e2422373068350 [[],[]] .three = true := by decide
def e2422373068386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373068386 : Closed e2422373068386 ∧ code e2422373068386 = 11218466090594 := by decide
theorem cert_e2422373068386 : check e2422373068386 [[],[]] .three = true := by decide
def e2422373068398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373068398 : Closed e2422373068398 ∧ code e2422373068398 = 11218466090606 := by decide
theorem cert_e2422373068398 : check e2422373068398 [[],[]] .three = true := by decide
def e2422373068406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373068406 : Closed e2422373068406 ∧ code e2422373068406 = 11218466090614 := by decide
theorem cert_e2422373068406 : check e2422373068406 [[],[]] .three = true := by decide
def e2422373068410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373068410 : Closed e2422373068410 ∧ code e2422373068410 = 11218466090618 := by decide
theorem cert_e2422373068410 : check e2422373068410 [[],[]] .three = true := by decide
def e2422373068574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.lam (.var 3))))))))
theorem wire_e2422373068574 : Closed e2422373068574 ∧ code e2422373068574 = 11218466090782 := by decide
theorem cert_e2422373068574 : check e2422373068574 [[],[]] .three = true := by decide
def e2422373068598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373068598 : Closed e2422373068598 ∧ code e2422373068598 = 11218466090806 := by decide
theorem cert_e2422373068598 : check e2422373068598 [[],[]] .three = true := by decide
def e2422373068602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373068602 : Closed e2422373068602 ∧ code e2422373068602 = 11218466090810 := by decide
theorem cert_e2422373068602 : check e2422373068602 [[],[]] .three = true := by decide
def e2422373068918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2422373068918 : Closed e2422373068918 ∧ code e2422373068918 = 11218466091126 := by decide
theorem cert_e2422373068918 : check e2422373068918 [[],[]] .three = true := by decide
def e2422373068922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422373068922 : Closed e2422373068922 ∧ code e2422373068922 = 11218466091130 := by decide
theorem cert_e2422373068922 : check e2422373068922 [[],[]] .three = true := by decide
def e2422373069018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2422373069018 : Closed e2422373069018 ∧ code e2422373069018 = 11218466091226 := by decide
theorem cert_e2422373069018 : check e2422373069018 [[],[]] .three = true := by decide
def e2422373069034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2422373069034 : Closed e2422373069034 ∧ code e2422373069034 = 11218466091242 := by decide
theorem cert_e2422373069034 : check e2422373069034 [[],[]] .three = true := by decide
def e2422373069110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373069110 : Closed e2422373069110 ∧ code e2422373069110 = 11218466091318 := by decide
theorem cert_e2422373069110 : check e2422373069110 [[],[]] .three = true := by decide
def e2422373069114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373069114 : Closed e2422373069114 ∧ code e2422373069114 = 11218466091322 := by decide
theorem cert_e2422373069114 : check e2422373069114 [[],[]] .three = true := by decide
def e2422373069198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2422373069198 : Closed e2422373069198 ∧ code e2422373069198 = 11218466091406 := by decide
theorem cert_e2422373069198 : check e2422373069198 [[],[]] .three = true := by decide
def e2422373069210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373069210 : Closed e2422373069210 ∧ code e2422373069210 = 11218466091418 := by decide
theorem cert_e2422373069210 : check e2422373069210 [[],[]] .three = true := by decide
def e2422373069254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422373069254 : Closed e2422373069254 ∧ code e2422373069254 = 11218466091462 := by decide
theorem cert_e2422373069254 : check e2422373069254 [[],[]] .three = true := by decide
def e2422373069294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e2422373069294 : Closed e2422373069294 ∧ code e2422373069294 = 11218466091502 := by decide
theorem cert_e2422373069294 : check e2422373069294 [[],[]] .three = true := by decide
def e2422373069590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373069590 : Closed e2422373069590 ∧ code e2422373069590 = 11218466091798 := by decide
theorem cert_e2422373069590 : check e2422373069590 [[],[]] .three = true := by decide
def e2422373069594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373069594 : Closed e2422373069594 ∧ code e2422373069594 = 11218466091802 := by decide
theorem cert_e2422373069594 : check e2422373069594 [[],[]] .three = true := by decide
def e2422373069638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373069638 : Closed e2422373069638 ∧ code e2422373069638 = 11218466091846 := by decide
theorem cert_e2422373069638 : check e2422373069638 [[],[]] .three = true := by decide
def e2422373069662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2422373069662 : Closed e2422373069662 ∧ code e2422373069662 = 11218466091870 := by decide
theorem cert_e2422373069662 : check e2422373069662 [[],[]] .three = true := by decide
def e2422373069666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373069666 : Closed e2422373069666 ∧ code e2422373069666 = 11218466091874 := by decide
theorem cert_e2422373069666 : check e2422373069666 [[],[]] .three = true := by decide
def e2422373069678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422373069678 : Closed e2422373069678 ∧ code e2422373069678 = 11218466091886 := by decide
theorem cert_e2422373069678 : check e2422373069678 [[],[]] .three = true := by decide
def e2422373069686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422373069686 : Closed e2422373069686 ∧ code e2422373069686 = 11218466091894 := by decide
theorem cert_e2422373069686 : check e2422373069686 [[],[]] .three = true := by decide
def e2422373069690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2422373069690 : Closed e2422373069690 ∧ code e2422373069690 = 11218466091898 := by decide
theorem cert_e2422373069690 : check e2422373069690 [[],[]] .three = true := by decide
def e2422373069706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373069706 : Closed e2422373069706 ∧ code e2422373069706 = 11218466091914 := by decide
theorem cert_e2422373069706 : check e2422373069706 [[],[]] .three = true := by decide
end Blc.Floor43
