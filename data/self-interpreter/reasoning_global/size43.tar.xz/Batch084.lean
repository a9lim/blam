import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e826973329946 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826973329946 : Closed e826973329946 ∧ code e826973329946 = 9623066352154 := by decide
theorem cert_e826973329946 : check e826973329946 [] .sourceHead = true := by decide
def e826973331482 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826973331482 : Closed e826973331482 ∧ code e826973331482 = 9623066353690 := by decide
theorem cert_e826973331482 : check e826973331482 [] .sourceHead = true := by decide
def e826973331574 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826973331574 : Closed e826973331574 ∧ code e826973331574 = 9623066353782 := by decide
theorem cert_e826973331574 : check e826973331574 [] .sourceHead = true := by decide
def e826973331818 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826973331818 : Closed e826973331818 ∧ code e826973331818 = 9623066354026 := by decide
theorem cert_e826973331818 : check e826973331818 [] .sourceHead = true := by decide
def e826973331866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826973331866 : Closed e826973331866 ∧ code e826973331866 = 9623066354074 := by decide
theorem cert_e826973331866 : check e826973331866 [] .sourceHead = true := by decide
def e826973333018 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826973333018 : Closed e826973333018 ∧ code e826973333018 = 9623066355226 := by decide
theorem cert_e826973333018 : check e826973333018 [] .sourceHead = true := by decide
def e826975628826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975628826 : Closed e826975628826 ∧ code e826975628826 = 9623068651034 := by decide
theorem cert_e826975628826 : check e826975628826 [] .sourceHead = true := by decide
def e826975631898 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975631898 : Closed e826975631898 ∧ code e826975631898 = 9623068654106 := by decide
theorem cert_e826975631898 : check e826975631898 [] .sourceHead = true := by decide
def e826975644186 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975644186 : Closed e826975644186 ∧ code e826975644186 = 9623068666394 := by decide
theorem cert_e826975644186 : check e826975644186 [] .sourceHead = true := by decide
def e826975693338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975693338 : Closed e826975693338 ∧ code e826975693338 = 9623068715546 := by decide
theorem cert_e826975693338 : check e826975693338 [] .sourceHead = true := by decide
def e826975825434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975825434 : Closed e826975825434 ∧ code e826975825434 = 9623068847642 := by decide
theorem cert_e826975825434 : check e826975825434 [] .sourceHead = true := by decide
def e826975828506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975828506 : Closed e826975828506 ∧ code e826975828506 = 9623068850714 := by decide
theorem cert_e826975828506 : check e826975828506 [] .sourceHead = true := by decide
def e826975840794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975840794 : Closed e826975840794 ∧ code e826975840794 = 9623068863002 := by decide
theorem cert_e826975840794 : check e826975840794 [] .sourceHead = true := by decide
def e826975874586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975874586 : Closed e826975874586 ∧ code e826975874586 = 9623068896794 := by decide
theorem cert_e826975874586 : check e826975874586 [] .sourceHead = true := by decide
def e826975877658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975877658 : Closed e826975877658 ∧ code e826975877658 = 9623068899866 := by decide
theorem cert_e826975877658 : check e826975877658 [] .sourceHead = true := by decide
def e826975903770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826975903770 : Closed e826975903770 ∧ code e826975903770 = 9623068925978 := by decide
theorem cert_e826975903770 : check e826975903770 [] .sourceHead = true := by decide
def e826975903862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826975903862 : Closed e826975903862 ∧ code e826975903862 = 9623068926070 := by decide
theorem cert_e826975903862 : check e826975903862 [] .sourceHead = true := by decide
def e826975904106 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826975904106 : Closed e826975904106 ∧ code e826975904106 = 9623068926314 := by decide
theorem cert_e826975904106 : check e826975904106 [] .sourceHead = true := by decide
def e826975904154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826975904154 : Closed e826975904154 ∧ code e826975904154 = 9623068926362 := by decide
theorem cert_e826975904154 : check e826975904154 [] .sourceHead = true := by decide
def e826975905306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826975905306 : Closed e826975905306 ∧ code e826975905306 = 9623068927514 := by decide
theorem cert_e826975905306 : check e826975905306 [] .sourceHead = true := by decide
def e826975951386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826975951386 : Closed e826975951386 ∧ code e826975951386 = 9623068973594 := by decide
theorem cert_e826975951386 : check e826975951386 [] .sourceHead = true := by decide
def e826975952922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826975952922 : Closed e826975952922 ∧ code e826975952922 = 9623068975130 := by decide
theorem cert_e826975952922 : check e826975952922 [] .sourceHead = true := by decide
def e826975953014 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826975953014 : Closed e826975953014 ∧ code e826975953014 = 9623068975222 := by decide
theorem cert_e826975953014 : check e826975953014 [] .sourceHead = true := by decide
def e826975953258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826975953258 : Closed e826975953258 ∧ code e826975953258 = 9623068975466 := by decide
theorem cert_e826975953258 : check e826975953258 [] .sourceHead = true := by decide
def e826975953306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826975953306 : Closed e826975953306 ∧ code e826975953306 = 9623068975514 := by decide
theorem cert_e826975953306 : check e826975953306 [] .sourceHead = true := by decide
def e826975954458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826975954458 : Closed e826975954458 ∧ code e826975954458 = 9623068976666 := by decide
theorem cert_e826975954458 : check e826975954458 [] .sourceHead = true := by decide
def e826976135706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826976135706 : Closed e826976135706 ∧ code e826976135706 = 9623069157914 := by decide
theorem cert_e826976135706 : check e826976135706 [] .sourceHead = true := by decide
def e826976147994 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826976147994 : Closed e826976147994 ∧ code e826976147994 = 9623069170202 := by decide
theorem cert_e826976147994 : check e826976147994 [] .sourceHead = true := by decide
def e826976149530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826976149530 : Closed e826976149530 ∧ code e826976149530 = 9623069171738 := by decide
theorem cert_e826976149530 : check e826976149530 [] .sourceHead = true := by decide
def e826976149622 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826976149622 : Closed e826976149622 ∧ code e826976149622 = 9623069171830 := by decide
theorem cert_e826976149622 : check e826976149622 [] .sourceHead = true := by decide
def e826976149866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826976149866 : Closed e826976149866 ∧ code e826976149866 = 9623069172074 := by decide
theorem cert_e826976149866 : check e826976149866 [] .sourceHead = true := by decide
def e826976149914 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826976149914 : Closed e826976149914 ∧ code e826976149914 = 9623069172122 := by decide
theorem cert_e826976149914 : check e826976149914 [] .sourceHead = true := by decide
def e826976151066 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826976151066 : Closed e826976151066 ∧ code e826976151066 = 9623069173274 := by decide
theorem cert_e826976151066 : check e826976151066 [] .sourceHead = true := by decide
def e826976611866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826976611866 : Closed e826976611866 ∧ code e826976611866 = 9623069634074 := by decide
theorem cert_e826976611866 : check e826976611866 [] .sourceHead = true := by decide
def e826976614938 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826976614938 : Closed e826976614938 ∧ code e826976614938 = 9623069637146 := by decide
theorem cert_e826976614938 : check e826976614938 [] .sourceHead = true := by decide
def e826976627226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826976627226 : Closed e826976627226 ∧ code e826976627226 = 9623069649434 := by decide
theorem cert_e826976627226 : check e826976627226 [] .sourceHead = true := by decide
def e826976661018 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826976661018 : Closed e826976661018 ∧ code e826976661018 = 9623069683226 := by decide
theorem cert_e826976661018 : check e826976661018 [] .sourceHead = true := by decide
def e826976664090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826976664090 : Closed e826976664090 ∧ code e826976664090 = 9623069686298 := by decide
theorem cert_e826976664090 : check e826976664090 [] .sourceHead = true := by decide
def e826976690202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826976690202 : Closed e826976690202 ∧ code e826976690202 = 9623069712410 := by decide
theorem cert_e826976690202 : check e826976690202 [] .sourceHead = true := by decide
def e826976690294 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826976690294 : Closed e826976690294 ∧ code e826976690294 = 9623069712502 := by decide
theorem cert_e826976690294 : check e826976690294 [] .sourceHead = true := by decide
def e826976690538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826976690538 : Closed e826976690538 ∧ code e826976690538 = 9623069712746 := by decide
theorem cert_e826976690538 : check e826976690538 [] .sourceHead = true := by decide
def e826976690586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826976690586 : Closed e826976690586 ∧ code e826976690586 = 9623069712794 := by decide
theorem cert_e826976690586 : check e826976690586 [] .sourceHead = true := by decide
def e826976691738 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826976691738 : Closed e826976691738 ∧ code e826976691738 = 9623069713946 := by decide
theorem cert_e826976691738 : check e826976691738 [] .sourceHead = true := by decide
def e826976737818 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826976737818 : Closed e826976737818 ∧ code e826976737818 = 9623069760026 := by decide
theorem cert_e826976737818 : check e826976737818 [] .sourceHead = true := by decide
def e826976739354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826976739354 : Closed e826976739354 ∧ code e826976739354 = 9623069761562 := by decide
theorem cert_e826976739354 : check e826976739354 [] .sourceHead = true := by decide
def e826976739446 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826976739446 : Closed e826976739446 ∧ code e826976739446 = 9623069761654 := by decide
theorem cert_e826976739446 : check e826976739446 [] .sourceHead = true := by decide
def e826976739690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826976739690 : Closed e826976739690 ∧ code e826976739690 = 9623069761898 := by decide
theorem cert_e826976739690 : check e826976739690 [] .sourceHead = true := by decide
def e826976739738 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826976739738 : Closed e826976739738 ∧ code e826976739738 = 9623069761946 := by decide
theorem cert_e826976739738 : check e826976739738 [] .sourceHead = true := by decide
def e826976740890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826976740890 : Closed e826976740890 ∧ code e826976740890 = 9623069763098 := by decide
theorem cert_e826976740890 : check e826976740890 [] .sourceHead = true := by decide
def e826977905178 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826977905178 : Closed e826977905178 ∧ code e826977905178 = 9623070927386 := by decide
theorem cert_e826977905178 : check e826977905178 [] .sourceHead = true := by decide
def e826977917466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826977917466 : Closed e826977917466 ∧ code e826977917466 = 9623070939674 := by decide
theorem cert_e826977917466 : check e826977917466 [] .sourceHead = true := by decide
def e826977919002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826977919002 : Closed e826977919002 ∧ code e826977919002 = 9623070941210 := by decide
theorem cert_e826977919002 : check e826977919002 [] .sourceHead = true := by decide
def e826977919094 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826977919094 : Closed e826977919094 ∧ code e826977919094 = 9623070941302 := by decide
theorem cert_e826977919094 : check e826977919094 [] .sourceHead = true := by decide
def e826977919338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826977919338 : Closed e826977919338 ∧ code e826977919338 = 9623070941546 := by decide
theorem cert_e826977919338 : check e826977919338 [] .sourceHead = true := by decide
def e826977919386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826977919386 : Closed e826977919386 ∧ code e826977919386 = 9623070941594 := by decide
theorem cert_e826977919386 : check e826977919386 [] .sourceHead = true := by decide
def e826977920538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826977920538 : Closed e826977920538 ∧ code e826977920538 = 9623070942746 := by decide
theorem cert_e826977920538 : check e826977920538 [] .sourceHead = true := by decide
def e826979079706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979079706 : Closed e826979079706 ∧ code e826979079706 = 9623072101914 := by decide
theorem cert_e826979079706 : check e826979079706 [] .sourceHead = true := by decide
def e826979080730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979080730 : Closed e826979080730 ∧ code e826979080730 = 9623072102938 := by decide
theorem cert_e826979080730 : check e826979080730 [] .sourceHead = true := by decide
def e826979084826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979084826 : Closed e826979084826 ∧ code e826979084826 = 9623072107034 := by decide
theorem cert_e826979084826 : check e826979084826 [] .sourceHead = true := by decide
def e826979101210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979101210 : Closed e826979101210 ∧ code e826979101210 = 9623072123418 := by decide
theorem cert_e826979101210 : check e826979101210 [] .sourceHead = true := by decide
def e826979178010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979178010 : Closed e826979178010 ∧ code e826979178010 = 9623072200218 := by decide
theorem cert_e826979178010 : check e826979178010 [] .sourceHead = true := by decide
def e826979179034 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979179034 : Closed e826979179034 ∧ code e826979179034 = 9623072201242 := by decide
theorem cert_e826979179034 : check e826979179034 [] .sourceHead = true := by decide
def e826979183130 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979183130 : Closed e826979183130 ∧ code e826979183130 = 9623072205338 := by decide
theorem cert_e826979183130 : check e826979183130 [] .sourceHead = true := by decide
def e826979202586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979202586 : Closed e826979202586 ∧ code e826979202586 = 9623072224794 := by decide
theorem cert_e826979202586 : check e826979202586 [] .sourceHead = true := by decide
def e826979203610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979203610 : Closed e826979203610 ∧ code e826979203610 = 9623072225818 := by decide
theorem cert_e826979203610 : check e826979203610 [] .sourceHead = true := by decide
def e826979213338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826979213338 : Closed e826979213338 ∧ code e826979213338 = 9623072235546 := by decide
theorem cert_e826979213338 : check e826979213338 [] .sourceHead = true := by decide
def e826979213430 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826979213430 : Closed e826979213430 ∧ code e826979213430 = 9623072235638 := by decide
theorem cert_e826979213430 : check e826979213430 [] .sourceHead = true := by decide
def e826979213674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826979213674 : Closed e826979213674 ∧ code e826979213674 = 9623072235882 := by decide
theorem cert_e826979213674 : check e826979213674 [] .sourceHead = true := by decide
def e826979213722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826979213722 : Closed e826979213722 ∧ code e826979213722 = 9623072235930 := by decide
theorem cert_e826979213722 : check e826979213722 [] .sourceHead = true := by decide
def e826979214874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826979214874 : Closed e826979214874 ∧ code e826979214874 = 9623072237082 := by decide
theorem cert_e826979214874 : check e826979214874 [] .sourceHead = true := by decide
def e826979228186 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979228186 : Closed e826979228186 ∧ code e826979228186 = 9623072250394 := by decide
theorem cert_e826979228186 : check e826979228186 [] .sourceHead = true := by decide
def e826979229722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826979229722 : Closed e826979229722 ∧ code e826979229722 = 9623072251930 := by decide
theorem cert_e826979229722 : check e826979229722 [] .sourceHead = true := by decide
def e826979229814 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826979229814 : Closed e826979229814 ∧ code e826979229814 = 9623072252022 := by decide
theorem cert_e826979229814 : check e826979229814 [] .sourceHead = true := by decide
def e826979230058 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826979230058 : Closed e826979230058 ∧ code e826979230058 = 9623072252266 := by decide
theorem cert_e826979230058 : check e826979230058 [] .sourceHead = true := by decide
def e826979230106 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826979230106 : Closed e826979230106 ∧ code e826979230106 = 9623072252314 := by decide
theorem cert_e826979230106 : check e826979230106 [] .sourceHead = true := by decide
def e826979231258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826979231258 : Closed e826979231258 ∧ code e826979231258 = 9623072253466 := by decide
theorem cert_e826979231258 : check e826979231258 [] .sourceHead = true := by decide
def e826979281434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979281434 : Closed e826979281434 ∧ code e826979281434 = 9623072303642 := by decide
theorem cert_e826979281434 : check e826979281434 [] .sourceHead = true := by decide
def e826979293722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979293722 : Closed e826979293722 ∧ code e826979293722 = 9623072315930 := by decide
theorem cert_e826979293722 : check e826979293722 [] .sourceHead = true := by decide
def e826979295258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826979295258 : Closed e826979295258 ∧ code e826979295258 = 9623072317466 := by decide
theorem cert_e826979295258 : check e826979295258 [] .sourceHead = true := by decide
def e826979295350 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826979295350 : Closed e826979295350 ∧ code e826979295350 = 9623072317558 := by decide
theorem cert_e826979295350 : check e826979295350 [] .sourceHead = true := by decide
def e826979295594 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826979295594 : Closed e826979295594 ∧ code e826979295594 = 9623072317802 := by decide
theorem cert_e826979295594 : check e826979295594 [] .sourceHead = true := by decide
def e826979295642 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826979295642 : Closed e826979295642 ∧ code e826979295642 = 9623072317850 := by decide
theorem cert_e826979295642 : check e826979295642 [] .sourceHead = true := by decide
def e826979296794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826979296794 : Closed e826979296794 ∧ code e826979296794 = 9623072319002 := by decide
theorem cert_e826979296794 : check e826979296794 [] .sourceHead = true := by decide
def e826979571226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979571226 : Closed e826979571226 ∧ code e826979571226 = 9623072593434 := by decide
theorem cert_e826979571226 : check e826979571226 [] .sourceHead = true := by decide
def e826979572250 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979572250 : Closed e826979572250 ∧ code e826979572250 = 9623072594458 := by decide
theorem cert_e826979572250 : check e826979572250 [] .sourceHead = true := by decide
def e826979576346 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979576346 : Closed e826979576346 ∧ code e826979576346 = 9623072598554 := by decide
theorem cert_e826979576346 : check e826979576346 [] .sourceHead = true := by decide
def e826979595802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979595802 : Closed e826979595802 ∧ code e826979595802 = 9623072618010 := by decide
theorem cert_e826979595802 : check e826979595802 [] .sourceHead = true := by decide
def e826979596826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979596826 : Closed e826979596826 ∧ code e826979596826 = 9623072619034 := by decide
theorem cert_e826979596826 : check e826979596826 [] .sourceHead = true := by decide
def e826979606554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826979606554 : Closed e826979606554 ∧ code e826979606554 = 9623072628762 := by decide
theorem cert_e826979606554 : check e826979606554 [] .sourceHead = true := by decide
def e826979606646 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826979606646 : Closed e826979606646 ∧ code e826979606646 = 9623072628854 := by decide
theorem cert_e826979606646 : check e826979606646 [] .sourceHead = true := by decide
def e826979606890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826979606890 : Closed e826979606890 ∧ code e826979606890 = 9623072629098 := by decide
theorem cert_e826979606890 : check e826979606890 [] .sourceHead = true := by decide
def e826979606938 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826979606938 : Closed e826979606938 ∧ code e826979606938 = 9623072629146 := by decide
theorem cert_e826979606938 : check e826979606938 [] .sourceHead = true := by decide
def e826979608090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826979608090 : Closed e826979608090 ∧ code e826979608090 = 9623072630298 := by decide
theorem cert_e826979608090 : check e826979608090 [] .sourceHead = true := by decide
def e826979621402 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826979621402 : Closed e826979621402 ∧ code e826979621402 = 9623072643610 := by decide
theorem cert_e826979621402 : check e826979621402 [] .sourceHead = true := by decide
def e826979622938 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826979622938 : Closed e826979622938 ∧ code e826979622938 = 9623072645146 := by decide
theorem cert_e826979622938 : check e826979622938 [] .sourceHead = true := by decide
def e826979623030 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826979623030 : Closed e826979623030 ∧ code e826979623030 = 9623072645238 := by decide
theorem cert_e826979623030 : check e826979623030 [] .sourceHead = true := by decide
def e826979623274 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826979623274 : Closed e826979623274 ∧ code e826979623274 = 9623072645482 := by decide
theorem cert_e826979623274 : check e826979623274 [] .sourceHead = true := by decide
def e826979623322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826979623322 : Closed e826979623322 ∧ code e826979623322 = 9623072645530 := by decide
theorem cert_e826979623322 : check e826979623322 [] .sourceHead = true := by decide
def e826979624474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826979624474 : Closed e826979624474 ∧ code e826979624474 = 9623072646682 := by decide
theorem cert_e826979624474 : check e826979624474 [] .sourceHead = true := by decide
def e826980002330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826980002330 : Closed e826980002330 ∧ code e826980002330 = 9623073024538 := by decide
theorem cert_e826980002330 : check e826980002330 [] .sourceHead = true := by decide
def e826980014618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826980014618 : Closed e826980014618 ∧ code e826980014618 = 9623073036826 := by decide
theorem cert_e826980014618 : check e826980014618 [] .sourceHead = true := by decide
def e826980016154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826980016154 : Closed e826980016154 ∧ code e826980016154 = 9623073038362 := by decide
theorem cert_e826980016154 : check e826980016154 [] .sourceHead = true := by decide
def e826980016246 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826980016246 : Closed e826980016246 ∧ code e826980016246 = 9623073038454 := by decide
theorem cert_e826980016246 : check e826980016246 [] .sourceHead = true := by decide
def e826980016490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826980016490 : Closed e826980016490 ∧ code e826980016490 = 9623073038698 := by decide
theorem cert_e826980016490 : check e826980016490 [] .sourceHead = true := by decide
def e826980016538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826980016538 : Closed e826980016538 ∧ code e826980016538 = 9623073038746 := by decide
theorem cert_e826980016538 : check e826980016538 [] .sourceHead = true := by decide
def e826980017690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826980017690 : Closed e826980017690 ∧ code e826980017690 = 9623073039898 := by decide
theorem cert_e826980017690 : check e826980017690 [] .sourceHead = true := by decide
def e826985527322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826985527322 : Closed e826985527322 ∧ code e826985527322 = 9623078549530 := by decide
theorem cert_e826985527322 : check e826985527322 [] .sourceHead = true := by decide
def e826985535514 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826985535514 : Closed e826985535514 ∧ code e826985535514 = 9623078557722 := by decide
theorem cert_e826985535514 : check e826985535514 [] .sourceHead = true := by decide
def e826985592858 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826985592858 : Closed e826985592858 ∧ code e826985592858 = 9623078615066 := by decide
theorem cert_e826985592858 : check e826985592858 [] .sourceHead = true := by decide
def e826985605146 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826985605146 : Closed e826985605146 ∧ code e826985605146 = 9623078627354 := by decide
theorem cert_e826985605146 : check e826985605146 [] .sourceHead = true := by decide
def e826985633818 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826985633818 : Closed e826985633818 ∧ code e826985633818 = 9623078656026 := by decide
theorem cert_e826985633818 : check e826985633818 [] .sourceHead = true := by decide
def e826985637914 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826985637914 : Closed e826985637914 ∧ code e826985637914 = 9623078660122 := by decide
theorem cert_e826985637914 : check e826985637914 [] .sourceHead = true := by decide
def e826985920538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826985920538 : Closed e826985920538 ∧ code e826985920538 = 9623078942746 := by decide
theorem cert_e826985920538 : check e826985920538 [] .sourceHead = true := by decide
def e826985928730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826985928730 : Closed e826985928730 ∧ code e826985928730 = 9623078950938 := by decide
theorem cert_e826985928730 : check e826985928730 [] .sourceHead = true := by decide
def e826986313754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826986313754 : Closed e826986313754 ∧ code e826986313754 = 9623079335962 := by decide
theorem cert_e826986313754 : check e826986313754 [] .sourceHead = true := by decide
def e826986326042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826986326042 : Closed e826986326042 ∧ code e826986326042 = 9623079348250 := by decide
theorem cert_e826986326042 : check e826986326042 [] .sourceHead = true := by decide
def e826986518554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826986518554 : Closed e826986518554 ∧ code e826986518554 = 9623079540762 := by decide
theorem cert_e826986518554 : check e826986518554 [] .sourceHead = true := by decide
def e826986522650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826986522650 : Closed e826986522650 ∧ code e826986522650 = 9623079544858 := by decide
theorem cert_e826986522650 : check e826986522650 [] .sourceHead = true := by decide
def e826993896986 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826993896986 : Closed e826993896986 ∧ code e826993896986 = 9623086919194 := by decide
theorem cert_e826993896986 : check e826993896986 [] .sourceHead = true := by decide
def e826993899034 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826993899034 : Closed e826993899034 ∧ code e826993899034 = 9623086921242 := by decide
theorem cert_e826993899034 : check e826993899034 [] .sourceHead = true := by decide
def e826993913370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826993913370 : Closed e826993913370 ∧ code e826993913370 = 9623086935578 := by decide
theorem cert_e826993913370 : check e826993913370 [] .sourceHead = true := by decide
def e826993916442 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826993916442 : Closed e826993916442 ∧ code e826993916442 = 9623086938650 := by decide
theorem cert_e826993916442 : check e826993916442 [] .sourceHead = true := by decide
def e826993923610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826993923610 : Closed e826993923610 ∧ code e826993923610 = 9623086945818 := by decide
theorem cert_e826993923610 : check e826993923610 [] .sourceHead = true := by decide
def e826993924634 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826993924634 : Closed e826993924634 ∧ code e826993924634 = 9623086946842 := by decide
theorem cert_e826993924634 : check e826993924634 [] .sourceHead = true := by decide
def e826993978906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826993978906 : Closed e826993978906 ∧ code e826993978906 = 9623087001114 := by decide
theorem cert_e826993978906 : check e826993978906 [] .sourceHead = true := by decide
def e826993981978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826993981978 : Closed e826993981978 ∧ code e826993981978 = 9623087004186 := by decide
theorem cert_e826993981978 : check e826993981978 [] .sourceHead = true := by decide
def e826993994266 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826993994266 : Closed e826993994266 ∧ code e826993994266 = 9623087016474 := by decide
theorem cert_e826993994266 : check e826993994266 [] .sourceHead = true := by decide
def e826994021914 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994021914 : Closed e826994021914 ∧ code e826994021914 = 9623087044122 := by decide
theorem cert_e826994021914 : check e826994021914 [] .sourceHead = true := by decide
def e826994022938 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994022938 : Closed e826994022938 ∧ code e826994022938 = 9623087045146 := by decide
theorem cert_e826994022938 : check e826994022938 [] .sourceHead = true := by decide
def e826994027034 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994027034 : Closed e826994027034 ∧ code e826994027034 = 9623087049242 := by decide
theorem cert_e826994027034 : check e826994027034 [] .sourceHead = true := by decide
def e826994290202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994290202 : Closed e826994290202 ∧ code e826994290202 = 9623087312410 := by decide
theorem cert_e826994290202 : check e826994290202 [] .sourceHead = true := by decide
def e826994292250 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994292250 : Closed e826994292250 ∧ code e826994292250 = 9623087314458 := by decide
theorem cert_e826994292250 : check e826994292250 [] .sourceHead = true := by decide
def e826994306586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994306586 : Closed e826994306586 ∧ code e826994306586 = 9623087328794 := by decide
theorem cert_e826994306586 : check e826994306586 [] .sourceHead = true := by decide
def e826994309658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994309658 : Closed e826994309658 ∧ code e826994309658 = 9623087331866 := by decide
theorem cert_e826994309658 : check e826994309658 [] .sourceHead = true := by decide
def e826994316826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994316826 : Closed e826994316826 ∧ code e826994316826 = 9623087339034 := by decide
theorem cert_e826994316826 : check e826994316826 [] .sourceHead = true := by decide
def e826994317850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994317850 : Closed e826994317850 ∧ code e826994317850 = 9623087340058 := by decide
theorem cert_e826994317850 : check e826994317850 [] .sourceHead = true := by decide
def e826994388506 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994388506 : Closed e826994388506 ∧ code e826994388506 = 9623087410714 := by decide
theorem cert_e826994388506 : check e826994388506 [] .sourceHead = true := by decide
def e826994390554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994390554 : Closed e826994390554 ∧ code e826994390554 = 9623087412762 := by decide
theorem cert_e826994390554 : check e826994390554 [] .sourceHead = true := by decide
def e826994486810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994486810 : Closed e826994486810 ∧ code e826994486810 = 9623087509018 := by decide
theorem cert_e826994486810 : check e826994486810 [] .sourceHead = true := by decide
def e826994489882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994489882 : Closed e826994489882 ∧ code e826994489882 = 9623087512090 := by decide
theorem cert_e826994489882 : check e826994489882 [] .sourceHead = true := by decide
def e826994515994 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826994515994 : Closed e826994515994 ∧ code e826994515994 = 9623087538202 := by decide
theorem cert_e826994515994 : check e826994515994 [] .sourceHead = true := by decide
def e826994516086 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826994516086 : Closed e826994516086 ∧ code e826994516086 = 9623087538294 := by decide
theorem cert_e826994516086 : check e826994516086 [] .sourceHead = true := by decide
def e826994516330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826994516330 : Closed e826994516330 ∧ code e826994516330 = 9623087538538 := by decide
theorem cert_e826994516330 : check e826994516330 [] .sourceHead = true := by decide
def e826994516378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826994516378 : Closed e826994516378 ∧ code e826994516378 = 9623087538586 := by decide
theorem cert_e826994516378 : check e826994516378 [] .sourceHead = true := by decide
def e826994517530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826994517530 : Closed e826994517530 ∧ code e826994517530 = 9623087539738 := by decide
theorem cert_e826994517530 : check e826994517530 [] .sourceHead = true := by decide
def e826994538010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994538010 : Closed e826994538010 ∧ code e826994538010 = 9623087560218 := by decide
theorem cert_e826994538010 : check e826994538010 [] .sourceHead = true := by decide
def e826994539034 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994539034 : Closed e826994539034 ∧ code e826994539034 = 9623087561242 := by decide
theorem cert_e826994539034 : check e826994539034 [] .sourceHead = true := by decide
def e826994548762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826994548762 : Closed e826994548762 ∧ code e826994548762 = 9623087570970 := by decide
theorem cert_e826994548762 : check e826994548762 [] .sourceHead = true := by decide
def e826994548854 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826994548854 : Closed e826994548854 ∧ code e826994548854 = 9623087571062 := by decide
theorem cert_e826994548854 : check e826994548854 [] .sourceHead = true := by decide
def e826994549098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826994549098 : Closed e826994549098 ∧ code e826994549098 = 9623087571306 := by decide
theorem cert_e826994549098 : check e826994549098 [] .sourceHead = true := by decide
def e826994549146 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826994549146 : Closed e826994549146 ∧ code e826994549146 = 9623087571354 := by decide
theorem cert_e826994549146 : check e826994549146 [] .sourceHead = true := by decide
def e826994550298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826994550298 : Closed e826994550298 ∧ code e826994550298 = 9623087572506 := by decide
theorem cert_e826994550298 : check e826994550298 [] .sourceHead = true := by decide
def e826994699802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994699802 : Closed e826994699802 ∧ code e826994699802 = 9623087722010 := by decide
theorem cert_e826994699802 : check e826994699802 [] .sourceHead = true := by decide
def e826994702874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994702874 : Closed e826994702874 ∧ code e826994702874 = 9623087725082 := by decide
theorem cert_e826994702874 : check e826994702874 [] .sourceHead = true := by decide
def e826994715162 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994715162 : Closed e826994715162 ∧ code e826994715162 = 9623087737370 := by decide
theorem cert_e826994715162 : check e826994715162 [] .sourceHead = true := by decide
def e826994748954 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994748954 : Closed e826994748954 ∧ code e826994748954 = 9623087771162 := by decide
theorem cert_e826994748954 : check e826994748954 [] .sourceHead = true := by decide
def e826994752026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994752026 : Closed e826994752026 ∧ code e826994752026 = 9623087774234 := by decide
theorem cert_e826994752026 : check e826994752026 [] .sourceHead = true := by decide
def e826994778138 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826994778138 : Closed e826994778138 ∧ code e826994778138 = 9623087800346 := by decide
theorem cert_e826994778138 : check e826994778138 [] .sourceHead = true := by decide
def e826994778230 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826994778230 : Closed e826994778230 ∧ code e826994778230 = 9623087800438 := by decide
theorem cert_e826994778230 : check e826994778230 [] .sourceHead = true := by decide
def e826994778474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826994778474 : Closed e826994778474 ∧ code e826994778474 = 9623087800682 := by decide
theorem cert_e826994778474 : check e826994778474 [] .sourceHead = true := by decide
end Blc.Floor43
