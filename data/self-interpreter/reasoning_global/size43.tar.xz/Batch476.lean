import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407265002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422407265002 : Closed e2422407265002 ∧ code e2422407265002 = 11218500287210 := by decide
theorem cert_e2422407265002 : check e2422407265002 [[],[]] .sourceHead = true := by decide
def e2422407265110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422407265110 : Closed e2422407265110 ∧ code e2422407265110 = 11218500287318 := by decide
theorem cert_e2422407265110 : check e2422407265110 [[],[]] .chain = true := by decide
def e2422407265114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422407265114 : Closed e2422407265114 ∧ code e2422407265114 = 11218500287322 := by decide
theorem cert_e2422407265114 : check e2422407265114 [[],[]] .chain = true := by decide
def e2422407265130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422407265130 : Closed e2422407265130 ∧ code e2422407265130 = 11218500287338 := by decide
theorem cert_e2422407265130 : check e2422407265130 [[],[]] .chain = true := by decide
def e2422407265194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422407265194 : Closed e2422407265194 ∧ code e2422407265194 = 11218500287402 := by decide
theorem cert_e2422407265194 : check e2422407265194 [[],[]] .sourceHead = true := by decide
def e2422407266478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 2))))))
theorem wire_e2422407266478 : Closed e2422407266478 ∧ code e2422407266478 = 11218500288686 := by decide
theorem cert_e2422407266478 : check e2422407266478 [[],[]] .chain = true := by decide
def e2422407266490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 2)) (.var 0))))))
theorem wire_e2422407266490 : Closed e2422407266490 ∧ code e2422407266490 = 11218500288698 := by decide
theorem cert_e2422407266490 : check e2422407266490 [[],[]] .chain = true := by decide
def e2422407267054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)) (.var 2))))))
theorem wire_e2422407267054 : Closed e2422407267054 ∧ code e2422407267054 = 11218500289262 := by decide
theorem cert_e2422407267054 : check e2422407267054 [[],[]] .sourceHead = true := by decide
def e2422407267182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1)) (.var 2))))))
theorem wire_e2422407267182 : Closed e2422407267182 ∧ code e2422407267182 = 11218500289390 := by decide
theorem cert_e2422407267182 : check e2422407267182 [[],[]] .chain = true := by decide
def e2422407267190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2)) (.var 1))))))
theorem wire_e2422407267190 : Closed e2422407267190 ∧ code e2422407267190 = 11218500289398 := by decide
theorem cert_e2422407267190 : check e2422407267190 [[],[]] .chain = true := by decide
def e2422407267246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 0)) (.var 2))))))
theorem wire_e2422407267246 : Closed e2422407267246 ∧ code e2422407267246 = 11218500289454 := by decide
theorem cert_e2422407267246 : check e2422407267246 [[],[]] .chain = true := by decide
def e2422407267258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2)) (.var 0))))))
theorem wire_e2422407267258 : Closed e2422407267258 ∧ code e2422407267258 = 11218500289466 := by decide
theorem cert_e2422407267258 : check e2422407267258 [[],[]] .chain = true := by decide
def e2422407267306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0)) (.var 0))))))
theorem wire_e2422407267306 : Closed e2422407267306 ∧ code e2422407267306 = 11218500289514 := by decide
theorem cert_e2422407267306 : check e2422407267306 [[],[]] .chain = true := by decide
def e2422407268014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422407268014 : Closed e2422407268014 ∧ code e2422407268014 = 11218500290222 := by decide
theorem cert_e2422407268014 : check e2422407268014 [[],[]] .sourceHead = true := by decide
def e2422407268026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422407268026 : Closed e2422407268026 ∧ code e2422407268026 = 11218500290234 := by decide
theorem cert_e2422407268026 : check e2422407268026 [[],[]] .sourceHead = true := by decide
def e2422407268590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422407268590 : Closed e2422407268590 ∧ code e2422407268590 = 11218500290798 := by decide
theorem cert_e2422407268590 : check e2422407268590 [[],[]] .chain = true := by decide
def e2422407268598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422407268598 : Closed e2422407268598 ∧ code e2422407268598 = 11218500290806 := by decide
theorem cert_e2422407268598 : check e2422407268598 [[],[]] .chain = true := by decide
def e2422407268782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422407268782 : Closed e2422407268782 ∧ code e2422407268782 = 11218500290990 := by decide
theorem cert_e2422407268782 : check e2422407268782 [[],[]] .chain = true := by decide
def e2422407268794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422407268794 : Closed e2422407268794 ∧ code e2422407268794 = 11218500291002 := by decide
theorem cert_e2422407268794 : check e2422407268794 [[],[]] .chain = true := by decide
def e2422407268842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422407268842 : Closed e2422407268842 ∧ code e2422407268842 = 11218500291050 := by decide
theorem cert_e2422407268842 : check e2422407268842 [[],[]] .chain = true := by decide
def e2422407268974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407268974 : Closed e2422407268974 ∧ code e2422407268974 = 11218500291182 := by decide
theorem cert_e2422407268974 : check e2422407268974 [[],[]] .chain = true := by decide
def e2422407268986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407268986 : Closed e2422407268986 ∧ code e2422407268986 = 11218500291194 := by decide
theorem cert_e2422407268986 : check e2422407268986 [[],[]] .chain = true := by decide
def e2422407269150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422407269150 : Closed e2422407269150 ∧ code e2422407269150 = 11218500291358 := by decide
theorem cert_e2422407269150 : check e2422407269150 [[],[]] .chain = true := by decide
def e2422407269262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422407269262 : Closed e2422407269262 ∧ code e2422407269262 = 11218500291470 := by decide
theorem cert_e2422407269262 : check e2422407269262 [[],[]] .chain = true := by decide
def e2422407269274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407269274 : Closed e2422407269274 ∧ code e2422407269274 = 11218500291482 := by decide
theorem cert_e2422407269274 : check e2422407269274 [[],[]] .chain = true := by decide
def e2422407269486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422407269486 : Closed e2422407269486 ∧ code e2422407269486 = 11218500291694 := by decide
theorem cert_e2422407269486 : check e2422407269486 [[],[]] .chain = true := by decide
def e2422407269498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422407269498 : Closed e2422407269498 ∧ code e2422407269498 = 11218500291706 := by decide
theorem cert_e2422407269498 : check e2422407269498 [[],[]] .chain = true := by decide
def e2422407269662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422407269662 : Closed e2422407269662 ∧ code e2422407269662 = 11218500291870 := by decide
theorem cert_e2422407269662 : check e2422407269662 [[],[]] .chain = true := by decide
def e2422407269830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422407269830 : Closed e2422407269830 ∧ code e2422407269830 = 11218500292038 := by decide
theorem cert_e2422407269830 : check e2422407269830 [[],[]] .chain = true := by decide
def e2422407269934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422407269934 : Closed e2422407269934 ∧ code e2422407269934 = 11218500292142 := by decide
theorem cert_e2422407269934 : check e2422407269934 [[],[]] .chain = true := by decide
def e2422407270114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422407270114 : Closed e2422407270114 ∧ code e2422407270114 = 11218500292322 := by decide
theorem cert_e2422407270114 : check e2422407270114 [[],[]] .chain = true := by decide
def e2422407270126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 2))))))
theorem wire_e2422407270126 : Closed e2422407270126 ∧ code e2422407270126 = 11218500292334 := by decide
theorem cert_e2422407270126 : check e2422407270126 [[],[]] .sourceHead = true := by decide
def e2422407270166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422407270166 : Closed e2422407270166 ∧ code e2422407270166 = 11218500292374 := by decide
theorem cert_e2422407270166 : check e2422407270166 [[],[]] .chain = true := by decide
def e2422407270170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422407270170 : Closed e2422407270170 ∧ code e2422407270170 = 11218500292378 := by decide
theorem cert_e2422407270170 : check e2422407270170 [[],[]] .chain = true := by decide
def e2422407270214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422407270214 : Closed e2422407270214 ∧ code e2422407270214 = 11218500292422 := by decide
theorem cert_e2422407270214 : check e2422407270214 [[],[]] .chain = true := by decide
def e2422407270242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422407270242 : Closed e2422407270242 ∧ code e2422407270242 = 11218500292450 := by decide
theorem cert_e2422407270242 : check e2422407270242 [[],[]] .chain = true := by decide
def e2422407270254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 2))))))
theorem wire_e2422407270254 : Closed e2422407270254 ∧ code e2422407270254 = 11218500292462 := by decide
theorem cert_e2422407270254 : check e2422407270254 [[],[]] .sourceHead = true := by decide
def e2422407270262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 2)) (.var 1))))))
theorem wire_e2422407270262 : Closed e2422407270262 ∧ code e2422407270262 = 11218500292470 := by decide
theorem cert_e2422407270262 : check e2422407270262 [[],[]] .sourceHead = true := by decide
def e2422407272622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422407272622 : Closed e2422407272622 ∧ code e2422407272622 = 11218500294830 := by decide
theorem cert_e2422407272622 : check e2422407272622 [[],[]] .chain = true := by decide
def e2422407272634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422407272634 : Closed e2422407272634 ∧ code e2422407272634 = 11218500294842 := by decide
theorem cert_e2422407272634 : check e2422407272634 [[],[]] .chain = true := by decide
def e2422407273006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422407273006 : Closed e2422407273006 ∧ code e2422407273006 = 11218500295214 := by decide
theorem cert_e2422407273006 : check e2422407273006 [[],[]] .chain = true := by decide
def e2422407273186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422407273186 : Closed e2422407273186 ∧ code e2422407273186 = 11218500295394 := by decide
theorem cert_e2422407273186 : check e2422407273186 [[],[]] .chain = true := by decide
def e2422407273198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)) (.var 2))))))
theorem wire_e2422407273198 : Closed e2422407273198 ∧ code e2422407273198 = 11218500295406 := by decide
theorem cert_e2422407273198 : check e2422407273198 [[],[]] .sourceHead = true := by decide
def e2422407273326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422407273326 : Closed e2422407273326 ∧ code e2422407273326 = 11218500295534 := by decide
theorem cert_e2422407273326 : check e2422407273326 [[],[]] .chain = true := by decide
def e2422407273334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422407273334 : Closed e2422407273334 ∧ code e2422407273334 = 11218500295542 := by decide
theorem cert_e2422407273334 : check e2422407273334 [[],[]] .chain = true := by decide
def e2422407273354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407273354 : Closed e2422407273354 ∧ code e2422407273354 = 11218500295562 := by decide
theorem cert_e2422407273354 : check e2422407273354 [[],[]] .chain = true := by decide
def e2422407273378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407273378 : Closed e2422407273378 ∧ code e2422407273378 = 11218500295586 := by decide
theorem cert_e2422407273378 : check e2422407273378 [[],[]] .chain = true := by decide
def e2422407273390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422407273390 : Closed e2422407273390 ∧ code e2422407273390 = 11218500295598 := by decide
theorem cert_e2422407273390 : check e2422407273390 [[],[]] .sourceHead = true := by decide
def e2422407273398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e2422407273398 : Closed e2422407273398 ∧ code e2422407273398 = 11218500295606 := by decide
theorem cert_e2422407273398 : check e2422407273398 [[],[]] .chain = true := by decide
def e2422407273402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422407273402 : Closed e2422407273402 ∧ code e2422407273402 = 11218500295610 := by decide
theorem cert_e2422407273402 : check e2422407273402 [[],[]] .sourceHead = true := by decide
def e2422407273838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422407273838 : Closed e2422407273838 ∧ code e2422407273838 = 11218500296046 := by decide
theorem cert_e2422407273838 : check e2422407273838 [[],[]] .chain = true := by decide
def e2422407273846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422407273846 : Closed e2422407273846 ∧ code e2422407273846 = 11218500296054 := by decide
theorem cert_e2422407273846 : check e2422407273846 [[],[]] .chain = true := by decide
def e2422407273902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2422407273902 : Closed e2422407273902 ∧ code e2422407273902 = 11218500296110 := by decide
theorem cert_e2422407273902 : check e2422407273902 [[],[]] .chain = true := by decide
def e2422407273914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2422407273914 : Closed e2422407273914 ∧ code e2422407273914 = 11218500296122 := by decide
theorem cert_e2422407273914 : check e2422407273914 [[],[]] .chain = true := by decide
def e2422407273942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422407273942 : Closed e2422407273942 ∧ code e2422407273942 = 11218500296150 := by decide
theorem cert_e2422407273942 : check e2422407273942 [[],[]] .chain = true := by decide
def e2422407273946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422407273946 : Closed e2422407273946 ∧ code e2422407273946 = 11218500296154 := by decide
theorem cert_e2422407273946 : check e2422407273946 [[],[]] .chain = true := by decide
def e2422407274026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422407274026 : Closed e2422407274026 ∧ code e2422407274026 = 11218500296234 := by decide
theorem cert_e2422407274026 : check e2422407274026 [[],[]] .chain = true := by decide
def e2422407274122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407274122 : Closed e2422407274122 ∧ code e2422407274122 = 11218500296330 := by decide
theorem cert_e2422407274122 : check e2422407274122 [[],[]] .chain = true := by decide
def e2422407274146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407274146 : Closed e2422407274146 ∧ code e2422407274146 = 11218500296354 := by decide
theorem cert_e2422407274146 : check e2422407274146 [[],[]] .chain = true := by decide
def e2422407274158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422407274158 : Closed e2422407274158 ∧ code e2422407274158 = 11218500296366 := by decide
theorem cert_e2422407274158 : check e2422407274158 [[],[]] .sourceHead = true := by decide
def e2422407274166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e2422407274166 : Closed e2422407274166 ∧ code e2422407274166 = 11218500296374 := by decide
theorem cert_e2422407274166 : check e2422407274166 [[],[]] .chain = true := by decide
def e2422407274170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422407274170 : Closed e2422407274170 ∧ code e2422407274170 = 11218500296378 := by decide
theorem cert_e2422407274170 : check e2422407274170 [[],[]] .sourceHead = true := by decide
def e2422407274198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2422407274198 : Closed e2422407274198 ∧ code e2422407274198 = 11218500296406 := by decide
theorem cert_e2422407274198 : check e2422407274198 [[],[]] .chain = true := by decide
def e2422407274202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2422407274202 : Closed e2422407274202 ∧ code e2422407274202 = 11218500296410 := by decide
theorem cert_e2422407274202 : check e2422407274202 [[],[]] .chain = true := by decide
def e2422407274218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422407274218 : Closed e2422407274218 ∧ code e2422407274218 = 11218500296426 := by decide
theorem cert_e2422407274218 : check e2422407274218 [[],[]] .sourceHead = true := by decide
def e2422407274542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407274542 : Closed e2422407274542 ∧ code e2422407274542 = 11218500296750 := by decide
theorem cert_e2422407274542 : check e2422407274542 [[],[]] .chain = true := by decide
def e2422407274734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422407274734 : Closed e2422407274734 ∧ code e2422407274734 = 11218500296942 := by decide
theorem cert_e2422407274734 : check e2422407274734 [[],[]] .chain = true := by decide
def e2422407274746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2422407274746 : Closed e2422407274746 ∧ code e2422407274746 = 11218500296954 := by decide
theorem cert_e2422407274746 : check e2422407274746 [[],[]] .chain = true := by decide
def e2422407274926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422407274926 : Closed e2422407274926 ∧ code e2422407274926 = 11218500297134 := by decide
theorem cert_e2422407274926 : check e2422407274926 [[],[]] .sourceHead = true := by decide
def e2422407275118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407275118 : Closed e2422407275118 ∧ code e2422407275118 = 11218500297326 := by decide
theorem cert_e2422407275118 : check e2422407275118 [[],[]] .chain = true := by decide
def e2422407275130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407275130 : Closed e2422407275130 ∧ code e2422407275130 = 11218500297338 := by decide
theorem cert_e2422407275130 : check e2422407275130 [[],[]] .chain = true := by decide
def e2422407275294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422407275294 : Closed e2422407275294 ∧ code e2422407275294 = 11218500297502 := by decide
theorem cert_e2422407275294 : check e2422407275294 [[],[]] .chain = true := by decide
def e2422407275462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2422407275462 : Closed e2422407275462 ∧ code e2422407275462 = 11218500297670 := by decide
theorem cert_e2422407275462 : check e2422407275462 [[],[]] .chain = true := by decide
def e2422407276078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422407276078 : Closed e2422407276078 ∧ code e2422407276078 = 11218500298286 := by decide
theorem cert_e2422407276078 : check e2422407276078 [[],[]] .chain = true := by decide
def e2422407276258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422407276258 : Closed e2422407276258 ∧ code e2422407276258 = 11218500298466 := by decide
theorem cert_e2422407276258 : check e2422407276258 [[],[]] .chain = true := by decide
def e2422407276270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2422407276270 : Closed e2422407276270 ∧ code e2422407276270 = 11218500298478 := by decide
theorem cert_e2422407276270 : check e2422407276270 [[],[]] .sourceHead = true := by decide
def e2422407276398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2422407276398 : Closed e2422407276398 ∧ code e2422407276398 = 11218500298606 := by decide
theorem cert_e2422407276398 : check e2422407276398 [[],[]] .chain = true := by decide
def e2422407276406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2422407276406 : Closed e2422407276406 ∧ code e2422407276406 = 11218500298614 := by decide
theorem cert_e2422407276406 : check e2422407276406 [[],[]] .chain = true := by decide
def e2422407276426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407276426 : Closed e2422407276426 ∧ code e2422407276426 = 11218500298634 := by decide
theorem cert_e2422407276426 : check e2422407276426 [[],[]] .chain = true := by decide
def e2422407276450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407276450 : Closed e2422407276450 ∧ code e2422407276450 = 11218500298658 := by decide
theorem cert_e2422407276450 : check e2422407276450 [[],[]] .chain = true := by decide
def e2422407276462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2422407276462 : Closed e2422407276462 ∧ code e2422407276462 = 11218500298670 := by decide
theorem cert_e2422407276462 : check e2422407276462 [[],[]] .sourceHead = true := by decide
def e2422407276470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2422407276470 : Closed e2422407276470 ∧ code e2422407276470 = 11218500298678 := by decide
theorem cert_e2422407276470 : check e2422407276470 [[],[]] .chain = true := by decide
def e2422407276474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2422407276474 : Closed e2422407276474 ∧ code e2422407276474 = 11218500298682 := by decide
theorem cert_e2422407276474 : check e2422407276474 [[],[]] .sourceHead = true := by decide
def e2422407276606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2422407276606 : Closed e2422407276606 ∧ code e2422407276606 = 11218500298814 := by decide
theorem cert_e2422407276606 : check e2422407276606 [[],[]] .chain = true := by decide
def e2422407277026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407277026 : Closed e2422407277026 ∧ code e2422407277026 = 11218500299234 := by decide
theorem cert_e2422407277026 : check e2422407277026 [[],[]] .chain = true := by decide
def e2422407277038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407277038 : Closed e2422407277038 ∧ code e2422407277038 = 11218500299246 := by decide
theorem cert_e2422407277038 : check e2422407277038 [[],[]] .sourceHead = true := by decide
def e2422407277806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407277806 : Closed e2422407277806 ∧ code e2422407277806 = 11218500300014 := by decide
theorem cert_e2422407277806 : check e2422407277806 [[],[]] .chain = true := by decide
def e2422407277814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407277814 : Closed e2422407277814 ∧ code e2422407277814 = 11218500300022 := by decide
theorem cert_e2422407277814 : check e2422407277814 [[],[]] .chain = true := by decide
def e2422407278082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407278082 : Closed e2422407278082 ∧ code e2422407278082 = 11218500300290 := by decide
theorem cert_e2422407278082 : check e2422407278082 [[],[]] .chain = true := by decide
def e2422407278094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2422407278094 : Closed e2422407278094 ∧ code e2422407278094 = 11218500300302 := by decide
theorem cert_e2422407278094 : check e2422407278094 [[],[]] .chain = true := by decide
def e2422407278106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407278106 : Closed e2422407278106 ∧ code e2422407278106 = 11218500300314 := by decide
theorem cert_e2422407278106 : check e2422407278106 [[],[]] .sourceHead = true := by decide
def e2422407278178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407278178 : Closed e2422407278178 ∧ code e2422407278178 = 11218500300386 := by decide
theorem cert_e2422407278178 : check e2422407278178 [[],[]] .chain = true := by decide
def e2422407278190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407278190 : Closed e2422407278190 ∧ code e2422407278190 = 11218500300398 := by decide
theorem cert_e2422407278190 : check e2422407278190 [[],[]] .sourceHead = true := by decide
def e2422407278198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407278198 : Closed e2422407278198 ∧ code e2422407278198 = 11218500300406 := by decide
theorem cert_e2422407278198 : check e2422407278198 [[],[]] .chain = true := by decide
def e2422407278202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407278202 : Closed e2422407278202 ∧ code e2422407278202 = 11218500300410 := by decide
theorem cert_e2422407278202 : check e2422407278202 [[],[]] .sourceHead = true := by decide
def e2422407278702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422407278702 : Closed e2422407278702 ∧ code e2422407278702 = 11218500300910 := by decide
theorem cert_e2422407278702 : check e2422407278702 [[],[]] .chain = true := by decide
def e2422407278878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422407278878 : Closed e2422407278878 ∧ code e2422407278878 = 11218500301086 := by decide
theorem cert_e2422407278878 : check e2422407278878 [[],[]] .chain = true := by decide
def e2422407279074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e2422407279074 : Closed e2422407279074 ∧ code e2422407279074 = 11218500301282 := by decide
theorem cert_e2422407279074 : check e2422407279074 [[],[]] .chain = true := by decide
def e2422407279086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 2))))))
theorem wire_e2422407279086 : Closed e2422407279086 ∧ code e2422407279086 = 11218500301294 := by decide
theorem cert_e2422407279086 : check e2422407279086 [[],[]] .sourceHead = true := by decide
def e2422407279470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422407279470 : Closed e2422407279470 ∧ code e2422407279470 = 11218500301678 := by decide
theorem cert_e2422407279470 : check e2422407279470 [[],[]] .chain = true := by decide
def e2422407279478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422407279478 : Closed e2422407279478 ∧ code e2422407279478 = 11218500301686 := by decide
theorem cert_e2422407279478 : check e2422407279478 [[],[]] .chain = true := by decide
def e2422407279534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422407279534 : Closed e2422407279534 ∧ code e2422407279534 = 11218500301742 := by decide
theorem cert_e2422407279534 : check e2422407279534 [[],[]] .chain = true := by decide
def e2422407279546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422407279546 : Closed e2422407279546 ∧ code e2422407279546 = 11218500301754 := by decide
theorem cert_e2422407279546 : check e2422407279546 [[],[]] .chain = true := by decide
def e2422407279574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422407279574 : Closed e2422407279574 ∧ code e2422407279574 = 11218500301782 := by decide
theorem cert_e2422407279574 : check e2422407279574 [[],[]] .chain = true := by decide
def e2422407279578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422407279578 : Closed e2422407279578 ∧ code e2422407279578 = 11218500301786 := by decide
theorem cert_e2422407279578 : check e2422407279578 [[],[]] .chain = true := by decide
def e2422407279854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407279854 : Closed e2422407279854 ∧ code e2422407279854 = 11218500302062 := by decide
theorem cert_e2422407279854 : check e2422407279854 [[],[]] .chain = true := by decide
def e2422407279862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407279862 : Closed e2422407279862 ∧ code e2422407279862 = 11218500302070 := by decide
theorem cert_e2422407279862 : check e2422407279862 [[],[]] .chain = true := by decide
def e2422407280238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407280238 : Closed e2422407280238 ∧ code e2422407280238 = 11218500302446 := by decide
theorem cert_e2422407280238 : check e2422407280238 [[],[]] .chain = true := by decide
def e2422407280250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407280250 : Closed e2422407280250 ∧ code e2422407280250 = 11218500302458 := by decide
theorem cert_e2422407280250 : check e2422407280250 [[],[]] .chain = true := by decide
def e2422407280390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e2422407280390 : Closed e2422407280390 ∧ code e2422407280390 = 11218500302598 := by decide
theorem cert_e2422407280390 : check e2422407280390 [[],[]] .chain = true := by decide
def e2422407280414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 3)))))))
theorem wire_e2422407280414 : Closed e2422407280414 ∧ code e2422407280414 = 11218500302622 := by decide
theorem cert_e2422407280414 : check e2422407280414 [[],[]] .sourceHead = true := by decide
def e2422407280438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407280438 : Closed e2422407280438 ∧ code e2422407280438 = 11218500302646 := by decide
theorem cert_e2422407280438 : check e2422407280438 [[],[]] .chain = true := by decide
def e2422407280442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407280442 : Closed e2422407280442 ∧ code e2422407280442 = 11218500302650 := by decide
theorem cert_e2422407280442 : check e2422407280442 [[],[]] .chain = true := by decide
def e2422407280650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407280650 : Closed e2422407280650 ∧ code e2422407280650 = 11218500302858 := by decide
theorem cert_e2422407280650 : check e2422407280650 [[],[]] .chain = true := by decide
def e2422407280686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422407280686 : Closed e2422407280686 ∧ code e2422407280686 = 11218500302894 := by decide
theorem cert_e2422407280686 : check e2422407280686 [[],[]] .sourceHead = true := by decide
def e2422407280694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407280694 : Closed e2422407280694 ∧ code e2422407280694 = 11218500302902 := by decide
theorem cert_e2422407280694 : check e2422407280694 [[],[]] .chain = true := by decide
def e2422407280698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407280698 : Closed e2422407280698 ∧ code e2422407280698 = 11218500302906 := by decide
theorem cert_e2422407280698 : check e2422407280698 [[],[]] .chain = true := by decide
def e2422407280746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422407280746 : Closed e2422407280746 ∧ code e2422407280746 = 11218500302954 := by decide
theorem cert_e2422407280746 : check e2422407280746 [[],[]] .sourceHead = true := by decide
def e2422407280782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407280782 : Closed e2422407280782 ∧ code e2422407280782 = 11218500302990 := by decide
theorem cert_e2422407280782 : check e2422407280782 [[],[]] .chain = true := by decide
def e2422407280794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407280794 : Closed e2422407280794 ∧ code e2422407280794 = 11218500303002 := by decide
theorem cert_e2422407280794 : check e2422407280794 [[],[]] .chain = true := by decide
def e2422407280838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407280838 : Closed e2422407280838 ∧ code e2422407280838 = 11218500303046 := by decide
theorem cert_e2422407280838 : check e2422407280838 [[],[]] .chain = true := by decide
def e2422407280866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422407280866 : Closed e2422407280866 ∧ code e2422407280866 = 11218500303074 := by decide
theorem cert_e2422407280866 : check e2422407280866 [[],[]] .chain = true := by decide
def e2422407280878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422407280878 : Closed e2422407280878 ∧ code e2422407280878 = 11218500303086 := by decide
theorem cert_e2422407280878 : check e2422407280878 [[],[]] .sourceHead = true := by decide
def e2422407280886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422407280886 : Closed e2422407280886 ∧ code e2422407280886 = 11218500303094 := by decide
theorem cert_e2422407280886 : check e2422407280886 [[],[]] .sourceHead = true := by decide
def e2422407281034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407281034 : Closed e2422407281034 ∧ code e2422407281034 = 11218500303242 := by decide
theorem cert_e2422407281034 : check e2422407281034 [[],[]] .chain = true := by decide
def e2422407281058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407281058 : Closed e2422407281058 ∧ code e2422407281058 = 11218500303266 := by decide
theorem cert_e2422407281058 : check e2422407281058 [[],[]] .chain = true := by decide
def e2422407281070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422407281070 : Closed e2422407281070 ∧ code e2422407281070 = 11218500303278 := by decide
theorem cert_e2422407281070 : check e2422407281070 [[],[]] .sourceHead = true := by decide
def e2422407281078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422407281078 : Closed e2422407281078 ∧ code e2422407281078 = 11218500303286 := by decide
theorem cert_e2422407281078 : check e2422407281078 [[],[]] .chain = true := by decide
def e2422407281082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422407281082 : Closed e2422407281082 ∧ code e2422407281082 = 11218500303290 := by decide
theorem cert_e2422407281082 : check e2422407281082 [[],[]] .sourceHead = true := by decide
def e2422407281110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422407281110 : Closed e2422407281110 ∧ code e2422407281110 = 11218500303318 := by decide
theorem cert_e2422407281110 : check e2422407281110 [[],[]] .chain = true := by decide
def e2422407281114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422407281114 : Closed e2422407281114 ∧ code e2422407281114 = 11218500303322 := by decide
theorem cert_e2422407281114 : check e2422407281114 [[],[]] .chain = true := by decide
def e2422407281130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422407281130 : Closed e2422407281130 ∧ code e2422407281130 = 11218500303338 := by decide
theorem cert_e2422407281130 : check e2422407281130 [[],[]] .sourceHead = true := by decide
def e2422407281154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407281154 : Closed e2422407281154 ∧ code e2422407281154 = 11218500303362 := by decide
theorem cert_e2422407281154 : check e2422407281154 [[],[]] .chain = true := by decide
def e2422407281166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422407281166 : Closed e2422407281166 ∧ code e2422407281166 = 11218500303374 := by decide
theorem cert_e2422407281166 : check e2422407281166 [[],[]] .chain = true := by decide
def e2422407281178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407281178 : Closed e2422407281178 ∧ code e2422407281178 = 11218500303386 := by decide
theorem cert_e2422407281178 : check e2422407281178 [[],[]] .sourceHead = true := by decide
def e2422407281250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407281250 : Closed e2422407281250 ∧ code e2422407281250 = 11218500303458 := by decide
theorem cert_e2422407281250 : check e2422407281250 [[],[]] .chain = true := by decide
def e2422407281262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407281262 : Closed e2422407281262 ∧ code e2422407281262 = 11218500303470 := by decide
theorem cert_e2422407281262 : check e2422407281262 [[],[]] .sourceHead = true := by decide
def e2422407281270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407281270 : Closed e2422407281270 ∧ code e2422407281270 = 11218500303478 := by decide
theorem cert_e2422407281270 : check e2422407281270 [[],[]] .chain = true := by decide
def e2422407281274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407281274 : Closed e2422407281274 ∧ code e2422407281274 = 11218500303482 := by decide
theorem cert_e2422407281274 : check e2422407281274 [[],[]] .sourceHead = true := by decide
def e2422407281414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422407281414 : Closed e2422407281414 ∧ code e2422407281414 = 11218500303622 := by decide
theorem cert_e2422407281414 : check e2422407281414 [[],[]] .chain = true := by decide
def e2422407281438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422407281438 : Closed e2422407281438 ∧ code e2422407281438 = 11218500303646 := by decide
theorem cert_e2422407281438 : check e2422407281438 [[],[]] .sourceHead = true := by decide
def e2422407281462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407281462 : Closed e2422407281462 ∧ code e2422407281462 = 11218500303670 := by decide
theorem cert_e2422407281462 : check e2422407281462 [[],[]] .chain = true := by decide
def e2422407281466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407281466 : Closed e2422407281466 ∧ code e2422407281466 = 11218500303674 := by decide
theorem cert_e2422407281466 : check e2422407281466 [[],[]] .chain = true := by decide
def e2422407281538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422407281538 : Closed e2422407281538 ∧ code e2422407281538 = 11218500303746 := by decide
theorem cert_e2422407281538 : check e2422407281538 [[],[]] .sourceHead = true := by decide
def e2422407281550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422407281550 : Closed e2422407281550 ∧ code e2422407281550 = 11218500303758 := by decide
theorem cert_e2422407281550 : check e2422407281550 [[],[]] .sourceHead = true := by decide
def e2422407281562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407281562 : Closed e2422407281562 ∧ code e2422407281562 = 11218500303770 := by decide
theorem cert_e2422407281562 : check e2422407281562 [[],[]] .sourceHead = true := by decide
def e2422407283118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0)) (.var 2))))))
theorem wire_e2422407283118 : Closed e2422407283118 ∧ code e2422407283118 = 11218500305326 := by decide
theorem cert_e2422407283118 : check e2422407283118 [[],[]] .chain = true := by decide
def e2422407283130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 2)) (.var 0))))))
theorem wire_e2422407283130 : Closed e2422407283130 ∧ code e2422407283130 = 11218500305338 := by decide
theorem cert_e2422407283130 : check e2422407283130 [[],[]] .chain = true := by decide
def e2422407283822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422407283822 : Closed e2422407283822 ∧ code e2422407283822 = 11218500306030 := by decide
theorem cert_e2422407283822 : check e2422407283822 [[],[]] .chain = true := by decide
def e2422407283834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422407283834 : Closed e2422407283834 ∧ code e2422407283834 = 11218500306042 := by decide
theorem cert_e2422407283834 : check e2422407283834 [[],[]] .chain = true := by decide
def e2422407283998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422407283998 : Closed e2422407283998 ∧ code e2422407283998 = 11218500306206 := by decide
theorem cert_e2422407283998 : check e2422407283998 [[],[]] .chain = true := by decide
def e2422407284166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422407284166 : Closed e2422407284166 ∧ code e2422407284166 = 11218500306374 := by decide
theorem cert_e2422407284166 : check e2422407284166 [[],[]] .chain = true := by decide
def e2422407284270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422407284270 : Closed e2422407284270 ∧ code e2422407284270 = 11218500306478 := by decide
theorem cert_e2422407284270 : check e2422407284270 [[],[]] .chain = true := by decide
def e2422407284450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422407284450 : Closed e2422407284450 ∧ code e2422407284450 = 11218500306658 := by decide
theorem cert_e2422407284450 : check e2422407284450 [[],[]] .chain = true := by decide
def e2422407284462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 2))))))
theorem wire_e2422407284462 : Closed e2422407284462 ∧ code e2422407284462 = 11218500306670 := by decide
theorem cert_e2422407284462 : check e2422407284462 [[],[]] .sourceHead = true := by decide
def e2422407284618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407284618 : Closed e2422407284618 ∧ code e2422407284618 = 11218500306826 := by decide
theorem cert_e2422407284618 : check e2422407284618 [[],[]] .chain = true := by decide
def e2422407284642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407284642 : Closed e2422407284642 ∧ code e2422407284642 = 11218500306850 := by decide
theorem cert_e2422407284642 : check e2422407284642 [[],[]] .chain = true := by decide
def e2422407284654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e2422407284654 : Closed e2422407284654 ∧ code e2422407284654 = 11218500306862 := by decide
theorem cert_e2422407284654 : check e2422407284654 [[],[]] .sourceHead = true := by decide
def e2422407284666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e2422407284666 : Closed e2422407284666 ∧ code e2422407284666 = 11218500306874 := by decide
theorem cert_e2422407284666 : check e2422407284666 [[],[]] .sourceHead = true := by decide
def e2422407286126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422407286126 : Closed e2422407286126 ∧ code e2422407286126 = 11218500308334 := by decide
theorem cert_e2422407286126 : check e2422407286126 [[],[]] .chain = true := by decide
end Blc.Floor43
