import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372886766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422372886766 : Closed e2422372886766 ∧ code e2422372886766 = 11218465908974 := by decide
theorem cert_e2422372886766 : check e2422372886766 [[],[]] .smaller = true := by decide
def e2422372886774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422372886774 : Closed e2422372886774 ∧ code e2422372886774 = 11218465908982 := by decide
theorem cert_e2422372886774 : check e2422372886774 [[],[]] .smaller = true := by decide
def e2422372886778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422372886778 : Closed e2422372886778 ∧ code e2422372886778 = 11218465908986 := by decide
theorem cert_e2422372886778 : check e2422372886778 [[],[]] .three = true := by decide
def e2422372886958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422372886958 : Closed e2422372886958 ∧ code e2422372886958 = 11218465909166 := by decide
theorem cert_e2422372886958 : check e2422372886958 [[],[]] .smaller = true := by decide
def e2422372886970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422372886970 : Closed e2422372886970 ∧ code e2422372886970 = 11218465909178 := by decide
theorem cert_e2422372886970 : check e2422372886970 [[],[]] .smaller = true := by decide
def e2422372887018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422372887018 : Closed e2422372887018 ∧ code e2422372887018 = 11218465909226 := by decide
theorem cert_e2422372887018 : check e2422372887018 [[],[]] .smaller = true := by decide
def e2422372887102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422372887102 : Closed e2422372887102 ∧ code e2422372887102 = 11218465909310 := by decide
theorem cert_e2422372887102 : check e2422372887102 [[],[]] .three = true := by decide
def e2422372887150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372887150 : Closed e2422372887150 ∧ code e2422372887150 = 11218465909358 := by decide
theorem cert_e2422372887150 : check e2422372887150 [[],[]] .smaller = true := by decide
def e2422372887162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372887162 : Closed e2422372887162 ∧ code e2422372887162 = 11218465909370 := by decide
theorem cert_e2422372887162 : check e2422372887162 [[],[]] .smaller = true := by decide
def e2422372887326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422372887326 : Closed e2422372887326 ∧ code e2422372887326 = 11218465909534 := by decide
theorem cert_e2422372887326 : check e2422372887326 [[],[]] .smaller = true := by decide
def e2422372887426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372887426 : Closed e2422372887426 ∧ code e2422372887426 = 11218465909634 := by decide
theorem cert_e2422372887426 : check e2422372887426 [[],[]] .smaller = true := by decide
def e2422372887438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422372887438 : Closed e2422372887438 ∧ code e2422372887438 = 11218465909646 := by decide
theorem cert_e2422372887438 : check e2422372887438 [[],[]] .smaller = true := by decide
def e2422372887450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372887450 : Closed e2422372887450 ∧ code e2422372887450 = 11218465909658 := by decide
theorem cert_e2422372887450 : check e2422372887450 [[],[]] .smaller = true := by decide
def e2422372887494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422372887494 : Closed e2422372887494 ∧ code e2422372887494 = 11218465909702 := by decide
theorem cert_e2422372887494 : check e2422372887494 [[],[]] .three = true := by decide
def e2422372887518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)) (.var 3)))))))
theorem wire_e2422372887518 : Closed e2422372887518 ∧ code e2422372887518 = 11218465909726 := by decide
theorem cert_e2422372887518 : check e2422372887518 [[],[]] .three = true := by decide
def e2422372887646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372887646 : Closed e2422372887646 ∧ code e2422372887646 = 11218465909854 := by decide
theorem cert_e2422372887646 : check e2422372887646 [[],[]] .three = true := by decide
def e2422372887662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422372887662 : Closed e2422372887662 ∧ code e2422372887662 = 11218465909870 := by decide
theorem cert_e2422372887662 : check e2422372887662 [[],[]] .smaller = true := by decide
def e2422372887674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422372887674 : Closed e2422372887674 ∧ code e2422372887674 = 11218465909882 := by decide
theorem cert_e2422372887674 : check e2422372887674 [[],[]] .smaller = true := by decide
def e2422372887838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422372887838 : Closed e2422372887838 ∧ code e2422372887838 = 11218465910046 := by decide
theorem cert_e2422372887838 : check e2422372887838 [[],[]] .smaller = true := by decide
def e2422372888006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422372888006 : Closed e2422372888006 ∧ code e2422372888006 = 11218465910214 := by decide
theorem cert_e2422372888006 : check e2422372888006 [[],[]] .smaller = true := by decide
def e2422372888030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e2422372888030 : Closed e2422372888030 ∧ code e2422372888030 = 11218465910238 := by decide
theorem cert_e2422372888030 : check e2422372888030 [[],[]] .three = true := by decide
def e2422372888034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372888034 : Closed e2422372888034 ∧ code e2422372888034 = 11218465910242 := by decide
theorem cert_e2422372888034 : check e2422372888034 [[],[]] .three = true := by decide
def e2422372888046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e2422372888046 : Closed e2422372888046 ∧ code e2422372888046 = 11218465910254 := by decide
theorem cert_e2422372888046 : check e2422372888046 [[],[]] .three = true := by decide
def e2422372888074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372888074 : Closed e2422372888074 ∧ code e2422372888074 = 11218465910282 := by decide
theorem cert_e2422372888074 : check e2422372888074 [[],[]] .smaller = true := by decide
def e2422372888110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372888110 : Closed e2422372888110 ∧ code e2422372888110 = 11218465910318 := by decide
theorem cert_e2422372888110 : check e2422372888110 [[],[]] .smaller = true := by decide
def e2422372888118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372888118 : Closed e2422372888118 ∧ code e2422372888118 = 11218465910326 := by decide
theorem cert_e2422372888118 : check e2422372888118 [[],[]] .smaller = true := by decide
def e2422372888122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372888122 : Closed e2422372888122 ∧ code e2422372888122 = 11218465910330 := by decide
theorem cert_e2422372888122 : check e2422372888122 [[],[]] .smaller = true := by decide
def e2422372888170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372888170 : Closed e2422372888170 ∧ code e2422372888170 = 11218465910378 := by decide
theorem cert_e2422372888170 : check e2422372888170 [[],[]] .smaller = true := by decide
def e2422372888194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372888194 : Closed e2422372888194 ∧ code e2422372888194 = 11218465910402 := by decide
theorem cert_e2422372888194 : check e2422372888194 [[],[]] .smaller = true := by decide
def e2422372888206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372888206 : Closed e2422372888206 ∧ code e2422372888206 = 11218465910414 := by decide
theorem cert_e2422372888206 : check e2422372888206 [[],[]] .smaller = true := by decide
def e2422372888218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372888218 : Closed e2422372888218 ∧ code e2422372888218 = 11218465910426 := by decide
theorem cert_e2422372888218 : check e2422372888218 [[],[]] .smaller = true := by decide
def e2422372888262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372888262 : Closed e2422372888262 ∧ code e2422372888262 = 11218465910470 := by decide
theorem cert_e2422372888262 : check e2422372888262 [[],[]] .smaller = true := by decide
def e2422372888286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 3)))))))
theorem wire_e2422372888286 : Closed e2422372888286 ∧ code e2422372888286 = 11218465910494 := by decide
theorem cert_e2422372888286 : check e2422372888286 [[],[]] .three = true := by decide
def e2422372888290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372888290 : Closed e2422372888290 ∧ code e2422372888290 = 11218465910498 := by decide
theorem cert_e2422372888290 : check e2422372888290 [[],[]] .smaller = true := by decide
def e2422372888302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 2)))))))
theorem wire_e2422372888302 : Closed e2422372888302 ∧ code e2422372888302 = 11218465910510 := by decide
theorem cert_e2422372888302 : check e2422372888302 [[],[]] .smaller = true := by decide
def e2422372888310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3)) (.var 1)))))))
theorem wire_e2422372888310 : Closed e2422372888310 ∧ code e2422372888310 = 11218465910518 := by decide
theorem cert_e2422372888310 : check e2422372888310 [[],[]] .three = true := by decide
def e2422372888342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372888342 : Closed e2422372888342 ∧ code e2422372888342 = 11218465910550 := by decide
theorem cert_e2422372888342 : check e2422372888342 [[],[]] .three = true := by decide
def e2422372888346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372888346 : Closed e2422372888346 ∧ code e2422372888346 = 11218465910554 := by decide
theorem cert_e2422372888346 : check e2422372888346 [[],[]] .three = true := by decide
def e2422372888390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372888390 : Closed e2422372888390 ∧ code e2422372888390 = 11218465910598 := by decide
theorem cert_e2422372888390 : check e2422372888390 [[],[]] .three = true := by decide
def e2422372888414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)) (.var 3)))))))
theorem wire_e2422372888414 : Closed e2422372888414 ∧ code e2422372888414 = 11218465910622 := by decide
theorem cert_e2422372888414 : check e2422372888414 [[],[]] .three = true := by decide
def e2422372888418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372888418 : Closed e2422372888418 ∧ code e2422372888418 = 11218465910626 := by decide
theorem cert_e2422372888418 : check e2422372888418 [[],[]] .three = true := by decide
def e2422372888430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e2422372888430 : Closed e2422372888430 ∧ code e2422372888430 = 11218465910638 := by decide
theorem cert_e2422372888430 : check e2422372888430 [[],[]] .three = true := by decide
def e2422372888438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e2422372888438 : Closed e2422372888438 ∧ code e2422372888438 = 11218465910646 := by decide
theorem cert_e2422372888438 : check e2422372888438 [[],[]] .three = true := by decide
def e2422372888442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 3)) (.var 0)))))))
theorem wire_e2422372888442 : Closed e2422372888442 ∧ code e2422372888442 = 11218465910650 := by decide
theorem cert_e2422372888442 : check e2422372888442 [[],[]] .three = true := by decide
def e2422372888662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)) (.var 1)))))))
theorem wire_e2422372888662 : Closed e2422372888662 ∧ code e2422372888662 = 11218465910870 := by decide
theorem cert_e2422372888662 : check e2422372888662 [[],[]] .smaller = true := by decide
def e2422372888666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)) (.var 0)))))))
theorem wire_e2422372888666 : Closed e2422372888666 ∧ code e2422372888666 = 11218465910874 := by decide
theorem cert_e2422372888666 : check e2422372888666 [[],[]] .smaller = true := by decide
def e2422372888926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372888926 : Closed e2422372888926 ∧ code e2422372888926 = 11218465911134 := by decide
theorem cert_e2422372888926 : check e2422372888926 [[],[]] .three = true := by decide
def e2422372888942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372888942 : Closed e2422372888942 ∧ code e2422372888942 = 11218465911150 := by decide
theorem cert_e2422372888942 : check e2422372888942 [[],[]] .smaller = true := by decide
def e2422372888950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372888950 : Closed e2422372888950 ∧ code e2422372888950 = 11218465911158 := by decide
theorem cert_e2422372888950 : check e2422372888950 [[],[]] .smaller = true := by decide
def e2422372888954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372888954 : Closed e2422372888954 ∧ code e2422372888954 = 11218465911162 := by decide
theorem cert_e2422372888954 : check e2422372888954 [[],[]] .three = true := by decide
def e2422372889014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 1)))))))
theorem wire_e2422372889014 : Closed e2422372889014 ∧ code e2422372889014 = 11218465911222 := by decide
theorem cert_e2422372889014 : check e2422372889014 [[],[]] .smaller = true := by decide
def e2422372889046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372889046 : Closed e2422372889046 ∧ code e2422372889046 = 11218465911254 := by decide
theorem cert_e2422372889046 : check e2422372889046 [[],[]] .smaller = true := by decide
def e2422372889050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372889050 : Closed e2422372889050 ∧ code e2422372889050 = 11218465911258 := by decide
theorem cert_e2422372889050 : check e2422372889050 [[],[]] .smaller = true := by decide
def e2422372889430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372889430 : Closed e2422372889430 ∧ code e2422372889430 = 11218465911638 := by decide
theorem cert_e2422372889430 : check e2422372889430 [[],[]] .smaller = true := by decide
def e2422372889434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372889434 : Closed e2422372889434 ∧ code e2422372889434 = 11218465911642 := by decide
theorem cert_e2422372889434 : check e2422372889434 [[],[]] .smaller = true := by decide
def e2422372889450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372889450 : Closed e2422372889450 ∧ code e2422372889450 = 11218465911658 := by decide
theorem cert_e2422372889450 : check e2422372889450 [[],[]] .smaller = true := by decide
def e2422372889514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372889514 : Closed e2422372889514 ∧ code e2422372889514 = 11218465911722 := by decide
theorem cert_e2422372889514 : check e2422372889514 [[],[]] .smaller = true := by decide
def e2422372889622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422372889622 : Closed e2422372889622 ∧ code e2422372889622 = 11218465911830 := by decide
theorem cert_e2422372889622 : check e2422372889622 [[],[]] .smaller = true := by decide
def e2422372889694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372889694 : Closed e2422372889694 ∧ code e2422372889694 = 11218465911902 := by decide
theorem cert_e2422372889694 : check e2422372889694 [[],[]] .three = true := by decide
def e2422372889718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2422372889718 : Closed e2422372889718 ∧ code e2422372889718 = 11218465911926 := by decide
theorem cert_e2422372889718 : check e2422372889718 [[],[]] .smaller = true := by decide
def e2422372889814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422372889814 : Closed e2422372889814 ∧ code e2422372889814 = 11218465912022 := by decide
theorem cert_e2422372889814 : check e2422372889814 [[],[]] .smaller = true := by decide
def e2422372889818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422372889818 : Closed e2422372889818 ∧ code e2422372889818 = 11218465912026 := by decide
theorem cert_e2422372889818 : check e2422372889818 [[],[]] .smaller = true := by decide
def e2422372889834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422372889834 : Closed e2422372889834 ∧ code e2422372889834 = 11218465912042 := by decide
theorem cert_e2422372889834 : check e2422372889834 [[],[]] .smaller = true := by decide
def e2422372889910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372889910 : Closed e2422372889910 ∧ code e2422372889910 = 11218465912118 := by decide
theorem cert_e2422372889910 : check e2422372889910 [[],[]] .smaller = true := by decide
def e2422372889914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372889914 : Closed e2422372889914 ∧ code e2422372889914 = 11218465912122 := by decide
theorem cert_e2422372889914 : check e2422372889914 [[],[]] .smaller = true := by decide
def e2422372889986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372889986 : Closed e2422372889986 ∧ code e2422372889986 = 11218465912194 := by decide
theorem cert_e2422372889986 : check e2422372889986 [[],[]] .smaller = true := by decide
def e2422372889998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2422372889998 : Closed e2422372889998 ∧ code e2422372889998 = 11218465912206 := by decide
theorem cert_e2422372889998 : check e2422372889998 [[],[]] .smaller = true := by decide
def e2422372890010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372890010 : Closed e2422372890010 ∧ code e2422372890010 = 11218465912218 := by decide
theorem cert_e2422372890010 : check e2422372890010 [[],[]] .smaller = true := by decide
def e2422372890078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e2422372890078 : Closed e2422372890078 ∧ code e2422372890078 = 11218465912286 := by decide
theorem cert_e2422372890078 : check e2422372890078 [[],[]] .three = true := by decide
def e2422372890082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372890082 : Closed e2422372890082 ∧ code e2422372890082 = 11218465912290 := by decide
theorem cert_e2422372890082 : check e2422372890082 [[],[]] .three = true := by decide
def e2422372890094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e2422372890094 : Closed e2422372890094 ∧ code e2422372890094 = 11218465912302 := by decide
theorem cert_e2422372890094 : check e2422372890094 [[],[]] .three = true := by decide
def e2422372890122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372890122 : Closed e2422372890122 ∧ code e2422372890122 = 11218465912330 := by decide
theorem cert_e2422372890122 : check e2422372890122 [[],[]] .smaller = true := by decide
def e2422372890158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372890158 : Closed e2422372890158 ∧ code e2422372890158 = 11218465912366 := by decide
theorem cert_e2422372890158 : check e2422372890158 [[],[]] .smaller = true := by decide
def e2422372890166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372890166 : Closed e2422372890166 ∧ code e2422372890166 = 11218465912374 := by decide
theorem cert_e2422372890166 : check e2422372890166 [[],[]] .smaller = true := by decide
def e2422372890170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372890170 : Closed e2422372890170 ∧ code e2422372890170 = 11218465912378 := by decide
theorem cert_e2422372890170 : check e2422372890170 [[],[]] .smaller = true := by decide
def e2422372890218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372890218 : Closed e2422372890218 ∧ code e2422372890218 = 11218465912426 := by decide
theorem cert_e2422372890218 : check e2422372890218 [[],[]] .smaller = true := by decide
def e2422372890242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372890242 : Closed e2422372890242 ∧ code e2422372890242 = 11218465912450 := by decide
theorem cert_e2422372890242 : check e2422372890242 [[],[]] .smaller = true := by decide
def e2422372890254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372890254 : Closed e2422372890254 ∧ code e2422372890254 = 11218465912462 := by decide
theorem cert_e2422372890254 : check e2422372890254 [[],[]] .smaller = true := by decide
def e2422372890266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372890266 : Closed e2422372890266 ∧ code e2422372890266 = 11218465912474 := by decide
theorem cert_e2422372890266 : check e2422372890266 [[],[]] .smaller = true := by decide
def e2422372890310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372890310 : Closed e2422372890310 ∧ code e2422372890310 = 11218465912518 := by decide
theorem cert_e2422372890310 : check e2422372890310 [[],[]] .smaller = true := by decide
def e2422372890334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e2422372890334 : Closed e2422372890334 ∧ code e2422372890334 = 11218465912542 := by decide
theorem cert_e2422372890334 : check e2422372890334 [[],[]] .three = true := by decide
def e2422372890338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372890338 : Closed e2422372890338 ∧ code e2422372890338 = 11218465912546 := by decide
theorem cert_e2422372890338 : check e2422372890338 [[],[]] .smaller = true := by decide
def e2422372890350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 2)))))))
theorem wire_e2422372890350 : Closed e2422372890350 ∧ code e2422372890350 = 11218465912558 := by decide
theorem cert_e2422372890350 : check e2422372890350 [[],[]] .smaller = true := by decide
def e2422372890358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e2422372890358 : Closed e2422372890358 ∧ code e2422372890358 = 11218465912566 := by decide
theorem cert_e2422372890358 : check e2422372890358 [[],[]] .three = true := by decide
def e2422372890390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372890390 : Closed e2422372890390 ∧ code e2422372890390 = 11218465912598 := by decide
theorem cert_e2422372890390 : check e2422372890390 [[],[]] .smaller = true := by decide
def e2422372890462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e2422372890462 : Closed e2422372890462 ∧ code e2422372890462 = 11218465912670 := by decide
theorem cert_e2422372890462 : check e2422372890462 [[],[]] .three = true := by decide
def e2422372890466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372890466 : Closed e2422372890466 ∧ code e2422372890466 = 11218465912674 := by decide
theorem cert_e2422372890466 : check e2422372890466 [[],[]] .smaller = true := by decide
def e2422372890478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e2422372890478 : Closed e2422372890478 ∧ code e2422372890478 = 11218465912686 := by decide
theorem cert_e2422372890478 : check e2422372890478 [[],[]] .smaller = true := by decide
def e2422372890486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e2422372890486 : Closed e2422372890486 ∧ code e2422372890486 = 11218465912694 := by decide
theorem cert_e2422372890486 : check e2422372890486 [[],[]] .smaller = true := by decide
def e2422372890490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e2422372890490 : Closed e2422372890490 ∧ code e2422372890490 = 11218465912698 := by decide
theorem cert_e2422372890490 : check e2422372890490 [[],[]] .three = true := by decide
def e2422372890506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372890506 : Closed e2422372890506 ∧ code e2422372890506 = 11218465912714 := by decide
theorem cert_e2422372890506 : check e2422372890506 [[],[]] .three = true := by decide
def e2422372890530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372890530 : Closed e2422372890530 ∧ code e2422372890530 = 11218465912738 := by decide
theorem cert_e2422372890530 : check e2422372890530 [[],[]] .three = true := by decide
def e2422372890542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e2422372890542 : Closed e2422372890542 ∧ code e2422372890542 = 11218465912750 := by decide
theorem cert_e2422372890542 : check e2422372890542 [[],[]] .three = true := by decide
def e2422372890550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e2422372890550 : Closed e2422372890550 ∧ code e2422372890550 = 11218465912758 := by decide
theorem cert_e2422372890550 : check e2422372890550 [[],[]] .three = true := by decide
def e2422372890554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e2422372890554 : Closed e2422372890554 ∧ code e2422372890554 = 11218465912762 := by decide
theorem cert_e2422372890554 : check e2422372890554 [[],[]] .three = true := by decide
def e2422372890798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372890798 : Closed e2422372890798 ∧ code e2422372890798 = 11218465913006 := by decide
theorem cert_e2422372890798 : check e2422372890798 [[],[]] .three = true := by decide
def e2422372890806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 1)) (.var 1)))))))
theorem wire_e2422372890806 : Closed e2422372890806 ∧ code e2422372890806 = 11218465913014 := by decide
theorem cert_e2422372890806 : check e2422372890806 [[],[]] .three = true := by decide
def e2422372890810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372890810 : Closed e2422372890810 ∧ code e2422372890810 = 11218465913018 := by decide
theorem cert_e2422372890810 : check e2422372890810 [[],[]] .three = true := by decide
def e2422372890838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372890838 : Closed e2422372890838 ∧ code e2422372890838 = 11218465913046 := by decide
theorem cert_e2422372890838 : check e2422372890838 [[],[]] .three = true := by decide
def e2422372890842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372890842 : Closed e2422372890842 ∧ code e2422372890842 = 11218465913050 := by decide
theorem cert_e2422372890842 : check e2422372890842 [[],[]] .three = true := by decide
def e2422372890858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372890858 : Closed e2422372890858 ∧ code e2422372890858 = 11218465913066 := by decide
theorem cert_e2422372890858 : check e2422372890858 [[],[]] .three = true := by decide
def e2422372891182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372891182 : Closed e2422372891182 ∧ code e2422372891182 = 11218465913390 := by decide
theorem cert_e2422372891182 : check e2422372891182 [[],[]] .three = true := by decide
def e2422372891190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372891190 : Closed e2422372891190 ∧ code e2422372891190 = 11218465913398 := by decide
theorem cert_e2422372891190 : check e2422372891190 [[],[]] .three = true := by decide
def e2422372891194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372891194 : Closed e2422372891194 ∧ code e2422372891194 = 11218465913402 := by decide
theorem cert_e2422372891194 : check e2422372891194 [[],[]] .three = true := by decide
def e2422372891278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372891278 : Closed e2422372891278 ∧ code e2422372891278 = 11218465913486 := by decide
theorem cert_e2422372891278 : check e2422372891278 [[],[]] .three = true := by decide
def e2422372891334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372891334 : Closed e2422372891334 ∧ code e2422372891334 = 11218465913542 := by decide
theorem cert_e2422372891334 : check e2422372891334 [[],[]] .three = true := by decide
def e2422372891358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e2422372891358 : Closed e2422372891358 ∧ code e2422372891358 = 11218465913566 := by decide
theorem cert_e2422372891358 : check e2422372891358 [[],[]] .three = true := by decide
def e2422372891362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372891362 : Closed e2422372891362 ∧ code e2422372891362 = 11218465913570 := by decide
theorem cert_e2422372891362 : check e2422372891362 [[],[]] .three = true := by decide
def e2422372891374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e2422372891374 : Closed e2422372891374 ∧ code e2422372891374 = 11218465913582 := by decide
theorem cert_e2422372891374 : check e2422372891374 [[],[]] .three = true := by decide
def e2422372891382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e2422372891382 : Closed e2422372891382 ∧ code e2422372891382 = 11218465913590 := by decide
theorem cert_e2422372891382 : check e2422372891382 [[],[]] .three = true := by decide
def e2422372891414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372891414 : Closed e2422372891414 ∧ code e2422372891414 = 11218465913622 := by decide
theorem cert_e2422372891414 : check e2422372891414 [[],[]] .three = true := by decide
def e2422372891418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372891418 : Closed e2422372891418 ∧ code e2422372891418 = 11218465913626 := by decide
theorem cert_e2422372891418 : check e2422372891418 [[],[]] .three = true := by decide
def e2422372891462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372891462 : Closed e2422372891462 ∧ code e2422372891462 = 11218465913670 := by decide
theorem cert_e2422372891462 : check e2422372891462 [[],[]] .three = true := by decide
def e2422372891486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2422372891486 : Closed e2422372891486 ∧ code e2422372891486 = 11218465913694 := by decide
theorem cert_e2422372891486 : check e2422372891486 [[],[]] .three = true := by decide
def e2422372891490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372891490 : Closed e2422372891490 ∧ code e2422372891490 = 11218465913698 := by decide
theorem cert_e2422372891490 : check e2422372891490 [[],[]] .three = true := by decide
def e2422372891502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2422372891502 : Closed e2422372891502 ∧ code e2422372891502 = 11218465913710 := by decide
theorem cert_e2422372891502 : check e2422372891502 [[],[]] .three = true := by decide
def e2422372891510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2422372891510 : Closed e2422372891510 ∧ code e2422372891510 = 11218465913718 := by decide
theorem cert_e2422372891510 : check e2422372891510 [[],[]] .three = true := by decide
def e2422372891514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2422372891514 : Closed e2422372891514 ∧ code e2422372891514 = 11218465913722 := by decide
theorem cert_e2422372891514 : check e2422372891514 [[],[]] .three = true := by decide
def e2422372891530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372891530 : Closed e2422372891530 ∧ code e2422372891530 = 11218465913738 := by decide
theorem cert_e2422372891530 : check e2422372891530 [[],[]] .three = true := by decide
def e2422372891554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372891554 : Closed e2422372891554 ∧ code e2422372891554 = 11218465913762 := by decide
theorem cert_e2422372891554 : check e2422372891554 [[],[]] .three = true := by decide
def e2422372891566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2422372891566 : Closed e2422372891566 ∧ code e2422372891566 = 11218465913774 := by decide
theorem cert_e2422372891566 : check e2422372891566 [[],[]] .three = true := by decide
def e2422372891574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e2422372891574 : Closed e2422372891574 ∧ code e2422372891574 = 11218465913782 := by decide
theorem cert_e2422372891574 : check e2422372891574 [[],[]] .three = true := by decide
def e2422372891578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2422372891578 : Closed e2422372891578 ∧ code e2422372891578 = 11218465913786 := by decide
theorem cert_e2422372891578 : check e2422372891578 [[],[]] .three = true := by decide
def e2422372891606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2422372891606 : Closed e2422372891606 ∧ code e2422372891606 = 11218465913814 := by decide
theorem cert_e2422372891606 : check e2422372891606 [[],[]] .three = true := by decide
def e2422372891610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2422372891610 : Closed e2422372891610 ∧ code e2422372891610 = 11218465913818 := by decide
theorem cert_e2422372891610 : check e2422372891610 [[],[]] .three = true := by decide
def e2422372893934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372893934 : Closed e2422372893934 ∧ code e2422372893934 = 11218465916142 := by decide
theorem cert_e2422372893934 : check e2422372893934 [[],[]] .smaller = true := by decide
def e2422372893942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372893942 : Closed e2422372893942 ∧ code e2422372893942 = 11218465916150 := by decide
theorem cert_e2422372893942 : check e2422372893942 [[],[]] .smaller = true := by decide
def e2422372894686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.var 3)))))))
theorem wire_e2422372894686 : Closed e2422372894686 ∧ code e2422372894686 = 11218465916894 := by decide
theorem cert_e2422372894686 : check e2422372894686 [[],[]] .three = true := by decide
def e2422372894702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 5)))) (.var 2)))))))
theorem wire_e2422372894702 : Closed e2422372894702 ∧ code e2422372894702 = 11218465916910 := by decide
theorem cert_e2422372894702 : check e2422372894702 [[],[]] .three = true := by decide
def e2422372896222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e2422372896222 : Closed e2422372896222 ∧ code e2422372896222 = 11218465918430 := by decide
theorem cert_e2422372896222 : check e2422372896222 [[],[]] .three = true := by decide
def e2422372896246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 4)))) (.var 1)))))))
theorem wire_e2422372896246 : Closed e2422372896246 ∧ code e2422372896246 = 11218465918454 := by decide
theorem cert_e2422372896246 : check e2422372896246 [[],[]] .three = true := by decide
def e2422372896494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e2422372896494 : Closed e2422372896494 ∧ code e2422372896494 = 11218465918702 := by decide
theorem cert_e2422372896494 : check e2422372896494 [[],[]] .smaller = true := by decide
def e2422372896502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e2422372896502 : Closed e2422372896502 ∧ code e2422372896502 = 11218465918710 := by decide
theorem cert_e2422372896502 : check e2422372896502 [[],[]] .smaller = true := by decide
def e2422372896606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e2422372896606 : Closed e2422372896606 ∧ code e2422372896606 = 11218465918814 := by decide
theorem cert_e2422372896606 : check e2422372896606 [[],[]] .three = true := by decide
def e2422372896622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e2422372896622 : Closed e2422372896622 ∧ code e2422372896622 = 11218465918830 := by decide
theorem cert_e2422372896622 : check e2422372896622 [[],[]] .smaller = true := by decide
def e2422372896634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e2422372896634 : Closed e2422372896634 ∧ code e2422372896634 = 11218465918842 := by decide
theorem cert_e2422372896634 : check e2422372896634 [[],[]] .smaller = true := by decide
def e2422372896694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e2422372896694 : Closed e2422372896694 ∧ code e2422372896694 = 11218465918902 := by decide
theorem cert_e2422372896694 : check e2422372896694 [[],[]] .smaller = true := by decide
def e2422372896698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e2422372896698 : Closed e2422372896698 ∧ code e2422372896698 = 11218465918906 := by decide
theorem cert_e2422372896698 : check e2422372896698 [[],[]] .smaller = true := by decide
def e2422372896726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.var 0)))) (.var 1)))))))
theorem wire_e2422372896726 : Closed e2422372896726 ∧ code e2422372896726 = 11218465918934 := by decide
theorem cert_e2422372896726 : check e2422372896726 [[],[]] .three = true := by decide
def e2422372897758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422372897758 : Closed e2422372897758 ∧ code e2422372897758 = 11218465919966 := by decide
theorem cert_e2422372897758 : check e2422372897758 [[],[]] .three = true := by decide
def e2422372897774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422372897774 : Closed e2422372897774 ∧ code e2422372897774 = 11218465919982 := by decide
theorem cert_e2422372897774 : check e2422372897774 [[],[]] .three = true := by decide
def e2422372899294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372899294 : Closed e2422372899294 ∧ code e2422372899294 = 11218465921502 := by decide
theorem cert_e2422372899294 : check e2422372899294 [[],[]] .three = true := by decide
def e2422372899318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372899318 : Closed e2422372899318 ∧ code e2422372899318 = 11218465921526 := by decide
theorem cert_e2422372899318 : check e2422372899318 [[],[]] .three = true := by decide
def e2422372900062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372900062 : Closed e2422372900062 ∧ code e2422372900062 = 11218465922270 := by decide
theorem cert_e2422372900062 : check e2422372900062 [[],[]] .three = true := by decide
def e2422372900078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372900078 : Closed e2422372900078 ∧ code e2422372900078 = 11218465922286 := by decide
theorem cert_e2422372900078 : check e2422372900078 [[],[]] .smaller = true := by decide
def e2422372900086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372900086 : Closed e2422372900086 ∧ code e2422372900086 = 11218465922294 := by decide
theorem cert_e2422372900086 : check e2422372900086 [[],[]] .smaller = true := by decide
def e2422372900090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372900090 : Closed e2422372900090 ∧ code e2422372900090 = 11218465922298 := by decide
theorem cert_e2422372900090 : check e2422372900090 [[],[]] .three = true := by decide
def e2422372900414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 4))))))))
theorem wire_e2422372900414 : Closed e2422372900414 ∧ code e2422372900414 = 11218465922622 := by decide
theorem cert_e2422372900414 : check e2422372900414 [[],[]] .three = true := by decide
def e2422372900470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422372900470 : Closed e2422372900470 ∧ code e2422372900470 = 11218465922678 := by decide
theorem cert_e2422372900470 : check e2422372900470 [[],[]] .smaller = true := by decide
def e2422372900638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.lam (.var 3))))))))
theorem wire_e2422372900638 : Closed e2422372900638 ∧ code e2422372900638 = 11218465922846 := by decide
theorem cert_e2422372900638 : check e2422372900638 [[],[]] .three = true := by decide
def e2422372900662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372900662 : Closed e2422372900662 ∧ code e2422372900662 = 11218465922870 := by decide
theorem cert_e2422372900662 : check e2422372900662 [[],[]] .three = true := by decide
def e2422372900666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372900666 : Closed e2422372900666 ∧ code e2422372900666 = 11218465922874 := by decide
theorem cert_e2422372900666 : check e2422372900666 [[],[]] .three = true := by decide
def e2422372904302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2422372904302 : Closed e2422372904302 ∧ code e2422372904302 = 11218465926510 := by decide
theorem cert_e2422372904302 : check e2422372904302 [[],[]] .smaller = true := by decide
def e2422372904310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2422372904310 : Closed e2422372904310 ∧ code e2422372904310 = 11218465926518 := by decide
theorem cert_e2422372904310 : check e2422372904310 [[],[]] .smaller = true := by decide
def e2422372904366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2422372904366 : Closed e2422372904366 ∧ code e2422372904366 = 11218465926574 := by decide
theorem cert_e2422372904366 : check e2422372904366 [[],[]] .smaller = true := by decide
def e2422372904378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2422372904378 : Closed e2422372904378 ∧ code e2422372904378 = 11218465926586 := by decide
theorem cert_e2422372904378 : check e2422372904378 [[],[]] .smaller = true := by decide
def e2422372904406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2422372904406 : Closed e2422372904406 ∧ code e2422372904406 = 11218465926614 := by decide
theorem cert_e2422372904406 : check e2422372904406 [[],[]] .smaller = true := by decide
def e2422372904410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2422372904410 : Closed e2422372904410 ∧ code e2422372904410 = 11218465926618 := by decide
theorem cert_e2422372904410 : check e2422372904410 [[],[]] .smaller = true := by decide
def e2422372904622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2422372904622 : Closed e2422372904622 ∧ code e2422372904622 = 11218465926830 := by decide
theorem cert_e2422372904622 : check e2422372904622 [[],[]] .smaller = true := by decide
def e2422372904634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2422372904634 : Closed e2422372904634 ∧ code e2422372904634 = 11218465926842 := by decide
theorem cert_e2422372904634 : check e2422372904634 [[],[]] .smaller = true := by decide
end Blc.Floor43
