import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e826843132630 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e826843132630 : Closed e826843132630 ∧ code e826843132630 = 9622936154838 := by decide
theorem cert_e826843132630 : check e826843132630 [] .sourceHead = true := by decide
def e826843132634 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e826843132634 : Closed e826843132634 ∧ code e826843132634 = 9622936154842 := by decide
theorem cert_e826843132634 : check e826843132634 [] .sourceHead = true := by decide
def e826843132650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e826843132650 : Closed e826843132650 ∧ code e826843132650 = 9622936154858 := by decide
theorem cert_e826843132650 : check e826843132650 [] .sourceHead = true := by decide
def e826843132726 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e826843132726 : Closed e826843132726 ∧ code e826843132726 = 9622936154934 := by decide
theorem cert_e826843132726 : check e826843132726 [] .sourceHead = true := by decide
def e826843132730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e826843132730 : Closed e826843132730 ∧ code e826843132730 = 9622936154938 := by decide
theorem cert_e826843132730 : check e826843132730 [] .sourceHead = true := by decide
def e826843132826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e826843132826 : Closed e826843132826 ∧ code e826843132826 = 9622936155034 := by decide
theorem cert_e826843132826 : check e826843132826 [] .sourceHead = true := by decide
def e826960866842 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960866842 : Closed e826960866842 ∧ code e826960866842 = 9623053889050 := by decide
theorem cert_e826960866842 : check e826960866842 [] .sourceHead = true := by decide
def e826960868890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960868890 : Closed e826960868890 ∧ code e826960868890 = 9623053891098 := by decide
theorem cert_e826960868890 : check e826960868890 [] .sourceHead = true := by decide
def e826960883226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960883226 : Closed e826960883226 ∧ code e826960883226 = 9623053905434 := by decide
theorem cert_e826960883226 : check e826960883226 [] .sourceHead = true := by decide
def e826960886298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960886298 : Closed e826960886298 ∧ code e826960886298 = 9623053908506 := by decide
theorem cert_e826960886298 : check e826960886298 [] .sourceHead = true := by decide
def e826960893466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960893466 : Closed e826960893466 ∧ code e826960893466 = 9623053915674 := by decide
theorem cert_e826960893466 : check e826960893466 [] .sourceHead = true := by decide
def e826960894490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960894490 : Closed e826960894490 ∧ code e826960894490 = 9623053916698 := by decide
theorem cert_e826960894490 : check e826960894490 [] .sourceHead = true := by decide
def e826960948762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960948762 : Closed e826960948762 ∧ code e826960948762 = 9623053970970 := by decide
theorem cert_e826960948762 : check e826960948762 [] .sourceHead = true := by decide
def e826960951834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960951834 : Closed e826960951834 ∧ code e826960951834 = 9623053974042 := by decide
theorem cert_e826960951834 : check e826960951834 [] .sourceHead = true := by decide
def e826960964122 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960964122 : Closed e826960964122 ∧ code e826960964122 = 9623053986330 := by decide
theorem cert_e826960964122 : check e826960964122 [] .sourceHead = true := by decide
def e826960991770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960991770 : Closed e826960991770 ∧ code e826960991770 = 9623054013978 := by decide
theorem cert_e826960991770 : check e826960991770 [] .sourceHead = true := by decide
def e826960992794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960992794 : Closed e826960992794 ∧ code e826960992794 = 9623054015002 := by decide
theorem cert_e826960992794 : check e826960992794 [] .sourceHead = true := by decide
def e826960996890 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826960996890 : Closed e826960996890 ∧ code e826960996890 = 9623054019098 := by decide
theorem cert_e826960996890 : check e826960996890 [] .sourceHead = true := by decide
def e826961210906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826961210906 : Closed e826961210906 ∧ code e826961210906 = 9623054233114 := by decide
theorem cert_e826961210906 : check e826961210906 [] .sourceHead = true := by decide
def e826961213978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826961213978 : Closed e826961213978 ∧ code e826961213978 = 9623054236186 := by decide
theorem cert_e826961213978 : check e826961213978 [] .sourceHead = true := by decide
def e826961226266 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826961226266 : Closed e826961226266 ∧ code e826961226266 = 9623054248474 := by decide
theorem cert_e826961226266 : check e826961226266 [] .sourceHead = true := by decide
def e826961275418 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826961275418 : Closed e826961275418 ∧ code e826961275418 = 9623054297626 := by decide
theorem cert_e826961275418 : check e826961275418 [] .sourceHead = true := by decide
def e826961384986 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826961384986 : Closed e826961384986 ∧ code e826961384986 = 9623054407194 := by decide
theorem cert_e826961384986 : check e826961384986 [] .sourceHead = true := by decide
def e826961386010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826961386010 : Closed e826961386010 ∧ code e826961386010 = 9623054408218 := by decide
theorem cert_e826961386010 : check e826961386010 [] .sourceHead = true := by decide
def e826961390106 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826961390106 : Closed e826961390106 ∧ code e826961390106 = 9623054412314 := by decide
theorem cert_e826961390106 : check e826961390106 [] .sourceHead = true := by decide
def e826961406490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826961406490 : Closed e826961406490 ∧ code e826961406490 = 9623054428698 := by decide
theorem cert_e826961406490 : check e826961406490 [] .sourceHead = true := by decide
def e826962439706 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962439706 : Closed e826962439706 ∧ code e826962439706 = 9623055461914 := by decide
theorem cert_e826962439706 : check e826962439706 [] .sourceHead = true := by decide
def e826962441754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962441754 : Closed e826962441754 ∧ code e826962441754 = 9623055463962 := by decide
theorem cert_e826962441754 : check e826962441754 [] .sourceHead = true := by decide
def e826962456090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962456090 : Closed e826962456090 ∧ code e826962456090 = 9623055478298 := by decide
theorem cert_e826962456090 : check e826962456090 [] .sourceHead = true := by decide
def e826962459162 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962459162 : Closed e826962459162 ∧ code e826962459162 = 9623055481370 := by decide
theorem cert_e826962459162 : check e826962459162 [] .sourceHead = true := by decide
def e826962466330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962466330 : Closed e826962466330 ∧ code e826962466330 = 9623055488538 := by decide
theorem cert_e826962466330 : check e826962466330 [] .sourceHead = true := by decide
def e826962467354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962467354 : Closed e826962467354 ∧ code e826962467354 = 9623055489562 := by decide
theorem cert_e826962467354 : check e826962467354 [] .sourceHead = true := by decide
def e826962521626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962521626 : Closed e826962521626 ∧ code e826962521626 = 9623055543834 := by decide
theorem cert_e826962521626 : check e826962521626 [] .sourceHead = true := by decide
def e826962524698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962524698 : Closed e826962524698 ∧ code e826962524698 = 9623055546906 := by decide
theorem cert_e826962524698 : check e826962524698 [] .sourceHead = true := by decide
def e826962536986 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962536986 : Closed e826962536986 ∧ code e826962536986 = 9623055559194 := by decide
theorem cert_e826962536986 : check e826962536986 [] .sourceHead = true := by decide
def e826962564634 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962564634 : Closed e826962564634 ∧ code e826962564634 = 9623055586842 := by decide
theorem cert_e826962564634 : check e826962564634 [] .sourceHead = true := by decide
def e826962565658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962565658 : Closed e826962565658 ∧ code e826962565658 = 9623055587866 := by decide
theorem cert_e826962565658 : check e826962565658 [] .sourceHead = true := by decide
def e826962569754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962569754 : Closed e826962569754 ∧ code e826962569754 = 9623055591962 := by decide
theorem cert_e826962569754 : check e826962569754 [] .sourceHead = true := by decide
def e826962832922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962832922 : Closed e826962832922 ∧ code e826962832922 = 9623055855130 := by decide
theorem cert_e826962832922 : check e826962832922 [] .sourceHead = true := by decide
def e826962834970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962834970 : Closed e826962834970 ∧ code e826962834970 = 9623055857178 := by decide
theorem cert_e826962834970 : check e826962834970 [] .sourceHead = true := by decide
def e826962849306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962849306 : Closed e826962849306 ∧ code e826962849306 = 9623055871514 := by decide
theorem cert_e826962849306 : check e826962849306 [] .sourceHead = true := by decide
def e826962852378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962852378 : Closed e826962852378 ∧ code e826962852378 = 9623055874586 := by decide
theorem cert_e826962852378 : check e826962852378 [] .sourceHead = true := by decide
def e826962859546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962859546 : Closed e826962859546 ∧ code e826962859546 = 9623055881754 := by decide
theorem cert_e826962859546 : check e826962859546 [] .sourceHead = true := by decide
def e826962860570 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962860570 : Closed e826962860570 ∧ code e826962860570 = 9623055882778 := by decide
theorem cert_e826962860570 : check e826962860570 [] .sourceHead = true := by decide
def e826962931226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962931226 : Closed e826962931226 ∧ code e826962931226 = 9623055953434 := by decide
theorem cert_e826962931226 : check e826962931226 [] .sourceHead = true := by decide
def e826962933274 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826962933274 : Closed e826962933274 ∧ code e826962933274 = 9623055955482 := by decide
theorem cert_e826962933274 : check e826962933274 [] .sourceHead = true := by decide
def e826963029530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963029530 : Closed e826963029530 ∧ code e826963029530 = 9623056051738 := by decide
theorem cert_e826963029530 : check e826963029530 [] .sourceHead = true := by decide
def e826963032602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963032602 : Closed e826963032602 ∧ code e826963032602 = 9623056054810 := by decide
theorem cert_e826963032602 : check e826963032602 [] .sourceHead = true := by decide
def e826963058714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826963058714 : Closed e826963058714 ∧ code e826963058714 = 9623056080922 := by decide
theorem cert_e826963058714 : check e826963058714 [] .sourceHead = true := by decide
def e826963058806 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826963058806 : Closed e826963058806 ∧ code e826963058806 = 9623056081014 := by decide
theorem cert_e826963058806 : check e826963058806 [] .sourceHead = true := by decide
def e826963059050 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826963059050 : Closed e826963059050 ∧ code e826963059050 = 9623056081258 := by decide
theorem cert_e826963059050 : check e826963059050 [] .sourceHead = true := by decide
def e826963059098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826963059098 : Closed e826963059098 ∧ code e826963059098 = 9623056081306 := by decide
theorem cert_e826963059098 : check e826963059098 [] .sourceHead = true := by decide
def e826963060250 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826963060250 : Closed e826963060250 ∧ code e826963060250 = 9623056082458 := by decide
theorem cert_e826963060250 : check e826963060250 [] .sourceHead = true := by decide
def e826963080730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963080730 : Closed e826963080730 ∧ code e826963080730 = 9623056102938 := by decide
theorem cert_e826963080730 : check e826963080730 [] .sourceHead = true := by decide
def e826963081754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963081754 : Closed e826963081754 ∧ code e826963081754 = 9623056103962 := by decide
theorem cert_e826963081754 : check e826963081754 [] .sourceHead = true := by decide
def e826963091482 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826963091482 : Closed e826963091482 ∧ code e826963091482 = 9623056113690 := by decide
theorem cert_e826963091482 : check e826963091482 [] .sourceHead = true := by decide
def e826963091574 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826963091574 : Closed e826963091574 ∧ code e826963091574 = 9623056113782 := by decide
theorem cert_e826963091574 : check e826963091574 [] .sourceHead = true := by decide
def e826963091818 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826963091818 : Closed e826963091818 ∧ code e826963091818 = 9623056114026 := by decide
theorem cert_e826963091818 : check e826963091818 [] .sourceHead = true := by decide
def e826963091866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826963091866 : Closed e826963091866 ∧ code e826963091866 = 9623056114074 := by decide
theorem cert_e826963091866 : check e826963091866 [] .sourceHead = true := by decide
def e826963093018 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826963093018 : Closed e826963093018 ∧ code e826963093018 = 9623056115226 := by decide
theorem cert_e826963093018 : check e826963093018 [] .sourceHead = true := by decide
def e826963242522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963242522 : Closed e826963242522 ∧ code e826963242522 = 9623056264730 := by decide
theorem cert_e826963242522 : check e826963242522 [] .sourceHead = true := by decide
def e826963245594 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963245594 : Closed e826963245594 ∧ code e826963245594 = 9623056267802 := by decide
theorem cert_e826963245594 : check e826963245594 [] .sourceHead = true := by decide
def e826963257882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963257882 : Closed e826963257882 ∧ code e826963257882 = 9623056280090 := by decide
theorem cert_e826963257882 : check e826963257882 [] .sourceHead = true := by decide
def e826963291674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963291674 : Closed e826963291674 ∧ code e826963291674 = 9623056313882 := by decide
theorem cert_e826963291674 : check e826963291674 [] .sourceHead = true := by decide
def e826963294746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963294746 : Closed e826963294746 ∧ code e826963294746 = 9623056316954 := by decide
theorem cert_e826963294746 : check e826963294746 [] .sourceHead = true := by decide
def e826963320858 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826963320858 : Closed e826963320858 ∧ code e826963320858 = 9623056343066 := by decide
theorem cert_e826963320858 : check e826963320858 [] .sourceHead = true := by decide
def e826963320950 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826963320950 : Closed e826963320950 ∧ code e826963320950 = 9623056343158 := by decide
theorem cert_e826963320950 : check e826963320950 [] .sourceHead = true := by decide
def e826963321194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826963321194 : Closed e826963321194 ∧ code e826963321194 = 9623056343402 := by decide
theorem cert_e826963321194 : check e826963321194 [] .sourceHead = true := by decide
def e826963321242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826963321242 : Closed e826963321242 ∧ code e826963321242 = 9623056343450 := by decide
theorem cert_e826963321242 : check e826963321242 [] .sourceHead = true := by decide
def e826963322394 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826963322394 : Closed e826963322394 ∧ code e826963322394 = 9623056344602 := by decide
theorem cert_e826963322394 : check e826963322394 [] .sourceHead = true := by decide
def e826963368474 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963368474 : Closed e826963368474 ∧ code e826963368474 = 9623056390682 := by decide
theorem cert_e826963368474 : check e826963368474 [] .sourceHead = true := by decide
def e826963370010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826963370010 : Closed e826963370010 ∧ code e826963370010 = 9623056392218 := by decide
theorem cert_e826963370010 : check e826963370010 [] .sourceHead = true := by decide
def e826963370102 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826963370102 : Closed e826963370102 ∧ code e826963370102 = 9623056392310 := by decide
theorem cert_e826963370102 : check e826963370102 [] .sourceHead = true := by decide
def e826963370346 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826963370346 : Closed e826963370346 ∧ code e826963370346 = 9623056392554 := by decide
theorem cert_e826963370346 : check e826963370346 [] .sourceHead = true := by decide
def e826963370394 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826963370394 : Closed e826963370394 ∧ code e826963370394 = 9623056392602 := by decide
theorem cert_e826963370394 : check e826963370394 [] .sourceHead = true := by decide
def e826963371546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826963371546 : Closed e826963371546 ∧ code e826963371546 = 9623056393754 := by decide
theorem cert_e826963371546 : check e826963371546 [] .sourceHead = true := by decide
def e826963449370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963449370 : Closed e826963449370 ∧ code e826963449370 = 9623056471578 := by decide
theorem cert_e826963449370 : check e826963449370 [] .sourceHead = true := by decide
def e826963450394 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963450394 : Closed e826963450394 ∧ code e826963450394 = 9623056472602 := by decide
theorem cert_e826963450394 : check e826963450394 [] .sourceHead = true := by decide
def e826963454490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963454490 : Closed e826963454490 ∧ code e826963454490 = 9623056476698 := by decide
theorem cert_e826963454490 : check e826963454490 [] .sourceHead = true := by decide
def e826963473946 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963473946 : Closed e826963473946 ∧ code e826963473946 = 9623056496154 := by decide
theorem cert_e826963473946 : check e826963473946 [] .sourceHead = true := by decide
def e826963474970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963474970 : Closed e826963474970 ∧ code e826963474970 = 9623056497178 := by decide
theorem cert_e826963474970 : check e826963474970 [] .sourceHead = true := by decide
def e826963484698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826963484698 : Closed e826963484698 ∧ code e826963484698 = 9623056506906 := by decide
theorem cert_e826963484698 : check e826963484698 [] .sourceHead = true := by decide
def e826963484790 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826963484790 : Closed e826963484790 ∧ code e826963484790 = 9623056506998 := by decide
theorem cert_e826963484790 : check e826963484790 [] .sourceHead = true := by decide
def e826963485034 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826963485034 : Closed e826963485034 ∧ code e826963485034 = 9623056507242 := by decide
theorem cert_e826963485034 : check e826963485034 [] .sourceHead = true := by decide
def e826963485082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826963485082 : Closed e826963485082 ∧ code e826963485082 = 9623056507290 := by decide
theorem cert_e826963485082 : check e826963485082 [] .sourceHead = true := by decide
def e826963486234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826963486234 : Closed e826963486234 ∧ code e826963486234 = 9623056508442 := by decide
theorem cert_e826963486234 : check e826963486234 [] .sourceHead = true := by decide
def e826963499546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826963499546 : Closed e826963499546 ∧ code e826963499546 = 9623056521754 := by decide
theorem cert_e826963499546 : check e826963499546 [] .sourceHead = true := by decide
def e826963501082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826963501082 : Closed e826963501082 ∧ code e826963501082 = 9623056523290 := by decide
theorem cert_e826963501082 : check e826963501082 [] .sourceHead = true := by decide
def e826963501174 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826963501174 : Closed e826963501174 ∧ code e826963501174 = 9623056523382 := by decide
theorem cert_e826963501174 : check e826963501174 [] .sourceHead = true := by decide
def e826963501418 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826963501418 : Closed e826963501418 ∧ code e826963501418 = 9623056523626 := by decide
theorem cert_e826963501418 : check e826963501418 [] .sourceHead = true := by decide
def e826963501466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826963501466 : Closed e826963501466 ∧ code e826963501466 = 9623056523674 := by decide
theorem cert_e826963501466 : check e826963501466 [] .sourceHead = true := by decide
def e826963502618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826963502618 : Closed e826963502618 ∧ code e826963502618 = 9623056524826 := by decide
theorem cert_e826963502618 : check e826963502618 [] .sourceHead = true := by decide
def e826964094490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964094490 : Closed e826964094490 ∧ code e826964094490 = 9623057116698 := by decide
theorem cert_e826964094490 : check e826964094490 [] .sourceHead = true := by decide
def e826964097562 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964097562 : Closed e826964097562 ∧ code e826964097562 = 9623057119770 := by decide
theorem cert_e826964097562 : check e826964097562 [] .sourceHead = true := by decide
def e826964109850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964109850 : Closed e826964109850 ∧ code e826964109850 = 9623057132058 := by decide
theorem cert_e826964109850 : check e826964109850 [] .sourceHead = true := by decide
def e826964159002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964159002 : Closed e826964159002 ∧ code e826964159002 = 9623057181210 := by decide
theorem cert_e826964159002 : check e826964159002 [] .sourceHead = true := by decide
def e826964291098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964291098 : Closed e826964291098 ∧ code e826964291098 = 9623057313306 := by decide
theorem cert_e826964291098 : check e826964291098 [] .sourceHead = true := by decide
def e826964294170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964294170 : Closed e826964294170 ∧ code e826964294170 = 9623057316378 := by decide
theorem cert_e826964294170 : check e826964294170 [] .sourceHead = true := by decide
def e826964306458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964306458 : Closed e826964306458 ∧ code e826964306458 = 9623057328666 := by decide
theorem cert_e826964306458 : check e826964306458 [] .sourceHead = true := by decide
def e826964340250 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964340250 : Closed e826964340250 ∧ code e826964340250 = 9623057362458 := by decide
theorem cert_e826964340250 : check e826964340250 [] .sourceHead = true := by decide
def e826964343322 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964343322 : Closed e826964343322 ∧ code e826964343322 = 9623057365530 := by decide
theorem cert_e826964343322 : check e826964343322 [] .sourceHead = true := by decide
def e826964369434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826964369434 : Closed e826964369434 ∧ code e826964369434 = 9623057391642 := by decide
theorem cert_e826964369434 : check e826964369434 [] .sourceHead = true := by decide
def e826964369526 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826964369526 : Closed e826964369526 ∧ code e826964369526 = 9623057391734 := by decide
theorem cert_e826964369526 : check e826964369526 [] .sourceHead = true := by decide
def e826964369770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826964369770 : Closed e826964369770 ∧ code e826964369770 = 9623057391978 := by decide
theorem cert_e826964369770 : check e826964369770 [] .sourceHead = true := by decide
def e826964369818 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826964369818 : Closed e826964369818 ∧ code e826964369818 = 9623057392026 := by decide
theorem cert_e826964369818 : check e826964369818 [] .sourceHead = true := by decide
def e826964370970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826964370970 : Closed e826964370970 ∧ code e826964370970 = 9623057393178 := by decide
theorem cert_e826964370970 : check e826964370970 [] .sourceHead = true := by decide
def e826964417050 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964417050 : Closed e826964417050 ∧ code e826964417050 = 9623057439258 := by decide
theorem cert_e826964417050 : check e826964417050 [] .sourceHead = true := by decide
def e826964418586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826964418586 : Closed e826964418586 ∧ code e826964418586 = 9623057440794 := by decide
theorem cert_e826964418586 : check e826964418586 [] .sourceHead = true := by decide
def e826964418678 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826964418678 : Closed e826964418678 ∧ code e826964418678 = 9623057440886 := by decide
theorem cert_e826964418678 : check e826964418678 [] .sourceHead = true := by decide
def e826964418922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826964418922 : Closed e826964418922 ∧ code e826964418922 = 9623057441130 := by decide
theorem cert_e826964418922 : check e826964418922 [] .sourceHead = true := by decide
def e826964418970 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826964418970 : Closed e826964418970 ∧ code e826964418970 = 9623057441178 := by decide
theorem cert_e826964418970 : check e826964418970 [] .sourceHead = true := by decide
def e826964420122 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826964420122 : Closed e826964420122 ∧ code e826964420122 = 9623057442330 := by decide
theorem cert_e826964420122 : check e826964420122 [] .sourceHead = true := by decide
def e826964601370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964601370 : Closed e826964601370 ∧ code e826964601370 = 9623057623578 := by decide
theorem cert_e826964601370 : check e826964601370 [] .sourceHead = true := by decide
def e826964613658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964613658 : Closed e826964613658 ∧ code e826964613658 = 9623057635866 := by decide
theorem cert_e826964613658 : check e826964613658 [] .sourceHead = true := by decide
def e826964615194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826964615194 : Closed e826964615194 ∧ code e826964615194 = 9623057637402 := by decide
theorem cert_e826964615194 : check e826964615194 [] .sourceHead = true := by decide
def e826964615286 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826964615286 : Closed e826964615286 ∧ code e826964615286 = 9623057637494 := by decide
theorem cert_e826964615286 : check e826964615286 [] .sourceHead = true := by decide
def e826964615530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826964615530 : Closed e826964615530 ∧ code e826964615530 = 9623057637738 := by decide
theorem cert_e826964615530 : check e826964615530 [] .sourceHead = true := by decide
def e826964615578 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826964615578 : Closed e826964615578 ∧ code e826964615578 = 9623057637786 := by decide
theorem cert_e826964615578 : check e826964615578 [] .sourceHead = true := by decide
def e826964616730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826964616730 : Closed e826964616730 ∧ code e826964616730 = 9623057638938 := by decide
theorem cert_e826964616730 : check e826964616730 [] .sourceHead = true := by decide
def e826964923930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964923930 : Closed e826964923930 ∧ code e826964923930 = 9623057946138 := by decide
theorem cert_e826964923930 : check e826964923930 [] .sourceHead = true := by decide
def e826964924954 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964924954 : Closed e826964924954 ∧ code e826964924954 = 9623057947162 := by decide
theorem cert_e826964924954 : check e826964924954 [] .sourceHead = true := by decide
def e826964929050 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964929050 : Closed e826964929050 ∧ code e826964929050 = 9623057951258 := by decide
theorem cert_e826964929050 : check e826964929050 [] .sourceHead = true := by decide
def e826964945434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826964945434 : Closed e826964945434 ∧ code e826964945434 = 9623057967642 := by decide
theorem cert_e826964945434 : check e826964945434 [] .sourceHead = true := by decide
def e826965022234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826965022234 : Closed e826965022234 ∧ code e826965022234 = 9623058044442 := by decide
theorem cert_e826965022234 : check e826965022234 [] .sourceHead = true := by decide
def e826965023258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826965023258 : Closed e826965023258 ∧ code e826965023258 = 9623058045466 := by decide
theorem cert_e826965023258 : check e826965023258 [] .sourceHead = true := by decide
def e826965027354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826965027354 : Closed e826965027354 ∧ code e826965027354 = 9623058049562 := by decide
theorem cert_e826965027354 : check e826965027354 [] .sourceHead = true := by decide
def e826965046810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826965046810 : Closed e826965046810 ∧ code e826965046810 = 9623058069018 := by decide
theorem cert_e826965046810 : check e826965046810 [] .sourceHead = true := by decide
def e826965047834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826965047834 : Closed e826965047834 ∧ code e826965047834 = 9623058070042 := by decide
theorem cert_e826965047834 : check e826965047834 [] .sourceHead = true := by decide
def e826965057562 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826965057562 : Closed e826965057562 ∧ code e826965057562 = 9623058079770 := by decide
theorem cert_e826965057562 : check e826965057562 [] .sourceHead = true := by decide
def e826965057654 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826965057654 : Closed e826965057654 ∧ code e826965057654 = 9623058079862 := by decide
theorem cert_e826965057654 : check e826965057654 [] .sourceHead = true := by decide
def e826965057898 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826965057898 : Closed e826965057898 ∧ code e826965057898 = 9623058080106 := by decide
theorem cert_e826965057898 : check e826965057898 [] .sourceHead = true := by decide
def e826965057946 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826965057946 : Closed e826965057946 ∧ code e826965057946 = 9623058080154 := by decide
theorem cert_e826965057946 : check e826965057946 [] .sourceHead = true := by decide
def e826965059098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826965059098 : Closed e826965059098 ∧ code e826965059098 = 9623058081306 := by decide
theorem cert_e826965059098 : check e826965059098 [] .sourceHead = true := by decide
def e826965072410 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826965072410 : Closed e826965072410 ∧ code e826965072410 = 9623058094618 := by decide
theorem cert_e826965072410 : check e826965072410 [] .sourceHead = true := by decide
def e826965073946 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826965073946 : Closed e826965073946 ∧ code e826965073946 = 9623058096154 := by decide
theorem cert_e826965073946 : check e826965073946 [] .sourceHead = true := by decide
def e826965074038 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826965074038 : Closed e826965074038 ∧ code e826965074038 = 9623058096246 := by decide
theorem cert_e826965074038 : check e826965074038 [] .sourceHead = true := by decide
def e826965074282 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826965074282 : Closed e826965074282 ∧ code e826965074282 = 9623058096490 := by decide
theorem cert_e826965074282 : check e826965074282 [] .sourceHead = true := by decide
def e826965074330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826965074330 : Closed e826965074330 ∧ code e826965074330 = 9623058096538 := by decide
theorem cert_e826965074330 : check e826965074330 [] .sourceHead = true := by decide
def e826965075482 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826965075482 : Closed e826965075482 ∧ code e826965075482 = 9623058097690 := by decide
theorem cert_e826965075482 : check e826965075482 [] .sourceHead = true := by decide
def e826965125658 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826965125658 : Closed e826965125658 ∧ code e826965125658 = 9623058147866 := by decide
theorem cert_e826965125658 : check e826965125658 [] .sourceHead = true := by decide
def e826965137946 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826965137946 : Closed e826965137946 ∧ code e826965137946 = 9623058160154 := by decide
theorem cert_e826965137946 : check e826965137946 [] .sourceHead = true := by decide
def e826965139482 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826965139482 : Closed e826965139482 ∧ code e826965139482 = 9623058161690 := by decide
theorem cert_e826965139482 : check e826965139482 [] .sourceHead = true := by decide
def e826965139574 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826965139574 : Closed e826965139574 ∧ code e826965139574 = 9623058161782 := by decide
theorem cert_e826965139574 : check e826965139574 [] .sourceHead = true := by decide
def e826965139818 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826965139818 : Closed e826965139818 ∧ code e826965139818 = 9623058162026 := by decide
theorem cert_e826965139818 : check e826965139818 [] .sourceHead = true := by decide
def e826965139866 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826965139866 : Closed e826965139866 ∧ code e826965139866 = 9623058162074 := by decide
theorem cert_e826965139866 : check e826965139866 [] .sourceHead = true := by decide
def e826965141018 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826965141018 : Closed e826965141018 ∧ code e826965141018 = 9623058163226 := by decide
theorem cert_e826965141018 : check e826965141018 [] .sourceHead = true := by decide
def e826968731162 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968731162 : Closed e826968731162 ∧ code e826968731162 = 9623061753370 := by decide
theorem cert_e826968731162 : check e826968731162 [] .sourceHead = true := by decide
def e826968733210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968733210 : Closed e826968733210 ∧ code e826968733210 = 9623061755418 := by decide
theorem cert_e826968733210 : check e826968733210 [] .sourceHead = true := by decide
def e826968747546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968747546 : Closed e826968747546 ∧ code e826968747546 = 9623061769754 := by decide
theorem cert_e826968747546 : check e826968747546 [] .sourceHead = true := by decide
def e826968750618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968750618 : Closed e826968750618 ∧ code e826968750618 = 9623061772826 := by decide
theorem cert_e826968750618 : check e826968750618 [] .sourceHead = true := by decide
def e826968757786 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968757786 : Closed e826968757786 ∧ code e826968757786 = 9623061779994 := by decide
theorem cert_e826968757786 : check e826968757786 [] .sourceHead = true := by decide
def e826968758810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968758810 : Closed e826968758810 ∧ code e826968758810 = 9623061781018 := by decide
theorem cert_e826968758810 : check e826968758810 [] .sourceHead = true := by decide
def e826968813082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968813082 : Closed e826968813082 ∧ code e826968813082 = 9623061835290 := by decide
theorem cert_e826968813082 : check e826968813082 [] .sourceHead = true := by decide
def e826968816154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968816154 : Closed e826968816154 ∧ code e826968816154 = 9623061838362 := by decide
theorem cert_e826968816154 : check e826968816154 [] .sourceHead = true := by decide
def e826968828442 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968828442 : Closed e826968828442 ∧ code e826968828442 = 9623061850650 := by decide
theorem cert_e826968828442 : check e826968828442 [] .sourceHead = true := by decide
def e826968856090 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968856090 : Closed e826968856090 ∧ code e826968856090 = 9623061878298 := by decide
theorem cert_e826968856090 : check e826968856090 [] .sourceHead = true := by decide
def e826968857114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968857114 : Closed e826968857114 ∧ code e826968857114 = 9623061879322 := by decide
theorem cert_e826968857114 : check e826968857114 [] .sourceHead = true := by decide
def e826968861210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826968861210 : Closed e826968861210 ∧ code e826968861210 = 9623061883418 := by decide
theorem cert_e826968861210 : check e826968861210 [] .sourceHead = true := by decide
def e826969124378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969124378 : Closed e826969124378 ∧ code e826969124378 = 9623062146586 := by decide
theorem cert_e826969124378 : check e826969124378 [] .sourceHead = true := by decide
def e826969126426 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826969126426 : Closed e826969126426 ∧ code e826969126426 = 9623062148634 := by decide
theorem cert_e826969126426 : check e826969126426 [] .sourceHead = true := by decide
end Blc.Floor43
