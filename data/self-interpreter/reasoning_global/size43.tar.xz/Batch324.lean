import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2417278847958 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2417278847958 : Closed e2417278847958 ∧ code e2417278847958 = 11213371870166 := by decide
theorem cert_e2417278847958 : check e2417278847958 [[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2417278847962 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2417278847962 : Closed e2417278847962 ∧ code e2417278847962 = 11213371870170 := by decide
private def t_e2417278847962 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2417278847962 : ¬ IsSelfInterpreter e2417278847962 :=
  wSource (t := t_e2417278847962) (replay_sound (ps := []) (t := e2417278847962) (by decide)) (by decide)
def e2417278848238 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2417278848238 : Closed e2417278848238 ∧ code e2417278848238 = 11213371870446 := by decide
theorem cert_e2417278848238 : check e2417278848238 [[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2417278848246 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2417278848246 : Closed e2417278848246 ∧ code e2417278848246 = 11213371870454 := by decide
theorem cert_e2417278848246 : check e2417278848246 [[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2417278848622 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2417278848622 : Closed e2417278848622 ∧ code e2417278848622 = 11213371870830 := by decide
theorem cert_e2417278848622 : check e2417278848622 [[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e2417278848634 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2417278848634 : Closed e2417278848634 ∧ code e2417278848634 = 11213371870842 := by decide
theorem cert_e2417278848634 : checkPay e2417278848634 [[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left]] 0 [[.under,.under,.right,.left]] = true := by decide
def e2417278848822 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2417278848822 : Closed e2417278848822 ∧ code e2417278848822 = 11213371871030 := by decide
theorem cert_e2417278848822 : check e2417278848822 [[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2417278848826 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2417278848826 : Closed e2417278848826 ∧ code e2417278848826 = 11213371871034 := by decide
def e2417328434542 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2417328434542 : Closed e2417328434542 ∧ code e2417328434542 = 11213421456750 := by decide
theorem cert_e2417328434542 : check e2417328434542 [[],[]] .smaller = true := by decide
def e2417328434550 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2417328434550 : Closed e2417328434550 ∧ code e2417328434550 = 11213421456758 := by decide
theorem cert_e2417328434550 : check e2417328434550 [[],[]] .smaller = true := by decide
def e2417328434606 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2417328434606 : Closed e2417328434606 ∧ code e2417328434606 = 11213421456814 := by decide
theorem cert_e2417328434606 : check e2417328434606 [[],[]] .smaller = true := by decide
def e2417328434618 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2417328434618 : Closed e2417328434618 ∧ code e2417328434618 = 11213421456826 := by decide
theorem cert_e2417328434618 : check e2417328434618 [[],[]] .smaller = true := by decide
def e2417328434646 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2417328434646 : Closed e2417328434646 ∧ code e2417328434646 = 11213421456854 := by decide
theorem cert_e2417328434646 : check e2417328434646 [[],[]] .smaller = true := by decide
def e2417328434650 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2417328434650 : Closed e2417328434650 ∧ code e2417328434650 = 11213421456858 := by decide
theorem cert_e2417328434650 : check e2417328434650 [[],[]] .smaller = true := by decide
def e2417328434862 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2417328434862 : Closed e2417328434862 ∧ code e2417328434862 = 11213421457070 := by decide
theorem cert_e2417328434862 : check e2417328434862 [[],[]] .smaller = true := by decide
def e2417328434874 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2417328434874 : Closed e2417328434874 ∧ code e2417328434874 = 11213421457082 := by decide
theorem cert_e2417328434874 : check e2417328434874 [[],[]] .smaller = true := by decide
def e2417328434922 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2417328434922 : Closed e2417328434922 ∧ code e2417328434922 = 11213421457130 := by decide
theorem cert_e2417328434922 : check e2417328434922 [[],[]] .smaller = true := by decide
def e2417328435030 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2417328435030 : Closed e2417328435030 ∧ code e2417328435030 = 11213421457238 := by decide
theorem cert_e2417328435030 : check e2417328435030 [[],[]] .smaller = true := by decide
def e2417328435034 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2417328435034 : Closed e2417328435034 ∧ code e2417328435034 = 11213421457242 := by decide
theorem cert_e2417328435034 : check e2417328435034 [[],[]] .smaller = true := by decide
def e2417328435050 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2417328435050 : Closed e2417328435050 ∧ code e2417328435050 = 11213421457258 := by decide
theorem cert_e2417328435050 : check e2417328435050 [[],[]] .smaller = true := by decide
def e2417328436078 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2417328436078 : Closed e2417328436078 ∧ code e2417328436078 = 11213421458286 := by decide
theorem cert_e2417328436078 : check e2417328436078 [[],[]] .smaller = true := by decide
def e2417328436086 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2417328436086 : Closed e2417328436086 ∧ code e2417328436086 = 11213421458294 := by decide
theorem cert_e2417328436086 : check e2417328436086 [[],[]] .smaller = true := by decide
def e2417328436142 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2417328436142 : Closed e2417328436142 ∧ code e2417328436142 = 11213421458350 := by decide
theorem cert_e2417328436142 : check e2417328436142 [[],[]] .smaller = true := by decide
def e2417328436154 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2417328436154 : Closed e2417328436154 ∧ code e2417328436154 = 11213421458362 := by decide
theorem cert_e2417328436154 : check e2417328436154 [[],[]] .smaller = true := by decide
def e2417328436182 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2417328436182 : Closed e2417328436182 ∧ code e2417328436182 = 11213421458390 := by decide
theorem cert_e2417328436182 : check e2417328436182 [[],[]] .smaller = true := by decide
def e2417328436186 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2417328436186 : Closed e2417328436186 ∧ code e2417328436186 = 11213421458394 := by decide
theorem cert_e2417328436186 : check e2417328436186 [[],[]] .smaller = true := by decide
def e2417328436462 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2417328436462 : Closed e2417328436462 ∧ code e2417328436462 = 11213421458670 := by decide
theorem cert_e2417328436462 : check e2417328436462 [[],[]] .smaller = true := by decide
def e2417328436470 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2417328436470 : Closed e2417328436470 ∧ code e2417328436470 = 11213421458678 := by decide
theorem cert_e2417328436470 : check e2417328436470 [[],[]] .smaller = true := by decide
def e2417328436846 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2417328436846 : Closed e2417328436846 ∧ code e2417328436846 = 11213421459054 := by decide
theorem cert_e2417328436846 : check e2417328436846 [[],[]] .smaller = true := by decide
def e2417328436858 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2417328436858 : Closed e2417328436858 ∧ code e2417328436858 = 11213421459066 := by decide
theorem cert_e2417328436858 : check e2417328436858 [[],[]] .smaller = true := by decide
def e2417328437046 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2417328437046 : Closed e2417328437046 ∧ code e2417328437046 = 11213421459254 := by decide
theorem cert_e2417328437046 : check e2417328437046 [[],[]] .smaller = true := by decide
def e2417328437050 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2417328437050 : Closed e2417328437050 ∧ code e2417328437050 = 11213421459258 := by decide
theorem cert_e2417328437050 : check e2417328437050 [[],[]] .smaller = true := by decide
def e2417328437678 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2417328437678 : Closed e2417328437678 ∧ code e2417328437678 = 11213421459886 := by decide
theorem cert_e2417328437678 : check e2417328437678 [[],[]] .smaller = true := by decide
def e2417328437690 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2417328437690 : Closed e2417328437690 ∧ code e2417328437690 = 11213421459898 := by decide
theorem cert_e2417328437690 : check e2417328437690 [[],[]] .smaller = true := by decide
def e2417328437738 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2417328437738 : Closed e2417328437738 ∧ code e2417328437738 = 11213421459946 := by decide
theorem cert_e2417328437738 : check e2417328437738 [[],[]] .smaller = true := by decide
def e2417328437870 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2417328437870 : Closed e2417328437870 ∧ code e2417328437870 = 11213421460078 := by decide
theorem cert_e2417328437870 : check e2417328437870 [[],[]] .smaller = true := by decide
def e2417328437882 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2417328437882 : Closed e2417328437882 ∧ code e2417328437882 = 11213421460090 := by decide
theorem cert_e2417328437882 : check e2417328437882 [[],[]] .smaller = true := by decide
def e2417328438170 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2417328438170 : Closed e2417328438170 ∧ code e2417328438170 = 11213421460378 := by decide
theorem cert_e2417328438170 : check e2417328438170 [[],[]] .smaller = true := by decide
def e2417328438486 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2417328438486 : Closed e2417328438486 ∧ code e2417328438486 = 11213421460694 := by decide
theorem cert_e2417328438486 : check e2417328438486 [[],[]] .smaller = true := by decide
def e2417328438490 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2417328438490 : Closed e2417328438490 ∧ code e2417328438490 = 11213421460698 := by decide
theorem cert_e2417328438490 : check e2417328438490 [[],[]] .smaller = true := by decide
def e2417328438506 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2417328438506 : Closed e2417328438506 ∧ code e2417328438506 = 11213421460714 := by decide
theorem cert_e2417328438506 : check e2417328438506 [[],[]] .smaller = true := by decide
def e2417328438582 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2417328438582 : Closed e2417328438582 ∧ code e2417328438582 = 11213421460790 := by decide
theorem cert_e2417328438582 : check e2417328438582 [[],[]] .smaller = true := by decide
def e2417328438586 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2417328438586 : Closed e2417328438586 ∧ code e2417328438586 = 11213421460794 := by decide
theorem cert_e2417328438586 : check e2417328438586 [[],[]] .smaller = true := by decide
def e2417328438682 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2417328438682 : Closed e2417328438682 ∧ code e2417328438682 = 11213421460890 := by decide
theorem cert_e2417328438682 : check e2417328438682 [[],[]] .smaller = true := by decide
def e2417328442222 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2417328442222 : Closed e2417328442222 ∧ code e2417328442222 = 11213421464430 := by decide
theorem cert_e2417328442222 : check e2417328442222 [[],[]] .smaller = true := by decide
def e2417328442230 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2417328442230 : Closed e2417328442230 ∧ code e2417328442230 = 11213421464438 := by decide
theorem cert_e2417328442230 : check e2417328442230 [[],[]] .smaller = true := by decide
def e2417328442286 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2417328442286 : Closed e2417328442286 ∧ code e2417328442286 = 11213421464494 := by decide
theorem cert_e2417328442286 : check e2417328442286 [[],[]] .smaller = true := by decide
def e2417328442298 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2417328442298 : Closed e2417328442298 ∧ code e2417328442298 = 11213421464506 := by decide
theorem cert_e2417328442298 : check e2417328442298 [[],[]] .smaller = true := by decide
def e2417328442326 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2417328442326 : Closed e2417328442326 ∧ code e2417328442326 = 11213421464534 := by decide
theorem cert_e2417328442326 : check e2417328442326 [[],[]] .smaller = true := by decide
def e2417328442330 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2417328442330 : Closed e2417328442330 ∧ code e2417328442330 = 11213421464538 := by decide
theorem cert_e2417328442330 : check e2417328442330 [[],[]] .smaller = true := by decide
def e2417328442606 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2417328442606 : Closed e2417328442606 ∧ code e2417328442606 = 11213421464814 := by decide
theorem cert_e2417328442606 : check e2417328442606 [[],[]] .smaller = true := by decide
def e2417328442614 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2417328442614 : Closed e2417328442614 ∧ code e2417328442614 = 11213421464822 := by decide
theorem cert_e2417328442614 : check e2417328442614 [[],[]] .smaller = true := by decide
def e2417328442990 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2417328442990 : Closed e2417328442990 ∧ code e2417328442990 = 11213421465198 := by decide
theorem cert_e2417328442990 : check e2417328442990 [[],[]] .smaller = true := by decide
def e2417328443002 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2417328443002 : Closed e2417328443002 ∧ code e2417328443002 = 11213421465210 := by decide
theorem cert_e2417328443002 : check e2417328443002 [[],[]] .smaller = true := by decide
def e2417328443190 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2417328443190 : Closed e2417328443190 ∧ code e2417328443190 = 11213421465398 := by decide
theorem cert_e2417328443190 : check e2417328443190 [[],[]] .smaller = true := by decide
def e2417328443194 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2417328443194 : Closed e2417328443194 ∧ code e2417328443194 = 11213421465402 := by decide
theorem cert_e2417328443194 : check e2417328443194 [[],[]] .smaller = true := by decide
def e2417328448942 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2417328448942 : Closed e2417328448942 ∧ code e2417328448942 = 11213421471150 := by decide
theorem cert_e2417328448942 : check e2417328448942 [[],[]] .smaller = true := by decide
def e2417328448954 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2417328448954 : Closed e2417328448954 ∧ code e2417328448954 = 11213421471162 := by decide
theorem cert_e2417328448954 : check e2417328448954 [[],[]] .smaller = true := by decide
def e2417328449002 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2417328449002 : Closed e2417328449002 ∧ code e2417328449002 = 11213421471210 := by decide
theorem cert_e2417328449002 : check e2417328449002 [[],[]] .smaller = true := by decide
def e2417328449134 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2417328449134 : Closed e2417328449134 ∧ code e2417328449134 = 11213421471342 := by decide
theorem cert_e2417328449134 : check e2417328449134 [[],[]] .smaller = true := by decide
def e2417328449146 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2417328449146 : Closed e2417328449146 ∧ code e2417328449146 = 11213421471354 := by decide
theorem cert_e2417328449146 : check e2417328449146 [[],[]] .smaller = true := by decide
def e2417328449434 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2417328449434 : Closed e2417328449434 ∧ code e2417328449434 = 11213421471642 := by decide
theorem cert_e2417328449434 : check e2417328449434 [[],[]] .smaller = true := by decide
def e2417328452310 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2417328452310 : Closed e2417328452310 ∧ code e2417328452310 = 11213421474518 := by decide
theorem cert_e2417328452310 : check e2417328452310 [[],[]] .smaller = true := by decide
def e2417328452314 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2417328452314 : Closed e2417328452314 ∧ code e2417328452314 = 11213421474522 := by decide
theorem cert_e2417328452314 : check e2417328452314 [[],[]] .smaller = true := by decide
def e2417328452330 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2417328452330 : Closed e2417328452330 ∧ code e2417328452330 = 11213421474538 := by decide
theorem cert_e2417328452330 : check e2417328452330 [[],[]] .smaller = true := by decide
def e2417328452406 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2417328452406 : Closed e2417328452406 ∧ code e2417328452406 = 11213421474614 := by decide
theorem cert_e2417328452406 : check e2417328452406 [[],[]] .smaller = true := by decide
def e2417328452410 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2417328452410 : Closed e2417328452410 ∧ code e2417328452410 = 11213421474618 := by decide
theorem cert_e2417328452410 : check e2417328452410 [[],[]] .smaller = true := by decide
def e2417328452506 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2417328452506 : Closed e2417328452506 ∧ code e2417328452506 = 11213421474714 := by decide
theorem cert_e2417328452506 : check e2417328452506 [[],[]] .smaller = true := by decide
def e2417328568046 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2417328568046 : Closed e2417328568046 ∧ code e2417328568046 = 11213421590254 := by decide
theorem cert_e2417328568046 : check e2417328568046 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2417328568174 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2417328568174 : Closed e2417328568174 ∧ code e2417328568174 = 11213421590382 := by decide
theorem cert_e2417328568174 : check e2417328568174 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2417328568182 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2417328568182 : Closed e2417328568182 ∧ code e2417328568182 = 11213421590390 := by decide
def e2417328569070 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2417328569070 : Closed e2417328569070 ∧ code e2417328569070 = 11213421591278 := by decide
theorem cert_e2417328569070 : check e2417328569070 [[],[]] .sourceHead = true := by decide
def e2417328569262 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2417328569262 : Closed e2417328569262 ∧ code e2417328569262 = 11213421591470 := by decide
theorem cert_e2417328569262 : check e2417328569262 [[],[]] .sourceHead = true := by decide
def e2417328569274 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2417328569274 : Closed e2417328569274 ∧ code e2417328569274 = 11213421591482 := by decide
theorem cert_e2417328569274 : check e2417328569274 [[],[]] .sourceHead = true := by decide
def e2417328569710 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2417328569710 : Closed e2417328569710 ∧ code e2417328569710 = 11213421591918 := by decide
theorem cert_e2417328569710 : checkPay e2417328569710 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2417328569718 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2417328569718 : Closed e2417328569718 ∧ code e2417328569718 = 11213421591926 := by decide
theorem cert_e2417328569718 : check e2417328569718 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417328569774 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2417328569774 : Closed e2417328569774 ∧ code e2417328569774 = 11213421591982 := by decide
theorem cert_e2417328569774 : check e2417328569774 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2417328569786 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2417328569786 : Closed e2417328569786 ∧ code e2417328569786 = 11213421591994 := by decide
def e2417328569814 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2417328569814 : Closed e2417328569814 ∧ code e2417328569814 = 11213421592022 := by decide
private def t_e2417328569814 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e2417328569814 : ¬ IsSelfInterpreter e2417328569814 :=
  wSource (t := t_e2417328569814) (replay_sound (ps := []) (t := e2417328569814) (by decide)) (by decide)
def e2417328569818 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2417328569818 : Closed e2417328569818 ∧ code e2417328569818 = 11213421592026 := by decide
private def t_e2417328569818 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e2417328569818 : ¬ IsSelfInterpreter e2417328569818 :=
  wSource (t := t_e2417328569818) (replay_sound (ps := []) (t := e2417328569818) (by decide)) (by decide)
def e2417328574190 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2417328574190 : Closed e2417328574190 ∧ code e2417328574190 = 11213421596398 := by decide
theorem cert_e2417328574190 : check e2417328574190 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417328574318 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2417328574318 : Closed e2417328574318 ∧ code e2417328574318 = 11213421596526 := by decide
theorem cert_e2417328574318 : check e2417328574318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417328574326 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2417328574326 : Closed e2417328574326 ∧ code e2417328574326 = 11213421596534 := by decide
def e2417328577006 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2417328577006 : Closed e2417328577006 ∧ code e2417328577006 = 11213421599214 := by decide
theorem cert_e2417328577006 : check e2417328577006 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417328577774 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2417328577774 : Closed e2417328577774 ∧ code e2417328577774 = 11213421599982 := by decide
theorem cert_e2417328577774 : check e2417328577774 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417328577782 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2417328577782 : Closed e2417328577782 ∧ code e2417328577782 = 11213421599990 := by decide
theorem cert_e2417328577782 : check e2417328577782 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417328580334 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2417328580334 : Closed e2417328580334 ∧ code e2417328580334 = 11213421602542 := by decide
theorem cert_e2417328580334 : checkPay e2417328580334 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.under,.under,.left,.right,.right],[.under,.under,.under,.left,.right,.right,.left,.left],[.under,.under,.under,.left,.right,.right,.left],[.under,.under,.under,.left,.right,.right],[.under,.under,.under,.right],[.under,.under,.under,.right,.left,.left],[.under,.under,.under,.right,.left],[.under,.under,.under,.right]] = true := by decide
def e2417328580526 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2417328580526 : Closed e2417328580526 ∧ code e2417328580526 = 11213421602734 := by decide
theorem cert_e2417328580526 : checkPay e2417328580526 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.right],[.under,.under,.left,.right],[.under,.under,.left,.right,.left,.left,.left],[.under,.under,.left,.right,.left,.left],[.under,.under,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.right],[.under,.under,.left,.right,.left,.left,.right,.left],[.under,.under,.left,.right,.left,.left,.right]] = true := by decide
def e2417328580538 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2417328580538 : Closed e2417328580538 ∧ code e2417328580538 = 11213421602746 := by decide
theorem cert_e2417328580538 : checkPay e2417328580538 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2417328581102 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2417328581102 : Closed e2417328581102 ∧ code e2417328581102 = 11213421603310 := by decide
theorem cert_e2417328581102 : checkPay e2417328581102 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2417328582254 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2417328582254 : Closed e2417328582254 ∧ code e2417328582254 = 11213421604462 := by decide
theorem cert_e2417328582254 : checkPay e2417328582254 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e2417328582266 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2417328582266 : Closed e2417328582266 ∧ code e2417328582266 = 11213421604474 := by decide
theorem cert_e2417328582266 : checkPay e2417328582266 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.under,.left,.left,.right]] = true := by decide
def e2417328583534 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2417328583534 : Closed e2417328583534 ∧ code e2417328583534 = 11213421605742 := by decide
theorem cert_e2417328583534 : check e2417328583534 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2417328583542 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2417328583542 : Closed e2417328583542 ∧ code e2417328583542 = 11213421605750 := by decide
theorem cert_e2417328583542 : check e2417328583542 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2417328583598 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2417328583598 : Closed e2417328583598 ∧ code e2417328583598 = 11213421605806 := by decide
theorem cert_e2417328583598 : check e2417328583598 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2417328583610 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2417328583610 : Closed e2417328583610 ∧ code e2417328583610 = 11213421605818 := by decide
theorem cert_e2417328583610 : check e2417328583610 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2417328583638 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2417328583638 : Closed e2417328583638 ∧ code e2417328583638 = 11213421605846 := by decide
def e2417328583642 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2417328583642 : Closed e2417328583642 ∧ code e2417328583642 = 11213421605850 := by decide
theorem cert_e2417328583642 : check e2417328583642 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2417328583918 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2417328583918 : Closed e2417328583918 ∧ code e2417328583918 = 11213421606126 := by decide
theorem cert_e2417328583918 : check e2417328583918 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2417328583926 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2417328583926 : Closed e2417328583926 ∧ code e2417328583926 = 11213421606134 := by decide
theorem cert_e2417328583926 : check e2417328583926 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2417328584302 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2417328584302 : Closed e2417328584302 ∧ code e2417328584302 = 11213421606510 := by decide
theorem cert_e2417328584302 : check e2417328584302 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2417328584314 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2417328584314 : Closed e2417328584314 ∧ code e2417328584314 = 11213421606522 := by decide
theorem cert_e2417328584314 : check e2417328584314 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2417328584502 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2417328584502 : Closed e2417328584502 ∧ code e2417328584502 = 11213421606710 := by decide
private def t_e2417328584502 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e2417328584502 : ¬ IsSelfInterpreter e2417328584502 :=
  wSource (t := t_e2417328584502) (replay_sound (ps := []) (t := e2417328584502) (by decide)) (by decide)
def e2417328584506 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2417328584506 : Closed e2417328584506 ∧ code e2417328584506 = 11213421606714 := by decide
private def t_e2417328584506 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e2417328584506 : ¬ IsSelfInterpreter e2417328584506 :=
  wSource (t := t_e2417328584506) (replay_sound (ps := []) (t := e2417328584506) (by decide)) (by decide)
def e2417328589678 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2417328589678 : Closed e2417328589678 ∧ code e2417328589678 = 11213421611886 := by decide
theorem cert_e2417328589678 : check e2417328589678 [[],[]] .smaller = true := by decide
def e2417328589686 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2417328589686 : Closed e2417328589686 ∧ code e2417328589686 = 11213421611894 := by decide
theorem cert_e2417328589686 : check e2417328589686 [[],[]] .smaller = true := by decide
def e2417328589742 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2417328589742 : Closed e2417328589742 ∧ code e2417328589742 = 11213421611950 := by decide
theorem cert_e2417328589742 : check e2417328589742 [[],[]] .smaller = true := by decide
def e2417328589754 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2417328589754 : Closed e2417328589754 ∧ code e2417328589754 = 11213421611962 := by decide
theorem cert_e2417328589754 : check e2417328589754 [[],[]] .smaller = true := by decide
def e2417328589782 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2417328589782 : Closed e2417328589782 ∧ code e2417328589782 = 11213421611990 := by decide
theorem cert_e2417328589782 : check e2417328589782 [[],[]] .smaller = true := by decide
def e2417328589786 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2417328589786 : Closed e2417328589786 ∧ code e2417328589786 = 11213421611994 := by decide
theorem cert_e2417328589786 : check e2417328589786 [[],[]] .smaller = true := by decide
def e2417328590062 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2417328590062 : Closed e2417328590062 ∧ code e2417328590062 = 11213421612270 := by decide
theorem cert_e2417328590062 : check e2417328590062 [[],[]] .smaller = true := by decide
def e2417328590070 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2417328590070 : Closed e2417328590070 ∧ code e2417328590070 = 11213421612278 := by decide
theorem cert_e2417328590070 : check e2417328590070 [[],[]] .smaller = true := by decide
def e2417328590446 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2417328590446 : Closed e2417328590446 ∧ code e2417328590446 = 11213421612654 := by decide
theorem cert_e2417328590446 : check e2417328590446 [[],[]] .smaller = true := by decide
def e2417328590458 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2417328590458 : Closed e2417328590458 ∧ code e2417328590458 = 11213421612666 := by decide
theorem cert_e2417328590458 : check e2417328590458 [[],[]] .smaller = true := by decide
def e2417328590646 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2417328590646 : Closed e2417328590646 ∧ code e2417328590646 = 11213421612854 := by decide
theorem cert_e2417328590646 : check e2417328590646 [[],[]] .smaller = true := by decide
def e2417328590650 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2417328590650 : Closed e2417328590650 ∧ code e2417328590650 = 11213421612858 := by decide
theorem cert_e2417328590650 : check e2417328590650 [[],[]] .smaller = true := by decide
def e2417328598766 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2417328598766 : Closed e2417328598766 ∧ code e2417328598766 = 11213421620974 := by decide
theorem cert_e2417328598766 : check e2417328598766 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417328598894 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2417328598894 : Closed e2417328598894 ∧ code e2417328598894 = 11213421621102 := by decide
theorem cert_e2417328598894 : check e2417328598894 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417328598902 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2417328598902 : Closed e2417328598902 ∧ code e2417328598902 = 11213421621110 := by decide
def e2417328601582 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2417328601582 : Closed e2417328601582 ∧ code e2417328601582 = 11213421623790 := by decide
theorem cert_e2417328601582 : check e2417328601582 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2417328602350 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2417328602350 : Closed e2417328602350 ∧ code e2417328602350 = 11213421624558 := by decide
theorem cert_e2417328602350 : check e2417328602350 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2417328602358 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2417328602358 : Closed e2417328602358 ∧ code e2417328602358 = 11213421624566 := by decide
theorem cert_e2417328602358 : check e2417328602358 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2417328625390 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2417328625390 : Closed e2417328625390 ∧ code e2417328625390 = 11213421647598 := by decide
theorem cert_e2417328625390 : check e2417328625390 [[],[]] .sourceHead = true := by decide
def e2417328625582 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2417328625582 : Closed e2417328625582 ∧ code e2417328625582 = 11213421647790 := by decide
theorem cert_e2417328625582 : check e2417328625582 [[],[]] .sourceHead = true := by decide
def e2417328625594 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2417328625594 : Closed e2417328625594 ∧ code e2417328625594 = 11213421647802 := by decide
theorem cert_e2417328625594 : check e2417328625594 [[],[]] .sourceHead = true := by decide
def e2417328626158 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2417328626158 : Closed e2417328626158 ∧ code e2417328626158 = 11213421648366 := by decide
theorem cert_e2417328626158 : check e2417328626158 [[],[]] .sourceHead = true := by decide
def e2417328627310 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2417328627310 : Closed e2417328627310 ∧ code e2417328627310 = 11213421649518 := by decide
theorem cert_e2417328627310 : check e2417328627310 [[],[]] .sourceHead = true := by decide
def e2417328627322 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2417328627322 : Closed e2417328627322 ∧ code e2417328627322 = 11213421649530 := by decide
theorem cert_e2417328627322 : check e2417328627322 [[],[]] .sourceHead = true := by decide
def e2417328638830 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2417328638830 : Closed e2417328638830 ∧ code e2417328638830 = 11213421661038 := by decide
theorem cert_e2417328638830 : check e2417328638830 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328638838 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2417328638838 : Closed e2417328638838 ∧ code e2417328638838 = 11213421661046 := by decide
theorem cert_e2417328638838 : check e2417328638838 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328638894 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2417328638894 : Closed e2417328638894 ∧ code e2417328638894 = 11213421661102 := by decide
theorem cert_e2417328638894 : check e2417328638894 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328638906 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2417328638906 : Closed e2417328638906 ∧ code e2417328638906 = 11213421661114 := by decide
theorem cert_e2417328638906 : check e2417328638906 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328638934 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2417328638934 : Closed e2417328638934 ∧ code e2417328638934 = 11213421661142 := by decide
theorem cert_e2417328638934 : check e2417328638934 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328638938 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2417328638938 : Closed e2417328638938 ∧ code e2417328638938 = 11213421661146 := by decide
theorem cert_e2417328638938 : check e2417328638938 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328639214 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2417328639214 : Closed e2417328639214 ∧ code e2417328639214 = 11213421661422 := by decide
theorem cert_e2417328639214 : check e2417328639214 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328639222 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2417328639222 : Closed e2417328639222 ∧ code e2417328639222 = 11213421661430 := by decide
theorem cert_e2417328639222 : check e2417328639222 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328639598 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2417328639598 : Closed e2417328639598 ∧ code e2417328639598 = 11213421661806 := by decide
theorem cert_e2417328639598 : check e2417328639598 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328639610 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2417328639610 : Closed e2417328639610 ∧ code e2417328639610 = 11213421661818 := by decide
theorem cert_e2417328639610 : check e2417328639610 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328639798 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2417328639798 : Closed e2417328639798 ∧ code e2417328639798 = 11213421662006 := by decide
theorem cert_e2417328639798 : check e2417328639798 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417328639802 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2417328639802 : Closed e2417328639802 ∧ code e2417328639802 = 11213421662010 := by decide
theorem cert_e2417328639802 : check e2417328639802 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2417329179502 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2417329179502 : Closed e2417329179502 ∧ code e2417329179502 = 11213422201710 := by decide
theorem cert_e2417329179502 : check e2417329179502 [[],[]] .smaller = true := by decide
def e2417329179510 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2417329179510 : Closed e2417329179510 ∧ code e2417329179510 = 11213422201718 := by decide
theorem cert_e2417329179510 : check e2417329179510 [[],[]] .smaller = true := by decide
def e2417329179566 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2417329179566 : Closed e2417329179566 ∧ code e2417329179566 = 11213422201774 := by decide
theorem cert_e2417329179566 : check e2417329179566 [[],[]] .smaller = true := by decide
def e2417329179578 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2417329179578 : Closed e2417329179578 ∧ code e2417329179578 = 11213422201786 := by decide
theorem cert_e2417329179578 : check e2417329179578 [[],[]] .smaller = true := by decide
def e2417329179606 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2417329179606 : Closed e2417329179606 ∧ code e2417329179606 = 11213422201814 := by decide
theorem cert_e2417329179606 : check e2417329179606 [[],[]] .smaller = true := by decide
def e2417329179610 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2417329179610 : Closed e2417329179610 ∧ code e2417329179610 = 11213422201818 := by decide
theorem cert_e2417329179610 : check e2417329179610 [[],[]] .smaller = true := by decide
def e2417329179886 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2417329179886 : Closed e2417329179886 ∧ code e2417329179886 = 11213422202094 := by decide
theorem cert_e2417329179886 : check e2417329179886 [[],[]] .smaller = true := by decide
def e2417329179894 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2417329179894 : Closed e2417329179894 ∧ code e2417329179894 = 11213422202102 := by decide
theorem cert_e2417329179894 : check e2417329179894 [[],[]] .smaller = true := by decide
def e2417329180270 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2417329180270 : Closed e2417329180270 ∧ code e2417329180270 = 11213422202478 := by decide
theorem cert_e2417329180270 : check e2417329180270 [[],[]] .smaller = true := by decide
def e2417329180282 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2417329180282 : Closed e2417329180282 ∧ code e2417329180282 = 11213422202490 := by decide
theorem cert_e2417329180282 : check e2417329180282 [[],[]] .smaller = true := by decide
def e2417329180470 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2417329180470 : Closed e2417329180470 ∧ code e2417329180470 = 11213422202678 := by decide
theorem cert_e2417329180470 : check e2417329180470 [[],[]] .smaller = true := by decide
def e2417329180474 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2417329180474 : Closed e2417329180474 ∧ code e2417329180474 = 11213422202682 := by decide
theorem cert_e2417329180474 : check e2417329180474 [[],[]] .smaller = true := by decide
def e2418067336730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067336730 : Closed e2418067336730 ∧ code e2418067336730 = 11214160358938 := by decide
theorem cert_e2418067336730 : check e2418067336730 [[],[],[.left]] .chain = true := by decide
def e2418067338778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067338778 : Closed e2418067338778 ∧ code e2418067338778 = 11214160360986 := by decide
theorem cert_e2418067338778 : check e2418067338778 [[],[],[.left]] .chain = true := by decide
def e2418067353114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067353114 : Closed e2418067353114 ∧ code e2418067353114 = 11214160375322 := by decide
theorem cert_e2418067353114 : check e2418067353114 [[],[],[.left]] .chain = true := by decide
def e2418067356186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067356186 : Closed e2418067356186 ∧ code e2418067356186 = 11214160378394 := by decide
theorem cert_e2418067356186 : check e2418067356186 [[],[],[.left]] .chain = true := by decide
def e2418067363354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067363354 : Closed e2418067363354 ∧ code e2418067363354 = 11214160385562 := by decide
theorem cert_e2418067363354 : check e2418067363354 [[],[],[.left]] .chain = true := by decide
def e2418067364378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067364378 : Closed e2418067364378 ∧ code e2418067364378 = 11214160386586 := by decide
theorem cert_e2418067364378 : check e2418067364378 [[],[],[.left]] .chain = true := by decide
def e2418067435034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067435034 : Closed e2418067435034 ∧ code e2418067435034 = 11214160457242 := by decide
theorem cert_e2418067435034 : check e2418067435034 [[],[],[.left]] .chain = true := by decide
def e2418067437082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067437082 : Closed e2418067437082 ∧ code e2418067437082 = 11214160459290 := by decide
theorem cert_e2418067437082 : check e2418067437082 [[],[],[.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2417278847962
#print axioms Blc.Floor43.cert_e2417328569814
#print axioms Blc.Floor43.cert_e2417328569818
#print axioms Blc.Floor43.cert_e2417328584502
#print axioms Blc.Floor43.cert_e2417328584506
