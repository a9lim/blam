import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393374289134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393374289134 : Closed e2393374289134 ∧ code e2393374289134 = 11189467311342 := by decide
theorem cert_e2393374289134 : check e2393374289134 [[],[.left],[],[.under]] .three = true := by decide
def e2393374289142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393374289142 : Closed e2393374289142 ∧ code e2393374289142 = 11189467311350 := by decide
theorem cert_e2393374289142 : check e2393374289142 [[],[.left],[],[.under]] .three = true := by decide
def e2393374289422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393374289422 : Closed e2393374289422 ∧ code e2393374289422 = 11189467311630 := by decide
theorem cert_e2393374289422 : check e2393374289422 [[],[.left],[],[.under]] .three = true := by decide
def e2393374289434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393374289434 : Closed e2393374289434 ∧ code e2393374289434 = 11189467311642 := by decide
theorem cert_e2393374289434 : check e2393374289434 [[],[.left],[],[.under]] .three = true := by decide
def e2393374289506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393374289506 : Closed e2393374289506 ∧ code e2393374289506 = 11189467311714 := by decide
theorem cert_e2393374289506 : check e2393374289506 [[],[.left],[],[.under]] .three = true := by decide
def e2393374289518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393374289518 : Closed e2393374289518 ∧ code e2393374289518 = 11189467311726 := by decide
theorem cert_e2393374289518 : check e2393374289518 [[],[.left],[],[.under]] .three = true := by decide
def e2393374289526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393374289526 : Closed e2393374289526 ∧ code e2393374289526 = 11189467311734 := by decide
theorem cert_e2393374289526 : check e2393374289526 [[],[.left],[],[.under]] .three = true := by decide
def e2393374289530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393374289530 : Closed e2393374289530 ∧ code e2393374289530 = 11189467311738 := by decide
theorem cert_e2393374289530 : check e2393374289530 [[],[.left],[],[.under]] .three = true := by decide
def e2393374290798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2393374290798 : Closed e2393374290798 ∧ code e2393374290798 = 11189467313006 := by decide
theorem cert_e2393374290798 : check e2393374290798 [[],[.left],[],[.under]] .three = true := by decide
def e2393374290806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2393374290806 : Closed e2393374290806 ∧ code e2393374290806 = 11189467313014 := by decide
theorem cert_e2393374290806 : check e2393374290806 [[],[.left],[],[.under]] .three = true := by decide
def e2393374290862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2393374290862 : Closed e2393374290862 ∧ code e2393374290862 = 11189467313070 := by decide
theorem cert_e2393374290862 : check e2393374290862 [[],[.left],[],[.under]] .three = true := by decide
def e2393374290874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2393374290874 : Closed e2393374290874 ∧ code e2393374290874 = 11189467313082 := by decide
theorem cert_e2393374290874 : check e2393374290874 [[],[.left],[],[.under]] .three = true := by decide
def e2393374290902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2393374290902 : Closed e2393374290902 ∧ code e2393374290902 = 11189467313110 := by decide
theorem cert_e2393374290902 : check e2393374290902 [[],[.left],[],[.under]] .three = true := by decide
def e2393374290906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2393374290906 : Closed e2393374290906 ∧ code e2393374290906 = 11189467313114 := by decide
theorem cert_e2393374290906 : check e2393374290906 [[],[.left],[],[.under]] .three = true := by decide
def e2393374291182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393374291182 : Closed e2393374291182 ∧ code e2393374291182 = 11189467313390 := by decide
theorem cert_e2393374291182 : check e2393374291182 [[],[.left],[],[.under]] .three = true := by decide
def e2393374291190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393374291190 : Closed e2393374291190 ∧ code e2393374291190 = 11189467313398 := by decide
theorem cert_e2393374291190 : check e2393374291190 [[],[.left],[],[.under]] .three = true := by decide
def e2393374291566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393374291566 : Closed e2393374291566 ∧ code e2393374291566 = 11189467313774 := by decide
theorem cert_e2393374291566 : check e2393374291566 [[],[.left],[],[.under]] .three = true := by decide
def e2393374291578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393374291578 : Closed e2393374291578 ∧ code e2393374291578 = 11189467313786 := by decide
theorem cert_e2393374291578 : check e2393374291578 [[],[.left],[],[.under]] .three = true := by decide
def e2393374291766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393374291766 : Closed e2393374291766 ∧ code e2393374291766 = 11189467313974 := by decide
theorem cert_e2393374291766 : check e2393374291766 [[],[.left],[],[.under]] .three = true := by decide
def e2393374291770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393374291770 : Closed e2393374291770 ∧ code e2393374291770 = 11189467313978 := by decide
theorem cert_e2393374291770 : check e2393374291770 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2393374292026 : Closed e2393374292026 ∧ code e2393374292026 = 11189467314234 := by decide
theorem cert_e2393374292026 : check e2393374292026 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2393374292074 : Closed e2393374292074 ∧ code e2393374292074 = 11189467314282 := by decide
theorem cert_e2393374292074 : check e2393374292074 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393374292122 : Closed e2393374292122 ∧ code e2393374292122 = 11189467314330 := by decide
theorem cert_e2393374292122 : check e2393374292122 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e2393374292166 : Closed e2393374292166 ∧ code e2393374292166 = 11189467314374 := by decide
theorem cert_e2393374292166 : check e2393374292166 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393374292362 : Closed e2393374292362 ∧ code e2393374292362 = 11189467314570 := by decide
theorem cert_e2393374292362 : check e2393374292362 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393374292386 : Closed e2393374292386 ∧ code e2393374292386 = 11189467314594 := by decide
theorem cert_e2393374292386 : check e2393374292386 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2393374292398 : Closed e2393374292398 ∧ code e2393374292398 = 11189467314606 := by decide
theorem cert_e2393374292398 : check e2393374292398 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2393374292406 : Closed e2393374292406 ∧ code e2393374292406 = 11189467314614 := by decide
theorem cert_e2393374292406 : check e2393374292406 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2393374292410 : Closed e2393374292410 ∧ code e2393374292410 = 11189467314618 := by decide
theorem cert_e2393374292410 : check e2393374292410 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2393374292438 : Closed e2393374292438 ∧ code e2393374292438 = 11189467314646 := by decide
theorem cert_e2393374292438 : check e2393374292438 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2393374292442 : Closed e2393374292442 ∧ code e2393374292442 = 11189467314650 := by decide
theorem cert_e2393374292442 : check e2393374292442 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2393374292458 : Closed e2393374292458 ∧ code e2393374292458 = 11189467314666 := by decide
theorem cert_e2393374292458 : check e2393374292458 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393374292494 : Closed e2393374292494 ∧ code e2393374292494 = 11189467314702 := by decide
theorem cert_e2393374292494 : check e2393374292494 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393374292506 : Closed e2393374292506 ∧ code e2393374292506 = 11189467314714 := by decide
theorem cert_e2393374292506 : check e2393374292506 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393374292578 : Closed e2393374292578 ∧ code e2393374292578 = 11189467314786 := by decide
theorem cert_e2393374292578 : check e2393374292578 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393374292590 : Closed e2393374292590 ∧ code e2393374292590 = 11189467314798 := by decide
theorem cert_e2393374292590 : check e2393374292590 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393374292598 : Closed e2393374292598 ∧ code e2393374292598 = 11189467314806 := by decide
theorem cert_e2393374292598 : check e2393374292598 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393374292602 : Closed e2393374292602 ∧ code e2393374292602 = 11189467314810 := by decide
theorem cert_e2393374292602 : check e2393374292602 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393374292790 : Closed e2393374292790 ∧ code e2393374292790 = 11189467314998 := by decide
theorem cert_e2393374292790 : check e2393374292790 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393374292794 : Closed e2393374292794 ∧ code e2393374292794 = 11189467315002 := by decide
theorem cert_e2393374292794 : check e2393374292794 [[],[.left],[],[.under]] .three = true := by decide
def e2393374292890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393374292890 : Closed e2393374292890 ∧ code e2393374292890 = 11189467315098 := by decide
theorem cert_e2393374292890 : check e2393374292890 [[],[.left],[],[.under]] .three = true := by decide
def e2393374296030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e2393374296030 : Closed e2393374296030 ∧ code e2393374296030 = 11189467318238 := by decide
theorem cert_e2393374296030 : check e2393374296030 [[],[.left],[],[.under]] .three = true := by decide
def e2393374299694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2393374299694 : Closed e2393374299694 ∧ code e2393374299694 = 11189467321902 := by decide
theorem cert_e2393374299694 : check e2393374299694 [[],[.left],[],[.under]] .three = true := by decide
def e2393374299874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2393374299874 : Closed e2393374299874 ∧ code e2393374299874 = 11189467322082 := by decide
theorem cert_e2393374299874 : check e2393374299874 [[],[.left],[],[.under]] .three = true := by decide
def e2393374299886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2393374299886 : Closed e2393374299886 ∧ code e2393374299886 = 11189467322094 := by decide
theorem cert_e2393374299886 : check e2393374299886 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2393374300014 : Closed e2393374300014 ∧ code e2393374300014 = 11189467322222 := by decide
theorem cert_e2393374300014 : check e2393374300014 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2393374300022 : Closed e2393374300022 ∧ code e2393374300022 = 11189467322230 := by decide
theorem cert_e2393374300022 : check e2393374300022 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393374300042 : Closed e2393374300042 ∧ code e2393374300042 = 11189467322250 := by decide
theorem cert_e2393374300042 : check e2393374300042 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393374300066 : Closed e2393374300066 ∧ code e2393374300066 = 11189467322274 := by decide
theorem cert_e2393374300066 : check e2393374300066 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2393374300078 : Closed e2393374300078 ∧ code e2393374300078 = 11189467322286 := by decide
theorem cert_e2393374300078 : check e2393374300078 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2393374300086 : Closed e2393374300086 ∧ code e2393374300086 = 11189467322294 := by decide
theorem cert_e2393374300086 : check e2393374300086 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2393374300090 : Closed e2393374300090 ∧ code e2393374300090 = 11189467322298 := by decide
theorem cert_e2393374300090 : check e2393374300090 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2393374300222 : Closed e2393374300222 ∧ code e2393374300222 = 11189467322430 := by decide
theorem cert_e2393374300222 : check e2393374300222 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2393374300642 : Closed e2393374300642 ∧ code e2393374300642 = 11189467322850 := by decide
theorem cert_e2393374300642 : check e2393374300642 [[],[.left],[],[.under]] .three = true := by decide
def e2393374300654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393374300654 : Closed e2393374300654 ∧ code e2393374300654 = 11189467322862 := by decide
theorem cert_e2393374300654 : check e2393374300654 [[],[.left],[],[.under]] .three = true := by decide
def e2393374301422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393374301422 : Closed e2393374301422 ∧ code e2393374301422 = 11189467323630 := by decide
theorem cert_e2393374301422 : check e2393374301422 [[],[.left],[],[.under]] .three = true := by decide
def e2393374301430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393374301430 : Closed e2393374301430 ∧ code e2393374301430 = 11189467323638 := by decide
theorem cert_e2393374301430 : check e2393374301430 [[],[.left],[],[.under]] .three = true := by decide
def e2393374301710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2393374301710 : Closed e2393374301710 ∧ code e2393374301710 = 11189467323918 := by decide
theorem cert_e2393374301710 : check e2393374301710 [[],[.left],[],[.under]] .three = true := by decide
def e2393374301722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2393374301722 : Closed e2393374301722 ∧ code e2393374301722 = 11189467323930 := by decide
theorem cert_e2393374301722 : check e2393374301722 [[],[.left],[],[.under]] .three = true := by decide
def e2393374301794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393374301794 : Closed e2393374301794 ∧ code e2393374301794 = 11189467324002 := by decide
theorem cert_e2393374301794 : check e2393374301794 [[],[.left],[],[.under]] .three = true := by decide
def e2393374301806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393374301806 : Closed e2393374301806 ∧ code e2393374301806 = 11189467324014 := by decide
theorem cert_e2393374301806 : check e2393374301806 [[],[.left],[],[.under]] .three = true := by decide
def e2393374301814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393374301814 : Closed e2393374301814 ∧ code e2393374301814 = 11189467324022 := by decide
theorem cert_e2393374301814 : check e2393374301814 [[],[.left],[],[.under]] .three = true := by decide
def e2393374301818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393374301818 : Closed e2393374301818 ∧ code e2393374301818 = 11189467324026 := by decide
theorem cert_e2393374301818 : check e2393374301818 [[],[.left],[],[.under]] .three = true := by decide
def e2393374313326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393374313326 : Closed e2393374313326 ∧ code e2393374313326 = 11189467335534 := by decide
theorem cert_e2393374313326 : check e2393374313326 [[],[.left],[],[.under]] .three = true := by decide
def e2393374313334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393374313334 : Closed e2393374313334 ∧ code e2393374313334 = 11189467335542 := by decide
theorem cert_e2393374313334 : check e2393374313334 [[],[.left],[],[.under]] .three = true := by decide
def e2393374313390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393374313390 : Closed e2393374313390 ∧ code e2393374313390 = 11189467335598 := by decide
theorem cert_e2393374313390 : check e2393374313390 [[],[.left],[],[.under]] .three = true := by decide
def e2393374313402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393374313402 : Closed e2393374313402 ∧ code e2393374313402 = 11189467335610 := by decide
theorem cert_e2393374313402 : check e2393374313402 [[],[.left],[],[.under]] .three = true := by decide
def e2393374313430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393374313430 : Closed e2393374313430 ∧ code e2393374313430 = 11189467335638 := by decide
theorem cert_e2393374313430 : check e2393374313430 [[],[.left],[],[.under]] .three = true := by decide
def e2393374313434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393374313434 : Closed e2393374313434 ∧ code e2393374313434 = 11189467335642 := by decide
theorem cert_e2393374313434 : check e2393374313434 [[],[.left],[],[.under]] .three = true := by decide
def e2393374313710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393374313710 : Closed e2393374313710 ∧ code e2393374313710 = 11189467335918 := by decide
theorem cert_e2393374313710 : check e2393374313710 [[],[.left],[],[.under]] .three = true := by decide
def e2393374313718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393374313718 : Closed e2393374313718 ∧ code e2393374313718 = 11189467335926 := by decide
theorem cert_e2393374313718 : check e2393374313718 [[],[.left],[],[.under]] .three = true := by decide
def e2393374314094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393374314094 : Closed e2393374314094 ∧ code e2393374314094 = 11189467336302 := by decide
theorem cert_e2393374314094 : check e2393374314094 [[],[.left],[],[.under]] .three = true := by decide
def e2393374314106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393374314106 : Closed e2393374314106 ∧ code e2393374314106 = 11189467336314 := by decide
theorem cert_e2393374314106 : check e2393374314106 [[],[.left],[],[.under]] .three = true := by decide
def e2393374314294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393374314294 : Closed e2393374314294 ∧ code e2393374314294 = 11189467336502 := by decide
theorem cert_e2393374314294 : check e2393374314294 [[],[.left],[],[.under]] .three = true := by decide
def e2393374314298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393374314298 : Closed e2393374314298 ∧ code e2393374314298 = 11189467336506 := by decide
theorem cert_e2393374314298 : check e2393374314298 [[],[.left],[],[.under]] .three = true := by decide
def e2393374319070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2393374319070 : Closed e2393374319070 ∧ code e2393374319070 = 11189467341278 := by decide
theorem cert_e2393374319070 : check e2393374319070 [[],[.left],[],[.under]] .three = true := by decide
def e2393374319094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2393374319094 : Closed e2393374319094 ∧ code e2393374319094 = 11189467341302 := by decide
theorem cert_e2393374319094 : check e2393374319094 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393374320010 : Closed e2393374320010 ∧ code e2393374320010 = 11189467342218 := by decide
theorem cert_e2393374320010 : check e2393374320010 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393374320034 : Closed e2393374320034 ∧ code e2393374320034 = 11189467342242 := by decide
theorem cert_e2393374320034 : check e2393374320034 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2393374320046 : Closed e2393374320046 ∧ code e2393374320046 = 11189467342254 := by decide
theorem cert_e2393374320046 : check e2393374320046 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2393374320054 : Closed e2393374320054 ∧ code e2393374320054 = 11189467342262 := by decide
theorem cert_e2393374320054 : check e2393374320054 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2393374320058 : Closed e2393374320058 ∧ code e2393374320058 = 11189467342266 := by decide
theorem cert_e2393374320058 : check e2393374320058 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2393374320086 : Closed e2393374320086 ∧ code e2393374320086 = 11189467342294 := by decide
theorem cert_e2393374320086 : check e2393374320086 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2393374320090 : Closed e2393374320090 ∧ code e2393374320090 = 11189467342298 := by decide
theorem cert_e2393374320090 : check e2393374320090 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2393374320106 : Closed e2393374320106 ∧ code e2393374320106 = 11189467342314 := by decide
theorem cert_e2393374320106 : check e2393374320106 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e2393374320142 : Closed e2393374320142 ∧ code e2393374320142 = 11189467342350 := by decide
theorem cert_e2393374320142 : check e2393374320142 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2393374320154 : Closed e2393374320154 ∧ code e2393374320154 = 11189467342362 := by decide
theorem cert_e2393374320154 : check e2393374320154 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393374320226 : Closed e2393374320226 ∧ code e2393374320226 = 11189467342434 := by decide
theorem cert_e2393374320226 : check e2393374320226 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393374320238 : Closed e2393374320238 ∧ code e2393374320238 = 11189467342446 := by decide
theorem cert_e2393374320238 : check e2393374320238 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393374320246 : Closed e2393374320246 ∧ code e2393374320246 = 11189467342454 := by decide
theorem cert_e2393374320246 : check e2393374320246 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393374320250 : Closed e2393374320250 ∧ code e2393374320250 = 11189467342458 := by decide
theorem cert_e2393374320250 : check e2393374320250 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393374320438 : Closed e2393374320438 ∧ code e2393374320438 = 11189467342646 := by decide
theorem cert_e2393374320438 : check e2393374320438 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393374320442 : Closed e2393374320442 ∧ code e2393374320442 = 11189467342650 := by decide
theorem cert_e2393374320442 : check e2393374320442 [[],[.left],[],[.under]] .three = true := by decide
def e2393374320538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393374320538 : Closed e2393374320538 ∧ code e2393374320538 = 11189467342746 := by decide
theorem cert_e2393374320538 : check e2393374320538 [[],[.left],[],[.under]] .three = true := by decide
def e2393374469598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2393374469598 : Closed e2393374469598 ∧ code e2393374469598 = 11189467491806 := by decide
theorem cert_e2393374469598 : check e2393374469598 [[],[.left],[],[.under]] .three = true := by decide
def e2393374469614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2393374469614 : Closed e2393374469614 ∧ code e2393374469614 = 11189467491822 := by decide
private def t_e2393374469614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem cert_e2393374469614 : ¬ IsSelfInterpreter e2393374469614 :=
  wSource (t := t_e2393374469614) (replay_sound (ps := []) (t := e2393374469614) (by decide)) (by decide)
def e2393374469870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2393374469870 : Closed e2393374469870 ∧ code e2393374469870 = 11189467492078 := by decide
theorem cert_e2393374469870 : check e2393374469870 [[],[.left],[],[.under]] .three = true := by decide
def e2393374469982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2393374469982 : Closed e2393374469982 ∧ code e2393374469982 = 11189467492190 := by decide
theorem cert_e2393374469982 : check e2393374469982 [[],[.left],[],[.under]] .three = true := by decide
def e2393374469998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2393374469998 : Closed e2393374469998 ∧ code e2393374469998 = 11189467492206 := by decide
theorem cert_e2393374469998 : check e2393374469998 [[],[.left],[],[.under]] .three = true := by decide
def e2393374470006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2393374470006 : Closed e2393374470006 ∧ code e2393374470006 = 11189467492214 := by decide
theorem cert_e2393374470006 : check e2393374470006 [[],[.left],[],[.under]] .three = true := by decide
def e2393374470010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2393374470010 : Closed e2393374470010 ∧ code e2393374470010 = 11189467492218 := by decide
theorem cert_e2393374470010 : check e2393374470010 [[],[.left],[],[.under]] .three = true := by decide
def e2393374470062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2393374470062 : Closed e2393374470062 ∧ code e2393374470062 = 11189467492270 := by decide
private def t_e2393374470062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem cert_e2393374470062 : ¬ IsSelfInterpreter e2393374470062 :=
  wSource (t := t_e2393374470062) (replay_sound (ps := []) (t := e2393374470062) (by decide)) (by decide)
def e2393374470074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2393374470074 : Closed e2393374470074 ∧ code e2393374470074 = 11189467492282 := by decide
theorem cert_e2393374470074 : check e2393374470074 [[],[.left],[],[.under]] .three = true := by decide
def e2393374471134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2393374471134 : Closed e2393374471134 ∧ code e2393374471134 = 11189467493342 := by decide
theorem cert_e2393374471134 : check e2393374471134 [[],[.left],[],[.under]] .three = true := by decide
def e2393374471150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2393374471150 : Closed e2393374471150 ∧ code e2393374471150 = 11189467493358 := by decide
theorem cert_e2393374471150 : check e2393374471150 [[],[.left],[],[.under]] .three = true := by decide
def e2393374472686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393374472686 : Closed e2393374472686 ∧ code e2393374472686 = 11189467494894 := by decide
theorem cert_e2393374472686 : check e2393374472686 [[],[.left],[],[.under]] .three = true := by decide
def e2393374473438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2393374473438 : Closed e2393374473438 ∧ code e2393374473438 = 11189467495646 := by decide
theorem cert_e2393374473438 : check e2393374473438 [[],[.left],[],[.under]] .three = true := by decide
def e2393374473454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393374473454 : Closed e2393374473454 ∧ code e2393374473454 = 11189467495662 := by decide
theorem cert_e2393374473454 : check e2393374473454 [[],[.left],[],[.under]] .three = true := by decide
def e2393374473462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393374473462 : Closed e2393374473462 ∧ code e2393374473462 = 11189467495670 := by decide
theorem cert_e2393374473462 : check e2393374473462 [[],[.left],[],[.under]] .three = true := by decide
def e2393374473466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2393374473466 : Closed e2393374473466 ∧ code e2393374473466 = 11189467495674 := by decide
theorem cert_e2393374473466 : check e2393374473466 [[],[.left],[],[.under]] .three = true := by decide
def e2393374473838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393374473838 : Closed e2393374473838 ∧ code e2393374473838 = 11189467496046 := by decide
theorem cert_e2393374473838 : check e2393374473838 [[],[.left],[],[.under]] .three = true := by decide
def e2393374473850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393374473850 : Closed e2393374473850 ∧ code e2393374473850 = 11189467496058 := by decide
theorem cert_e2393374473850 : check e2393374473850 [[],[.left],[],[.under]] .three = true := by decide
def e2393374501974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2393374501974 : Closed e2393374501974 ∧ code e2393374501974 = 11189467524182 := by decide
theorem cert_e2393374501974 : check e2393374501974 [[],[.left],[],[.under]] .three = true := by decide
def e2393374501978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2393374501978 : Closed e2393374501978 ∧ code e2393374501978 = 11189467524186 := by decide
theorem cert_e2393374501978 : check e2393374501978 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393374502166 : Closed e2393374502166 ∧ code e2393374502166 = 11189467524374 := by decide
theorem cert_e2393374502166 : check e2393374502166 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393374502242 : Closed e2393374502242 ∧ code e2393374502242 = 11189467524450 := by decide
theorem cert_e2393374502242 : check e2393374502242 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2393374502254 : Closed e2393374502254 ∧ code e2393374502254 = 11189467524462 := by decide
theorem cert_e2393374502254 : check e2393374502254 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2393374502262 : Closed e2393374502262 ∧ code e2393374502262 = 11189467524470 := by decide
theorem cert_e2393374502262 : check e2393374502262 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393374502282 : Closed e2393374502282 ∧ code e2393374502282 = 11189467524490 := by decide
theorem cert_e2393374502282 : check e2393374502282 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393374502306 : Closed e2393374502306 ∧ code e2393374502306 = 11189467524514 := by decide
theorem cert_e2393374502306 : check e2393374502306 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2393374502318 : Closed e2393374502318 ∧ code e2393374502318 = 11189467524526 := by decide
theorem cert_e2393374502318 : check e2393374502318 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e2393374502326 : Closed e2393374502326 ∧ code e2393374502326 = 11189467524534 := by decide
theorem cert_e2393374502326 : check e2393374502326 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2393374502330 : Closed e2393374502330 ∧ code e2393374502330 = 11189467524538 := by decide
theorem cert_e2393374502330 : check e2393374502330 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2393374502358 : Closed e2393374502358 ∧ code e2393374502358 = 11189467524566 := by decide
theorem cert_e2393374502358 : check e2393374502358 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2393374502362 : Closed e2393374502362 ∧ code e2393374502362 = 11189467524570 := by decide
theorem cert_e2393374502362 : check e2393374502362 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2393374502442 : Closed e2393374502442 ∧ code e2393374502442 = 11189467524650 := by decide
theorem cert_e2393374502442 : check e2393374502442 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393374502538 : Closed e2393374502538 ∧ code e2393374502538 = 11189467524746 := by decide
theorem cert_e2393374502538 : check e2393374502538 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393374502562 : Closed e2393374502562 ∧ code e2393374502562 = 11189467524770 := by decide
theorem cert_e2393374502562 : check e2393374502562 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2393374502574 : Closed e2393374502574 ∧ code e2393374502574 = 11189467524782 := by decide
theorem cert_e2393374502574 : check e2393374502574 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2393374502582 : Closed e2393374502582 ∧ code e2393374502582 = 11189467524790 := by decide
theorem cert_e2393374502582 : check e2393374502582 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2393374502586 : Closed e2393374502586 ∧ code e2393374502586 = 11189467524794 := by decide
theorem cert_e2393374502586 : check e2393374502586 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2393374502614 : Closed e2393374502614 ∧ code e2393374502614 = 11189467524822 := by decide
theorem cert_e2393374502614 : check e2393374502614 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2393374502618 : Closed e2393374502618 ∧ code e2393374502618 = 11189467524826 := by decide
theorem cert_e2393374502618 : check e2393374502618 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2393374502634 : Closed e2393374502634 ∧ code e2393374502634 = 11189467524842 := by decide
theorem cert_e2393374502634 : check e2393374502634 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2393374502742 : Closed e2393374502742 ∧ code e2393374502742 = 11189467524950 := by decide
theorem cert_e2393374502742 : check e2393374502742 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2393374502746 : Closed e2393374502746 ∧ code e2393374502746 = 11189467524954 := by decide
theorem cert_e2393374502746 : check e2393374502746 [[],[.left],[],[.under]] .three = true := by decide
def e2393374502762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2393374502762 : Closed e2393374502762 ∧ code e2393374502762 = 11189467524970 := by decide
theorem cert_e2393374502762 : check e2393374502762 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2393374503030 : Closed e2393374503030 ∧ code e2393374503030 = 11189467525238 := by decide
theorem cert_e2393374503030 : check e2393374503030 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2393374503034 : Closed e2393374503034 ∧ code e2393374503034 = 11189467525242 := by decide
theorem cert_e2393374503034 : check e2393374503034 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2393374503126 : Closed e2393374503126 ∧ code e2393374503126 = 11189467525334 := by decide
theorem cert_e2393374503126 : check e2393374503126 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393374503222 : Closed e2393374503222 ∧ code e2393374503222 = 11189467525430 := by decide
theorem cert_e2393374503222 : check e2393374503222 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393374503226 : Closed e2393374503226 ∧ code e2393374503226 = 11189467525434 := by decide
theorem cert_e2393374503226 : check e2393374503226 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2393374503310 : Closed e2393374503310 ∧ code e2393374503310 = 11189467525518 := by decide
theorem cert_e2393374503310 : check e2393374503310 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2393374503366 : Closed e2393374503366 ∧ code e2393374503366 = 11189467525574 := by decide
theorem cert_e2393374503366 : check e2393374503366 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2393374503702 : Closed e2393374503702 ∧ code e2393374503702 = 11189467525910 := by decide
theorem cert_e2393374503702 : check e2393374503702 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2393374503778 : Closed e2393374503778 ∧ code e2393374503778 = 11189467525986 := by decide
theorem cert_e2393374503778 : check e2393374503778 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2393374503790 : Closed e2393374503790 ∧ code e2393374503790 = 11189467525998 := by decide
theorem cert_e2393374503790 : check e2393374503790 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2393374503798 : Closed e2393374503798 ∧ code e2393374503798 = 11189467526006 := by decide
theorem cert_e2393374503798 : check e2393374503798 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393374503818 : Closed e2393374503818 ∧ code e2393374503818 = 11189467526026 := by decide
theorem cert_e2393374503818 : check e2393374503818 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393374503842 : Closed e2393374503842 ∧ code e2393374503842 = 11189467526050 := by decide
theorem cert_e2393374503842 : check e2393374503842 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2393374503854 : Closed e2393374503854 ∧ code e2393374503854 = 11189467526062 := by decide
theorem cert_e2393374503854 : check e2393374503854 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e2393374503862 : Closed e2393374503862 ∧ code e2393374503862 = 11189467526070 := by decide
theorem cert_e2393374503862 : check e2393374503862 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2393374503866 : Closed e2393374503866 ∧ code e2393374503866 = 11189467526074 := by decide
theorem cert_e2393374503866 : check e2393374503866 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2393374503894 : Closed e2393374503894 ∧ code e2393374503894 = 11189467526102 := by decide
theorem cert_e2393374503894 : check e2393374503894 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2393374503898 : Closed e2393374503898 ∧ code e2393374503898 = 11189467526106 := by decide
theorem cert_e2393374503898 : check e2393374503898 [[],[.left],[],[.under]] .three = true := by decide
def e2393374503966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2393374503966 : Closed e2393374503966 ∧ code e2393374503966 = 11189467526174 := by decide
theorem cert_e2393374503966 : check e2393374503966 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393374504162 : Closed e2393374504162 ∧ code e2393374504162 = 11189467526370 := by decide
theorem cert_e2393374504162 : check e2393374504162 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393374504174 : Closed e2393374504174 ∧ code e2393374504174 = 11189467526382 := by decide
theorem cert_e2393374504174 : check e2393374504174 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393374504182 : Closed e2393374504182 ∧ code e2393374504182 = 11189467526390 := by decide
theorem cert_e2393374504182 : check e2393374504182 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393374504462 : Closed e2393374504462 ∧ code e2393374504462 = 11189467526670 := by decide
theorem cert_e2393374504462 : check e2393374504462 [[],[.left],[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393374469614
#print axioms Blc.Floor43.cert_e2393374470062
