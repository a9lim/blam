import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422408547182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422408547182 : Closed e2422408547182 ∧ code e2422408547182 = 11218501569390 := by decide
theorem cert_e2422408547182 : check e2422408547182 [[],[]] .smaller = true := by decide
def e2422408547190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422408547190 : Closed e2422408547190 ∧ code e2422408547190 = 11218501569398 := by decide
theorem cert_e2422408547190 : check e2422408547190 [[],[]] .smaller = true := by decide
def e2422408547246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422408547246 : Closed e2422408547246 ∧ code e2422408547246 = 11218501569454 := by decide
theorem cert_e2422408547246 : check e2422408547246 [[],[]] .smaller = true := by decide
def e2422408547258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422408547258 : Closed e2422408547258 ∧ code e2422408547258 = 11218501569466 := by decide
theorem cert_e2422408547258 : check e2422408547258 [[],[]] .smaller = true := by decide
def e2422408547286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422408547286 : Closed e2422408547286 ∧ code e2422408547286 = 11218501569494 := by decide
theorem cert_e2422408547286 : check e2422408547286 [[],[]] .smaller = true := by decide
def e2422408547290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422408547290 : Closed e2422408547290 ∧ code e2422408547290 = 11218501569498 := by decide
theorem cert_e2422408547290 : check e2422408547290 [[],[]] .smaller = true := by decide
def e2422408547566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422408547566 : Closed e2422408547566 ∧ code e2422408547566 = 11218501569774 := by decide
theorem cert_e2422408547566 : check e2422408547566 [[],[]] .smaller = true := by decide
def e2422408547574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422408547574 : Closed e2422408547574 ∧ code e2422408547574 = 11218501569782 := by decide
theorem cert_e2422408547574 : check e2422408547574 [[],[]] .smaller = true := by decide
def e2422408547950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408547950 : Closed e2422408547950 ∧ code e2422408547950 = 11218501570158 := by decide
theorem cert_e2422408547950 : check e2422408547950 [[],[]] .smaller = true := by decide
def e2422408547962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408547962 : Closed e2422408547962 ∧ code e2422408547962 = 11218501570170 := by decide
theorem cert_e2422408547962 : check e2422408547962 [[],[]] .smaller = true := by decide
def e2422408548150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422408548150 : Closed e2422408548150 ∧ code e2422408548150 = 11218501570358 := by decide
theorem cert_e2422408548150 : check e2422408548150 [[],[]] .smaller = true := by decide
def e2422408548154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422408548154 : Closed e2422408548154 ∧ code e2422408548154 = 11218501570362 := by decide
theorem cert_e2422408548154 : check e2422408548154 [[],[]] .smaller = true := by decide
def e2422408556078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422408556078 : Closed e2422408556078 ∧ code e2422408556078 = 11218501578286 := by decide
theorem cert_e2422408556078 : check e2422408556078 [[],[]] .chain = true := by decide
def e2422408556258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422408556258 : Closed e2422408556258 ∧ code e2422408556258 = 11218501578466 := by decide
theorem cert_e2422408556258 : check e2422408556258 [[],[]] .chain = true := by decide
def e2422408556270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2422408556270 : Closed e2422408556270 ∧ code e2422408556270 = 11218501578478 := by decide
theorem cert_e2422408556270 : check e2422408556270 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408556310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422408556310 : Closed e2422408556310 ∧ code e2422408556310 = 11218501578518 := by decide
theorem cert_e2422408556310 : check e2422408556310 [[],[]] .chain = true := by decide
def e2422408556386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422408556386 : Closed e2422408556386 ∧ code e2422408556386 = 11218501578594 := by decide
theorem cert_e2422408556386 : check e2422408556386 [[],[]] .chain = true := by decide
def e2422408556398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2422408556398 : Closed e2422408556398 ∧ code e2422408556398 = 11218501578606 := by decide
theorem cert_e2422408556398 : check e2422408556398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408556406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2422408556406 : Closed e2422408556406 ∧ code e2422408556406 = 11218501578614 := by decide
theorem cert_e2422408556406 : check e2422408556406 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408558654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e2422408558654 : Closed e2422408558654 ∧ code e2422408558654 = 11218501580862 := by decide
theorem cert_e2422408558654 : check e2422408558654 [[],[]] .chain = true := by decide
def e2422408559074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422408559074 : Closed e2422408559074 ∧ code e2422408559074 = 11218501581282 := by decide
theorem cert_e2422408559074 : check e2422408559074 [[],[]] .chain = true := by decide
def e2422408559086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2422408559086 : Closed e2422408559086 ∧ code e2422408559086 = 11218501581294 := by decide
theorem cert_e2422408559086 : check e2422408559086 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408559646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e2422408559646 : Closed e2422408559646 ∧ code e2422408559646 = 11218501581854 := by decide
theorem cert_e2422408559646 : check e2422408559646 [[],[]] .chain = true := by decide
def e2422408559842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422408559842 : Closed e2422408559842 ∧ code e2422408559842 = 11218501582050 := by decide
theorem cert_e2422408559842 : check e2422408559842 [[],[]] .chain = true := by decide
def e2422408559854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408559854 : Closed e2422408559854 ∧ code e2422408559854 = 11218501582062 := by decide
theorem cert_e2422408559854 : check e2422408559854 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408559862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408559862 : Closed e2422408559862 ∧ code e2422408559862 = 11218501582070 := by decide
theorem cert_e2422408559862 : check e2422408559862 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408577470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422408577470 : Closed e2422408577470 ∧ code e2422408577470 = 11218501599678 := by decide
theorem cert_e2422408577470 : check e2422408577470 [[],[]] .chain = true := by decide
def e2422408577530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422408577530 : Closed e2422408577530 ∧ code e2422408577530 = 11218501599738 := by decide
theorem cert_e2422408577530 : check e2422408577530 [[],[]] .chain = true := by decide
def e2422408578622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422408578622 : Closed e2422408578622 ∧ code e2422408578622 = 11218501600830 := by decide
theorem cert_e2422408578622 : check e2422408578622 [[],[]] .chain = true := by decide
def e2422408579014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422408579014 : Closed e2422408579014 ∧ code e2422408579014 = 11218501601222 := by decide
theorem cert_e2422408579014 : check e2422408579014 [[],[]] .chain = true := by decide
def e2422408579038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2422408579038 : Closed e2422408579038 ∧ code e2422408579038 = 11218501601246 := by decide
theorem cert_e2422408579038 : check e2422408579038 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408582702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422408582702 : Closed e2422408582702 ∧ code e2422408582702 = 11218501604910 := by decide
theorem cert_e2422408582702 : check e2422408582702 [[],[]] .chain = true := by decide
def e2422408582882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422408582882 : Closed e2422408582882 ∧ code e2422408582882 = 11218501605090 := by decide
theorem cert_e2422408582882 : check e2422408582882 [[],[]] .chain = true := by decide
def e2422408582894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2422408582894 : Closed e2422408582894 ∧ code e2422408582894 = 11218501605102 := by decide
theorem cert_e2422408582894 : check e2422408582894 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408583022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2422408583022 : Closed e2422408583022 ∧ code e2422408583022 = 11218501605230 := by decide
theorem cert_e2422408583022 : check e2422408583022 [[],[]] .chain = true := by decide
def e2422408583030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2422408583030 : Closed e2422408583030 ∧ code e2422408583030 = 11218501605238 := by decide
theorem cert_e2422408583030 : check e2422408583030 [[],[]] .chain = true := by decide
def e2422408583050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422408583050 : Closed e2422408583050 ∧ code e2422408583050 = 11218501605258 := by decide
theorem cert_e2422408583050 : check e2422408583050 [[],[]] .chain = true := by decide
def e2422408583074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422408583074 : Closed e2422408583074 ∧ code e2422408583074 = 11218501605282 := by decide
theorem cert_e2422408583074 : check e2422408583074 [[],[]] .chain = true := by decide
def e2422408583086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2422408583086 : Closed e2422408583086 ∧ code e2422408583086 = 11218501605294 := by decide
theorem cert_e2422408583086 : check e2422408583086 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408583094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2422408583094 : Closed e2422408583094 ∧ code e2422408583094 = 11218501605302 := by decide
theorem cert_e2422408583094 : check e2422408583094 [[],[]] .chain = true := by decide
def e2422408583098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2422408583098 : Closed e2422408583098 ∧ code e2422408583098 = 11218501605306 := by decide
theorem cert_e2422408583098 : check e2422408583098 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408583230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2422408583230 : Closed e2422408583230 ∧ code e2422408583230 = 11218501605438 := by decide
theorem cert_e2422408583230 : check e2422408583230 [[],[]] .chain = true := by decide
def e2422408583650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422408583650 : Closed e2422408583650 ∧ code e2422408583650 = 11218501605858 := by decide
theorem cert_e2422408583650 : check e2422408583650 [[],[]] .chain = true := by decide
def e2422408583662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2422408583662 : Closed e2422408583662 ∧ code e2422408583662 = 11218501605870 := by decide
theorem cert_e2422408583662 : check e2422408583662 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408584430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408584430 : Closed e2422408584430 ∧ code e2422408584430 = 11218501606638 := by decide
theorem cert_e2422408584430 : check e2422408584430 [[],[]] .chain = true := by decide
def e2422408584438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408584438 : Closed e2422408584438 ∧ code e2422408584438 = 11218501606646 := by decide
theorem cert_e2422408584438 : check e2422408584438 [[],[]] .chain = true := by decide
def e2422408584706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422408584706 : Closed e2422408584706 ∧ code e2422408584706 = 11218501606914 := by decide
theorem cert_e2422408584706 : check e2422408584706 [[],[]] .chain = true := by decide
def e2422408584718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2422408584718 : Closed e2422408584718 ∧ code e2422408584718 = 11218501606926 := by decide
theorem cert_e2422408584718 : check e2422408584718 [[],[]] .chain = true := by decide
def e2422408584730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408584730 : Closed e2422408584730 ∧ code e2422408584730 = 11218501606938 := by decide
theorem cert_e2422408584730 : check e2422408584730 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408584802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422408584802 : Closed e2422408584802 ∧ code e2422408584802 = 11218501607010 := by decide
theorem cert_e2422408584802 : check e2422408584802 [[],[]] .chain = true := by decide
def e2422408584814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408584814 : Closed e2422408584814 ∧ code e2422408584814 = 11218501607022 := by decide
theorem cert_e2422408584814 : check e2422408584814 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408584822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2422408584822 : Closed e2422408584822 ∧ code e2422408584822 = 11218501607030 := by decide
theorem cert_e2422408584822 : check e2422408584822 [[],[]] .chain = true := by decide
def e2422408584826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408584826 : Closed e2422408584826 ∧ code e2422408584826 = 11218501607034 := by decide
theorem cert_e2422408584826 : check e2422408584826 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408593630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422408593630 : Closed e2422408593630 ∧ code e2422408593630 = 11218501615838 := by decide
theorem cert_e2422408593630 : check e2422408593630 [[],[]] .chain = true := by decide
def e2422408593658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422408593658 : Closed e2422408593658 ∧ code e2422408593658 = 11218501615866 := by decide
theorem cert_e2422408593658 : check e2422408593658 [[],[]] .chain = true := by decide
def e2422408594206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422408594206 : Closed e2422408594206 ∧ code e2422408594206 = 11218501616414 := by decide
theorem cert_e2422408594206 : check e2422408594206 [[],[]] .chain = true := by decide
def e2422408594374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422408594374 : Closed e2422408594374 ∧ code e2422408594374 = 11218501616582 := by decide
theorem cert_e2422408594374 : check e2422408594374 [[],[]] .chain = true := by decide
def e2422408594398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422408594398 : Closed e2422408594398 ∧ code e2422408594398 = 11218501616606 := by decide
theorem cert_e2422408594398 : check e2422408594398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408594414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422408594414 : Closed e2422408594414 ∧ code e2422408594414 = 11218501616622 := by decide
theorem cert_e2422408594414 : check e2422408594414 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.under]] .identityHead = true := by decide
def e2422408596246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422408596246 : Closed e2422408596246 ∧ code e2422408596246 = 11218501618454 := by decide
theorem cert_e2422408596246 : check e2422408596246 [[],[]] .chain = true := by decide
def e2422408596322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422408596322 : Closed e2422408596322 ∧ code e2422408596322 = 11218501618530 := by decide
theorem cert_e2422408596322 : check e2422408596322 [[],[]] .chain = true := by decide
def e2422408596334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422408596334 : Closed e2422408596334 ∧ code e2422408596334 = 11218501618542 := by decide
theorem cert_e2422408596334 : check e2422408596334 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.left]] .identityHead = true := by decide
def e2422408596342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422408596342 : Closed e2422408596342 ∧ code e2422408596342 = 11218501618550 := by decide
theorem cert_e2422408596342 : check e2422408596342 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2422408596362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422408596362 : Closed e2422408596362 ∧ code e2422408596362 = 11218501618570 := by decide
theorem cert_e2422408596362 : check e2422408596362 [[],[]] .chain = true := by decide
def e2422408596386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422408596386 : Closed e2422408596386 ∧ code e2422408596386 = 11218501618594 := by decide
theorem cert_e2422408596386 : check e2422408596386 [[],[]] .chain = true := by decide
def e2422408596398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422408596398 : Closed e2422408596398 ∧ code e2422408596398 = 11218501618606 := by decide
theorem cert_e2422408596398 : check e2422408596398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408596406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2422408596406 : Closed e2422408596406 ∧ code e2422408596406 = 11218501618614 := by decide
theorem cert_e2422408596406 : check e2422408596406 [[],[]] .chain = true := by decide
def e2422408596410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422408596410 : Closed e2422408596410 ∧ code e2422408596410 = 11218501618618 := by decide
theorem cert_e2422408596410 : check e2422408596410 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408596438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422408596438 : Closed e2422408596438 ∧ code e2422408596438 = 11218501618646 := by decide
theorem cert_e2422408596438 : check e2422408596438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2422408596442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422408596442 : Closed e2422408596442 ∧ code e2422408596442 = 11218501618650 := by decide
theorem cert_e2422408596442 : check e2422408596442 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2422408596510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2422408596510 : Closed e2422408596510 ∧ code e2422408596510 = 11218501618718 := by decide
theorem cert_e2422408596510 : check e2422408596510 [[],[]] .chain = true := by decide
def e2422408596706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422408596706 : Closed e2422408596706 ∧ code e2422408596706 = 11218501618914 := by decide
theorem cert_e2422408596706 : check e2422408596706 [[],[]] .chain = true := by decide
def e2422408596718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408596718 : Closed e2422408596718 ∧ code e2422408596718 = 11218501618926 := by decide
theorem cert_e2422408596718 : check e2422408596718 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422408596726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408596726 : Closed e2422408596726 ∧ code e2422408596726 = 11218501618934 := by decide
theorem cert_e2422408596726 : check e2422408596726 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left,.left]] .identityHead = true := by decide
def e2422408596994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422408596994 : Closed e2422408596994 ∧ code e2422408596994 = 11218501619202 := by decide
theorem cert_e2422408596994 : check e2422408596994 [[],[]] .chain = true := by decide
def e2422408597006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2422408597006 : Closed e2422408597006 ∧ code e2422408597006 = 11218501619214 := by decide
theorem cert_e2422408597006 : check e2422408597006 [[],[]] .chain = true := by decide
def e2422408597018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408597018 : Closed e2422408597018 ∧ code e2422408597018 = 11218501619226 := by decide
theorem cert_e2422408597018 : check e2422408597018 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408597090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422408597090 : Closed e2422408597090 ∧ code e2422408597090 = 11218501619298 := by decide
theorem cert_e2422408597090 : check e2422408597090 [[],[]] .chain = true := by decide
def e2422408597102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408597102 : Closed e2422408597102 ∧ code e2422408597102 = 11218501619310 := by decide
theorem cert_e2422408597102 : check e2422408597102 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408597110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2422408597110 : Closed e2422408597110 ∧ code e2422408597110 = 11218501619318 := by decide
theorem cert_e2422408597110 : check e2422408597110 [[],[]] .chain = true := by decide
def e2422408597114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408597114 : Closed e2422408597114 ∧ code e2422408597114 = 11218501619322 := by decide
theorem cert_e2422408597114 : check e2422408597114 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408597302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408597302 : Closed e2422408597302 ∧ code e2422408597302 = 11218501619510 := by decide
theorem cert_e2422408597302 : check e2422408597302 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422408597306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408597306 : Closed e2422408597306 ∧ code e2422408597306 = 11218501619514 := by decide
theorem cert_e2422408597306 : check e2422408597306 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422408610222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))) (.var 2))))))
theorem wire_e2422408610222 : Closed e2422408610222 ∧ code e2422408610222 = 11218501632430 := by decide
theorem cert_e2422408610222 : check e2422408610222 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408610414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408610414 : Closed e2422408610414 ∧ code e2422408610414 = 11218501632622 := by decide
theorem cert_e2422408610414 : check e2422408610414 [[],[]] .chain = true := by decide
def e2422408610426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408610426 : Closed e2422408610426 ∧ code e2422408610426 = 11218501632634 := by decide
theorem cert_e2422408610426 : check e2422408610426 [[],[]] .chain = true := by decide
def e2422408610798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 4)))))) (.var 2))))))
theorem wire_e2422408610798 : Closed e2422408610798 ∧ code e2422408610798 = 11218501633006 := by decide
theorem cert_e2422408610798 : check e2422408610798 [[],[]] .chain = true := by decide
def e2422408610806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 5)))))) (.var 1))))))
theorem wire_e2422408610806 : Closed e2422408610806 ∧ code e2422408610806 = 11218501633014 := by decide
theorem cert_e2422408610806 : check e2422408610806 [[],[]] .chain = true := by decide
def e2422408611566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 2)))))) (.var 2))))))
theorem wire_e2422408611566 : Closed e2422408611566 ∧ code e2422408611566 = 11218501633774 := by decide
theorem cert_e2422408611566 : check e2422408611566 [[],[]] .chain = true := by decide
def e2422408611578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 4)))))) (.var 0))))))
theorem wire_e2422408611578 : Closed e2422408611578 ∧ code e2422408611578 = 11218501633786 := by decide
theorem cert_e2422408611578 : check e2422408611578 [[],[]] .chain = true := by decide
def e2422408611694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.var 1)))))) (.var 2))))))
theorem wire_e2422408611694 : Closed e2422408611694 ∧ code e2422408611694 = 11218501633902 := by decide
theorem cert_e2422408611694 : check e2422408611694 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408611758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 0)))))) (.var 2))))))
theorem wire_e2422408611758 : Closed e2422408611758 ∧ code e2422408611758 = 11218501633966 := by decide
theorem cert_e2422408611758 : check e2422408611758 [[],[]] .chain = true := by decide
def e2422408611818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 0)))))) (.var 0))))))
theorem wire_e2422408611818 : Closed e2422408611818 ∧ code e2422408611818 = 11218501634026 := by decide
theorem cert_e2422408611818 : check e2422408611818 [[],[]] .chain = true := by decide
def e2422408612334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422408612334 : Closed e2422408612334 ∧ code e2422408612334 = 11218501634542 := by decide
theorem cert_e2422408612334 : check e2422408612334 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408613102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408613102 : Closed e2422408613102 ∧ code e2422408613102 = 11218501635310 := by decide
theorem cert_e2422408613102 : check e2422408613102 [[],[]] .chain = true := by decide
def e2422408613110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408613110 : Closed e2422408613110 ∧ code e2422408613110 = 11218501635318 := by decide
theorem cert_e2422408613110 : check e2422408613110 [[],[]] .chain = true := by decide
def e2422408613486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408613486 : Closed e2422408613486 ∧ code e2422408613486 = 11218501635694 := by decide
theorem cert_e2422408613486 : check e2422408613486 [[],[]] .chain = true := by decide
def e2422408613498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408613498 : Closed e2422408613498 ∧ code e2422408613498 = 11218501635706 := by decide
theorem cert_e2422408613498 : check e2422408613498 [[],[]] .chain = true := by decide
def e2422408613662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 3))))) (.lam (.var 3)))))))
theorem wire_e2422408613662 : Closed e2422408613662 ∧ code e2422408613662 = 11218501635870 := by decide
theorem cert_e2422408613662 : check e2422408613662 [[],[]] .chain = true := by decide
def e2422408613774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.lam (.var 2)))))))
theorem wire_e2422408613774 : Closed e2422408613774 ∧ code e2422408613774 = 11218501635982 := by decide
theorem cert_e2422408613774 : check e2422408613774 [[],[]] .chain = true := by decide
def e2422408613786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408613786 : Closed e2422408613786 ∧ code e2422408613786 = 11218501635994 := by decide
theorem cert_e2422408613786 : check e2422408613786 [[],[]] .chain = true := by decide
def e2422408615598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))) (.var 2))))))
theorem wire_e2422408615598 : Closed e2422408615598 ∧ code e2422408615598 = 11218501637806 := by decide
theorem cert_e2422408615598 : check e2422408615598 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408616174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 2)))))) (.var 2))))))
theorem wire_e2422408616174 : Closed e2422408616174 ∧ code e2422408616174 = 11218501638382 := by decide
theorem cert_e2422408616174 : check e2422408616174 [[],[]] .chain = true := by decide
def e2422408616186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 4)))))) (.var 0))))))
theorem wire_e2422408616186 : Closed e2422408616186 ∧ code e2422408616186 = 11218501638394 := by decide
theorem cert_e2422408616186 : check e2422408616186 [[],[]] .chain = true := by decide
def e2422408616366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e2422408616366 : Closed e2422408616366 ∧ code e2422408616366 = 11218501638574 := by decide
theorem cert_e2422408616366 : check e2422408616366 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408616558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408616558 : Closed e2422408616558 ∧ code e2422408616558 = 11218501638766 := by decide
theorem cert_e2422408616558 : check e2422408616558 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408616570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408616570 : Closed e2422408616570 ∧ code e2422408616570 = 11218501638778 := by decide
theorem cert_e2422408616570 : check e2422408616570 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408616734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.lam (.var 3)))))))
theorem wire_e2422408616734 : Closed e2422408616734 ∧ code e2422408616734 = 11218501638942 := by decide
theorem cert_e2422408616734 : check e2422408616734 [[],[]] .chain = true := by decide
def e2422408616902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.lam (.var 1)))))))
theorem wire_e2422408616902 : Closed e2422408616902 ∧ code e2422408616902 = 11218501639110 := by decide
theorem cert_e2422408616902 : check e2422408616902 [[],[]] .chain = true := by decide
def e2422408617070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 1)))))) (.var 2))))))
theorem wire_e2422408617070 : Closed e2422408617070 ∧ code e2422408617070 = 11218501639278 := by decide
theorem cert_e2422408617070 : check e2422408617070 [[],[]] .chain = true := by decide
def e2422408617246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.lam (.var 3)))))))
theorem wire_e2422408617246 : Closed e2422408617246 ∧ code e2422408617246 = 11218501639454 := by decide
theorem cert_e2422408617246 : check e2422408617246 [[],[]] .chain = true := by decide
def e2422408617442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))) (.lam (.var 0)))))))
theorem wire_e2422408617442 : Closed e2422408617442 ∧ code e2422408617442 = 11218501639650 := by decide
theorem cert_e2422408617442 : check e2422408617442 [[],[]] .chain = true := by decide
def e2422408617454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))) (.var 2))))))
theorem wire_e2422408617454 : Closed e2422408617454 ∧ code e2422408617454 = 11218501639662 := by decide
theorem cert_e2422408617454 : check e2422408617454 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408617518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422408617518 : Closed e2422408617518 ∧ code e2422408617518 = 11218501639726 := by decide
theorem cert_e2422408617518 : check e2422408617518 [[],[]] .chain = true := by decide
def e2422408617710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 2))))) (.var 2))))))
theorem wire_e2422408617710 : Closed e2422408617710 ∧ code e2422408617710 = 11218501639918 := by decide
theorem cert_e2422408617710 : check e2422408617710 [[],[]] .chain = true := by decide
def e2422408617718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 3))))) (.var 1))))))
theorem wire_e2422408617718 : Closed e2422408617718 ∧ code e2422408617718 = 11218501639926 := by decide
theorem cert_e2422408617718 : check e2422408617718 [[],[]] .chain = true := by decide
def e2422408617750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422408617750 : Closed e2422408617750 ∧ code e2422408617750 = 11218501639958 := by decide
theorem cert_e2422408617750 : check e2422408617750 [[],[]] .chain = true := by decide
def e2422408617754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 1)))))) (.var 0))))))
theorem wire_e2422408617754 : Closed e2422408617754 ∧ code e2422408617754 = 11218501639962 := by decide
theorem cert_e2422408617754 : check e2422408617754 [[],[]] .chain = true := by decide
def e2422408617798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.lam (.var 1)))))))
theorem wire_e2422408617798 : Closed e2422408617798 ∧ code e2422408617798 = 11218501640006 := by decide
theorem cert_e2422408617798 : check e2422408617798 [[],[]] .chain = true := by decide
def e2422408617826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e2422408617826 : Closed e2422408617826 ∧ code e2422408617826 = 11218501640034 := by decide
theorem cert_e2422408617826 : check e2422408617826 [[],[]] .chain = true := by decide
def e2422408617838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))) (.var 2))))))
theorem wire_e2422408617838 : Closed e2422408617838 ∧ code e2422408617838 = 11218501640046 := by decide
theorem cert_e2422408617838 : check e2422408617838 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408617846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 2))))) (.var 1))))))
theorem wire_e2422408617846 : Closed e2422408617846 ∧ code e2422408617846 = 11218501640054 := by decide
theorem cert_e2422408617846 : check e2422408617846 [[],[]] .chain = true := by decide
def e2422408617850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 3))))) (.var 0))))))
theorem wire_e2422408617850 : Closed e2422408617850 ∧ code e2422408617850 = 11218501640058 := by decide
theorem cert_e2422408617850 : check e2422408617850 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408618462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422408618462 : Closed e2422408618462 ∧ code e2422408618462 = 11218501640670 := by decide
theorem cert_e2422408618462 : check e2422408618462 [[],[]] .chain = true := by decide
def e2422408618486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422408618486 : Closed e2422408618486 ∧ code e2422408618486 = 11218501640694 := by decide
theorem cert_e2422408618486 : check e2422408618486 [[],[]] .chain = true := by decide
def e2422408619438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422408619438 : Closed e2422408619438 ∧ code e2422408619438 = 11218501641646 := by decide
theorem cert_e2422408619438 : check e2422408619438 [[],[]] .chain = true := by decide
def e2422408619450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422408619450 : Closed e2422408619450 ∧ code e2422408619450 = 11218501641658 := by decide
theorem cert_e2422408619450 : check e2422408619450 [[],[]] .chain = true := by decide
def e2422408619498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422408619498 : Closed e2422408619498 ∧ code e2422408619498 = 11218501641706 := by decide
theorem cert_e2422408619498 : check e2422408619498 [[],[]] .chain = true := by decide
def e2422408619630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408619630 : Closed e2422408619630 ∧ code e2422408619630 = 11218501641838 := by decide
theorem cert_e2422408619630 : check e2422408619630 [[],[]] .chain = true := by decide
def e2422408619642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408619642 : Closed e2422408619642 ∧ code e2422408619642 = 11218501641850 := by decide
theorem cert_e2422408619642 : check e2422408619642 [[],[]] .chain = true := by decide
def e2422408619806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422408619806 : Closed e2422408619806 ∧ code e2422408619806 = 11218501642014 := by decide
theorem cert_e2422408619806 : check e2422408619806 [[],[]] .chain = true := by decide
def e2422408619918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422408619918 : Closed e2422408619918 ∧ code e2422408619918 = 11218501642126 := by decide
theorem cert_e2422408619918 : check e2422408619918 [[],[]] .chain = true := by decide
def e2422408619930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422408619930 : Closed e2422408619930 ∧ code e2422408619930 = 11218501642138 := by decide
theorem cert_e2422408619930 : check e2422408619930 [[],[]] .chain = true := by decide
def e2422408622302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2422408622302 : Closed e2422408622302 ∧ code e2422408622302 = 11218501644510 := by decide
theorem cert_e2422408622302 : check e2422408622302 [[],[]] .chain = true := by decide
def e2422408622330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2422408622330 : Closed e2422408622330 ∧ code e2422408622330 = 11218501644538 := by decide
theorem cert_e2422408622330 : check e2422408622330 [[],[]] .chain = true := by decide
def e2422408622878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422408622878 : Closed e2422408622878 ∧ code e2422408622878 = 11218501645086 := by decide
theorem cert_e2422408622878 : check e2422408622878 [[],[]] .chain = true := by decide
def e2422408623046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422408623046 : Closed e2422408623046 ∧ code e2422408623046 = 11218501645254 := by decide
theorem cert_e2422408623046 : check e2422408623046 [[],[]] .chain = true := by decide
def e2422408624190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.lam (.lam (.var 4))))))))
theorem wire_e2422408624190 : Closed e2422408624190 ∧ code e2422408624190 = 11218501646398 := by decide
theorem cert_e2422408624190 : check e2422408624190 [[],[]] .chain = true := by decide
def e2422408624610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422408624610 : Closed e2422408624610 ∧ code e2422408624610 = 11218501646818 := by decide
theorem cert_e2422408624610 : check e2422408624610 [[],[]] .chain = true := by decide
def e2422408624622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422408624622 : Closed e2422408624622 ∧ code e2422408624622 = 11218501646830 := by decide
theorem cert_e2422408624622 : check e2422408624622 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408625182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.lam (.var 3))))))))
theorem wire_e2422408625182 : Closed e2422408625182 ∧ code e2422408625182 = 11218501647390 := by decide
theorem cert_e2422408625182 : check e2422408625182 [[],[]] .chain = true := by decide
def e2422408625206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422408625206 : Closed e2422408625206 ∧ code e2422408625206 = 11218501647414 := by decide
theorem cert_e2422408625206 : check e2422408625206 [[],[]] .chain = true := by decide
def e2422408625210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422408625210 : Closed e2422408625210 ∧ code e2422408625210 = 11218501647418 := by decide
theorem cert_e2422408625210 : check e2422408625210 [[],[]] .chain = true := by decide
def e2422408625350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422408625350 : Closed e2422408625350 ∧ code e2422408625350 = 11218501647558 := by decide
theorem cert_e2422408625350 : check e2422408625350 [[],[]] .chain = true := by decide
def e2422408625378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422408625378 : Closed e2422408625378 ∧ code e2422408625378 = 11218501647586 := by decide
theorem cert_e2422408625378 : check e2422408625378 [[],[]] .chain = true := by decide
def e2422408625390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408625390 : Closed e2422408625390 ∧ code e2422408625390 = 11218501647598 := by decide
theorem cert_e2422408625390 : check e2422408625390 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408625398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408625398 : Closed e2422408625398 ∧ code e2422408625398 = 11218501647606 := by decide
theorem cert_e2422408625398 : check e2422408625398 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408632494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))) (.var 2))))))
theorem wire_e2422408632494 : Closed e2422408632494 ∧ code e2422408632494 = 11218501654702 := by decide
theorem cert_e2422408632494 : check e2422408632494 [[],[]] .chain = true := by decide
def e2422408632506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))) (.var 0))))))
theorem wire_e2422408632506 : Closed e2422408632506 ∧ code e2422408632506 = 11218501654714 := by decide
theorem cert_e2422408632506 : check e2422408632506 [[],[]] .chain = true := by decide
def e2422408632878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422408632878 : Closed e2422408632878 ∧ code e2422408632878 = 11218501655086 := by decide
theorem cert_e2422408632878 : check e2422408632878 [[],[]] .chain = true := by decide
def e2422408633058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422408633058 : Closed e2422408633058 ∧ code e2422408633058 = 11218501655266 := by decide
theorem cert_e2422408633058 : check e2422408633058 [[],[]] .chain = true := by decide
def e2422408633070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e2422408633070 : Closed e2422408633070 ∧ code e2422408633070 = 11218501655278 := by decide
theorem cert_e2422408633070 : check e2422408633070 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408633198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1)))) (.var 2))))))
theorem wire_e2422408633198 : Closed e2422408633198 ∧ code e2422408633198 = 11218501655406 := by decide
theorem cert_e2422408633198 : check e2422408633198 [[],[]] .chain = true := by decide
def e2422408633206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e2422408633206 : Closed e2422408633206 ∧ code e2422408633206 = 11218501655414 := by decide
theorem cert_e2422408633206 : check e2422408633206 [[],[]] .chain = true := by decide
def e2422408633226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408633226 : Closed e2422408633226 ∧ code e2422408633226 = 11218501655434 := by decide
theorem cert_e2422408633226 : check e2422408633226 [[],[]] .chain = true := by decide
def e2422408633250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408633250 : Closed e2422408633250 ∧ code e2422408633250 = 11218501655458 := by decide
theorem cert_e2422408633250 : check e2422408633250 [[],[]] .chain = true := by decide
def e2422408633262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e2422408633262 : Closed e2422408633262 ∧ code e2422408633262 = 11218501655470 := by decide
theorem cert_e2422408633262 : check e2422408633262 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408633270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e2422408633270 : Closed e2422408633270 ∧ code e2422408633270 = 11218501655478 := by decide
theorem cert_e2422408633270 : check e2422408633270 [[],[]] .chain = true := by decide
def e2422408633274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))) (.var 0))))))
theorem wire_e2422408633274 : Closed e2422408633274 ∧ code e2422408633274 = 11218501655482 := by decide
theorem cert_e2422408633274 : check e2422408633274 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408633710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e2422408633710 : Closed e2422408633710 ∧ code e2422408633710 = 11218501655918 := by decide
theorem cert_e2422408633710 : check e2422408633710 [[],[]] .chain = true := by decide
end Blc.Floor43
