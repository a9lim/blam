import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406854510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e2422406854510 : Closed e2422406854510 ∧ code e2422406854510 = 11218499876718 := by decide
theorem cert_e2422406854510 : check e2422406854510 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406854518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e2422406854518 : Closed e2422406854518 ∧ code e2422406854518 = 11218499876726 := by decide
theorem cert_e2422406854518 : check e2422406854518 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406854830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422406854830 : Closed e2422406854830 ∧ code e2422406854830 = 11218499877038 := by decide
theorem cert_e2422406854830 : check e2422406854830 [[],[]] .chain = true := by decide
def e2422406854842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422406854842 : Closed e2422406854842 ∧ code e2422406854842 = 11218499877050 := by decide
theorem cert_e2422406854842 : check e2422406854842 [[],[]] .chain = true := by decide
def e2422406855214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406855214 : Closed e2422406855214 ∧ code e2422406855214 = 11218499877422 := by decide
theorem cert_e2422406855214 : check e2422406855214 [[],[]] .chain = true := by decide
def e2422406855394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406855394 : Closed e2422406855394 ∧ code e2422406855394 = 11218499877602 := by decide
theorem cert_e2422406855394 : check e2422406855394 [[],[]] .chain = true := by decide
def e2422406855406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)) (.var 2))))))
theorem wire_e2422406855406 : Closed e2422406855406 ∧ code e2422406855406 = 11218499877614 := by decide
theorem cert_e2422406855406 : check e2422406855406 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406855534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422406855534 : Closed e2422406855534 ∧ code e2422406855534 = 11218499877742 := by decide
theorem cert_e2422406855534 : check e2422406855534 [[],[]] .chain = true := by decide
def e2422406855542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422406855542 : Closed e2422406855542 ∧ code e2422406855542 = 11218499877750 := by decide
theorem cert_e2422406855542 : check e2422406855542 [[],[]] .chain = true := by decide
def e2422406855562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406855562 : Closed e2422406855562 ∧ code e2422406855562 = 11218499877770 := by decide
theorem cert_e2422406855562 : check e2422406855562 [[],[]] .chain = true := by decide
def e2422406855586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406855586 : Closed e2422406855586 ∧ code e2422406855586 = 11218499877794 := by decide
theorem cert_e2422406855586 : check e2422406855586 [[],[]] .chain = true := by decide
def e2422406855598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422406855598 : Closed e2422406855598 ∧ code e2422406855598 = 11218499877806 := by decide
theorem cert_e2422406855598 : check e2422406855598 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406855606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e2422406855606 : Closed e2422406855606 ∧ code e2422406855606 = 11218499877814 := by decide
theorem cert_e2422406855606 : check e2422406855606 [[],[]] .chain = true := by decide
def e2422406855610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422406855610 : Closed e2422406855610 ∧ code e2422406855610 = 11218499877818 := by decide
theorem cert_e2422406855610 : check e2422406855610 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406855766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422406855766 : Closed e2422406855766 ∧ code e2422406855766 = 11218499877974 := by decide
theorem cert_e2422406855766 : check e2422406855766 [[],[]] .chain = true := by decide
def e2422406855770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422406855770 : Closed e2422406855770 ∧ code e2422406855770 = 11218499877978 := by decide
theorem cert_e2422406855770 : check e2422406855770 [[],[]] .chain = true := by decide
def e2422406855958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406855958 : Closed e2422406855958 ∧ code e2422406855958 = 11218499878166 := by decide
theorem cert_e2422406855958 : check e2422406855958 [[],[]] .chain = true := by decide
def e2422406856034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406856034 : Closed e2422406856034 ∧ code e2422406856034 = 11218499878242 := by decide
theorem cert_e2422406856034 : check e2422406856034 [[],[]] .chain = true := by decide
def e2422406856046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422406856046 : Closed e2422406856046 ∧ code e2422406856046 = 11218499878254 := by decide
theorem cert_e2422406856046 : check e2422406856046 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406856054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422406856054 : Closed e2422406856054 ∧ code e2422406856054 = 11218499878262 := by decide
theorem cert_e2422406856054 : check e2422406856054 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406856074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406856074 : Closed e2422406856074 ∧ code e2422406856074 = 11218499878282 := by decide
theorem cert_e2422406856074 : check e2422406856074 [[],[]] .chain = true := by decide
def e2422406856098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406856098 : Closed e2422406856098 ∧ code e2422406856098 = 11218499878306 := by decide
theorem cert_e2422406856098 : check e2422406856098 [[],[]] .chain = true := by decide
def e2422406856110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2422406856110 : Closed e2422406856110 ∧ code e2422406856110 = 11218499878318 := by decide
theorem cert_e2422406856110 : check e2422406856110 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406856118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e2422406856118 : Closed e2422406856118 ∧ code e2422406856118 = 11218499878326 := by decide
theorem cert_e2422406856118 : check e2422406856118 [[],[]] .chain = true := by decide
def e2422406856122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2422406856122 : Closed e2422406856122 ∧ code e2422406856122 = 11218499878330 := by decide
theorem cert_e2422406856122 : check e2422406856122 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406856150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422406856150 : Closed e2422406856150 ∧ code e2422406856150 = 11218499878358 := by decide
theorem cert_e2422406856150 : check e2422406856150 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406856154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422406856154 : Closed e2422406856154 ∧ code e2422406856154 = 11218499878362 := by decide
theorem cert_e2422406856154 : check e2422406856154 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406857198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e2422406857198 : Closed e2422406857198 ∧ code e2422406857198 = 11218499879406 := by decide
theorem cert_e2422406857198 : check e2422406857198 [[],[]] .chain = true := by decide
def e2422406857206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e2422406857206 : Closed e2422406857206 ∧ code e2422406857206 = 11218499879414 := by decide
theorem cert_e2422406857206 : check e2422406857206 [[],[]] .chain = true := by decide
def e2422406857966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406857966 : Closed e2422406857966 ∧ code e2422406857966 = 11218499880174 := by decide
theorem cert_e2422406857966 : check e2422406857966 [[],[]] .chain = true := by decide
def e2422406857974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406857974 : Closed e2422406857974 ∧ code e2422406857974 = 11218499880182 := by decide
theorem cert_e2422406857974 : check e2422406857974 [[],[]] .chain = true := by decide
def e2422406858526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e2422406858526 : Closed e2422406858526 ∧ code e2422406858526 = 11218499880734 := by decide
theorem cert_e2422406858526 : check e2422406858526 [[],[]] .chain = true := by decide
def e2422406858638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e2422406858638 : Closed e2422406858638 ∧ code e2422406858638 = 11218499880846 := by decide
theorem cert_e2422406858638 : check e2422406858638 [[],[]] .chain = true := by decide
def e2422406860334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406860334 : Closed e2422406860334 ∧ code e2422406860334 = 11218499882542 := by decide
theorem cert_e2422406860334 : check e2422406860334 [[],[]] .chain = true := by decide
def e2422406860514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406860514 : Closed e2422406860514 ∧ code e2422406860514 = 11218499882722 := by decide
theorem cert_e2422406860514 : check e2422406860514 [[],[]] .chain = true := by decide
def e2422406860526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2422406860526 : Closed e2422406860526 ∧ code e2422406860526 = 11218499882734 := by decide
theorem cert_e2422406860526 : check e2422406860526 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406860566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406860566 : Closed e2422406860566 ∧ code e2422406860566 = 11218499882774 := by decide
theorem cert_e2422406860566 : check e2422406860566 [[],[]] .chain = true := by decide
def e2422406860642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406860642 : Closed e2422406860642 ∧ code e2422406860642 = 11218499882850 := by decide
theorem cert_e2422406860642 : check e2422406860642 [[],[]] .chain = true := by decide
def e2422406860654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2422406860654 : Closed e2422406860654 ∧ code e2422406860654 = 11218499882862 := by decide
theorem cert_e2422406860654 : check e2422406860654 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406860662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2422406860662 : Closed e2422406860662 ∧ code e2422406860662 = 11218499882870 := by decide
theorem cert_e2422406860662 : checkPay e2422406860662 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422406862910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e2422406862910 : Closed e2422406862910 ∧ code e2422406862910 = 11218499885118 := by decide
theorem cert_e2422406862910 : check e2422406862910 [[],[]] .chain = true := by decide
def e2422406863330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406863330 : Closed e2422406863330 ∧ code e2422406863330 = 11218499885538 := by decide
theorem cert_e2422406863330 : check e2422406863330 [[],[]] .chain = true := by decide
def e2422406863342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406863342 : Closed e2422406863342 ∧ code e2422406863342 = 11218499885550 := by decide
theorem cert_e2422406863342 : check e2422406863342 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406863902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e2422406863902 : Closed e2422406863902 ∧ code e2422406863902 = 11218499886110 := by decide
theorem cert_e2422406863902 : check e2422406863902 [[],[]] .chain = true := by decide
def e2422406864098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406864098 : Closed e2422406864098 ∧ code e2422406864098 = 11218499886306 := by decide
theorem cert_e2422406864098 : check e2422406864098 [[],[]] .chain = true := by decide
def e2422406864110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406864110 : Closed e2422406864110 ∧ code e2422406864110 = 11218499886318 := by decide
theorem cert_e2422406864110 : check e2422406864110 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406864118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406864118 : Closed e2422406864118 ∧ code e2422406864118 = 11218499886326 := by decide
theorem cert_e2422406864118 : check e2422406864118 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406864942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422406864942 : Closed e2422406864942 ∧ code e2422406864942 = 11218499887150 := by decide
theorem cert_e2422406864942 : check e2422406864942 [[],[]] .chain = true := by decide
def e2422406865134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422406865134 : Closed e2422406865134 ∧ code e2422406865134 = 11218499887342 := by decide
theorem cert_e2422406865134 : check e2422406865134 [[],[]] .chain = true := by decide
def e2422406865146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2422406865146 : Closed e2422406865146 ∧ code e2422406865146 = 11218499887354 := by decide
theorem cert_e2422406865146 : check e2422406865146 [[],[]] .chain = true := by decide
def e2422406865326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422406865326 : Closed e2422406865326 ∧ code e2422406865326 = 11218499887534 := by decide
theorem cert_e2422406865326 : check e2422406865326 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406865518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406865518 : Closed e2422406865518 ∧ code e2422406865518 = 11218499887726 := by decide
theorem cert_e2422406865518 : check e2422406865518 [[],[]] .chain = true := by decide
def e2422406865530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406865530 : Closed e2422406865530 ∧ code e2422406865530 = 11218499887738 := by decide
theorem cert_e2422406865530 : check e2422406865530 [[],[]] .chain = true := by decide
def e2422406865694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422406865694 : Closed e2422406865694 ∧ code e2422406865694 = 11218499887902 := by decide
theorem cert_e2422406865694 : check e2422406865694 [[],[]] .chain = true := by decide
def e2422406865862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2422406865862 : Closed e2422406865862 ∧ code e2422406865862 = 11218499888070 := by decide
theorem cert_e2422406865862 : check e2422406865862 [[],[]] .chain = true := by decide
def e2422406866478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406866478 : Closed e2422406866478 ∧ code e2422406866478 = 11218499888686 := by decide
theorem cert_e2422406866478 : check e2422406866478 [[],[]] .chain = true := by decide
def e2422406866658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406866658 : Closed e2422406866658 ∧ code e2422406866658 = 11218499888866 := by decide
theorem cert_e2422406866658 : check e2422406866658 [[],[]] .chain = true := by decide
def e2422406866670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2422406866670 : Closed e2422406866670 ∧ code e2422406866670 = 11218499888878 := by decide
theorem cert_e2422406866670 : check e2422406866670 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406866798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2422406866798 : Closed e2422406866798 ∧ code e2422406866798 = 11218499889006 := by decide
theorem cert_e2422406866798 : check e2422406866798 [[],[]] .chain = true := by decide
def e2422406866806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2422406866806 : Closed e2422406866806 ∧ code e2422406866806 = 11218499889014 := by decide
theorem cert_e2422406866806 : check e2422406866806 [[],[]] .chain = true := by decide
def e2422406866826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406866826 : Closed e2422406866826 ∧ code e2422406866826 = 11218499889034 := by decide
theorem cert_e2422406866826 : check e2422406866826 [[],[]] .chain = true := by decide
def e2422406866850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406866850 : Closed e2422406866850 ∧ code e2422406866850 = 11218499889058 := by decide
theorem cert_e2422406866850 : check e2422406866850 [[],[]] .chain = true := by decide
def e2422406866862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2422406866862 : Closed e2422406866862 ∧ code e2422406866862 = 11218499889070 := by decide
theorem cert_e2422406866862 : check e2422406866862 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406866870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2422406866870 : Closed e2422406866870 ∧ code e2422406866870 = 11218499889078 := by decide
theorem cert_e2422406866870 : check e2422406866870 [[],[]] .chain = true := by decide
def e2422406866874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2422406866874 : Closed e2422406866874 ∧ code e2422406866874 = 11218499889082 := by decide
theorem cert_e2422406866874 : check e2422406866874 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406867006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2422406867006 : Closed e2422406867006 ∧ code e2422406867006 = 11218499889214 := by decide
theorem cert_e2422406867006 : check e2422406867006 [[],[]] .chain = true := by decide
def e2422406867426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406867426 : Closed e2422406867426 ∧ code e2422406867426 = 11218499889634 := by decide
theorem cert_e2422406867426 : check e2422406867426 [[],[]] .chain = true := by decide
def e2422406867438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406867438 : Closed e2422406867438 ∧ code e2422406867438 = 11218499889646 := by decide
theorem cert_e2422406867438 : check e2422406867438 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406868206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406868206 : Closed e2422406868206 ∧ code e2422406868206 = 11218499890414 := by decide
theorem cert_e2422406868206 : check e2422406868206 [[],[]] .chain = true := by decide
def e2422406868214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406868214 : Closed e2422406868214 ∧ code e2422406868214 = 11218499890422 := by decide
theorem cert_e2422406868214 : check e2422406868214 [[],[]] .chain = true := by decide
def e2422406868482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406868482 : Closed e2422406868482 ∧ code e2422406868482 = 11218499890690 := by decide
theorem cert_e2422406868482 : check e2422406868482 [[],[]] .chain = true := by decide
def e2422406868494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406868494 : Closed e2422406868494 ∧ code e2422406868494 = 11218499890702 := by decide
theorem cert_e2422406868494 : check e2422406868494 [[],[]] .chain = true := by decide
def e2422406868506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406868506 : Closed e2422406868506 ∧ code e2422406868506 = 11218499890714 := by decide
theorem cert_e2422406868506 : check e2422406868506 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406868578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406868578 : Closed e2422406868578 ∧ code e2422406868578 = 11218499890786 := by decide
theorem cert_e2422406868578 : check e2422406868578 [[],[]] .chain = true := by decide
def e2422406868590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406868590 : Closed e2422406868590 ∧ code e2422406868590 = 11218499890798 := by decide
theorem cert_e2422406868590 : check e2422406868590 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406868598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406868598 : Closed e2422406868598 ∧ code e2422406868598 = 11218499890806 := by decide
theorem cert_e2422406868598 : check e2422406868598 [[],[]] .chain = true := by decide
def e2422406868602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406868602 : Closed e2422406868602 ∧ code e2422406868602 = 11218499890810 := by decide
theorem cert_e2422406868602 : check e2422406868602 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406869014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422406869014 : Closed e2422406869014 ∧ code e2422406869014 = 11218499891222 := by decide
theorem cert_e2422406869014 : check e2422406869014 [[],[]] .chain = true := by decide
def e2422406869110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422406869110 : Closed e2422406869110 ∧ code e2422406869110 = 11218499891318 := by decide
theorem cert_e2422406869110 : check e2422406869110 [[],[]] .chain = true := by decide
def e2422406869114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422406869114 : Closed e2422406869114 ∧ code e2422406869114 = 11218499891322 := by decide
theorem cert_e2422406869114 : check e2422406869114 [[],[]] .chain = true := by decide
def e2422406869206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422406869206 : Closed e2422406869206 ∧ code e2422406869206 = 11218499891414 := by decide
theorem cert_e2422406869206 : checkPay e2422406869206 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406869302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406869302 : Closed e2422406869302 ∧ code e2422406869302 = 11218499891510 := by decide
theorem cert_e2422406869302 : check e2422406869302 [[],[]] .chain = true := by decide
def e2422406869306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406869306 : Closed e2422406869306 ∧ code e2422406869306 = 11218499891514 := by decide
theorem cert_e2422406869306 : check e2422406869306 [[],[]] .chain = true := by decide
def e2422406869390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422406869390 : Closed e2422406869390 ∧ code e2422406869390 = 11218499891598 := by decide
theorem cert_e2422406869390 : check e2422406869390 [[],[]] .chain = true := by decide
def e2422406869446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422406869446 : Closed e2422406869446 ∧ code e2422406869446 = 11218499891654 := by decide
theorem cert_e2422406869446 : check e2422406869446 [[],[]] .chain = true := by decide
def e2422406869782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406869782 : Closed e2422406869782 ∧ code e2422406869782 = 11218499891990 := by decide
theorem cert_e2422406869782 : check e2422406869782 [[],[]] .chain = true := by decide
def e2422406869858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406869858 : Closed e2422406869858 ∧ code e2422406869858 = 11218499892066 := by decide
theorem cert_e2422406869858 : check e2422406869858 [[],[]] .chain = true := by decide
def e2422406869870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406869870 : Closed e2422406869870 ∧ code e2422406869870 = 11218499892078 := by decide
theorem cert_e2422406869870 : check e2422406869870 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406869878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406869878 : Closed e2422406869878 ∧ code e2422406869878 = 11218499892086 := by decide
theorem cert_e2422406869878 : checkPay e2422406869878 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406869898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406869898 : Closed e2422406869898 ∧ code e2422406869898 = 11218499892106 := by decide
theorem cert_e2422406869898 : check e2422406869898 [[],[]] .chain = true := by decide
def e2422406869922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406869922 : Closed e2422406869922 ∧ code e2422406869922 = 11218499892130 := by decide
theorem cert_e2422406869922 : check e2422406869922 [[],[]] .chain = true := by decide
def e2422406869934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406869934 : Closed e2422406869934 ∧ code e2422406869934 = 11218499892142 := by decide
theorem cert_e2422406869934 : check e2422406869934 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406869942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2422406869942 : Closed e2422406869942 ∧ code e2422406869942 = 11218499892150 := by decide
theorem cert_e2422406869942 : check e2422406869942 [[],[]] .chain = true := by decide
def e2422406869946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406869946 : Closed e2422406869946 ∧ code e2422406869946 = 11218499892154 := by decide
theorem cert_e2422406869946 : check e2422406869946 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406869974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406869974 : Closed e2422406869974 ∧ code e2422406869974 = 11218499892182 := by decide
theorem cert_e2422406869974 : checkPay e2422406869974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406869978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406869978 : Closed e2422406869978 ∧ code e2422406869978 = 11218499892186 := by decide
theorem cert_e2422406869978 : check e2422406869978 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406870046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2422406870046 : Closed e2422406870046 ∧ code e2422406870046 = 11218499892254 := by decide
theorem cert_e2422406870046 : check e2422406870046 [[],[]] .chain = true := by decide
def e2422406870242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406870242 : Closed e2422406870242 ∧ code e2422406870242 = 11218499892450 := by decide
theorem cert_e2422406870242 : check e2422406870242 [[],[]] .chain = true := by decide
def e2422406870254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406870254 : Closed e2422406870254 ∧ code e2422406870254 = 11218499892462 := by decide
theorem cert_e2422406870254 : check e2422406870254 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406870262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406870262 : Closed e2422406870262 ∧ code e2422406870262 = 11218499892470 := by decide
theorem cert_e2422406870262 : check e2422406870262 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406870530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406870530 : Closed e2422406870530 ∧ code e2422406870530 = 11218499892738 := by decide
theorem cert_e2422406870530 : check e2422406870530 [[],[]] .chain = true := by decide
def e2422406870542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406870542 : Closed e2422406870542 ∧ code e2422406870542 = 11218499892750 := by decide
theorem cert_e2422406870542 : check e2422406870542 [[],[]] .chain = true := by decide
def e2422406870554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406870554 : Closed e2422406870554 ∧ code e2422406870554 = 11218499892762 := by decide
theorem cert_e2422406870554 : check e2422406870554 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2422406870626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406870626 : Closed e2422406870626 ∧ code e2422406870626 = 11218499892834 := by decide
theorem cert_e2422406870626 : check e2422406870626 [[],[]] .chain = true := by decide
def e2422406870638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406870638 : Closed e2422406870638 ∧ code e2422406870638 = 11218499892846 := by decide
theorem cert_e2422406870638 : check e2422406870638 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406870646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406870646 : Closed e2422406870646 ∧ code e2422406870646 = 11218499892854 := by decide
theorem cert_e2422406870646 : check e2422406870646 [[],[]] .chain = true := by decide
def e2422406870650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406870650 : Closed e2422406870650 ∧ code e2422406870650 = 11218499892858 := by decide
theorem cert_e2422406870650 : check e2422406870650 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406870838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406870838 : Closed e2422406870838 ∧ code e2422406870838 = 11218499893046 := by decide
theorem cert_e2422406870838 : check e2422406870838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406870842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406870842 : Closed e2422406870842 ∧ code e2422406870842 = 11218499893050 := by decide
theorem cert_e2422406870842 : check e2422406870842 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406873262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 2))))))
theorem wire_e2422406873262 : Closed e2422406873262 ∧ code e2422406873262 = 11218499895470 := by decide
theorem cert_e2422406873262 : check e2422406873262 [[],[]] .chain = true := by decide
def e2422406873274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 2)) (.var 0))))))
theorem wire_e2422406873274 : Closed e2422406873274 ∧ code e2422406873274 = 11218499895482 := by decide
theorem cert_e2422406873274 : check e2422406873274 [[],[]] .chain = true := by decide
def e2422406873838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)) (.var 2))))))
theorem wire_e2422406873838 : Closed e2422406873838 ∧ code e2422406873838 = 11218499896046 := by decide
theorem cert_e2422406873838 : check e2422406873838 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406873966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 1)) (.var 2))))))
theorem wire_e2422406873966 : Closed e2422406873966 ∧ code e2422406873966 = 11218499896174 := by decide
theorem cert_e2422406873966 : check e2422406873966 [[],[]] .chain = true := by decide
def e2422406873974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 2)) (.var 1))))))
theorem wire_e2422406873974 : Closed e2422406873974 ∧ code e2422406873974 = 11218499896182 := by decide
theorem cert_e2422406873974 : check e2422406873974 [[],[]] .chain = true := by decide
def e2422406874030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0)) (.var 2))))))
theorem wire_e2422406874030 : Closed e2422406874030 ∧ code e2422406874030 = 11218499896238 := by decide
theorem cert_e2422406874030 : check e2422406874030 [[],[]] .chain = true := by decide
def e2422406874042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2)) (.var 0))))))
theorem wire_e2422406874042 : Closed e2422406874042 ∧ code e2422406874042 = 11218499896250 := by decide
theorem cert_e2422406874042 : check e2422406874042 [[],[]] .chain = true := by decide
def e2422406874090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0)) (.var 0))))))
theorem wire_e2422406874090 : Closed e2422406874090 ∧ code e2422406874090 = 11218499896298 := by decide
theorem cert_e2422406874090 : check e2422406874090 [[],[]] .chain = true := by decide
def e2422406874798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422406874798 : Closed e2422406874798 ∧ code e2422406874798 = 11218499897006 := by decide
theorem cert_e2422406874798 : check e2422406874798 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406874810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422406874810 : Closed e2422406874810 ∧ code e2422406874810 = 11218499897018 := by decide
theorem cert_e2422406874810 : check e2422406874810 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406875374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406875374 : Closed e2422406875374 ∧ code e2422406875374 = 11218499897582 := by decide
theorem cert_e2422406875374 : check e2422406875374 [[],[]] .chain = true := by decide
def e2422406875382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406875382 : Closed e2422406875382 ∧ code e2422406875382 = 11218499897590 := by decide
theorem cert_e2422406875382 : check e2422406875382 [[],[]] .chain = true := by decide
def e2422406875566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406875566 : Closed e2422406875566 ∧ code e2422406875566 = 11218499897774 := by decide
theorem cert_e2422406875566 : check e2422406875566 [[],[]] .chain = true := by decide
def e2422406875578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406875578 : Closed e2422406875578 ∧ code e2422406875578 = 11218499897786 := by decide
theorem cert_e2422406875578 : check e2422406875578 [[],[]] .chain = true := by decide
def e2422406875626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406875626 : Closed e2422406875626 ∧ code e2422406875626 = 11218499897834 := by decide
theorem cert_e2422406875626 : check e2422406875626 [[],[]] .chain = true := by decide
def e2422406875758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406875758 : Closed e2422406875758 ∧ code e2422406875758 = 11218499897966 := by decide
theorem cert_e2422406875758 : check e2422406875758 [[],[]] .chain = true := by decide
def e2422406875770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406875770 : Closed e2422406875770 ∧ code e2422406875770 = 11218499897978 := by decide
theorem cert_e2422406875770 : check e2422406875770 [[],[]] .chain = true := by decide
def e2422406875934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406875934 : Closed e2422406875934 ∧ code e2422406875934 = 11218499898142 := by decide
theorem cert_e2422406875934 : check e2422406875934 [[],[]] .chain = true := by decide
def e2422406876046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406876046 : Closed e2422406876046 ∧ code e2422406876046 = 11218499898254 := by decide
theorem cert_e2422406876046 : check e2422406876046 [[],[]] .chain = true := by decide
def e2422406876058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406876058 : Closed e2422406876058 ∧ code e2422406876058 = 11218499898266 := by decide
theorem cert_e2422406876058 : check e2422406876058 [[],[]] .chain = true := by decide
def e2422406876270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406876270 : Closed e2422406876270 ∧ code e2422406876270 = 11218499898478 := by decide
theorem cert_e2422406876270 : check e2422406876270 [[],[]] .chain = true := by decide
def e2422406876282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406876282 : Closed e2422406876282 ∧ code e2422406876282 = 11218499898490 := by decide
theorem cert_e2422406876282 : check e2422406876282 [[],[]] .chain = true := by decide
def e2422406876446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406876446 : Closed e2422406876446 ∧ code e2422406876446 = 11218499898654 := by decide
theorem cert_e2422406876446 : check e2422406876446 [[],[]] .chain = true := by decide
def e2422406876614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406876614 : Closed e2422406876614 ∧ code e2422406876614 = 11218499898822 := by decide
theorem cert_e2422406876614 : check e2422406876614 [[],[]] .chain = true := by decide
def e2422406876718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406876718 : Closed e2422406876718 ∧ code e2422406876718 = 11218499898926 := by decide
theorem cert_e2422406876718 : check e2422406876718 [[],[]] .chain = true := by decide
def e2422406876898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406876898 : Closed e2422406876898 ∧ code e2422406876898 = 11218499899106 := by decide
theorem cert_e2422406876898 : check e2422406876898 [[],[]] .chain = true := by decide
def e2422406876910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)) (.var 2))))))
theorem wire_e2422406876910 : Closed e2422406876910 ∧ code e2422406876910 = 11218499899118 := by decide
theorem cert_e2422406876910 : check e2422406876910 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406876950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406876950 : Closed e2422406876950 ∧ code e2422406876950 = 11218499899158 := by decide
theorem cert_e2422406876950 : check e2422406876950 [[],[]] .chain = true := by decide
def e2422406876954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406876954 : Closed e2422406876954 ∧ code e2422406876954 = 11218499899162 := by decide
theorem cert_e2422406876954 : check e2422406876954 [[],[]] .chain = true := by decide
def e2422406876998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406876998 : Closed e2422406876998 ∧ code e2422406876998 = 11218499899206 := by decide
theorem cert_e2422406876998 : check e2422406876998 [[],[]] .chain = true := by decide
def e2422406877026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406877026 : Closed e2422406877026 ∧ code e2422406877026 = 11218499899234 := by decide
theorem cert_e2422406877026 : check e2422406877026 [[],[]] .chain = true := by decide
def e2422406877038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)) (.var 2))))))
theorem wire_e2422406877038 : Closed e2422406877038 ∧ code e2422406877038 = 11218499899246 := by decide
theorem cert_e2422406877038 : check e2422406877038 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406877046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2)) (.var 1))))))
theorem wire_e2422406877046 : Closed e2422406877046 ∧ code e2422406877046 = 11218499899254 := by decide
theorem cert_e2422406877046 : check e2422406877046 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406879406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422406879406 : Closed e2422406879406 ∧ code e2422406879406 = 11218499901614 := by decide
theorem cert_e2422406879406 : check e2422406879406 [[],[]] .chain = true := by decide
def e2422406879418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422406879418 : Closed e2422406879418 ∧ code e2422406879418 = 11218499901626 := by decide
theorem cert_e2422406879418 : check e2422406879418 [[],[]] .chain = true := by decide
def e2422406879790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406879790 : Closed e2422406879790 ∧ code e2422406879790 = 11218499901998 := by decide
theorem cert_e2422406879790 : check e2422406879790 [[],[]] .chain = true := by decide
def e2422406879970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406879970 : Closed e2422406879970 ∧ code e2422406879970 = 11218499902178 := by decide
theorem cert_e2422406879970 : check e2422406879970 [[],[]] .chain = true := by decide
def e2422406879982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)) (.var 2))))))
theorem wire_e2422406879982 : Closed e2422406879982 ∧ code e2422406879982 = 11218499902190 := by decide
theorem cert_e2422406879982 : check e2422406879982 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406880110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422406880110 : Closed e2422406880110 ∧ code e2422406880110 = 11218499902318 := by decide
theorem cert_e2422406880110 : check e2422406880110 [[],[]] .chain = true := by decide
def e2422406880118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422406880118 : Closed e2422406880118 ∧ code e2422406880118 = 11218499902326 := by decide
theorem cert_e2422406880118 : check e2422406880118 [[],[]] .chain = true := by decide
def e2422406880138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406880138 : Closed e2422406880138 ∧ code e2422406880138 = 11218499902346 := by decide
theorem cert_e2422406880138 : check e2422406880138 [[],[]] .chain = true := by decide
def e2422406880162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406880162 : Closed e2422406880162 ∧ code e2422406880162 = 11218499902370 := by decide
theorem cert_e2422406880162 : check e2422406880162 [[],[]] .chain = true := by decide
def e2422406880174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422406880174 : Closed e2422406880174 ∧ code e2422406880174 = 11218499902382 := by decide
theorem cert_e2422406880174 : check e2422406880174 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406880182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e2422406880182 : Closed e2422406880182 ∧ code e2422406880182 = 11218499902390 := by decide
theorem cert_e2422406880182 : check e2422406880182 [[],[]] .chain = true := by decide
def e2422406880186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422406880186 : Closed e2422406880186 ∧ code e2422406880186 = 11218499902394 := by decide
theorem cert_e2422406880186 : check e2422406880186 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406880622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422406880622 : Closed e2422406880622 ∧ code e2422406880622 = 11218499902830 := by decide
theorem cert_e2422406880622 : check e2422406880622 [[],[]] .chain = true := by decide
def e2422406880630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422406880630 : Closed e2422406880630 ∧ code e2422406880630 = 11218499902838 := by decide
theorem cert_e2422406880630 : check e2422406880630 [[],[]] .chain = true := by decide
def e2422406880686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2422406880686 : Closed e2422406880686 ∧ code e2422406880686 = 11218499902894 := by decide
theorem cert_e2422406880686 : check e2422406880686 [[],[]] .chain = true := by decide
def e2422406880698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2422406880698 : Closed e2422406880698 ∧ code e2422406880698 = 11218499902906 := by decide
theorem cert_e2422406880698 : check e2422406880698 [[],[]] .chain = true := by decide
def e2422406880726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422406880726 : Closed e2422406880726 ∧ code e2422406880726 = 11218499902934 := by decide
theorem cert_e2422406880726 : check e2422406880726 [[],[]] .chain = true := by decide
def e2422406880730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422406880730 : Closed e2422406880730 ∧ code e2422406880730 = 11218499902938 := by decide
theorem cert_e2422406880730 : check e2422406880730 [[],[]] .chain = true := by decide
end Blc.Floor43
