import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411653696430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411653696430 : Closed e2411653696430 ∧ code e2411653696430 = 11207746718638 := by decide
theorem cert_e2411653696430 : check e2411653696430 [[],[],[.under]] .smaller = true := by decide
def e2411653696442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411653696442 : Closed e2411653696442 ∧ code e2411653696442 = 11207746718650 := by decide
theorem cert_e2411653696442 : check e2411653696442 [[],[],[.under]] .smaller = true := by decide
def e2411653696470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411653696470 : Closed e2411653696470 ∧ code e2411653696470 = 11207746718678 := by decide
theorem cert_e2411653696470 : check e2411653696470 [[],[],[.under]] .smaller = true := by decide
def e2411653696474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411653696474 : Closed e2411653696474 ∧ code e2411653696474 = 11207746718682 := by decide
theorem cert_e2411653696474 : check e2411653696474 [[],[],[.under]] .smaller = true := by decide
def e2411653696750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411653696750 : Closed e2411653696750 ∧ code e2411653696750 = 11207746718958 := by decide
theorem cert_e2411653696750 : check e2411653696750 [[],[],[.under]] .smaller = true := by decide
def e2411653696758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411653696758 : Closed e2411653696758 ∧ code e2411653696758 = 11207746718966 := by decide
theorem cert_e2411653696758 : check e2411653696758 [[],[],[.under]] .smaller = true := by decide
def e2411653697134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411653697134 : Closed e2411653697134 ∧ code e2411653697134 = 11207746719342 := by decide
theorem cert_e2411653697134 : check e2411653697134 [[],[],[.under]] .smaller = true := by decide
def e2411653697146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411653697146 : Closed e2411653697146 ∧ code e2411653697146 = 11207746719354 := by decide
theorem cert_e2411653697146 : check e2411653697146 [[],[],[.under]] .smaller = true := by decide
def e2411653697334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411653697334 : Closed e2411653697334 ∧ code e2411653697334 = 11207746719542 := by decide
theorem cert_e2411653697334 : check e2411653697334 [[],[],[.under]] .smaller = true := by decide
def e2411653697338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411653697338 : Closed e2411653697338 ∧ code e2411653697338 = 11207746719546 := by decide
theorem cert_e2411653697338 : check e2411653697338 [[],[],[.under]] .smaller = true := by decide
def e2411653705262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2411653705262 : Closed e2411653705262 ∧ code e2411653705262 = 11207746727470 := by decide
theorem cert_e2411653705262 : check e2411653705262 [[],[],[.under]] .smaller = true := by decide
def e2411653705442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2411653705442 : Closed e2411653705442 ∧ code e2411653705442 = 11207746727650 := by decide
theorem cert_e2411653705442 : check e2411653705442 [[],[],[.under]] .smaller = true := by decide
def e2411653705454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2411653705454 : Closed e2411653705454 ∧ code e2411653705454 = 11207746727662 := by decide
theorem cert_e2411653705454 : check e2411653705454 [[],[],[.under]] .smaller = true := by decide
def e2411653705494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2411653705494 : Closed e2411653705494 ∧ code e2411653705494 = 11207746727702 := by decide
theorem cert_e2411653705494 : check e2411653705494 [[],[],[.under]] .smaller = true := by decide
def e2411653705570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2411653705570 : Closed e2411653705570 ∧ code e2411653705570 = 11207746727778 := by decide
theorem cert_e2411653705570 : check e2411653705570 [[],[],[.under]] .smaller = true := by decide
def e2411653705582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2411653705582 : Closed e2411653705582 ∧ code e2411653705582 = 11207746727790 := by decide
theorem cert_e2411653705582 : check e2411653705582 [[],[],[.under]] .smaller = true := by decide
def e2411653705590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2411653705590 : Closed e2411653705590 ∧ code e2411653705590 = 11207746727798 := by decide
theorem cert_e2411653705590 : check e2411653705590 [[],[],[.under]] .smaller = true := by decide
def e2411653707838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2411653707838 : Closed e2411653707838 ∧ code e2411653707838 = 11207746730046 := by decide
theorem cert_e2411653707838 : check e2411653707838 [[],[],[.under]] .smaller = true := by decide
def e2411653708258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2411653708258 : Closed e2411653708258 ∧ code e2411653708258 = 11207746730466 := by decide
theorem cert_e2411653708258 : check e2411653708258 [[],[],[.under]] .smaller = true := by decide
def e2411653708270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2411653708270 : Closed e2411653708270 ∧ code e2411653708270 = 11207746730478 := by decide
theorem cert_e2411653708270 : check e2411653708270 [[],[],[.under]] .smaller = true := by decide
def e2411653708830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2411653708830 : Closed e2411653708830 ∧ code e2411653708830 = 11207746731038 := by decide
theorem cert_e2411653708830 : check e2411653708830 [[],[],[.under]] .smaller = true := by decide
def e2411653709026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2411653709026 : Closed e2411653709026 ∧ code e2411653709026 = 11207746731234 := by decide
theorem cert_e2411653709026 : check e2411653709026 [[],[],[.under]] .smaller = true := by decide
def e2411653709038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411653709038 : Closed e2411653709038 ∧ code e2411653709038 = 11207746731246 := by decide
theorem cert_e2411653709038 : check e2411653709038 [[],[],[.under]] .smaller = true := by decide
def e2411653709046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411653709046 : Closed e2411653709046 ∧ code e2411653709046 = 11207746731254 := by decide
theorem cert_e2411653709046 : check e2411653709046 [[],[],[.under]] .smaller = true := by decide
def e2411653731886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2411653731886 : Closed e2411653731886 ∧ code e2411653731886 = 11207746754094 := by decide
theorem cert_e2411653731886 : check e2411653731886 [[],[],[.under]] .smaller = true := by decide
def e2411653732066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2411653732066 : Closed e2411653732066 ∧ code e2411653732066 = 11207746754274 := by decide
theorem cert_e2411653732066 : check e2411653732066 [[],[],[.under]] .smaller = true := by decide
def e2411653732078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2411653732078 : Closed e2411653732078 ∧ code e2411653732078 = 11207746754286 := by decide
theorem cert_e2411653732078 : check e2411653732078 [[],[],[.under]] .smaller = true := by decide
def e2411653732234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2411653732234 : Closed e2411653732234 ∧ code e2411653732234 = 11207746754442 := by decide
theorem cert_e2411653732234 : check e2411653732234 [[],[],[.under]] .smaller = true := by decide
def e2411653732258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2411653732258 : Closed e2411653732258 ∧ code e2411653732258 = 11207746754466 := by decide
theorem cert_e2411653732258 : check e2411653732258 [[],[],[.under]] .smaller = true := by decide
def e2411653732270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2411653732270 : Closed e2411653732270 ∧ code e2411653732270 = 11207746754478 := by decide
theorem cert_e2411653732270 : check e2411653732270 [[],[],[.under]] .smaller = true := by decide
def e2411653732282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2411653732282 : Closed e2411653732282 ∧ code e2411653732282 = 11207746754490 := by decide
theorem cert_e2411653732282 : check e2411653732282 [[],[],[.under]] .smaller = true := by decide
def e2411653732414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2411653732414 : Closed e2411653732414 ∧ code e2411653732414 = 11207746754622 := by decide
theorem cert_e2411653732414 : check e2411653732414 [[],[],[.under]] .smaller = true := by decide
def e2411653732834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2411653732834 : Closed e2411653732834 ∧ code e2411653732834 = 11207746755042 := by decide
theorem cert_e2411653732834 : check e2411653732834 [[],[],[.under]] .smaller = true := by decide
def e2411653732846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2411653732846 : Closed e2411653732846 ∧ code e2411653732846 = 11207746755054 := by decide
theorem cert_e2411653732846 : check e2411653732846 [[],[],[.under]] .smaller = true := by decide
def e2411653733902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2411653733902 : Closed e2411653733902 ∧ code e2411653733902 = 11207746756110 := by decide
theorem cert_e2411653733902 : check e2411653733902 [[],[],[.under]] .smaller = true := by decide
def e2411653733986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2411653733986 : Closed e2411653733986 ∧ code e2411653733986 = 11207746756194 := by decide
theorem cert_e2411653733986 : check e2411653733986 [[],[],[.under]] .smaller = true := by decide
def e2411653733998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411653733998 : Closed e2411653733998 ∧ code e2411653733998 = 11207746756206 := by decide
theorem cert_e2411653733998 : check e2411653733998 [[],[],[.under]] .smaller = true := by decide
def e2411653734010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411653734010 : Closed e2411653734010 ∧ code e2411653734010 = 11207746756218 := by decide
theorem cert_e2411653734010 : check e2411653734010 [[],[],[.under]] .smaller = true := by decide
def e2411653745430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2411653745430 : Closed e2411653745430 ∧ code e2411653745430 = 11207746767638 := by decide
theorem cert_e2411653745430 : check e2411653745430 [[],[],[.under]] .smaller = true := by decide
def e2411653745506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2411653745506 : Closed e2411653745506 ∧ code e2411653745506 = 11207746767714 := by decide
theorem cert_e2411653745506 : check e2411653745506 [[],[],[.under]] .smaller = true := by decide
def e2411653745518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2411653745518 : Closed e2411653745518 ∧ code e2411653745518 = 11207746767726 := by decide
theorem cert_e2411653745518 : check e2411653745518 [[],[],[.under]] .smaller = true := by decide
def e2411653745526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2411653745526 : Closed e2411653745526 ∧ code e2411653745526 = 11207746767734 := by decide
theorem cert_e2411653745526 : check e2411653745526 [[],[],[.under]] .smaller = true := by decide
def e2411653745546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2411653745546 : Closed e2411653745546 ∧ code e2411653745546 = 11207746767754 := by decide
theorem cert_e2411653745546 : check e2411653745546 [[],[],[.under]] .smaller = true := by decide
def e2411653745570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2411653745570 : Closed e2411653745570 ∧ code e2411653745570 = 11207746767778 := by decide
theorem cert_e2411653745570 : check e2411653745570 [[],[],[.under]] .smaller = true := by decide
def e2411653745582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2411653745582 : Closed e2411653745582 ∧ code e2411653745582 = 11207746767790 := by decide
theorem cert_e2411653745582 : check e2411653745582 [[],[],[.under]] .smaller = true := by decide
def e2411653745594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2411653745594 : Closed e2411653745594 ∧ code e2411653745594 = 11207746767802 := by decide
theorem cert_e2411653745594 : check e2411653745594 [[],[],[.under]] .smaller = true := by decide
def e2411653745622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2411653745622 : Closed e2411653745622 ∧ code e2411653745622 = 11207746767830 := by decide
theorem cert_e2411653745622 : check e2411653745622 [[],[],[.under]] .smaller = true := by decide
def e2411653745626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2411653745626 : Closed e2411653745626 ∧ code e2411653745626 = 11207746767834 := by decide
theorem cert_e2411653745626 : check e2411653745626 [[],[],[.under]] .smaller = true := by decide
def e2411653745694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2411653745694 : Closed e2411653745694 ∧ code e2411653745694 = 11207746767902 := by decide
theorem cert_e2411653745694 : check e2411653745694 [[],[],[.under]] .smaller = true := by decide
def e2411653745890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2411653745890 : Closed e2411653745890 ∧ code e2411653745890 = 11207746768098 := by decide
theorem cert_e2411653745890 : check e2411653745890 [[],[],[.under]] .smaller = true := by decide
def e2411653745902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411653745902 : Closed e2411653745902 ∧ code e2411653745902 = 11207746768110 := by decide
theorem cert_e2411653745902 : check e2411653745902 [[],[],[.under]] .smaller = true := by decide
def e2411653745910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411653745910 : Closed e2411653745910 ∧ code e2411653745910 = 11207746768118 := by decide
theorem cert_e2411653745910 : check e2411653745910 [[],[],[.under]] .smaller = true := by decide
def e2411653746190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2411653746190 : Closed e2411653746190 ∧ code e2411653746190 = 11207746768398 := by decide
theorem cert_e2411653746190 : check e2411653746190 [[],[],[.under]] .smaller = true := by decide
def e2411653746274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2411653746274 : Closed e2411653746274 ∧ code e2411653746274 = 11207746768482 := by decide
theorem cert_e2411653746274 : check e2411653746274 [[],[],[.under]] .smaller = true := by decide
def e2411653746286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411653746286 : Closed e2411653746286 ∧ code e2411653746286 = 11207746768494 := by decide
theorem cert_e2411653746286 : check e2411653746286 [[],[],[.under]] .smaller = true := by decide
def e2411653746298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411653746298 : Closed e2411653746298 ∧ code e2411653746298 = 11207746768506 := by decide
theorem cert_e2411653746298 : check e2411653746298 [[],[],[.under]] .smaller = true := by decide
def e2411653746486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411653746486 : Closed e2411653746486 ∧ code e2411653746486 = 11207746768694 := by decide
theorem cert_e2411653746486 : check e2411653746486 [[],[],[.under]] .smaller = true := by decide
def e2411653746490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411653746490 : Closed e2411653746490 ∧ code e2411653746490 = 11207746768698 := by decide
theorem cert_e2411653746490 : check e2411653746490 [[],[],[.under]] .smaller = true := by decide
def e2411654286190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411654286190 : Closed e2411654286190 ∧ code e2411654286190 = 11207747308398 := by decide
theorem cert_e2411654286190 : check e2411654286190 [[],[]] .chain = true := by decide
def e2411654286198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411654286198 : Closed e2411654286198 ∧ code e2411654286198 = 11207747308406 := by decide
theorem cert_e2411654286198 : check e2411654286198 [[],[]] .chain = true := by decide
def e2411654286254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411654286254 : Closed e2411654286254 ∧ code e2411654286254 = 11207747308462 := by decide
theorem cert_e2411654286254 : check e2411654286254 [[],[]] .chain = true := by decide
def e2411654286266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411654286266 : Closed e2411654286266 ∧ code e2411654286266 = 11207747308474 := by decide
theorem cert_e2411654286266 : check e2411654286266 [[],[]] .chain = true := by decide
def e2411654286294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411654286294 : Closed e2411654286294 ∧ code e2411654286294 = 11207747308502 := by decide
theorem cert_e2411654286294 : check e2411654286294 [[],[]] .chain = true := by decide
def e2411654286298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411654286298 : Closed e2411654286298 ∧ code e2411654286298 = 11207747308506 := by decide
theorem cert_e2411654286298 : check e2411654286298 [[],[]] .chain = true := by decide
def e2411654286574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411654286574 : Closed e2411654286574 ∧ code e2411654286574 = 11207747308782 := by decide
theorem cert_e2411654286574 : check e2411654286574 [[],[]] .chain = true := by decide
def e2411654286582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411654286582 : Closed e2411654286582 ∧ code e2411654286582 = 11207747308790 := by decide
theorem cert_e2411654286582 : check e2411654286582 [[],[]] .chain = true := by decide
def e2411654286958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411654286958 : Closed e2411654286958 ∧ code e2411654286958 = 11207747309166 := by decide
theorem cert_e2411654286958 : check e2411654286958 [[],[]] .chain = true := by decide
def e2411654286970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411654286970 : Closed e2411654286970 ∧ code e2411654286970 = 11207747309178 := by decide
theorem cert_e2411654286970 : check e2411654286970 [[],[]] .chain = true := by decide
def e2411654287158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411654287158 : Closed e2411654287158 ∧ code e2411654287158 = 11207747309366 := by decide
theorem cert_e2411654287158 : check e2411654287158 [[],[]] .chain = true := by decide
def e2411654287162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411654287162 : Closed e2411654287162 ∧ code e2411654287162 = 11207747309370 := by decide
theorem cert_e2411654287162 : check e2411654287162 [[],[]] .chain = true := by decide
def e2411716434810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))) (.var 0))))
theorem wire_e2411716434810 : Closed e2411716434810 ∧ code e2411716434810 = 11207809457018 := by decide
def e2411716434906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))) (.var 0))))
theorem wire_e2411716434906 : Closed e2411716434906 ∧ code e2411716434906 = 11207809457114 := by decide
def e2411716435322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))) (.var 0))))
theorem wire_e2411716435322 : Closed e2411716435322 ∧ code e2411716435322 = 11207809457530 := by decide
def e2411716435434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))) (.var 0))))
theorem wire_e2411716435434 : Closed e2411716435434 ∧ code e2411716435434 = 11207809457642 := by decide
def e2411716435802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e2411716435802 : Closed e2411716435802 ∧ code e2411716435802 = 11207809458010 := by decide
def e2411716435818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e2411716435818 : Closed e2411716435818 ∧ code e2411716435818 = 11207809458026 := by decide
def e2411716437882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))) (.var 0))))
theorem wire_e2411716437882 : Closed e2411716437882 ∧ code e2411716437882 = 11207809460090 := by decide
def e2411716437978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))) (.var 0))))
theorem wire_e2411716437978 : Closed e2411716437978 ∧ code e2411716437978 = 11207809460186 := by decide
def e2411716440954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))) (.var 0))))
theorem wire_e2411716440954 : Closed e2411716440954 ∧ code e2411716440954 = 11207809463162 := by decide
def e2411716441066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))) (.var 0))))
theorem wire_e2411716441066 : Closed e2411716441066 ∧ code e2411716441066 = 11207809463274 := by decide
def e2411716443354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e2411716443354 : Closed e2411716443354 ∧ code e2411716443354 = 11207809465562 := by decide
def e2411716443370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e2411716443370 : Closed e2411716443370 ∧ code e2411716443370 = 11207809465578 := by decide
def e2411716502458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))) (.var 0))))
theorem wire_e2411716502458 : Closed e2411716502458 ∧ code e2411716502458 = 11207809524666 := by decide
def e2411716502490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))) (.var 0))))
theorem wire_e2411716502490 : Closed e2411716502490 ∧ code e2411716502490 = 11207809524698 := by decide
def e2411716504698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))) (.var 0))))
theorem wire_e2411716504698 : Closed e2411716504698 ∧ code e2411716504698 = 11207809526906 := by decide
def e2411716505030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 1)))))
theorem wire_e2411716505030 : Closed e2411716505030 ∧ code e2411716505030 = 11207809527238 := by decide
theorem cert_e2411716505030 : check e2411716505030 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716505146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))) (.var 0))))
theorem wire_e2411716505146 : Closed e2411716505146 ∧ code e2411716505146 = 11207809527354 := by decide
def e2411716505286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 1)))))
theorem wire_e2411716505286 : Closed e2411716505286 ∧ code e2411716505286 = 11207809527494 := by decide
theorem cert_e2411716505286 : check e2411716505286 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716506042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))) (.var 0))))
theorem wire_e2411716506042 : Closed e2411716506042 ∧ code e2411716506042 = 11207809528250 := by decide
def e2411716506090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))) (.var 0))))
theorem wire_e2411716506090 : Closed e2411716506090 ∧ code e2411716506090 = 11207809528298 := by decide
def e2411716506746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))) (.var 0))))
theorem wire_e2411716506746 : Closed e2411716506746 ∧ code e2411716506746 = 11207809528954 := by decide
def e2411716507078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 1)))))
theorem wire_e2411716507078 : Closed e2411716507078 ∧ code e2411716507078 = 11207809529286 := by decide
theorem cert_e2411716507078 : check e2411716507078 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716507418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))) (.var 0))))
theorem wire_e2411716507418 : Closed e2411716507418 ∧ code e2411716507418 = 11207809529626 := by decide
def e2411716507462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 1)))))
theorem wire_e2411716507462 : Closed e2411716507462 ∧ code e2411716507462 = 11207809529670 := by decide
theorem cert_e2411716507462 : check e2411716507462 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716507866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.var 0))))
theorem wire_e2411716507866 : Closed e2411716507866 ∧ code e2411716507866 = 11207809530074 := by decide
def e2411716507882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.var 0))))
theorem wire_e2411716507882 : Closed e2411716507882 ∧ code e2411716507882 = 11207809530090 := by decide
def e2411716508218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.var 0))))
theorem wire_e2411716508218 : Closed e2411716508218 ∧ code e2411716508218 = 11207809530426 := by decide
def e2411716508358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 1)))))
theorem wire_e2411716508358 : Closed e2411716508358 ∧ code e2411716508358 = 11207809530566 := by decide
theorem cert_e2411716508358 : check e2411716508358 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716508442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 0))))
theorem wire_e2411716508442 : Closed e2411716508442 ∧ code e2411716508442 = 11207809530650 := by decide
def e2411716508486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 1)))))
theorem wire_e2411716508486 : Closed e2411716508486 ∧ code e2411716508486 = 11207809530694 := by decide
theorem cert_e2411716508486 : check e2411716508486 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716516986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.var 0))))
theorem wire_e2411716516986 : Closed e2411716516986 ∧ code e2411716516986 = 11207809539194 := by decide
def e2411716517318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 1)))))
theorem wire_e2411716517318 : Closed e2411716517318 ∧ code e2411716517318 = 11207809539526 := by decide
theorem cert_e2411716517318 : check e2411716517318 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716517434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.var 0))))
theorem wire_e2411716517434 : Closed e2411716517434 ∧ code e2411716517434 = 11207809539642 := by decide
def e2411716517574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 1)))))
theorem wire_e2411716517574 : Closed e2411716517574 ∧ code e2411716517574 = 11207809539782 := by decide
theorem cert_e2411716517574 : check e2411716517574 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716529274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.var 0))))
theorem wire_e2411716529274 : Closed e2411716529274 ∧ code e2411716529274 = 11207809551482 := by decide
def e2411716529606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 1)))))
theorem wire_e2411716529606 : Closed e2411716529606 ∧ code e2411716529606 = 11207809551814 := by decide
theorem cert_e2411716529606 : check e2411716529606 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716529946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.var 0))))
theorem wire_e2411716529946 : Closed e2411716529946 ∧ code e2411716529946 = 11207809552154 := by decide
def e2411716529990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 1)))))
theorem wire_e2411716529990 : Closed e2411716529990 ∧ code e2411716529990 = 11207809552198 := by decide
theorem cert_e2411716529990 : check e2411716529990 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716535866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))) (.var 0))))
theorem wire_e2411716535866 : Closed e2411716535866 ∧ code e2411716535866 = 11207809558074 := by decide
def e2411716536006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 1)))))
theorem wire_e2411716536006 : Closed e2411716536006 ∧ code e2411716536006 = 11207809558214 := by decide
theorem cert_e2411716536006 : check e2411716536006 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411716536090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))) (.var 0))))
theorem wire_e2411716536090 : Closed e2411716536090 ∧ code e2411716536090 = 11207809558298 := by decide
def e2411716536134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 1)))))
theorem wire_e2411716536134 : Closed e2411716536134 ∧ code e2411716536134 = 11207809558342 := by decide
theorem cert_e2411716536134 : check e2411716536134 [[],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411717200750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2411717200750 : Closed e2411717200750 ∧ code e2411717200750 = 11207810222958 := by decide
def e2411717200758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2411717200758 : Closed e2411717200758 ∧ code e2411717200758 = 11207810222966 := by decide
theorem cert_e2411717200758 : check e2411717200758 [[],[],[.left],[],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2411717200814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2411717200814 : Closed e2411717200814 ∧ code e2411717200814 = 11207810223022 := by decide
theorem cert_e2411717200814 : check e2411717200814 [[],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411717200826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2411717200826 : Closed e2411717200826 ∧ code e2411717200826 = 11207810223034 := by decide
theorem cert_e2411717200826 : check e2411717200826 [[],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e2411717200854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2411717200854 : Closed e2411717200854 ∧ code e2411717200854 = 11207810223062 := by decide
theorem cert_e2411717200854 : check e2411717200854 [[],[],[.left],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411717200858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2411717200858 : Closed e2411717200858 ∧ code e2411717200858 = 11207810223066 := by decide
def e2411717201134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2411717201134 : Closed e2411717201134 ∧ code e2411717201134 = 11207810223342 := by decide
theorem cert_e2411717201134 : check e2411717201134 [[],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2411717201142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2411717201142 : Closed e2411717201142 ∧ code e2411717201142 = 11207810223350 := by decide
theorem cert_e2411717201142 : check e2411717201142 [[],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2411717201518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2411717201518 : Closed e2411717201518 ∧ code e2411717201518 = 11207810223726 := by decide
theorem cert_e2411717201518 : check e2411717201518 [[],[],[.left],[],[.left],[],[]] .chain = true := by decide
def e2411717201530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2411717201530 : Closed e2411717201530 ∧ code e2411717201530 = 11207810223738 := by decide
theorem cert_e2411717201530 : check e2411717201530 [[],[],[.left],[],[.left],[],[]] .chain = true := by decide
def e2411717201718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2411717201718 : Closed e2411717201718 ∧ code e2411717201718 = 11207810223926 := by decide
theorem cert_e2411717201718 : check e2411717201718 [[],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2411717201722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2411717201722 : Closed e2411717201722 ∧ code e2411717201722 = 11207810223930 := by decide
theorem cert_e2411717201722 : check e2411717201722 [[],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2411718514398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2411718514398 : Closed e2411718514398 ∧ code e2411718514398 = 11207811536606 := by decide
theorem cert_e2411718514398 : check e2411718514398 [[],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2411718514422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2411718514422 : Closed e2411718514422 ∧ code e2411718514422 = 11207811536630 := by decide
theorem cert_e2411718514422 : check e2411718514422 [[],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2411718514526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2411718514526 : Closed e2411718514526 ∧ code e2411718514526 = 11207811536734 := by decide
theorem cert_e2411718514526 : check e2411718514526 [[],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411718514554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2411718514554 : Closed e2411718514554 ∧ code e2411718514554 = 11207811536762 := by decide
theorem cert_e2411718514554 : check e2411718514554 [[],[],[.left],[],[.left],[],[.under,.left]] .chain = true := by decide
def e2411718514646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2411718514646 : Closed e2411718514646 ∧ code e2411718514646 = 11207811536854 := by decide
theorem cert_e2411718514646 : check e2411718514646 [[],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411718514650 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2411718514650 : Closed e2411718514650 ∧ code e2411718514650 = 11207811536858 := by decide
theorem cert_e2411718514650 : check e2411718514650 [[],[],[.left],[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2411718515166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411718515166 : Closed e2411718515166 ∧ code e2411718515166 = 11207811537374 := by decide
theorem cert_e2411718515166 : check e2411718515166 [[],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2411718515190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411718515190 : Closed e2411718515190 ∧ code e2411718515190 = 11207811537398 := by decide
theorem cert_e2411718515190 : check e2411718515190 [[],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2411718515934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411718515934 : Closed e2411718515934 ∧ code e2411718515934 = 11207811538142 := by decide
theorem cert_e2411718515934 : check e2411718515934 [[],[],[.left],[],[.left],[],[.under]] .three = true := by decide
def e2411718515962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411718515962 : Closed e2411718515962 ∧ code e2411718515962 = 11207811538170 := by decide
theorem cert_e2411718515962 : check e2411718515962 [[],[],[.left],[],[.left],[],[.under]] .three = true := by decide
def e2411718516534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411718516534 : Closed e2411718516534 ∧ code e2411718516534 = 11207811538742 := by decide
theorem cert_e2411718516534 : check e2411718516534 [[],[],[.left],[],[.left],[],[.under]] .smaller = true := by decide
def e2411718516538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411718516538 : Closed e2411718516538 ∧ code e2411718516538 = 11207811538746 := by decide
theorem cert_e2411718516538 : check e2411718516538 [[],[],[.left],[],[.left],[],[.under]] .smaller = true := by decide
def e2411718531310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2411718531310 : Closed e2411718531310 ∧ code e2411718531310 = 11207811553518 := by decide
def e2411718531318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2411718531318 : Closed e2411718531318 ∧ code e2411718531318 = 11207811553526 := by decide
theorem cert_e2411718531318 : check e2411718531318 [[],[],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411718531870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2411718531870 : Closed e2411718531870 ∧ code e2411718531870 = 11207811554078 := by decide
theorem cert_e2411718531870 : check e2411718531870 [[],[],[.left],[],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411718531982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2411718531982 : Closed e2411718531982 ∧ code e2411718531982 = 11207811554190 := by decide
theorem cert_e2411718531982 : check e2411718531982 [[],[],[.left],[],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2411718532206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411718532206 : Closed e2411718532206 ∧ code e2411718532206 = 11207811554414 := by decide
theorem cert_e2411718532206 : check e2411718532206 [[],[],[.left],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411718532218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411718532218 : Closed e2411718532218 ∧ code e2411718532218 = 11207811554426 := by decide
theorem cert_e2411718532218 : check e2411718532218 [[],[],[.left],[],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411718532382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411718532382 : Closed e2411718532382 ∧ code e2411718532382 = 11207811554590 := by decide
theorem cert_e2411718532382 : check e2411718532382 [[],[],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2411718532550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411718532550 : Closed e2411718532550 ∧ code e2411718532550 = 11207811554758 := by decide
theorem cert_e2411718532550 : check e2411718532550 [[],[],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[]] .chain = true := by decide
def e2411718532662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411718532662 : Closed e2411718532662 ∧ code e2411718532662 = 11207811554870 := by decide
def e2411718532666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411718532666 : Closed e2411718532666 ∧ code e2411718532666 = 11207811554874 := by decide
def e2411718532750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411718532750 : Closed e2411718532750 ∧ code e2411718532750 = 11207811554958 := by decide
theorem cert_e2411718532750 : check e2411718532750 [[],[],[.left],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411718532806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411718532806 : Closed e2411718532806 ∧ code e2411718532806 = 11207811555014 := by decide
theorem cert_e2411718532806 : check e2411718532806 [[],[],[.left],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e2411718534942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411718534942 : Closed e2411718534942 ∧ code e2411718534942 = 11207811557150 := by decide
theorem cert_e2411718534942 : check e2411718534942 [[],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2411718535054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411718535054 : Closed e2411718535054 ∧ code e2411718535054 = 11207811557262 := by decide
theorem cert_e2411718535054 : check e2411718535054 [[],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2411718538014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411718538014 : Closed e2411718538014 ∧ code e2411718538014 = 11207811560222 := by decide
theorem cert_e2411718538014 : check e2411718538014 [[],[],[.left],[],[.left],[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2411718538182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411718538182 : Closed e2411718538182 ∧ code e2411718538182 = 11207811560390 := by decide
def e2411718539662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411718539662 : Closed e2411718539662 ∧ code e2411718539662 = 11207811561870 := by decide
theorem cert_e2411718539662 : check e2411718539662 [[],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2411718539718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411718539718 : Closed e2411718539718 ∧ code e2411718539718 = 11207811561926 := by decide
theorem cert_e2411718539718 : check e2411718539718 [[],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2411724823486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e2411724823486 : Closed e2411724823486 ∧ code e2411724823486 = 11207817845694 := by decide
theorem cert_e2411724823486 : check e2411724823486 [[],[],[]] .smaller = true := by decide
def e2411724823534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e2411724823534 : Closed e2411724823534 ∧ code e2411724823534 = 11207817845742 := by decide
theorem cert_e2411724823534 : check e2411724823534 [[],[],[]] .smaller = true := by decide
def e2411724824254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e2411724824254 : Closed e2411724824254 ∧ code e2411724824254 = 11207817846462 := by decide
theorem cert_e2411724824254 : check e2411724824254 [[],[],[]] .smaller = true := by decide
def e2411724824314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e2411724824314 : Closed e2411724824314 ∧ code e2411724824314 = 11207817846522 := by decide
theorem cert_e2411724824314 : check e2411724824314 [[],[],[]] .smaller = true := by decide
def e2411724824494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e2411724824494 : Closed e2411724824494 ∧ code e2411724824494 = 11207817846702 := by decide
theorem cert_e2411724824494 : check e2411724824494 [[],[],[]] .smaller = true := by decide
def e2411724824506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e2411724824506 : Closed e2411724824506 ∧ code e2411724824506 = 11207817846714 := by decide
theorem cert_e2411724824506 : check e2411724824506 [[],[],[]] .smaller = true := by decide
end Blc.Floor43
