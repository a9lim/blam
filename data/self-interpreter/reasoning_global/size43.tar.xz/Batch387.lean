import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422365314902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365314902 : Closed e2422365314902 ∧ code e2422365314902 = 11218458337110 := by decide
theorem cert_e2422365314902 : check e2422365314902 [[],[]] .smaller = true := by decide
def e2422365314906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365314906 : Closed e2422365314906 ∧ code e2422365314906 = 11218458337114 := by decide
theorem cert_e2422365314906 : check e2422365314906 [[],[]] .smaller = true := by decide
def e2422365314922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365314922 : Closed e2422365314922 ∧ code e2422365314922 = 11218458337130 := by decide
theorem cert_e2422365314922 : check e2422365314922 [[],[]] .smaller = true := by decide
def e2422365314986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365314986 : Closed e2422365314986 ∧ code e2422365314986 = 11218458337194 := by decide
theorem cert_e2422365314986 : check e2422365314986 [[],[]] .three = true := by decide
def e2422365315310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)))))))))
theorem wire_e2422365315310 : Closed e2422365315310 ∧ code e2422365315310 = 11218458337518 := by decide
theorem cert_e2422365315310 : check e2422365315310 [[],[]] .smaller = true := by decide
def e2422365315322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)))))))))
theorem wire_e2422365315322 : Closed e2422365315322 ∧ code e2422365315322 = 11218458337530 := by decide
theorem cert_e2422365315322 : check e2422365315322 [[],[]] .smaller = true := by decide
def e2422365315502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))))
theorem wire_e2422365315502 : Closed e2422365315502 ∧ code e2422365315502 = 11218458337710 := by decide
theorem cert_e2422365315502 : check e2422365315502 [[],[]] .smaller = true := by decide
def e2422365315694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422365315694 : Closed e2422365315694 ∧ code e2422365315694 = 11218458337902 := by decide
theorem cert_e2422365315694 : check e2422365315694 [[],[]] .smaller = true := by decide
def e2422365315706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422365315706 : Closed e2422365315706 ∧ code e2422365315706 = 11218458337914 := by decide
theorem cert_e2422365315706 : check e2422365315706 [[],[]] .smaller = true := by decide
def e2422365315870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))))))))))
theorem wire_e2422365315870 : Closed e2422365315870 ∧ code e2422365315870 = 11218458338078 := by decide
theorem cert_e2422365315870 : check e2422365315870 [[],[]] .smaller = true := by decide
def e2422365316030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 4)))))))))
theorem wire_e2422365316030 : Closed e2422365316030 ∧ code e2422365316030 = 11218458338238 := by decide
theorem cert_e2422365316030 : check e2422365316030 [[],[]] .three = true := by decide
def e2422365316038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))))))))))
theorem wire_e2422365316038 : Closed e2422365316038 ∧ code e2422365316038 = 11218458338246 := by decide
theorem cert_e2422365316038 : check e2422365316038 [[],[]] .smaller = true := by decide
def e2422365316086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 5))) (.var 1)))))))))
theorem wire_e2422365316086 : Closed e2422365316086 ∧ code e2422365316086 = 11218458338294 := by decide
theorem cert_e2422365316086 : check e2422365316086 [[],[]] .three = true := by decide
def e2422365316654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))))
theorem wire_e2422365316654 : Closed e2422365316654 ∧ code e2422365316654 = 11218458338862 := by decide
theorem cert_e2422365316654 : check e2422365316654 [[],[]] .smaller = true := by decide
def e2422365316798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 4)))))))))
theorem wire_e2422365316798 : Closed e2422365316798 ∧ code e2422365316798 = 11218458339006 := by decide
theorem cert_e2422365316798 : check e2422365316798 [[],[]] .three = true := by decide
def e2422365316830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e2422365316830 : Closed e2422365316830 ∧ code e2422365316830 = 11218458339038 := by decide
theorem cert_e2422365316830 : check e2422365316830 [[],[]] .smaller = true := by decide
def e2422365316834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))))
theorem wire_e2422365316834 : Closed e2422365316834 ∧ code e2422365316834 = 11218458339042 := by decide
theorem cert_e2422365316834 : check e2422365316834 [[],[]] .smaller = true := by decide
def e2422365316846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)))))))))
theorem wire_e2422365316846 : Closed e2422365316846 ∧ code e2422365316846 = 11218458339054 := by decide
theorem cert_e2422365316846 : check e2422365316846 [[],[]] .smaller = true := by decide
def e2422365316854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e2422365316854 : Closed e2422365316854 ∧ code e2422365316854 = 11218458339062 := by decide
theorem cert_e2422365316854 : check e2422365316854 [[],[]] .smaller = true := by decide
def e2422365316858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 0)))))))))
theorem wire_e2422365316858 : Closed e2422365316858 ∧ code e2422365316858 = 11218458339066 := by decide
theorem cert_e2422365316858 : check e2422365316858 [[],[]] .three = true := by decide
def e2422365316958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e2422365316958 : Closed e2422365316958 ∧ code e2422365316958 = 11218458339166 := by decide
theorem cert_e2422365316958 : check e2422365316958 [[],[]] .smaller = true := by decide
def e2422365316974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e2422365316974 : Closed e2422365316974 ∧ code e2422365316974 = 11218458339182 := by decide
theorem cert_e2422365316974 : check e2422365316974 [[],[]] .smaller = true := by decide
def e2422365316982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e2422365316982 : Closed e2422365316982 ∧ code e2422365316982 = 11218458339190 := by decide
theorem cert_e2422365316982 : check e2422365316982 [[],[]] .smaller = true := by decide
def e2422365316986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e2422365316986 : Closed e2422365316986 ∧ code e2422365316986 = 11218458339194 := by decide
theorem cert_e2422365316986 : check e2422365316986 [[],[]] .smaller = true := by decide
def e2422365317002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422365317002 : Closed e2422365317002 ∧ code e2422365317002 = 11218458339210 := by decide
theorem cert_e2422365317002 : check e2422365317002 [[],[]] .smaller = true := by decide
def e2422365317026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))))
theorem wire_e2422365317026 : Closed e2422365317026 ∧ code e2422365317026 = 11218458339234 := by decide
theorem cert_e2422365317026 : check e2422365317026 [[],[]] .smaller = true := by decide
def e2422365317038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)))))))))
theorem wire_e2422365317038 : Closed e2422365317038 ∧ code e2422365317038 = 11218458339246 := by decide
theorem cert_e2422365317038 : check e2422365317038 [[],[]] .smaller = true := by decide
def e2422365317046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e2422365317046 : Closed e2422365317046 ∧ code e2422365317046 = 11218458339254 := by decide
theorem cert_e2422365317046 : check e2422365317046 [[],[]] .smaller = true := by decide
def e2422365317050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)))))))))
theorem wire_e2422365317050 : Closed e2422365317050 ∧ code e2422365317050 = 11218458339258 := by decide
theorem cert_e2422365317050 : check e2422365317050 [[],[]] .smaller = true := by decide
def e2422365317078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e2422365317078 : Closed e2422365317078 ∧ code e2422365317078 = 11218458339286 := by decide
theorem cert_e2422365317078 : check e2422365317078 [[],[]] .smaller = true := by decide
def e2422365317082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e2422365317082 : Closed e2422365317082 ∧ code e2422365317082 = 11218458339290 := by decide
theorem cert_e2422365317082 : check e2422365317082 [[],[]] .smaller = true := by decide
def e2422365317098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 0)))))))))
theorem wire_e2422365317098 : Closed e2422365317098 ∧ code e2422365317098 = 11218458339306 := by decide
theorem cert_e2422365317098 : check e2422365317098 [[],[]] .three = true := by decide
def e2422365317182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422365317182 : Closed e2422365317182 ∧ code e2422365317182 = 11218458339390 := by decide
theorem cert_e2422365317182 : check e2422365317182 [[],[]] .smaller = true := by decide
def e2422365317566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422365317566 : Closed e2422365317566 ∧ code e2422365317566 = 11218458339774 := by decide
theorem cert_e2422365317566 : check e2422365317566 [[],[]] .three = true := by decide
def e2422365317598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422365317598 : Closed e2422365317598 ∧ code e2422365317598 = 11218458339806 := by decide
theorem cert_e2422365317598 : check e2422365317598 [[],[]] .smaller = true := by decide
def e2422365317602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422365317602 : Closed e2422365317602 ∧ code e2422365317602 = 11218458339810 := by decide
theorem cert_e2422365317602 : check e2422365317602 [[],[]] .smaller = true := by decide
def e2422365317614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422365317614 : Closed e2422365317614 ∧ code e2422365317614 = 11218458339822 := by decide
theorem cert_e2422365317614 : check e2422365317614 [[],[]] .smaller = true := by decide
def e2422365317622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422365317622 : Closed e2422365317622 ∧ code e2422365317622 = 11218458339830 := by decide
theorem cert_e2422365317622 : check e2422365317622 [[],[]] .smaller = true := by decide
def e2422365317626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422365317626 : Closed e2422365317626 ∧ code e2422365317626 = 11218458339834 := by decide
theorem cert_e2422365317626 : check e2422365317626 [[],[]] .three = true := by decide
def e2422365318270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 5))))))))))
theorem wire_e2422365318270 : Closed e2422365318270 ∧ code e2422365318270 = 11218458340478 := by decide
theorem cert_e2422365318270 : check e2422365318270 [[],[]] .three = true := by decide
def e2422365318366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422365318366 : Closed e2422365318366 ∧ code e2422365318366 = 11218458340574 := by decide
theorem cert_e2422365318366 : check e2422365318366 [[],[]] .smaller = true := by decide
def e2422365318382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422365318382 : Closed e2422365318382 ∧ code e2422365318382 = 11218458340590 := by decide
theorem cert_e2422365318382 : check e2422365318382 [[],[]] .smaller = true := by decide
def e2422365318390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422365318390 : Closed e2422365318390 ∧ code e2422365318390 = 11218458340598 := by decide
theorem cert_e2422365318390 : check e2422365318390 [[],[]] .smaller = true := by decide
def e2422365318394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422365318394 : Closed e2422365318394 ∧ code e2422365318394 = 11218458340602 := by decide
theorem cert_e2422365318394 : check e2422365318394 [[],[]] .smaller = true := by decide
def e2422365318670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422365318670 : Closed e2422365318670 ∧ code e2422365318670 = 11218458340878 := by decide
theorem cert_e2422365318670 : check e2422365318670 [[],[]] .smaller = true := by decide
def e2422365318682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365318682 : Closed e2422365318682 ∧ code e2422365318682 = 11218458340890 := by decide
theorem cert_e2422365318682 : check e2422365318682 [[],[]] .smaller = true := by decide
def e2422365318754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422365318754 : Closed e2422365318754 ∧ code e2422365318754 = 11218458340962 := by decide
theorem cert_e2422365318754 : check e2422365318754 [[],[]] .smaller = true := by decide
def e2422365318766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422365318766 : Closed e2422365318766 ∧ code e2422365318766 = 11218458340974 := by decide
theorem cert_e2422365318766 : check e2422365318766 [[],[]] .smaller = true := by decide
def e2422365318774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422365318774 : Closed e2422365318774 ∧ code e2422365318774 = 11218458340982 := by decide
theorem cert_e2422365318774 : check e2422365318774 [[],[]] .smaller = true := by decide
def e2422365318778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422365318778 : Closed e2422365318778 ∧ code e2422365318778 = 11218458340986 := by decide
theorem cert_e2422365318778 : check e2422365318778 [[],[]] .smaller = true := by decide
def e2422365318966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365318966 : Closed e2422365318966 ∧ code e2422365318966 = 11218458341174 := by decide
theorem cert_e2422365318966 : check e2422365318966 [[],[]] .smaller = true := by decide
def e2422365318970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365318970 : Closed e2422365318970 ∧ code e2422365318970 = 11218458341178 := by decide
theorem cert_e2422365318970 : check e2422365318970 [[],[]] .smaller = true := by decide
def e2422365319054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.lam (.var 2))))))))))
theorem wire_e2422365319054 : Closed e2422365319054 ∧ code e2422365319054 = 11218458341262 := by decide
theorem cert_e2422365319054 : check e2422365319054 [[],[]] .three = true := by decide
def e2422365319066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365319066 : Closed e2422365319066 ∧ code e2422365319066 = 11218458341274 := by decide
theorem cert_e2422365319066 : check e2422365319066 [[],[]] .three = true := by decide
def e2422365319102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 4)))))))))
theorem wire_e2422365319102 : Closed e2422365319102 ∧ code e2422365319102 = 11218458341310 := by decide
theorem cert_e2422365319102 : check e2422365319102 [[],[]] .three = true := by decide
def e2422365319614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 4)))))))))
theorem wire_e2422365319614 : Closed e2422365319614 ∧ code e2422365319614 = 11218458341822 := by decide
theorem cert_e2422365319614 : check e2422365319614 [[],[]] .three = true := by decide
def e2422365319674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 5))) (.var 0)))))))))
theorem wire_e2422365319674 : Closed e2422365319674 ∧ code e2422365319674 = 11218458341882 := by decide
theorem cert_e2422365319674 : check e2422365319674 [[],[]] .three = true := by decide
def e2422365320030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e2422365320030 : Closed e2422365320030 ∧ code e2422365320030 = 11218458342238 := by decide
theorem cert_e2422365320030 : check e2422365320030 [[],[]] .smaller = true := by decide
def e2422365320046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2422365320046 : Closed e2422365320046 ∧ code e2422365320046 = 11218458342254 := by decide
theorem cert_e2422365320046 : check e2422365320046 [[],[]] .smaller = true := by decide
def e2422365320054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2422365320054 : Closed e2422365320054 ∧ code e2422365320054 = 11218458342262 := by decide
theorem cert_e2422365320054 : check e2422365320054 [[],[]] .smaller = true := by decide
def e2422365320058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e2422365320058 : Closed e2422365320058 ∧ code e2422365320058 = 11218458342266 := by decide
theorem cert_e2422365320058 : check e2422365320058 [[],[]] .smaller = true := by decide
def e2422365320110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2422365320110 : Closed e2422365320110 ∧ code e2422365320110 = 11218458342318 := by decide
theorem cert_e2422365320110 : check e2422365320110 [[],[]] .smaller = true := by decide
def e2422365320122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2422365320122 : Closed e2422365320122 ∧ code e2422365320122 = 11218458342330 := by decide
theorem cert_e2422365320122 : check e2422365320122 [[],[]] .smaller = true := by decide
def e2422365320150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2422365320150 : Closed e2422365320150 ∧ code e2422365320150 = 11218458342358 := by decide
theorem cert_e2422365320150 : check e2422365320150 [[],[]] .smaller = true := by decide
def e2422365320154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2422365320154 : Closed e2422365320154 ∧ code e2422365320154 = 11218458342362 := by decide
theorem cert_e2422365320154 : check e2422365320154 [[],[]] .smaller = true := by decide
def e2422365320170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e2422365320170 : Closed e2422365320170 ∧ code e2422365320170 = 11218458342378 := by decide
theorem cert_e2422365320170 : check e2422365320170 [[],[]] .smaller = true := by decide
def e2422365320318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 5))))))))))
theorem wire_e2422365320318 : Closed e2422365320318 ∧ code e2422365320318 = 11218458342526 := by decide
theorem cert_e2422365320318 : check e2422365320318 [[],[]] .three = true := by decide
def e2422365320414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422365320414 : Closed e2422365320414 ∧ code e2422365320414 = 11218458342622 := by decide
theorem cert_e2422365320414 : check e2422365320414 [[],[]] .smaller = true := by decide
def e2422365320430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422365320430 : Closed e2422365320430 ∧ code e2422365320430 = 11218458342638 := by decide
theorem cert_e2422365320430 : check e2422365320430 [[],[]] .smaller = true := by decide
def e2422365320438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422365320438 : Closed e2422365320438 ∧ code e2422365320438 = 11218458342646 := by decide
theorem cert_e2422365320438 : check e2422365320438 [[],[]] .smaller = true := by decide
def e2422365320442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422365320442 : Closed e2422365320442 ∧ code e2422365320442 = 11218458342650 := by decide
theorem cert_e2422365320442 : check e2422365320442 [[],[]] .smaller = true := by decide
def e2422365320814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422365320814 : Closed e2422365320814 ∧ code e2422365320814 = 11218458343022 := by decide
theorem cert_e2422365320814 : check e2422365320814 [[],[]] .smaller = true := by decide
def e2422365320826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422365320826 : Closed e2422365320826 ∧ code e2422365320826 = 11218458343034 := by decide
theorem cert_e2422365320826 : check e2422365320826 [[],[]] .smaller = true := by decide
def e2422365321014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365321014 : Closed e2422365321014 ∧ code e2422365321014 = 11218458343222 := by decide
theorem cert_e2422365321014 : check e2422365321014 [[],[]] .smaller = true := by decide
def e2422365321018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365321018 : Closed e2422365321018 ∧ code e2422365321018 = 11218458343226 := by decide
theorem cert_e2422365321018 : check e2422365321018 [[],[]] .smaller = true := by decide
def e2422365321114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365321114 : Closed e2422365321114 ∧ code e2422365321114 = 11218458343322 := by decide
theorem cert_e2422365321114 : check e2422365321114 [[],[]] .smaller = true := by decide
def e2422365321150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 4)))))))))
theorem wire_e2422365321150 : Closed e2422365321150 ∧ code e2422365321150 = 11218458343358 := by decide
theorem cert_e2422365321150 : check e2422365321150 [[],[]] .three = true := by decide
def e2422365321158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 4)) (.lam (.var 1))))))))))
theorem wire_e2422365321158 : Closed e2422365321158 ∧ code e2422365321158 = 11218458343366 := by decide
theorem cert_e2422365321158 : check e2422365321158 [[],[]] .three = true := by decide
def e2422365321182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 4)) (.var 3)))))))))
theorem wire_e2422365321182 : Closed e2422365321182 ∧ code e2422365321182 = 11218458343390 := by decide
theorem cert_e2422365321182 : check e2422365321182 [[],[]] .three = true := by decide
def e2422365321274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)))))))))
theorem wire_e2422365321274 : Closed e2422365321274 ∧ code e2422365321274 = 11218458343482 := by decide
theorem cert_e2422365321274 : check e2422365321274 [[],[]] .smaller = true := by decide
def e2422365321322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))))
theorem wire_e2422365321322 : Closed e2422365321322 ∧ code e2422365321322 = 11218458343530 := by decide
theorem cert_e2422365321322 : check e2422365321322 [[],[]] .smaller = true := by decide
def e2422365321370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365321370 : Closed e2422365321370 ∧ code e2422365321370 = 11218458343578 := by decide
theorem cert_e2422365321370 : check e2422365321370 [[],[]] .smaller = true := by decide
def e2422365321414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))))))))))
theorem wire_e2422365321414 : Closed e2422365321414 ∧ code e2422365321414 = 11218458343622 := by decide
theorem cert_e2422365321414 : check e2422365321414 [[],[]] .smaller = true := by decide
def e2422365321610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422365321610 : Closed e2422365321610 ∧ code e2422365321610 = 11218458343818 := by decide
theorem cert_e2422365321610 : check e2422365321610 [[],[]] .smaller = true := by decide
def e2422365321634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))))
theorem wire_e2422365321634 : Closed e2422365321634 ∧ code e2422365321634 = 11218458343842 := by decide
theorem cert_e2422365321634 : check e2422365321634 [[],[]] .smaller = true := by decide
def e2422365321646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422365321646 : Closed e2422365321646 ∧ code e2422365321646 = 11218458343854 := by decide
theorem cert_e2422365321646 : check e2422365321646 [[],[]] .smaller = true := by decide
def e2422365321654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e2422365321654 : Closed e2422365321654 ∧ code e2422365321654 = 11218458343862 := by decide
theorem cert_e2422365321654 : check e2422365321654 [[],[]] .smaller = true := by decide
def e2422365321658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422365321658 : Closed e2422365321658 ∧ code e2422365321658 = 11218458343866 := by decide
theorem cert_e2422365321658 : check e2422365321658 [[],[]] .smaller = true := by decide
def e2422365321686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e2422365321686 : Closed e2422365321686 ∧ code e2422365321686 = 11218458343894 := by decide
theorem cert_e2422365321686 : check e2422365321686 [[],[]] .smaller = true := by decide
def e2422365321690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e2422365321690 : Closed e2422365321690 ∧ code e2422365321690 = 11218458343898 := by decide
theorem cert_e2422365321690 : check e2422365321690 [[],[]] .smaller = true := by decide
def e2422365321706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422365321706 : Closed e2422365321706 ∧ code e2422365321706 = 11218458343914 := by decide
theorem cert_e2422365321706 : check e2422365321706 [[],[]] .smaller = true := by decide
def e2422365321742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422365321742 : Closed e2422365321742 ∧ code e2422365321742 = 11218458343950 := by decide
theorem cert_e2422365321742 : check e2422365321742 [[],[]] .smaller = true := by decide
def e2422365321754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365321754 : Closed e2422365321754 ∧ code e2422365321754 = 11218458343962 := by decide
theorem cert_e2422365321754 : check e2422365321754 [[],[]] .smaller = true := by decide
def e2422365321826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422365321826 : Closed e2422365321826 ∧ code e2422365321826 = 11218458344034 := by decide
theorem cert_e2422365321826 : check e2422365321826 [[],[]] .smaller = true := by decide
def e2422365321838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422365321838 : Closed e2422365321838 ∧ code e2422365321838 = 11218458344046 := by decide
theorem cert_e2422365321838 : check e2422365321838 [[],[]] .smaller = true := by decide
def e2422365321846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422365321846 : Closed e2422365321846 ∧ code e2422365321846 = 11218458344054 := by decide
theorem cert_e2422365321846 : check e2422365321846 [[],[]] .smaller = true := by decide
def e2422365321850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422365321850 : Closed e2422365321850 ∧ code e2422365321850 = 11218458344058 := by decide
theorem cert_e2422365321850 : check e2422365321850 [[],[]] .smaller = true := by decide
def e2422365322038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365322038 : Closed e2422365322038 ∧ code e2422365322038 = 11218458344246 := by decide
theorem cert_e2422365322038 : check e2422365322038 [[],[]] .smaller = true := by decide
def e2422365322042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365322042 : Closed e2422365322042 ∧ code e2422365322042 = 11218458344250 := by decide
theorem cert_e2422365322042 : check e2422365322042 [[],[]] .smaller = true := by decide
def e2422365322138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365322138 : Closed e2422365322138 ∧ code e2422365322138 = 11218458344346 := by decide
theorem cert_e2422365322138 : check e2422365322138 [[],[]] .smaller = true := by decide
def e2422365322174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 4)))))))))
theorem wire_e2422365322174 : Closed e2422365322174 ∧ code e2422365322174 = 11218458344382 := by decide
theorem cert_e2422365322174 : check e2422365322174 [[],[]] .three = true := by decide
def e2422365322206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 3)))))))))
theorem wire_e2422365322206 : Closed e2422365322206 ∧ code e2422365322206 = 11218458344414 := by decide
theorem cert_e2422365322206 : check e2422365322206 [[],[]] .smaller = true := by decide
def e2422365322222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 4)) (.var 2)))))))))
theorem wire_e2422365322222 : Closed e2422365322222 ∧ code e2422365322222 = 11218458344430 := by decide
theorem cert_e2422365322222 : check e2422365322222 [[],[]] .three = true := by decide
def e2422365322454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422365322454 : Closed e2422365322454 ∧ code e2422365322454 = 11218458344662 := by decide
theorem cert_e2422365322454 : check e2422365322454 [[],[]] .smaller = true := by decide
def e2422365322458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422365322458 : Closed e2422365322458 ∧ code e2422365322458 = 11218458344666 := by decide
theorem cert_e2422365322458 : check e2422365322458 [[],[]] .smaller = true := by decide
def e2422365322474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422365322474 : Closed e2422365322474 ∧ code e2422365322474 = 11218458344682 := by decide
theorem cert_e2422365322474 : check e2422365322474 [[],[]] .smaller = true := by decide
def e2422365322550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365322550 : Closed e2422365322550 ∧ code e2422365322550 = 11218458344758 := by decide
theorem cert_e2422365322550 : check e2422365322550 [[],[]] .smaller = true := by decide
def e2422365322554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365322554 : Closed e2422365322554 ∧ code e2422365322554 = 11218458344762 := by decide
theorem cert_e2422365322554 : check e2422365322554 [[],[]] .smaller = true := by decide
def e2422365322650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365322650 : Closed e2422365322650 ∧ code e2422365322650 = 11218458344858 := by decide
theorem cert_e2422365322650 : check e2422365322650 [[],[]] .smaller = true := by decide
def e2422365322686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 4)))))))))
theorem wire_e2422365322686 : Closed e2422365322686 ∧ code e2422365322686 = 11218458344894 := by decide
theorem cert_e2422365322686 : check e2422365322686 [[],[]] .three = true := by decide
def e2422365322718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 3)))))))))
theorem wire_e2422365322718 : Closed e2422365322718 ∧ code e2422365322718 = 11218458344926 := by decide
theorem cert_e2422365322718 : check e2422365322718 [[],[]] .smaller = true := by decide
def e2422365322734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 2)))))))))
theorem wire_e2422365322734 : Closed e2422365322734 ∧ code e2422365322734 = 11218458344942 := by decide
theorem cert_e2422365322734 : check e2422365322734 [[],[]] .smaller = true := by decide
def e2422365322742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 4)) (.var 1)))))))))
theorem wire_e2422365322742 : Closed e2422365322742 ∧ code e2422365322742 = 11218458344950 := by decide
theorem cert_e2422365322742 : check e2422365322742 [[],[]] .three = true := by decide
def e2422365322806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422365322806 : Closed e2422365322806 ∧ code e2422365322806 = 11218458345014 := by decide
theorem cert_e2422365322806 : check e2422365322806 [[],[]] .three = true := by decide
def e2422365322810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422365322810 : Closed e2422365322810 ∧ code e2422365322810 = 11218458345018 := by decide
theorem cert_e2422365322810 : check e2422365322810 [[],[]] .three = true := by decide
def e2422365322858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422365322858 : Closed e2422365322858 ∧ code e2422365322858 = 11218458345066 := by decide
theorem cert_e2422365322858 : check e2422365322858 [[],[]] .three = true := by decide
def e2422365322894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422365322894 : Closed e2422365322894 ∧ code e2422365322894 = 11218458345102 := by decide
theorem cert_e2422365322894 : check e2422365322894 [[],[]] .three = true := by decide
def e2422365322906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365322906 : Closed e2422365322906 ∧ code e2422365322906 = 11218458345114 := by decide
theorem cert_e2422365322906 : check e2422365322906 [[],[]] .three = true := by decide
def e2422365322942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 4)))))))))
theorem wire_e2422365322942 : Closed e2422365322942 ∧ code e2422365322942 = 11218458345150 := by decide
theorem cert_e2422365322942 : check e2422365322942 [[],[]] .three = true := by decide
def e2422365322950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422365322950 : Closed e2422365322950 ∧ code e2422365322950 = 11218458345158 := by decide
theorem cert_e2422365322950 : check e2422365322950 [[],[]] .three = true := by decide
def e2422365322974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 1)) (.var 3)))))))))
theorem wire_e2422365322974 : Closed e2422365322974 ∧ code e2422365322974 = 11218458345182 := by decide
theorem cert_e2422365322974 : check e2422365322974 [[],[]] .three = true := by decide
def e2422365322990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 2)) (.var 2)))))))))
theorem wire_e2422365322990 : Closed e2422365322990 ∧ code e2422365322990 = 11218458345198 := by decide
theorem cert_e2422365322990 : check e2422365322990 [[],[]] .three = true := by decide
def e2422365322998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 3)) (.var 1)))))))))
theorem wire_e2422365322998 : Closed e2422365322998 ∧ code e2422365322998 = 11218458345206 := by decide
theorem cert_e2422365322998 : check e2422365322998 [[],[]] .three = true := by decide
def e2422365323002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 4)) (.var 0)))))))))
theorem wire_e2422365323002 : Closed e2422365323002 ∧ code e2422365323002 = 11218458345210 := by decide
theorem cert_e2422365323002 : check e2422365323002 [[],[]] .three = true := by decide
def e2422365325182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 5)))))))))))
theorem wire_e2422365325182 : Closed e2422365325182 ∧ code e2422365325182 = 11218458347390 := by decide
theorem cert_e2422365325182 : check e2422365325182 [[],[]] .three = true := by decide
def e2422365325246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 4)))))))))))
theorem wire_e2422365325246 : Closed e2422365325246 ∧ code e2422365325246 = 11218458347454 := by decide
theorem cert_e2422365325246 : check e2422365325246 [[],[]] .smaller = true := by decide
def e2422365325278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 3)))))))))))
theorem wire_e2422365325278 : Closed e2422365325278 ∧ code e2422365325278 = 11218458347486 := by decide
theorem cert_e2422365325278 : check e2422365325278 [[],[]] .smaller = true := by decide
def e2422365325294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.var 2)))))))))))
theorem wire_e2422365325294 : Closed e2422365325294 ∧ code e2422365325294 = 11218458347502 := by decide
theorem cert_e2422365325294 : check e2422365325294 [[],[]] .smaller = true := by decide
def e2422365325302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 5) (.var 1)))))))))))
theorem wire_e2422365325302 : Closed e2422365325302 ∧ code e2422365325302 = 11218458347510 := by decide
theorem cert_e2422365325302 : check e2422365325302 [[],[]] .three = true := by decide
def e2422365328942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))))
theorem wire_e2422365328942 : Closed e2422365328942 ∧ code e2422365328942 = 11218458351150 := by decide
theorem cert_e2422365328942 : check e2422365328942 [[],[]] .smaller = true := by decide
def e2422365329086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 4))))))))))
theorem wire_e2422365329086 : Closed e2422365329086 ∧ code e2422365329086 = 11218458351294 := by decide
theorem cert_e2422365329086 : check e2422365329086 [[],[]] .three = true := by decide
def e2422365329118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2422365329118 : Closed e2422365329118 ∧ code e2422365329118 = 11218458351326 := by decide
theorem cert_e2422365329118 : check e2422365329118 [[],[]] .smaller = true := by decide
def e2422365329122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))))
theorem wire_e2422365329122 : Closed e2422365329122 ∧ code e2422365329122 = 11218458351330 := by decide
theorem cert_e2422365329122 : check e2422365329122 [[],[]] .smaller = true := by decide
def e2422365329134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))))))))))
theorem wire_e2422365329134 : Closed e2422365329134 ∧ code e2422365329134 = 11218458351342 := by decide
theorem cert_e2422365329134 : check e2422365329134 [[],[]] .smaller = true := by decide
def e2422365329142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2422365329142 : Closed e2422365329142 ∧ code e2422365329142 = 11218458351350 := by decide
theorem cert_e2422365329142 : check e2422365329142 [[],[]] .smaller = true := by decide
def e2422365329146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 0))))))))))
theorem wire_e2422365329146 : Closed e2422365329146 ∧ code e2422365329146 = 11218458351354 := by decide
theorem cert_e2422365329146 : check e2422365329146 [[],[]] .three = true := by decide
def e2422365329246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2422365329246 : Closed e2422365329246 ∧ code e2422365329246 = 11218458351454 := by decide
theorem cert_e2422365329246 : check e2422365329246 [[],[]] .smaller = true := by decide
def e2422365329262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e2422365329262 : Closed e2422365329262 ∧ code e2422365329262 = 11218458351470 := by decide
theorem cert_e2422365329262 : check e2422365329262 [[],[]] .smaller = true := by decide
def e2422365329270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e2422365329270 : Closed e2422365329270 ∧ code e2422365329270 = 11218458351478 := by decide
theorem cert_e2422365329270 : check e2422365329270 [[],[]] .smaller = true := by decide
def e2422365329274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2422365329274 : Closed e2422365329274 ∧ code e2422365329274 = 11218458351482 := by decide
theorem cert_e2422365329274 : check e2422365329274 [[],[]] .smaller = true := by decide
def e2422365329290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))))
theorem wire_e2422365329290 : Closed e2422365329290 ∧ code e2422365329290 = 11218458351498 := by decide
theorem cert_e2422365329290 : check e2422365329290 [[],[]] .smaller = true := by decide
def e2422365329314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))))
theorem wire_e2422365329314 : Closed e2422365329314 ∧ code e2422365329314 = 11218458351522 := by decide
theorem cert_e2422365329314 : check e2422365329314 [[],[]] .smaller = true := by decide
def e2422365329326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))))))))))
theorem wire_e2422365329326 : Closed e2422365329326 ∧ code e2422365329326 = 11218458351534 := by decide
theorem cert_e2422365329326 : check e2422365329326 [[],[]] .smaller = true := by decide
def e2422365329334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e2422365329334 : Closed e2422365329334 ∧ code e2422365329334 = 11218458351542 := by decide
theorem cert_e2422365329334 : check e2422365329334 [[],[]] .smaller = true := by decide
def e2422365329338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))))))))))
theorem wire_e2422365329338 : Closed e2422365329338 ∧ code e2422365329338 = 11218458351546 := by decide
theorem cert_e2422365329338 : check e2422365329338 [[],[]] .smaller = true := by decide
def e2422365329366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2422365329366 : Closed e2422365329366 ∧ code e2422365329366 = 11218458351574 := by decide
theorem cert_e2422365329366 : check e2422365329366 [[],[]] .smaller = true := by decide
def e2422365329370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2422365329370 : Closed e2422365329370 ∧ code e2422365329370 = 11218458351578 := by decide
theorem cert_e2422365329370 : check e2422365329370 [[],[]] .smaller = true := by decide
def e2422365329386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 0))))))))))
theorem wire_e2422365329386 : Closed e2422365329386 ∧ code e2422365329386 = 11218458351594 := by decide
theorem cert_e2422365329386 : check e2422365329386 [[],[]] .three = true := by decide
def e2422365329470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))))))))))
theorem wire_e2422365329470 : Closed e2422365329470 ∧ code e2422365329470 = 11218458351678 := by decide
theorem cert_e2422365329470 : check e2422365329470 [[],[]] .smaller = true := by decide
def e2422365329854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422365329854 : Closed e2422365329854 ∧ code e2422365329854 = 11218458352062 := by decide
theorem cert_e2422365329854 : check e2422365329854 [[],[]] .three = true := by decide
def e2422365329886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422365329886 : Closed e2422365329886 ∧ code e2422365329886 = 11218458352094 := by decide
theorem cert_e2422365329886 : check e2422365329886 [[],[]] .smaller = true := by decide
def e2422365329890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))))
theorem wire_e2422365329890 : Closed e2422365329890 ∧ code e2422365329890 = 11218458352098 := by decide
theorem cert_e2422365329890 : check e2422365329890 [[],[]] .smaller = true := by decide
def e2422365329902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422365329902 : Closed e2422365329902 ∧ code e2422365329902 = 11218458352110 := by decide
theorem cert_e2422365329902 : check e2422365329902 [[],[]] .smaller = true := by decide
def e2422365329910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422365329910 : Closed e2422365329910 ∧ code e2422365329910 = 11218458352118 := by decide
theorem cert_e2422365329910 : check e2422365329910 [[],[]] .smaller = true := by decide
def e2422365329914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422365329914 : Closed e2422365329914 ∧ code e2422365329914 = 11218458352122 := by decide
theorem cert_e2422365329914 : check e2422365329914 [[],[]] .three = true := by decide
def e2422365330558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 5)))))))))))
theorem wire_e2422365330558 : Closed e2422365330558 ∧ code e2422365330558 = 11218458352766 := by decide
theorem cert_e2422365330558 : check e2422365330558 [[],[]] .three = true := by decide
def e2422365330654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422365330654 : Closed e2422365330654 ∧ code e2422365330654 = 11218458352862 := by decide
theorem cert_e2422365330654 : check e2422365330654 [[],[]] .smaller = true := by decide
def e2422365330670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365330670 : Closed e2422365330670 ∧ code e2422365330670 = 11218458352878 := by decide
theorem cert_e2422365330670 : check e2422365330670 [[],[]] .smaller = true := by decide
def e2422365330678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365330678 : Closed e2422365330678 ∧ code e2422365330678 = 11218458352886 := by decide
theorem cert_e2422365330678 : check e2422365330678 [[],[]] .smaller = true := by decide
def e2422365330682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422365330682 : Closed e2422365330682 ∧ code e2422365330682 = 11218458352890 := by decide
theorem cert_e2422365330682 : check e2422365330682 [[],[]] .smaller = true := by decide
end Blc.Floor43
