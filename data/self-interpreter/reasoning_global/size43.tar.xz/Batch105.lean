import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e862483168490 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e862483168490 : Closed e862483168490 ∧ code e862483168490 = 9658576190698 := by decide
theorem cert_e862483168490 : check e862483168490 [] .sourceHead = true := by decide
def e862483168566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862483168566 : Closed e862483168566 ∧ code e862483168566 = 9658576190774 := by decide
theorem cert_e862483168566 : check e862483168566 [] .sourceHead = true := by decide
def e862483168570 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862483168570 : Closed e862483168570 ∧ code e862483168570 = 9658576190778 := by decide
theorem cert_e862483168570 : check e862483168570 [] .sourceHead = true := by decide
def e862483168666 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862483168666 : Closed e862483168666 ∧ code e862483168666 = 9658576190874 := by decide
theorem cert_e862483168666 : check e862483168666 [] .sourceHead = true := by decide
def e862483172206 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e862483172206 : Closed e862483172206 ∧ code e862483172206 = 9658576194414 := by decide
theorem cert_e862483172206 : check e862483172206 [] .sourceHead = true := by decide
def e862483172214 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e862483172214 : Closed e862483172214 ∧ code e862483172214 = 9658576194422 := by decide
theorem cert_e862483172214 : check e862483172214 [] .sourceHead = true := by decide
def e862483172270 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e862483172270 : Closed e862483172270 ∧ code e862483172270 = 9658576194478 := by decide
theorem cert_e862483172270 : check e862483172270 [] .sourceHead = true := by decide
def e862483172282 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e862483172282 : Closed e862483172282 ∧ code e862483172282 = 9658576194490 := by decide
theorem cert_e862483172282 : check e862483172282 [] .sourceHead = true := by decide
def e862483172310 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e862483172310 : Closed e862483172310 ∧ code e862483172310 = 9658576194518 := by decide
theorem cert_e862483172310 : check e862483172310 [] .sourceHead = true := by decide
def e862483172314 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e862483172314 : Closed e862483172314 ∧ code e862483172314 = 9658576194522 := by decide
theorem cert_e862483172314 : check e862483172314 [] .sourceHead = true := by decide
def e862483172590 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e862483172590 : Closed e862483172590 ∧ code e862483172590 = 9658576194798 := by decide
theorem cert_e862483172590 : check e862483172590 [] .sourceHead = true := by decide
def e862483172598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e862483172598 : Closed e862483172598 ∧ code e862483172598 = 9658576194806 := by decide
theorem cert_e862483172598 : check e862483172598 [] .sourceHead = true := by decide
def e862483172974 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e862483172974 : Closed e862483172974 ∧ code e862483172974 = 9658576195182 := by decide
theorem cert_e862483172974 : check e862483172974 [] .sourceHead = true := by decide
def e862483172986 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e862483172986 : Closed e862483172986 ∧ code e862483172986 = 9658576195194 := by decide
theorem cert_e862483172986 : check e862483172986 [] .sourceHead = true := by decide
def e862483173174 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e862483173174 : Closed e862483173174 ∧ code e862483173174 = 9658576195382 := by decide
theorem cert_e862483173174 : check e862483173174 [] .sourceHead = true := by decide
def e862483173178 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e862483173178 : Closed e862483173178 ∧ code e862483173178 = 9658576195386 := by decide
theorem cert_e862483173178 : check e862483173178 [] .sourceHead = true := by decide
def e862483178926 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e862483178926 : Closed e862483178926 ∧ code e862483178926 = 9658576201134 := by decide
theorem cert_e862483178926 : check e862483178926 [] .sourceHead = true := by decide
def e862483178938 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e862483178938 : Closed e862483178938 ∧ code e862483178938 = 9658576201146 := by decide
theorem cert_e862483178938 : check e862483178938 [] .sourceHead = true := by decide
def e862483178986 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e862483178986 : Closed e862483178986 ∧ code e862483178986 = 9658576201194 := by decide
theorem cert_e862483178986 : check e862483178986 [] .sourceHead = true := by decide
def e862483179118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e862483179118 : Closed e862483179118 ∧ code e862483179118 = 9658576201326 := by decide
theorem cert_e862483179118 : check e862483179118 [] .sourceHead = true := by decide
def e862483179130 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e862483179130 : Closed e862483179130 ∧ code e862483179130 = 9658576201338 := by decide
theorem cert_e862483179130 : check e862483179130 [] .sourceHead = true := by decide
def e862483179418 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e862483179418 : Closed e862483179418 ∧ code e862483179418 = 9658576201626 := by decide
theorem cert_e862483179418 : check e862483179418 [] .sourceHead = true := by decide
def e862483182294 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e862483182294 : Closed e862483182294 ∧ code e862483182294 = 9658576204502 := by decide
theorem cert_e862483182294 : check e862483182294 [] .sourceHead = true := by decide
def e862483182298 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e862483182298 : Closed e862483182298 ∧ code e862483182298 = 9658576204506 := by decide
theorem cert_e862483182298 : check e862483182298 [] .sourceHead = true := by decide
def e862483182314 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e862483182314 : Closed e862483182314 ∧ code e862483182314 = 9658576204522 := by decide
theorem cert_e862483182314 : check e862483182314 [] .sourceHead = true := by decide
def e862483182390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e862483182390 : Closed e862483182390 ∧ code e862483182390 = 9658576204598 := by decide
theorem cert_e862483182390 : check e862483182390 [] .sourceHead = true := by decide
def e862483182394 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e862483182394 : Closed e862483182394 ∧ code e862483182394 = 9658576204602 := by decide
theorem cert_e862483182394 : check e862483182394 [] .sourceHead = true := by decide
def e862483182490 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e862483182490 : Closed e862483182490 ∧ code e862483182490 = 9658576204698 := by decide
theorem cert_e862483182490 : check e862483182490 [] .sourceHead = true := by decide
def e862483297758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))))
theorem wire_e862483297758 : Closed e862483297758 ∧ code e862483297758 = 9658576319966 := by decide
theorem cert_e862483297758 : check e862483297758 [] .sourceHead = true := by decide
def e862483297774 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))))
theorem wire_e862483297774 : Closed e862483297774 ∧ code e862483297774 = 9658576319982 := by decide
theorem cert_e862483297774 : check e862483297774 [] .sourceHead = true := by decide
def e862483298014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))))
theorem wire_e862483298014 : Closed e862483298014 ∧ code e862483298014 = 9658576320222 := by decide
theorem cert_e862483298014 : check e862483298014 [] .sourceHead = true := by decide
def e862483298030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))))
theorem wire_e862483298030 : Closed e862483298030 ∧ code e862483298030 = 9658576320238 := by decide
theorem cert_e862483298030 : check e862483298030 [] .sourceHead = true := by decide
def e862483298038 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))))
theorem wire_e862483298038 : Closed e862483298038 ∧ code e862483298038 = 9658576320246 := by decide
theorem cert_e862483298038 : check e862483298038 [] .sourceHead = true := by decide
def e862483298142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))))
theorem wire_e862483298142 : Closed e862483298142 ∧ code e862483298142 = 9658576320350 := by decide
theorem cert_e862483298142 : check e862483298142 [] .sourceHead = true := by decide
def e862483298158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))))
theorem wire_e862483298158 : Closed e862483298158 ∧ code e862483298158 = 9658576320366 := by decide
theorem cert_e862483298158 : check e862483298158 [] .sourceHead = true := by decide
def e862483298166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))))
theorem wire_e862483298166 : Closed e862483298166 ∧ code e862483298166 = 9658576320374 := by decide
theorem cert_e862483298166 : check e862483298166 [] .sourceHead = true := by decide
def e862483298170 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))))
theorem wire_e862483298170 : Closed e862483298170 ∧ code e862483298170 = 9658576320378 := by decide
theorem cert_e862483298170 : check e862483298170 [] .sourceHead = true := by decide
def e862483298222 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))))
theorem wire_e862483298222 : Closed e862483298222 ∧ code e862483298222 = 9658576320430 := by decide
theorem cert_e862483298222 : check e862483298222 [] .sourceHead = true := by decide
def e862483298230 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))))
theorem wire_e862483298230 : Closed e862483298230 ∧ code e862483298230 = 9658576320438 := by decide
theorem cert_e862483298230 : check e862483298230 [] .sourceHead = true := by decide
def e862483298234 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))))
theorem wire_e862483298234 : Closed e862483298234 ∧ code e862483298234 = 9658576320442 := by decide
theorem cert_e862483298234 : check e862483298234 [] .sourceHead = true := by decide
def e862483299038 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e862483299038 : Closed e862483299038 ∧ code e862483299038 = 9658576321246 := by decide
theorem cert_e862483299038 : check e862483299038 [] .sourceHead = true := by decide
def e862483299054 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))))
theorem wire_e862483299054 : Closed e862483299054 ∧ code e862483299054 = 9658576321262 := by decide
theorem cert_e862483299054 : check e862483299054 [] .sourceHead = true := by decide
def e862483299062 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e862483299062 : Closed e862483299062 ∧ code e862483299062 = 9658576321270 := by decide
theorem cert_e862483299062 : check e862483299062 [] .sourceHead = true := by decide
def e862483299166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e862483299166 : Closed e862483299166 ∧ code e862483299166 = 9658576321374 := by decide
theorem cert_e862483299166 : check e862483299166 [] .sourceHead = true := by decide
def e862483299194 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e862483299194 : Closed e862483299194 ∧ code e862483299194 = 9658576321402 := by decide
theorem cert_e862483299194 : check e862483299194 [] .sourceHead = true := by decide
def e862483299246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))))
theorem wire_e862483299246 : Closed e862483299246 ∧ code e862483299246 = 9658576321454 := by decide
theorem cert_e862483299246 : check e862483299246 [] .sourceHead = true := by decide
def e862483299258 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))))
theorem wire_e862483299258 : Closed e862483299258 ∧ code e862483299258 = 9658576321466 := by decide
theorem cert_e862483299258 : check e862483299258 [] .sourceHead = true := by decide
def e862483299286 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e862483299286 : Closed e862483299286 ∧ code e862483299286 = 9658576321494 := by decide
theorem cert_e862483299286 : check e862483299286 [] .sourceHead = true := by decide
def e862483299290 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e862483299290 : Closed e862483299290 ∧ code e862483299290 = 9658576321498 := by decide
theorem cert_e862483299290 : check e862483299290 [] .sourceHead = true := by decide
def e862483299678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e862483299678 : Closed e862483299678 ∧ code e862483299678 = 9658576321886 := by decide
theorem cert_e862483299678 : check e862483299678 [] .sourceHead = true := by decide
def e862483299694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e862483299694 : Closed e862483299694 ∧ code e862483299694 = 9658576321902 := by decide
theorem cert_e862483299694 : check e862483299694 [] .sourceHead = true := by decide
def e862483299702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e862483299702 : Closed e862483299702 ∧ code e862483299702 = 9658576321910 := by decide
theorem cert_e862483299702 : check e862483299702 [] .sourceHead = true := by decide
def e862483299706 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e862483299706 : Closed e862483299706 ∧ code e862483299706 = 9658576321914 := by decide
theorem cert_e862483299706 : check e862483299706 [] .sourceHead = true := by decide
def e862483299758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e862483299758 : Closed e862483299758 ∧ code e862483299758 = 9658576321966 := by decide
theorem cert_e862483299758 : check e862483299758 [] .sourceHead = true := by decide
def e862483299770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e862483299770 : Closed e862483299770 ∧ code e862483299770 = 9658576321978 := by decide
theorem cert_e862483299770 : check e862483299770 [] .sourceHead = true := by decide
def e862483299798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e862483299798 : Closed e862483299798 ∧ code e862483299798 = 9658576322006 := by decide
theorem cert_e862483299798 : check e862483299798 [] .sourceHead = true := by decide
def e862483299802 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e862483299802 : Closed e862483299802 ∧ code e862483299802 = 9658576322010 := by decide
theorem cert_e862483299802 : check e862483299802 [] .sourceHead = true := by decide
def e862483299818 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e862483299818 : Closed e862483299818 ∧ code e862483299818 = 9658576322026 := by decide
theorem cert_e862483299818 : check e862483299818 [] .sourceHead = true := by decide
def e862483300014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e862483300014 : Closed e862483300014 ∧ code e862483300014 = 9658576322222 := by decide
theorem cert_e862483300014 : check e862483300014 [] .sourceHead = true := by decide
def e862483300022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e862483300022 : Closed e862483300022 ∧ code e862483300022 = 9658576322230 := by decide
theorem cert_e862483300022 : check e862483300022 [] .sourceHead = true := by decide
def e862483300026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e862483300026 : Closed e862483300026 ∧ code e862483300026 = 9658576322234 := by decide
theorem cert_e862483300026 : check e862483300026 [] .sourceHead = true := by decide
def e862483300054 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e862483300054 : Closed e862483300054 ∧ code e862483300054 = 9658576322262 := by decide
theorem cert_e862483300054 : check e862483300054 [] .sourceHead = true := by decide
def e862483300058 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e862483300058 : Closed e862483300058 ∧ code e862483300058 = 9658576322266 := by decide
theorem cert_e862483300058 : check e862483300058 [] .sourceHead = true := by decide
def e862483300074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e862483300074 : Closed e862483300074 ∧ code e862483300074 = 9658576322282 := by decide
theorem cert_e862483300074 : check e862483300074 [] .sourceHead = true := by decide
def e862483303902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))))
theorem wire_e862483303902 : Closed e862483303902 ∧ code e862483303902 = 9658576326110 := by decide
theorem cert_e862483303902 : check e862483303902 [] .sourceHead = true := by decide
def e862483303918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))))
theorem wire_e862483303918 : Closed e862483303918 ∧ code e862483303918 = 9658576326126 := by decide
theorem cert_e862483303918 : check e862483303918 [] .sourceHead = true := by decide
def e862483304158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))))
theorem wire_e862483304158 : Closed e862483304158 ∧ code e862483304158 = 9658576326366 := by decide
theorem cert_e862483304158 : check e862483304158 [] .sourceHead = true := by decide
def e862483304174 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))))
theorem wire_e862483304174 : Closed e862483304174 ∧ code e862483304174 = 9658576326382 := by decide
theorem cert_e862483304174 : check e862483304174 [] .sourceHead = true := by decide
def e862483304182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))))
theorem wire_e862483304182 : Closed e862483304182 ∧ code e862483304182 = 9658576326390 := by decide
theorem cert_e862483304182 : check e862483304182 [] .sourceHead = true := by decide
def e862483304286 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))))
theorem wire_e862483304286 : Closed e862483304286 ∧ code e862483304286 = 9658576326494 := by decide
theorem cert_e862483304286 : check e862483304286 [] .sourceHead = true := by decide
def e862483304302 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))))
theorem wire_e862483304302 : Closed e862483304302 ∧ code e862483304302 = 9658576326510 := by decide
theorem cert_e862483304302 : check e862483304302 [] .sourceHead = true := by decide
def e862483304310 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))))
theorem wire_e862483304310 : Closed e862483304310 ∧ code e862483304310 = 9658576326518 := by decide
theorem cert_e862483304310 : check e862483304310 [] .sourceHead = true := by decide
def e862483304314 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))))
theorem wire_e862483304314 : Closed e862483304314 ∧ code e862483304314 = 9658576326522 := by decide
theorem cert_e862483304314 : check e862483304314 [] .sourceHead = true := by decide
def e862483304366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))))
theorem wire_e862483304366 : Closed e862483304366 ∧ code e862483304366 = 9658576326574 := by decide
theorem cert_e862483304366 : check e862483304366 [] .sourceHead = true := by decide
def e862483304374 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))))
theorem wire_e862483304374 : Closed e862483304374 ∧ code e862483304374 = 9658576326582 := by decide
theorem cert_e862483304374 : check e862483304374 [] .sourceHead = true := by decide
def e862483304378 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))))
theorem wire_e862483304378 : Closed e862483304378 ∧ code e862483304378 = 9658576326586 := by decide
theorem cert_e862483304378 : check e862483304378 [] .sourceHead = true := by decide
def e862483305438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))))
theorem wire_e862483305438 : Closed e862483305438 ∧ code e862483305438 = 9658576327646 := by decide
theorem cert_e862483305438 : check e862483305438 [] .sourceHead = true := by decide
def e862483305454 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))))
theorem wire_e862483305454 : Closed e862483305454 ∧ code e862483305454 = 9658576327662 := by decide
theorem cert_e862483305454 : check e862483305454 [] .sourceHead = true := by decide
def e862483306974 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))))
theorem wire_e862483306974 : Closed e862483306974 ∧ code e862483306974 = 9658576329182 := by decide
theorem cert_e862483306974 : check e862483306974 [] .sourceHead = true := by decide
def e862483306990 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))))
theorem wire_e862483306990 : Closed e862483306990 ∧ code e862483306990 = 9658576329198 := by decide
theorem cert_e862483306990 : check e862483306990 [] .sourceHead = true := by decide
def e862483306998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))))
theorem wire_e862483306998 : Closed e862483306998 ∧ code e862483306998 = 9658576329206 := by decide
theorem cert_e862483306998 : check e862483306998 [] .sourceHead = true := by decide
def e862483307742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))))
theorem wire_e862483307742 : Closed e862483307742 ∧ code e862483307742 = 9658576329950 := by decide
theorem cert_e862483307742 : check e862483307742 [] .sourceHead = true := by decide
def e862483307758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))))
theorem wire_e862483307758 : Closed e862483307758 ∧ code e862483307758 = 9658576329966 := by decide
theorem cert_e862483307758 : check e862483307758 [] .sourceHead = true := by decide
def e862483307766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))))
theorem wire_e862483307766 : Closed e862483307766 ∧ code e862483307766 = 9658576329974 := by decide
theorem cert_e862483307766 : check e862483307766 [] .sourceHead = true := by decide
def e862483307770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))))
theorem wire_e862483307770 : Closed e862483307770 ∧ code e862483307770 = 9658576329978 := by decide
theorem cert_e862483307770 : check e862483307770 [] .sourceHead = true := by decide
def e862483308142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862483308142 : Closed e862483308142 ∧ code e862483308142 = 9658576330350 := by decide
theorem cert_e862483308142 : check e862483308142 [] .sourceHead = true := by decide
def e862483308150 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))))
theorem wire_e862483308150 : Closed e862483308150 ∧ code e862483308150 = 9658576330358 := by decide
theorem cert_e862483308150 : check e862483308150 [] .sourceHead = true := by decide
def e862483308154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862483308154 : Closed e862483308154 ∧ code e862483308154 = 9658576330362 := by decide
theorem cert_e862483308154 : check e862483308154 [] .sourceHead = true := by decide
def e862483310302 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e862483310302 : Closed e862483310302 ∧ code e862483310302 = 9658576332510 := by decide
theorem cert_e862483310302 : check e862483310302 [] .sourceHead = true := by decide
def e862483310318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))))
theorem wire_e862483310318 : Closed e862483310318 ∧ code e862483310318 = 9658576332526 := by decide
theorem cert_e862483310318 : check e862483310318 [] .sourceHead = true := by decide
def e862483310326 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e862483310326 : Closed e862483310326 ∧ code e862483310326 = 9658576332534 := by decide
theorem cert_e862483310326 : check e862483310326 [] .sourceHead = true := by decide
def e862483310430 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e862483310430 : Closed e862483310430 ∧ code e862483310430 = 9658576332638 := by decide
theorem cert_e862483310430 : check e862483310430 [] .sourceHead = true := by decide
def e862483310458 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e862483310458 : Closed e862483310458 ∧ code e862483310458 = 9658576332666 := by decide
theorem cert_e862483310458 : check e862483310458 [] .sourceHead = true := by decide
def e862483310510 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))))
theorem wire_e862483310510 : Closed e862483310510 ∧ code e862483310510 = 9658576332718 := by decide
theorem cert_e862483310510 : check e862483310510 [] .sourceHead = true := by decide
def e862483310522 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))))
theorem wire_e862483310522 : Closed e862483310522 ∧ code e862483310522 = 9658576332730 := by decide
theorem cert_e862483310522 : check e862483310522 [] .sourceHead = true := by decide
def e862483310550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e862483310550 : Closed e862483310550 ∧ code e862483310550 = 9658576332758 := by decide
theorem cert_e862483310550 : check e862483310550 [] .sourceHead = true := by decide
def e862483310554 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e862483310554 : Closed e862483310554 ∧ code e862483310554 = 9658576332762 := by decide
theorem cert_e862483310554 : check e862483310554 [] .sourceHead = true := by decide
def e862483311070 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e862483311070 : Closed e862483311070 ∧ code e862483311070 = 9658576333278 := by decide
theorem cert_e862483311070 : check e862483311070 [] .sourceHead = true := by decide
def e862483311086 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))))
theorem wire_e862483311086 : Closed e862483311086 ∧ code e862483311086 = 9658576333294 := by decide
theorem cert_e862483311086 : check e862483311086 [] .sourceHead = true := by decide
def e862483311094 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e862483311094 : Closed e862483311094 ∧ code e862483311094 = 9658576333302 := by decide
theorem cert_e862483311094 : check e862483311094 [] .sourceHead = true := by decide
def e862483311838 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e862483311838 : Closed e862483311838 ∧ code e862483311838 = 9658576334046 := by decide
theorem cert_e862483311838 : check e862483311838 [] .sourceHead = true := by decide
def e862483311866 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e862483311866 : Closed e862483311866 ∧ code e862483311866 = 9658576334074 := by decide
theorem cert_e862483311866 : check e862483311866 [] .sourceHead = true := by decide
def e862483312238 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862483312238 : Closed e862483312238 ∧ code e862483312238 = 9658576334446 := by decide
theorem cert_e862483312238 : check e862483312238 [] .sourceHead = true := by decide
def e862483312250 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862483312250 : Closed e862483312250 ∧ code e862483312250 = 9658576334458 := by decide
theorem cert_e862483312250 : check e862483312250 [] .sourceHead = true := by decide
def e862483312438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862483312438 : Closed e862483312438 ∧ code e862483312438 = 9658576334646 := by decide
theorem cert_e862483312438 : check e862483312438 [] .sourceHead = true := by decide
def e862483312442 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862483312442 : Closed e862483312442 ∧ code e862483312442 = 9658576334650 := by decide
theorem cert_e862483312442 : check e862483312442 [] .sourceHead = true := by decide
def e862483313502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e862483313502 : Closed e862483313502 ∧ code e862483313502 = 9658576335710 := by decide
theorem cert_e862483313502 : check e862483313502 [] .sourceHead = true := by decide
def e862483313518 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e862483313518 : Closed e862483313518 ∧ code e862483313518 = 9658576335726 := by decide
theorem cert_e862483313518 : check e862483313518 [] .sourceHead = true := by decide
def e862483313526 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e862483313526 : Closed e862483313526 ∧ code e862483313526 = 9658576335734 := by decide
theorem cert_e862483313526 : check e862483313526 [] .sourceHead = true := by decide
def e862483313530 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e862483313530 : Closed e862483313530 ∧ code e862483313530 = 9658576335738 := by decide
theorem cert_e862483313530 : check e862483313530 [] .sourceHead = true := by decide
def e862483313582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e862483313582 : Closed e862483313582 ∧ code e862483313582 = 9658576335790 := by decide
theorem cert_e862483313582 : check e862483313582 [] .sourceHead = true := by decide
def e862483313594 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e862483313594 : Closed e862483313594 ∧ code e862483313594 = 9658576335802 := by decide
theorem cert_e862483313594 : check e862483313594 [] .sourceHead = true := by decide
def e862483313622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e862483313622 : Closed e862483313622 ∧ code e862483313622 = 9658576335830 := by decide
theorem cert_e862483313622 : check e862483313622 [] .sourceHead = true := by decide
def e862483313626 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e862483313626 : Closed e862483313626 ∧ code e862483313626 = 9658576335834 := by decide
theorem cert_e862483313626 : check e862483313626 [] .sourceHead = true := by decide
def e862483313642 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e862483313642 : Closed e862483313642 ∧ code e862483313642 = 9658576335850 := by decide
theorem cert_e862483313642 : check e862483313642 [] .sourceHead = true := by decide
def e862483313886 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e862483313886 : Closed e862483313886 ∧ code e862483313886 = 9658576336094 := by decide
theorem cert_e862483313886 : check e862483313886 [] .sourceHead = true := by decide
def e862483313902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e862483313902 : Closed e862483313902 ∧ code e862483313902 = 9658576336110 := by decide
theorem cert_e862483313902 : check e862483313902 [] .sourceHead = true := by decide
def e862483313910 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e862483313910 : Closed e862483313910 ∧ code e862483313910 = 9658576336118 := by decide
theorem cert_e862483313910 : check e862483313910 [] .sourceHead = true := by decide
def e862483313914 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e862483313914 : Closed e862483313914 ∧ code e862483313914 = 9658576336122 := by decide
theorem cert_e862483313914 : check e862483313914 [] .sourceHead = true := by decide
def e862483314286 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862483314286 : Closed e862483314286 ∧ code e862483314286 = 9658576336494 := by decide
theorem cert_e862483314286 : check e862483314286 [] .sourceHead = true := by decide
def e862483314298 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862483314298 : Closed e862483314298 ∧ code e862483314298 = 9658576336506 := by decide
theorem cert_e862483314298 : check e862483314298 [] .sourceHead = true := by decide
def e862483314486 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862483314486 : Closed e862483314486 ∧ code e862483314486 = 9658576336694 := by decide
theorem cert_e862483314486 : check e862483314486 [] .sourceHead = true := by decide
def e862483314490 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862483314490 : Closed e862483314490 ∧ code e862483314490 = 9658576336698 := by decide
theorem cert_e862483314490 : check e862483314490 [] .sourceHead = true := by decide
def e862483314586 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483314586 : Closed e862483314586 ∧ code e862483314586 = 9658576336794 := by decide
theorem cert_e862483314586 : check e862483314586 [] .sourceHead = true := by decide
def e862483315118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e862483315118 : Closed e862483315118 ∧ code e862483315118 = 9658576337326 := by decide
theorem cert_e862483315118 : check e862483315118 [] .sourceHead = true := by decide
def e862483315126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e862483315126 : Closed e862483315126 ∧ code e862483315126 = 9658576337334 := by decide
theorem cert_e862483315126 : check e862483315126 [] .sourceHead = true := by decide
def e862483315130 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e862483315130 : Closed e862483315130 ∧ code e862483315130 = 9658576337338 := by decide
theorem cert_e862483315130 : check e862483315130 [] .sourceHead = true := by decide
def e862483315158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e862483315158 : Closed e862483315158 ∧ code e862483315158 = 9658576337366 := by decide
theorem cert_e862483315158 : check e862483315158 [] .sourceHead = true := by decide
def e862483315162 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e862483315162 : Closed e862483315162 ∧ code e862483315162 = 9658576337370 := by decide
theorem cert_e862483315162 : check e862483315162 [] .sourceHead = true := by decide
def e862483315178 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e862483315178 : Closed e862483315178 ∧ code e862483315178 = 9658576337386 := by decide
theorem cert_e862483315178 : check e862483315178 [] .sourceHead = true := by decide
def e862483315310 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862483315310 : Closed e862483315310 ∧ code e862483315310 = 9658576337518 := by decide
theorem cert_e862483315310 : check e862483315310 [] .sourceHead = true := by decide
def e862483315318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e862483315318 : Closed e862483315318 ∧ code e862483315318 = 9658576337526 := by decide
theorem cert_e862483315318 : check e862483315318 [] .sourceHead = true := by decide
def e862483315322 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862483315322 : Closed e862483315322 ∧ code e862483315322 = 9658576337530 := by decide
theorem cert_e862483315322 : check e862483315322 [] .sourceHead = true := by decide
def e862483315510 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862483315510 : Closed e862483315510 ∧ code e862483315510 = 9658576337718 := by decide
theorem cert_e862483315510 : check e862483315510 [] .sourceHead = true := by decide
def e862483315514 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862483315514 : Closed e862483315514 ∧ code e862483315514 = 9658576337722 := by decide
theorem cert_e862483315514 : check e862483315514 [] .sourceHead = true := by decide
def e862483315610 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862483315610 : Closed e862483315610 ∧ code e862483315610 = 9658576337818 := by decide
theorem cert_e862483315610 : check e862483315610 [] .sourceHead = true := by decide
def e862483319662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e862483319662 : Closed e862483319662 ∧ code e862483319662 = 9658576341870 := by decide
theorem cert_e862483319662 : check e862483319662 [] .sourceHead = true := by decide
def e862483319670 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e862483319670 : Closed e862483319670 ∧ code e862483319670 = 9658576341878 := by decide
theorem cert_e862483319670 : check e862483319670 [] .sourceHead = true := by decide
def e862483319726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e862483319726 : Closed e862483319726 ∧ code e862483319726 = 9658576341934 := by decide
theorem cert_e862483319726 : check e862483319726 [] .sourceHead = true := by decide
def e862483319738 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e862483319738 : Closed e862483319738 ∧ code e862483319738 = 9658576341946 := by decide
theorem cert_e862483319738 : check e862483319738 [] .sourceHead = true := by decide
def e862483319766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e862483319766 : Closed e862483319766 ∧ code e862483319766 = 9658576341974 := by decide
theorem cert_e862483319766 : check e862483319766 [] .sourceHead = true := by decide
def e862483319770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e862483319770 : Closed e862483319770 ∧ code e862483319770 = 9658576341978 := by decide
theorem cert_e862483319770 : check e862483319770 [] .sourceHead = true := by decide
def e862483320046 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e862483320046 : Closed e862483320046 ∧ code e862483320046 = 9658576342254 := by decide
theorem cert_e862483320046 : check e862483320046 [] .sourceHead = true := by decide
def e862483320054 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e862483320054 : Closed e862483320054 ∧ code e862483320054 = 9658576342262 := by decide
theorem cert_e862483320054 : check e862483320054 [] .sourceHead = true := by decide
def e862483320430 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e862483320430 : Closed e862483320430 ∧ code e862483320430 = 9658576342638 := by decide
theorem cert_e862483320430 : check e862483320430 [] .sourceHead = true := by decide
def e862483320442 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e862483320442 : Closed e862483320442 ∧ code e862483320442 = 9658576342650 := by decide
theorem cert_e862483320442 : check e862483320442 [] .sourceHead = true := by decide
def e862483320630 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e862483320630 : Closed e862483320630 ∧ code e862483320630 = 9658576342838 := by decide
theorem cert_e862483320630 : check e862483320630 [] .sourceHead = true := by decide
def e862483320634 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e862483320634 : Closed e862483320634 ∧ code e862483320634 = 9658576342842 := by decide
theorem cert_e862483320634 : check e862483320634 [] .sourceHead = true := by decide
def e862483328478 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e862483328478 : Closed e862483328478 ∧ code e862483328478 = 9658576350686 := by decide
theorem cert_e862483328478 : check e862483328478 [] .sourceHead = true := by decide
def e862483328494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e862483328494 : Closed e862483328494 ∧ code e862483328494 = 9658576350702 := by decide
theorem cert_e862483328494 : check e862483328494 [] .sourceHead = true := by decide
def e862483328734 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))))
theorem wire_e862483328734 : Closed e862483328734 ∧ code e862483328734 = 9658576350942 := by decide
theorem cert_e862483328734 : check e862483328734 [] .sourceHead = true := by decide
def e862483328750 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))))
theorem wire_e862483328750 : Closed e862483328750 ∧ code e862483328750 = 9658576350958 := by decide
theorem cert_e862483328750 : check e862483328750 [] .sourceHead = true := by decide
def e862483328758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))))
theorem wire_e862483328758 : Closed e862483328758 ∧ code e862483328758 = 9658576350966 := by decide
theorem cert_e862483328758 : check e862483328758 [] .sourceHead = true := by decide
def e862483328862 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e862483328862 : Closed e862483328862 ∧ code e862483328862 = 9658576351070 := by decide
theorem cert_e862483328862 : check e862483328862 [] .sourceHead = true := by decide
def e862483328878 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))))
theorem wire_e862483328878 : Closed e862483328878 ∧ code e862483328878 = 9658576351086 := by decide
theorem cert_e862483328878 : check e862483328878 [] .sourceHead = true := by decide
def e862483328886 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))))
theorem wire_e862483328886 : Closed e862483328886 ∧ code e862483328886 = 9658576351094 := by decide
theorem cert_e862483328886 : check e862483328886 [] .sourceHead = true := by decide
def e862483328890 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e862483328890 : Closed e862483328890 ∧ code e862483328890 = 9658576351098 := by decide
theorem cert_e862483328890 : check e862483328890 [] .sourceHead = true := by decide
def e862483328942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e862483328942 : Closed e862483328942 ∧ code e862483328942 = 9658576351150 := by decide
theorem cert_e862483328942 : check e862483328942 [] .sourceHead = true := by decide
def e862483328950 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))))
theorem wire_e862483328950 : Closed e862483328950 ∧ code e862483328950 = 9658576351158 := by decide
theorem cert_e862483328950 : check e862483328950 [] .sourceHead = true := by decide
def e862483328954 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e862483328954 : Closed e862483328954 ∧ code e862483328954 = 9658576351162 := by decide
theorem cert_e862483328954 : check e862483328954 [] .sourceHead = true := by decide
end Blc.Floor43
