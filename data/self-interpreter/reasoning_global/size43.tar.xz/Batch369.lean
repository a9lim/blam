import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422362394558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 4)))))))))))
theorem wire_e2422362394558 : Closed e2422362394558 ∧ code e2422362394558 = 11218455416766 := by decide
theorem cert_e2422362394558 : check e2422362394558 [[],[]] .smaller = true := by decide
def e2422362394590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 3)))))))))))
theorem wire_e2422362394590 : Closed e2422362394590 ∧ code e2422362394590 = 11218455416798 := by decide
theorem cert_e2422362394590 : check e2422362394590 [[],[]] .smaller = true := by decide
def e2422362394606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 5) (.var 2)))))))))))
theorem wire_e2422362394606 : Closed e2422362394606 ∧ code e2422362394606 = 11218455416814 := by decide
theorem cert_e2422362394606 : check e2422362394606 [[],[]] .three = true := by decide
def e2422362399198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))))
theorem wire_e2422362399198 : Closed e2422362399198 ∧ code e2422362399198 = 11218455421406 := by decide
theorem cert_e2422362399198 : check e2422362399198 [[],[]] .smaller = true := by decide
def e2422362399222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))))
theorem wire_e2422362399222 : Closed e2422362399222 ∧ code e2422362399222 = 11218455421430 := by decide
theorem cert_e2422362399222 : check e2422362399222 [[],[]] .smaller = true := by decide
def e2422362400174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e2422362400174 : Closed e2422362400174 ∧ code e2422362400174 = 11218455422382 := by decide
theorem cert_e2422362400174 : check e2422362400174 [[],[]] .smaller = true := by decide
def e2422362400186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e2422362400186 : Closed e2422362400186 ∧ code e2422362400186 = 11218455422394 := by decide
theorem cert_e2422362400186 : check e2422362400186 [[],[]] .smaller = true := by decide
def e2422362400234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e2422362400234 : Closed e2422362400234 ∧ code e2422362400234 = 11218455422442 := by decide
theorem cert_e2422362400234 : check e2422362400234 [[],[]] .smaller = true := by decide
def e2422362400318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))))
theorem wire_e2422362400318 : Closed e2422362400318 ∧ code e2422362400318 = 11218455422526 := by decide
theorem cert_e2422362400318 : check e2422362400318 [[],[]] .smaller = true := by decide
def e2422362400366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422362400366 : Closed e2422362400366 ∧ code e2422362400366 = 11218455422574 := by decide
theorem cert_e2422362400366 : check e2422362400366 [[],[]] .smaller = true := by decide
def e2422362400378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422362400378 : Closed e2422362400378 ∧ code e2422362400378 = 11218455422586 := by decide
theorem cert_e2422362400378 : check e2422362400378 [[],[]] .smaller = true := by decide
def e2422362400542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))))
theorem wire_e2422362400542 : Closed e2422362400542 ∧ code e2422362400542 = 11218455422750 := by decide
theorem cert_e2422362400542 : check e2422362400542 [[],[]] .smaller = true := by decide
def e2422362400638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 5)))))))))))
theorem wire_e2422362400638 : Closed e2422362400638 ∧ code e2422362400638 = 11218455422846 := by decide
theorem cert_e2422362400638 : check e2422362400638 [[],[]] .three = true := by decide
def e2422362400654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))))
theorem wire_e2422362400654 : Closed e2422362400654 ∧ code e2422362400654 = 11218455422862 := by decide
theorem cert_e2422362400654 : check e2422362400654 [[],[]] .smaller = true := by decide
def e2422362400666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422362400666 : Closed e2422362400666 ∧ code e2422362400666 = 11218455422874 := by decide
theorem cert_e2422362400666 : check e2422362400666 [[],[]] .smaller = true := by decide
def e2422362400710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))))
theorem wire_e2422362400710 : Closed e2422362400710 ∧ code e2422362400710 = 11218455422918 := by decide
theorem cert_e2422362400710 : check e2422362400710 [[],[]] .smaller = true := by decide
def e2422362400734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 3)))))))))))
theorem wire_e2422362400734 : Closed e2422362400734 ∧ code e2422362400734 = 11218455422942 := by decide
theorem cert_e2422362400734 : check e2422362400734 [[],[]] .smaller = true := by decide
def e2422362400758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 5) (.var 1)))))))))))
theorem wire_e2422362400758 : Closed e2422362400758 ∧ code e2422362400758 = 11218455422966 := by decide
theorem cert_e2422362400758 : check e2422362400758 [[],[]] .three = true := by decide
def e2422362403054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422362403054 : Closed e2422362403054 ∧ code e2422362403054 = 11218455425262 := by decide
theorem cert_e2422362403054 : check e2422362403054 [[],[]] .smaller = true := by decide
def e2422362403062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422362403062 : Closed e2422362403062 ∧ code e2422362403062 = 11218455425270 := by decide
theorem cert_e2422362403062 : check e2422362403062 [[],[]] .smaller = true := by decide
def e2422362403542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e2422362403542 : Closed e2422362403542 ∧ code e2422362403542 = 11218455425750 := by decide
theorem cert_e2422362403542 : check e2422362403542 [[],[]] .smaller = true := by decide
def e2422362403546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e2422362403546 : Closed e2422362403546 ∧ code e2422362403546 = 11218455425754 := by decide
theorem cert_e2422362403546 : check e2422362403546 [[],[]] .smaller = true := by decide
def e2422362403562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e2422362403562 : Closed e2422362403562 ∧ code e2422362403562 = 11218455425770 := by decide
theorem cert_e2422362403562 : check e2422362403562 [[],[]] .smaller = true := by decide
def e2422362403638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422362403638 : Closed e2422362403638 ∧ code e2422362403638 = 11218455425846 := by decide
theorem cert_e2422362403638 : check e2422362403638 [[],[]] .smaller = true := by decide
def e2422362403642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422362403642 : Closed e2422362403642 ∧ code e2422362403642 = 11218455425850 := by decide
theorem cert_e2422362403642 : check e2422362403642 [[],[]] .smaller = true := by decide
def e2422362403710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 5)))))))))))
theorem wire_e2422362403710 : Closed e2422362403710 ∧ code e2422362403710 = 11218455425918 := by decide
theorem cert_e2422362403710 : check e2422362403710 [[],[]] .three = true := by decide
def e2422362403726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))))
theorem wire_e2422362403726 : Closed e2422362403726 ∧ code e2422362403726 = 11218455425934 := by decide
theorem cert_e2422362403726 : check e2422362403726 [[],[]] .smaller = true := by decide
def e2422362403738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422362403738 : Closed e2422362403738 ∧ code e2422362403738 = 11218455425946 := by decide
theorem cert_e2422362403738 : check e2422362403738 [[],[]] .smaller = true := by decide
def e2422362403806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422362403806 : Closed e2422362403806 ∧ code e2422362403806 = 11218455426014 := by decide
theorem cert_e2422362403806 : check e2422362403806 [[],[]] .smaller = true := by decide
def e2422362403822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422362403822 : Closed e2422362403822 ∧ code e2422362403822 = 11218455426030 := by decide
theorem cert_e2422362403822 : check e2422362403822 [[],[]] .smaller = true := by decide
def e2422362403834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 5) (.var 0)))))))))))
theorem wire_e2422362403834 : Closed e2422362403834 ∧ code e2422362403834 = 11218455426042 := by decide
theorem cert_e2422362403834 : check e2422362403834 [[],[]] .three = true := by decide
def e2422362405262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e2422362405262 : Closed e2422362405262 ∧ code e2422362405262 = 11218455427470 := by decide
theorem cert_e2422362405262 : check e2422362405262 [[],[]] .smaller = true := by decide
def e2422362405310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422362405310 : Closed e2422362405310 ∧ code e2422362405310 = 11218455427518 := by decide
theorem cert_e2422362405310 : check e2422362405310 [[],[]] .smaller = true := by decide
def e2422362405318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e2422362405318 : Closed e2422362405318 ∧ code e2422362405318 = 11218455427526 := by decide
theorem cert_e2422362405318 : check e2422362405318 [[],[]] .smaller = true := by decide
def e2422362405342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422362405342 : Closed e2422362405342 ∧ code e2422362405342 = 11218455427550 := by decide
theorem cert_e2422362405342 : check e2422362405342 [[],[]] .smaller = true := by decide
def e2422362405358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422362405358 : Closed e2422362405358 ∧ code e2422362405358 = 11218455427566 := by decide
theorem cert_e2422362405358 : check e2422362405358 [[],[]] .smaller = true := by decide
def e2422362405366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422362405366 : Closed e2422362405366 ∧ code e2422362405366 = 11218455427574 := by decide
theorem cert_e2422362405366 : check e2422362405366 [[],[]] .smaller = true := by decide
def e2422362405370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422362405370 : Closed e2422362405370 ∧ code e2422362405370 = 11218455427578 := by decide
theorem cert_e2422362405370 : check e2422362405370 [[],[]] .smaller = true := by decide
def e2422362406110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422362406110 : Closed e2422362406110 ∧ code e2422362406110 = 11218455428318 := by decide
theorem cert_e2422362406110 : check e2422362406110 [[],[]] .smaller = true := by decide
def e2422362406138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422362406138 : Closed e2422362406138 ∧ code e2422362406138 = 11218455428346 := by decide
theorem cert_e2422362406138 : check e2422362406138 [[],[]] .smaller = true := by decide
def e2422362406510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 5) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362406510 : Closed e2422362406510 ∧ code e2422362406510 = 11218455428718 := by decide
theorem cert_e2422362406510 : check e2422362406510 [[],[]] .three = true := by decide
def e2422362406518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 5) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422362406518 : Closed e2422362406518 ∧ code e2422362406518 = 11218455428726 := by decide
theorem cert_e2422362406518 : check e2422362406518 [[],[]] .three = true := by decide
def e2422362406522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 5) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362406522 : Closed e2422362406522 ∧ code e2422362406522 = 11218455428730 := by decide
theorem cert_e2422362406522 : check e2422362406522 [[],[]] .three = true := by decide
def e2422362494638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e2422362494638 : Closed e2422362494638 ∧ code e2422362494638 = 11218455516846 := by decide
theorem cert_e2422362494638 : check e2422362494638 [[],[]] .smaller = true := by decide
def e2422362494650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e2422362494650 : Closed e2422362494650 ∧ code e2422362494650 = 11218455516858 := by decide
theorem cert_e2422362494650 : check e2422362494650 [[],[]] .smaller = true := by decide
def e2422362494698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e2422362494698 : Closed e2422362494698 ∧ code e2422362494698 = 11218455516906 := by decide
theorem cert_e2422362494698 : check e2422362494698 [[],[]] .smaller = true := by decide
def e2422362494890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))))
theorem wire_e2422362494890 : Closed e2422362494890 ∧ code e2422362494890 = 11218455517098 := by decide
theorem cert_e2422362494890 : check e2422362494890 [[],[]] .smaller = true := by decide
def e2422362495198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))))))))))
theorem wire_e2422362495198 : Closed e2422362495198 ∧ code e2422362495198 = 11218455517406 := by decide
theorem cert_e2422362495198 : check e2422362495198 [[],[]] .smaller = true := by decide
def e2422362495214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))))
theorem wire_e2422362495214 : Closed e2422362495214 ∧ code e2422362495214 = 11218455517422 := by decide
theorem cert_e2422362495214 : check e2422362495214 [[],[]] .smaller = true := by decide
def e2422362495222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))))
theorem wire_e2422362495222 : Closed e2422362495222 ∧ code e2422362495222 = 11218455517430 := by decide
theorem cert_e2422362495222 : check e2422362495222 [[],[]] .smaller = true := by decide
def e2422362495226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))))))))
theorem wire_e2422362495226 : Closed e2422362495226 ∧ code e2422362495226 = 11218455517434 := by decide
theorem cert_e2422362495226 : check e2422362495226 [[],[]] .smaller = true := by decide
def e2422362495406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e2422362495406 : Closed e2422362495406 ∧ code e2422362495406 = 11218455517614 := by decide
theorem cert_e2422362495406 : check e2422362495406 [[],[]] .smaller = true := by decide
def e2422362495418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e2422362495418 : Closed e2422362495418 ∧ code e2422362495418 = 11218455517626 := by decide
theorem cert_e2422362495418 : check e2422362495418 [[],[]] .smaller = true := by decide
def e2422362495466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e2422362495466 : Closed e2422362495466 ∧ code e2422362495466 = 11218455517674 := by decide
theorem cert_e2422362495466 : check e2422362495466 [[],[]] .smaller = true := by decide
def e2422362495550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))))))
theorem wire_e2422362495550 : Closed e2422362495550 ∧ code e2422362495550 = 11218455517758 := by decide
theorem cert_e2422362495550 : check e2422362495550 [[],[]] .smaller = true := by decide
def e2422362495598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362495598 : Closed e2422362495598 ∧ code e2422362495598 = 11218455517806 := by decide
theorem cert_e2422362495598 : check e2422362495598 [[],[]] .smaller = true := by decide
def e2422362495610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362495610 : Closed e2422362495610 ∧ code e2422362495610 = 11218455517818 := by decide
theorem cert_e2422362495610 : check e2422362495610 [[],[]] .smaller = true := by decide
def e2422362495774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))))
theorem wire_e2422362495774 : Closed e2422362495774 ∧ code e2422362495774 = 11218455517982 := by decide
theorem cert_e2422362495774 : check e2422362495774 [[],[]] .smaller = true := by decide
def e2422362495870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 5))))))))))
theorem wire_e2422362495870 : Closed e2422362495870 ∧ code e2422362495870 = 11218455518078 := by decide
theorem cert_e2422362495870 : check e2422362495870 [[],[]] .three = true := by decide
def e2422362495886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))))
theorem wire_e2422362495886 : Closed e2422362495886 ∧ code e2422362495886 = 11218455518094 := by decide
theorem cert_e2422362495886 : check e2422362495886 [[],[]] .smaller = true := by decide
def e2422362495898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362495898 : Closed e2422362495898 ∧ code e2422362495898 = 11218455518106 := by decide
theorem cert_e2422362495898 : check e2422362495898 [[],[]] .smaller = true := by decide
def e2422362495942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))))))))))
theorem wire_e2422362495942 : Closed e2422362495942 ∧ code e2422362495942 = 11218455518150 := by decide
theorem cert_e2422362495942 : check e2422362495942 [[],[]] .smaller = true := by decide
def e2422362495966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 3))))))))))
theorem wire_e2422362495966 : Closed e2422362495966 ∧ code e2422362495966 = 11218455518174 := by decide
theorem cert_e2422362495966 : check e2422362495966 [[],[]] .smaller = true := by decide
def e2422362495990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 5)) (.var 1))))))))))
theorem wire_e2422362495990 : Closed e2422362495990 ∧ code e2422362495990 = 11218455518198 := by decide
theorem cert_e2422362495990 : check e2422362495990 [[],[]] .three = true := by decide
def e2422362496110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))))
theorem wire_e2422362496110 : Closed e2422362496110 ∧ code e2422362496110 = 11218455518318 := by decide
theorem cert_e2422362496110 : check e2422362496110 [[],[]] .smaller = true := by decide
def e2422362496122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))))
theorem wire_e2422362496122 : Closed e2422362496122 ∧ code e2422362496122 = 11218455518330 := by decide
theorem cert_e2422362496122 : check e2422362496122 [[],[]] .smaller = true := by decide
def e2422362496286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))))
theorem wire_e2422362496286 : Closed e2422362496286 ∧ code e2422362496286 = 11218455518494 := by decide
theorem cert_e2422362496286 : check e2422362496286 [[],[]] .smaller = true := by decide
def e2422362496382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 5))))))))))
theorem wire_e2422362496382 : Closed e2422362496382 ∧ code e2422362496382 = 11218455518590 := by decide
theorem cert_e2422362496382 : check e2422362496382 [[],[]] .three = true := by decide
def e2422362496454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))))
theorem wire_e2422362496454 : Closed e2422362496454 ∧ code e2422362496454 = 11218455518662 := by decide
theorem cert_e2422362496454 : check e2422362496454 [[],[]] .smaller = true := by decide
def e2422362496478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3))))))))))
theorem wire_e2422362496478 : Closed e2422362496478 ∧ code e2422362496478 = 11218455518686 := by decide
theorem cert_e2422362496478 : check e2422362496478 [[],[]] .smaller = true := by decide
def e2422362496494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2))))))))))
theorem wire_e2422362496494 : Closed e2422362496494 ∧ code e2422362496494 = 11218455518702 := by decide
theorem cert_e2422362496494 : check e2422362496494 [[],[]] .smaller = true := by decide
def e2422362496506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 5)) (.var 0))))))))))
theorem wire_e2422362496506 : Closed e2422362496506 ∧ code e2422362496506 = 11218455518714 := by decide
theorem cert_e2422362496506 : check e2422362496506 [[],[]] .three = true := by decide
def e2422362496566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e2422362496566 : Closed e2422362496566 ∧ code e2422362496566 = 11218455518774 := by decide
theorem cert_e2422362496566 : check e2422362496566 [[],[]] .smaller = true := by decide
def e2422362496570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e2422362496570 : Closed e2422362496570 ∧ code e2422362496570 = 11218455518778 := by decide
theorem cert_e2422362496570 : check e2422362496570 [[],[]] .smaller = true := by decide
def e2422362496618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))))
theorem wire_e2422362496618 : Closed e2422362496618 ∧ code e2422362496618 = 11218455518826 := by decide
theorem cert_e2422362496618 : check e2422362496618 [[],[]] .smaller = true := by decide
def e2422362496654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e2422362496654 : Closed e2422362496654 ∧ code e2422362496654 = 11218455518862 := by decide
theorem cert_e2422362496654 : check e2422362496654 [[],[]] .smaller = true := by decide
def e2422362496666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362496666 : Closed e2422362496666 ∧ code e2422362496666 = 11218455518874 := by decide
theorem cert_e2422362496666 : check e2422362496666 [[],[]] .smaller = true := by decide
def e2422362496710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e2422362496710 : Closed e2422362496710 ∧ code e2422362496710 = 11218455518918 := by decide
theorem cert_e2422362496710 : check e2422362496710 [[],[]] .smaller = true := by decide
def e2422362496734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3))))))))))
theorem wire_e2422362496734 : Closed e2422362496734 ∧ code e2422362496734 = 11218455518942 := by decide
theorem cert_e2422362496734 : check e2422362496734 [[],[]] .smaller = true := by decide
def e2422362496758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1))))))))))
theorem wire_e2422362496758 : Closed e2422362496758 ∧ code e2422362496758 = 11218455518966 := by decide
theorem cert_e2422362496758 : check e2422362496758 [[],[]] .smaller = true := by decide
def e2422362496794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.var 0))))))))))
theorem wire_e2422362496794 : Closed e2422362496794 ∧ code e2422362496794 = 11218455519002 := by decide
theorem cert_e2422362496794 : check e2422362496794 [[],[]] .smaller = true := by decide
def e2422362496838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.var 1)))))))))))
theorem wire_e2422362496838 : Closed e2422362496838 ∧ code e2422362496838 = 11218455519046 := by decide
theorem cert_e2422362496838 : check e2422362496838 [[],[]] .smaller = true := by decide
def e2422362496862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 3))))))))))
theorem wire_e2422362496862 : Closed e2422362496862 ∧ code e2422362496862 = 11218455519070 := by decide
theorem cert_e2422362496862 : check e2422362496862 [[],[]] .smaller = true := by decide
def e2422362496878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2))))))))))
theorem wire_e2422362496878 : Closed e2422362496878 ∧ code e2422362496878 = 11218455519086 := by decide
theorem cert_e2422362496878 : check e2422362496878 [[],[]] .smaller = true := by decide
def e2422362496886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1))))))))))
theorem wire_e2422362496886 : Closed e2422362496886 ∧ code e2422362496886 = 11218455519094 := by decide
theorem cert_e2422362496886 : check e2422362496886 [[],[]] .smaller = true := by decide
def e2422362496890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 0))))))))))
theorem wire_e2422362496890 : Closed e2422362496890 ∧ code e2422362496890 = 11218455519098 := by decide
theorem cert_e2422362496890 : check e2422362496890 [[],[]] .smaller = true := by decide
def e2422362496982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 5) (.var 0)) (.var 1))))))))))
theorem wire_e2422362496982 : Closed e2422362496982 ∧ code e2422362496982 = 11218455519190 := by decide
theorem cert_e2422362496982 : check e2422362496982 [[],[]] .three = true := by decide
def e2422362496986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 5) (.var 1)) (.var 0))))))))))
theorem wire_e2422362496986 : Closed e2422362496986 ∧ code e2422362496986 = 11218455519194 := by decide
theorem cert_e2422362496986 : check e2422362496986 [[],[]] .three = true := by decide
def e2422362497502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))))
theorem wire_e2422362497502 : Closed e2422362497502 ∧ code e2422362497502 = 11218455519710 := by decide
theorem cert_e2422362497502 : check e2422362497502 [[],[]] .smaller = true := by decide
def e2422362497526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))))
theorem wire_e2422362497526 : Closed e2422362497526 ∧ code e2422362497526 = 11218455519734 := by decide
theorem cert_e2422362497526 : check e2422362497526 [[],[]] .smaller = true := by decide
def e2422362498478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e2422362498478 : Closed e2422362498478 ∧ code e2422362498478 = 11218455520686 := by decide
theorem cert_e2422362498478 : check e2422362498478 [[],[]] .smaller = true := by decide
def e2422362498490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e2422362498490 : Closed e2422362498490 ∧ code e2422362498490 = 11218455520698 := by decide
theorem cert_e2422362498490 : check e2422362498490 [[],[]] .smaller = true := by decide
def e2422362498538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e2422362498538 : Closed e2422362498538 ∧ code e2422362498538 = 11218455520746 := by decide
theorem cert_e2422362498538 : check e2422362498538 [[],[]] .smaller = true := by decide
def e2422362498622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))))))))))
theorem wire_e2422362498622 : Closed e2422362498622 ∧ code e2422362498622 = 11218455520830 := by decide
theorem cert_e2422362498622 : check e2422362498622 [[],[]] .smaller = true := by decide
def e2422362498670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422362498670 : Closed e2422362498670 ∧ code e2422362498670 = 11218455520878 := by decide
theorem cert_e2422362498670 : check e2422362498670 [[],[]] .smaller = true := by decide
def e2422362498682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422362498682 : Closed e2422362498682 ∧ code e2422362498682 = 11218455520890 := by decide
theorem cert_e2422362498682 : check e2422362498682 [[],[]] .smaller = true := by decide
def e2422362498846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))))
theorem wire_e2422362498846 : Closed e2422362498846 ∧ code e2422362498846 = 11218455521054 := by decide
theorem cert_e2422362498846 : check e2422362498846 [[],[]] .smaller = true := by decide
def e2422362498942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 5)))))))))))
theorem wire_e2422362498942 : Closed e2422362498942 ∧ code e2422362498942 = 11218455521150 := by decide
theorem cert_e2422362498942 : check e2422362498942 [[],[]] .three = true := by decide
def e2422362498958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))))
theorem wire_e2422362498958 : Closed e2422362498958 ∧ code e2422362498958 = 11218455521166 := by decide
theorem cert_e2422362498958 : check e2422362498958 [[],[]] .smaller = true := by decide
def e2422362498970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422362498970 : Closed e2422362498970 ∧ code e2422362498970 = 11218455521178 := by decide
theorem cert_e2422362498970 : check e2422362498970 [[],[]] .smaller = true := by decide
def e2422362499014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))))))))))
theorem wire_e2422362499014 : Closed e2422362499014 ∧ code e2422362499014 = 11218455521222 := by decide
theorem cert_e2422362499014 : check e2422362499014 [[],[]] .smaller = true := by decide
def e2422362499038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 3)))))))))))
theorem wire_e2422362499038 : Closed e2422362499038 ∧ code e2422362499038 = 11218455521246 := by decide
theorem cert_e2422362499038 : check e2422362499038 [[],[]] .smaller = true := by decide
def e2422362499062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 5) (.var 1)))))))))))
theorem wire_e2422362499062 : Closed e2422362499062 ∧ code e2422362499062 = 11218455521270 := by decide
theorem cert_e2422362499062 : check e2422362499062 [[],[]] .three = true := by decide
def e2422362501918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))))
theorem wire_e2422362501918 : Closed e2422362501918 ∧ code e2422362501918 = 11218455524126 := by decide
theorem cert_e2422362501918 : check e2422362501918 [[],[]] .smaller = true := by decide
def e2422362502014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 5)))))))))))
theorem wire_e2422362502014 : Closed e2422362502014 ∧ code e2422362502014 = 11218455524222 := by decide
theorem cert_e2422362502014 : check e2422362502014 [[],[]] .three = true := by decide
def e2422362502086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))))
theorem wire_e2422362502086 : Closed e2422362502086 ∧ code e2422362502086 = 11218455524294 := by decide
theorem cert_e2422362502086 : check e2422362502086 [[],[]] .smaller = true := by decide
def e2422362502110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422362502110 : Closed e2422362502110 ∧ code e2422362502110 = 11218455524318 := by decide
theorem cert_e2422362502110 : check e2422362502110 [[],[]] .smaller = true := by decide
def e2422362502126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422362502126 : Closed e2422362502126 ∧ code e2422362502126 = 11218455524334 := by decide
theorem cert_e2422362502126 : check e2422362502126 [[],[]] .smaller = true := by decide
def e2422362502138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 5) (.var 0)))))))))))
theorem wire_e2422362502138 : Closed e2422362502138 ∧ code e2422362502138 = 11218455524346 := by decide
theorem cert_e2422362502138 : check e2422362502138 [[],[]] .three = true := by decide
def e2422362503286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))))
theorem wire_e2422362503286 : Closed e2422362503286 ∧ code e2422362503286 = 11218455525494 := by decide
theorem cert_e2422362503286 : check e2422362503286 [[],[]] .smaller = true := by decide
def e2422362503530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))))
theorem wire_e2422362503530 : Closed e2422362503530 ∧ code e2422362503530 = 11218455525738 := by decide
theorem cert_e2422362503530 : check e2422362503530 [[],[]] .smaller = true := by decide
def e2422362503566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e2422362503566 : Closed e2422362503566 ∧ code e2422362503566 = 11218455525774 := by decide
theorem cert_e2422362503566 : check e2422362503566 [[],[]] .smaller = true := by decide
def e2422362503578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422362503578 : Closed e2422362503578 ∧ code e2422362503578 = 11218455525786 := by decide
theorem cert_e2422362503578 : check e2422362503578 [[],[]] .smaller = true := by decide
def e2422362503622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e2422362503622 : Closed e2422362503622 ∧ code e2422362503622 = 11218455525830 := by decide
theorem cert_e2422362503622 : check e2422362503622 [[],[]] .smaller = true := by decide
def e2422362503646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422362503646 : Closed e2422362503646 ∧ code e2422362503646 = 11218455525854 := by decide
theorem cert_e2422362503646 : check e2422362503646 [[],[]] .smaller = true := by decide
def e2422362503670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422362503670 : Closed e2422362503670 ∧ code e2422362503670 = 11218455525878 := by decide
theorem cert_e2422362503670 : check e2422362503670 [[],[]] .smaller = true := by decide
def e2422362504390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))))))))))
theorem wire_e2422362504390 : Closed e2422362504390 ∧ code e2422362504390 = 11218455526598 := by decide
theorem cert_e2422362504390 : check e2422362504390 [[],[]] .smaller = true := by decide
def e2422362504414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422362504414 : Closed e2422362504414 ∧ code e2422362504414 = 11218455526622 := by decide
theorem cert_e2422362504414 : check e2422362504414 [[],[]] .smaller = true := by decide
def e2422362504430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422362504430 : Closed e2422362504430 ∧ code e2422362504430 = 11218455526638 := by decide
theorem cert_e2422362504430 : check e2422362504430 [[],[]] .smaller = true := by decide
def e2422362504438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422362504438 : Closed e2422362504438 ∧ code e2422362504438 = 11218455526646 := by decide
theorem cert_e2422362504438 : check e2422362504438 [[],[]] .smaller = true := by decide
def e2422362504442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422362504442 : Closed e2422362504442 ∧ code e2422362504442 = 11218455526650 := by decide
theorem cert_e2422362504442 : check e2422362504442 [[],[]] .smaller = true := by decide
def e2422362505014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 5) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422362505014 : Closed e2422362505014 ∧ code e2422362505014 = 11218455527222 := by decide
theorem cert_e2422362505014 : check e2422362505014 [[],[]] .three = true := by decide
def e2422362505018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 5) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422362505018 : Closed e2422362505018 ∧ code e2422362505018 = 11218455527226 := by decide
theorem cert_e2422362505018 : check e2422362505018 [[],[]] .three = true := by decide
def e2422362549078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e2422362549078 : Closed e2422362549078 ∧ code e2422362549078 = 11218455571286 := by decide
theorem cert_e2422362549078 : check e2422362549078 [[],[]] .smaller = true := by decide
def e2422362549082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e2422362549082 : Closed e2422362549082 ∧ code e2422362549082 = 11218455571290 := by decide
theorem cert_e2422362549082 : check e2422362549082 [[],[]] .smaller = true := by decide
def e2422362549098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e2422362549098 : Closed e2422362549098 ∧ code e2422362549098 = 11218455571306 := by decide
theorem cert_e2422362549098 : check e2422362549098 [[],[]] .smaller = true := by decide
def e2422362549162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))))
theorem wire_e2422362549162 : Closed e2422362549162 ∧ code e2422362549162 = 11218455571370 := by decide
theorem cert_e2422362549162 : check e2422362549162 [[],[]] .smaller = true := by decide
def e2422362549366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))))
theorem wire_e2422362549366 : Closed e2422362549366 ∧ code e2422362549366 = 11218455571574 := by decide
theorem cert_e2422362549366 : check e2422362549366 [[],[]] .smaller = true := by decide
def e2422362549462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e2422362549462 : Closed e2422362549462 ∧ code e2422362549462 = 11218455571670 := by decide
theorem cert_e2422362549462 : check e2422362549462 [[],[]] .smaller = true := by decide
def e2422362549466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e2422362549466 : Closed e2422362549466 ∧ code e2422362549466 = 11218455571674 := by decide
theorem cert_e2422362549466 : check e2422362549466 [[],[]] .smaller = true := by decide
def e2422362549482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e2422362549482 : Closed e2422362549482 ∧ code e2422362549482 = 11218455571690 := by decide
theorem cert_e2422362549482 : check e2422362549482 [[],[]] .smaller = true := by decide
def e2422362549558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422362549558 : Closed e2422362549558 ∧ code e2422362549558 = 11218455571766 := by decide
theorem cert_e2422362549558 : check e2422362549558 [[],[]] .smaller = true := by decide
def e2422362549562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422362549562 : Closed e2422362549562 ∧ code e2422362549562 = 11218455571770 := by decide
theorem cert_e2422362549562 : check e2422362549562 [[],[]] .smaller = true := by decide
def e2422362549630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 5))))))))))
theorem wire_e2422362549630 : Closed e2422362549630 ∧ code e2422362549630 = 11218455571838 := by decide
theorem cert_e2422362549630 : check e2422362549630 [[],[]] .three = true := by decide
def e2422362549646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))))
theorem wire_e2422362549646 : Closed e2422362549646 ∧ code e2422362549646 = 11218455571854 := by decide
theorem cert_e2422362549646 : check e2422362549646 [[],[]] .smaller = true := by decide
def e2422362549658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362549658 : Closed e2422362549658 ∧ code e2422362549658 = 11218455571866 := by decide
theorem cert_e2422362549658 : check e2422362549658 [[],[]] .smaller = true := by decide
def e2422362549726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e2422362549726 : Closed e2422362549726 ∧ code e2422362549726 = 11218455571934 := by decide
theorem cert_e2422362549726 : check e2422362549726 [[],[]] .smaller = true := by decide
def e2422362549742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e2422362549742 : Closed e2422362549742 ∧ code e2422362549742 = 11218455571950 := by decide
theorem cert_e2422362549742 : check e2422362549742 [[],[]] .smaller = true := by decide
def e2422362549754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 5)) (.var 0))))))))))
theorem wire_e2422362549754 : Closed e2422362549754 ∧ code e2422362549754 = 11218455571962 := by decide
theorem cert_e2422362549754 : check e2422362549754 [[],[]] .three = true := by decide
def e2422362549814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e2422362549814 : Closed e2422362549814 ∧ code e2422362549814 = 11218455572022 := by decide
theorem cert_e2422362549814 : check e2422362549814 [[],[]] .smaller = true := by decide
def e2422362549818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e2422362549818 : Closed e2422362549818 ∧ code e2422362549818 = 11218455572026 := by decide
theorem cert_e2422362549818 : check e2422362549818 [[],[]] .smaller = true := by decide
def e2422362549866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))))
theorem wire_e2422362549866 : Closed e2422362549866 ∧ code e2422362549866 = 11218455572074 := by decide
theorem cert_e2422362549866 : check e2422362549866 [[],[]] .smaller = true := by decide
def e2422362549902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e2422362549902 : Closed e2422362549902 ∧ code e2422362549902 = 11218455572110 := by decide
theorem cert_e2422362549902 : check e2422362549902 [[],[]] .smaller = true := by decide
def e2422362549914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362549914 : Closed e2422362549914 ∧ code e2422362549914 = 11218455572122 := by decide
theorem cert_e2422362549914 : check e2422362549914 [[],[]] .smaller = true := by decide
def e2422362549958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e2422362549958 : Closed e2422362549958 ∧ code e2422362549958 = 11218455572166 := by decide
theorem cert_e2422362549958 : check e2422362549958 [[],[]] .smaller = true := by decide
def e2422362549982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3))))))))))
theorem wire_e2422362549982 : Closed e2422362549982 ∧ code e2422362549982 = 11218455572190 := by decide
theorem cert_e2422362549982 : check e2422362549982 [[],[]] .smaller = true := by decide
def e2422362550006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1))))))))))
theorem wire_e2422362550006 : Closed e2422362550006 ∧ code e2422362550006 = 11218455572214 := by decide
theorem cert_e2422362550006 : check e2422362550006 [[],[]] .smaller = true := by decide
def e2422362550110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e2422362550110 : Closed e2422362550110 ∧ code e2422362550110 = 11218455572318 := by decide
theorem cert_e2422362550110 : check e2422362550110 [[],[]] .smaller = true := by decide
def e2422362550138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e2422362550138 : Closed e2422362550138 ∧ code e2422362550138 = 11218455572346 := by decide
theorem cert_e2422362550138 : check e2422362550138 [[],[]] .smaller = true := by decide
def e2422362550190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e2422362550190 : Closed e2422362550190 ∧ code e2422362550190 = 11218455572398 := by decide
theorem cert_e2422362550190 : check e2422362550190 [[],[]] .smaller = true := by decide
def e2422362550198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1))))))))))
theorem wire_e2422362550198 : Closed e2422362550198 ∧ code e2422362550198 = 11218455572406 := by decide
theorem cert_e2422362550198 : check e2422362550198 [[],[]] .smaller = true := by decide
def e2422362550202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e2422362550202 : Closed e2422362550202 ∧ code e2422362550202 = 11218455572410 := by decide
theorem cert_e2422362550202 : check e2422362550202 [[],[]] .smaller = true := by decide
def e2422362550250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 5) (.var 0)) (.var 0))))))))))
theorem wire_e2422362550250 : Closed e2422362550250 ∧ code e2422362550250 = 11218455572458 := by decide
theorem cert_e2422362550250 : check e2422362550250 [[],[]] .three = true := by decide
def e2422362550510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422362550510 : Closed e2422362550510 ∧ code e2422362550510 = 11218455572718 := by decide
theorem cert_e2422362550510 : check e2422362550510 [[],[]] .smaller = true := by decide
def e2422362550518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422362550518 : Closed e2422362550518 ∧ code e2422362550518 = 11218455572726 := by decide
theorem cert_e2422362550518 : check e2422362550518 [[],[]] .smaller = true := by decide
def e2422362550998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e2422362550998 : Closed e2422362550998 ∧ code e2422362550998 = 11218455573206 := by decide
theorem cert_e2422362550998 : check e2422362550998 [[],[]] .smaller = true := by decide
def e2422362551002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e2422362551002 : Closed e2422362551002 ∧ code e2422362551002 = 11218455573210 := by decide
theorem cert_e2422362551002 : check e2422362551002 [[],[]] .smaller = true := by decide
def e2422362551018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e2422362551018 : Closed e2422362551018 ∧ code e2422362551018 = 11218455573226 := by decide
theorem cert_e2422362551018 : check e2422362551018 [[],[]] .smaller = true := by decide
def e2422362551094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422362551094 : Closed e2422362551094 ∧ code e2422362551094 = 11218455573302 := by decide
theorem cert_e2422362551094 : check e2422362551094 [[],[]] .smaller = true := by decide
def e2422362551098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422362551098 : Closed e2422362551098 ∧ code e2422362551098 = 11218455573306 := by decide
theorem cert_e2422362551098 : check e2422362551098 [[],[]] .smaller = true := by decide
end Blc.Floor43
