import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2259662094534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259662094534 : Closed e2259662094534 ∧ code e2259662094534 = 11055755116742 := by decide
theorem cert_e2259662094534 : check e2259662094534 [[]] .width = true := by decide
def e2259662102554 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259662102554 : Closed e2259662102554 ∧ code e2259662102554 = 11055755124762 := by decide
theorem cert_e2259662102554 : check e2259662102554 [[]] .width = true := by decide
def e2259662102646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259662102646 : Closed e2259662102646 ∧ code e2259662102646 = 11055755124854 := by decide
theorem cert_e2259662102646 : check e2259662102646 [[]] .width = true := by decide
def e2259662102890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259662102890 : Closed e2259662102890 ∧ code e2259662102890 = 11055755125098 := by decide
theorem cert_e2259662102890 : check e2259662102890 [[]] .width = true := by decide
def e2259662102938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259662102938 : Closed e2259662102938 ∧ code e2259662102938 = 11055755125146 := by decide
theorem cert_e2259662102938 : check e2259662102938 [[]] .width = true := by decide
def e2259662106822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662106822 : Closed e2259662106822 ∧ code e2259662106822 = 11055755129030 := by decide
theorem cert_e2259662106822 : check e2259662106822 [[]] .width = true := by decide
def e2259662114330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662114330 : Closed e2259662114330 ∧ code e2259662114330 = 11055755136538 := by decide
private def t_e2259662114330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259662114330 : ¬ IsSelfInterpreter e2259662114330 :=
  wSource (t := t_e2259662114330) (replay_sound (ps := []) (t := e2259662114330) (by decide)) (by decide)
def e2259662123206 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662123206 : Closed e2259662123206 ∧ code e2259662123206 = 11055755145414 := by decide
theorem cert_e2259662123206 : check e2259662123206 [[]] .width = true := by decide
def e2259662164166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662164166 : Closed e2259662164166 ∧ code e2259662164166 = 11055755186374 := by decide
theorem cert_e2259662164166 : check e2259662164166 [[]] .width = true := by decide
def e2259662171674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662171674 : Closed e2259662171674 ∧ code e2259662171674 = 11055755193882 := by decide
theorem cert_e2259662171674 : check e2259662171674 [[]] .width = true := by decide
def e2259662174746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662174746 : Closed e2259662174746 ∧ code e2259662174746 = 11055755196954 := by decide
theorem cert_e2259662174746 : check e2259662174746 [[]] .width = true := by decide
def e2259662213318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662213318 : Closed e2259662213318 ∧ code e2259662213318 = 11055755235526 := by decide
theorem cert_e2259662213318 : check e2259662213318 [[]] .width = true := by decide
def e2259662216730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662216730 : Closed e2259662216730 ∧ code e2259662216730 = 11055755238938 := by decide
theorem cert_e2259662216730 : check e2259662216730 [[]] .width = true := by decide
def e2259662225606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259662225606 : Closed e2259662225606 ∧ code e2259662225606 = 11055755247814 := by decide
theorem cert_e2259662225606 : check e2259662225606 [[]] .width = true := by decide
def e2259662233626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259662233626 : Closed e2259662233626 ∧ code e2259662233626 = 11055755255834 := by decide
theorem cert_e2259662233626 : check e2259662233626 [[]] .width = true := by decide
def e2259662233718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259662233718 : Closed e2259662233718 ∧ code e2259662233718 = 11055755255926 := by decide
theorem cert_e2259662233718 : check e2259662233718 [[]] .width = true := by decide
def e2259662233962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259662233962 : Closed e2259662233962 ∧ code e2259662233962 = 11055755256170 := by decide
theorem cert_e2259662233962 : check e2259662233962 [[]] .width = true := by decide
def e2259662234010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259662234010 : Closed e2259662234010 ∧ code e2259662234010 = 11055755256218 := by decide
theorem cert_e2259662234010 : check e2259662234010 [[]] .width = true := by decide
def e2259662237894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662237894 : Closed e2259662237894 ∧ code e2259662237894 = 11055755260102 := by decide
theorem cert_e2259662237894 : check e2259662237894 [[]] .width = true := by decide
def e2259662250010 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259662250010 : Closed e2259662250010 ∧ code e2259662250010 = 11055755272218 := by decide
theorem cert_e2259662250010 : check e2259662250010 [[]] .width = true := by decide
def e2259662250102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259662250102 : Closed e2259662250102 ∧ code e2259662250102 = 11055755272310 := by decide
theorem cert_e2259662250102 : check e2259662250102 [[]] .width = true := by decide
def e2259662250346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259662250346 : Closed e2259662250346 ∧ code e2259662250346 = 11055755272554 := by decide
theorem cert_e2259662250346 : check e2259662250346 [[]] .width = true := by decide
def e2259662250394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259662250394 : Closed e2259662250394 ∧ code e2259662250394 = 11055755272602 := by decide
theorem cert_e2259662250394 : check e2259662250394 [[]] .width = true := by decide
def e2259662259738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662259738 : Closed e2259662259738 ∧ code e2259662259738 = 11055755281946 := by decide
theorem cert_e2259662259738 : check e2259662259738 [[]] .width = true := by decide
def e2259662262470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662262470 : Closed e2259662262470 ∧ code e2259662262470 = 11055755284678 := by decide
theorem cert_e2259662262470 : check e2259662262470 [[]] .width = true := by decide
def e2259662288410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662288410 : Closed e2259662288410 ∧ code e2259662288410 = 11055755310618 := by decide
theorem cert_e2259662288410 : check e2259662288410 [[]] .width = true := by decide
def e2259662289434 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662289434 : Closed e2259662289434 ∧ code e2259662289434 = 11055755311642 := by decide
theorem cert_e2259662289434 : check e2259662289434 [[]] .width = true := by decide
def e2259662310938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662310938 : Closed e2259662310938 ∧ code e2259662310938 = 11055755333146 := by decide
private def t_e2259662310938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259662310938 : ¬ IsSelfInterpreter e2259662310938 :=
  wSource (t := t_e2259662310938) (replay_sound (ps := []) (t := e2259662310938) (by decide)) (by decide)
def e2259662319814 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662319814 : Closed e2259662319814 ∧ code e2259662319814 = 11055755342022 := by decide
theorem cert_e2259662319814 : check e2259662319814 [[]] .width = true := by decide
def e2259662325274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662325274 : Closed e2259662325274 ∧ code e2259662325274 = 11055755347482 := by decide
theorem cert_e2259662325274 : check e2259662325274 [[]] .width = true := by decide
def e2259662328006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662328006 : Closed e2259662328006 ∧ code e2259662328006 = 11055755350214 := by decide
theorem cert_e2259662328006 : check e2259662328006 [[]] .width = true := by decide
def e2259662467270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662467270 : Closed e2259662467270 ∧ code e2259662467270 = 11055755489478 := by decide
theorem cert_e2259662467270 : check e2259662467270 [[]] .width = true := by decide
def e2259662635034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259662635034 : Closed e2259662635034 ∧ code e2259662635034 = 11055755657242 := by decide
theorem cert_e2259662635034 : check e2259662635034 [[]] .width = true := by decide
def e2259662635126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259662635126 : Closed e2259662635126 ∧ code e2259662635126 = 11055755657334 := by decide
theorem cert_e2259662635126 : check e2259662635126 [[]] .width = true := by decide
def e2259662635370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259662635370 : Closed e2259662635370 ∧ code e2259662635370 = 11055755657578 := by decide
theorem cert_e2259662635370 : check e2259662635370 [[]] .width = true := by decide
def e2259662635418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259662635418 : Closed e2259662635418 ∧ code e2259662635418 = 11055755657626 := by decide
theorem cert_e2259662635418 : check e2259662635418 [[]] .width = true := by decide
def e2259662636426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259662636426 : Closed e2259662636426 ∧ code e2259662636426 = 11055755658634 := by decide
theorem cert_e2259662636426 : check e2259662636426 [[]] .width = true := by decide
def e2259662636450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259662636450 : Closed e2259662636450 ∧ code e2259662636450 = 11055755658658 := by decide
theorem cert_e2259662636450 : check e2259662636450 [[]] .width = true := by decide
def e2259662636558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259662636558 : Closed e2259662636558 ∧ code e2259662636558 = 11055755658766 := by decide
theorem cert_e2259662636558 : check e2259662636558 [[]] .width = true := by decide
def e2259662636570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259662636570 : Closed e2259662636570 ∧ code e2259662636570 = 11055755658778 := by decide
theorem cert_e2259662636570 : check e2259662636570 [[]] .width = true := by decide
def e2259662636642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259662636642 : Closed e2259662636642 ∧ code e2259662636642 = 11055755658850 := by decide
theorem cert_e2259662636642 : check e2259662636642 [[]] .width = true := by decide
def e2259662848198 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259662848198 : Closed e2259662848198 ∧ code e2259662848198 = 11055755870406 := by decide
theorem cert_e2259662848198 : check e2259662848198 [[]] .width = true := by decide
def e2259662868678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662868678 : Closed e2259662868678 ∧ code e2259662868678 = 11055755890886 := by decide
theorem cert_e2259662868678 : check e2259662868678 [[]] .width = true := by decide
def e2259662872090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662872090 : Closed e2259662872090 ∧ code e2259662872090 = 11055755894298 := by decide
theorem cert_e2259662872090 : check e2259662872090 [[]] .width = true := by decide
def e2259662880966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259662880966 : Closed e2259662880966 ∧ code e2259662880966 = 11055755903174 := by decide
theorem cert_e2259662880966 : check e2259662880966 [[]] .width = true := by decide
def e2259662888986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259662888986 : Closed e2259662888986 ∧ code e2259662888986 = 11055755911194 := by decide
theorem cert_e2259662888986 : check e2259662888986 [[]] .width = true := by decide
def e2259662889078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259662889078 : Closed e2259662889078 ∧ code e2259662889078 = 11055755911286 := by decide
theorem cert_e2259662889078 : check e2259662889078 [[]] .width = true := by decide
def e2259662889322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259662889322 : Closed e2259662889322 ∧ code e2259662889322 = 11055755911530 := by decide
theorem cert_e2259662889322 : check e2259662889322 [[]] .width = true := by decide
def e2259662889370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259662889370 : Closed e2259662889370 ∧ code e2259662889370 = 11055755911578 := by decide
theorem cert_e2259662889370 : check e2259662889370 [[]] .width = true := by decide
def e2259662893254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662893254 : Closed e2259662893254 ∧ code e2259662893254 = 11055755915462 := by decide
theorem cert_e2259662893254 : check e2259662893254 [[]] .width = true := by decide
def e2259662900762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259662900762 : Closed e2259662900762 ∧ code e2259662900762 = 11055755922970 := by decide
theorem cert_e2259662900762 : check e2259662900762 [[]] .width = true := by decide
def e2259662909638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259662909638 : Closed e2259662909638 ∧ code e2259662909638 = 11055755931846 := by decide
theorem cert_e2259662909638 : check e2259662909638 [[]] .width = true := by decide
def e2259663192262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259663192262 : Closed e2259663192262 ∧ code e2259663192262 = 11055756214470 := by decide
theorem cert_e2259663192262 : check e2259663192262 [[]] .width = true := by decide
def e2259663192790 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259663192790 : Closed e2259663192790 ∧ code e2259663192790 = 11055756214998 := by decide
theorem cert_e2259663192790 : check e2259663192790 [[]] .width = true := by decide
def e2259663192794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259663192794 : Closed e2259663192794 ∧ code e2259663192794 = 11055756215002 := by decide
theorem cert_e2259663192794 : check e2259663192794 [[]] .width = true := by decide
def e2259663192810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259663192810 : Closed e2259663192810 ∧ code e2259663192810 = 11055756215018 := by decide
theorem cert_e2259663192810 : check e2259663192810 [[]] .width = true := by decide
def e2259663192886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259663192886 : Closed e2259663192886 ∧ code e2259663192886 = 11055756215094 := by decide
theorem cert_e2259663192886 : check e2259663192886 [[]] .width = true := by decide
def e2259663192890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259663192890 : Closed e2259663192890 ∧ code e2259663192890 = 11055756215098 := by decide
theorem cert_e2259663192890 : check e2259663192890 [[]] .width = true := by decide
def e2259663192974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259663192974 : Closed e2259663192974 ∧ code e2259663192974 = 11055756215182 := by decide
theorem cert_e2259663192974 : check e2259663192974 [[]] .width = true := by decide
def e2259663192986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259663192986 : Closed e2259663192986 ∧ code e2259663192986 = 11055756215194 := by decide
theorem cert_e2259663192986 : check e2259663192986 [[]] .width = true := by decide
def e2259663194906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259663194906 : Closed e2259663194906 ∧ code e2259663194906 = 11055756217114 := by decide
theorem cert_e2259663194906 : check e2259663194906 [[]] .width = true := by decide
def e2259663194950 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259663194950 : Closed e2259663194950 ∧ code e2259663194950 = 11055756217158 := by decide
theorem cert_e2259663194950 : check e2259663194950 [[]] .width = true := by decide
def e2259663195062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259663195062 : Closed e2259663195062 ∧ code e2259663195062 = 11055756217270 := by decide
theorem cert_e2259663195062 : check e2259663195062 [[]] .width = true := by decide
def e2259663195190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259663195190 : Closed e2259663195190 ∧ code e2259663195190 = 11055756217398 := by decide
theorem cert_e2259663195190 : check e2259663195190 [[]] .width = true := by decide
def e2259663195194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259663195194 : Closed e2259663195194 ∧ code e2259663195194 = 11055756217402 := by decide
theorem cert_e2259663195194 : check e2259663195194 [[]] .width = true := by decide
def e2259663195334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259663195334 : Closed e2259663195334 ∧ code e2259663195334 = 11055756217542 := by decide
theorem cert_e2259663195334 : check e2259663195334 [[]] .width = true := by decide
def e2259663195674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259663195674 : Closed e2259663195674 ∧ code e2259663195674 = 11055756217882 := by decide
theorem cert_e2259663195674 : check e2259663195674 [[]] .width = true := by decide
def e2259663195766 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259663195766 : Closed e2259663195766 ∧ code e2259663195766 = 11055756217974 := by decide
theorem cert_e2259663195766 : check e2259663195766 [[]] .width = true := by decide
def e2259663203354 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259663203354 : Closed e2259663203354 ∧ code e2259663203354 = 11055756225562 := by decide
theorem cert_e2259663203354 : check e2259663203354 [[]] .width = true := by decide
def e2259663203398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259663203398 : Closed e2259663203398 ∧ code e2259663203398 = 11055756225606 := by decide
theorem cert_e2259663203398 : check e2259663203398 [[]] .width = true := by decide
def e2259663203426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259663203426 : Closed e2259663203426 ∧ code e2259663203426 = 11055756225634 := by decide
theorem cert_e2259663203426 : check e2259663203426 [[]] .width = true := by decide
def e2259663203590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259663203590 : Closed e2259663203590 ∧ code e2259663203590 = 11055756225798 := by decide
theorem cert_e2259663203590 : check e2259663203590 [[]] .width = true := by decide
def e2259663204382 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259663204382 : Closed e2259663204382 ∧ code e2259663204382 = 11055756226590 := by decide
theorem cert_e2259663204382 : check e2259663204382 [[]] .width = true := by decide
def e2259663204550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259663204550 : Closed e2259663204550 ∧ code e2259663204550 = 11055756226758 := by decide
theorem cert_e2259663204550 : check e2259663204550 [[]] .width = true := by decide
def e2259663204578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259663204578 : Closed e2259663204578 ∧ code e2259663204578 = 11055756226786 := by decide
theorem cert_e2259663204578 : check e2259663204578 [[]] .width = true := by decide
def e2259663205126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259663205126 : Closed e2259663205126 ∧ code e2259663205126 = 11055756227334 := by decide
theorem cert_e2259663205126 : check e2259663205126 [[]] .width = true := by decide
def e2259663483078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259663483078 : Closed e2259663483078 ∧ code e2259663483078 = 11055756505286 := by decide
theorem cert_e2259663483078 : check e2259663483078 [[]] .width = true := by decide
def e2259663552538 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259663552538 : Closed e2259663552538 ∧ code e2259663552538 = 11055756574746 := by decide
theorem cert_e2259663552538 : check e2259663552538 [[]] .width = true := by decide
def e2259663552630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259663552630 : Closed e2259663552630 ∧ code e2259663552630 = 11055756574838 := by decide
theorem cert_e2259663552630 : check e2259663552630 [[]] .width = true := by decide
def e2259663552874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259663552874 : Closed e2259663552874 ∧ code e2259663552874 = 11055756575082 := by decide
theorem cert_e2259663552874 : check e2259663552874 [[]] .width = true := by decide
def e2259663552922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259663552922 : Closed e2259663552922 ∧ code e2259663552922 = 11055756575130 := by decide
theorem cert_e2259663552922 : check e2259663552922 [[]] .width = true := by decide
def e2259663553930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259663553930 : Closed e2259663553930 ∧ code e2259663553930 = 11055756576138 := by decide
theorem cert_e2259663553930 : check e2259663553930 [[]] .width = true := by decide
def e2259663553954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259663553954 : Closed e2259663553954 ∧ code e2259663553954 = 11055756576162 := by decide
theorem cert_e2259663553954 : check e2259663553954 [[]] .width = true := by decide
def e2259663554062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259663554062 : Closed e2259663554062 ∧ code e2259663554062 = 11055756576270 := by decide
theorem cert_e2259663554062 : check e2259663554062 [[]] .width = true := by decide
def e2259663554074 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259663554074 : Closed e2259663554074 ∧ code e2259663554074 = 11055756576282 := by decide
theorem cert_e2259663554074 : check e2259663554074 [[]] .width = true := by decide
def e2259663554146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259663554146 : Closed e2259663554146 ∧ code e2259663554146 = 11055756576354 := by decide
theorem cert_e2259663554146 : check e2259663554146 [[]] .width = true := by decide
def e2259663655110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259663655110 : Closed e2259663655110 ∧ code e2259663655110 = 11055756677318 := by decide
theorem cert_e2259663655110 : check e2259663655110 [[]] .width = true := by decide
def e2259663658522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259663658522 : Closed e2259663658522 ∧ code e2259663658522 = 11055756680730 := by decide
theorem cert_e2259663658522 : check e2259663658522 [[]] .width = true := by decide
def e2259663667398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259663667398 : Closed e2259663667398 ∧ code e2259663667398 = 11055756689606 := by decide
theorem cert_e2259663667398 : check e2259663667398 [[]] .width = true := by decide
def e2259663675418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259663675418 : Closed e2259663675418 ∧ code e2259663675418 = 11055756697626 := by decide
theorem cert_e2259663675418 : check e2259663675418 [[]] .width = true := by decide
def e2259663675510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259663675510 : Closed e2259663675510 ∧ code e2259663675510 = 11055756697718 := by decide
theorem cert_e2259663675510 : check e2259663675510 [[]] .width = true := by decide
def e2259663675754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259663675754 : Closed e2259663675754 ∧ code e2259663675754 = 11055756697962 := by decide
theorem cert_e2259663675754 : check e2259663675754 [[]] .width = true := by decide
def e2259663675802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259663675802 : Closed e2259663675802 ∧ code e2259663675802 = 11055756698010 := by decide
theorem cert_e2259663675802 : check e2259663675802 [[]] .width = true := by decide
def e2259663679686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259663679686 : Closed e2259663679686 ∧ code e2259663679686 = 11055756701894 := by decide
theorem cert_e2259663679686 : check e2259663679686 [[]] .width = true := by decide
def e2259663691802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259663691802 : Closed e2259663691802 ∧ code e2259663691802 = 11055756714010 := by decide
theorem cert_e2259663691802 : check e2259663691802 [[]] .width = true := by decide
def e2259663691894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259663691894 : Closed e2259663691894 ∧ code e2259663691894 = 11055756714102 := by decide
theorem cert_e2259663691894 : check e2259663691894 [[]] .width = true := by decide
def e2259663692138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259663692138 : Closed e2259663692138 ∧ code e2259663692138 = 11055756714346 := by decide
theorem cert_e2259663692138 : check e2259663692138 [[]] .width = true := by decide
def e2259663692186 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259663692186 : Closed e2259663692186 ∧ code e2259663692186 = 11055756714394 := by decide
theorem cert_e2259663692186 : check e2259663692186 [[]] .width = true := by decide
def e2259663701530 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259663701530 : Closed e2259663701530 ∧ code e2259663701530 = 11055756723738 := by decide
theorem cert_e2259663701530 : check e2259663701530 [[]] .width = true := by decide
def e2259663704262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259663704262 : Closed e2259663704262 ∧ code e2259663704262 = 11055756726470 := by decide
theorem cert_e2259663704262 : check e2259663704262 [[]] .width = true := by decide
def e2259663716550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259663716550 : Closed e2259663716550 ∧ code e2259663716550 = 11055756738758 := by decide
theorem cert_e2259663716550 : check e2259663716550 [[]] .width = true := by decide
def e2259663717078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259663717078 : Closed e2259663717078 ∧ code e2259663717078 = 11055756739286 := by decide
theorem cert_e2259663717078 : check e2259663717078 [[]] .width = true := by decide
def e2259663717082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259663717082 : Closed e2259663717082 ∧ code e2259663717082 = 11055756739290 := by decide
theorem cert_e2259663717082 : check e2259663717082 [[]] .width = true := by decide
def e2259663717098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259663717098 : Closed e2259663717098 ∧ code e2259663717098 = 11055756739306 := by decide
theorem cert_e2259663717098 : check e2259663717098 [[]] .width = true := by decide
def e2259663717174 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259663717174 : Closed e2259663717174 ∧ code e2259663717174 = 11055756739382 := by decide
theorem cert_e2259663717174 : check e2259663717174 [[]] .width = true := by decide
def e2259663717178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259663717178 : Closed e2259663717178 ∧ code e2259663717178 = 11055756739386 := by decide
theorem cert_e2259663717178 : check e2259663717178 [[]] .width = true := by decide
def e2259663717262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259663717262 : Closed e2259663717262 ∧ code e2259663717262 = 11055756739470 := by decide
theorem cert_e2259663717262 : check e2259663717262 [[]] .width = true := by decide
def e2259663717274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259663717274 : Closed e2259663717274 ∧ code e2259663717274 = 11055756739482 := by decide
theorem cert_e2259663717274 : check e2259663717274 [[]] .width = true := by decide
def e2259663719194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259663719194 : Closed e2259663719194 ∧ code e2259663719194 = 11055756741402 := by decide
theorem cert_e2259663719194 : check e2259663719194 [[]] .width = true := by decide
def e2259663719238 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259663719238 : Closed e2259663719238 ∧ code e2259663719238 = 11055756741446 := by decide
theorem cert_e2259663719238 : check e2259663719238 [[]] .width = true := by decide
def e2259663719350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259663719350 : Closed e2259663719350 ∧ code e2259663719350 = 11055756741558 := by decide
theorem cert_e2259663719350 : check e2259663719350 [[]] .width = true := by decide
def e2259663719478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259663719478 : Closed e2259663719478 ∧ code e2259663719478 = 11055756741686 := by decide
theorem cert_e2259663719478 : check e2259663719478 [[]] .width = true := by decide
def e2259663719482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259663719482 : Closed e2259663719482 ∧ code e2259663719482 = 11055756741690 := by decide
theorem cert_e2259663719482 : check e2259663719482 [[]] .width = true := by decide
def e2259663719622 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259663719622 : Closed e2259663719622 ∧ code e2259663719622 = 11055756741830 := by decide
theorem cert_e2259663719622 : check e2259663719622 [[]] .width = true := by decide
def e2259663719962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259663719962 : Closed e2259663719962 ∧ code e2259663719962 = 11055756742170 := by decide
theorem cert_e2259663719962 : check e2259663719962 [[]] .width = true := by decide
def e2259663720054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259663720054 : Closed e2259663720054 ∧ code e2259663720054 = 11055756742262 := by decide
theorem cert_e2259663720054 : check e2259663720054 [[]] .width = true := by decide
def e2259663727642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259663727642 : Closed e2259663727642 ∧ code e2259663727642 = 11055756749850 := by decide
theorem cert_e2259663727642 : check e2259663727642 [[]] .width = true := by decide
def e2259663727686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259663727686 : Closed e2259663727686 ∧ code e2259663727686 = 11055756749894 := by decide
theorem cert_e2259663727686 : check e2259663727686 [[]] .width = true := by decide
def e2259663727714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259663727714 : Closed e2259663727714 ∧ code e2259663727714 = 11055756749922 := by decide
theorem cert_e2259663727714 : check e2259663727714 [[]] .width = true := by decide
def e2259663727878 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259663727878 : Closed e2259663727878 ∧ code e2259663727878 = 11055756750086 := by decide
theorem cert_e2259663727878 : check e2259663727878 [[]] .width = true := by decide
def e2259663728670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259663728670 : Closed e2259663728670 ∧ code e2259663728670 = 11055756750878 := by decide
theorem cert_e2259663728670 : check e2259663728670 [[]] .width = true := by decide
def e2259663728838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259663728838 : Closed e2259663728838 ∧ code e2259663728838 = 11055756751046 := by decide
theorem cert_e2259663728838 : check e2259663728838 [[]] .width = true := by decide
def e2259663728866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259663728866 : Closed e2259663728866 ∧ code e2259663728866 = 11055756751074 := by decide
theorem cert_e2259663728866 : check e2259663728866 [[]] .width = true := by decide
def e2259663729414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259663729414 : Closed e2259663729414 ∧ code e2259663729414 = 11055756751622 := by decide
theorem cert_e2259663729414 : check e2259663729414 [[]] .width = true := by decide
def e2259664080410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259664080410 : Closed e2259664080410 ∧ code e2259664080410 = 11055757102618 := by decide
theorem cert_e2259664080410 : check e2259664080410 [[]] .width = true := by decide
def e2259664089286 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259664089286 : Closed e2259664089286 ∧ code e2259664089286 = 11055757111494 := by decide
theorem cert_e2259664089286 : check e2259664089286 [[]] .width = true := by decide
def e2259664094746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259664094746 : Closed e2259664094746 ∧ code e2259664094746 = 11055757116954 := by decide
theorem cert_e2259664094746 : check e2259664094746 [[]] .width = true := by decide
def e2259664097478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259664097478 : Closed e2259664097478 ∧ code e2259664097478 = 11055757119686 := by decide
theorem cert_e2259664097478 : check e2259664097478 [[]] .width = true := by decide
def e2260092410590 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2260092410590 : Closed e2260092410590 ∧ code e2260092410590 = 11056185432798 := by decide
theorem cert_e2260092410590 : check e2260092410590 [[],[.under]] .three = true := by decide
def e2260092410614 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2260092410614 : Closed e2260092410614 ∧ code e2260092410614 = 11056185432822 := by decide
theorem cert_e2260092410614 : check e2260092410614 [[],[.under]] .three = true := by decide
def e2260092410718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2260092410718 : Closed e2260092410718 ∧ code e2260092410718 = 11056185432926 := by decide
theorem cert_e2260092410718 : check e2260092410718 [[],[.under]] .three = true := by decide
def e2260092410734 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2260092410734 : Closed e2260092410734 ∧ code e2260092410734 = 11056185432942 := by decide
theorem cert_e2260092410734 : check e2260092410734 [[],[.under]] .smaller = true := by decide
def e2260092410742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2260092410742 : Closed e2260092410742 ∧ code e2260092410742 = 11056185432950 := by decide
theorem cert_e2260092410742 : check e2260092410742 [[],[.under]] .smaller = true := by decide
def e2260092410746 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2260092410746 : Closed e2260092410746 ∧ code e2260092410746 = 11056185432954 := by decide
theorem cert_e2260092410746 : check e2260092410746 [[],[.under]] .three = true := by decide
def e2260092410806 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2260092410806 : Closed e2260092410806 ∧ code e2260092410806 = 11056185433014 := by decide
theorem cert_e2260092410806 : check e2260092410806 [[],[.under]] .smaller = true := by decide
def e2260092410838 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2260092410838 : Closed e2260092410838 ∧ code e2260092410838 = 11056185433046 := by decide
theorem cert_e2260092410838 : check e2260092410838 [[],[.under]] .three = true := by decide
def e2260092410842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2260092410842 : Closed e2260092410842 ∧ code e2260092410842 = 11056185433050 := by decide
theorem cert_e2260092410842 : check e2260092410842 [[],[.under]] .three = true := by decide
def e2260092411230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2260092411230 : Closed e2260092411230 ∧ code e2260092411230 = 11056185433438 := by decide
theorem cert_e2260092411230 : check e2260092411230 [[],[.under]] .three = true := by decide
def e2260092411246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2260092411246 : Closed e2260092411246 ∧ code e2260092411246 = 11056185433454 := by decide
theorem cert_e2260092411246 : check e2260092411246 [[],[.under]] .smaller = true := by decide
def e2260092411254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2260092411254 : Closed e2260092411254 ∧ code e2260092411254 = 11056185433462 := by decide
theorem cert_e2260092411254 : check e2260092411254 [[],[.under]] .smaller = true := by decide
def e2260092411258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2260092411258 : Closed e2260092411258 ∧ code e2260092411258 = 11056185433466 := by decide
theorem cert_e2260092411258 : check e2260092411258 [[],[.under]] .three = true := by decide
def e2260092411310 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2260092411310 : Closed e2260092411310 ∧ code e2260092411310 = 11056185433518 := by decide
theorem cert_e2260092411310 : check e2260092411310 [[],[.under]] .smaller = true := by decide
def e2260092411322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2260092411322 : Closed e2260092411322 ∧ code e2260092411322 = 11056185433530 := by decide
theorem cert_e2260092411322 : check e2260092411322 [[],[.under]] .smaller = true := by decide
def e2260092411350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2260092411350 : Closed e2260092411350 ∧ code e2260092411350 = 11056185433558 := by decide
theorem cert_e2260092411350 : check e2260092411350 [[],[.under]] .smaller = true := by decide
def e2260092411354 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2260092411354 : Closed e2260092411354 ∧ code e2260092411354 = 11056185433562 := by decide
theorem cert_e2260092411354 : check e2260092411354 [[],[.under]] .smaller = true := by decide
def e2260092411370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2260092411370 : Closed e2260092411370 ∧ code e2260092411370 = 11056185433578 := by decide
theorem cert_e2260092411370 : check e2260092411370 [[],[.under]] .three = true := by decide
def e2260092411574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2260092411574 : Closed e2260092411574 ∧ code e2260092411574 = 11056185433782 := by decide
theorem cert_e2260092411574 : check e2260092411574 [[],[.under]] .smaller = true := by decide
def e2260092411606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2260092411606 : Closed e2260092411606 ∧ code e2260092411606 = 11056185433814 := by decide
theorem cert_e2260092411606 : check e2260092411606 [[],[.under]] .smaller = true := by decide
def e2260092411610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2260092411610 : Closed e2260092411610 ∧ code e2260092411610 = 11056185433818 := by decide
theorem cert_e2260092411610 : check e2260092411610 [[],[.under]] .smaller = true := by decide
def e2260092411734 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2260092411734 : Closed e2260092411734 ∧ code e2260092411734 = 11056185433942 := by decide
theorem cert_e2260092411734 : check e2260092411734 [[],[.under]] .three = true := by decide
def e2260092411738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2260092411738 : Closed e2260092411738 ∧ code e2260092411738 = 11056185433946 := by decide
theorem cert_e2260092411738 : check e2260092411738 [[],[.under]] .three = true := by decide
def e2260092411754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2260092411754 : Closed e2260092411754 ∧ code e2260092411754 = 11056185433962 := by decide
theorem cert_e2260092411754 : check e2260092411754 [[],[.under]] .three = true := by decide
def e2260092413662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2260092413662 : Closed e2260092413662 ∧ code e2260092413662 = 11056185435870 := by decide
theorem cert_e2260092413662 : check e2260092413662 [[],[.under]] .three = true := by decide
def e2260092413686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2260092413686 : Closed e2260092413686 ∧ code e2260092413686 = 11056185435894 := by decide
theorem cert_e2260092413686 : check e2260092413686 [[],[.under]] .three = true := by decide
def e2260092413790 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2260092413790 : Closed e2260092413790 ∧ code e2260092413790 = 11056185435998 := by decide
theorem cert_e2260092413790 : check e2260092413790 [[],[.under]] .three = true := by decide
def e2260092413806 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2260092413806 : Closed e2260092413806 ∧ code e2260092413806 = 11056185436014 := by decide
theorem cert_e2260092413806 : check e2260092413806 [[],[.under]] .smaller = true := by decide
def e2260092413814 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2260092413814 : Closed e2260092413814 ∧ code e2260092413814 = 11056185436022 := by decide
theorem cert_e2260092413814 : check e2260092413814 [[],[.under]] .smaller = true := by decide
def e2260092413818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2260092413818 : Closed e2260092413818 ∧ code e2260092413818 = 11056185436026 := by decide
theorem cert_e2260092413818 : check e2260092413818 [[],[.under]] .three = true := by decide
def e2260092413878 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2260092413878 : Closed e2260092413878 ∧ code e2260092413878 = 11056185436086 := by decide
theorem cert_e2260092413878 : check e2260092413878 [[],[.under]] .smaller = true := by decide
def e2260092413910 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2260092413910 : Closed e2260092413910 ∧ code e2260092413910 = 11056185436118 := by decide
theorem cert_e2260092413910 : check e2260092413910 [[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2259662114330
#print axioms Blc.Floor43.cert_e2259662310938
