import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374031194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2422374031194 : Closed e2422374031194 ∧ code e2422374031194 = 11218467053402 := by decide
theorem cert_e2422374031194 : check e2422374031194 [[],[]] .three = true := by decide
def e2422374031210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2422374031210 : Closed e2422374031210 ∧ code e2422374031210 = 11218467053418 := by decide
theorem cert_e2422374031210 : check e2422374031210 [[],[]] .three = true := by decide
def e2422374031598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2)))))))
theorem wire_e2422374031598 : Closed e2422374031598 ∧ code e2422374031598 = 11218467053806 := by decide
theorem cert_e2422374031598 : check e2422374031598 [[],[]] .three = true := by decide
def e2422374031606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 1)))))))
theorem wire_e2422374031606 : Closed e2422374031606 ∧ code e2422374031606 = 11218467053814 := by decide
theorem cert_e2422374031606 : check e2422374031606 [[],[]] .three = true := by decide
def e2422374031610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e2422374031610 : Closed e2422374031610 ∧ code e2422374031610 = 11218467053818 := by decide
theorem cert_e2422374031610 : check e2422374031610 [[],[]] .three = true := by decide
def e2422374031790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e2422374031790 : Closed e2422374031790 ∧ code e2422374031790 = 11218467053998 := by decide
theorem cert_e2422374031790 : check e2422374031790 [[],[]] .three = true := by decide
def e2422374031798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e2422374031798 : Closed e2422374031798 ∧ code e2422374031798 = 11218467054006 := by decide
theorem cert_e2422374031798 : check e2422374031798 [[],[]] .three = true := by decide
def e2422374031802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422374031802 : Closed e2422374031802 ∧ code e2422374031802 = 11218467054010 := by decide
theorem cert_e2422374031802 : check e2422374031802 [[],[]] .three = true := by decide
def e2422374031830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e2422374031830 : Closed e2422374031830 ∧ code e2422374031830 = 11218467054038 := by decide
theorem cert_e2422374031830 : check e2422374031830 [[],[]] .three = true := by decide
def e2422374031850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422374031850 : Closed e2422374031850 ∧ code e2422374031850 = 11218467054058 := by decide
theorem cert_e2422374031850 : check e2422374031850 [[],[]] .three = true := by decide
def e2422374031982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422374031982 : Closed e2422374031982 ∧ code e2422374031982 = 11218467054190 := by decide
theorem cert_e2422374031982 : check e2422374031982 [[],[]] .three = true := by decide
def e2422374031990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422374031990 : Closed e2422374031990 ∧ code e2422374031990 = 11218467054198 := by decide
theorem cert_e2422374031990 : check e2422374031990 [[],[]] .three = true := by decide
def e2422374031994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422374031994 : Closed e2422374031994 ∧ code e2422374031994 = 11218467054202 := by decide
theorem cert_e2422374031994 : check e2422374031994 [[],[]] .three = true := by decide
def e2422374032158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3))))))))
theorem wire_e2422374032158 : Closed e2422374032158 ∧ code e2422374032158 = 11218467054366 := by decide
theorem cert_e2422374032158 : check e2422374032158 [[],[]] .three = true := by decide
def e2422374032182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422374032182 : Closed e2422374032182 ∧ code e2422374032182 = 11218467054390 := by decide
theorem cert_e2422374032182 : check e2422374032182 [[],[]] .three = true := by decide
def e2422374032186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422374032186 : Closed e2422374032186 ∧ code e2422374032186 = 11218467054394 := by decide
theorem cert_e2422374032186 : check e2422374032186 [[],[]] .three = true := by decide
def e2422374032270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 2))))))))
theorem wire_e2422374032270 : Closed e2422374032270 ∧ code e2422374032270 = 11218467054478 := by decide
theorem cert_e2422374032270 : check e2422374032270 [[],[]] .three = true := by decide
def e2422374032282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422374032282 : Closed e2422374032282 ∧ code e2422374032282 = 11218467054490 := by decide
theorem cert_e2422374032282 : check e2422374032282 [[],[]] .three = true := by decide
def e2422374032326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e2422374032326 : Closed e2422374032326 ∧ code e2422374032326 = 11218467054534 := by decide
theorem cert_e2422374032326 : check e2422374032326 [[],[]] .three = true := by decide
def e2422374032350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 3)))) (.var 3)))))))
theorem wire_e2422374032350 : Closed e2422374032350 ∧ code e2422374032350 = 11218467054558 := by decide
theorem cert_e2422374032350 : check e2422374032350 [[],[]] .three = true := by decide
def e2422374032366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 4)))) (.var 2)))))))
theorem wire_e2422374032366 : Closed e2422374032366 ∧ code e2422374032366 = 11218467054574 := by decide
theorem cert_e2422374032366 : check e2422374032366 [[],[]] .three = true := by decide
def e2422374032942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422374032942 : Closed e2422374032942 ∧ code e2422374032942 = 11218467055150 := by decide
theorem cert_e2422374032942 : check e2422374032942 [[],[]] .three = true := by decide
def e2422374032950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e2422374032950 : Closed e2422374032950 ∧ code e2422374032950 = 11218467055158 := by decide
theorem cert_e2422374032950 : check e2422374032950 [[],[]] .three = true := by decide
def e2422374032954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422374032954 : Closed e2422374032954 ∧ code e2422374032954 = 11218467055162 := by decide
theorem cert_e2422374032954 : check e2422374032954 [[],[]] .three = true := by decide
def e2422374033038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e2422374033038 : Closed e2422374033038 ∧ code e2422374033038 = 11218467055246 := by decide
theorem cert_e2422374033038 : check e2422374033038 [[],[]] .three = true := by decide
def e2422374033094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422374033094 : Closed e2422374033094 ∧ code e2422374033094 = 11218467055302 := by decide
theorem cert_e2422374033094 : check e2422374033094 [[],[]] .three = true := by decide
def e2422374033118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e2422374033118 : Closed e2422374033118 ∧ code e2422374033118 = 11218467055326 := by decide
theorem cert_e2422374033118 : check e2422374033118 [[],[]] .three = true := by decide
def e2422374033122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422374033122 : Closed e2422374033122 ∧ code e2422374033122 = 11218467055330 := by decide
theorem cert_e2422374033122 : check e2422374033122 [[],[]] .three = true := by decide
def e2422374033134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e2422374033134 : Closed e2422374033134 ∧ code e2422374033134 = 11218467055342 := by decide
theorem cert_e2422374033134 : check e2422374033134 [[],[]] .three = true := by decide
def e2422374033142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2422374033142 : Closed e2422374033142 ∧ code e2422374033142 = 11218467055350 := by decide
theorem cert_e2422374033142 : check e2422374033142 [[],[]] .three = true := by decide
def e2422374033174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422374033174 : Closed e2422374033174 ∧ code e2422374033174 = 11218467055382 := by decide
theorem cert_e2422374033174 : check e2422374033174 [[],[]] .three = true := by decide
def e2422374033178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e2422374033178 : Closed e2422374033178 ∧ code e2422374033178 = 11218467055386 := by decide
theorem cert_e2422374033178 : check e2422374033178 [[],[]] .three = true := by decide
def e2422374033222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e2422374033222 : Closed e2422374033222 ∧ code e2422374033222 = 11218467055430 := by decide
theorem cert_e2422374033222 : check e2422374033222 [[],[]] .three = true := by decide
def e2422374033246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e2422374033246 : Closed e2422374033246 ∧ code e2422374033246 = 11218467055454 := by decide
theorem cert_e2422374033246 : check e2422374033246 [[],[]] .three = true := by decide
def e2422374033250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422374033250 : Closed e2422374033250 ∧ code e2422374033250 = 11218467055458 := by decide
theorem cert_e2422374033250 : check e2422374033250 [[],[]] .three = true := by decide
def e2422374033262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e2422374033262 : Closed e2422374033262 ∧ code e2422374033262 = 11218467055470 := by decide
theorem cert_e2422374033262 : check e2422374033262 [[],[]] .three = true := by decide
def e2422374033270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e2422374033270 : Closed e2422374033270 ∧ code e2422374033270 = 11218467055478 := by decide
theorem cert_e2422374033270 : check e2422374033270 [[],[]] .three = true := by decide
def e2422374033274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2422374033274 : Closed e2422374033274 ∧ code e2422374033274 = 11218467055482 := by decide
theorem cert_e2422374033274 : check e2422374033274 [[],[]] .three = true := by decide
def e2422374033290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422374033290 : Closed e2422374033290 ∧ code e2422374033290 = 11218467055498 := by decide
theorem cert_e2422374033290 : check e2422374033290 [[],[]] .three = true := by decide
def e2422374033314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422374033314 : Closed e2422374033314 ∧ code e2422374033314 = 11218467055522 := by decide
theorem cert_e2422374033314 : check e2422374033314 [[],[]] .three = true := by decide
def e2422374033326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e2422374033326 : Closed e2422374033326 ∧ code e2422374033326 = 11218467055534 := by decide
theorem cert_e2422374033326 : check e2422374033326 [[],[]] .three = true := by decide
def e2422374033334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e2422374033334 : Closed e2422374033334 ∧ code e2422374033334 = 11218467055542 := by decide
theorem cert_e2422374033334 : check e2422374033334 [[],[]] .three = true := by decide
def e2422374033338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e2422374033338 : Closed e2422374033338 ∧ code e2422374033338 = 11218467055546 := by decide
theorem cert_e2422374033338 : check e2422374033338 [[],[]] .three = true := by decide
def e2422374033366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2422374033366 : Closed e2422374033366 ∧ code e2422374033366 = 11218467055574 := by decide
theorem cert_e2422374033366 : check e2422374033366 [[],[]] .three = true := by decide
def e2422374033370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2422374033370 : Closed e2422374033370 ∧ code e2422374033370 = 11218467055578 := by decide
theorem cert_e2422374033370 : check e2422374033370 [[],[]] .three = true := by decide
def e2422374033470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4)))))))))
theorem wire_e2422374033470 : Closed e2422374033470 ∧ code e2422374033470 = 11218467055678 := by decide
theorem cert_e2422374033470 : check e2422374033470 [[],[]] .three = true := by decide
def e2422374033518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374033518 : Closed e2422374033518 ∧ code e2422374033518 = 11218467055726 := by decide
theorem cert_e2422374033518 : check e2422374033518 [[],[]] .three = true := by decide
def e2422374033530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374033530 : Closed e2422374033530 ∧ code e2422374033530 = 11218467055738 := by decide
theorem cert_e2422374033530 : check e2422374033530 [[],[]] .three = true := by decide
def e2422374033806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422374033806 : Closed e2422374033806 ∧ code e2422374033806 = 11218467056014 := by decide
theorem cert_e2422374033806 : check e2422374033806 [[],[]] .three = true := by decide
def e2422374033862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422374033862 : Closed e2422374033862 ∧ code e2422374033862 = 11218467056070 := by decide
theorem cert_e2422374033862 : check e2422374033862 [[],[]] .three = true := by decide
def e2422374033886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422374033886 : Closed e2422374033886 ∧ code e2422374033886 = 11218467056094 := by decide
theorem cert_e2422374033886 : check e2422374033886 [[],[]] .three = true := by decide
def e2422374033890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422374033890 : Closed e2422374033890 ∧ code e2422374033890 = 11218467056098 := by decide
theorem cert_e2422374033890 : check e2422374033890 [[],[]] .three = true := by decide
def e2422374033902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422374033902 : Closed e2422374033902 ∧ code e2422374033902 = 11218467056110 := by decide
theorem cert_e2422374033902 : check e2422374033902 [[],[]] .three = true := by decide
def e2422374033910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422374033910 : Closed e2422374033910 ∧ code e2422374033910 = 11218467056118 := by decide
theorem cert_e2422374033910 : check e2422374033910 [[],[]] .three = true := by decide
def e2422374034462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.lam (.var 3)))))))))
theorem wire_e2422374034462 : Closed e2422374034462 ∧ code e2422374034462 = 11218467056670 := by decide
theorem cert_e2422374034462 : check e2422374034462 [[],[]] .three = true := by decide
def e2422374034486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374034486 : Closed e2422374034486 ∧ code e2422374034486 = 11218467056694 := by decide
theorem cert_e2422374034486 : check e2422374034486 [[],[]] .three = true := by decide
def e2422374034490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374034490 : Closed e2422374034490 ∧ code e2422374034490 = 11218467056698 := by decide
theorem cert_e2422374034490 : check e2422374034490 [[],[]] .three = true := by decide
def e2422374034630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422374034630 : Closed e2422374034630 ∧ code e2422374034630 = 11218467056838 := by decide
theorem cert_e2422374034630 : check e2422374034630 [[],[]] .three = true := by decide
def e2422374034654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422374034654 : Closed e2422374034654 ∧ code e2422374034654 = 11218467056862 := by decide
theorem cert_e2422374034654 : check e2422374034654 [[],[]] .three = true := by decide
def e2422374034658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422374034658 : Closed e2422374034658 ∧ code e2422374034658 = 11218467056866 := by decide
theorem cert_e2422374034658 : check e2422374034658 [[],[]] .three = true := by decide
def e2422374034670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422374034670 : Closed e2422374034670 ∧ code e2422374034670 = 11218467056878 := by decide
theorem cert_e2422374034670 : check e2422374034670 [[],[]] .three = true := by decide
def e2422374034678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422374034678 : Closed e2422374034678 ∧ code e2422374034678 = 11218467056886 := by decide
theorem cert_e2422374034678 : check e2422374034678 [[],[]] .three = true := by decide
def e2422374034682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422374034682 : Closed e2422374034682 ∧ code e2422374034682 = 11218467056890 := by decide
theorem cert_e2422374034682 : check e2422374034682 [[],[]] .three = true := by decide
def e2422374034958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422374034958 : Closed e2422374034958 ∧ code e2422374034958 = 11218467057166 := by decide
theorem cert_e2422374034958 : check e2422374034958 [[],[]] .three = true := by decide
def e2422374034970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374034970 : Closed e2422374034970 ∧ code e2422374034970 = 11218467057178 := by decide
theorem cert_e2422374034970 : check e2422374034970 [[],[]] .three = true := by decide
def e2422374035006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.lam (.var 4))))))))
theorem wire_e2422374035006 : Closed e2422374035006 ∧ code e2422374035006 = 11218467057214 := by decide
theorem cert_e2422374035006 : check e2422374035006 [[],[]] .three = true := by decide
def e2422374035042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422374035042 : Closed e2422374035042 ∧ code e2422374035042 = 11218467057250 := by decide
theorem cert_e2422374035042 : check e2422374035042 [[],[]] .three = true := by decide
def e2422374035054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422374035054 : Closed e2422374035054 ∧ code e2422374035054 = 11218467057262 := by decide
theorem cert_e2422374035054 : check e2422374035054 [[],[]] .three = true := by decide
def e2422374035062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422374035062 : Closed e2422374035062 ∧ code e2422374035062 = 11218467057270 := by decide
theorem cert_e2422374035062 : check e2422374035062 [[],[]] .three = true := by decide
def e2422374035066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422374035066 : Closed e2422374035066 ∧ code e2422374035066 = 11218467057274 := by decide
theorem cert_e2422374035066 : check e2422374035066 [[],[]] .three = true := by decide
def e2422374035230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.lam (.var 3))))))))
theorem wire_e2422374035230 : Closed e2422374035230 ∧ code e2422374035230 = 11218467057438 := by decide
theorem cert_e2422374035230 : check e2422374035230 [[],[]] .three = true := by decide
def e2422374035254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422374035254 : Closed e2422374035254 ∧ code e2422374035254 = 11218467057462 := by decide
theorem cert_e2422374035254 : check e2422374035254 [[],[]] .three = true := by decide
def e2422374035258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422374035258 : Closed e2422374035258 ∧ code e2422374035258 = 11218467057466 := by decide
theorem cert_e2422374035258 : check e2422374035258 [[],[]] .three = true := by decide
def e2422374035574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422374035574 : Closed e2422374035574 ∧ code e2422374035574 = 11218467057782 := by decide
theorem cert_e2422374035574 : check e2422374035574 [[],[]] .three = true := by decide
def e2422374035578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422374035578 : Closed e2422374035578 ∧ code e2422374035578 = 11218467057786 := by decide
theorem cert_e2422374035578 : check e2422374035578 [[],[]] .three = true := by decide
def e2422374035674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e2422374035674 : Closed e2422374035674 ∧ code e2422374035674 = 11218467057882 := by decide
theorem cert_e2422374035674 : check e2422374035674 [[],[]] .three = true := by decide
def e2422374035690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e2422374035690 : Closed e2422374035690 ∧ code e2422374035690 = 11218467057898 := by decide
theorem cert_e2422374035690 : check e2422374035690 [[],[]] .three = true := by decide
def e2422374035766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422374035766 : Closed e2422374035766 ∧ code e2422374035766 = 11218467057974 := by decide
theorem cert_e2422374035766 : check e2422374035766 [[],[]] .three = true := by decide
def e2422374035770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422374035770 : Closed e2422374035770 ∧ code e2422374035770 = 11218467057978 := by decide
theorem cert_e2422374035770 : check e2422374035770 [[],[]] .three = true := by decide
def e2422374035854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422374035854 : Closed e2422374035854 ∧ code e2422374035854 = 11218467058062 := by decide
theorem cert_e2422374035854 : check e2422374035854 [[],[]] .three = true := by decide
def e2422374035866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422374035866 : Closed e2422374035866 ∧ code e2422374035866 = 11218467058074 := by decide
theorem cert_e2422374035866 : check e2422374035866 [[],[]] .three = true := by decide
def e2422374035910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422374035910 : Closed e2422374035910 ∧ code e2422374035910 = 11218467058118 := by decide
theorem cert_e2422374035910 : check e2422374035910 [[],[]] .three = true := by decide
def e2422374035950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2422374035950 : Closed e2422374035950 ∧ code e2422374035950 = 11218467058158 := by decide
theorem cert_e2422374035950 : check e2422374035950 [[],[]] .three = true := by decide
def e2422374036246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422374036246 : Closed e2422374036246 ∧ code e2422374036246 = 11218467058454 := by decide
theorem cert_e2422374036246 : check e2422374036246 [[],[]] .three = true := by decide
def e2422374036250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e2422374036250 : Closed e2422374036250 ∧ code e2422374036250 = 11218467058458 := by decide
theorem cert_e2422374036250 : check e2422374036250 [[],[]] .three = true := by decide
def e2422374036294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e2422374036294 : Closed e2422374036294 ∧ code e2422374036294 = 11218467058502 := by decide
theorem cert_e2422374036294 : check e2422374036294 [[],[]] .three = true := by decide
def e2422374036318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e2422374036318 : Closed e2422374036318 ∧ code e2422374036318 = 11218467058526 := by decide
theorem cert_e2422374036318 : check e2422374036318 [[],[]] .three = true := by decide
def e2422374036322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422374036322 : Closed e2422374036322 ∧ code e2422374036322 = 11218467058530 := by decide
theorem cert_e2422374036322 : check e2422374036322 [[],[]] .three = true := by decide
def e2422374036334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2422374036334 : Closed e2422374036334 ∧ code e2422374036334 = 11218467058542 := by decide
theorem cert_e2422374036334 : check e2422374036334 [[],[]] .three = true := by decide
def e2422374036342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2422374036342 : Closed e2422374036342 ∧ code e2422374036342 = 11218467058550 := by decide
theorem cert_e2422374036342 : check e2422374036342 [[],[]] .three = true := by decide
def e2422374036346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2422374036346 : Closed e2422374036346 ∧ code e2422374036346 = 11218467058554 := by decide
theorem cert_e2422374036346 : check e2422374036346 [[],[]] .three = true := by decide
def e2422374036362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422374036362 : Closed e2422374036362 ∧ code e2422374036362 = 11218467058570 := by decide
theorem cert_e2422374036362 : check e2422374036362 [[],[]] .three = true := by decide
def e2422374036386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422374036386 : Closed e2422374036386 ∧ code e2422374036386 = 11218467058594 := by decide
theorem cert_e2422374036386 : check e2422374036386 [[],[]] .three = true := by decide
def e2422374036398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2422374036398 : Closed e2422374036398 ∧ code e2422374036398 = 11218467058606 := by decide
theorem cert_e2422374036398 : check e2422374036398 [[],[]] .three = true := by decide
def e2422374036410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2422374036410 : Closed e2422374036410 ∧ code e2422374036410 = 11218467058618 := by decide
theorem cert_e2422374036410 : check e2422374036410 [[],[]] .three = true := by decide
def e2422374036438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2422374036438 : Closed e2422374036438 ∧ code e2422374036438 = 11218467058646 := by decide
theorem cert_e2422374036438 : check e2422374036438 [[],[]] .three = true := by decide
def e2422374036442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2422374036442 : Closed e2422374036442 ∧ code e2422374036442 = 11218467058650 := by decide
theorem cert_e2422374036442 : check e2422374036442 [[],[]] .three = true := by decide
def e2422374036458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2422374036458 : Closed e2422374036458 ∧ code e2422374036458 = 11218467058666 := by decide
theorem cert_e2422374036458 : check e2422374036458 [[],[]] .three = true := by decide
def e2422374036510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.lam (.var 3)))))))))
theorem wire_e2422374036510 : Closed e2422374036510 ∧ code e2422374036510 = 11218467058718 := by decide
theorem cert_e2422374036510 : check e2422374036510 [[],[]] .three = true := by decide
def e2422374036534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374036534 : Closed e2422374036534 ∧ code e2422374036534 = 11218467058742 := by decide
theorem cert_e2422374036534 : check e2422374036534 [[],[]] .three = true := by decide
def e2422374036538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374036538 : Closed e2422374036538 ∧ code e2422374036538 = 11218467058746 := by decide
theorem cert_e2422374036538 : check e2422374036538 [[],[]] .three = true := by decide
def e2422374036678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422374036678 : Closed e2422374036678 ∧ code e2422374036678 = 11218467058886 := by decide
theorem cert_e2422374036678 : check e2422374036678 [[],[]] .three = true := by decide
def e2422374036702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422374036702 : Closed e2422374036702 ∧ code e2422374036702 = 11218467058910 := by decide
theorem cert_e2422374036702 : check e2422374036702 [[],[]] .three = true := by decide
def e2422374036706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422374036706 : Closed e2422374036706 ∧ code e2422374036706 = 11218467058914 := by decide
theorem cert_e2422374036706 : check e2422374036706 [[],[]] .three = true := by decide
def e2422374036718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422374036718 : Closed e2422374036718 ∧ code e2422374036718 = 11218467058926 := by decide
theorem cert_e2422374036718 : check e2422374036718 [[],[]] .three = true := by decide
def e2422374036726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422374036726 : Closed e2422374036726 ∧ code e2422374036726 = 11218467058934 := by decide
theorem cert_e2422374036726 : check e2422374036726 [[],[]] .three = true := by decide
def e2422374036730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422374036730 : Closed e2422374036730 ∧ code e2422374036730 = 11218467058938 := by decide
theorem cert_e2422374036730 : check e2422374036730 [[],[]] .three = true := by decide
def e2422374037006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422374037006 : Closed e2422374037006 ∧ code e2422374037006 = 11218467059214 := by decide
theorem cert_e2422374037006 : check e2422374037006 [[],[]] .three = true := by decide
def e2422374037090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422374037090 : Closed e2422374037090 ∧ code e2422374037090 = 11218467059298 := by decide
theorem cert_e2422374037090 : check e2422374037090 [[],[]] .three = true := by decide
def e2422374037102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422374037102 : Closed e2422374037102 ∧ code e2422374037102 = 11218467059310 := by decide
theorem cert_e2422374037102 : check e2422374037102 [[],[]] .three = true := by decide
def e2422374037114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422374037114 : Closed e2422374037114 ∧ code e2422374037114 = 11218467059322 := by decide
theorem cert_e2422374037114 : check e2422374037114 [[],[]] .three = true := by decide
def e2422374037278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.lam (.var 3))))))))
theorem wire_e2422374037278 : Closed e2422374037278 ∧ code e2422374037278 = 11218467059486 := by decide
theorem cert_e2422374037278 : check e2422374037278 [[],[]] .three = true := by decide
def e2422374037302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422374037302 : Closed e2422374037302 ∧ code e2422374037302 = 11218467059510 := by decide
theorem cert_e2422374037302 : check e2422374037302 [[],[]] .three = true := by decide
def e2422374037306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422374037306 : Closed e2422374037306 ∧ code e2422374037306 = 11218467059514 := by decide
theorem cert_e2422374037306 : check e2422374037306 [[],[]] .three = true := by decide
def e2422374037402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422374037402 : Closed e2422374037402 ∧ code e2422374037402 = 11218467059610 := by decide
theorem cert_e2422374037402 : check e2422374037402 [[],[]] .three = true := by decide
def e2422374037562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422374037562 : Closed e2422374037562 ∧ code e2422374037562 = 11218467059770 := by decide
theorem cert_e2422374037562 : check e2422374037562 [[],[]] .three = true := by decide
def e2422374037610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422374037610 : Closed e2422374037610 ∧ code e2422374037610 = 11218467059818 := by decide
theorem cert_e2422374037610 : check e2422374037610 [[],[]] .three = true := by decide
def e2422374037658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422374037658 : Closed e2422374037658 ∧ code e2422374037658 = 11218467059866 := by decide
theorem cert_e2422374037658 : check e2422374037658 [[],[]] .three = true := by decide
def e2422374037702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422374037702 : Closed e2422374037702 ∧ code e2422374037702 = 11218467059910 := by decide
theorem cert_e2422374037702 : check e2422374037702 [[],[]] .three = true := by decide
def e2422374037726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2422374037726 : Closed e2422374037726 ∧ code e2422374037726 = 11218467059934 := by decide
theorem cert_e2422374037726 : check e2422374037726 [[],[]] .three = true := by decide
def e2422374037742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422374037742 : Closed e2422374037742 ∧ code e2422374037742 = 11218467059950 := by decide
theorem cert_e2422374037742 : check e2422374037742 [[],[]] .three = true := by decide
def e2422374037750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422374037750 : Closed e2422374037750 ∧ code e2422374037750 = 11218467059958 := by decide
theorem cert_e2422374037750 : check e2422374037750 [[],[]] .three = true := by decide
def e2422374037754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422374037754 : Closed e2422374037754 ∧ code e2422374037754 = 11218467059962 := by decide
theorem cert_e2422374037754 : check e2422374037754 [[],[]] .three = true := by decide
def e2422374037898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422374037898 : Closed e2422374037898 ∧ code e2422374037898 = 11218467060106 := by decide
theorem cert_e2422374037898 : check e2422374037898 [[],[]] .three = true := by decide
def e2422374037922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422374037922 : Closed e2422374037922 ∧ code e2422374037922 = 11218467060130 := by decide
theorem cert_e2422374037922 : check e2422374037922 [[],[]] .three = true := by decide
def e2422374037934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422374037934 : Closed e2422374037934 ∧ code e2422374037934 = 11218467060142 := by decide
theorem cert_e2422374037934 : check e2422374037934 [[],[]] .three = true := by decide
def e2422374037942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2422374037942 : Closed e2422374037942 ∧ code e2422374037942 = 11218467060150 := by decide
theorem cert_e2422374037942 : check e2422374037942 [[],[]] .three = true := by decide
def e2422374037946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422374037946 : Closed e2422374037946 ∧ code e2422374037946 = 11218467060154 := by decide
theorem cert_e2422374037946 : check e2422374037946 [[],[]] .three = true := by decide
def e2422374037974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2422374037974 : Closed e2422374037974 ∧ code e2422374037974 = 11218467060182 := by decide
theorem cert_e2422374037974 : check e2422374037974 [[],[]] .three = true := by decide
def e2422374037978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e2422374037978 : Closed e2422374037978 ∧ code e2422374037978 = 11218467060186 := by decide
theorem cert_e2422374037978 : check e2422374037978 [[],[]] .three = true := by decide
def e2422374037994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422374037994 : Closed e2422374037994 ∧ code e2422374037994 = 11218467060202 := by decide
theorem cert_e2422374037994 : check e2422374037994 [[],[]] .three = true := by decide
def e2422374038030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422374038030 : Closed e2422374038030 ∧ code e2422374038030 = 11218467060238 := by decide
theorem cert_e2422374038030 : check e2422374038030 [[],[]] .three = true := by decide
def e2422374038042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374038042 : Closed e2422374038042 ∧ code e2422374038042 = 11218467060250 := by decide
theorem cert_e2422374038042 : check e2422374038042 [[],[]] .three = true := by decide
def e2422374038078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2422374038078 : Closed e2422374038078 ∧ code e2422374038078 = 11218467060286 := by decide
theorem cert_e2422374038078 : check e2422374038078 [[],[]] .three = true := by decide
def e2422374038114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422374038114 : Closed e2422374038114 ∧ code e2422374038114 = 11218467060322 := by decide
theorem cert_e2422374038114 : check e2422374038114 [[],[]] .three = true := by decide
def e2422374038126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422374038126 : Closed e2422374038126 ∧ code e2422374038126 = 11218467060334 := by decide
theorem cert_e2422374038126 : check e2422374038126 [[],[]] .three = true := by decide
def e2422374038134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422374038134 : Closed e2422374038134 ∧ code e2422374038134 = 11218467060342 := by decide
theorem cert_e2422374038134 : check e2422374038134 [[],[]] .three = true := by decide
def e2422374038138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422374038138 : Closed e2422374038138 ∧ code e2422374038138 = 11218467060346 := by decide
theorem cert_e2422374038138 : check e2422374038138 [[],[]] .three = true := by decide
def e2422374038302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422374038302 : Closed e2422374038302 ∧ code e2422374038302 = 11218467060510 := by decide
theorem cert_e2422374038302 : check e2422374038302 [[],[]] .three = true := by decide
def e2422374038326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422374038326 : Closed e2422374038326 ∧ code e2422374038326 = 11218467060534 := by decide
theorem cert_e2422374038326 : check e2422374038326 [[],[]] .three = true := by decide
def e2422374038330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422374038330 : Closed e2422374038330 ∧ code e2422374038330 = 11218467060538 := by decide
theorem cert_e2422374038330 : check e2422374038330 [[],[]] .three = true := by decide
def e2422374038414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422374038414 : Closed e2422374038414 ∧ code e2422374038414 = 11218467060622 := by decide
theorem cert_e2422374038414 : check e2422374038414 [[],[]] .three = true := by decide
def e2422374038426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422374038426 : Closed e2422374038426 ∧ code e2422374038426 = 11218467060634 := by decide
theorem cert_e2422374038426 : check e2422374038426 [[],[]] .three = true := by decide
def e2422374038470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422374038470 : Closed e2422374038470 ∧ code e2422374038470 = 11218467060678 := by decide
theorem cert_e2422374038470 : check e2422374038470 [[],[]] .three = true := by decide
def e2422374038638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2422374038638 : Closed e2422374038638 ∧ code e2422374038638 = 11218467060846 := by decide
theorem cert_e2422374038638 : check e2422374038638 [[],[]] .three = true := by decide
def e2422374038650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422374038650 : Closed e2422374038650 ∧ code e2422374038650 = 11218467060858 := by decide
theorem cert_e2422374038650 : check e2422374038650 [[],[]] .three = true := by decide
def e2422374038742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2422374038742 : Closed e2422374038742 ∧ code e2422374038742 = 11218467060950 := by decide
theorem cert_e2422374038742 : check e2422374038742 [[],[]] .three = true := by decide
def e2422374038746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2422374038746 : Closed e2422374038746 ∧ code e2422374038746 = 11218467060954 := by decide
theorem cert_e2422374038746 : check e2422374038746 [[],[]] .three = true := by decide
def e2422374038762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2422374038762 : Closed e2422374038762 ∧ code e2422374038762 = 11218467060970 := by decide
theorem cert_e2422374038762 : check e2422374038762 [[],[]] .three = true := by decide
def e2422374038814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2422374038814 : Closed e2422374038814 ∧ code e2422374038814 = 11218467061022 := by decide
theorem cert_e2422374038814 : check e2422374038814 [[],[]] .three = true := by decide
def e2422374038838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422374038838 : Closed e2422374038838 ∧ code e2422374038838 = 11218467061046 := by decide
theorem cert_e2422374038838 : check e2422374038838 [[],[]] .three = true := by decide
def e2422374038842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422374038842 : Closed e2422374038842 ∧ code e2422374038842 = 11218467061050 := by decide
theorem cert_e2422374038842 : check e2422374038842 [[],[]] .three = true := by decide
def e2422374038938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422374038938 : Closed e2422374038938 ∧ code e2422374038938 = 11218467061146 := by decide
theorem cert_e2422374038938 : check e2422374038938 [[],[]] .three = true := by decide
def e2422374038982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422374038982 : Closed e2422374038982 ∧ code e2422374038982 = 11218467061190 := by decide
theorem cert_e2422374038982 : check e2422374038982 [[],[]] .three = true := by decide
def e2422374041006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422374041006 : Closed e2422374041006 ∧ code e2422374041006 = 11218467063214 := by decide
theorem cert_e2422374041006 : check e2422374041006 [[],[]] .three = true := by decide
def e2422374041018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422374041018 : Closed e2422374041018 ∧ code e2422374041018 = 11218467063226 := by decide
theorem cert_e2422374041018 : check e2422374041018 [[],[]] .three = true := by decide
def e2422374041066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422374041066 : Closed e2422374041066 ∧ code e2422374041066 = 11218467063274 := by decide
theorem cert_e2422374041066 : check e2422374041066 [[],[]] .three = true := by decide
def e2422374041198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374041198 : Closed e2422374041198 ∧ code e2422374041198 = 11218467063406 := by decide
theorem cert_e2422374041198 : check e2422374041198 [[],[]] .three = true := by decide
def e2422374041210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374041210 : Closed e2422374041210 ∧ code e2422374041210 = 11218467063418 := by decide
theorem cert_e2422374041210 : check e2422374041210 [[],[]] .three = true := by decide
def e2422374041374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422374041374 : Closed e2422374041374 ∧ code e2422374041374 = 11218467063582 := by decide
theorem cert_e2422374041374 : check e2422374041374 [[],[]] .three = true := by decide
end Blc.Floor43
