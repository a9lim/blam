import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e756786711406 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e756786711406 : Closed e756786711406 ∧ code e756786711406 = 9552879733614 := by decide
theorem cert_e756786711406 : check e756786711406 [] .sourceHead = true := by decide
def e756786711414 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e756786711414 : Closed e756786711414 ∧ code e756786711414 = 9552879733622 := by decide
theorem cert_e756786711414 : check e756786711414 [] .sourceHead = true := by decide
def e756786711470 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e756786711470 : Closed e756786711470 ∧ code e756786711470 = 9552879733678 := by decide
theorem cert_e756786711470 : check e756786711470 [] .sourceHead = true := by decide
def e756786711482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e756786711482 : Closed e756786711482 ∧ code e756786711482 = 9552879733690 := by decide
theorem cert_e756786711482 : check e756786711482 [] .sourceHead = true := by decide
def e756786711510 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e756786711510 : Closed e756786711510 ∧ code e756786711510 = 9552879733718 := by decide
theorem cert_e756786711510 : check e756786711510 [] .sourceHead = true := by decide
def e756786711514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e756786711514 : Closed e756786711514 ∧ code e756786711514 = 9552879733722 := by decide
theorem cert_e756786711514 : check e756786711514 [] .sourceHead = true := by decide
def e756786711790 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e756786711790 : Closed e756786711790 ∧ code e756786711790 = 9552879733998 := by decide
theorem cert_e756786711790 : check e756786711790 [] .sourceHead = true := by decide
def e756786711798 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e756786711798 : Closed e756786711798 ∧ code e756786711798 = 9552879734006 := by decide
theorem cert_e756786711798 : check e756786711798 [] .sourceHead = true := by decide
def e756786712174 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e756786712174 : Closed e756786712174 ∧ code e756786712174 = 9552879734382 := by decide
theorem cert_e756786712174 : check e756786712174 [] .sourceHead = true := by decide
def e756786712186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e756786712186 : Closed e756786712186 ∧ code e756786712186 = 9552879734394 := by decide
theorem cert_e756786712186 : check e756786712186 [] .sourceHead = true := by decide
def e756786712374 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e756786712374 : Closed e756786712374 ∧ code e756786712374 = 9552879734582 := by decide
theorem cert_e756786712374 : check e756786712374 [] .sourceHead = true := by decide
def e756786712378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e756786712378 : Closed e756786712378 ∧ code e756786712378 = 9552879734586 := by decide
theorem cert_e756786712378 : check e756786712378 [] .sourceHead = true := by decide
def e756786718126 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e756786718126 : Closed e756786718126 ∧ code e756786718126 = 9552879740334 := by decide
theorem cert_e756786718126 : check e756786718126 [] .sourceHead = true := by decide
def e756786718138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e756786718138 : Closed e756786718138 ∧ code e756786718138 = 9552879740346 := by decide
theorem cert_e756786718138 : check e756786718138 [] .sourceHead = true := by decide
def e756786718186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e756786718186 : Closed e756786718186 ∧ code e756786718186 = 9552879740394 := by decide
theorem cert_e756786718186 : check e756786718186 [] .sourceHead = true := by decide
def e756786718318 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e756786718318 : Closed e756786718318 ∧ code e756786718318 = 9552879740526 := by decide
theorem cert_e756786718318 : check e756786718318 [] .sourceHead = true := by decide
def e756786718330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e756786718330 : Closed e756786718330 ∧ code e756786718330 = 9552879740538 := by decide
theorem cert_e756786718330 : check e756786718330 [] .sourceHead = true := by decide
def e756786718618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e756786718618 : Closed e756786718618 ∧ code e756786718618 = 9552879740826 := by decide
theorem cert_e756786718618 : check e756786718618 [] .sourceHead = true := by decide
def e756786721494 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e756786721494 : Closed e756786721494 ∧ code e756786721494 = 9552879743702 := by decide
theorem cert_e756786721494 : check e756786721494 [] .sourceHead = true := by decide
def e756786721498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e756786721498 : Closed e756786721498 ∧ code e756786721498 = 9552879743706 := by decide
theorem cert_e756786721498 : check e756786721498 [] .sourceHead = true := by decide
def e756786721514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e756786721514 : Closed e756786721514 ∧ code e756786721514 = 9552879743722 := by decide
theorem cert_e756786721514 : check e756786721514 [] .sourceHead = true := by decide
def e756786721590 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e756786721590 : Closed e756786721590 ∧ code e756786721590 = 9552879743798 := by decide
theorem cert_e756786721590 : check e756786721590 [] .sourceHead = true := by decide
def e756786721594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e756786721594 : Closed e756786721594 ∧ code e756786721594 = 9552879743802 := by decide
theorem cert_e756786721594 : check e756786721594 [] .sourceHead = true := by decide
def e756786721690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e756786721690 : Closed e756786721690 ∧ code e756786721690 = 9552879743898 := by decide
theorem cert_e756786721690 : check e756786721690 [] .sourceHead = true := by decide
def e756786837230 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e756786837230 : Closed e756786837230 ∧ code e756786837230 = 9552879859438 := by decide
theorem cert_e756786837230 : check e756786837230 [] .sourceHead = true := by decide
def e756786837358 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e756786837358 : Closed e756786837358 ∧ code e756786837358 = 9552879859566 := by decide
theorem cert_e756786837358 : check e756786837358 [] .sourceHead = true := by decide
def e756786837366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e756786837366 : Closed e756786837366 ∧ code e756786837366 = 9552879859574 := by decide
theorem cert_e756786837366 : check e756786837366 [] .sourceHead = true := by decide
def e756786838254 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e756786838254 : Closed e756786838254 ∧ code e756786838254 = 9552879860462 := by decide
theorem cert_e756786838254 : check e756786838254 [] .sourceHead = true := by decide
def e756786838446 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e756786838446 : Closed e756786838446 ∧ code e756786838446 = 9552879860654 := by decide
theorem cert_e756786838446 : check e756786838446 [] .sourceHead = true := by decide
def e756786838458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e756786838458 : Closed e756786838458 ∧ code e756786838458 = 9552879860666 := by decide
theorem cert_e756786838458 : check e756786838458 [] .sourceHead = true := by decide
def e756786838894 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e756786838894 : Closed e756786838894 ∧ code e756786838894 = 9552879861102 := by decide
theorem cert_e756786838894 : check e756786838894 [] .sourceHead = true := by decide
def e756786838902 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e756786838902 : Closed e756786838902 ∧ code e756786838902 = 9552879861110 := by decide
theorem cert_e756786838902 : check e756786838902 [] .sourceHead = true := by decide
def e756786838958 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e756786838958 : Closed e756786838958 ∧ code e756786838958 = 9552879861166 := by decide
theorem cert_e756786838958 : check e756786838958 [] .sourceHead = true := by decide
def e756786838970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e756786838970 : Closed e756786838970 ∧ code e756786838970 = 9552879861178 := by decide
theorem cert_e756786838970 : check e756786838970 [] .sourceHead = true := by decide
def e756786838998 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e756786838998 : Closed e756786838998 ∧ code e756786838998 = 9552879861206 := by decide
theorem cert_e756786838998 : check e756786838998 [] .sourceHead = true := by decide
def e756786839002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e756786839002 : Closed e756786839002 ∧ code e756786839002 = 9552879861210 := by decide
theorem cert_e756786839002 : check e756786839002 [] .sourceHead = true := by decide
def e756786843374 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e756786843374 : Closed e756786843374 ∧ code e756786843374 = 9552879865582 := by decide
theorem cert_e756786843374 : check e756786843374 [] .sourceHead = true := by decide
def e756786843502 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e756786843502 : Closed e756786843502 ∧ code e756786843502 = 9552879865710 := by decide
theorem cert_e756786843502 : check e756786843502 [] .sourceHead = true := by decide
def e756786843510 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e756786843510 : Closed e756786843510 ∧ code e756786843510 = 9552879865718 := by decide
theorem cert_e756786843510 : check e756786843510 [] .sourceHead = true := by decide
def e756786846190 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e756786846190 : Closed e756786846190 ∧ code e756786846190 = 9552879868398 := by decide
theorem cert_e756786846190 : check e756786846190 [] .sourceHead = true := by decide
def e756786846958 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e756786846958 : Closed e756786846958 ∧ code e756786846958 = 9552879869166 := by decide
theorem cert_e756786846958 : check e756786846958 [] .sourceHead = true := by decide
def e756786846966 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e756786846966 : Closed e756786846966 ∧ code e756786846966 = 9552879869174 := by decide
theorem cert_e756786846966 : check e756786846966 [] .sourceHead = true := by decide
def e756786849518 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e756786849518 : Closed e756786849518 ∧ code e756786849518 = 9552879871726 := by decide
theorem cert_e756786849518 : check e756786849518 [] .sourceHead = true := by decide
def e756786849710 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e756786849710 : Closed e756786849710 ∧ code e756786849710 = 9552879871918 := by decide
theorem cert_e756786849710 : check e756786849710 [] .sourceHead = true := by decide
def e756786849722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e756786849722 : Closed e756786849722 ∧ code e756786849722 = 9552879871930 := by decide
theorem cert_e756786849722 : check e756786849722 [] .sourceHead = true := by decide
def e756786850286 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e756786850286 : Closed e756786850286 ∧ code e756786850286 = 9552879872494 := by decide
theorem cert_e756786850286 : check e756786850286 [] .sourceHead = true := by decide
def e756786851438 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e756786851438 : Closed e756786851438 ∧ code e756786851438 = 9552879873646 := by decide
theorem cert_e756786851438 : check e756786851438 [] .sourceHead = true := by decide
def e756786851450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e756786851450 : Closed e756786851450 ∧ code e756786851450 = 9552879873658 := by decide
theorem cert_e756786851450 : check e756786851450 [] .sourceHead = true := by decide
def e756786852718 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e756786852718 : Closed e756786852718 ∧ code e756786852718 = 9552879874926 := by decide
theorem cert_e756786852718 : check e756786852718 [] .sourceHead = true := by decide
def e756786852726 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e756786852726 : Closed e756786852726 ∧ code e756786852726 = 9552879874934 := by decide
theorem cert_e756786852726 : check e756786852726 [] .sourceHead = true := by decide
def e756786852782 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e756786852782 : Closed e756786852782 ∧ code e756786852782 = 9552879874990 := by decide
theorem cert_e756786852782 : check e756786852782 [] .sourceHead = true := by decide
def e756786852794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e756786852794 : Closed e756786852794 ∧ code e756786852794 = 9552879875002 := by decide
theorem cert_e756786852794 : check e756786852794 [] .sourceHead = true := by decide
def e756786852822 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e756786852822 : Closed e756786852822 ∧ code e756786852822 = 9552879875030 := by decide
theorem cert_e756786852822 : check e756786852822 [] .sourceHead = true := by decide
def e756786852826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e756786852826 : Closed e756786852826 ∧ code e756786852826 = 9552879875034 := by decide
theorem cert_e756786852826 : check e756786852826 [] .sourceHead = true := by decide
def e756786853102 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e756786853102 : Closed e756786853102 ∧ code e756786853102 = 9552879875310 := by decide
theorem cert_e756786853102 : check e756786853102 [] .sourceHead = true := by decide
def e756786853110 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e756786853110 : Closed e756786853110 ∧ code e756786853110 = 9552879875318 := by decide
theorem cert_e756786853110 : check e756786853110 [] .sourceHead = true := by decide
def e756786853486 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e756786853486 : Closed e756786853486 ∧ code e756786853486 = 9552879875694 := by decide
theorem cert_e756786853486 : check e756786853486 [] .sourceHead = true := by decide
def e756786853498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e756786853498 : Closed e756786853498 ∧ code e756786853498 = 9552879875706 := by decide
theorem cert_e756786853498 : check e756786853498 [] .sourceHead = true := by decide
def e756786853686 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e756786853686 : Closed e756786853686 ∧ code e756786853686 = 9552879875894 := by decide
theorem cert_e756786853686 : check e756786853686 [] .sourceHead = true := by decide
def e756786853690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e756786853690 : Closed e756786853690 ∧ code e756786853690 = 9552879875898 := by decide
theorem cert_e756786853690 : check e756786853690 [] .sourceHead = true := by decide
def e756786858862 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e756786858862 : Closed e756786858862 ∧ code e756786858862 = 9552879881070 := by decide
theorem cert_e756786858862 : check e756786858862 [] .sourceHead = true := by decide
def e756786858870 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e756786858870 : Closed e756786858870 ∧ code e756786858870 = 9552879881078 := by decide
theorem cert_e756786858870 : check e756786858870 [] .sourceHead = true := by decide
def e756786858926 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e756786858926 : Closed e756786858926 ∧ code e756786858926 = 9552879881134 := by decide
theorem cert_e756786858926 : check e756786858926 [] .sourceHead = true := by decide
def e756786858938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e756786858938 : Closed e756786858938 ∧ code e756786858938 = 9552879881146 := by decide
theorem cert_e756786858938 : check e756786858938 [] .sourceHead = true := by decide
def e756786858966 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e756786858966 : Closed e756786858966 ∧ code e756786858966 = 9552879881174 := by decide
theorem cert_e756786858966 : check e756786858966 [] .sourceHead = true := by decide
def e756786858970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e756786858970 : Closed e756786858970 ∧ code e756786858970 = 9552879881178 := by decide
theorem cert_e756786858970 : check e756786858970 [] .sourceHead = true := by decide
def e756786859246 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e756786859246 : Closed e756786859246 ∧ code e756786859246 = 9552879881454 := by decide
theorem cert_e756786859246 : check e756786859246 [] .sourceHead = true := by decide
def e756786859254 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e756786859254 : Closed e756786859254 ∧ code e756786859254 = 9552879881462 := by decide
theorem cert_e756786859254 : check e756786859254 [] .sourceHead = true := by decide
def e756786859630 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e756786859630 : Closed e756786859630 ∧ code e756786859630 = 9552879881838 := by decide
theorem cert_e756786859630 : check e756786859630 [] .sourceHead = true := by decide
def e756786859642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e756786859642 : Closed e756786859642 ∧ code e756786859642 = 9552879881850 := by decide
theorem cert_e756786859642 : check e756786859642 [] .sourceHead = true := by decide
def e756786859830 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e756786859830 : Closed e756786859830 ∧ code e756786859830 = 9552879882038 := by decide
theorem cert_e756786859830 : check e756786859830 [] .sourceHead = true := by decide
def e756786859834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e756786859834 : Closed e756786859834 ∧ code e756786859834 = 9552879882042 := by decide
theorem cert_e756786859834 : check e756786859834 [] .sourceHead = true := by decide
def e756786867950 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e756786867950 : Closed e756786867950 ∧ code e756786867950 = 9552879890158 := by decide
theorem cert_e756786867950 : check e756786867950 [] .sourceHead = true := by decide
def e756786868078 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e756786868078 : Closed e756786868078 ∧ code e756786868078 = 9552879890286 := by decide
theorem cert_e756786868078 : check e756786868078 [] .sourceHead = true := by decide
def e756786868086 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e756786868086 : Closed e756786868086 ∧ code e756786868086 = 9552879890294 := by decide
theorem cert_e756786868086 : check e756786868086 [] .sourceHead = true := by decide
def e756786870766 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e756786870766 : Closed e756786870766 ∧ code e756786870766 = 9552879892974 := by decide
theorem cert_e756786870766 : check e756786870766 [] .sourceHead = true := by decide
def e756786871534 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e756786871534 : Closed e756786871534 ∧ code e756786871534 = 9552879893742 := by decide
theorem cert_e756786871534 : check e756786871534 [] .sourceHead = true := by decide
def e756786871542 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e756786871542 : Closed e756786871542 ∧ code e756786871542 = 9552879893750 := by decide
theorem cert_e756786871542 : check e756786871542 [] .sourceHead = true := by decide
def e756786894574 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e756786894574 : Closed e756786894574 ∧ code e756786894574 = 9552879916782 := by decide
theorem cert_e756786894574 : check e756786894574 [] .sourceHead = true := by decide
def e756786894766 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e756786894766 : Closed e756786894766 ∧ code e756786894766 = 9552879916974 := by decide
theorem cert_e756786894766 : check e756786894766 [] .sourceHead = true := by decide
def e756786894778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e756786894778 : Closed e756786894778 ∧ code e756786894778 = 9552879916986 := by decide
theorem cert_e756786894778 : check e756786894778 [] .sourceHead = true := by decide
def e756786895342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e756786895342 : Closed e756786895342 ∧ code e756786895342 = 9552879917550 := by decide
theorem cert_e756786895342 : check e756786895342 [] .sourceHead = true := by decide
def e756786896494 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e756786896494 : Closed e756786896494 ∧ code e756786896494 = 9552879918702 := by decide
theorem cert_e756786896494 : check e756786896494 [] .sourceHead = true := by decide
def e756786896506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e756786896506 : Closed e756786896506 ∧ code e756786896506 = 9552879918714 := by decide
theorem cert_e756786896506 : check e756786896506 [] .sourceHead = true := by decide
def e756786908014 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e756786908014 : Closed e756786908014 ∧ code e756786908014 = 9552879930222 := by decide
theorem cert_e756786908014 : check e756786908014 [] .sourceHead = true := by decide
def e756786908022 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e756786908022 : Closed e756786908022 ∧ code e756786908022 = 9552879930230 := by decide
theorem cert_e756786908022 : check e756786908022 [] .sourceHead = true := by decide
def e756786908078 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e756786908078 : Closed e756786908078 ∧ code e756786908078 = 9552879930286 := by decide
theorem cert_e756786908078 : check e756786908078 [] .sourceHead = true := by decide
def e756786908090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e756786908090 : Closed e756786908090 ∧ code e756786908090 = 9552879930298 := by decide
theorem cert_e756786908090 : check e756786908090 [] .sourceHead = true := by decide
def e756786908118 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e756786908118 : Closed e756786908118 ∧ code e756786908118 = 9552879930326 := by decide
theorem cert_e756786908118 : check e756786908118 [] .sourceHead = true := by decide
def e756786908122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e756786908122 : Closed e756786908122 ∧ code e756786908122 = 9552879930330 := by decide
theorem cert_e756786908122 : check e756786908122 [] .sourceHead = true := by decide
def e756786908398 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e756786908398 : Closed e756786908398 ∧ code e756786908398 = 9552879930606 := by decide
theorem cert_e756786908398 : check e756786908398 [] .sourceHead = true := by decide
def e756786908406 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e756786908406 : Closed e756786908406 ∧ code e756786908406 = 9552879930614 := by decide
theorem cert_e756786908406 : check e756786908406 [] .sourceHead = true := by decide
def e756786908782 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e756786908782 : Closed e756786908782 ∧ code e756786908782 = 9552879930990 := by decide
theorem cert_e756786908782 : check e756786908782 [] .sourceHead = true := by decide
def e756786908794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e756786908794 : Closed e756786908794 ∧ code e756786908794 = 9552879931002 := by decide
theorem cert_e756786908794 : check e756786908794 [] .sourceHead = true := by decide
def e756786908982 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e756786908982 : Closed e756786908982 ∧ code e756786908982 = 9552879931190 := by decide
theorem cert_e756786908982 : check e756786908982 [] .sourceHead = true := by decide
def e756786908986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e756786908986 : Closed e756786908986 ∧ code e756786908986 = 9552879931194 := by decide
theorem cert_e756786908986 : check e756786908986 [] .sourceHead = true := by decide
def e756787448686 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e756787448686 : Closed e756787448686 ∧ code e756787448686 = 9552880470894 := by decide
theorem cert_e756787448686 : check e756787448686 [] .sourceHead = true := by decide
def e756787448694 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e756787448694 : Closed e756787448694 ∧ code e756787448694 = 9552880470902 := by decide
theorem cert_e756787448694 : check e756787448694 [] .sourceHead = true := by decide
def e756787448750 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e756787448750 : Closed e756787448750 ∧ code e756787448750 = 9552880470958 := by decide
theorem cert_e756787448750 : check e756787448750 [] .sourceHead = true := by decide
def e756787448762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e756787448762 : Closed e756787448762 ∧ code e756787448762 = 9552880470970 := by decide
theorem cert_e756787448762 : check e756787448762 [] .sourceHead = true := by decide
def e756787448790 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e756787448790 : Closed e756787448790 ∧ code e756787448790 = 9552880470998 := by decide
theorem cert_e756787448790 : check e756787448790 [] .sourceHead = true := by decide
def e756787448794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e756787448794 : Closed e756787448794 ∧ code e756787448794 = 9552880471002 := by decide
theorem cert_e756787448794 : check e756787448794 [] .sourceHead = true := by decide
def e756787449070 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e756787449070 : Closed e756787449070 ∧ code e756787449070 = 9552880471278 := by decide
theorem cert_e756787449070 : check e756787449070 [] .sourceHead = true := by decide
def e756787449078 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e756787449078 : Closed e756787449078 ∧ code e756787449078 = 9552880471286 := by decide
theorem cert_e756787449078 : check e756787449078 [] .sourceHead = true := by decide
def e756787449454 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e756787449454 : Closed e756787449454 ∧ code e756787449454 = 9552880471662 := by decide
theorem cert_e756787449454 : check e756787449454 [] .sourceHead = true := by decide
def e756787449466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e756787449466 : Closed e756787449466 ∧ code e756787449466 = 9552880471674 := by decide
theorem cert_e756787449466 : check e756787449466 [] .sourceHead = true := by decide
def e756787449654 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e756787449654 : Closed e756787449654 ∧ code e756787449654 = 9552880471862 := by decide
theorem cert_e756787449654 : check e756787449654 [] .sourceHead = true := by decide
def e756787449658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e756787449658 : Closed e756787449658 ∧ code e756787449658 = 9552880471866 := by decide
theorem cert_e756787449658 : check e756787449658 [] .sourceHead = true := by decide
def e756855266842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855266842 : Closed e756855266842 ∧ code e756855266842 = 9552948289050 := by decide
theorem cert_e756855266842 : check e756855266842 [] .sourceHead = true := by decide
def e756855272986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855272986 : Closed e756855272986 ∧ code e756855272986 = 9552948295194 := by decide
theorem cert_e756855272986 : check e756855272986 [] .sourceHead = true := by decide
def e756855299610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855299610 : Closed e756855299610 ∧ code e756855299610 = 9552948321818 := by decide
theorem cert_e756855299610 : check e756855299610 [] .sourceHead = true := by decide
def e756855306778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855306778 : Closed e756855306778 ∧ code e756855306778 = 9552948328986 := by decide
theorem cert_e756855306778 : check e756855306778 [] .sourceHead = true := by decide
def e756855330330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855330330 : Closed e756855330330 ∧ code e756855330330 = 9552948352538 := by decide
theorem cert_e756855330330 : check e756855330330 [] .sourceHead = true := by decide
def e756855331354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855331354 : Closed e756855331354 ∧ code e756855331354 = 9552948353562 := by decide
theorem cert_e756855331354 : check e756855331354 [] .sourceHead = true := by decide
def e756855463450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855463450 : Closed e756855463450 ∧ code e756855463450 = 9552948485658 := by decide
theorem cert_e756855463450 : check e756855463450 [] .sourceHead = true := by decide
def e756855469594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855469594 : Closed e756855469594 ∧ code e756855469594 = 9552948491802 := by decide
theorem cert_e756855469594 : check e756855469594 [] .sourceHead = true := by decide
def e756855660058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855660058 : Closed e756855660058 ∧ code e756855660058 = 9552948682266 := by decide
theorem cert_e756855660058 : check e756855660058 [] .sourceHead = true := by decide
def e756855667226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855667226 : Closed e756855667226 ∧ code e756855667226 = 9552948689434 := by decide
theorem cert_e756855667226 : check e756855667226 [] .sourceHead = true := by decide
def e756855813658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855813658 : Closed e756855813658 ∧ code e756855813658 = 9552948835866 := by decide
theorem cert_e756855813658 : check e756855813658 [] .sourceHead = true := by decide
def e756855814682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756855814682 : Closed e756855814682 ∧ code e756855814682 = 9552948836890 := by decide
theorem cert_e756855814682 : check e756855814682 [] .sourceHead = true := by decide
def e756859596314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859596314 : Closed e756859596314 ∧ code e756859596314 = 9552952618522 := by decide
theorem cert_e756859596314 : check e756859596314 [] .sourceHead = true := by decide
def e756859598362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859598362 : Closed e756859598362 ∧ code e756859598362 = 9552952620570 := by decide
theorem cert_e756859598362 : check e756859598362 [] .sourceHead = true := by decide
def e756859739674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859739674 : Closed e756859739674 ∧ code e756859739674 = 9552952761882 := by decide
theorem cert_e756859739674 : check e756859739674 [] .sourceHead = true := by decide
def e756859760838 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756859760838 : Closed e756859760838 ∧ code e756859760838 = 9552952783046 := by decide
theorem cert_e756859760838 : check e756859760838 [] .sourceHead = true := by decide
def e756859768346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859768346 : Closed e756859768346 ∧ code e756859768346 = 9552952790554 := by decide
theorem cert_e756859768346 : check e756859768346 [] .sourceHead = true := by decide
def e756859777222 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756859777222 : Closed e756859777222 ∧ code e756859777222 = 9552952799430 := by decide
theorem cert_e756859777222 : check e756859777222 [] .sourceHead = true := by decide
def e756859825690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859825690 : Closed e756859825690 ∧ code e756859825690 = 9552952847898 := by decide
theorem cert_e756859825690 : check e756859825690 [] .sourceHead = true := by decide
def e756859828762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859828762 : Closed e756859828762 ∧ code e756859828762 = 9552952850970 := by decide
theorem cert_e756859828762 : check e756859828762 [] .sourceHead = true := by decide
def e756859870746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859870746 : Closed e756859870746 ∧ code e756859870746 = 9552952892954 := by decide
theorem cert_e756859870746 : check e756859870746 [] .sourceHead = true := by decide
def e756859891910 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756859891910 : Closed e756859891910 ∧ code e756859891910 = 9552952914118 := by decide
theorem cert_e756859891910 : check e756859891910 [] .sourceHead = true := by decide
def e756859913754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859913754 : Closed e756859913754 ∧ code e756859913754 = 9552952935962 := by decide
theorem cert_e756859913754 : check e756859913754 [] .sourceHead = true := by decide
def e756859916486 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756859916486 : Closed e756859916486 ∧ code e756859916486 = 9552952938694 := by decide
theorem cert_e756859916486 : check e756859916486 [] .sourceHead = true := by decide
def e756859942426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859942426 : Closed e756859942426 ∧ code e756859942426 = 9552952964634 := by decide
theorem cert_e756859942426 : check e756859942426 [] .sourceHead = true := by decide
def e756859943450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859943450 : Closed e756859943450 ∧ code e756859943450 = 9552952965658 := by decide
theorem cert_e756859943450 : check e756859943450 [] .sourceHead = true := by decide
def e756859964954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859964954 : Closed e756859964954 ∧ code e756859964954 = 9552952987162 := by decide
theorem cert_e756859964954 : check e756859964954 [] .sourceHead = true := by decide
def e756859973830 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756859973830 : Closed e756859973830 ∧ code e756859973830 = 9552952996038 := by decide
theorem cert_e756859973830 : check e756859973830 [] .sourceHead = true := by decide
def e756859979290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756859979290 : Closed e756859979290 ∧ code e756859979290 = 9552953001498 := by decide
theorem cert_e756859979290 : check e756859979290 [] .sourceHead = true := by decide
def e756859982022 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756859982022 : Closed e756859982022 ∧ code e756859982022 = 9552953004230 := by decide
theorem cert_e756859982022 : check e756859982022 [] .sourceHead = true := by decide
def e756860526106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756860526106 : Closed e756860526106 ∧ code e756860526106 = 9552953548314 := by decide
theorem cert_e756860526106 : check e756860526106 [] .sourceHead = true := by decide
def e756860547270 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756860547270 : Closed e756860547270 ∧ code e756860547270 = 9552953569478 := by decide
theorem cert_e756860547270 : check e756860547270 [] .sourceHead = true := by decide
def e756860554778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756860554778 : Closed e756860554778 ∧ code e756860554778 = 9552953576986 := by decide
theorem cert_e756860554778 : check e756860554778 [] .sourceHead = true := by decide
def e756860563654 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756860563654 : Closed e756860563654 ∧ code e756860563654 = 9552953585862 := by decide
theorem cert_e756860563654 : check e756860563654 [] .sourceHead = true := by decide
def e756861312538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756861312538 : Closed e756861312538 ∧ code e756861312538 = 9552954334746 := by decide
theorem cert_e756861312538 : check e756861312538 [] .sourceHead = true := by decide
def e756861333702 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756861333702 : Closed e756861333702 ∧ code e756861333702 = 9552954355910 := by decide
theorem cert_e756861333702 : check e756861333702 [] .sourceHead = true := by decide
def e756861355546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756861355546 : Closed e756861355546 ∧ code e756861355546 = 9552954377754 := by decide
theorem cert_e756861355546 : check e756861355546 [] .sourceHead = true := by decide
def e756861358278 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756861358278 : Closed e756861358278 ∧ code e756861358278 = 9552954380486 := by decide
theorem cert_e756861358278 : check e756861358278 [] .sourceHead = true := by decide
def e756861734426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756861734426 : Closed e756861734426 ∧ code e756861734426 = 9552954756634 := by decide
theorem cert_e756861734426 : check e756861734426 [] .sourceHead = true := by decide
def e756861743302 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756861743302 : Closed e756861743302 ∧ code e756861743302 = 9552954765510 := by decide
theorem cert_e756861743302 : check e756861743302 [] .sourceHead = true := by decide
def e756861748762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756861748762 : Closed e756861748762 ∧ code e756861748762 = 9552954770970 := by decide
theorem cert_e756861748762 : check e756861748762 [] .sourceHead = true := by decide
def e756861751494 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756861751494 : Closed e756861751494 ∧ code e756861751494 = 9552954773702 := by decide
theorem cert_e756861751494 : check e756861751494 [] .sourceHead = true := by decide
def e756904144238 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e756904144238 : Closed e756904144238 ∧ code e756904144238 = 9552997166446 := by decide
theorem cert_e756904144238 : check e756904144238 [] .sourceHead = true := by decide
def e756904144246 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e756904144246 : Closed e756904144246 ∧ code e756904144246 = 9552997166454 := by decide
theorem cert_e756904144246 : check e756904144246 [] .sourceHead = true := by decide
def e756904144302 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e756904144302 : Closed e756904144302 ∧ code e756904144302 = 9552997166510 := by decide
theorem cert_e756904144302 : check e756904144302 [] .sourceHead = true := by decide
def e756904144314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e756904144314 : Closed e756904144314 ∧ code e756904144314 = 9552997166522 := by decide
theorem cert_e756904144314 : check e756904144314 [] .sourceHead = true := by decide
def e756904144342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e756904144342 : Closed e756904144342 ∧ code e756904144342 = 9552997166550 := by decide
theorem cert_e756904144342 : check e756904144342 [] .sourceHead = true := by decide
def e756904144346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e756904144346 : Closed e756904144346 ∧ code e756904144346 = 9552997166554 := by decide
theorem cert_e756904144346 : check e756904144346 [] .sourceHead = true := by decide
def e756904144558 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e756904144558 : Closed e756904144558 ∧ code e756904144558 = 9552997166766 := by decide
theorem cert_e756904144558 : check e756904144558 [] .sourceHead = true := by decide
def e756904144570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e756904144570 : Closed e756904144570 ∧ code e756904144570 = 9552997166778 := by decide
theorem cert_e756904144570 : check e756904144570 [] .sourceHead = true := by decide
def e756904144618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e756904144618 : Closed e756904144618 ∧ code e756904144618 = 9552997166826 := by decide
theorem cert_e756904144618 : check e756904144618 [] .sourceHead = true := by decide
def e756904144726 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e756904144726 : Closed e756904144726 ∧ code e756904144726 = 9552997166934 := by decide
theorem cert_e756904144726 : check e756904144726 [] .sourceHead = true := by decide
end Blc.Floor43
