import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422376621482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422376621482 : Closed e2422376621482 ∧ code e2422376621482 = 11218469643690 := by decide
theorem cert_e2422376621482 : check e2422376621482 [[],[]] .smaller = true := by decide
def e2422376621578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422376621578 : Closed e2422376621578 ∧ code e2422376621578 = 11218469643786 := by decide
theorem cert_e2422376621578 : check e2422376621578 [[],[]] .smaller = true := by decide
def e2422376621614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422376621614 : Closed e2422376621614 ∧ code e2422376621614 = 11218469643822 := by decide
theorem cert_e2422376621614 : check e2422376621614 [[],[]] .smaller = true := by decide
def e2422376621622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422376621622 : Closed e2422376621622 ∧ code e2422376621622 = 11218469643830 := by decide
theorem cert_e2422376621622 : check e2422376621622 [[],[]] .smaller = true := by decide
def e2422376621626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422376621626 : Closed e2422376621626 ∧ code e2422376621626 = 11218469643834 := by decide
theorem cert_e2422376621626 : check e2422376621626 [[],[]] .smaller = true := by decide
def e2422376621674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422376621674 : Closed e2422376621674 ∧ code e2422376621674 = 11218469643882 := by decide
theorem cert_e2422376621674 : check e2422376621674 [[],[]] .smaller = true := by decide
def e2422376621698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422376621698 : Closed e2422376621698 ∧ code e2422376621698 = 11218469643906 := by decide
theorem cert_e2422376621698 : check e2422376621698 [[],[]] .smaller = true := by decide
def e2422376621710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422376621710 : Closed e2422376621710 ∧ code e2422376621710 = 11218469643918 := by decide
theorem cert_e2422376621710 : check e2422376621710 [[],[]] .smaller = true := by decide
def e2422376621722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376621722 : Closed e2422376621722 ∧ code e2422376621722 = 11218469643930 := by decide
theorem cert_e2422376621722 : check e2422376621722 [[],[]] .smaller = true := by decide
def e2422376621766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422376621766 : Closed e2422376621766 ∧ code e2422376621766 = 11218469643974 := by decide
theorem cert_e2422376621766 : check e2422376621766 [[],[]] .smaller = true := by decide
def e2422376621790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2422376621790 : Closed e2422376621790 ∧ code e2422376621790 = 11218469643998 := by decide
theorem cert_e2422376621790 : check e2422376621790 [[],[]] .three = true := by decide
def e2422376621794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422376621794 : Closed e2422376621794 ∧ code e2422376621794 = 11218469644002 := by decide
theorem cert_e2422376621794 : check e2422376621794 [[],[]] .smaller = true := by decide
def e2422376621806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e2422376621806 : Closed e2422376621806 ∧ code e2422376621806 = 11218469644014 := by decide
theorem cert_e2422376621806 : check e2422376621806 [[],[]] .smaller = true := by decide
def e2422376621814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2422376621814 : Closed e2422376621814 ∧ code e2422376621814 = 11218469644022 := by decide
theorem cert_e2422376621814 : check e2422376621814 [[],[]] .three = true := by decide
def e2422376621850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422376621850 : Closed e2422376621850 ∧ code e2422376621850 = 11218469644058 := by decide
theorem cert_e2422376621850 : check e2422376621850 [[],[]] .smaller = true := by decide
def e2422376621894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422376621894 : Closed e2422376621894 ∧ code e2422376621894 = 11218469644102 := by decide
theorem cert_e2422376621894 : check e2422376621894 [[],[]] .smaller = true := by decide
def e2422376621918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2422376621918 : Closed e2422376621918 ∧ code e2422376621918 = 11218469644126 := by decide
theorem cert_e2422376621918 : check e2422376621918 [[],[]] .three = true := by decide
def e2422376621946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2422376621946 : Closed e2422376621946 ∧ code e2422376621946 = 11218469644154 := by decide
theorem cert_e2422376621946 : check e2422376621946 [[],[]] .three = true := by decide
def e2422376621962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422376621962 : Closed e2422376621962 ∧ code e2422376621962 = 11218469644170 := by decide
theorem cert_e2422376621962 : check e2422376621962 [[],[]] .smaller = true := by decide
def e2422376621986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422376621986 : Closed e2422376621986 ∧ code e2422376621986 = 11218469644194 := by decide
theorem cert_e2422376621986 : check e2422376621986 [[],[]] .smaller = true := by decide
def e2422376621998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e2422376621998 : Closed e2422376621998 ∧ code e2422376621998 = 11218469644206 := by decide
theorem cert_e2422376621998 : check e2422376621998 [[],[]] .smaller = true := by decide
def e2422376622010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e2422376622010 : Closed e2422376622010 ∧ code e2422376622010 = 11218469644218 := by decide
theorem cert_e2422376622010 : check e2422376622010 [[],[]] .smaller = true := by decide
def e2422376622038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2422376622038 : Closed e2422376622038 ∧ code e2422376622038 = 11218469644246 := by decide
theorem cert_e2422376622038 : check e2422376622038 [[],[]] .three = true := by decide
def e2422376622042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2422376622042 : Closed e2422376622042 ∧ code e2422376622042 = 11218469644250 := by decide
theorem cert_e2422376622042 : check e2422376622042 [[],[]] .three = true := by decide
def e2422376622106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422376622106 : Closed e2422376622106 ∧ code e2422376622106 = 11218469644314 := by decide
theorem cert_e2422376622106 : check e2422376622106 [[],[]] .smaller = true := by decide
def e2422376622142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422376622142 : Closed e2422376622142 ∧ code e2422376622142 = 11218469644350 := by decide
theorem cert_e2422376622142 : check e2422376622142 [[],[]] .smaller = true := by decide
def e2422376622190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422376622190 : Closed e2422376622190 ∧ code e2422376622190 = 11218469644398 := by decide
theorem cert_e2422376622190 : check e2422376622190 [[],[]] .smaller = true := by decide
def e2422376622198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422376622198 : Closed e2422376622198 ∧ code e2422376622198 = 11218469644406 := by decide
theorem cert_e2422376622198 : check e2422376622198 [[],[]] .smaller = true := by decide
def e2422376622202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422376622202 : Closed e2422376622202 ∧ code e2422376622202 = 11218469644410 := by decide
theorem cert_e2422376622202 : check e2422376622202 [[],[]] .smaller = true := by decide
def e2422376622442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422376622442 : Closed e2422376622442 ∧ code e2422376622442 = 11218469644650 := by decide
theorem cert_e2422376622442 : check e2422376622442 [[],[]] .smaller = true := by decide
def e2422376622466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422376622466 : Closed e2422376622466 ∧ code e2422376622466 = 11218469644674 := by decide
theorem cert_e2422376622466 : check e2422376622466 [[],[]] .smaller = true := by decide
def e2422376622478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422376622478 : Closed e2422376622478 ∧ code e2422376622478 = 11218469644686 := by decide
theorem cert_e2422376622478 : check e2422376622478 [[],[]] .smaller = true := by decide
def e2422376622490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422376622490 : Closed e2422376622490 ∧ code e2422376622490 = 11218469644698 := by decide
theorem cert_e2422376622490 : check e2422376622490 [[],[]] .smaller = true := by decide
def e2422376622534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422376622534 : Closed e2422376622534 ∧ code e2422376622534 = 11218469644742 := by decide
theorem cert_e2422376622534 : check e2422376622534 [[],[]] .smaller = true := by decide
def e2422376622558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422376622558 : Closed e2422376622558 ∧ code e2422376622558 = 11218469644766 := by decide
theorem cert_e2422376622558 : check e2422376622558 [[],[]] .three = true := by decide
def e2422376622562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422376622562 : Closed e2422376622562 ∧ code e2422376622562 = 11218469644770 := by decide
theorem cert_e2422376622562 : check e2422376622562 [[],[]] .smaller = true := by decide
def e2422376622574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422376622574 : Closed e2422376622574 ∧ code e2422376622574 = 11218469644782 := by decide
theorem cert_e2422376622574 : check e2422376622574 [[],[]] .smaller = true := by decide
def e2422376622582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422376622582 : Closed e2422376622582 ∧ code e2422376622582 = 11218469644790 := by decide
theorem cert_e2422376622582 : check e2422376622582 [[],[]] .three = true := by decide
def e2422376623158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376623158 : Closed e2422376623158 ∧ code e2422376623158 = 11218469645366 := by decide
theorem cert_e2422376623158 : check e2422376623158 [[],[]] .smaller = true := by decide
def e2422376623162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376623162 : Closed e2422376623162 ∧ code e2422376623162 = 11218469645370 := by decide
theorem cert_e2422376623162 : check e2422376623162 [[],[]] .smaller = true := by decide
def e2422376623302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422376623302 : Closed e2422376623302 ∧ code e2422376623302 = 11218469645510 := by decide
theorem cert_e2422376623302 : check e2422376623302 [[],[]] .smaller = true := by decide
def e2422376623326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422376623326 : Closed e2422376623326 ∧ code e2422376623326 = 11218469645534 := by decide
theorem cert_e2422376623326 : check e2422376623326 [[],[]] .three = true := by decide
def e2422376623354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422376623354 : Closed e2422376623354 ∧ code e2422376623354 = 11218469645562 := by decide
theorem cert_e2422376623354 : check e2422376623354 [[],[]] .three = true := by decide
def e2422376623630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422376623630 : Closed e2422376623630 ∧ code e2422376623630 = 11218469645838 := by decide
theorem cert_e2422376623630 : check e2422376623630 [[],[]] .smaller = true := by decide
def e2422376623678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e2422376623678 : Closed e2422376623678 ∧ code e2422376623678 = 11218469645886 := by decide
theorem cert_e2422376623678 : check e2422376623678 [[],[]] .three = true := by decide
def e2422376623714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422376623714 : Closed e2422376623714 ∧ code e2422376623714 = 11218469645922 := by decide
theorem cert_e2422376623714 : check e2422376623714 [[],[]] .smaller = true := by decide
def e2422376623726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422376623726 : Closed e2422376623726 ∧ code e2422376623726 = 11218469645934 := by decide
theorem cert_e2422376623726 : check e2422376623726 [[],[]] .smaller = true := by decide
def e2422376623738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422376623738 : Closed e2422376623738 ∧ code e2422376623738 = 11218469645946 := by decide
theorem cert_e2422376623738 : check e2422376623738 [[],[]] .smaller = true := by decide
def e2422376623902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e2422376623902 : Closed e2422376623902 ∧ code e2422376623902 = 11218469646110 := by decide
theorem cert_e2422376623902 : check e2422376623902 [[],[]] .three = true := by decide
def e2422376623926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422376623926 : Closed e2422376623926 ∧ code e2422376623926 = 11218469646134 := by decide
theorem cert_e2422376623926 : check e2422376623926 [[],[]] .three = true := by decide
def e2422376623930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422376623930 : Closed e2422376623930 ∧ code e2422376623930 = 11218469646138 := by decide
theorem cert_e2422376623930 : check e2422376623930 [[],[]] .three = true := by decide
def e2422376624246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422376624246 : Closed e2422376624246 ∧ code e2422376624246 = 11218469646454 := by decide
theorem cert_e2422376624246 : check e2422376624246 [[],[]] .three = true := by decide
def e2422376624250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422376624250 : Closed e2422376624250 ∧ code e2422376624250 = 11218469646458 := by decide
theorem cert_e2422376624250 : check e2422376624250 [[],[]] .three = true := by decide
def e2422376624346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422376624346 : Closed e2422376624346 ∧ code e2422376624346 = 11218469646554 := by decide
theorem cert_e2422376624346 : check e2422376624346 [[],[]] .three = true := by decide
def e2422376624362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422376624362 : Closed e2422376624362 ∧ code e2422376624362 = 11218469646570 := by decide
theorem cert_e2422376624362 : check e2422376624362 [[],[]] .three = true := by decide
def e2422376624438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422376624438 : Closed e2422376624438 ∧ code e2422376624438 = 11218469646646 := by decide
theorem cert_e2422376624438 : check e2422376624438 [[],[]] .three = true := by decide
def e2422376624442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422376624442 : Closed e2422376624442 ∧ code e2422376624442 = 11218469646650 := by decide
theorem cert_e2422376624442 : check e2422376624442 [[],[]] .three = true := by decide
def e2422376624526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422376624526 : Closed e2422376624526 ∧ code e2422376624526 = 11218469646734 := by decide
theorem cert_e2422376624526 : check e2422376624526 [[],[]] .three = true := by decide
def e2422376624538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376624538 : Closed e2422376624538 ∧ code e2422376624538 = 11218469646746 := by decide
theorem cert_e2422376624538 : check e2422376624538 [[],[]] .three = true := by decide
def e2422376624582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422376624582 : Closed e2422376624582 ∧ code e2422376624582 = 11218469646790 := by decide
theorem cert_e2422376624582 : check e2422376624582 [[],[]] .three = true := by decide
def e2422376624622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.lam (.var 3))) (.var 2))))))))
theorem wire_e2422376624622 : Closed e2422376624622 ∧ code e2422376624622 = 11218469646830 := by decide
theorem cert_e2422376624622 : check e2422376624622 [[],[]] .three = true := by decide
def e2422376624918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422376624918 : Closed e2422376624918 ∧ code e2422376624918 = 11218469647126 := by decide
theorem cert_e2422376624918 : check e2422376624918 [[],[]] .three = true := by decide
def e2422376624922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422376624922 : Closed e2422376624922 ∧ code e2422376624922 = 11218469647130 := by decide
theorem cert_e2422376624922 : check e2422376624922 [[],[]] .three = true := by decide
def e2422376624966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422376624966 : Closed e2422376624966 ∧ code e2422376624966 = 11218469647174 := by decide
theorem cert_e2422376624966 : check e2422376624966 [[],[]] .three = true := by decide
def e2422376624990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2422376624990 : Closed e2422376624990 ∧ code e2422376624990 = 11218469647198 := by decide
theorem cert_e2422376624990 : check e2422376624990 [[],[]] .three = true := by decide
def e2422376624994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422376624994 : Closed e2422376624994 ∧ code e2422376624994 = 11218469647202 := by decide
theorem cert_e2422376624994 : check e2422376624994 [[],[]] .three = true := by decide
def e2422376625006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422376625006 : Closed e2422376625006 ∧ code e2422376625006 = 11218469647214 := by decide
theorem cert_e2422376625006 : check e2422376625006 [[],[]] .three = true := by decide
def e2422376625014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422376625014 : Closed e2422376625014 ∧ code e2422376625014 = 11218469647222 := by decide
theorem cert_e2422376625014 : check e2422376625014 [[],[]] .three = true := by decide
def e2422376625018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2422376625018 : Closed e2422376625018 ∧ code e2422376625018 = 11218469647226 := by decide
theorem cert_e2422376625018 : check e2422376625018 [[],[]] .three = true := by decide
def e2422376625034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422376625034 : Closed e2422376625034 ∧ code e2422376625034 = 11218469647242 := by decide
theorem cert_e2422376625034 : check e2422376625034 [[],[]] .three = true := by decide
def e2422376625058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422376625058 : Closed e2422376625058 ∧ code e2422376625058 = 11218469647266 := by decide
theorem cert_e2422376625058 : check e2422376625058 [[],[]] .three = true := by decide
def e2422376625070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422376625070 : Closed e2422376625070 ∧ code e2422376625070 = 11218469647278 := by decide
theorem cert_e2422376625070 : check e2422376625070 [[],[]] .three = true := by decide
def e2422376625082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422376625082 : Closed e2422376625082 ∧ code e2422376625082 = 11218469647290 := by decide
theorem cert_e2422376625082 : check e2422376625082 [[],[]] .three = true := by decide
def e2422376625110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422376625110 : Closed e2422376625110 ∧ code e2422376625110 = 11218469647318 := by decide
theorem cert_e2422376625110 : check e2422376625110 [[],[]] .three = true := by decide
def e2422376625114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422376625114 : Closed e2422376625114 ∧ code e2422376625114 = 11218469647322 := by decide
theorem cert_e2422376625114 : check e2422376625114 [[],[]] .three = true := by decide
def e2422376625130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2422376625130 : Closed e2422376625130 ∧ code e2422376625130 = 11218469647338 := by decide
theorem cert_e2422376625130 : check e2422376625130 [[],[]] .three = true := by decide
def e2422376625182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422376625182 : Closed e2422376625182 ∧ code e2422376625182 = 11218469647390 := by decide
theorem cert_e2422376625182 : check e2422376625182 [[],[]] .three = true := by decide
def e2422376625206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376625206 : Closed e2422376625206 ∧ code e2422376625206 = 11218469647414 := by decide
theorem cert_e2422376625206 : check e2422376625206 [[],[]] .three = true := by decide
def e2422376625210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376625210 : Closed e2422376625210 ∧ code e2422376625210 = 11218469647418 := by decide
theorem cert_e2422376625210 : check e2422376625210 [[],[]] .three = true := by decide
def e2422376625350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422376625350 : Closed e2422376625350 ∧ code e2422376625350 = 11218469647558 := by decide
theorem cert_e2422376625350 : check e2422376625350 [[],[]] .three = true := by decide
def e2422376625374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422376625374 : Closed e2422376625374 ∧ code e2422376625374 = 11218469647582 := by decide
theorem cert_e2422376625374 : check e2422376625374 [[],[]] .three = true := by decide
def e2422376625378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422376625378 : Closed e2422376625378 ∧ code e2422376625378 = 11218469647586 := by decide
theorem cert_e2422376625378 : check e2422376625378 [[],[]] .three = true := by decide
def e2422376625390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422376625390 : Closed e2422376625390 ∧ code e2422376625390 = 11218469647598 := by decide
theorem cert_e2422376625390 : check e2422376625390 [[],[]] .three = true := by decide
def e2422376625398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422376625398 : Closed e2422376625398 ∧ code e2422376625398 = 11218469647606 := by decide
theorem cert_e2422376625398 : check e2422376625398 [[],[]] .three = true := by decide
def e2422376625402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422376625402 : Closed e2422376625402 ∧ code e2422376625402 = 11218469647610 := by decide
theorem cert_e2422376625402 : check e2422376625402 [[],[]] .three = true := by decide
def e2422376625678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422376625678 : Closed e2422376625678 ∧ code e2422376625678 = 11218469647886 := by decide
theorem cert_e2422376625678 : check e2422376625678 [[],[]] .three = true := by decide
def e2422376625762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422376625762 : Closed e2422376625762 ∧ code e2422376625762 = 11218469647970 := by decide
theorem cert_e2422376625762 : check e2422376625762 [[],[]] .three = true := by decide
def e2422376625774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422376625774 : Closed e2422376625774 ∧ code e2422376625774 = 11218469647982 := by decide
theorem cert_e2422376625774 : check e2422376625774 [[],[]] .three = true := by decide
def e2422376625786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422376625786 : Closed e2422376625786 ∧ code e2422376625786 = 11218469647994 := by decide
theorem cert_e2422376625786 : check e2422376625786 [[],[]] .three = true := by decide
def e2422376625950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.lam (.var 3)))))))))
theorem wire_e2422376625950 : Closed e2422376625950 ∧ code e2422376625950 = 11218469648158 := by decide
theorem cert_e2422376625950 : check e2422376625950 [[],[]] .three = true := by decide
def e2422376625974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422376625974 : Closed e2422376625974 ∧ code e2422376625974 = 11218469648182 := by decide
theorem cert_e2422376625974 : check e2422376625974 [[],[]] .three = true := by decide
def e2422376625978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422376625978 : Closed e2422376625978 ∧ code e2422376625978 = 11218469648186 := by decide
theorem cert_e2422376625978 : check e2422376625978 [[],[]] .three = true := by decide
def e2422376626074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376626074 : Closed e2422376626074 ∧ code e2422376626074 = 11218469648282 := by decide
theorem cert_e2422376626074 : check e2422376626074 [[],[]] .three = true := by decide
def e2422376630206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 4)))))))))))
theorem wire_e2422376630206 : Closed e2422376630206 ∧ code e2422376630206 = 11218469652414 := by decide
theorem cert_e2422376630206 : check e2422376630206 [[],[]] .smaller = true := by decide
def e2422376630254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 2)))))))))))
theorem wire_e2422376630254 : Closed e2422376630254 ∧ code e2422376630254 = 11218469652462 := by decide
theorem cert_e2422376630254 : check e2422376630254 [[],[]] .smaller = true := by decide
def e2422376634046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 4))))))))))
theorem wire_e2422376634046 : Closed e2422376634046 ∧ code e2422376634046 = 11218469656254 := by decide
theorem cert_e2422376634046 : check e2422376634046 [[],[]] .three = true := by decide
def e2422376634078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2422376634078 : Closed e2422376634078 ∧ code e2422376634078 = 11218469656286 := by decide
theorem cert_e2422376634078 : check e2422376634078 [[],[]] .smaller = true := by decide
def e2422376634102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2422376634102 : Closed e2422376634102 ∧ code e2422376634102 = 11218469656310 := by decide
theorem cert_e2422376634102 : check e2422376634102 [[],[]] .smaller = true := by decide
def e2422376634106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 0))))))))))
theorem wire_e2422376634106 : Closed e2422376634106 ∧ code e2422376634106 = 11218469656314 := by decide
theorem cert_e2422376634106 : check e2422376634106 [[],[]] .three = true := by decide
def e2422376634206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2422376634206 : Closed e2422376634206 ∧ code e2422376634206 = 11218469656414 := by decide
theorem cert_e2422376634206 : check e2422376634206 [[],[]] .smaller = true := by decide
def e2422376634234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2422376634234 : Closed e2422376634234 ∧ code e2422376634234 = 11218469656442 := by decide
theorem cert_e2422376634234 : check e2422376634234 [[],[]] .smaller = true := by decide
def e2422376634326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2422376634326 : Closed e2422376634326 ∧ code e2422376634326 = 11218469656534 := by decide
theorem cert_e2422376634326 : check e2422376634326 [[],[]] .smaller = true := by decide
def e2422376634330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2422376634330 : Closed e2422376634330 ∧ code e2422376634330 = 11218469656538 := by decide
theorem cert_e2422376634330 : check e2422376634330 [[],[]] .smaller = true := by decide
def e2422376634346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 0))))))))))
theorem wire_e2422376634346 : Closed e2422376634346 ∧ code e2422376634346 = 11218469656554 := by decide
theorem cert_e2422376634346 : check e2422376634346 [[],[]] .three = true := by decide
def e2422376634814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422376634814 : Closed e2422376634814 ∧ code e2422376634814 = 11218469657022 := by decide
theorem cert_e2422376634814 : check e2422376634814 [[],[]] .three = true := by decide
def e2422376634846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422376634846 : Closed e2422376634846 ∧ code e2422376634846 = 11218469657054 := by decide
theorem cert_e2422376634846 : check e2422376634846 [[],[]] .smaller = true := by decide
def e2422376634870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422376634870 : Closed e2422376634870 ∧ code e2422376634870 = 11218469657078 := by decide
theorem cert_e2422376634870 : check e2422376634870 [[],[]] .smaller = true := by decide
def e2422376634874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422376634874 : Closed e2422376634874 ∧ code e2422376634874 = 11218469657082 := by decide
theorem cert_e2422376634874 : check e2422376634874 [[],[]] .three = true := by decide
def e2422376635518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 5)))))))))))
theorem wire_e2422376635518 : Closed e2422376635518 ∧ code e2422376635518 = 11218469657726 := by decide
theorem cert_e2422376635518 : check e2422376635518 [[],[]] .three = true := by decide
def e2422376635614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422376635614 : Closed e2422376635614 ∧ code e2422376635614 = 11218469657822 := by decide
theorem cert_e2422376635614 : check e2422376635614 [[],[]] .smaller = true := by decide
def e2422376635642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422376635642 : Closed e2422376635642 ∧ code e2422376635642 = 11218469657850 := by decide
theorem cert_e2422376635642 : check e2422376635642 [[],[]] .smaller = true := by decide
def e2422376635966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e2422376635966 : Closed e2422376635966 ∧ code e2422376635966 = 11218469658174 := by decide
theorem cert_e2422376635966 : check e2422376635966 [[],[]] .smaller = true := by decide
def e2422376636190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e2422376636190 : Closed e2422376636190 ∧ code e2422376636190 = 11218469658398 := by decide
theorem cert_e2422376636190 : check e2422376636190 [[],[]] .smaller = true := by decide
def e2422376636214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376636214 : Closed e2422376636214 ∧ code e2422376636214 = 11218469658422 := by decide
theorem cert_e2422376636214 : check e2422376636214 [[],[]] .smaller = true := by decide
def e2422376636218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376636218 : Closed e2422376636218 ∧ code e2422376636218 = 11218469658426 := by decide
theorem cert_e2422376636218 : check e2422376636218 [[],[]] .smaller = true := by decide
def e2422376636302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.lam (.var 2)))))))))))
theorem wire_e2422376636302 : Closed e2422376636302 ∧ code e2422376636302 = 11218469658510 := by decide
theorem cert_e2422376636302 : check e2422376636302 [[],[]] .three = true := by decide
def e2422376636314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422376636314 : Closed e2422376636314 ∧ code e2422376636314 = 11218469658522 := by decide
theorem cert_e2422376636314 : check e2422376636314 [[],[]] .three = true := by decide
def e2422376636350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 4) (.var 4))))))))))
theorem wire_e2422376636350 : Closed e2422376636350 ∧ code e2422376636350 = 11218469658558 := by decide
theorem cert_e2422376636350 : check e2422376636350 [[],[]] .three = true := by decide
def e2422376650414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422376650414 : Closed e2422376650414 ∧ code e2422376650414 = 11218469672622 := by decide
theorem cert_e2422376650414 : check e2422376650414 [[],[]] .smaller = true := by decide
def e2422376650426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422376650426 : Closed e2422376650426 ∧ code e2422376650426 = 11218469672634 := by decide
theorem cert_e2422376650426 : check e2422376650426 [[],[]] .smaller = true := by decide
def e2422376650474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422376650474 : Closed e2422376650474 ∧ code e2422376650474 = 11218469672682 := by decide
theorem cert_e2422376650474 : check e2422376650474 [[],[]] .smaller = true := by decide
def e2422376650666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422376650666 : Closed e2422376650666 ∧ code e2422376650666 = 11218469672874 := by decide
theorem cert_e2422376650666 : check e2422376650666 [[],[]] .smaller = true := by decide
def e2422376650798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)))))))))
theorem wire_e2422376650798 : Closed e2422376650798 ∧ code e2422376650798 = 11218469673006 := by decide
theorem cert_e2422376650798 : check e2422376650798 [[],[]] .smaller = true := by decide
def e2422376650974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e2422376650974 : Closed e2422376650974 ∧ code e2422376650974 = 11218469673182 := by decide
theorem cert_e2422376650974 : check e2422376650974 [[],[]] .three = true := by decide
def e2422376650990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2422376650990 : Closed e2422376650990 ∧ code e2422376650990 = 11218469673198 := by decide
theorem cert_e2422376650990 : check e2422376650990 [[],[]] .smaller = true := by decide
def e2422376650998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2422376650998 : Closed e2422376650998 ∧ code e2422376650998 = 11218469673206 := by decide
theorem cert_e2422376650998 : check e2422376650998 [[],[]] .smaller = true := by decide
def e2422376651002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e2422376651002 : Closed e2422376651002 ∧ code e2422376651002 = 11218469673210 := by decide
theorem cert_e2422376651002 : check e2422376651002 [[],[]] .three = true := by decide
def e2422376651182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422376651182 : Closed e2422376651182 ∧ code e2422376651182 = 11218469673390 := by decide
theorem cert_e2422376651182 : check e2422376651182 [[],[]] .smaller = true := by decide
def e2422376651194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422376651194 : Closed e2422376651194 ∧ code e2422376651194 = 11218469673402 := by decide
theorem cert_e2422376651194 : check e2422376651194 [[],[]] .smaller = true := by decide
def e2422376651242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422376651242 : Closed e2422376651242 ∧ code e2422376651242 = 11218469673450 := by decide
theorem cert_e2422376651242 : check e2422376651242 [[],[]] .smaller = true := by decide
def e2422376651326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e2422376651326 : Closed e2422376651326 ∧ code e2422376651326 = 11218469673534 := by decide
theorem cert_e2422376651326 : check e2422376651326 [[],[]] .three = true := by decide
def e2422376651374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422376651374 : Closed e2422376651374 ∧ code e2422376651374 = 11218469673582 := by decide
theorem cert_e2422376651374 : check e2422376651374 [[],[]] .smaller = true := by decide
def e2422376651386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422376651386 : Closed e2422376651386 ∧ code e2422376651386 = 11218469673594 := by decide
theorem cert_e2422376651386 : check e2422376651386 [[],[]] .smaller = true := by decide
def e2422376651550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2422376651550 : Closed e2422376651550 ∧ code e2422376651550 = 11218469673758 := by decide
theorem cert_e2422376651550 : check e2422376651550 [[],[]] .smaller = true := by decide
def e2422376651650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422376651650 : Closed e2422376651650 ∧ code e2422376651650 = 11218469673858 := by decide
theorem cert_e2422376651650 : check e2422376651650 [[],[]] .smaller = true := by decide
def e2422376651662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2422376651662 : Closed e2422376651662 ∧ code e2422376651662 = 11218469673870 := by decide
theorem cert_e2422376651662 : check e2422376651662 [[],[]] .smaller = true := by decide
def e2422376651674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422376651674 : Closed e2422376651674 ∧ code e2422376651674 = 11218469673882 := by decide
theorem cert_e2422376651674 : check e2422376651674 [[],[]] .smaller = true := by decide
def e2422376651718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e2422376651718 : Closed e2422376651718 ∧ code e2422376651718 = 11218469673926 := by decide
theorem cert_e2422376651718 : check e2422376651718 [[],[]] .three = true := by decide
def e2422376651742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 3)))))))))
theorem wire_e2422376651742 : Closed e2422376651742 ∧ code e2422376651742 = 11218469673950 := by decide
theorem cert_e2422376651742 : check e2422376651742 [[],[]] .three = true := by decide
def e2422376651870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e2422376651870 : Closed e2422376651870 ∧ code e2422376651870 = 11218469674078 := by decide
theorem cert_e2422376651870 : check e2422376651870 [[],[]] .three = true := by decide
def e2422376651886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2422376651886 : Closed e2422376651886 ∧ code e2422376651886 = 11218469674094 := by decide
theorem cert_e2422376651886 : check e2422376651886 [[],[]] .smaller = true := by decide
def e2422376651898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2422376651898 : Closed e2422376651898 ∧ code e2422376651898 = 11218469674106 := by decide
theorem cert_e2422376651898 : check e2422376651898 [[],[]] .smaller = true := by decide
def e2422376652062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2422376652062 : Closed e2422376652062 ∧ code e2422376652062 = 11218469674270 := by decide
theorem cert_e2422376652062 : check e2422376652062 [[],[]] .smaller = true := by decide
def e2422376652230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2422376652230 : Closed e2422376652230 ∧ code e2422376652230 = 11218469674438 := by decide
theorem cert_e2422376652230 : check e2422376652230 [[],[]] .smaller = true := by decide
def e2422376652254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e2422376652254 : Closed e2422376652254 ∧ code e2422376652254 = 11218469674462 := by decide
theorem cert_e2422376652254 : check e2422376652254 [[],[]] .three = true := by decide
def e2422376652258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e2422376652258 : Closed e2422376652258 ∧ code e2422376652258 = 11218469674466 := by decide
theorem cert_e2422376652258 : check e2422376652258 [[],[]] .three = true := by decide
def e2422376652270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e2422376652270 : Closed e2422376652270 ∧ code e2422376652270 = 11218469674478 := by decide
theorem cert_e2422376652270 : check e2422376652270 [[],[]] .three = true := by decide
def e2422376652298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422376652298 : Closed e2422376652298 ∧ code e2422376652298 = 11218469674506 := by decide
theorem cert_e2422376652298 : check e2422376652298 [[],[]] .smaller = true := by decide
def e2422376652334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422376652334 : Closed e2422376652334 ∧ code e2422376652334 = 11218469674542 := by decide
theorem cert_e2422376652334 : check e2422376652334 [[],[]] .smaller = true := by decide
def e2422376652342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422376652342 : Closed e2422376652342 ∧ code e2422376652342 = 11218469674550 := by decide
theorem cert_e2422376652342 : check e2422376652342 [[],[]] .smaller = true := by decide
def e2422376652346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422376652346 : Closed e2422376652346 ∧ code e2422376652346 = 11218469674554 := by decide
theorem cert_e2422376652346 : check e2422376652346 [[],[]] .smaller = true := by decide
def e2422376652394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422376652394 : Closed e2422376652394 ∧ code e2422376652394 = 11218469674602 := by decide
theorem cert_e2422376652394 : check e2422376652394 [[],[]] .smaller = true := by decide
def e2422376652418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422376652418 : Closed e2422376652418 ∧ code e2422376652418 = 11218469674626 := by decide
theorem cert_e2422376652418 : check e2422376652418 [[],[]] .smaller = true := by decide
def e2422376652430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422376652430 : Closed e2422376652430 ∧ code e2422376652430 = 11218469674638 := by decide
theorem cert_e2422376652430 : check e2422376652430 [[],[]] .smaller = true := by decide
def e2422376652442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422376652442 : Closed e2422376652442 ∧ code e2422376652442 = 11218469674650 := by decide
theorem cert_e2422376652442 : check e2422376652442 [[],[]] .smaller = true := by decide
def e2422376652486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422376652486 : Closed e2422376652486 ∧ code e2422376652486 = 11218469674694 := by decide
theorem cert_e2422376652486 : check e2422376652486 [[],[]] .smaller = true := by decide
def e2422376652510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e2422376652510 : Closed e2422376652510 ∧ code e2422376652510 = 11218469674718 := by decide
theorem cert_e2422376652510 : check e2422376652510 [[],[]] .three = true := by decide
def e2422376652514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422376652514 : Closed e2422376652514 ∧ code e2422376652514 = 11218469674722 := by decide
theorem cert_e2422376652514 : check e2422376652514 [[],[]] .smaller = true := by decide
def e2422376652526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 2)))))))))
theorem wire_e2422376652526 : Closed e2422376652526 ∧ code e2422376652526 = 11218469674734 := by decide
theorem cert_e2422376652526 : check e2422376652526 [[],[]] .smaller = true := by decide
def e2422376652534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e2422376652534 : Closed e2422376652534 ∧ code e2422376652534 = 11218469674742 := by decide
theorem cert_e2422376652534 : check e2422376652534 [[],[]] .three = true := by decide
end Blc.Floor43
