import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374183854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e2422374183854 : Closed e2422374183854 ∧ code e2422374183854 = 11218467206062 := by decide
theorem cert_e2422374183854 : check e2422374183854 [[],[]] .smaller = true := by decide
def e2422374183866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e2422374183866 : Closed e2422374183866 ∧ code e2422374183866 = 11218467206074 := by decide
theorem cert_e2422374183866 : check e2422374183866 [[],[]] .smaller = true := by decide
def e2422374183894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e2422374183894 : Closed e2422374183894 ∧ code e2422374183894 = 11218467206102 := by decide
theorem cert_e2422374183894 : check e2422374183894 [[],[]] .smaller = true := by decide
def e2422374183898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e2422374183898 : Closed e2422374183898 ∧ code e2422374183898 = 11218467206106 := by decide
theorem cert_e2422374183898 : check e2422374183898 [[],[]] .smaller = true := by decide
def e2422374184174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422374184174 : Closed e2422374184174 ∧ code e2422374184174 = 11218467206382 := by decide
theorem cert_e2422374184174 : check e2422374184174 [[],[]] .smaller = true := by decide
def e2422374184182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422374184182 : Closed e2422374184182 ∧ code e2422374184182 = 11218467206390 := by decide
theorem cert_e2422374184182 : check e2422374184182 [[],[]] .smaller = true := by decide
def e2422374184558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374184558 : Closed e2422374184558 ∧ code e2422374184558 = 11218467206766 := by decide
theorem cert_e2422374184558 : check e2422374184558 [[],[]] .smaller = true := by decide
def e2422374184570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374184570 : Closed e2422374184570 ∧ code e2422374184570 = 11218467206778 := by decide
theorem cert_e2422374184570 : check e2422374184570 [[],[]] .smaller = true := by decide
def e2422374184758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374184758 : Closed e2422374184758 ∧ code e2422374184758 = 11218467206966 := by decide
theorem cert_e2422374184758 : check e2422374184758 [[],[]] .smaller = true := by decide
def e2422374184762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374184762 : Closed e2422374184762 ∧ code e2422374184762 = 11218467206970 := by decide
theorem cert_e2422374184762 : check e2422374184762 [[],[]] .smaller = true := by decide
def e2422374184830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 5))))))))))
theorem wire_e2422374184830 : Closed e2422374184830 ∧ code e2422374184830 = 11218467207038 := by decide
theorem cert_e2422374184830 : check e2422374184830 [[],[]] .three = true := by decide
def e2422374184942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 5)) (.var 2))))))))))
theorem wire_e2422374184942 : Closed e2422374184942 ∧ code e2422374184942 = 11218467207150 := by decide
theorem cert_e2422374184942 : check e2422374184942 [[],[]] .three = true := by decide
def e2422374185390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e2422374185390 : Closed e2422374185390 ∧ code e2422374185390 = 11218467207598 := by decide
theorem cert_e2422374185390 : check e2422374185390 [[],[]] .smaller = true := by decide
def e2422374185402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e2422374185402 : Closed e2422374185402 ∧ code e2422374185402 = 11218467207610 := by decide
theorem cert_e2422374185402 : check e2422374185402 [[],[]] .smaller = true := by decide
def e2422374185450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e2422374185450 : Closed e2422374185450 ∧ code e2422374185450 = 11218467207658 := by decide
theorem cert_e2422374185450 : check e2422374185450 [[],[]] .smaller = true := by decide
def e2422374185582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374185582 : Closed e2422374185582 ∧ code e2422374185582 = 11218467207790 := by decide
theorem cert_e2422374185582 : check e2422374185582 [[],[]] .smaller = true := by decide
def e2422374185594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374185594 : Closed e2422374185594 ∧ code e2422374185594 = 11218467207802 := by decide
theorem cert_e2422374185594 : check e2422374185594 [[],[]] .smaller = true := by decide
def e2422374185882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374185882 : Closed e2422374185882 ∧ code e2422374185882 = 11218467208090 := by decide
theorem cert_e2422374185882 : check e2422374185882 [[],[]] .smaller = true := by decide
def e2422374185918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 4))))))))))
theorem wire_e2422374185918 : Closed e2422374185918 ∧ code e2422374185918 = 11218467208126 := by decide
theorem cert_e2422374185918 : check e2422374185918 [[],[]] .smaller = true := by decide
def e2422374185966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 2))))))))))
theorem wire_e2422374185966 : Closed e2422374185966 ∧ code e2422374185966 = 11218467208174 := by decide
theorem cert_e2422374185966 : check e2422374185966 [[],[]] .smaller = true := by decide
def e2422374186198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e2422374186198 : Closed e2422374186198 ∧ code e2422374186198 = 11218467208406 := by decide
theorem cert_e2422374186198 : check e2422374186198 [[],[]] .smaller = true := by decide
def e2422374186202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e2422374186202 : Closed e2422374186202 ∧ code e2422374186202 = 11218467208410 := by decide
theorem cert_e2422374186202 : check e2422374186202 [[],[]] .smaller = true := by decide
def e2422374186218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e2422374186218 : Closed e2422374186218 ∧ code e2422374186218 = 11218467208426 := by decide
theorem cert_e2422374186218 : check e2422374186218 [[],[]] .smaller = true := by decide
def e2422374186294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374186294 : Closed e2422374186294 ∧ code e2422374186294 = 11218467208502 := by decide
theorem cert_e2422374186294 : check e2422374186294 [[],[]] .smaller = true := by decide
def e2422374186298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374186298 : Closed e2422374186298 ∧ code e2422374186298 = 11218467208506 := by decide
theorem cert_e2422374186298 : check e2422374186298 [[],[]] .smaller = true := by decide
def e2422374186366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 5))))))))))
theorem wire_e2422374186366 : Closed e2422374186366 ∧ code e2422374186366 = 11218467208574 := by decide
theorem cert_e2422374186366 : check e2422374186366 [[],[]] .three = true := by decide
def e2422374186394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374186394 : Closed e2422374186394 ∧ code e2422374186394 = 11218467208602 := by decide
theorem cert_e2422374186394 : check e2422374186394 [[],[]] .smaller = true := by decide
def e2422374186430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 4))))))))))
theorem wire_e2422374186430 : Closed e2422374186430 ∧ code e2422374186430 = 11218467208638 := by decide
theorem cert_e2422374186430 : check e2422374186430 [[],[]] .smaller = true := by decide
def e2422374186486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 4)) (.var 1))))))))))
theorem wire_e2422374186486 : Closed e2422374186486 ∧ code e2422374186486 = 11218467208694 := by decide
theorem cert_e2422374186486 : check e2422374186486 [[],[]] .smaller = true := by decide
def e2422374186490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 5)) (.var 0))))))))))
theorem wire_e2422374186490 : Closed e2422374186490 ∧ code e2422374186490 = 11218467208698 := by decide
theorem cert_e2422374186490 : check e2422374186490 [[],[]] .three = true := by decide
def e2422374186862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))))))
theorem wire_e2422374186862 : Closed e2422374186862 ∧ code e2422374186862 = 11218467209070 := by decide
theorem cert_e2422374186862 : check e2422374186862 [[],[]] .smaller = true := by decide
def e2422374186870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 2)) (.var 1))))))))))
theorem wire_e2422374186870 : Closed e2422374186870 ∧ code e2422374186870 = 11218467209078 := by decide
theorem cert_e2422374186870 : check e2422374186870 [[],[]] .smaller = true := by decide
def e2422374186926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 5) (.var 0)) (.var 2))))))))))
theorem wire_e2422374186926 : Closed e2422374186926 ∧ code e2422374186926 = 11218467209134 := by decide
theorem cert_e2422374186926 : check e2422374186926 [[],[]] .three = true := by decide
def e2422374186938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 5) (.var 2)) (.var 0))))))))))
theorem wire_e2422374186938 : Closed e2422374186938 ∧ code e2422374186938 = 11218467209146 := by decide
theorem cert_e2422374186938 : check e2422374186938 [[],[]] .three = true := by decide
def e2422374187998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))))
theorem wire_e2422374187998 : Closed e2422374187998 ∧ code e2422374187998 = 11218467210206 := by decide
theorem cert_e2422374187998 : check e2422374187998 [[],[]] .smaller = true := by decide
def e2422374188014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))))
theorem wire_e2422374188014 : Closed e2422374188014 ∧ code e2422374188014 = 11218467210222 := by decide
theorem cert_e2422374188014 : check e2422374188014 [[],[]] .smaller = true := by decide
def e2422374189934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e2422374189934 : Closed e2422374189934 ∧ code e2422374189934 = 11218467212142 := by decide
theorem cert_e2422374189934 : check e2422374189934 [[],[]] .smaller = true := by decide
def e2422374189942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e2422374189942 : Closed e2422374189942 ∧ code e2422374189942 = 11218467212150 := by decide
theorem cert_e2422374189942 : check e2422374189942 [[],[]] .smaller = true := by decide
def e2422374189998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e2422374189998 : Closed e2422374189998 ∧ code e2422374189998 = 11218467212206 := by decide
theorem cert_e2422374189998 : check e2422374189998 [[],[]] .smaller = true := by decide
def e2422374190010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e2422374190010 : Closed e2422374190010 ∧ code e2422374190010 = 11218467212218 := by decide
theorem cert_e2422374190010 : check e2422374190010 [[],[]] .smaller = true := by decide
def e2422374190038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e2422374190038 : Closed e2422374190038 ∧ code e2422374190038 = 11218467212246 := by decide
theorem cert_e2422374190038 : check e2422374190038 [[],[]] .smaller = true := by decide
def e2422374190042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e2422374190042 : Closed e2422374190042 ∧ code e2422374190042 = 11218467212250 := by decide
theorem cert_e2422374190042 : check e2422374190042 [[],[]] .smaller = true := by decide
def e2422374190318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422374190318 : Closed e2422374190318 ∧ code e2422374190318 = 11218467212526 := by decide
theorem cert_e2422374190318 : check e2422374190318 [[],[]] .smaller = true := by decide
def e2422374190326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422374190326 : Closed e2422374190326 ∧ code e2422374190326 = 11218467212534 := by decide
theorem cert_e2422374190326 : check e2422374190326 [[],[]] .smaller = true := by decide
def e2422374190702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422374190702 : Closed e2422374190702 ∧ code e2422374190702 = 11218467212910 := by decide
theorem cert_e2422374190702 : check e2422374190702 [[],[]] .smaller = true := by decide
def e2422374190714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422374190714 : Closed e2422374190714 ∧ code e2422374190714 = 11218467212922 := by decide
theorem cert_e2422374190714 : check e2422374190714 [[],[]] .smaller = true := by decide
def e2422374190902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422374190902 : Closed e2422374190902 ∧ code e2422374190902 = 11218467213110 := by decide
theorem cert_e2422374190902 : check e2422374190902 [[],[]] .smaller = true := by decide
def e2422374190906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422374190906 : Closed e2422374190906 ∧ code e2422374190906 = 11218467213114 := by decide
theorem cert_e2422374190906 : check e2422374190906 [[],[]] .smaller = true := by decide
def e2422374190974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 5)))))))))))
theorem wire_e2422374190974 : Closed e2422374190974 ∧ code e2422374190974 = 11218467213182 := by decide
theorem cert_e2422374190974 : check e2422374190974 [[],[]] .three = true := by decide
def e2422374191086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 5) (.var 2)))))))))))
theorem wire_e2422374191086 : Closed e2422374191086 ∧ code e2422374191086 = 11218467213294 := by decide
theorem cert_e2422374191086 : check e2422374191086 [[],[]] .three = true := by decide
def e2422374195678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))))
theorem wire_e2422374195678 : Closed e2422374195678 ∧ code e2422374195678 = 11218467217886 := by decide
theorem cert_e2422374195678 : check e2422374195678 [[],[]] .smaller = true := by decide
def e2422374195702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))))
theorem wire_e2422374195702 : Closed e2422374195702 ∧ code e2422374195702 = 11218467217910 := by decide
theorem cert_e2422374195702 : check e2422374195702 [[],[]] .smaller = true := by decide
def e2422374196654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e2422374196654 : Closed e2422374196654 ∧ code e2422374196654 = 11218467218862 := by decide
theorem cert_e2422374196654 : check e2422374196654 [[],[]] .smaller = true := by decide
def e2422374196666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e2422374196666 : Closed e2422374196666 ∧ code e2422374196666 = 11218467218874 := by decide
theorem cert_e2422374196666 : check e2422374196666 [[],[]] .smaller = true := by decide
def e2422374196714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e2422374196714 : Closed e2422374196714 ∧ code e2422374196714 = 11218467218922 := by decide
theorem cert_e2422374196714 : check e2422374196714 [[],[]] .smaller = true := by decide
def e2422374196846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422374196846 : Closed e2422374196846 ∧ code e2422374196846 = 11218467219054 := by decide
theorem cert_e2422374196846 : check e2422374196846 [[],[]] .smaller = true := by decide
def e2422374196858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422374196858 : Closed e2422374196858 ∧ code e2422374196858 = 11218467219066 := by decide
theorem cert_e2422374196858 : check e2422374196858 [[],[]] .smaller = true := by decide
def e2422374197146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422374197146 : Closed e2422374197146 ∧ code e2422374197146 = 11218467219354 := by decide
theorem cert_e2422374197146 : check e2422374197146 [[],[]] .smaller = true := by decide
def e2422374197182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 4)))))))))))
theorem wire_e2422374197182 : Closed e2422374197182 ∧ code e2422374197182 = 11218467219390 := by decide
theorem cert_e2422374197182 : check e2422374197182 [[],[]] .smaller = true := by decide
def e2422374197230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 2)))))))))))
theorem wire_e2422374197230 : Closed e2422374197230 ∧ code e2422374197230 = 11218467219438 := by decide
theorem cert_e2422374197230 : check e2422374197230 [[],[]] .smaller = true := by decide
def e2422374199534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422374199534 : Closed e2422374199534 ∧ code e2422374199534 = 11218467221742 := by decide
theorem cert_e2422374199534 : check e2422374199534 [[],[]] .smaller = true := by decide
def e2422374199542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422374199542 : Closed e2422374199542 ∧ code e2422374199542 = 11218467221750 := by decide
theorem cert_e2422374199542 : check e2422374199542 [[],[]] .smaller = true := by decide
def e2422374200022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e2422374200022 : Closed e2422374200022 ∧ code e2422374200022 = 11218467222230 := by decide
theorem cert_e2422374200022 : check e2422374200022 [[],[]] .smaller = true := by decide
def e2422374200026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e2422374200026 : Closed e2422374200026 ∧ code e2422374200026 = 11218467222234 := by decide
theorem cert_e2422374200026 : check e2422374200026 [[],[]] .smaller = true := by decide
def e2422374200042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e2422374200042 : Closed e2422374200042 ∧ code e2422374200042 = 11218467222250 := by decide
theorem cert_e2422374200042 : check e2422374200042 [[],[]] .smaller = true := by decide
def e2422374200118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422374200118 : Closed e2422374200118 ∧ code e2422374200118 = 11218467222326 := by decide
theorem cert_e2422374200118 : check e2422374200118 [[],[]] .smaller = true := by decide
def e2422374200122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422374200122 : Closed e2422374200122 ∧ code e2422374200122 = 11218467222330 := by decide
theorem cert_e2422374200122 : check e2422374200122 [[],[]] .smaller = true := by decide
def e2422374200190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 5)))))))))))
theorem wire_e2422374200190 : Closed e2422374200190 ∧ code e2422374200190 = 11218467222398 := by decide
theorem cert_e2422374200190 : check e2422374200190 [[],[]] .three = true := by decide
def e2422374200218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422374200218 : Closed e2422374200218 ∧ code e2422374200218 = 11218467222426 := by decide
theorem cert_e2422374200218 : check e2422374200218 [[],[]] .smaller = true := by decide
def e2422374200254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422374200254 : Closed e2422374200254 ∧ code e2422374200254 = 11218467222462 := by decide
theorem cert_e2422374200254 : check e2422374200254 [[],[]] .smaller = true := by decide
def e2422374200310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422374200310 : Closed e2422374200310 ∧ code e2422374200310 = 11218467222518 := by decide
theorem cert_e2422374200310 : check e2422374200310 [[],[]] .smaller = true := by decide
def e2422374200314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 5) (.var 0)))))))))))
theorem wire_e2422374200314 : Closed e2422374200314 ∧ code e2422374200314 = 11218467222522 := by decide
theorem cert_e2422374200314 : check e2422374200314 [[],[]] .three = true := by decide
def e2422374202606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422374202606 : Closed e2422374202606 ∧ code e2422374202606 = 11218467224814 := by decide
theorem cert_e2422374202606 : check e2422374202606 [[],[]] .smaller = true := by decide
def e2422374202614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422374202614 : Closed e2422374202614 ∧ code e2422374202614 = 11218467224822 := by decide
theorem cert_e2422374202614 : check e2422374202614 [[],[]] .smaller = true := by decide
def e2422374202990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 5) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374202990 : Closed e2422374202990 ∧ code e2422374202990 = 11218467225198 := by decide
theorem cert_e2422374202990 : check e2422374202990 [[],[]] .three = true := by decide
def e2422374203002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 5) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374203002 : Closed e2422374203002 ∧ code e2422374203002 = 11218467225210 := by decide
theorem cert_e2422374203002 : check e2422374203002 [[],[]] .three = true := by decide
def e2422374314350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))))
theorem wire_e2422374314350 : Closed e2422374314350 ∧ code e2422374314350 = 11218467336558 := by decide
theorem cert_e2422374314350 : check e2422374314350 [[],[]] .smaller = true := by decide
def e2422374314358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))))
theorem wire_e2422374314358 : Closed e2422374314358 ∧ code e2422374314358 = 11218467336566 := by decide
theorem cert_e2422374314358 : check e2422374314358 [[],[]] .smaller = true := by decide
def e2422374315454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 4)))))))))
theorem wire_e2422374315454 : Closed e2422374315454 ∧ code e2422374315454 = 11218467337662 := by decide
theorem cert_e2422374315454 : check e2422374315454 [[],[]] .three = true := by decide
def e2422374315486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))))
theorem wire_e2422374315486 : Closed e2422374315486 ∧ code e2422374315486 = 11218467337694 := by decide
theorem cert_e2422374315486 : check e2422374315486 [[],[]] .smaller = true := by decide
def e2422374315502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))))
theorem wire_e2422374315502 : Closed e2422374315502 ∧ code e2422374315502 = 11218467337710 := by decide
theorem cert_e2422374315502 : check e2422374315502 [[],[]] .smaller = true := by decide
def e2422374315510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 1)))))))))
theorem wire_e2422374315510 : Closed e2422374315510 ∧ code e2422374315510 = 11218467337718 := by decide
theorem cert_e2422374315510 : check e2422374315510 [[],[]] .three = true := by decide
def e2422374315566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422374315566 : Closed e2422374315566 ∧ code e2422374315566 = 11218467337774 := by decide
theorem cert_e2422374315566 : check e2422374315566 [[],[]] .smaller = true := by decide
def e2422374315710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 4)))))))))
theorem wire_e2422374315710 : Closed e2422374315710 ∧ code e2422374315710 = 11218467337918 := by decide
theorem cert_e2422374315710 : check e2422374315710 [[],[]] .three = true := by decide
def e2422374315742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))))
theorem wire_e2422374315742 : Closed e2422374315742 ∧ code e2422374315742 = 11218467337950 := by decide
theorem cert_e2422374315742 : check e2422374315742 [[],[]] .smaller = true := by decide
def e2422374315746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422374315746 : Closed e2422374315746 ∧ code e2422374315746 = 11218467337954 := by decide
theorem cert_e2422374315746 : check e2422374315746 [[],[]] .smaller = true := by decide
def e2422374315758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))))
theorem wire_e2422374315758 : Closed e2422374315758 ∧ code e2422374315758 = 11218467337966 := by decide
theorem cert_e2422374315758 : check e2422374315758 [[],[]] .smaller = true := by decide
def e2422374315766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))))
theorem wire_e2422374315766 : Closed e2422374315766 ∧ code e2422374315766 = 11218467337974 := by decide
theorem cert_e2422374315766 : check e2422374315766 [[],[]] .smaller = true := by decide
def e2422374315770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 0)))))))))
theorem wire_e2422374315770 : Closed e2422374315770 ∧ code e2422374315770 = 11218467337978 := by decide
theorem cert_e2422374315770 : check e2422374315770 [[],[]] .three = true := by decide
def e2422374315798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422374315798 : Closed e2422374315798 ∧ code e2422374315798 = 11218467338006 := by decide
theorem cert_e2422374315798 : check e2422374315798 [[],[]] .smaller = true := by decide
def e2422374315870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))))
theorem wire_e2422374315870 : Closed e2422374315870 ∧ code e2422374315870 = 11218467338078 := by decide
theorem cert_e2422374315870 : check e2422374315870 [[],[]] .smaller = true := by decide
def e2422374315874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422374315874 : Closed e2422374315874 ∧ code e2422374315874 = 11218467338082 := by decide
theorem cert_e2422374315874 : check e2422374315874 [[],[]] .smaller = true := by decide
def e2422374315886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))))
theorem wire_e2422374315886 : Closed e2422374315886 ∧ code e2422374315886 = 11218467338094 := by decide
theorem cert_e2422374315886 : check e2422374315886 [[],[]] .smaller = true := by decide
def e2422374315894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))))
theorem wire_e2422374315894 : Closed e2422374315894 ∧ code e2422374315894 = 11218467338102 := by decide
theorem cert_e2422374315894 : check e2422374315894 [[],[]] .smaller = true := by decide
def e2422374315898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))))
theorem wire_e2422374315898 : Closed e2422374315898 ∧ code e2422374315898 = 11218467338106 := by decide
theorem cert_e2422374315898 : check e2422374315898 [[],[]] .smaller = true := by decide
def e2422374315950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))))
theorem wire_e2422374315950 : Closed e2422374315950 ∧ code e2422374315950 = 11218467338158 := by decide
theorem cert_e2422374315950 : check e2422374315950 [[],[]] .smaller = true := by decide
def e2422374315958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))))
theorem wire_e2422374315958 : Closed e2422374315958 ∧ code e2422374315958 = 11218467338166 := by decide
theorem cert_e2422374315958 : check e2422374315958 [[],[]] .smaller = true := by decide
def e2422374315962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))))
theorem wire_e2422374315962 : Closed e2422374315962 ∧ code e2422374315962 = 11218467338170 := by decide
theorem cert_e2422374315962 : check e2422374315962 [[],[]] .smaller = true := by decide
def e2422374315990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 1)))))))))
theorem wire_e2422374315990 : Closed e2422374315990 ∧ code e2422374315990 = 11218467338198 := by decide
theorem cert_e2422374315990 : check e2422374315990 [[],[]] .three = true := by decide
def e2422374315994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 0)))))))))
theorem wire_e2422374315994 : Closed e2422374315994 ∧ code e2422374315994 = 11218467338202 := by decide
theorem cert_e2422374315994 : check e2422374315994 [[],[]] .three = true := by decide
def e2422374316206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))))
theorem wire_e2422374316206 : Closed e2422374316206 ∧ code e2422374316206 = 11218467338414 := by decide
theorem cert_e2422374316206 : check e2422374316206 [[],[]] .smaller = true := by decide
def e2422374316218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))))
theorem wire_e2422374316218 : Closed e2422374316218 ∧ code e2422374316218 = 11218467338426 := by decide
theorem cert_e2422374316218 : check e2422374316218 [[],[]] .smaller = true := by decide
def e2422374316590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422374316590 : Closed e2422374316590 ∧ code e2422374316590 = 11218467338798 := by decide
theorem cert_e2422374316590 : check e2422374316590 [[],[]] .smaller = true := by decide
def e2422374316734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 4)))))))))
theorem wire_e2422374316734 : Closed e2422374316734 ∧ code e2422374316734 = 11218467338942 := by decide
theorem cert_e2422374316734 : check e2422374316734 [[],[]] .three = true := by decide
def e2422374316766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e2422374316766 : Closed e2422374316766 ∧ code e2422374316766 = 11218467338974 := by decide
theorem cert_e2422374316766 : check e2422374316766 [[],[]] .smaller = true := by decide
def e2422374316770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422374316770 : Closed e2422374316770 ∧ code e2422374316770 = 11218467338978 := by decide
theorem cert_e2422374316770 : check e2422374316770 [[],[]] .smaller = true := by decide
def e2422374316782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))))
theorem wire_e2422374316782 : Closed e2422374316782 ∧ code e2422374316782 = 11218467338990 := by decide
theorem cert_e2422374316782 : check e2422374316782 [[],[]] .smaller = true := by decide
def e2422374316790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e2422374316790 : Closed e2422374316790 ∧ code e2422374316790 = 11218467338998 := by decide
theorem cert_e2422374316790 : check e2422374316790 [[],[]] .smaller = true := by decide
def e2422374316794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 0)))))))))
theorem wire_e2422374316794 : Closed e2422374316794 ∧ code e2422374316794 = 11218467339002 := by decide
theorem cert_e2422374316794 : check e2422374316794 [[],[]] .three = true := by decide
def e2422374316894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e2422374316894 : Closed e2422374316894 ∧ code e2422374316894 = 11218467339102 := by decide
theorem cert_e2422374316894 : check e2422374316894 [[],[]] .smaller = true := by decide
def e2422374316922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e2422374316922 : Closed e2422374316922 ∧ code e2422374316922 = 11218467339130 := by decide
theorem cert_e2422374316922 : check e2422374316922 [[],[]] .smaller = true := by decide
def e2422374316938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422374316938 : Closed e2422374316938 ∧ code e2422374316938 = 11218467339146 := by decide
theorem cert_e2422374316938 : check e2422374316938 [[],[]] .smaller = true := by decide
def e2422374316962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422374316962 : Closed e2422374316962 ∧ code e2422374316962 = 11218467339170 := by decide
theorem cert_e2422374316962 : check e2422374316962 [[],[]] .smaller = true := by decide
def e2422374316974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))))
theorem wire_e2422374316974 : Closed e2422374316974 ∧ code e2422374316974 = 11218467339182 := by decide
theorem cert_e2422374316974 : check e2422374316974 [[],[]] .smaller = true := by decide
def e2422374316986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))))
theorem wire_e2422374316986 : Closed e2422374316986 ∧ code e2422374316986 = 11218467339194 := by decide
theorem cert_e2422374316986 : check e2422374316986 [[],[]] .smaller = true := by decide
def e2422374317014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e2422374317014 : Closed e2422374317014 ∧ code e2422374317014 = 11218467339222 := by decide
theorem cert_e2422374317014 : check e2422374317014 [[],[]] .smaller = true := by decide
def e2422374317018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e2422374317018 : Closed e2422374317018 ∧ code e2422374317018 = 11218467339226 := by decide
theorem cert_e2422374317018 : check e2422374317018 [[],[]] .smaller = true := by decide
def e2422374317034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 0)))))))))
theorem wire_e2422374317034 : Closed e2422374317034 ∧ code e2422374317034 = 11218467339242 := by decide
theorem cert_e2422374317034 : check e2422374317034 [[],[]] .three = true := by decide
def e2422374317142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))))
theorem wire_e2422374317142 : Closed e2422374317142 ∧ code e2422374317142 = 11218467339350 := by decide
theorem cert_e2422374317142 : check e2422374317142 [[],[]] .smaller = true := by decide
def e2422374317146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))))
theorem wire_e2422374317146 : Closed e2422374317146 ∧ code e2422374317146 = 11218467339354 := by decide
theorem cert_e2422374317146 : check e2422374317146 [[],[]] .smaller = true := by decide
def e2422374317334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422374317334 : Closed e2422374317334 ∧ code e2422374317334 = 11218467339542 := by decide
theorem cert_e2422374317334 : check e2422374317334 [[],[]] .smaller = true := by decide
def e2422374317406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e2422374317406 : Closed e2422374317406 ∧ code e2422374317406 = 11218467339614 := by decide
theorem cert_e2422374317406 : check e2422374317406 [[],[]] .smaller = true := by decide
def e2422374317410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422374317410 : Closed e2422374317410 ∧ code e2422374317410 = 11218467339618 := by decide
theorem cert_e2422374317410 : check e2422374317410 [[],[]] .smaller = true := by decide
def e2422374317422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2422374317422 : Closed e2422374317422 ∧ code e2422374317422 = 11218467339630 := by decide
theorem cert_e2422374317422 : check e2422374317422 [[],[]] .smaller = true := by decide
def e2422374317430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2422374317430 : Closed e2422374317430 ∧ code e2422374317430 = 11218467339638 := by decide
theorem cert_e2422374317430 : check e2422374317430 [[],[]] .smaller = true := by decide
def e2422374317434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e2422374317434 : Closed e2422374317434 ∧ code e2422374317434 = 11218467339642 := by decide
theorem cert_e2422374317434 : check e2422374317434 [[],[]] .smaller = true := by decide
def e2422374317450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422374317450 : Closed e2422374317450 ∧ code e2422374317450 = 11218467339658 := by decide
theorem cert_e2422374317450 : check e2422374317450 [[],[]] .smaller = true := by decide
def e2422374317474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422374317474 : Closed e2422374317474 ∧ code e2422374317474 = 11218467339682 := by decide
theorem cert_e2422374317474 : check e2422374317474 [[],[]] .smaller = true := by decide
def e2422374317486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2422374317486 : Closed e2422374317486 ∧ code e2422374317486 = 11218467339694 := by decide
theorem cert_e2422374317486 : check e2422374317486 [[],[]] .smaller = true := by decide
def e2422374317498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2422374317498 : Closed e2422374317498 ∧ code e2422374317498 = 11218467339706 := by decide
theorem cert_e2422374317498 : check e2422374317498 [[],[]] .smaller = true := by decide
def e2422374317526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2422374317526 : Closed e2422374317526 ∧ code e2422374317526 = 11218467339734 := by decide
theorem cert_e2422374317526 : check e2422374317526 [[],[]] .smaller = true := by decide
def e2422374317530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2422374317530 : Closed e2422374317530 ∧ code e2422374317530 = 11218467339738 := by decide
theorem cert_e2422374317530 : check e2422374317530 [[],[]] .smaller = true := by decide
def e2422374317546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e2422374317546 : Closed e2422374317546 ∧ code e2422374317546 = 11218467339754 := by decide
theorem cert_e2422374317546 : check e2422374317546 [[],[]] .smaller = true := by decide
def e2422374317742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422374317742 : Closed e2422374317742 ∧ code e2422374317742 = 11218467339950 := by decide
theorem cert_e2422374317742 : check e2422374317742 [[],[]] .smaller = true := by decide
def e2422374317750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e2422374317750 : Closed e2422374317750 ∧ code e2422374317750 = 11218467339958 := by decide
theorem cert_e2422374317750 : check e2422374317750 [[],[]] .smaller = true := by decide
def e2422374317754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422374317754 : Closed e2422374317754 ∧ code e2422374317754 = 11218467339962 := by decide
theorem cert_e2422374317754 : check e2422374317754 [[],[]] .smaller = true := by decide
def e2422374317782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e2422374317782 : Closed e2422374317782 ∧ code e2422374317782 = 11218467339990 := by decide
theorem cert_e2422374317782 : check e2422374317782 [[],[]] .smaller = true := by decide
def e2422374317786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e2422374317786 : Closed e2422374317786 ∧ code e2422374317786 = 11218467339994 := by decide
theorem cert_e2422374317786 : check e2422374317786 [[],[]] .smaller = true := by decide
def e2422374317802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422374317802 : Closed e2422374317802 ∧ code e2422374317802 = 11218467340010 := by decide
theorem cert_e2422374317802 : check e2422374317802 [[],[]] .smaller = true := by decide
def e2422374317910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422374317910 : Closed e2422374317910 ∧ code e2422374317910 = 11218467340118 := by decide
theorem cert_e2422374317910 : check e2422374317910 [[],[]] .three = true := by decide
def e2422374317914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422374317914 : Closed e2422374317914 ∧ code e2422374317914 = 11218467340122 := by decide
theorem cert_e2422374317914 : check e2422374317914 [[],[]] .three = true := by decide
def e2422374317930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422374317930 : Closed e2422374317930 ∧ code e2422374317930 = 11218467340138 := by decide
theorem cert_e2422374317930 : check e2422374317930 [[],[]] .three = true := by decide
def e2422374318574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))))
theorem wire_e2422374318574 : Closed e2422374318574 ∧ code e2422374318574 = 11218467340782 := by decide
theorem cert_e2422374318574 : check e2422374318574 [[],[]] .smaller = true := by decide
def e2422374318582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))))
theorem wire_e2422374318582 : Closed e2422374318582 ∧ code e2422374318582 = 11218467340790 := by decide
theorem cert_e2422374318582 : check e2422374318582 [[],[]] .smaller = true := by decide
def e2422374319342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422374319342 : Closed e2422374319342 ∧ code e2422374319342 = 11218467341550 := by decide
theorem cert_e2422374319342 : check e2422374319342 [[],[]] .smaller = true := by decide
def e2422374319350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422374319350 : Closed e2422374319350 ∧ code e2422374319350 = 11218467341558 := by decide
theorem cert_e2422374319350 : check e2422374319350 [[],[]] .smaller = true := by decide
def e2422374319902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))))
theorem wire_e2422374319902 : Closed e2422374319902 ∧ code e2422374319902 = 11218467342110 := by decide
theorem cert_e2422374319902 : check e2422374319902 [[],[]] .smaller = true := by decide
def e2422374320014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))))
theorem wire_e2422374320014 : Closed e2422374320014 ∧ code e2422374320014 = 11218467342222 := by decide
theorem cert_e2422374320014 : check e2422374320014 [[],[]] .smaller = true := by decide
def e2422374321598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 4)))))))))
theorem wire_e2422374321598 : Closed e2422374321598 ∧ code e2422374321598 = 11218467343806 := by decide
theorem cert_e2422374321598 : check e2422374321598 [[],[]] .three = true := by decide
def e2422374321630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))))
theorem wire_e2422374321630 : Closed e2422374321630 ∧ code e2422374321630 = 11218467343838 := by decide
theorem cert_e2422374321630 : check e2422374321630 [[],[]] .smaller = true := by decide
def e2422374321646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))))
theorem wire_e2422374321646 : Closed e2422374321646 ∧ code e2422374321646 = 11218467343854 := by decide
theorem cert_e2422374321646 : check e2422374321646 [[],[]] .smaller = true := by decide
def e2422374321654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 1)))))))))
theorem wire_e2422374321654 : Closed e2422374321654 ∧ code e2422374321654 = 11218467343862 := by decide
theorem cert_e2422374321654 : check e2422374321654 [[],[]] .three = true := by decide
def e2422374321710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))))
theorem wire_e2422374321710 : Closed e2422374321710 ∧ code e2422374321710 = 11218467343918 := by decide
theorem cert_e2422374321710 : check e2422374321710 [[],[]] .smaller = true := by decide
def e2422374321854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 4)))))))))
theorem wire_e2422374321854 : Closed e2422374321854 ∧ code e2422374321854 = 11218467344062 := by decide
theorem cert_e2422374321854 : check e2422374321854 [[],[]] .three = true := by decide
def e2422374321886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))))
theorem wire_e2422374321886 : Closed e2422374321886 ∧ code e2422374321886 = 11218467344094 := by decide
theorem cert_e2422374321886 : check e2422374321886 [[],[]] .smaller = true := by decide
def e2422374321890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))))
theorem wire_e2422374321890 : Closed e2422374321890 ∧ code e2422374321890 = 11218467344098 := by decide
theorem cert_e2422374321890 : check e2422374321890 [[],[]] .smaller = true := by decide
def e2422374321902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))))
theorem wire_e2422374321902 : Closed e2422374321902 ∧ code e2422374321902 = 11218467344110 := by decide
theorem cert_e2422374321902 : check e2422374321902 [[],[]] .smaller = true := by decide
def e2422374321910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))))
theorem wire_e2422374321910 : Closed e2422374321910 ∧ code e2422374321910 = 11218467344118 := by decide
theorem cert_e2422374321910 : check e2422374321910 [[],[]] .smaller = true := by decide
def e2422374321914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 0)))))))))
theorem wire_e2422374321914 : Closed e2422374321914 ∧ code e2422374321914 = 11218467344122 := by decide
theorem cert_e2422374321914 : check e2422374321914 [[],[]] .three = true := by decide
def e2422374321942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))))
theorem wire_e2422374321942 : Closed e2422374321942 ∧ code e2422374321942 = 11218467344150 := by decide
theorem cert_e2422374321942 : check e2422374321942 [[],[]] .smaller = true := by decide
end Blc.Floor43
