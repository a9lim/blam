import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418284736234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2418284736234 : Closed e2418284736234 ∧ code e2418284736234 = 11214377758442 := by decide
theorem cert_e2418284736234 : check e2418284736234 [[],[]] .sourceHead = true := by decide
def e2418284736342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2418284736342 : Closed e2418284736342 ∧ code e2418284736342 = 11214377758550 := by decide
theorem cert_e2418284736342 : check e2418284736342 [[],[],[.under,.under,.left,.left,.left]] .smaller = true := by decide
def e2418284736346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2418284736346 : Closed e2418284736346 ∧ code e2418284736346 = 11214377758554 := by decide
theorem cert_e2418284736346 : check e2418284736346 [[],[],[.under,.under,.left,.left,.left]] .smaller = true := by decide
def e2418284736362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2418284736362 : Closed e2418284736362 ∧ code e2418284736362 = 11214377758570 := by decide
theorem cert_e2418284736362 : check e2418284736362 [[],[],[.under,.under,.left,.left,.left]] .smaller = true := by decide
def e2418284737390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2418284737390 : Closed e2418284737390 ∧ code e2418284737390 = 11214377759598 := by decide
theorem cert_e2418284737390 : check e2418284737390 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418284737398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2418284737398 : Closed e2418284737398 ∧ code e2418284737398 = 11214377759606 := by decide
theorem cert_e2418284737398 : check e2418284737398 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418284737454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2418284737454 : Closed e2418284737454 ∧ code e2418284737454 = 11214377759662 := by decide
theorem cert_e2418284737454 : check e2418284737454 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418284737466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2418284737466 : Closed e2418284737466 ∧ code e2418284737466 = 11214377759674 := by decide
theorem cert_e2418284737466 : check e2418284737466 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418284737494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2418284737494 : Closed e2418284737494 ∧ code e2418284737494 = 11214377759702 := by decide
theorem cert_e2418284737494 : check e2418284737494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418284737498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2418284737498 : Closed e2418284737498 ∧ code e2418284737498 = 11214377759706 := by decide
theorem cert_e2418284737498 : check e2418284737498 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e2418284737774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418284737774 : Closed e2418284737774 ∧ code e2418284737774 = 11214377759982 := by decide
theorem cert_e2418284737774 : check e2418284737774 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418284737782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418284737782 : Closed e2418284737782 ∧ code e2418284737782 = 11214377759990 := by decide
theorem cert_e2418284737782 : check e2418284737782 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418284738158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418284738158 : Closed e2418284738158 ∧ code e2418284738158 = 11214377760366 := by decide
theorem cert_e2418284738158 : check e2418284738158 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418284738170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418284738170 : Closed e2418284738170 ∧ code e2418284738170 = 11214377760378 := by decide
theorem cert_e2418284738170 : check e2418284738170 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418284738358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418284738358 : Closed e2418284738358 ∧ code e2418284738358 = 11214377760566 := by decide
theorem cert_e2418284738358 : check e2418284738358 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2418284738362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418284738362 : Closed e2418284738362 ∧ code e2418284738362 = 11214377760570 := by decide
theorem cert_e2418284738362 : check e2418284738362 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418284738990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2418284738990 : Closed e2418284738990 ∧ code e2418284738990 = 11214377761198 := by decide
theorem cert_e2418284738990 : checkPay e2418284738990 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2418284739002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2418284739002 : Closed e2418284739002 ∧ code e2418284739002 = 11214377761210 := by decide
theorem cert_e2418284739002 : checkPay e2418284739002 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[.left],[]] = true := by decide
def e2418284739050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2418284739050 : Closed e2418284739050 ∧ code e2418284739050 = 11214377761258 := by decide
theorem cert_e2418284739050 : checkPay e2418284739050 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left]] = true := by decide
def e2418284739182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418284739182 : Closed e2418284739182 ∧ code e2418284739182 = 11214377761390 := by decide
theorem cert_e2418284739182 : checkPay e2418284739182 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418284739194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418284739194 : Closed e2418284739194 ∧ code e2418284739194 = 11214377761402 := by decide
theorem cert_e2418284739194 : checkPay e2418284739194 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418284739482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418284739482 : Closed e2418284739482 ∧ code e2418284739482 = 11214377761690 := by decide
theorem cert_e2418284739482 : checkPay e2418284739482 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2418284739798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2418284739798 : Closed e2418284739798 ∧ code e2418284739798 = 11214377762006 := by decide
theorem cert_e2418284739798 : check e2418284739798 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2418284739802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2418284739802 : Closed e2418284739802 ∧ code e2418284739802 = 11214377762010 := by decide
theorem cert_e2418284739802 : check e2418284739802 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2418284739818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2418284739818 : Closed e2418284739818 ∧ code e2418284739818 = 11214377762026 := by decide
theorem cert_e2418284739818 : check e2418284739818 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2418284739894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418284739894 : Closed e2418284739894 ∧ code e2418284739894 = 11214377762102 := by decide
theorem cert_e2418284739894 : check e2418284739894 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2418284739898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418284739898 : Closed e2418284739898 ∧ code e2418284739898 = 11214377762106 := by decide
theorem cert_e2418284739898 : check e2418284739898 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2418284739994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418284739994 : Closed e2418284739994 ∧ code e2418284739994 = 11214377762202 := by decide
theorem cert_e2418284739994 : check e2418284739994 [[],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2418284743534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418284743534 : Closed e2418284743534 ∧ code e2418284743534 = 11214377765742 := by decide
theorem cert_e2418284743534 : check e2418284743534 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2418284743542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418284743542 : Closed e2418284743542 ∧ code e2418284743542 = 11214377765750 := by decide
theorem cert_e2418284743542 : check e2418284743542 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418284743598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418284743598 : Closed e2418284743598 ∧ code e2418284743598 = 11214377765806 := by decide
theorem cert_e2418284743598 : check e2418284743598 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418284743610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418284743610 : Closed e2418284743610 ∧ code e2418284743610 = 11214377765818 := by decide
theorem cert_e2418284743610 : check e2418284743610 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418284743638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418284743638 : Closed e2418284743638 ∧ code e2418284743638 = 11214377765846 := by decide
theorem cert_e2418284743638 : check e2418284743638 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2418284743642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418284743642 : Closed e2418284743642 ∧ code e2418284743642 = 11214377765850 := by decide
theorem cert_e2418284743642 : check e2418284743642 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2418284743918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418284743918 : Closed e2418284743918 ∧ code e2418284743918 = 11214377766126 := by decide
theorem cert_e2418284743918 : check e2418284743918 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2418284743926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418284743926 : Closed e2418284743926 ∧ code e2418284743926 = 11214377766134 := by decide
theorem cert_e2418284743926 : checkPay e2418284743926 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left]] 0 [] = true := by decide
def e2418284744302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418284744302 : Closed e2418284744302 ∧ code e2418284744302 = 11214377766510 := by decide
theorem cert_e2418284744302 : check e2418284744302 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418284744314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418284744314 : Closed e2418284744314 ∧ code e2418284744314 = 11214377766522 := by decide
theorem cert_e2418284744314 : check e2418284744314 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418284744502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418284744502 : Closed e2418284744502 ∧ code e2418284744502 = 11214377766710 := by decide
theorem cert_e2418284744502 : checkPay e2418284744502 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[],[]] 0 [] = true := by decide
def e2418284744506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418284744506 : Closed e2418284744506 ∧ code e2418284744506 = 11214377766714 := by decide
theorem cert_e2418284744506 : check e2418284744506 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2418284750254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2418284750254 : Closed e2418284750254 ∧ code e2418284750254 = 11214377772462 := by decide
theorem cert_e2418284750254 : check e2418284750254 [[],[]] .sourceHead = true := by decide
def e2418284750266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2418284750266 : Closed e2418284750266 ∧ code e2418284750266 = 11214377772474 := by decide
theorem cert_e2418284750266 : check e2418284750266 [[],[]] .sourceHead = true := by decide
def e2418284750314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2418284750314 : Closed e2418284750314 ∧ code e2418284750314 = 11214377772522 := by decide
theorem cert_e2418284750314 : check e2418284750314 [[],[]] .sourceHead = true := by decide
def e2418284750446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2418284750446 : Closed e2418284750446 ∧ code e2418284750446 = 11214377772654 := by decide
theorem cert_e2418284750446 : check e2418284750446 [[],[]] .sourceHead = true := by decide
def e2418284750458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2418284750458 : Closed e2418284750458 ∧ code e2418284750458 = 11214377772666 := by decide
theorem cert_e2418284750458 : check e2418284750458 [[],[]] .sourceHead = true := by decide
def e2418284750746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2418284750746 : Closed e2418284750746 ∧ code e2418284750746 = 11214377772954 := by decide
theorem cert_e2418284750746 : check e2418284750746 [[],[]] .sourceHead = true := by decide
def e2418284753622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2418284753622 : Closed e2418284753622 ∧ code e2418284753622 = 11214377775830 := by decide
theorem cert_e2418284753622 : check e2418284753622 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2418284753626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2418284753626 : Closed e2418284753626 ∧ code e2418284753626 = 11214377775834 := by decide
theorem cert_e2418284753626 : check e2418284753626 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2418284753642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2418284753642 : Closed e2418284753642 ∧ code e2418284753642 = 11214377775850 := by decide
theorem cert_e2418284753642 : check e2418284753642 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2418284753718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2418284753718 : Closed e2418284753718 ∧ code e2418284753718 = 11214377775926 := by decide
theorem cert_e2418284753718 : check e2418284753718 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2418284753722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2418284753722 : Closed e2418284753722 ∧ code e2418284753722 = 11214377775930 := by decide
theorem cert_e2418284753722 : check e2418284753722 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2418284753818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2418284753818 : Closed e2418284753818 ∧ code e2418284753818 = 11214377776026 := by decide
theorem cert_e2418284753818 : check e2418284753818 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2418284890990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418284890990 : Closed e2418284890990 ∧ code e2418284890990 = 11214377913198 := by decide
theorem cert_e2418284890990 : check e2418284890990 [[],[]] .sourceHead = true := by decide
def e2418284890998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418284890998 : Closed e2418284890998 ∧ code e2418284890998 = 11214377913206 := by decide
theorem cert_e2418284890998 : check e2418284890998 [[],[]] .sourceHead = true := by decide
def e2418284891054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418284891054 : Closed e2418284891054 ∧ code e2418284891054 = 11214377913262 := by decide
theorem cert_e2418284891054 : check e2418284891054 [[],[]] .sourceHead = true := by decide
def e2418284891066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418284891066 : Closed e2418284891066 ∧ code e2418284891066 = 11214377913274 := by decide
theorem cert_e2418284891066 : check e2418284891066 [[],[]] .sourceHead = true := by decide
def e2418284891094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418284891094 : Closed e2418284891094 ∧ code e2418284891094 = 11214377913302 := by decide
theorem cert_e2418284891094 : check e2418284891094 [[],[]] .sourceHead = true := by decide
def e2418284891098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418284891098 : Closed e2418284891098 ∧ code e2418284891098 = 11214377913306 := by decide
theorem cert_e2418284891098 : check e2418284891098 [[],[]] .sourceHead = true := by decide
def e2418284891374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418284891374 : Closed e2418284891374 ∧ code e2418284891374 = 11214377913582 := by decide
theorem cert_e2418284891374 : check e2418284891374 [[],[]] .sourceHead = true := by decide
def e2418284891382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418284891382 : Closed e2418284891382 ∧ code e2418284891382 = 11214377913590 := by decide
theorem cert_e2418284891382 : check e2418284891382 [[],[]] .sourceHead = true := by decide
def e2418284891758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418284891758 : Closed e2418284891758 ∧ code e2418284891758 = 11214377913966 := by decide
theorem cert_e2418284891758 : check e2418284891758 [[],[]] .sourceHead = true := by decide
def e2418284891770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418284891770 : Closed e2418284891770 ∧ code e2418284891770 = 11214377913978 := by decide
theorem cert_e2418284891770 : check e2418284891770 [[],[]] .sourceHead = true := by decide
def e2418284891958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418284891958 : Closed e2418284891958 ∧ code e2418284891958 = 11214377914166 := by decide
theorem cert_e2418284891958 : check e2418284891958 [[],[]] .sourceHead = true := by decide
def e2418284891962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418284891962 : Closed e2418284891962 ∧ code e2418284891962 = 11214377914170 := by decide
theorem cert_e2418284891962 : check e2418284891962 [[],[]] .sourceHead = true := by decide
def e2418285480814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418285480814 : Closed e2418285480814 ∧ code e2418285480814 = 11214378503022 := by decide
theorem cert_e2418285480814 : check e2418285480814 [[],[],[.left],[.left],[.left],[],[.left],[],[.left],[.left],[],[.left,.left]] .width = true := by decide
def e2418285480822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418285480822 : Closed e2418285480822 ∧ code e2418285480822 = 11214378503030 := by decide
private def t_e2418285480822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418285480822 : ¬ IsSelfInterpreter e2418285480822 :=
  wSource (t := t_e2418285480822) (replay_sound (ps := [[],[],[.left],[.left],[.left],[],[.left],[],[.left]]) (t := e2418285480822) (by decide)) (by decide)
def e2418285480878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418285480878 : Closed e2418285480878 ∧ code e2418285480878 = 11214378503086 := by decide
private def t_e2418285480878 : Term := (.app (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.var 0)) (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418285480878 : ¬ IsSelfInterpreter e2418285480878 :=
  wSource (t := t_e2418285480878) (replay_sound (ps := [[],[],[.left],[.left],[.left],[],[.left],[],[.left]]) (t := e2418285480878) (by decide)) (by decide)
def e2418285480890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418285480890 : Closed e2418285480890 ∧ code e2418285480890 = 11214378503098 := by decide
private def t_e2418285480890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2418285480890 : ¬ IsSelfInterpreter e2418285480890 :=
  wSource (t := t_e2418285480890) (replay_sound (ps := []) (t := e2418285480890) (by decide)) (by decide)
def e2418285480918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418285480918 : Closed e2418285480918 ∧ code e2418285480918 = 11214378503126 := by decide
def e2418285480922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418285480922 : Closed e2418285480922 ∧ code e2418285480922 = 11214378503130 := by decide
private def t_e2418285480922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2418285480922 : ¬ IsSelfInterpreter e2418285480922 :=
  wSource (t := t_e2418285480922) (replay_sound (ps := []) (t := e2418285480922) (by decide)) (by decide)
def e2418285481198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418285481198 : Closed e2418285481198 ∧ code e2418285481198 = 11214378503406 := by decide
theorem cert_e2418285481198 : check e2418285481198 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418285481206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418285481206 : Closed e2418285481206 ∧ code e2418285481206 = 11214378503414 := by decide
theorem cert_e2418285481206 : check e2418285481206 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418285481582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418285481582 : Closed e2418285481582 ∧ code e2418285481582 = 11214378503790 := by decide
theorem cert_e2418285481582 : check e2418285481582 [[],[],[.left],[.left],[.left],[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2418285481594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418285481594 : Closed e2418285481594 ∧ code e2418285481594 = 11214378503802 := by decide
theorem cert_e2418285481594 : check e2418285481594 [[],[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2418285481782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418285481782 : Closed e2418285481782 ∧ code e2418285481782 = 11214378503990 := by decide
def e2418285481786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418285481786 : Closed e2418285481786 ∧ code e2418285481786 = 11214378503994 := by decide
def e2418335067502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2418335067502 : Closed e2418335067502 ∧ code e2418335067502 = 11214428089710 := by decide
theorem cert_e2418335067502 : check e2418335067502 [[],[]] .smaller = true := by decide
def e2418335067510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2418335067510 : Closed e2418335067510 ∧ code e2418335067510 = 11214428089718 := by decide
theorem cert_e2418335067510 : check e2418335067510 [[],[]] .smaller = true := by decide
def e2418335067566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2418335067566 : Closed e2418335067566 ∧ code e2418335067566 = 11214428089774 := by decide
theorem cert_e2418335067566 : check e2418335067566 [[],[]] .smaller = true := by decide
def e2418335067578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2418335067578 : Closed e2418335067578 ∧ code e2418335067578 = 11214428089786 := by decide
theorem cert_e2418335067578 : check e2418335067578 [[],[]] .smaller = true := by decide
def e2418335067606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2418335067606 : Closed e2418335067606 ∧ code e2418335067606 = 11214428089814 := by decide
theorem cert_e2418335067606 : check e2418335067606 [[],[]] .smaller = true := by decide
def e2418335067610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2418335067610 : Closed e2418335067610 ∧ code e2418335067610 = 11214428089818 := by decide
theorem cert_e2418335067610 : check e2418335067610 [[],[]] .smaller = true := by decide
def e2418335067822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2418335067822 : Closed e2418335067822 ∧ code e2418335067822 = 11214428090030 := by decide
theorem cert_e2418335067822 : check e2418335067822 [[],[]] .smaller = true := by decide
def e2418335067834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2418335067834 : Closed e2418335067834 ∧ code e2418335067834 = 11214428090042 := by decide
theorem cert_e2418335067834 : check e2418335067834 [[],[]] .smaller = true := by decide
def e2418335067882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2418335067882 : Closed e2418335067882 ∧ code e2418335067882 = 11214428090090 := by decide
theorem cert_e2418335067882 : check e2418335067882 [[],[]] .smaller = true := by decide
def e2418335067990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2418335067990 : Closed e2418335067990 ∧ code e2418335067990 = 11214428090198 := by decide
theorem cert_e2418335067990 : check e2418335067990 [[],[]] .smaller = true := by decide
def e2418335067994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2418335067994 : Closed e2418335067994 ∧ code e2418335067994 = 11214428090202 := by decide
theorem cert_e2418335067994 : check e2418335067994 [[],[]] .smaller = true := by decide
def e2418335068010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2418335068010 : Closed e2418335068010 ∧ code e2418335068010 = 11214428090218 := by decide
theorem cert_e2418335068010 : check e2418335068010 [[],[]] .smaller = true := by decide
def e2418335069038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2418335069038 : Closed e2418335069038 ∧ code e2418335069038 = 11214428091246 := by decide
theorem cert_e2418335069038 : check e2418335069038 [[],[]] .smaller = true := by decide
def e2418335069046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2418335069046 : Closed e2418335069046 ∧ code e2418335069046 = 11214428091254 := by decide
theorem cert_e2418335069046 : check e2418335069046 [[],[]] .smaller = true := by decide
def e2418335069102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2418335069102 : Closed e2418335069102 ∧ code e2418335069102 = 11214428091310 := by decide
theorem cert_e2418335069102 : check e2418335069102 [[],[]] .smaller = true := by decide
def e2418335069114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2418335069114 : Closed e2418335069114 ∧ code e2418335069114 = 11214428091322 := by decide
theorem cert_e2418335069114 : check e2418335069114 [[],[]] .smaller = true := by decide
def e2418335069142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2418335069142 : Closed e2418335069142 ∧ code e2418335069142 = 11214428091350 := by decide
theorem cert_e2418335069142 : check e2418335069142 [[],[]] .smaller = true := by decide
def e2418335069146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2418335069146 : Closed e2418335069146 ∧ code e2418335069146 = 11214428091354 := by decide
theorem cert_e2418335069146 : check e2418335069146 [[],[]] .smaller = true := by decide
def e2418335069422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418335069422 : Closed e2418335069422 ∧ code e2418335069422 = 11214428091630 := by decide
theorem cert_e2418335069422 : check e2418335069422 [[],[]] .smaller = true := by decide
def e2418335069430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418335069430 : Closed e2418335069430 ∧ code e2418335069430 = 11214428091638 := by decide
theorem cert_e2418335069430 : check e2418335069430 [[],[]] .smaller = true := by decide
def e2418335069806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418335069806 : Closed e2418335069806 ∧ code e2418335069806 = 11214428092014 := by decide
theorem cert_e2418335069806 : check e2418335069806 [[],[]] .smaller = true := by decide
def e2418335069818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418335069818 : Closed e2418335069818 ∧ code e2418335069818 = 11214428092026 := by decide
theorem cert_e2418335069818 : check e2418335069818 [[],[]] .smaller = true := by decide
def e2418335070006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418335070006 : Closed e2418335070006 ∧ code e2418335070006 = 11214428092214 := by decide
theorem cert_e2418335070006 : check e2418335070006 [[],[]] .smaller = true := by decide
def e2418335070010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418335070010 : Closed e2418335070010 ∧ code e2418335070010 = 11214428092218 := by decide
theorem cert_e2418335070010 : check e2418335070010 [[],[]] .smaller = true := by decide
def e2418335070638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2418335070638 : Closed e2418335070638 ∧ code e2418335070638 = 11214428092846 := by decide
theorem cert_e2418335070638 : check e2418335070638 [[],[]] .smaller = true := by decide
def e2418335070650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2418335070650 : Closed e2418335070650 ∧ code e2418335070650 = 11214428092858 := by decide
theorem cert_e2418335070650 : check e2418335070650 [[],[]] .smaller = true := by decide
def e2418335070698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2418335070698 : Closed e2418335070698 ∧ code e2418335070698 = 11214428092906 := by decide
theorem cert_e2418335070698 : check e2418335070698 [[],[]] .smaller = true := by decide
def e2418335070830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418335070830 : Closed e2418335070830 ∧ code e2418335070830 = 11214428093038 := by decide
theorem cert_e2418335070830 : check e2418335070830 [[],[]] .smaller = true := by decide
def e2418335070842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418335070842 : Closed e2418335070842 ∧ code e2418335070842 = 11214428093050 := by decide
theorem cert_e2418335070842 : check e2418335070842 [[],[]] .smaller = true := by decide
def e2418335071130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418335071130 : Closed e2418335071130 ∧ code e2418335071130 = 11214428093338 := by decide
theorem cert_e2418335071130 : check e2418335071130 [[],[]] .smaller = true := by decide
def e2418335071446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2418335071446 : Closed e2418335071446 ∧ code e2418335071446 = 11214428093654 := by decide
theorem cert_e2418335071446 : check e2418335071446 [[],[]] .smaller = true := by decide
def e2418335071450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2418335071450 : Closed e2418335071450 ∧ code e2418335071450 = 11214428093658 := by decide
theorem cert_e2418335071450 : check e2418335071450 [[],[]] .smaller = true := by decide
def e2418335071466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2418335071466 : Closed e2418335071466 ∧ code e2418335071466 = 11214428093674 := by decide
theorem cert_e2418335071466 : check e2418335071466 [[],[]] .smaller = true := by decide
def e2418335071542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418335071542 : Closed e2418335071542 ∧ code e2418335071542 = 11214428093750 := by decide
theorem cert_e2418335071542 : check e2418335071542 [[],[]] .smaller = true := by decide
def e2418335071546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418335071546 : Closed e2418335071546 ∧ code e2418335071546 = 11214428093754 := by decide
theorem cert_e2418335071546 : check e2418335071546 [[],[]] .smaller = true := by decide
def e2418335071642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418335071642 : Closed e2418335071642 ∧ code e2418335071642 = 11214428093850 := by decide
theorem cert_e2418335071642 : check e2418335071642 [[],[]] .smaller = true := by decide
def e2418335075182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2418335075182 : Closed e2418335075182 ∧ code e2418335075182 = 11214428097390 := by decide
theorem cert_e2418335075182 : check e2418335075182 [[],[]] .smaller = true := by decide
def e2418335075190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2418335075190 : Closed e2418335075190 ∧ code e2418335075190 = 11214428097398 := by decide
theorem cert_e2418335075190 : check e2418335075190 [[],[]] .smaller = true := by decide
def e2418335075246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2418335075246 : Closed e2418335075246 ∧ code e2418335075246 = 11214428097454 := by decide
theorem cert_e2418335075246 : check e2418335075246 [[],[]] .smaller = true := by decide
def e2418335075258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2418335075258 : Closed e2418335075258 ∧ code e2418335075258 = 11214428097466 := by decide
theorem cert_e2418335075258 : check e2418335075258 [[],[]] .smaller = true := by decide
def e2418335075286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2418335075286 : Closed e2418335075286 ∧ code e2418335075286 = 11214428097494 := by decide
theorem cert_e2418335075286 : check e2418335075286 [[],[]] .smaller = true := by decide
def e2418335075290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2418335075290 : Closed e2418335075290 ∧ code e2418335075290 = 11214428097498 := by decide
theorem cert_e2418335075290 : check e2418335075290 [[],[]] .smaller = true := by decide
def e2418335075566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2418335075566 : Closed e2418335075566 ∧ code e2418335075566 = 11214428097774 := by decide
theorem cert_e2418335075566 : check e2418335075566 [[],[]] .smaller = true := by decide
def e2418335075574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2418335075574 : Closed e2418335075574 ∧ code e2418335075574 = 11214428097782 := by decide
theorem cert_e2418335075574 : check e2418335075574 [[],[]] .smaller = true := by decide
def e2418335075950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2418335075950 : Closed e2418335075950 ∧ code e2418335075950 = 11214428098158 := by decide
theorem cert_e2418335075950 : check e2418335075950 [[],[]] .smaller = true := by decide
def e2418335075962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2418335075962 : Closed e2418335075962 ∧ code e2418335075962 = 11214428098170 := by decide
theorem cert_e2418335075962 : check e2418335075962 [[],[]] .smaller = true := by decide
def e2418335076150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2418335076150 : Closed e2418335076150 ∧ code e2418335076150 = 11214428098358 := by decide
theorem cert_e2418335076150 : check e2418335076150 [[],[]] .smaller = true := by decide
def e2418335076154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2418335076154 : Closed e2418335076154 ∧ code e2418335076154 = 11214428098362 := by decide
theorem cert_e2418335076154 : check e2418335076154 [[],[]] .smaller = true := by decide
def e2418335081902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2418335081902 : Closed e2418335081902 ∧ code e2418335081902 = 11214428104110 := by decide
theorem cert_e2418335081902 : check e2418335081902 [[],[]] .smaller = true := by decide
def e2418335081914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2418335081914 : Closed e2418335081914 ∧ code e2418335081914 = 11214428104122 := by decide
theorem cert_e2418335081914 : check e2418335081914 [[],[]] .smaller = true := by decide
def e2418335081962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2418335081962 : Closed e2418335081962 ∧ code e2418335081962 = 11214428104170 := by decide
theorem cert_e2418335081962 : check e2418335081962 [[],[]] .smaller = true := by decide
def e2418335082094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2418335082094 : Closed e2418335082094 ∧ code e2418335082094 = 11214428104302 := by decide
theorem cert_e2418335082094 : check e2418335082094 [[],[]] .smaller = true := by decide
def e2418335082106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2418335082106 : Closed e2418335082106 ∧ code e2418335082106 = 11214428104314 := by decide
theorem cert_e2418335082106 : check e2418335082106 [[],[]] .smaller = true := by decide
def e2418335082394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2418335082394 : Closed e2418335082394 ∧ code e2418335082394 = 11214428104602 := by decide
theorem cert_e2418335082394 : check e2418335082394 [[],[]] .smaller = true := by decide
def e2418335085270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2418335085270 : Closed e2418335085270 ∧ code e2418335085270 = 11214428107478 := by decide
theorem cert_e2418335085270 : check e2418335085270 [[],[]] .smaller = true := by decide
def e2418335085274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2418335085274 : Closed e2418335085274 ∧ code e2418335085274 = 11214428107482 := by decide
theorem cert_e2418335085274 : check e2418335085274 [[],[]] .smaller = true := by decide
def e2418335085290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2418335085290 : Closed e2418335085290 ∧ code e2418335085290 = 11214428107498 := by decide
theorem cert_e2418335085290 : check e2418335085290 [[],[]] .smaller = true := by decide
def e2418335085366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2418335085366 : Closed e2418335085366 ∧ code e2418335085366 = 11214428107574 := by decide
theorem cert_e2418335085366 : check e2418335085366 [[],[]] .smaller = true := by decide
def e2418335085370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2418335085370 : Closed e2418335085370 ∧ code e2418335085370 = 11214428107578 := by decide
theorem cert_e2418335085370 : check e2418335085370 [[],[]] .smaller = true := by decide
def e2418335085466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2418335085466 : Closed e2418335085466 ∧ code e2418335085466 = 11214428107674 := by decide
theorem cert_e2418335085466 : check e2418335085466 [[],[]] .smaller = true := by decide
def e2418335200734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2418335200734 : Closed e2418335200734 ∧ code e2418335200734 = 11214428222942 := by decide
theorem cert_e2418335200734 : check e2418335200734 [[],[]] .three = true := by decide
def e2418335200750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2418335200750 : Closed e2418335200750 ∧ code e2418335200750 = 11214428222958 := by decide
theorem cert_e2418335200750 : check e2418335200750 [[],[]] .three = true := by decide
def e2418335200990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2418335200990 : Closed e2418335200990 ∧ code e2418335200990 = 11214428223198 := by decide
theorem cert_e2418335200990 : check e2418335200990 [[],[]] .three = true := by decide
def e2418335201006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2418335201006 : Closed e2418335201006 ∧ code e2418335201006 = 11214428223214 := by decide
theorem cert_e2418335201006 : check e2418335201006 [[],[]] .smaller = true := by decide
def e2418335201014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2418335201014 : Closed e2418335201014 ∧ code e2418335201014 = 11214428223222 := by decide
theorem cert_e2418335201014 : check e2418335201014 [[],[]] .three = true := by decide
def e2418335201118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2418335201118 : Closed e2418335201118 ∧ code e2418335201118 = 11214428223326 := by decide
theorem cert_e2418335201118 : check e2418335201118 [[],[]] .three = true := by decide
def e2418335201134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2418335201134 : Closed e2418335201134 ∧ code e2418335201134 = 11214428223342 := by decide
theorem cert_e2418335201134 : check e2418335201134 [[],[]] .smaller = true := by decide
def e2418335201142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2418335201142 : Closed e2418335201142 ∧ code e2418335201142 = 11214428223350 := by decide
theorem cert_e2418335201142 : check e2418335201142 [[],[]] .smaller = true := by decide
def e2418335201146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2418335201146 : Closed e2418335201146 ∧ code e2418335201146 = 11214428223354 := by decide
theorem cert_e2418335201146 : check e2418335201146 [[],[]] .three = true := by decide
def e2418335201198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2418335201198 : Closed e2418335201198 ∧ code e2418335201198 = 11214428223406 := by decide
theorem cert_e2418335201198 : check e2418335201198 [[],[]] .three = true := by decide
def e2418335201206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2418335201206 : Closed e2418335201206 ∧ code e2418335201206 = 11214428223414 := by decide
theorem cert_e2418335201206 : check e2418335201206 [[],[]] .three = true := by decide
def e2418335201210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2418335201210 : Closed e2418335201210 ∧ code e2418335201210 = 11214428223418 := by decide
theorem cert_e2418335201210 : check e2418335201210 [[],[]] .three = true := by decide
def e2418335202014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2418335202014 : Closed e2418335202014 ∧ code e2418335202014 = 11214428224222 := by decide
theorem cert_e2418335202014 : check e2418335202014 [[],[]] .three = true := by decide
def e2418335202030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2418335202030 : Closed e2418335202030 ∧ code e2418335202030 = 11214428224238 := by decide
theorem cert_e2418335202030 : check e2418335202030 [[],[]] .smaller = true := by decide
def e2418335202038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2418335202038 : Closed e2418335202038 ∧ code e2418335202038 = 11214428224246 := by decide
theorem cert_e2418335202038 : check e2418335202038 [[],[]] .three = true := by decide
def e2418335202142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2418335202142 : Closed e2418335202142 ∧ code e2418335202142 = 11214428224350 := by decide
theorem cert_e2418335202142 : check e2418335202142 [[],[]] .three = true := by decide
def e2418335202170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2418335202170 : Closed e2418335202170 ∧ code e2418335202170 = 11214428224378 := by decide
theorem cert_e2418335202170 : check e2418335202170 [[],[]] .three = true := by decide
def e2418335202222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2418335202222 : Closed e2418335202222 ∧ code e2418335202222 = 11214428224430 := by decide
theorem cert_e2418335202222 : check e2418335202222 [[],[]] .smaller = true := by decide
def e2418335202234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2418335202234 : Closed e2418335202234 ∧ code e2418335202234 = 11214428224442 := by decide
theorem cert_e2418335202234 : check e2418335202234 [[],[]] .smaller = true := by decide
def e2418335202262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2418335202262 : Closed e2418335202262 ∧ code e2418335202262 = 11214428224470 := by decide
theorem cert_e2418335202262 : check e2418335202262 [[],[]] .three = true := by decide
def e2418335202266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2418335202266 : Closed e2418335202266 ∧ code e2418335202266 = 11214428224474 := by decide
theorem cert_e2418335202266 : check e2418335202266 [[],[]] .three = true := by decide
def e2418335202654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2418335202654 : Closed e2418335202654 ∧ code e2418335202654 = 11214428224862 := by decide
theorem cert_e2418335202654 : check e2418335202654 [[],[]] .three = true := by decide
def e2418335202670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2418335202670 : Closed e2418335202670 ∧ code e2418335202670 = 11214428224878 := by decide
theorem cert_e2418335202670 : check e2418335202670 [[],[]] .smaller = true := by decide
def e2418335202678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2418335202678 : Closed e2418335202678 ∧ code e2418335202678 = 11214428224886 := by decide
theorem cert_e2418335202678 : check e2418335202678 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2418285480822
#print axioms Blc.Floor43.cert_e2418285480878
#print axioms Blc.Floor43.cert_e2418285480890
#print axioms Blc.Floor43.cert_e2418285480922
