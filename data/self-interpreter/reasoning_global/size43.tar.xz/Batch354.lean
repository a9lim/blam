import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419143439162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143439162 : Closed e2419143439162 ∧ code e2419143439162 = 11215236461370 := by decide
private def t_e2419143439162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem cert_e2419143439162 : ¬ IsSelfInterpreter e2419143439162 :=
  wSource (t := t_e2419143439162) (replay_sound (ps := []) (t := e2419143439162) (by decide)) (by decide)
def e2419143439258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2419143439258 : Closed e2419143439258 ∧ code e2419143439258 = 11215236461466 := by decide
private def t_e2419143439258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem cert_e2419143439258 : ¬ IsSelfInterpreter e2419143439258 :=
  wSource (t := t_e2419143439258) (replay_sound (ps := []) (t := e2419143439258) (by decide)) (by decide)
def e2419143486942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2419143486942 : Closed e2419143486942 ∧ code e2419143486942 = 11215236509150 := by decide
theorem cert_e2419143486942 : check e2419143486942 [[],[]] .smaller = true := by decide
def e2419143486958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2419143486958 : Closed e2419143486958 ∧ code e2419143486958 = 11215236509166 := by decide
theorem cert_e2419143486958 : check e2419143486958 [[],[]] .smaller = true := by decide
def e2419143487326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2419143487326 : Closed e2419143487326 ∧ code e2419143487326 = 11215236509534 := by decide
theorem cert_e2419143487326 : check e2419143487326 [[],[]] .smaller = true := by decide
def e2419143487354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2419143487354 : Closed e2419143487354 ∧ code e2419143487354 = 11215236509562 := by decide
theorem cert_e2419143487354 : check e2419143487354 [[],[]] .smaller = true := by decide
def e2419143487406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2419143487406 : Closed e2419143487406 ∧ code e2419143487406 = 11215236509614 := by decide
theorem cert_e2419143487406 : check e2419143487406 [[],[]] .smaller = true := by decide
def e2419143487418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2419143487418 : Closed e2419143487418 ∧ code e2419143487418 = 11215236509626 := by decide
theorem cert_e2419143487418 : check e2419143487418 [[],[]] .smaller = true := by decide
def e2419143488478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2419143488478 : Closed e2419143488478 ∧ code e2419143488478 = 11215236510686 := by decide
theorem cert_e2419143488478 : check e2419143488478 [[],[]] .smaller = true := by decide
def e2419143488494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2419143488494 : Closed e2419143488494 ∧ code e2419143488494 = 11215236510702 := by decide
theorem cert_e2419143488494 : check e2419143488494 [[],[]] .smaller = true := by decide
def e2419143490782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2419143490782 : Closed e2419143490782 ∧ code e2419143490782 = 11215236512990 := by decide
theorem cert_e2419143490782 : check e2419143490782 [[],[]] .smaller = true := by decide
def e2419143490810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2419143490810 : Closed e2419143490810 ∧ code e2419143490810 = 11215236513018 := by decide
theorem cert_e2419143490810 : check e2419143490810 [[],[]] .smaller = true := by decide
def e2419143491182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419143491182 : Closed e2419143491182 ∧ code e2419143491182 = 11215236513390 := by decide
theorem cert_e2419143491182 : check e2419143491182 [[],[]] .smaller = true := by decide
def e2419143491194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419143491194 : Closed e2419143491194 ∧ code e2419143491194 = 11215236513402 := by decide
theorem cert_e2419143491194 : check e2419143491194 [[],[]] .smaller = true := by decide
def e2419143519598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2419143519598 : Closed e2419143519598 ∧ code e2419143519598 = 11215236541806 := by decide
theorem cert_e2419143519598 : check e2419143519598 [[],[]] .smaller = true := by decide
def e2419143519606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2419143519606 : Closed e2419143519606 ∧ code e2419143519606 = 11215236541814 := by decide
theorem cert_e2419143519606 : check e2419143519606 [[],[]] .smaller = true := by decide
def e2419143519662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2419143519662 : Closed e2419143519662 ∧ code e2419143519662 = 11215236541870 := by decide
theorem cert_e2419143519662 : check e2419143519662 [[],[]] .smaller = true := by decide
def e2419143519674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2419143519674 : Closed e2419143519674 ∧ code e2419143519674 = 11215236541882 := by decide
theorem cert_e2419143519674 : check e2419143519674 [[],[]] .smaller = true := by decide
def e2419143519702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2419143519702 : Closed e2419143519702 ∧ code e2419143519702 = 11215236541910 := by decide
theorem cert_e2419143519702 : check e2419143519702 [[],[]] .smaller = true := by decide
def e2419143519706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2419143519706 : Closed e2419143519706 ∧ code e2419143519706 = 11215236541914 := by decide
theorem cert_e2419143519706 : check e2419143519706 [[],[]] .smaller = true := by decide
def e2419143519918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2419143519918 : Closed e2419143519918 ∧ code e2419143519918 = 11215236542126 := by decide
theorem cert_e2419143519918 : check e2419143519918 [[],[]] .smaller = true := by decide
def e2419143519930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2419143519930 : Closed e2419143519930 ∧ code e2419143519930 = 11215236542138 := by decide
theorem cert_e2419143519930 : check e2419143519930 [[],[]] .smaller = true := by decide
def e2419143519978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2419143519978 : Closed e2419143519978 ∧ code e2419143519978 = 11215236542186 := by decide
theorem cert_e2419143519978 : check e2419143519978 [[],[]] .smaller = true := by decide
def e2419143520086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2419143520086 : Closed e2419143520086 ∧ code e2419143520086 = 11215236542294 := by decide
theorem cert_e2419143520086 : check e2419143520086 [[],[]] .smaller = true := by decide
def e2419143520090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2419143520090 : Closed e2419143520090 ∧ code e2419143520090 = 11215236542298 := by decide
theorem cert_e2419143520090 : check e2419143520090 [[],[]] .smaller = true := by decide
def e2419143520106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2419143520106 : Closed e2419143520106 ∧ code e2419143520106 = 11215236542314 := by decide
theorem cert_e2419143520106 : check e2419143520106 [[],[]] .smaller = true := by decide
def e2419143520734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2419143520734 : Closed e2419143520734 ∧ code e2419143520734 = 11215236542942 := by decide
theorem cert_e2419143520734 : check e2419143520734 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143520758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2419143520758 : Closed e2419143520758 ∧ code e2419143520758 = 11215236542966 := by decide
theorem cert_e2419143520758 : check e2419143520758 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143521134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2419143521134 : Closed e2419143521134 ∧ code e2419143521134 = 11215236543342 := by decide
theorem cert_e2419143521134 : check e2419143521134 [[],[]] .smaller = true := by decide
def e2419143521142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2419143521142 : Closed e2419143521142 ∧ code e2419143521142 = 11215236543350 := by decide
theorem cert_e2419143521142 : check e2419143521142 [[],[]] .smaller = true := by decide
def e2419143521198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2419143521198 : Closed e2419143521198 ∧ code e2419143521198 = 11215236543406 := by decide
theorem cert_e2419143521198 : check e2419143521198 [[],[]] .smaller = true := by decide
def e2419143521210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2419143521210 : Closed e2419143521210 ∧ code e2419143521210 = 11215236543418 := by decide
theorem cert_e2419143521210 : check e2419143521210 [[],[]] .smaller = true := by decide
def e2419143521238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2419143521238 : Closed e2419143521238 ∧ code e2419143521238 = 11215236543446 := by decide
theorem cert_e2419143521238 : check e2419143521238 [[],[]] .smaller = true := by decide
def e2419143521242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2419143521242 : Closed e2419143521242 ∧ code e2419143521242 = 11215236543450 := by decide
theorem cert_e2419143521242 : check e2419143521242 [[],[]] .smaller = true := by decide
def e2419143521518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419143521518 : Closed e2419143521518 ∧ code e2419143521518 = 11215236543726 := by decide
theorem cert_e2419143521518 : check e2419143521518 [[],[]] .smaller = true := by decide
def e2419143521526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419143521526 : Closed e2419143521526 ∧ code e2419143521526 = 11215236543734 := by decide
theorem cert_e2419143521526 : check e2419143521526 [[],[]] .smaller = true := by decide
def e2419143521854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2419143521854 : Closed e2419143521854 ∧ code e2419143521854 = 11215236544062 := by decide
theorem cert_e2419143521854 : check e2419143521854 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143521902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419143521902 : Closed e2419143521902 ∧ code e2419143521902 = 11215236544110 := by decide
theorem cert_e2419143521902 : check e2419143521902 [[],[]] .smaller = true := by decide
def e2419143521914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419143521914 : Closed e2419143521914 ∧ code e2419143521914 = 11215236544122 := by decide
theorem cert_e2419143521914 : check e2419143521914 [[],[]] .smaller = true := by decide
def e2419143522102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419143522102 : Closed e2419143522102 ∧ code e2419143522102 = 11215236544310 := by decide
theorem cert_e2419143522102 : check e2419143522102 [[],[]] .smaller = true := by decide
def e2419143522106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419143522106 : Closed e2419143522106 ∧ code e2419143522106 = 11215236544314 := by decide
theorem cert_e2419143522106 : check e2419143522106 [[],[]] .smaller = true := by decide
def e2419143522190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2419143522190 : Closed e2419143522190 ∧ code e2419143522190 = 11215236544398 := by decide
theorem cert_e2419143522190 : check e2419143522190 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143522526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2419143522526 : Closed e2419143522526 ∧ code e2419143522526 = 11215236544734 := by decide
theorem cert_e2419143522526 : check e2419143522526 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143522554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2419143522554 : Closed e2419143522554 ∧ code e2419143522554 = 11215236544762 := by decide
theorem cert_e2419143522554 : check e2419143522554 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2419143522734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2419143522734 : Closed e2419143522734 ∧ code e2419143522734 = 11215236544942 := by decide
theorem cert_e2419143522734 : check e2419143522734 [[],[]] .smaller = true := by decide
def e2419143522746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2419143522746 : Closed e2419143522746 ∧ code e2419143522746 = 11215236544954 := by decide
theorem cert_e2419143522746 : check e2419143522746 [[],[]] .smaller = true := by decide
def e2419143522794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2419143522794 : Closed e2419143522794 ∧ code e2419143522794 = 11215236545002 := by decide
theorem cert_e2419143522794 : check e2419143522794 [[],[]] .smaller = true := by decide
def e2419143522878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2419143522878 : Closed e2419143522878 ∧ code e2419143522878 = 11215236545086 := by decide
theorem cert_e2419143522878 : check e2419143522878 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2419143522926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419143522926 : Closed e2419143522926 ∧ code e2419143522926 = 11215236545134 := by decide
theorem cert_e2419143522926 : check e2419143522926 [[],[]] .smaller = true := by decide
def e2419143522938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419143522938 : Closed e2419143522938 ∧ code e2419143522938 = 11215236545146 := by decide
theorem cert_e2419143522938 : check e2419143522938 [[],[]] .smaller = true := by decide
def e2419143523226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143523226 : Closed e2419143523226 ∧ code e2419143523226 = 11215236545434 := by decide
theorem cert_e2419143523226 : check e2419143523226 [[],[]] .smaller = true := by decide
def e2419143523270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2419143523270 : Closed e2419143523270 ∧ code e2419143523270 = 11215236545478 := by decide
theorem cert_e2419143523270 : check e2419143523270 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2419143523542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2419143523542 : Closed e2419143523542 ∧ code e2419143523542 = 11215236545750 := by decide
theorem cert_e2419143523542 : check e2419143523542 [[],[]] .smaller = true := by decide
def e2419143523546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2419143523546 : Closed e2419143523546 ∧ code e2419143523546 = 11215236545754 := by decide
theorem cert_e2419143523546 : check e2419143523546 [[],[]] .smaller = true := by decide
def e2419143523562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2419143523562 : Closed e2419143523562 ∧ code e2419143523562 = 11215236545770 := by decide
theorem cert_e2419143523562 : check e2419143523562 [[],[]] .smaller = true := by decide
def e2419143523638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419143523638 : Closed e2419143523638 ∧ code e2419143523638 = 11215236545846 := by decide
theorem cert_e2419143523638 : check e2419143523638 [[],[]] .smaller = true := by decide
def e2419143523642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419143523642 : Closed e2419143523642 ∧ code e2419143523642 = 11215236545850 := by decide
theorem cert_e2419143523642 : check e2419143523642 [[],[]] .smaller = true := by decide
def e2419143523738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143523738 : Closed e2419143523738 ∧ code e2419143523738 = 11215236545946 := by decide
theorem cert_e2419143523738 : check e2419143523738 [[],[]] .smaller = true := by decide
def e2419143523806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e2419143523806 : Closed e2419143523806 ∧ code e2419143523806 = 11215236546014 := by decide
theorem cert_e2419143523806 : check e2419143523806 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2419143523822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e2419143523822 : Closed e2419143523822 ∧ code e2419143523822 = 11215236546030 := by decide
theorem cert_e2419143523822 : check e2419143523822 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2419143523894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2419143523894 : Closed e2419143523894 ∧ code e2419143523894 = 11215236546102 := by decide
theorem cert_e2419143523894 : check e2419143523894 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143523898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2419143523898 : Closed e2419143523898 ∧ code e2419143523898 = 11215236546106 := by decide
theorem cert_e2419143523898 : check e2419143523898 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2419143523982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2419143523982 : Closed e2419143523982 ∧ code e2419143523982 = 11215236546190 := by decide
theorem cert_e2419143523982 : check e2419143523982 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143524038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2419143524038 : Closed e2419143524038 ∧ code e2419143524038 = 11215236546246 := by decide
theorem cert_e2419143524038 : check e2419143524038 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143524078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 2))))))))
theorem wire_e2419143524078 : Closed e2419143524078 ∧ code e2419143524078 = 11215236546286 := by decide
theorem cert_e2419143524078 : checkPay e2419143524078 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left]] 0 [[.under,.left],[.under]] = true := by decide
def e2419143525342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2419143525342 : Closed e2419143525342 ∧ code e2419143525342 = 11215236547550 := by decide
theorem cert_e2419143525342 : check e2419143525342 [[],[]] .smaller = true := by decide
def e2419143525358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2419143525358 : Closed e2419143525358 ∧ code e2419143525358 = 11215236547566 := by decide
theorem cert_e2419143525358 : check e2419143525358 [[],[]] .smaller = true := by decide
def e2419143527278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419143527278 : Closed e2419143527278 ∧ code e2419143527278 = 11215236549486 := by decide
theorem cert_e2419143527278 : check e2419143527278 [[],[]] .smaller = true := by decide
def e2419143527286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419143527286 : Closed e2419143527286 ∧ code e2419143527286 = 11215236549494 := by decide
theorem cert_e2419143527286 : check e2419143527286 [[],[]] .smaller = true := by decide
def e2419143527342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419143527342 : Closed e2419143527342 ∧ code e2419143527342 = 11215236549550 := by decide
theorem cert_e2419143527342 : check e2419143527342 [[],[]] .smaller = true := by decide
def e2419143527354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419143527354 : Closed e2419143527354 ∧ code e2419143527354 = 11215236549562 := by decide
theorem cert_e2419143527354 : check e2419143527354 [[],[]] .smaller = true := by decide
def e2419143527382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419143527382 : Closed e2419143527382 ∧ code e2419143527382 = 11215236549590 := by decide
theorem cert_e2419143527382 : check e2419143527382 [[],[]] .smaller = true := by decide
def e2419143527386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419143527386 : Closed e2419143527386 ∧ code e2419143527386 = 11215236549594 := by decide
theorem cert_e2419143527386 : check e2419143527386 [[],[]] .smaller = true := by decide
def e2419143527662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419143527662 : Closed e2419143527662 ∧ code e2419143527662 = 11215236549870 := by decide
theorem cert_e2419143527662 : check e2419143527662 [[],[]] .smaller = true := by decide
def e2419143527670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419143527670 : Closed e2419143527670 ∧ code e2419143527670 = 11215236549878 := by decide
theorem cert_e2419143527670 : check e2419143527670 [[],[]] .smaller = true := by decide
def e2419143527998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2419143527998 : Closed e2419143527998 ∧ code e2419143527998 = 11215236550206 := by decide
theorem cert_e2419143527998 : check e2419143527998 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2419143528046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419143528046 : Closed e2419143528046 ∧ code e2419143528046 = 11215236550254 := by decide
theorem cert_e2419143528046 : check e2419143528046 [[],[]] .smaller = true := by decide
def e2419143528058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419143528058 : Closed e2419143528058 ∧ code e2419143528058 = 11215236550266 := by decide
theorem cert_e2419143528058 : check e2419143528058 [[],[]] .smaller = true := by decide
def e2419143528246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419143528246 : Closed e2419143528246 ∧ code e2419143528246 = 11215236550454 := by decide
theorem cert_e2419143528246 : check e2419143528246 [[],[]] .smaller = true := by decide
def e2419143528250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419143528250 : Closed e2419143528250 ∧ code e2419143528250 = 11215236550458 := by decide
theorem cert_e2419143528250 : check e2419143528250 [[],[]] .smaller = true := by decide
def e2419143528334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2419143528334 : Closed e2419143528334 ∧ code e2419143528334 = 11215236550542 := by decide
theorem cert_e2419143528334 : check e2419143528334 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143533022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2419143533022 : Closed e2419143533022 ∧ code e2419143533022 = 11215236555230 := by decide
theorem cert_e2419143533022 : check e2419143533022 [[],[]] .smaller = true := by decide
def e2419143533046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2419143533046 : Closed e2419143533046 ∧ code e2419143533046 = 11215236555254 := by decide
theorem cert_e2419143533046 : check e2419143533046 [[],[]] .smaller = true := by decide
def e2419143533998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2419143533998 : Closed e2419143533998 ∧ code e2419143533998 = 11215236556206 := by decide
theorem cert_e2419143533998 : check e2419143533998 [[],[]] .smaller = true := by decide
def e2419143534010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2419143534010 : Closed e2419143534010 ∧ code e2419143534010 = 11215236556218 := by decide
theorem cert_e2419143534010 : check e2419143534010 [[],[]] .smaller = true := by decide
def e2419143534058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2419143534058 : Closed e2419143534058 ∧ code e2419143534058 = 11215236556266 := by decide
theorem cert_e2419143534058 : check e2419143534058 [[],[]] .smaller = true := by decide
def e2419143534142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2419143534142 : Closed e2419143534142 ∧ code e2419143534142 = 11215236556350 := by decide
theorem cert_e2419143534142 : check e2419143534142 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2419143534190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419143534190 : Closed e2419143534190 ∧ code e2419143534190 = 11215236556398 := by decide
theorem cert_e2419143534190 : check e2419143534190 [[],[]] .smaller = true := by decide
def e2419143534202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419143534202 : Closed e2419143534202 ∧ code e2419143534202 = 11215236556410 := by decide
theorem cert_e2419143534202 : check e2419143534202 [[],[]] .smaller = true := by decide
def e2419143534490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419143534490 : Closed e2419143534490 ∧ code e2419143534490 = 11215236556698 := by decide
theorem cert_e2419143534490 : check e2419143534490 [[],[]] .smaller = true := by decide
def e2419143534534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2419143534534 : Closed e2419143534534 ∧ code e2419143534534 = 11215236556742 := by decide
theorem cert_e2419143534534 : check e2419143534534 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e2419143536878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2419143536878 : Closed e2419143536878 ∧ code e2419143536878 = 11215236559086 := by decide
theorem cert_e2419143536878 : check e2419143536878 [[],[]] .smaller = true := by decide
def e2419143536886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2419143536886 : Closed e2419143536886 ∧ code e2419143536886 = 11215236559094 := by decide
theorem cert_e2419143536886 : check e2419143536886 [[],[]] .smaller = true := by decide
def e2419143537366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2419143537366 : Closed e2419143537366 ∧ code e2419143537366 = 11215236559574 := by decide
theorem cert_e2419143537366 : check e2419143537366 [[],[]] .smaller = true := by decide
def e2419143537370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2419143537370 : Closed e2419143537370 ∧ code e2419143537370 = 11215236559578 := by decide
theorem cert_e2419143537370 : check e2419143537370 [[],[]] .smaller = true := by decide
def e2419143537386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2419143537386 : Closed e2419143537386 ∧ code e2419143537386 = 11215236559594 := by decide
theorem cert_e2419143537386 : check e2419143537386 [[],[]] .smaller = true := by decide
def e2419143537462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419143537462 : Closed e2419143537462 ∧ code e2419143537462 = 11215236559670 := by decide
theorem cert_e2419143537462 : check e2419143537462 [[],[]] .smaller = true := by decide
def e2419143537466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419143537466 : Closed e2419143537466 ∧ code e2419143537466 = 11215236559674 := by decide
theorem cert_e2419143537466 : check e2419143537466 [[],[]] .smaller = true := by decide
def e2419143537562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419143537562 : Closed e2419143537562 ∧ code e2419143537562 = 11215236559770 := by decide
theorem cert_e2419143537562 : check e2419143537562 [[],[]] .smaller = true := by decide
def e2419143537630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 3)))))))))
theorem wire_e2419143537630 : Closed e2419143537630 ∧ code e2419143537630 = 11215236559838 := by decide
theorem cert_e2419143537630 : checkPay e2419143537630 [[.left,.left],[.left,.left],[.left],[],[],[.left]] 0 [[.right]] = true := by decide
def e2419143537646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 2)))))))))
theorem wire_e2419143537646 : Closed e2419143537646 ∧ code e2419143537646 = 11215236559854 := by decide
theorem cert_e2419143537646 : checkPay e2419143537646 [[.left,.left],[.left,.left],[.left],[],[],[.left]] 0 [[.left],[],[.under,.right,.under,.right]] = true := by decide
def e2419143539086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2419143539086 : Closed e2419143539086 ∧ code e2419143539086 = 11215236561294 := by decide
theorem cert_e2419143539086 : check e2419143539086 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2419143539142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2419143539142 : Closed e2419143539142 ∧ code e2419143539142 = 11215236561350 := by decide
theorem cert_e2419143539142 : check e2419143539142 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2419143539182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419143539182 : Closed e2419143539182 ∧ code e2419143539182 = 11215236561390 := by decide
theorem cert_e2419143539182 : check e2419143539182 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2419143619822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143619822 : Closed e2419143619822 ∧ code e2419143619822 = 11215236642030 := by decide
theorem cert_e2419143619822 : check e2419143619822 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2419143619830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143619830 : Closed e2419143619830 ∧ code e2419143619830 = 11215236642038 := by decide
theorem cert_e2419143619830 : check e2419143619830 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143651694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2419143651694 : Closed e2419143651694 ∧ code e2419143651694 = 11215236673902 := by decide
theorem cert_e2419143651694 : check e2419143651694 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143651702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2419143651702 : Closed e2419143651702 ∧ code e2419143651702 = 11215236673910 := by decide
theorem cert_e2419143651702 : check e2419143651702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143652910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419143652910 : Closed e2419143652910 ∧ code e2419143652910 = 11215236675118 := by decide
theorem cert_e2419143652910 : check e2419143652910 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143653090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419143653090 : Closed e2419143653090 ∧ code e2419143653090 = 11215236675298 := by decide
theorem cert_e2419143653090 : check e2419143653090 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143653102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2419143653102 : Closed e2419143653102 ∧ code e2419143653102 = 11215236675310 := by decide
theorem cert_e2419143653102 : check e2419143653102 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143653142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419143653142 : Closed e2419143653142 ∧ code e2419143653142 = 11215236675350 := by decide
theorem cert_e2419143653142 : check e2419143653142 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143653218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419143653218 : Closed e2419143653218 ∧ code e2419143653218 = 11215236675426 := by decide
theorem cert_e2419143653218 : check e2419143653218 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143653230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2419143653230 : Closed e2419143653230 ∧ code e2419143653230 = 11215236675438 := by decide
theorem cert_e2419143653230 : check e2419143653230 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143653238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2419143653238 : Closed e2419143653238 ∧ code e2419143653238 = 11215236675446 := by decide
theorem cert_e2419143653238 : check e2419143653238 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143653550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2419143653550 : Closed e2419143653550 ∧ code e2419143653550 = 11215236675758 := by decide
theorem cert_e2419143653550 : check e2419143653550 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143653562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2419143653562 : Closed e2419143653562 ∧ code e2419143653562 = 11215236675770 := by decide
theorem cert_e2419143653562 : check e2419143653562 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143653934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419143653934 : Closed e2419143653934 ∧ code e2419143653934 = 11215236676142 := by decide
theorem cert_e2419143653934 : check e2419143653934 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419143654114 : Closed e2419143654114 ∧ code e2419143654114 = 11215236676322 := by decide
theorem cert_e2419143654114 : check e2419143654114 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2419143654126 : Closed e2419143654126 ∧ code e2419143654126 = 11215236676334 := by decide
theorem cert_e2419143654126 : check e2419143654126 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2419143654254 : Closed e2419143654254 ∧ code e2419143654254 = 11215236676462 := by decide
theorem cert_e2419143654254 : check e2419143654254 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2419143654262 : Closed e2419143654262 ∧ code e2419143654262 = 11215236676470 := by decide
theorem cert_e2419143654262 : check e2419143654262 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419143654282 : Closed e2419143654282 ∧ code e2419143654282 = 11215236676490 := by decide
theorem cert_e2419143654282 : check e2419143654282 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419143654306 : Closed e2419143654306 ∧ code e2419143654306 = 11215236676514 := by decide
theorem cert_e2419143654306 : check e2419143654306 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2419143654318 : Closed e2419143654318 ∧ code e2419143654318 = 11215236676526 := by decide
theorem cert_e2419143654318 : check e2419143654318 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2419143654326 : Closed e2419143654326 ∧ code e2419143654326 = 11215236676534 := by decide
theorem cert_e2419143654326 : check e2419143654326 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2419143654330 : Closed e2419143654330 ∧ code e2419143654330 = 11215236676538 := by decide
theorem cert_e2419143654330 : check e2419143654330 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143654486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2419143654486 : Closed e2419143654486 ∧ code e2419143654486 = 11215236676694 := by decide
theorem cert_e2419143654486 : check e2419143654486 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143654490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2419143654490 : Closed e2419143654490 ∧ code e2419143654490 = 11215236676698 := by decide
theorem cert_e2419143654490 : check e2419143654490 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143654678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419143654678 : Closed e2419143654678 ∧ code e2419143654678 = 11215236676886 := by decide
theorem cert_e2419143654678 : check e2419143654678 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143654754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419143654754 : Closed e2419143654754 ∧ code e2419143654754 = 11215236676962 := by decide
theorem cert_e2419143654754 : check e2419143654754 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143654766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2419143654766 : Closed e2419143654766 ∧ code e2419143654766 = 11215236676974 := by decide
theorem cert_e2419143654766 : check e2419143654766 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143654774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2419143654774 : Closed e2419143654774 ∧ code e2419143654774 = 11215236676982 := by decide
theorem cert_e2419143654774 : check e2419143654774 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143654794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419143654794 : Closed e2419143654794 ∧ code e2419143654794 = 11215236677002 := by decide
theorem cert_e2419143654794 : check e2419143654794 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143654818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419143654818 : Closed e2419143654818 ∧ code e2419143654818 = 11215236677026 := by decide
theorem cert_e2419143654818 : check e2419143654818 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143654830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2419143654830 : Closed e2419143654830 ∧ code e2419143654830 = 11215236677038 := by decide
theorem cert_e2419143654830 : check e2419143654830 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143654838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e2419143654838 : Closed e2419143654838 ∧ code e2419143654838 = 11215236677046 := by decide
theorem cert_e2419143654838 : check e2419143654838 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143654842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2419143654842 : Closed e2419143654842 ∧ code e2419143654842 = 11215236677050 := by decide
def e2419143654870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2419143654870 : Closed e2419143654870 ∧ code e2419143654870 = 11215236677078 := by decide
def e2419143654874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2419143654874 : Closed e2419143654874 ∧ code e2419143654874 = 11215236677082 := by decide
theorem cert_e2419143654874 : check e2419143654874 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143655918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2419143655918 : Closed e2419143655918 ∧ code e2419143655918 = 11215236678126 := by decide
theorem cert_e2419143655918 : check e2419143655918 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143655926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2419143655926 : Closed e2419143655926 ∧ code e2419143655926 = 11215236678134 := by decide
theorem cert_e2419143655926 : check e2419143655926 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143656686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143656686 : Closed e2419143656686 ∧ code e2419143656686 = 11215236678894 := by decide
theorem cert_e2419143656686 : check e2419143656686 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143656694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143656694 : Closed e2419143656694 ∧ code e2419143656694 = 11215236678902 := by decide
theorem cert_e2419143656694 : check e2419143656694 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143657246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2419143657246 : Closed e2419143657246 ∧ code e2419143657246 = 11215236679454 := by decide
theorem cert_e2419143657246 : check e2419143657246 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2419143657358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2419143657358 : Closed e2419143657358 ∧ code e2419143657358 = 11215236679566 := by decide
theorem cert_e2419143657358 : checkPay e2419143657358 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] 0 [] = true := by decide
def e2419143659054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2419143659054 : Closed e2419143659054 ∧ code e2419143659054 = 11215236681262 := by decide
theorem cert_e2419143659054 : check e2419143659054 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143659234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2419143659234 : Closed e2419143659234 ∧ code e2419143659234 = 11215236681442 := by decide
theorem cert_e2419143659234 : check e2419143659234 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143659246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2419143659246 : Closed e2419143659246 ∧ code e2419143659246 = 11215236681454 := by decide
theorem cert_e2419143659246 : check e2419143659246 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143659286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2419143659286 : Closed e2419143659286 ∧ code e2419143659286 = 11215236681494 := by decide
theorem cert_e2419143659286 : check e2419143659286 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[]] .identityHead = true := by decide
def e2419143659362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2419143659362 : Closed e2419143659362 ∧ code e2419143659362 = 11215236681570 := by decide
theorem cert_e2419143659362 : check e2419143659362 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143659374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2419143659374 : Closed e2419143659374 ∧ code e2419143659374 = 11215236681582 := by decide
theorem cert_e2419143659374 : check e2419143659374 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2419143659382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2419143659382 : Closed e2419143659382 ∧ code e2419143659382 = 11215236681590 := by decide
theorem cert_e2419143659382 : check e2419143659382 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[]] .identityHead = true := by decide
def e2419143661630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2419143661630 : Closed e2419143661630 ∧ code e2419143661630 = 11215236683838 := by decide
theorem cert_e2419143661630 : check e2419143661630 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143662050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419143662050 : Closed e2419143662050 ∧ code e2419143662050 = 11215236684258 := by decide
theorem cert_e2419143662050 : check e2419143662050 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143662062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2419143662062 : Closed e2419143662062 ∧ code e2419143662062 = 11215236684270 := by decide
theorem cert_e2419143662062 : check e2419143662062 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2419143662622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2419143662622 : Closed e2419143662622 ∧ code e2419143662622 = 11215236684830 := by decide
theorem cert_e2419143662622 : check e2419143662622 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143662818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419143662818 : Closed e2419143662818 ∧ code e2419143662818 = 11215236685026 := by decide
theorem cert_e2419143662818 : check e2419143662818 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143662830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143662830 : Closed e2419143662830 ∧ code e2419143662830 = 11215236685038 := by decide
theorem cert_e2419143662830 : check e2419143662830 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143662838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143662838 : Closed e2419143662838 ∧ code e2419143662838 = 11215236685046 := by decide
theorem cert_e2419143662838 : check e2419143662838 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419143439162
#print axioms Blc.Floor43.cert_e2419143439258
