import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262377999802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2262377999802 : Closed e2262377999802 ∧ code e2262377999802 = 11058471022010 := by decide
theorem cert_e2262377999802 : check e2262377999802 [[],[.under]] .three = true := by decide
def e2262377999830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2262377999830 : Closed e2262377999830 ∧ code e2262377999830 = 11058471022038 := by decide
theorem cert_e2262377999830 : check e2262377999830 [[],[.under]] .three = true := by decide
def e2262377999834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2262377999834 : Closed e2262377999834 ∧ code e2262377999834 = 11058471022042 := by decide
theorem cert_e2262377999834 : check e2262377999834 [[],[.under]] .three = true := by decide
def e2262377999914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2262377999914 : Closed e2262377999914 ∧ code e2262377999914 = 11058471022122 := by decide
theorem cert_e2262377999914 : check e2262377999914 [[],[.under]] .three = true := by decide
def e2262378000010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262378000010 : Closed e2262378000010 ∧ code e2262378000010 = 11058471022218 := by decide
theorem cert_e2262378000010 : check e2262378000010 [[],[.under]] .three = true := by decide
def e2262378000034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262378000034 : Closed e2262378000034 ∧ code e2262378000034 = 11058471022242 := by decide
theorem cert_e2262378000034 : check e2262378000034 [[],[.under]] .three = true := by decide
def e2262378000046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2262378000046 : Closed e2262378000046 ∧ code e2262378000046 = 11058471022254 := by decide
theorem cert_e2262378000046 : check e2262378000046 [[],[.under]] .three = true := by decide
def e2262378000054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2262378000054 : Closed e2262378000054 ∧ code e2262378000054 = 11058471022262 := by decide
theorem cert_e2262378000054 : check e2262378000054 [[],[.under]] .three = true := by decide
def e2262378000058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2262378000058 : Closed e2262378000058 ∧ code e2262378000058 = 11058471022266 := by decide
theorem cert_e2262378000058 : check e2262378000058 [[],[.under]] .three = true := by decide
def e2262378000086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2262378000086 : Closed e2262378000086 ∧ code e2262378000086 = 11058471022294 := by decide
theorem cert_e2262378000086 : check e2262378000086 [[],[.under]] .three = true := by decide
def e2262378000090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2262378000090 : Closed e2262378000090 ∧ code e2262378000090 = 11058471022298 := by decide
theorem cert_e2262378000090 : check e2262378000090 [[],[.under]] .three = true := by decide
def e2262378000106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2262378000106 : Closed e2262378000106 ∧ code e2262378000106 = 11058471022314 := by decide
theorem cert_e2262378000106 : check e2262378000106 [[],[.under]] .three = true := by decide
def e2262378000214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2262378000214 : Closed e2262378000214 ∧ code e2262378000214 = 11058471022422 := by decide
theorem cert_e2262378000214 : check e2262378000214 [[],[.under]] .three = true := by decide
def e2262378000218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2262378000218 : Closed e2262378000218 ∧ code e2262378000218 = 11058471022426 := by decide
theorem cert_e2262378000218 : check e2262378000218 [[],[.under]] .three = true := by decide
def e2262378000234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2262378000234 : Closed e2262378000234 ∧ code e2262378000234 = 11058471022442 := by decide
theorem cert_e2262378000234 : check e2262378000234 [[],[.under]] .three = true := by decide
def e2262378000502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2262378000502 : Closed e2262378000502 ∧ code e2262378000502 = 11058471022710 := by decide
theorem cert_e2262378000502 : check e2262378000502 [[],[.under]] .three = true := by decide
def e2262378000506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2262378000506 : Closed e2262378000506 ∧ code e2262378000506 = 11058471022714 := by decide
theorem cert_e2262378000506 : check e2262378000506 [[],[.under]] .three = true := by decide
def e2262378000598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2262378000598 : Closed e2262378000598 ∧ code e2262378000598 = 11058471022806 := by decide
theorem cert_e2262378000598 : check e2262378000598 [[],[.under]] .three = true := by decide
def e2262378000694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262378000694 : Closed e2262378000694 ∧ code e2262378000694 = 11058471022902 := by decide
theorem cert_e2262378000694 : check e2262378000694 [[],[.under]] .three = true := by decide
def e2262378000698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262378000698 : Closed e2262378000698 ∧ code e2262378000698 = 11058471022906 := by decide
theorem cert_e2262378000698 : check e2262378000698 [[],[.under]] .three = true := by decide
def e2262378000782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2262378000782 : Closed e2262378000782 ∧ code e2262378000782 = 11058471022990 := by decide
theorem cert_e2262378000782 : check e2262378000782 [[],[.under]] .three = true := by decide
def e2262378000838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2262378000838 : Closed e2262378000838 ∧ code e2262378000838 = 11058471023046 := by decide
theorem cert_e2262378000838 : check e2262378000838 [[],[.under]] .three = true := by decide
def e2262378001174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2262378001174 : Closed e2262378001174 ∧ code e2262378001174 = 11058471023382 := by decide
theorem cert_e2262378001174 : check e2262378001174 [[],[.under]] .three = true := by decide
def e2262378001250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2262378001250 : Closed e2262378001250 ∧ code e2262378001250 = 11058471023458 := by decide
theorem cert_e2262378001250 : check e2262378001250 [[],[.under]] .three = true := by decide
def e2262378001262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2262378001262 : Closed e2262378001262 ∧ code e2262378001262 = 11058471023470 := by decide
theorem cert_e2262378001262 : check e2262378001262 [[],[.under]] .three = true := by decide
def e2262378001270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2262378001270 : Closed e2262378001270 ∧ code e2262378001270 = 11058471023478 := by decide
theorem cert_e2262378001270 : check e2262378001270 [[],[.under]] .three = true := by decide
def e2262378001290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262378001290 : Closed e2262378001290 ∧ code e2262378001290 = 11058471023498 := by decide
theorem cert_e2262378001290 : check e2262378001290 [[],[.under]] .three = true := by decide
def e2262378001314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262378001314 : Closed e2262378001314 ∧ code e2262378001314 = 11058471023522 := by decide
theorem cert_e2262378001314 : check e2262378001314 [[],[.under]] .three = true := by decide
def e2262378001326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2262378001326 : Closed e2262378001326 ∧ code e2262378001326 = 11058471023534 := by decide
theorem cert_e2262378001326 : check e2262378001326 [[],[.under]] .three = true := by decide
def e2262378001334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e2262378001334 : Closed e2262378001334 ∧ code e2262378001334 = 11058471023542 := by decide
theorem cert_e2262378001334 : check e2262378001334 [[],[.under]] .three = true := by decide
def e2262378001338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2262378001338 : Closed e2262378001338 ∧ code e2262378001338 = 11058471023546 := by decide
theorem cert_e2262378001338 : check e2262378001338 [[],[.under]] .three = true := by decide
def e2262378001366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2262378001366 : Closed e2262378001366 ∧ code e2262378001366 = 11058471023574 := by decide
theorem cert_e2262378001366 : check e2262378001366 [[],[.under]] .three = true := by decide
def e2262378001370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2262378001370 : Closed e2262378001370 ∧ code e2262378001370 = 11058471023578 := by decide
theorem cert_e2262378001370 : check e2262378001370 [[],[.under]] .three = true := by decide
def e2262378001438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2262378001438 : Closed e2262378001438 ∧ code e2262378001438 = 11058471023646 := by decide
theorem cert_e2262378001438 : check e2262378001438 [[],[.under]] .three = true := by decide
def e2262378001634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262378001634 : Closed e2262378001634 ∧ code e2262378001634 = 11058471023842 := by decide
theorem cert_e2262378001634 : check e2262378001634 [[],[.under]] .three = true := by decide
def e2262378001646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262378001646 : Closed e2262378001646 ∧ code e2262378001646 = 11058471023854 := by decide
theorem cert_e2262378001646 : check e2262378001646 [[],[.under]] .three = true := by decide
def e2262378001654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262378001654 : Closed e2262378001654 ∧ code e2262378001654 = 11058471023862 := by decide
theorem cert_e2262378001654 : check e2262378001654 [[],[.under]] .three = true := by decide
def e2262378001934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262378001934 : Closed e2262378001934 ∧ code e2262378001934 = 11058471024142 := by decide
theorem cert_e2262378001934 : check e2262378001934 [[],[.under]] .three = true := by decide
def e2262378001946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262378001946 : Closed e2262378001946 ∧ code e2262378001946 = 11058471024154 := by decide
theorem cert_e2262378001946 : check e2262378001946 [[],[.under]] .three = true := by decide
def e2262378002018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262378002018 : Closed e2262378002018 ∧ code e2262378002018 = 11058471024226 := by decide
theorem cert_e2262378002018 : check e2262378002018 [[],[.under]] .three = true := by decide
def e2262378002030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262378002030 : Closed e2262378002030 ∧ code e2262378002030 = 11058471024238 := by decide
theorem cert_e2262378002030 : check e2262378002030 [[],[.under]] .three = true := by decide
def e2262378002038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262378002038 : Closed e2262378002038 ∧ code e2262378002038 = 11058471024246 := by decide
theorem cert_e2262378002038 : check e2262378002038 [[],[.under]] .three = true := by decide
def e2262378002042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262378002042 : Closed e2262378002042 ∧ code e2262378002042 = 11058471024250 := by decide
theorem cert_e2262378002042 : check e2262378002042 [[],[.under]] .three = true := by decide
def e2262378002230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262378002230 : Closed e2262378002230 ∧ code e2262378002230 = 11058471024438 := by decide
theorem cert_e2262378002230 : check e2262378002230 [[],[.under]] .three = true := by decide
def e2262378002234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262378002234 : Closed e2262378002234 ∧ code e2262378002234 = 11058471024442 := by decide
theorem cert_e2262378002234 : check e2262378002234 [[],[.under]] .three = true := by decide
def e2262378002490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2262378002490 : Closed e2262378002490 ∧ code e2262378002490 = 11058471024698 := by decide
theorem cert_e2262378002490 : check e2262378002490 [[],[.under]] .three = true := by decide
def e2262378002538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2262378002538 : Closed e2262378002538 ∧ code e2262378002538 = 11058471024746 := by decide
theorem cert_e2262378002538 : check e2262378002538 [[],[.under]] .three = true := by decide
def e2262378002586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262378002586 : Closed e2262378002586 ∧ code e2262378002586 = 11058471024794 := by decide
theorem cert_e2262378002586 : check e2262378002586 [[],[.under]] .three = true := by decide
def e2262378002630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e2262378002630 : Closed e2262378002630 ∧ code e2262378002630 = 11058471024838 := by decide
theorem cert_e2262378002630 : check e2262378002630 [[],[.under]] .three = true := by decide
def e2262378002826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262378002826 : Closed e2262378002826 ∧ code e2262378002826 = 11058471025034 := by decide
theorem cert_e2262378002826 : check e2262378002826 [[],[.under]] .three = true := by decide
def e2262378002850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262378002850 : Closed e2262378002850 ∧ code e2262378002850 = 11058471025058 := by decide
theorem cert_e2262378002850 : check e2262378002850 [[],[.under]] .three = true := by decide
def e2262378002862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2262378002862 : Closed e2262378002862 ∧ code e2262378002862 = 11058471025070 := by decide
theorem cert_e2262378002862 : check e2262378002862 [[],[.under]] .three = true := by decide
def e2262378002870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2262378002870 : Closed e2262378002870 ∧ code e2262378002870 = 11058471025078 := by decide
theorem cert_e2262378002870 : check e2262378002870 [[],[.under]] .three = true := by decide
def e2262378002874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2262378002874 : Closed e2262378002874 ∧ code e2262378002874 = 11058471025082 := by decide
theorem cert_e2262378002874 : check e2262378002874 [[],[.under]] .three = true := by decide
def e2262378002902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2262378002902 : Closed e2262378002902 ∧ code e2262378002902 = 11058471025110 := by decide
theorem cert_e2262378002902 : check e2262378002902 [[],[.under]] .three = true := by decide
def e2262378002906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2262378002906 : Closed e2262378002906 ∧ code e2262378002906 = 11058471025114 := by decide
theorem cert_e2262378002906 : check e2262378002906 [[],[.under]] .three = true := by decide
def e2262378002922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2262378002922 : Closed e2262378002922 ∧ code e2262378002922 = 11058471025130 := by decide
theorem cert_e2262378002922 : check e2262378002922 [[],[.under]] .three = true := by decide
def e2262378002958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262378002958 : Closed e2262378002958 ∧ code e2262378002958 = 11058471025166 := by decide
theorem cert_e2262378002958 : check e2262378002958 [[],[.under]] .three = true := by decide
def e2262378002970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262378002970 : Closed e2262378002970 ∧ code e2262378002970 = 11058471025178 := by decide
theorem cert_e2262378002970 : check e2262378002970 [[],[.under]] .three = true := by decide
def e2262378003042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262378003042 : Closed e2262378003042 ∧ code e2262378003042 = 11058471025250 := by decide
theorem cert_e2262378003042 : check e2262378003042 [[],[.under]] .three = true := by decide
def e2262378003054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262378003054 : Closed e2262378003054 ∧ code e2262378003054 = 11058471025262 := by decide
theorem cert_e2262378003054 : check e2262378003054 [[],[.under]] .three = true := by decide
def e2262378003062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262378003062 : Closed e2262378003062 ∧ code e2262378003062 = 11058471025270 := by decide
theorem cert_e2262378003062 : check e2262378003062 [[],[.under]] .three = true := by decide
def e2262378003066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262378003066 : Closed e2262378003066 ∧ code e2262378003066 = 11058471025274 := by decide
theorem cert_e2262378003066 : check e2262378003066 [[],[.under]] .three = true := by decide
def e2262378003254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262378003254 : Closed e2262378003254 ∧ code e2262378003254 = 11058471025462 := by decide
theorem cert_e2262378003254 : check e2262378003254 [[],[.under]] .three = true := by decide
def e2262378003258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262378003258 : Closed e2262378003258 ∧ code e2262378003258 = 11058471025466 := by decide
theorem cert_e2262378003258 : check e2262378003258 [[],[.under]] .three = true := by decide
def e2262378003354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2262378003354 : Closed e2262378003354 ∧ code e2262378003354 = 11058471025562 := by decide
theorem cert_e2262378003354 : check e2262378003354 [[],[.under]] .three = true := by decide
def e2262378003670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2262378003670 : Closed e2262378003670 ∧ code e2262378003670 = 11058471025878 := by decide
theorem cert_e2262378003670 : check e2262378003670 [[],[.under]] .three = true := by decide
def e2262378003674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2262378003674 : Closed e2262378003674 ∧ code e2262378003674 = 11058471025882 := by decide
theorem cert_e2262378003674 : check e2262378003674 [[],[.under]] .three = true := by decide
def e2262378003690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2262378003690 : Closed e2262378003690 ∧ code e2262378003690 = 11058471025898 := by decide
theorem cert_e2262378003690 : check e2262378003690 [[],[.under]] .three = true := by decide
def e2262378003766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262378003766 : Closed e2262378003766 ∧ code e2262378003766 = 11058471025974 := by decide
theorem cert_e2262378003766 : check e2262378003766 [[],[.under]] .three = true := by decide
def e2262378003770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262378003770 : Closed e2262378003770 ∧ code e2262378003770 = 11058471025978 := by decide
theorem cert_e2262378003770 : check e2262378003770 [[],[.under]] .three = true := by decide
def e2262378003866 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2262378003866 : Closed e2262378003866 ∧ code e2262378003866 = 11058471026074 := by decide
theorem cert_e2262378003866 : check e2262378003866 [[],[.under]] .three = true := by decide
def e2262378005470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2262378005470 : Closed e2262378005470 ∧ code e2262378005470 = 11058471027678 := by decide
theorem cert_e2262378005470 : check e2262378005470 [[],[.under]] .three = true := by decide
def e2262378005486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2262378005486 : Closed e2262378005486 ∧ code e2262378005486 = 11058471027694 := by decide
theorem cert_e2262378005486 : check e2262378005486 [[],[.under]] .three = true := by decide
def e2262378007318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2262378007318 : Closed e2262378007318 ∧ code e2262378007318 = 11058471029526 := by decide
theorem cert_e2262378007318 : check e2262378007318 [[],[.under]] .three = true := by decide
def e2262378007394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2262378007394 : Closed e2262378007394 ∧ code e2262378007394 = 11058471029602 := by decide
theorem cert_e2262378007394 : check e2262378007394 [[],[.under]] .three = true := by decide
def e2262378007406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262378007406 : Closed e2262378007406 ∧ code e2262378007406 = 11058471029614 := by decide
theorem cert_e2262378007406 : check e2262378007406 [[],[.under]] .three = true := by decide
def e2262378007414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262378007414 : Closed e2262378007414 ∧ code e2262378007414 = 11058471029622 := by decide
theorem cert_e2262378007414 : check e2262378007414 [[],[.under]] .three = true := by decide
def e2262378007434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262378007434 : Closed e2262378007434 ∧ code e2262378007434 = 11058471029642 := by decide
theorem cert_e2262378007434 : check e2262378007434 [[],[.under]] .three = true := by decide
def e2262378007458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262378007458 : Closed e2262378007458 ∧ code e2262378007458 = 11058471029666 := by decide
theorem cert_e2262378007458 : check e2262378007458 [[],[.under]] .three = true := by decide
def e2262378007470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262378007470 : Closed e2262378007470 ∧ code e2262378007470 = 11058471029678 := by decide
theorem cert_e2262378007470 : check e2262378007470 [[],[.under]] .three = true := by decide
def e2262378007478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e2262378007478 : Closed e2262378007478 ∧ code e2262378007478 = 11058471029686 := by decide
theorem cert_e2262378007478 : check e2262378007478 [[],[.under]] .three = true := by decide
def e2262378007482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262378007482 : Closed e2262378007482 ∧ code e2262378007482 = 11058471029690 := by decide
theorem cert_e2262378007482 : check e2262378007482 [[],[.under]] .three = true := by decide
def e2262378007510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262378007510 : Closed e2262378007510 ∧ code e2262378007510 = 11058471029718 := by decide
theorem cert_e2262378007510 : check e2262378007510 [[],[.under]] .three = true := by decide
def e2262378007514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262378007514 : Closed e2262378007514 ∧ code e2262378007514 = 11058471029722 := by decide
theorem cert_e2262378007514 : check e2262378007514 [[],[.under]] .three = true := by decide
def e2262378007582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2262378007582 : Closed e2262378007582 ∧ code e2262378007582 = 11058471029790 := by decide
theorem cert_e2262378007582 : check e2262378007582 [[],[.under]] .three = true := by decide
def e2262378007778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2262378007778 : Closed e2262378007778 ∧ code e2262378007778 = 11058471029986 := by decide
theorem cert_e2262378007778 : check e2262378007778 [[],[.under]] .three = true := by decide
def e2262378007790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262378007790 : Closed e2262378007790 ∧ code e2262378007790 = 11058471029998 := by decide
theorem cert_e2262378007790 : check e2262378007790 [[],[.under]] .three = true := by decide
def e2262378007798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262378007798 : Closed e2262378007798 ∧ code e2262378007798 = 11058471030006 := by decide
theorem cert_e2262378007798 : check e2262378007798 [[],[.under]] .three = true := by decide
def e2262378008078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2262378008078 : Closed e2262378008078 ∧ code e2262378008078 = 11058471030286 := by decide
theorem cert_e2262378008078 : check e2262378008078 [[],[.under]] .three = true := by decide
def e2262378008090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2262378008090 : Closed e2262378008090 ∧ code e2262378008090 = 11058471030298 := by decide
theorem cert_e2262378008090 : check e2262378008090 [[],[.under]] .three = true := by decide
def e2262378008162 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262378008162 : Closed e2262378008162 ∧ code e2262378008162 = 11058471030370 := by decide
theorem cert_e2262378008162 : check e2262378008162 [[],[.under]] .three = true := by decide
def e2262378008174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262378008174 : Closed e2262378008174 ∧ code e2262378008174 = 11058471030382 := by decide
theorem cert_e2262378008174 : check e2262378008174 [[],[.under]] .three = true := by decide
def e2262378008182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262378008182 : Closed e2262378008182 ∧ code e2262378008182 = 11058471030390 := by decide
theorem cert_e2262378008182 : check e2262378008182 [[],[.under]] .three = true := by decide
def e2262378008186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262378008186 : Closed e2262378008186 ∧ code e2262378008186 = 11058471030394 := by decide
theorem cert_e2262378008186 : check e2262378008186 [[],[.under]] .three = true := by decide
def e2262378008374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262378008374 : Closed e2262378008374 ∧ code e2262378008374 = 11058471030582 := by decide
theorem cert_e2262378008374 : check e2262378008374 [[],[.under]] .three = true := by decide
def e2262378008378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262378008378 : Closed e2262378008378 ∧ code e2262378008378 = 11058471030586 := by decide
theorem cert_e2262378008378 : check e2262378008378 [[],[.under]] .three = true := by decide
def e2262378013150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2262378013150 : Closed e2262378013150 ∧ code e2262378013150 = 11058471035358 := by decide
theorem cert_e2262378013150 : check e2262378013150 [[],[.under]] .three = true := by decide
def e2262378013174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2262378013174 : Closed e2262378013174 ∧ code e2262378013174 = 11058471035382 := by decide
theorem cert_e2262378013174 : check e2262378013174 [[],[.under]] .three = true := by decide
def e2262378014090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262378014090 : Closed e2262378014090 ∧ code e2262378014090 = 11058471036298 := by decide
theorem cert_e2262378014090 : check e2262378014090 [[],[.under]] .three = true := by decide
def e2262378014114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262378014114 : Closed e2262378014114 ∧ code e2262378014114 = 11058471036322 := by decide
theorem cert_e2262378014114 : check e2262378014114 [[],[.under]] .three = true := by decide
def e2262378014126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2262378014126 : Closed e2262378014126 ∧ code e2262378014126 = 11058471036334 := by decide
theorem cert_e2262378014126 : check e2262378014126 [[],[.under]] .three = true := by decide
def e2262378014134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2262378014134 : Closed e2262378014134 ∧ code e2262378014134 = 11058471036342 := by decide
theorem cert_e2262378014134 : check e2262378014134 [[],[.under]] .three = true := by decide
def e2262378014138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2262378014138 : Closed e2262378014138 ∧ code e2262378014138 = 11058471036346 := by decide
theorem cert_e2262378014138 : check e2262378014138 [[],[.under]] .three = true := by decide
def e2262378014166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2262378014166 : Closed e2262378014166 ∧ code e2262378014166 = 11058471036374 := by decide
theorem cert_e2262378014166 : check e2262378014166 [[],[.under]] .three = true := by decide
def e2262378014170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2262378014170 : Closed e2262378014170 ∧ code e2262378014170 = 11058471036378 := by decide
theorem cert_e2262378014170 : check e2262378014170 [[],[.under]] .three = true := by decide
def e2262378014186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2262378014186 : Closed e2262378014186 ∧ code e2262378014186 = 11058471036394 := by decide
theorem cert_e2262378014186 : check e2262378014186 [[],[.under]] .three = true := by decide
def e2262378014222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e2262378014222 : Closed e2262378014222 ∧ code e2262378014222 = 11058471036430 := by decide
theorem cert_e2262378014222 : check e2262378014222 [[],[.under]] .three = true := by decide
def e2262378014234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2262378014234 : Closed e2262378014234 ∧ code e2262378014234 = 11058471036442 := by decide
theorem cert_e2262378014234 : check e2262378014234 [[],[.under]] .three = true := by decide
def e2262378014306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262378014306 : Closed e2262378014306 ∧ code e2262378014306 = 11058471036514 := by decide
theorem cert_e2262378014306 : check e2262378014306 [[],[.under]] .three = true := by decide
def e2262378014318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262378014318 : Closed e2262378014318 ∧ code e2262378014318 = 11058471036526 := by decide
theorem cert_e2262378014318 : check e2262378014318 [[],[.under]] .three = true := by decide
def e2262378014326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262378014326 : Closed e2262378014326 ∧ code e2262378014326 = 11058471036534 := by decide
theorem cert_e2262378014326 : check e2262378014326 [[],[.under]] .three = true := by decide
def e2262378014330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262378014330 : Closed e2262378014330 ∧ code e2262378014330 = 11058471036538 := by decide
theorem cert_e2262378014330 : check e2262378014330 [[],[.under]] .three = true := by decide
def e2262378014518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262378014518 : Closed e2262378014518 ∧ code e2262378014518 = 11058471036726 := by decide
theorem cert_e2262378014518 : check e2262378014518 [[],[.under]] .three = true := by decide
def e2262378014522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262378014522 : Closed e2262378014522 ∧ code e2262378014522 = 11058471036730 := by decide
theorem cert_e2262378014522 : check e2262378014522 [[],[.under]] .three = true := by decide
def e2262378014618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262378014618 : Closed e2262378014618 ∧ code e2262378014618 = 11058471036826 := by decide
theorem cert_e2262378014618 : check e2262378014618 [[],[.under]] .three = true := by decide
def e2262378017006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2262378017006 : Closed e2262378017006 ∧ code e2262378017006 = 11058471039214 := by decide
theorem cert_e2262378017006 : check e2262378017006 [[],[.under]] .three = true := by decide
def e2262378017014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2262378017014 : Closed e2262378017014 ∧ code e2262378017014 = 11058471039222 := by decide
theorem cert_e2262378017014 : check e2262378017014 [[],[.under]] .three = true := by decide
def e2262378017494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2262378017494 : Closed e2262378017494 ∧ code e2262378017494 = 11058471039702 := by decide
theorem cert_e2262378017494 : check e2262378017494 [[],[.under]] .three = true := by decide
def e2262378017498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2262378017498 : Closed e2262378017498 ∧ code e2262378017498 = 11058471039706 := by decide
theorem cert_e2262378017498 : check e2262378017498 [[],[.under]] .three = true := by decide
def e2262378017514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2262378017514 : Closed e2262378017514 ∧ code e2262378017514 = 11058471039722 := by decide
theorem cert_e2262378017514 : check e2262378017514 [[],[.under]] .three = true := by decide
def e2262378017590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262378017590 : Closed e2262378017590 ∧ code e2262378017590 = 11058471039798 := by decide
theorem cert_e2262378017590 : check e2262378017590 [[],[.under]] .three = true := by decide
def e2262378017594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262378017594 : Closed e2262378017594 ∧ code e2262378017594 = 11058471039802 := by decide
theorem cert_e2262378017594 : check e2262378017594 [[],[.under]] .three = true := by decide
def e2262378017690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262378017690 : Closed e2262378017690 ∧ code e2262378017690 = 11058471039898 := by decide
theorem cert_e2262378017690 : check e2262378017690 [[],[.under]] .three = true := by decide
def e2262383266670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262383266670 : Closed e2262383266670 ∧ code e2262383266670 = 11058476288878 := by decide
theorem cert_e2262383266670 : check e2262383266670 [[.left,.left],[.left],[.left],[],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262383266678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262383266678 : Closed e2262383266678 ∧ code e2262383266678 = 11058476288886 := by decide
private def t_e2262383266678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2262383266678 : ¬ IsSelfInterpreter e2262383266678 :=
  wSource (t := t_e2262383266678) (replay_sound (ps := []) (t := e2262383266678) (by decide)) (by decide)
def e2262383266734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262383266734 : Closed e2262383266734 ∧ code e2262383266734 = 11058476288942 := by decide
theorem cert_e2262383266734 : check e2262383266734 [[.left,.left],[.left],[.left],[],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under],[.under]] .identityHead = true := by decide
def e2262383266746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262383266746 : Closed e2262383266746 ∧ code e2262383266746 = 11058476288954 := by decide
theorem cert_e2262383266746 : check e2262383266746 [[.left,.left],[.left],[.left],[],[],[],[.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2262383266774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262383266774 : Closed e2262383266774 ∧ code e2262383266774 = 11058476288982 := by decide
private def t_e2262383266774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2262383266774 : ¬ IsSelfInterpreter e2262383266774 :=
  wSource (t := t_e2262383266774) (replay_sound (ps := []) (t := e2262383266774) (by decide)) (by decide)
def e2262383266778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262383266778 : Closed e2262383266778 ∧ code e2262383266778 = 11058476288986 := by decide
theorem cert_e2262383266778 : check e2262383266778 [[.left,.left],[.left],[.left],[],[],[],[.left],[],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .identityHead = true := by decide
def e2262383267054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262383267054 : Closed e2262383267054 ∧ code e2262383267054 = 11058476289262 := by decide
theorem cert_e2262383267054 : check e2262383267054 [[.left,.left],[.left],[.left],[],[],[],[],[.left],[.left,.left],[.left],[.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2262383267062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262383267062 : Closed e2262383267062 ∧ code e2262383267062 = 11058476289270 := by decide
theorem cert_e2262383267062 : check e2262383267062 [[.left,.left],[.left],[.left],[],[],[],[],[.left],[],[],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.left],[.under]] .identityHead = true := by decide
def e2262383267438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262383267438 : Closed e2262383267438 ∧ code e2262383267438 = 11058476289646 := by decide
theorem cert_e2262383267438 : check e2262383267438 [[.left,.left],[.left],[.left],[],[],[],[],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[],[],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[],[],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262383267450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262383267450 : Closed e2262383267450 ∧ code e2262383267450 = 11058476289658 := by decide
def e2262383267638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262383267638 : Closed e2262383267638 ∧ code e2262383267638 = 11058476289846 := by decide
theorem cert_e2262383267638 : check e2262383267638 [[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2262383267642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262383267642 : Closed e2262383267642 ∧ code e2262383267642 = 11058476289850 := by decide
theorem cert_e2262383267642 : check e2262383267642 [[],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2262385569210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e2262385569210 : Closed e2262385569210 ∧ code e2262385569210 = 11058478591418 := by decide
theorem cert_e2262385569210 : check e2262385569210 [[],[.under]] .smaller = true := by decide
def e2262385569242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e2262385569242 : Closed e2262385569242 ∧ code e2262385569242 = 11058478591450 := by decide
theorem cert_e2262385569242 : check e2262385569242 [[],[.under]] .smaller = true := by decide
def e2262385569466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e2262385569466 : Closed e2262385569466 ∧ code e2262385569466 = 11058478591674 := by decide
theorem cert_e2262385569466 : check e2262385569466 [[],[.under]] .smaller = true := by decide
def e2262385569514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e2262385569514 : Closed e2262385569514 ∧ code e2262385569514 = 11058478591722 := by decide
theorem cert_e2262385569514 : check e2262385569514 [[],[.under]] .smaller = true := by decide
def e2262385569626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e2262385569626 : Closed e2262385569626 ∧ code e2262385569626 = 11058478591834 := by decide
theorem cert_e2262385569626 : check e2262385569626 [[],[.under]] .smaller = true := by decide
def e2262385569642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e2262385569642 : Closed e2262385569642 ∧ code e2262385569642 = 11058478591850 := by decide
theorem cert_e2262385569642 : check e2262385569642 [[],[.under]] .smaller = true := by decide
def e2262385570746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e2262385570746 : Closed e2262385570746 ∧ code e2262385570746 = 11058478592954 := by decide
theorem cert_e2262385570746 : check e2262385570746 [[],[.under]] .smaller = true := by decide
def e2262385570778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e2262385570778 : Closed e2262385570778 ∧ code e2262385570778 = 11058478592986 := by decide
theorem cert_e2262385570778 : check e2262385570778 [[],[.under]] .smaller = true := by decide
def e2262385572282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e2262385572282 : Closed e2262385572282 ∧ code e2262385572282 = 11058478594490 := by decide
theorem cert_e2262385572282 : check e2262385572282 [[],[.under]] .smaller = true := by decide
def e2262385572330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e2262385572330 : Closed e2262385572330 ∧ code e2262385572330 = 11058478594538 := by decide
theorem cert_e2262385572330 : check e2262385572330 [[],[.under]] .smaller = true := by decide
def e2262385573082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e2262385573082 : Closed e2262385573082 ∧ code e2262385573082 = 11058478595290 := by decide
theorem cert_e2262385573082 : check e2262385573082 [[],[.under]] .smaller = true := by decide
def e2262385573098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e2262385573098 : Closed e2262385573098 ∧ code e2262385573098 = 11058478595306 := by decide
theorem cert_e2262385573098 : check e2262385573098 [[],[.under]] .smaller = true := by decide
def e2262385604322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e2262385604322 : Closed e2262385604322 ∧ code e2262385604322 = 11058478626530 := by decide
theorem cert_e2262385604322 : check e2262385604322 [[],[.under]] .chain = true := by decide
def e2262385604450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e2262385604450 : Closed e2262385604450 ∧ code e2262385604450 = 11058478626658 := by decide
theorem cert_e2262385604450 : check e2262385604450 [[],[.under]] .chain = true := by decide
def e2262385605346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e2262385605346 : Closed e2262385605346 ∧ code e2262385605346 = 11058478627554 := by decide
theorem cert_e2262385605346 : check e2262385605346 [[],[.under]] .chain = true := by decide
def e2262385605538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e2262385605538 : Closed e2262385605538 ∧ code e2262385605538 = 11058478627746 := by decide
theorem cert_e2262385605538 : check e2262385605538 [[],[.under]] .chain = true := by decide
def e2262385605986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e2262385605986 : Closed e2262385605986 ∧ code e2262385605986 = 11058478628194 := by decide
theorem cert_e2262385605986 : check e2262385605986 [[],[.under]] .chain = true := by decide
def e2262385606050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e2262385606050 : Closed e2262385606050 ∧ code e2262385606050 = 11058478628258 := by decide
theorem cert_e2262385606050 : check e2262385606050 [[],[.under]] .chain = true := by decide
def e2262385610466 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0))))))
theorem wire_e2262385610466 : Closed e2262385610466 ∧ code e2262385610466 = 11058478632674 := by decide
theorem cert_e2262385610466 : check e2262385610466 [[],[.under]] .chain = true := by decide
def e2262385610594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0))))))
theorem wire_e2262385610594 : Closed e2262385610594 ∧ code e2262385610594 = 11058478632802 := by decide
theorem cert_e2262385610594 : check e2262385610594 [[],[.under]] .chain = true := by decide
def e2262385616610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0))))))
theorem wire_e2262385616610 : Closed e2262385616610 ∧ code e2262385616610 = 11058478638818 := by decide
theorem cert_e2262385616610 : check e2262385616610 [[],[.under]] .chain = true := by decide
def e2262385616802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0))))))
theorem wire_e2262385616802 : Closed e2262385616802 ∧ code e2262385616802 = 11058478639010 := by decide
theorem cert_e2262385616802 : check e2262385616802 [[],[.under]] .chain = true := by decide
def e2262385619810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0))))))
theorem wire_e2262385619810 : Closed e2262385619810 ∧ code e2262385619810 = 11058478642018 := by decide
theorem cert_e2262385619810 : check e2262385619810 [[],[.under]] .chain = true := by decide
def e2262385619874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0))))))
theorem wire_e2262385619874 : Closed e2262385619874 ∧ code e2262385619874 = 11058478642082 := by decide
theorem cert_e2262385619874 : check e2262385619874 [[],[.under]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262383266678
#print axioms Blc.Floor43.cert_e2262383266774
