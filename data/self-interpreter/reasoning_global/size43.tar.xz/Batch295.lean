import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411625690054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411625690054 : Closed e2411625690054 ∧ code e2411625690054 = 11207718712262 := by decide
theorem cert_e2411625690054 : check e2411625690054 [[],[]] .smaller = true := by decide
def e2411625690078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e2411625690078 : Closed e2411625690078 ∧ code e2411625690078 = 11207718712286 := by decide
theorem cert_e2411625690078 : check e2411625690078 [[],[]] .three = true := by decide
def e2411625690094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e2411625690094 : Closed e2411625690094 ∧ code e2411625690094 = 11207718712302 := by decide
theorem cert_e2411625690094 : check e2411625690094 [[],[]] .three = true := by decide
def e2411625691534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411625691534 : Closed e2411625691534 ∧ code e2411625691534 = 11207718713742 := by decide
theorem cert_e2411625691534 : check e2411625691534 [[],[]] .smaller = true := by decide
def e2411625691590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411625691590 : Closed e2411625691590 ∧ code e2411625691590 = 11207718713798 := by decide
theorem cert_e2411625691590 : check e2411625691590 [[],[]] .smaller = true := by decide
def e2411625691614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e2411625691614 : Closed e2411625691614 ∧ code e2411625691614 = 11207718713822 := by decide
theorem cert_e2411625691614 : check e2411625691614 [[],[]] .three = true := by decide
def e2411625691638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e2411625691638 : Closed e2411625691638 ∧ code e2411625691638 = 11207718713846 := by decide
theorem cert_e2411625691638 : check e2411625691638 [[],[]] .three = true := by decide
def e2411625692358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411625692358 : Closed e2411625692358 ∧ code e2411625692358 = 11207718714566 := by decide
theorem cert_e2411625692358 : check e2411625692358 [[],[]] .three = true := by decide
def e2411625692382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625692382 : Closed e2411625692382 ∧ code e2411625692382 = 11207718714590 := by decide
theorem cert_e2411625692382 : check e2411625692382 [[],[]] .three = true := by decide
def e2411625692398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625692398 : Closed e2411625692398 ∧ code e2411625692398 = 11207718714606 := by decide
theorem cert_e2411625692398 : check e2411625692398 [[],[]] .three = true := by decide
def e2411625692406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625692406 : Closed e2411625692406 ∧ code e2411625692406 = 11207718714614 := by decide
theorem cert_e2411625692406 : check e2411625692406 [[],[]] .three = true := by decide
def e2411625692410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625692410 : Closed e2411625692410 ∧ code e2411625692410 = 11207718714618 := by decide
theorem cert_e2411625692410 : check e2411625692410 [[],[]] .three = true := by decide
def e2411625694134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e2411625694134 : Closed e2411625694134 ∧ code e2411625694134 = 11207718716342 := by decide
theorem cert_e2411625694134 : check e2411625694134 [[],[]] .three = true := by decide
def e2411625694138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2411625694138 : Closed e2411625694138 ∧ code e2411625694138 = 11207718716346 := by decide
theorem cert_e2411625694138 : check e2411625694138 [[],[]] .three = true := by decide
def e2411625694170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2411625694170 : Closed e2411625694170 ∧ code e2411625694170 = 11207718716378 := by decide
theorem cert_e2411625694170 : check e2411625694170 [[],[]] .three = true := by decide
def e2411625694830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625694830 : Closed e2411625694830 ∧ code e2411625694830 = 11207718717038 := by decide
theorem cert_e2411625694830 : check e2411625694830 [[],[]] .three = true := by decide
def e2411625694838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e2411625694838 : Closed e2411625694838 ∧ code e2411625694838 = 11207718717046 := by decide
theorem cert_e2411625694838 : check e2411625694838 [[],[]] .three = true := by decide
def e2411625694842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625694842 : Closed e2411625694842 ∧ code e2411625694842 = 11207718717050 := by decide
theorem cert_e2411625694842 : check e2411625694842 [[],[]] .three = true := by decide
def e2411625695030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625695030 : Closed e2411625695030 ∧ code e2411625695030 = 11207718717238 := by decide
theorem cert_e2411625695030 : check e2411625695030 [[],[]] .three = true := by decide
def e2411625695034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625695034 : Closed e2411625695034 ∧ code e2411625695034 = 11207718717242 := by decide
theorem cert_e2411625695034 : check e2411625695034 [[],[]] .three = true := by decide
def e2411625695130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625695130 : Closed e2411625695130 ∧ code e2411625695130 = 11207718717338 := by decide
theorem cert_e2411625695130 : check e2411625695130 [[],[]] .three = true := by decide
def e2411625696086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2411625696086 : Closed e2411625696086 ∧ code e2411625696086 = 11207718718294 := by decide
theorem cert_e2411625696086 : check e2411625696086 [[],[]] .three = true := by decide
def e2411625696090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2411625696090 : Closed e2411625696090 ∧ code e2411625696090 = 11207718718298 := by decide
theorem cert_e2411625696090 : check e2411625696090 [[],[]] .three = true := by decide
def e2411625696106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2411625696106 : Closed e2411625696106 ∧ code e2411625696106 = 11207718718314 := by decide
theorem cert_e2411625696106 : check e2411625696106 [[],[]] .three = true := by decide
def e2411625696170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2411625696170 : Closed e2411625696170 ∧ code e2411625696170 = 11207718718378 := by decide
theorem cert_e2411625696170 : check e2411625696170 [[],[]] .three = true := by decide
def e2411625696366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411625696366 : Closed e2411625696366 ∧ code e2411625696366 = 11207718718574 := by decide
theorem cert_e2411625696366 : check e2411625696366 [[],[]] .three = true := by decide
def e2411625696374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2411625696374 : Closed e2411625696374 ∧ code e2411625696374 = 11207718718582 := by decide
theorem cert_e2411625696374 : check e2411625696374 [[],[]] .three = true := by decide
def e2411625696378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411625696378 : Closed e2411625696378 ∧ code e2411625696378 = 11207718718586 := by decide
theorem cert_e2411625696378 : check e2411625696378 [[],[]] .three = true := by decide
def e2411625696470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2411625696470 : Closed e2411625696470 ∧ code e2411625696470 = 11207718718678 := by decide
theorem cert_e2411625696470 : check e2411625696470 [[],[]] .three = true := by decide
def e2411625696474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2411625696474 : Closed e2411625696474 ∧ code e2411625696474 = 11207718718682 := by decide
theorem cert_e2411625696474 : check e2411625696474 [[],[]] .three = true := by decide
def e2411625696490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2411625696490 : Closed e2411625696490 ∧ code e2411625696490 = 11207718718698 := by decide
theorem cert_e2411625696490 : check e2411625696490 [[],[]] .three = true := by decide
def e2411625696542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411625696542 : Closed e2411625696542 ∧ code e2411625696542 = 11207718718750 := by decide
theorem cert_e2411625696542 : check e2411625696542 [[],[]] .three = true := by decide
def e2411625696566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411625696566 : Closed e2411625696566 ∧ code e2411625696566 = 11207718718774 := by decide
theorem cert_e2411625696566 : check e2411625696566 [[],[]] .three = true := by decide
def e2411625696570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411625696570 : Closed e2411625696570 ∧ code e2411625696570 = 11207718718778 := by decide
theorem cert_e2411625696570 : check e2411625696570 [[],[]] .three = true := by decide
def e2411625696654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2411625696654 : Closed e2411625696654 ∧ code e2411625696654 = 11207718718862 := by decide
theorem cert_e2411625696654 : check e2411625696654 [[],[]] .three = true := by decide
def e2411625696666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625696666 : Closed e2411625696666 ∧ code e2411625696666 = 11207718718874 := by decide
theorem cert_e2411625696666 : check e2411625696666 [[],[]] .three = true := by decide
def e2411625696710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411625696710 : Closed e2411625696710 ∧ code e2411625696710 = 11207718718918 := by decide
theorem cert_e2411625696710 : check e2411625696710 [[],[]] .three = true := by decide
def e2411625696734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2411625696734 : Closed e2411625696734 ∧ code e2411625696734 = 11207718718942 := by decide
theorem cert_e2411625696734 : check e2411625696734 [[],[]] .three = true := by decide
def e2411625696750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2411625696750 : Closed e2411625696750 ∧ code e2411625696750 = 11207718718958 := by decide
theorem cert_e2411625696750 : check e2411625696750 [[],[]] .three = true := by decide
def e2411625696822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411625696822 : Closed e2411625696822 ∧ code e2411625696822 = 11207718719030 := by decide
theorem cert_e2411625696822 : check e2411625696822 [[],[]] .three = true := by decide
def e2411625696826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411625696826 : Closed e2411625696826 ∧ code e2411625696826 = 11207718719034 := by decide
theorem cert_e2411625696826 : check e2411625696826 [[],[]] .three = true := by decide
def e2411625696874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2411625696874 : Closed e2411625696874 ∧ code e2411625696874 = 11207718719082 := by decide
theorem cert_e2411625696874 : check e2411625696874 [[],[]] .three = true := by decide
def e2411625696910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411625696910 : Closed e2411625696910 ∧ code e2411625696910 = 11207718719118 := by decide
theorem cert_e2411625696910 : check e2411625696910 [[],[]] .three = true := by decide
def e2411625696922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411625696922 : Closed e2411625696922 ∧ code e2411625696922 = 11207718719130 := by decide
theorem cert_e2411625696922 : check e2411625696922 [[],[]] .three = true := by decide
def e2411625696966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411625696966 : Closed e2411625696966 ∧ code e2411625696966 = 11207718719174 := by decide
theorem cert_e2411625696966 : check e2411625696966 [[],[]] .three = true := by decide
def e2411625697006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2411625697006 : Closed e2411625697006 ∧ code e2411625697006 = 11207718719214 := by decide
theorem cert_e2411625697006 : check e2411625697006 [[],[]] .three = true := by decide
def e2411625697050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411625697050 : Closed e2411625697050 ∧ code e2411625697050 = 11207718719258 := by decide
theorem cert_e2411625697050 : check e2411625697050 [[],[]] .three = true := by decide
def e2411625697094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411625697094 : Closed e2411625697094 ∧ code e2411625697094 = 11207718719302 := by decide
theorem cert_e2411625697094 : check e2411625697094 [[],[]] .three = true := by decide
def e2411625697118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2411625697118 : Closed e2411625697118 ∧ code e2411625697118 = 11207718719326 := by decide
theorem cert_e2411625697118 : check e2411625697118 [[],[]] .three = true := by decide
def e2411625697134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2411625697134 : Closed e2411625697134 ∧ code e2411625697134 = 11207718719342 := by decide
theorem cert_e2411625697134 : check e2411625697134 [[],[]] .three = true := by decide
def e2411625697142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2411625697142 : Closed e2411625697142 ∧ code e2411625697142 = 11207718719350 := by decide
theorem cert_e2411625697142 : check e2411625697142 [[],[]] .three = true := by decide
def e2411625697146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2411625697146 : Closed e2411625697146 ∧ code e2411625697146 = 11207718719354 := by decide
theorem cert_e2411625697146 : check e2411625697146 [[],[]] .three = true := by decide
def e2411625697198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2411625697198 : Closed e2411625697198 ∧ code e2411625697198 = 11207718719406 := by decide
theorem cert_e2411625697198 : check e2411625697198 [[],[]] .three = true := by decide
def e2411625697210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2411625697210 : Closed e2411625697210 ∧ code e2411625697210 = 11207718719418 := by decide
theorem cert_e2411625697210 : check e2411625697210 [[],[]] .three = true := by decide
def e2411625697518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2411625697518 : Closed e2411625697518 ∧ code e2411625697518 = 11207718719726 := by decide
theorem cert_e2411625697518 : check e2411625697518 [[],[]] .three = true := by decide
def e2411625697526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2411625697526 : Closed e2411625697526 ∧ code e2411625697526 = 11207718719734 := by decide
theorem cert_e2411625697526 : check e2411625697526 [[],[]] .three = true := by decide
def e2411625698006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2411625698006 : Closed e2411625698006 ∧ code e2411625698006 = 11207718720214 := by decide
theorem cert_e2411625698006 : check e2411625698006 [[],[]] .three = true := by decide
def e2411625698010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2411625698010 : Closed e2411625698010 ∧ code e2411625698010 = 11207718720218 := by decide
theorem cert_e2411625698010 : check e2411625698010 [[],[]] .three = true := by decide
def e2411625698026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2411625698026 : Closed e2411625698026 ∧ code e2411625698026 = 11207718720234 := by decide
theorem cert_e2411625698026 : check e2411625698026 [[],[]] .three = true := by decide
def e2411625698078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411625698078 : Closed e2411625698078 ∧ code e2411625698078 = 11207718720286 := by decide
theorem cert_e2411625698078 : check e2411625698078 [[],[]] .three = true := by decide
def e2411625698102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625698102 : Closed e2411625698102 ∧ code e2411625698102 = 11207718720310 := by decide
theorem cert_e2411625698102 : check e2411625698102 [[],[]] .three = true := by decide
def e2411625698106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625698106 : Closed e2411625698106 ∧ code e2411625698106 = 11207718720314 := by decide
theorem cert_e2411625698106 : check e2411625698106 [[],[]] .three = true := by decide
def e2411625698190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2411625698190 : Closed e2411625698190 ∧ code e2411625698190 = 11207718720398 := by decide
theorem cert_e2411625698190 : check e2411625698190 [[],[]] .three = true := by decide
def e2411625698202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625698202 : Closed e2411625698202 ∧ code e2411625698202 = 11207718720410 := by decide
theorem cert_e2411625698202 : check e2411625698202 [[],[]] .three = true := by decide
def e2411625698246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411625698246 : Closed e2411625698246 ∧ code e2411625698246 = 11207718720454 := by decide
theorem cert_e2411625698246 : check e2411625698246 [[],[]] .three = true := by decide
def e2411625698270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2411625698270 : Closed e2411625698270 ∧ code e2411625698270 = 11207718720478 := by decide
theorem cert_e2411625698270 : check e2411625698270 [[],[]] .three = true := by decide
def e2411625698286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2411625698286 : Closed e2411625698286 ∧ code e2411625698286 = 11207718720494 := by decide
theorem cert_e2411625698286 : check e2411625698286 [[],[]] .three = true := by decide
def e2411625699446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2411625699446 : Closed e2411625699446 ∧ code e2411625699446 = 11207718721654 := by decide
theorem cert_e2411625699446 : check e2411625699446 [[],[]] .three = true := by decide
def e2411625699690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2411625699690 : Closed e2411625699690 ∧ code e2411625699690 = 11207718721898 := by decide
theorem cert_e2411625699690 : check e2411625699690 [[],[]] .three = true := by decide
def e2411625699726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411625699726 : Closed e2411625699726 ∧ code e2411625699726 = 11207718721934 := by decide
theorem cert_e2411625699726 : check e2411625699726 [[],[]] .three = true := by decide
def e2411625699738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411625699738 : Closed e2411625699738 ∧ code e2411625699738 = 11207718721946 := by decide
theorem cert_e2411625699738 : check e2411625699738 [[],[]] .three = true := by decide
def e2411625699782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411625699782 : Closed e2411625699782 ∧ code e2411625699782 = 11207718721990 := by decide
theorem cert_e2411625699782 : check e2411625699782 [[],[]] .three = true := by decide
def e2411625699822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2411625699822 : Closed e2411625699822 ∧ code e2411625699822 = 11207718722030 := by decide
theorem cert_e2411625699822 : check e2411625699822 [[],[]] .three = true := by decide
def e2411625700550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411625700550 : Closed e2411625700550 ∧ code e2411625700550 = 11207718722758 := by decide
theorem cert_e2411625700550 : check e2411625700550 [[],[]] .three = true := by decide
def e2411625700574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2411625700574 : Closed e2411625700574 ∧ code e2411625700574 = 11207718722782 := by decide
theorem cert_e2411625700574 : check e2411625700574 [[],[]] .three = true := by decide
def e2411625700590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411625700590 : Closed e2411625700590 ∧ code e2411625700590 = 11207718722798 := by decide
theorem cert_e2411625700590 : check e2411625700590 [[],[]] .three = true := by decide
def e2411625700598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411625700598 : Closed e2411625700598 ∧ code e2411625700598 = 11207718722806 := by decide
theorem cert_e2411625700598 : check e2411625700598 [[],[]] .three = true := by decide
def e2411625700602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2411625700602 : Closed e2411625700602 ∧ code e2411625700602 = 11207718722810 := by decide
theorem cert_e2411625700602 : check e2411625700602 [[],[]] .three = true := by decide
def e2411625700974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2411625700974 : Closed e2411625700974 ∧ code e2411625700974 = 11207718723182 := by decide
theorem cert_e2411625700974 : check e2411625700974 [[],[]] .three = true := by decide
def e2411625700986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2411625700986 : Closed e2411625700986 ∧ code e2411625700986 = 11207718723194 := by decide
theorem cert_e2411625700986 : check e2411625700986 [[],[]] .three = true := by decide
def e2411625732334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2411625732334 : Closed e2411625732334 ∧ code e2411625732334 = 11207718754542 := by decide
theorem cert_e2411625732334 : check e2411625732334 [[],[]] .smaller = true := by decide
def e2411625732342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2411625732342 : Closed e2411625732342 ∧ code e2411625732342 = 11207718754550 := by decide
theorem cert_e2411625732342 : check e2411625732342 [[],[]] .smaller = true := by decide
def e2411625732894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2411625732894 : Closed e2411625732894 ∧ code e2411625732894 = 11207718755102 := by decide
theorem cert_e2411625732894 : check e2411625732894 [[],[]] .smaller = true := by decide
def e2411625733006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2411625733006 : Closed e2411625733006 ∧ code e2411625733006 = 11207718755214 := by decide
theorem cert_e2411625733006 : check e2411625733006 [[],[]] .smaller = true := by decide
def e2411625733230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2411625733230 : Closed e2411625733230 ∧ code e2411625733230 = 11207718755438 := by decide
theorem cert_e2411625733230 : check e2411625733230 [[],[]] .smaller = true := by decide
def e2411625733242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2411625733242 : Closed e2411625733242 ∧ code e2411625733242 = 11207718755450 := by decide
theorem cert_e2411625733242 : check e2411625733242 [[],[]] .smaller = true := by decide
def e2411625733406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2411625733406 : Closed e2411625733406 ∧ code e2411625733406 = 11207718755614 := by decide
theorem cert_e2411625733406 : check e2411625733406 [[],[]] .smaller = true := by decide
def e2411625733574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2411625733574 : Closed e2411625733574 ∧ code e2411625733574 = 11207718755782 := by decide
theorem cert_e2411625733574 : check e2411625733574 [[],[]] .smaller = true := by decide
def e2411625733598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e2411625733598 : Closed e2411625733598 ∧ code e2411625733598 = 11207718755806 := by decide
theorem cert_e2411625733598 : check e2411625733598 [[],[]] .smaller = true := by decide
def e2411625733614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e2411625733614 : Closed e2411625733614 ∧ code e2411625733614 = 11207718755822 := by decide
theorem cert_e2411625733614 : check e2411625733614 [[],[]] .smaller = true := by decide
def e2411625733686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2411625733686 : Closed e2411625733686 ∧ code e2411625733686 = 11207718755894 := by decide
theorem cert_e2411625733686 : check e2411625733686 [[],[]] .smaller = true := by decide
def e2411625733690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2411625733690 : Closed e2411625733690 ∧ code e2411625733690 = 11207718755898 := by decide
theorem cert_e2411625733690 : check e2411625733690 [[],[]] .smaller = true := by decide
def e2411625733774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2411625733774 : Closed e2411625733774 ∧ code e2411625733774 = 11207718755982 := by decide
theorem cert_e2411625733774 : check e2411625733774 [[],[]] .smaller = true := by decide
def e2411625733830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2411625733830 : Closed e2411625733830 ∧ code e2411625733830 = 11207718756038 := by decide
theorem cert_e2411625733830 : check e2411625733830 [[],[]] .smaller = true := by decide
def e2411625733854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e2411625733854 : Closed e2411625733854 ∧ code e2411625733854 = 11207718756062 := by decide
theorem cert_e2411625733854 : check e2411625733854 [[],[]] .smaller = true := by decide
def e2411625733878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e2411625733878 : Closed e2411625733878 ∧ code e2411625733878 = 11207718756086 := by decide
theorem cert_e2411625733878 : check e2411625733878 [[],[]] .smaller = true := by decide
def e2411625733998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e2411625733998 : Closed e2411625733998 ∧ code e2411625733998 = 11207718756206 := by decide
theorem cert_e2411625733998 : check e2411625733998 [[],[]] .smaller = true := by decide
def e2411625734006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e2411625734006 : Closed e2411625734006 ∧ code e2411625734006 = 11207718756214 := by decide
theorem cert_e2411625734006 : check e2411625734006 [[],[]] .smaller = true := by decide
def e2411625735966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2411625735966 : Closed e2411625735966 ∧ code e2411625735966 = 11207718758174 := by decide
theorem cert_e2411625735966 : check e2411625735966 [[],[]] .smaller = true := by decide
def e2411625736078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2411625736078 : Closed e2411625736078 ∧ code e2411625736078 = 11207718758286 := by decide
theorem cert_e2411625736078 : check e2411625736078 [[],[]] .smaller = true := by decide
def e2411625739038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2411625739038 : Closed e2411625739038 ∧ code e2411625739038 = 11207718761246 := by decide
theorem cert_e2411625739038 : check e2411625739038 [[],[]] .smaller = true := by decide
def e2411625739206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2411625739206 : Closed e2411625739206 ∧ code e2411625739206 = 11207718761414 := by decide
theorem cert_e2411625739206 : check e2411625739206 [[],[]] .smaller = true := by decide
def e2411625739230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e2411625739230 : Closed e2411625739230 ∧ code e2411625739230 = 11207718761438 := by decide
theorem cert_e2411625739230 : check e2411625739230 [[],[]] .smaller = true := by decide
def e2411625739246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e2411625739246 : Closed e2411625739246 ∧ code e2411625739246 = 11207718761454 := by decide
theorem cert_e2411625739246 : check e2411625739246 [[],[]] .smaller = true := by decide
def e2411625740686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2411625740686 : Closed e2411625740686 ∧ code e2411625740686 = 11207718762894 := by decide
theorem cert_e2411625740686 : check e2411625740686 [[],[]] .smaller = true := by decide
def e2411625740742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2411625740742 : Closed e2411625740742 ∧ code e2411625740742 = 11207718762950 := by decide
theorem cert_e2411625740742 : check e2411625740742 [[],[]] .smaller = true := by decide
def e2411625740766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411625740766 : Closed e2411625740766 ∧ code e2411625740766 = 11207718762974 := by decide
theorem cert_e2411625740766 : check e2411625740766 [[],[]] .smaller = true := by decide
def e2411625740790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411625740790 : Closed e2411625740790 ∧ code e2411625740790 = 11207718762998 := by decide
theorem cert_e2411625740790 : check e2411625740790 [[],[]] .smaller = true := by decide
def e2411625741550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411625741550 : Closed e2411625741550 ∧ code e2411625741550 = 11207718763758 := by decide
theorem cert_e2411625741550 : check e2411625741550 [[],[]] .smaller = true := by decide
def e2411625741558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411625741558 : Closed e2411625741558 ∧ code e2411625741558 = 11207718763766 := by decide
theorem cert_e2411625741558 : check e2411625741558 [[],[]] .smaller = true := by decide
def e2411625798366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2411625798366 : Closed e2411625798366 ∧ code e2411625798366 = 11207718820574 := by decide
theorem cert_e2411625798366 : check e2411625798366 [[],[]] .three = true := by decide
def e2411625798390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2411625798390 : Closed e2411625798390 ∧ code e2411625798390 = 11207718820598 := by decide
theorem cert_e2411625798390 : check e2411625798390 [[],[]] .three = true := by decide
def e2411625798494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2411625798494 : Closed e2411625798494 ∧ code e2411625798494 = 11207718820702 := by decide
theorem cert_e2411625798494 : check e2411625798494 [[],[]] .three = true := by decide
def e2411625798510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e2411625798510 : Closed e2411625798510 ∧ code e2411625798510 = 11207718820718 := by decide
theorem cert_e2411625798510 : check e2411625798510 [[],[]] .smaller = true := by decide
def e2411625798518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e2411625798518 : Closed e2411625798518 ∧ code e2411625798518 = 11207718820726 := by decide
theorem cert_e2411625798518 : check e2411625798518 [[],[]] .smaller = true := by decide
def e2411625798522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2411625798522 : Closed e2411625798522 ∧ code e2411625798522 = 11207718820730 := by decide
theorem cert_e2411625798522 : check e2411625798522 [[],[]] .three = true := by decide
def e2411625798582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e2411625798582 : Closed e2411625798582 ∧ code e2411625798582 = 11207718820790 := by decide
theorem cert_e2411625798582 : check e2411625798582 [[],[]] .smaller = true := by decide
def e2411625798614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2411625798614 : Closed e2411625798614 ∧ code e2411625798614 = 11207718820822 := by decide
theorem cert_e2411625798614 : check e2411625798614 [[],[]] .three = true := by decide
def e2411625798618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2411625798618 : Closed e2411625798618 ∧ code e2411625798618 = 11207718820826 := by decide
theorem cert_e2411625798618 : check e2411625798618 [[],[]] .three = true := by decide
def e2411625799006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2411625799006 : Closed e2411625799006 ∧ code e2411625799006 = 11207718821214 := by decide
theorem cert_e2411625799006 : check e2411625799006 [[],[]] .three = true := by decide
def e2411625799022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2411625799022 : Closed e2411625799022 ∧ code e2411625799022 = 11207718821230 := by decide
theorem cert_e2411625799022 : check e2411625799022 [[],[]] .smaller = true := by decide
def e2411625799030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2411625799030 : Closed e2411625799030 ∧ code e2411625799030 = 11207718821238 := by decide
theorem cert_e2411625799030 : check e2411625799030 [[],[]] .smaller = true := by decide
def e2411625799034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2411625799034 : Closed e2411625799034 ∧ code e2411625799034 = 11207718821242 := by decide
theorem cert_e2411625799034 : check e2411625799034 [[],[]] .three = true := by decide
def e2411625799086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2411625799086 : Closed e2411625799086 ∧ code e2411625799086 = 11207718821294 := by decide
theorem cert_e2411625799086 : check e2411625799086 [[],[]] .smaller = true := by decide
def e2411625799098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2411625799098 : Closed e2411625799098 ∧ code e2411625799098 = 11207718821306 := by decide
theorem cert_e2411625799098 : check e2411625799098 [[],[]] .smaller = true := by decide
def e2411625799126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2411625799126 : Closed e2411625799126 ∧ code e2411625799126 = 11207718821334 := by decide
theorem cert_e2411625799126 : check e2411625799126 [[],[]] .smaller = true := by decide
def e2411625799130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2411625799130 : Closed e2411625799130 ∧ code e2411625799130 = 11207718821338 := by decide
theorem cert_e2411625799130 : check e2411625799130 [[],[]] .smaller = true := by decide
def e2411625799146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2411625799146 : Closed e2411625799146 ∧ code e2411625799146 = 11207718821354 := by decide
theorem cert_e2411625799146 : check e2411625799146 [[],[]] .three = true := by decide
def e2411625799350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2411625799350 : Closed e2411625799350 ∧ code e2411625799350 = 11207718821558 := by decide
theorem cert_e2411625799350 : check e2411625799350 [[],[]] .smaller = true := by decide
def e2411625799382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2411625799382 : Closed e2411625799382 ∧ code e2411625799382 = 11207718821590 := by decide
theorem cert_e2411625799382 : check e2411625799382 [[],[]] .smaller = true := by decide
def e2411625799386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2411625799386 : Closed e2411625799386 ∧ code e2411625799386 = 11207718821594 := by decide
theorem cert_e2411625799386 : check e2411625799386 [[],[]] .smaller = true := by decide
def e2411625799510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2411625799510 : Closed e2411625799510 ∧ code e2411625799510 = 11207718821718 := by decide
theorem cert_e2411625799510 : check e2411625799510 [[],[]] .three = true := by decide
def e2411625799514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2411625799514 : Closed e2411625799514 ∧ code e2411625799514 = 11207718821722 := by decide
theorem cert_e2411625799514 : check e2411625799514 [[],[]] .three = true := by decide
def e2411625799530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2411625799530 : Closed e2411625799530 ∧ code e2411625799530 = 11207718821738 := by decide
theorem cert_e2411625799530 : check e2411625799530 [[],[]] .three = true := by decide
def e2411625800670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))))
theorem wire_e2411625800670 : Closed e2411625800670 ∧ code e2411625800670 = 11207718822878 := by decide
theorem cert_e2411625800670 : check e2411625800670 [[],[]] .three = true := by decide
def e2411625800686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 2))))))))
theorem wire_e2411625800686 : Closed e2411625800686 ∧ code e2411625800686 = 11207718822894 := by decide
theorem cert_e2411625800686 : check e2411625800686 [[],[]] .three = true := by decide
def e2411625801438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2411625801438 : Closed e2411625801438 ∧ code e2411625801438 = 11207718823646 := by decide
theorem cert_e2411625801438 : check e2411625801438 [[],[]] .three = true := by decide
def e2411625801462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2411625801462 : Closed e2411625801462 ∧ code e2411625801462 = 11207718823670 := by decide
theorem cert_e2411625801462 : check e2411625801462 [[],[]] .three = true := by decide
def e2411625801566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2411625801566 : Closed e2411625801566 ∧ code e2411625801566 = 11207718823774 := by decide
theorem cert_e2411625801566 : check e2411625801566 [[],[]] .three = true := by decide
def e2411625801582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e2411625801582 : Closed e2411625801582 ∧ code e2411625801582 = 11207718823790 := by decide
theorem cert_e2411625801582 : check e2411625801582 [[],[]] .smaller = true := by decide
def e2411625801590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e2411625801590 : Closed e2411625801590 ∧ code e2411625801590 = 11207718823798 := by decide
theorem cert_e2411625801590 : check e2411625801590 [[],[]] .smaller = true := by decide
def e2411625801594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2411625801594 : Closed e2411625801594 ∧ code e2411625801594 = 11207718823802 := by decide
theorem cert_e2411625801594 : check e2411625801594 [[],[]] .three = true := by decide
def e2411625801654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e2411625801654 : Closed e2411625801654 ∧ code e2411625801654 = 11207718823862 := by decide
theorem cert_e2411625801654 : check e2411625801654 [[],[]] .smaller = true := by decide
def e2411625801686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2411625801686 : Closed e2411625801686 ∧ code e2411625801686 = 11207718823894 := by decide
theorem cert_e2411625801686 : check e2411625801686 [[],[]] .three = true := by decide
def e2411625801690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2411625801690 : Closed e2411625801690 ∧ code e2411625801690 = 11207718823898 := by decide
theorem cert_e2411625801690 : check e2411625801690 [[],[]] .three = true := by decide
def e2411625802206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411625802206 : Closed e2411625802206 ∧ code e2411625802206 = 11207718824414 := by decide
theorem cert_e2411625802206 : check e2411625802206 [[],[]] .three = true := by decide
def e2411625802230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411625802230 : Closed e2411625802230 ∧ code e2411625802230 = 11207718824438 := by decide
theorem cert_e2411625802230 : check e2411625802230 [[],[]] .three = true := by decide
def e2411625802974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411625802974 : Closed e2411625802974 ∧ code e2411625802974 = 11207718825182 := by decide
theorem cert_e2411625802974 : check e2411625802974 [[],[]] .three = true := by decide
def e2411625802990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411625802990 : Closed e2411625802990 ∧ code e2411625802990 = 11207718825198 := by decide
theorem cert_e2411625802990 : check e2411625802990 [[],[]] .smaller = true := by decide
def e2411625802998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411625802998 : Closed e2411625802998 ∧ code e2411625802998 = 11207718825206 := by decide
theorem cert_e2411625802998 : check e2411625802998 [[],[]] .smaller = true := by decide
def e2411625803002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411625803002 : Closed e2411625803002 ∧ code e2411625803002 = 11207718825210 := by decide
theorem cert_e2411625803002 : check e2411625803002 [[],[]] .three = true := by decide
def e2411625803326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e2411625803326 : Closed e2411625803326 ∧ code e2411625803326 = 11207718825534 := by decide
theorem cert_e2411625803326 : check e2411625803326 [[],[]] .three = true := by decide
def e2411625803382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411625803382 : Closed e2411625803382 ∧ code e2411625803382 = 11207718825590 := by decide
theorem cert_e2411625803382 : check e2411625803382 [[],[]] .smaller = true := by decide
def e2411625803550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e2411625803550 : Closed e2411625803550 ∧ code e2411625803550 = 11207718825758 := by decide
theorem cert_e2411625803550 : check e2411625803550 [[],[]] .three = true := by decide
def e2411625803574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411625803574 : Closed e2411625803574 ∧ code e2411625803574 = 11207718825782 := by decide
theorem cert_e2411625803574 : check e2411625803574 [[],[]] .three = true := by decide
def e2411625803578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411625803578 : Closed e2411625803578 ∧ code e2411625803578 = 11207718825786 := by decide
theorem cert_e2411625803578 : check e2411625803578 [[],[]] .three = true := by decide
def e2411625804254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2411625804254 : Closed e2411625804254 ∧ code e2411625804254 = 11207718826462 := by decide
theorem cert_e2411625804254 : check e2411625804254 [[],[]] .three = true := by decide
def e2411625804270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 2))))))))
theorem wire_e2411625804270 : Closed e2411625804270 ∧ code e2411625804270 = 11207718826478 := by decide
theorem cert_e2411625804270 : check e2411625804270 [[],[]] .smaller = true := by decide
def e2411625804278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2411625804278 : Closed e2411625804278 ∧ code e2411625804278 = 11207718826486 := by decide
theorem cert_e2411625804278 : check e2411625804278 [[],[]] .three = true := by decide
def e2411625804638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2411625804638 : Closed e2411625804638 ∧ code e2411625804638 = 11207718826846 := by decide
theorem cert_e2411625804638 : check e2411625804638 [[],[]] .three = true := by decide
end Blc.Floor43
