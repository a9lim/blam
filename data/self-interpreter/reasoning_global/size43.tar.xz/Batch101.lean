import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e836499454586 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e836499454586 : Closed e836499454586 ∧ code e836499454586 = 9632592476794 := by decide
theorem cert_e836499454586 : check e836499454586 [] .sourceHead = true := by decide
def e836499454874 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e836499454874 : Closed e836499454874 ∧ code e836499454874 = 9632592477082 := by decide
theorem cert_e836499454874 : check e836499454874 [] .sourceHead = true := by decide
def e836499455190 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e836499455190 : Closed e836499455190 ∧ code e836499455190 = 9632592477398 := by decide
theorem cert_e836499455190 : check e836499455190 [] .sourceHead = true := by decide
def e836499455194 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e836499455194 : Closed e836499455194 ∧ code e836499455194 = 9632592477402 := by decide
theorem cert_e836499455194 : check e836499455194 [] .sourceHead = true := by decide
def e836499455210 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e836499455210 : Closed e836499455210 ∧ code e836499455210 = 9632592477418 := by decide
theorem cert_e836499455210 : check e836499455210 [] .sourceHead = true := by decide
def e836499455286 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e836499455286 : Closed e836499455286 ∧ code e836499455286 = 9632592477494 := by decide
theorem cert_e836499455286 : check e836499455286 [] .sourceHead = true := by decide
def e836499455290 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e836499455290 : Closed e836499455290 ∧ code e836499455290 = 9632592477498 := by decide
theorem cert_e836499455290 : check e836499455290 [] .sourceHead = true := by decide
def e836499455386 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e836499455386 : Closed e836499455386 ∧ code e836499455386 = 9632592477594 := by decide
theorem cert_e836499455386 : check e836499455386 [] .sourceHead = true := by decide
def e836499458926 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e836499458926 : Closed e836499458926 ∧ code e836499458926 = 9632592481134 := by decide
theorem cert_e836499458926 : check e836499458926 [] .sourceHead = true := by decide
def e836499458934 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e836499458934 : Closed e836499458934 ∧ code e836499458934 = 9632592481142 := by decide
theorem cert_e836499458934 : check e836499458934 [] .sourceHead = true := by decide
def e836499458990 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e836499458990 : Closed e836499458990 ∧ code e836499458990 = 9632592481198 := by decide
theorem cert_e836499458990 : check e836499458990 [] .sourceHead = true := by decide
def e836499459002 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e836499459002 : Closed e836499459002 ∧ code e836499459002 = 9632592481210 := by decide
theorem cert_e836499459002 : check e836499459002 [] .sourceHead = true := by decide
def e836499459030 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e836499459030 : Closed e836499459030 ∧ code e836499459030 = 9632592481238 := by decide
theorem cert_e836499459030 : check e836499459030 [] .sourceHead = true := by decide
def e836499459034 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e836499459034 : Closed e836499459034 ∧ code e836499459034 = 9632592481242 := by decide
theorem cert_e836499459034 : check e836499459034 [] .sourceHead = true := by decide
def e836499459310 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e836499459310 : Closed e836499459310 ∧ code e836499459310 = 9632592481518 := by decide
theorem cert_e836499459310 : check e836499459310 [] .sourceHead = true := by decide
def e836499459318 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e836499459318 : Closed e836499459318 ∧ code e836499459318 = 9632592481526 := by decide
theorem cert_e836499459318 : check e836499459318 [] .sourceHead = true := by decide
def e836499459694 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e836499459694 : Closed e836499459694 ∧ code e836499459694 = 9632592481902 := by decide
theorem cert_e836499459694 : check e836499459694 [] .sourceHead = true := by decide
def e836499459706 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e836499459706 : Closed e836499459706 ∧ code e836499459706 = 9632592481914 := by decide
theorem cert_e836499459706 : check e836499459706 [] .sourceHead = true := by decide
def e836499459894 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e836499459894 : Closed e836499459894 ∧ code e836499459894 = 9632592482102 := by decide
theorem cert_e836499459894 : check e836499459894 [] .sourceHead = true := by decide
def e836499459898 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e836499459898 : Closed e836499459898 ∧ code e836499459898 = 9632592482106 := by decide
theorem cert_e836499459898 : check e836499459898 [] .sourceHead = true := by decide
def e836499465646 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e836499465646 : Closed e836499465646 ∧ code e836499465646 = 9632592487854 := by decide
theorem cert_e836499465646 : check e836499465646 [] .sourceHead = true := by decide
def e836499465658 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e836499465658 : Closed e836499465658 ∧ code e836499465658 = 9632592487866 := by decide
theorem cert_e836499465658 : check e836499465658 [] .sourceHead = true := by decide
def e836499465706 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e836499465706 : Closed e836499465706 ∧ code e836499465706 = 9632592487914 := by decide
theorem cert_e836499465706 : check e836499465706 [] .sourceHead = true := by decide
def e836499465838 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e836499465838 : Closed e836499465838 ∧ code e836499465838 = 9632592488046 := by decide
theorem cert_e836499465838 : check e836499465838 [] .sourceHead = true := by decide
def e836499465850 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e836499465850 : Closed e836499465850 ∧ code e836499465850 = 9632592488058 := by decide
theorem cert_e836499465850 : check e836499465850 [] .sourceHead = true := by decide
def e836499466138 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e836499466138 : Closed e836499466138 ∧ code e836499466138 = 9632592488346 := by decide
theorem cert_e836499466138 : check e836499466138 [] .sourceHead = true := by decide
def e836499469014 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e836499469014 : Closed e836499469014 ∧ code e836499469014 = 9632592491222 := by decide
theorem cert_e836499469014 : check e836499469014 [] .sourceHead = true := by decide
def e836499469018 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e836499469018 : Closed e836499469018 ∧ code e836499469018 = 9632592491226 := by decide
theorem cert_e836499469018 : check e836499469018 [] .sourceHead = true := by decide
def e836499469034 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e836499469034 : Closed e836499469034 ∧ code e836499469034 = 9632592491242 := by decide
theorem cert_e836499469034 : check e836499469034 [] .sourceHead = true := by decide
def e836499469110 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e836499469110 : Closed e836499469110 ∧ code e836499469110 = 9632592491318 := by decide
theorem cert_e836499469110 : check e836499469110 [] .sourceHead = true := by decide
def e836499469114 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e836499469114 : Closed e836499469114 ∧ code e836499469114 = 9632592491322 := by decide
theorem cert_e836499469114 : check e836499469114 [] .sourceHead = true := by decide
def e836499469210 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e836499469210 : Closed e836499469210 ∧ code e836499469210 = 9632592491418 := by decide
theorem cert_e836499469210 : check e836499469210 [] .sourceHead = true := by decide
def e836499606382 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e836499606382 : Closed e836499606382 ∧ code e836499606382 = 9632592628590 := by decide
theorem cert_e836499606382 : check e836499606382 [] .sourceHead = true := by decide
def e836499606390 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e836499606390 : Closed e836499606390 ∧ code e836499606390 = 9632592628598 := by decide
theorem cert_e836499606390 : check e836499606390 [] .sourceHead = true := by decide
def e836499606446 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e836499606446 : Closed e836499606446 ∧ code e836499606446 = 9632592628654 := by decide
theorem cert_e836499606446 : check e836499606446 [] .sourceHead = true := by decide
def e836499606458 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e836499606458 : Closed e836499606458 ∧ code e836499606458 = 9632592628666 := by decide
theorem cert_e836499606458 : check e836499606458 [] .sourceHead = true := by decide
def e836499606486 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e836499606486 : Closed e836499606486 ∧ code e836499606486 = 9632592628694 := by decide
theorem cert_e836499606486 : check e836499606486 [] .sourceHead = true := by decide
def e836499606490 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e836499606490 : Closed e836499606490 ∧ code e836499606490 = 9632592628698 := by decide
theorem cert_e836499606490 : check e836499606490 [] .sourceHead = true := by decide
def e836499606766 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e836499606766 : Closed e836499606766 ∧ code e836499606766 = 9632592628974 := by decide
theorem cert_e836499606766 : check e836499606766 [] .sourceHead = true := by decide
def e836499606774 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e836499606774 : Closed e836499606774 ∧ code e836499606774 = 9632592628982 := by decide
theorem cert_e836499606774 : check e836499606774 [] .sourceHead = true := by decide
def e836499607150 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e836499607150 : Closed e836499607150 ∧ code e836499607150 = 9632592629358 := by decide
theorem cert_e836499607150 : check e836499607150 [] .sourceHead = true := by decide
def e836499607162 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e836499607162 : Closed e836499607162 ∧ code e836499607162 = 9632592629370 := by decide
theorem cert_e836499607162 : check e836499607162 [] .sourceHead = true := by decide
def e836499607350 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e836499607350 : Closed e836499607350 ∧ code e836499607350 = 9632592629558 := by decide
theorem cert_e836499607350 : check e836499607350 [] .sourceHead = true := by decide
def e836499607354 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e836499607354 : Closed e836499607354 ∧ code e836499607354 = 9632592629562 := by decide
theorem cert_e836499607354 : check e836499607354 [] .sourceHead = true := by decide
def e837666516334 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e837666516334 : Closed e837666516334 ∧ code e837666516334 = 9633759538542 := by decide
theorem cert_e837666516334 : check e837666516334 [] .sourceHead = true := by decide
def e837666516342 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e837666516342 : Closed e837666516342 ∧ code e837666516342 = 9633759538550 := by decide
theorem cert_e837666516342 : check e837666516342 [] .sourceHead = true := by decide
def e837666516398 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e837666516398 : Closed e837666516398 ∧ code e837666516398 = 9633759538606 := by decide
theorem cert_e837666516398 : check e837666516398 [] .sourceHead = true := by decide
def e837666516410 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e837666516410 : Closed e837666516410 ∧ code e837666516410 = 9633759538618 := by decide
theorem cert_e837666516410 : check e837666516410 [] .sourceHead = true := by decide
def e837666516438 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e837666516438 : Closed e837666516438 ∧ code e837666516438 = 9633759538646 := by decide
theorem cert_e837666516438 : check e837666516438 [] .sourceHead = true := by decide
def e837666516442 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e837666516442 : Closed e837666516442 ∧ code e837666516442 = 9633759538650 := by decide
theorem cert_e837666516442 : check e837666516442 [] .sourceHead = true := by decide
def e837666516654 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e837666516654 : Closed e837666516654 ∧ code e837666516654 = 9633759538862 := by decide
theorem cert_e837666516654 : check e837666516654 [] .sourceHead = true := by decide
def e837666516666 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e837666516666 : Closed e837666516666 ∧ code e837666516666 = 9633759538874 := by decide
theorem cert_e837666516666 : check e837666516666 [] .sourceHead = true := by decide
def e837666516714 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e837666516714 : Closed e837666516714 ∧ code e837666516714 = 9633759538922 := by decide
theorem cert_e837666516714 : check e837666516714 [] .sourceHead = true := by decide
def e837666516822 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e837666516822 : Closed e837666516822 ∧ code e837666516822 = 9633759539030 := by decide
theorem cert_e837666516822 : check e837666516822 [] .sourceHead = true := by decide
def e837666516826 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e837666516826 : Closed e837666516826 ∧ code e837666516826 = 9633759539034 := by decide
theorem cert_e837666516826 : check e837666516826 [] .sourceHead = true := by decide
def e837666516842 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e837666516842 : Closed e837666516842 ∧ code e837666516842 = 9633759539050 := by decide
theorem cert_e837666516842 : check e837666516842 [] .sourceHead = true := by decide
def e837666517870 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e837666517870 : Closed e837666517870 ∧ code e837666517870 = 9633759540078 := by decide
theorem cert_e837666517870 : check e837666517870 [] .sourceHead = true := by decide
def e837666517878 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e837666517878 : Closed e837666517878 ∧ code e837666517878 = 9633759540086 := by decide
theorem cert_e837666517878 : check e837666517878 [] .sourceHead = true := by decide
def e837666517934 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e837666517934 : Closed e837666517934 ∧ code e837666517934 = 9633759540142 := by decide
theorem cert_e837666517934 : check e837666517934 [] .sourceHead = true := by decide
def e837666517946 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e837666517946 : Closed e837666517946 ∧ code e837666517946 = 9633759540154 := by decide
theorem cert_e837666517946 : check e837666517946 [] .sourceHead = true := by decide
def e837666517974 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e837666517974 : Closed e837666517974 ∧ code e837666517974 = 9633759540182 := by decide
theorem cert_e837666517974 : check e837666517974 [] .sourceHead = true := by decide
def e837666517978 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e837666517978 : Closed e837666517978 ∧ code e837666517978 = 9633759540186 := by decide
theorem cert_e837666517978 : check e837666517978 [] .sourceHead = true := by decide
def e837666518254 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e837666518254 : Closed e837666518254 ∧ code e837666518254 = 9633759540462 := by decide
theorem cert_e837666518254 : check e837666518254 [] .sourceHead = true := by decide
def e837666518262 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e837666518262 : Closed e837666518262 ∧ code e837666518262 = 9633759540470 := by decide
theorem cert_e837666518262 : check e837666518262 [] .sourceHead = true := by decide
def e837666518638 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e837666518638 : Closed e837666518638 ∧ code e837666518638 = 9633759540846 := by decide
theorem cert_e837666518638 : check e837666518638 [] .sourceHead = true := by decide
def e837666518650 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e837666518650 : Closed e837666518650 ∧ code e837666518650 = 9633759540858 := by decide
theorem cert_e837666518650 : check e837666518650 [] .sourceHead = true := by decide
def e837666518838 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e837666518838 : Closed e837666518838 ∧ code e837666518838 = 9633759541046 := by decide
theorem cert_e837666518838 : check e837666518838 [] .sourceHead = true := by decide
def e837666518842 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e837666518842 : Closed e837666518842 ∧ code e837666518842 = 9633759541050 := by decide
theorem cert_e837666518842 : check e837666518842 [] .sourceHead = true := by decide
def e837666519470 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e837666519470 : Closed e837666519470 ∧ code e837666519470 = 9633759541678 := by decide
theorem cert_e837666519470 : check e837666519470 [] .sourceHead = true := by decide
def e837666519482 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e837666519482 : Closed e837666519482 ∧ code e837666519482 = 9633759541690 := by decide
theorem cert_e837666519482 : check e837666519482 [] .sourceHead = true := by decide
def e837666519530 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e837666519530 : Closed e837666519530 ∧ code e837666519530 = 9633759541738 := by decide
theorem cert_e837666519530 : check e837666519530 [] .sourceHead = true := by decide
def e837666519662 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e837666519662 : Closed e837666519662 ∧ code e837666519662 = 9633759541870 := by decide
theorem cert_e837666519662 : check e837666519662 [] .sourceHead = true := by decide
def e837666519674 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e837666519674 : Closed e837666519674 ∧ code e837666519674 = 9633759541882 := by decide
theorem cert_e837666519674 : check e837666519674 [] .sourceHead = true := by decide
def e837666519962 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e837666519962 : Closed e837666519962 ∧ code e837666519962 = 9633759542170 := by decide
theorem cert_e837666519962 : check e837666519962 [] .sourceHead = true := by decide
def e837666520278 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e837666520278 : Closed e837666520278 ∧ code e837666520278 = 9633759542486 := by decide
theorem cert_e837666520278 : check e837666520278 [] .sourceHead = true := by decide
def e837666520282 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e837666520282 : Closed e837666520282 ∧ code e837666520282 = 9633759542490 := by decide
theorem cert_e837666520282 : check e837666520282 [] .sourceHead = true := by decide
def e837666520298 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e837666520298 : Closed e837666520298 ∧ code e837666520298 = 9633759542506 := by decide
theorem cert_e837666520298 : check e837666520298 [] .sourceHead = true := by decide
def e837666520374 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e837666520374 : Closed e837666520374 ∧ code e837666520374 = 9633759542582 := by decide
theorem cert_e837666520374 : check e837666520374 [] .sourceHead = true := by decide
def e837666520378 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e837666520378 : Closed e837666520378 ∧ code e837666520378 = 9633759542586 := by decide
theorem cert_e837666520378 : check e837666520378 [] .sourceHead = true := by decide
def e837666520474 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e837666520474 : Closed e837666520474 ∧ code e837666520474 = 9633759542682 := by decide
theorem cert_e837666520474 : check e837666520474 [] .sourceHead = true := by decide
def e837666524014 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e837666524014 : Closed e837666524014 ∧ code e837666524014 = 9633759546222 := by decide
theorem cert_e837666524014 : check e837666524014 [] .sourceHead = true := by decide
def e837666524022 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e837666524022 : Closed e837666524022 ∧ code e837666524022 = 9633759546230 := by decide
theorem cert_e837666524022 : check e837666524022 [] .sourceHead = true := by decide
def e837666524078 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e837666524078 : Closed e837666524078 ∧ code e837666524078 = 9633759546286 := by decide
theorem cert_e837666524078 : check e837666524078 [] .sourceHead = true := by decide
def e837666524090 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e837666524090 : Closed e837666524090 ∧ code e837666524090 = 9633759546298 := by decide
theorem cert_e837666524090 : check e837666524090 [] .sourceHead = true := by decide
def e837666524118 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e837666524118 : Closed e837666524118 ∧ code e837666524118 = 9633759546326 := by decide
theorem cert_e837666524118 : check e837666524118 [] .sourceHead = true := by decide
def e837666524122 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e837666524122 : Closed e837666524122 ∧ code e837666524122 = 9633759546330 := by decide
theorem cert_e837666524122 : check e837666524122 [] .sourceHead = true := by decide
def e837666524398 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e837666524398 : Closed e837666524398 ∧ code e837666524398 = 9633759546606 := by decide
theorem cert_e837666524398 : check e837666524398 [] .sourceHead = true := by decide
def e837666524406 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e837666524406 : Closed e837666524406 ∧ code e837666524406 = 9633759546614 := by decide
theorem cert_e837666524406 : check e837666524406 [] .sourceHead = true := by decide
def e837666524782 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e837666524782 : Closed e837666524782 ∧ code e837666524782 = 9633759546990 := by decide
theorem cert_e837666524782 : check e837666524782 [] .sourceHead = true := by decide
def e837666524794 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e837666524794 : Closed e837666524794 ∧ code e837666524794 = 9633759547002 := by decide
theorem cert_e837666524794 : check e837666524794 [] .sourceHead = true := by decide
def e837666524982 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e837666524982 : Closed e837666524982 ∧ code e837666524982 = 9633759547190 := by decide
theorem cert_e837666524982 : check e837666524982 [] .sourceHead = true := by decide
def e837666524986 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e837666524986 : Closed e837666524986 ∧ code e837666524986 = 9633759547194 := by decide
theorem cert_e837666524986 : check e837666524986 [] .sourceHead = true := by decide
def e837666530734 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e837666530734 : Closed e837666530734 ∧ code e837666530734 = 9633759552942 := by decide
theorem cert_e837666530734 : check e837666530734 [] .sourceHead = true := by decide
def e837666530746 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e837666530746 : Closed e837666530746 ∧ code e837666530746 = 9633759552954 := by decide
theorem cert_e837666530746 : check e837666530746 [] .sourceHead = true := by decide
def e837666530794 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e837666530794 : Closed e837666530794 ∧ code e837666530794 = 9633759553002 := by decide
theorem cert_e837666530794 : check e837666530794 [] .sourceHead = true := by decide
def e837666530926 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e837666530926 : Closed e837666530926 ∧ code e837666530926 = 9633759553134 := by decide
theorem cert_e837666530926 : check e837666530926 [] .sourceHead = true := by decide
def e837666530938 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e837666530938 : Closed e837666530938 ∧ code e837666530938 = 9633759553146 := by decide
theorem cert_e837666530938 : check e837666530938 [] .sourceHead = true := by decide
def e837666531226 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e837666531226 : Closed e837666531226 ∧ code e837666531226 = 9633759553434 := by decide
theorem cert_e837666531226 : check e837666531226 [] .sourceHead = true := by decide
def e837666534102 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e837666534102 : Closed e837666534102 ∧ code e837666534102 = 9633759556310 := by decide
theorem cert_e837666534102 : check e837666534102 [] .sourceHead = true := by decide
def e837666534106 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e837666534106 : Closed e837666534106 ∧ code e837666534106 = 9633759556314 := by decide
theorem cert_e837666534106 : check e837666534106 [] .sourceHead = true := by decide
def e837666534122 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e837666534122 : Closed e837666534122 ∧ code e837666534122 = 9633759556330 := by decide
theorem cert_e837666534122 : check e837666534122 [] .sourceHead = true := by decide
def e837666534198 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e837666534198 : Closed e837666534198 ∧ code e837666534198 = 9633759556406 := by decide
theorem cert_e837666534198 : check e837666534198 [] .sourceHead = true := by decide
def e837666534202 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e837666534202 : Closed e837666534202 ∧ code e837666534202 = 9633759556410 := by decide
theorem cert_e837666534202 : check e837666534202 [] .sourceHead = true := by decide
def e837666534298 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e837666534298 : Closed e837666534298 ∧ code e837666534298 = 9633759556506 := by decide
theorem cert_e837666534298 : check e837666534298 [] .sourceHead = true := by decide
def e838110063982 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e838110063982 : Closed e838110063982 ∧ code e838110063982 = 9634203086190 := by decide
theorem cert_e838110063982 : check e838110063982 [] .sourceHead = true := by decide
def e838110063990 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e838110063990 : Closed e838110063990 ∧ code e838110063990 = 9634203086198 := by decide
theorem cert_e838110063990 : check e838110063990 [] .sourceHead = true := by decide
def e838110064046 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e838110064046 : Closed e838110064046 ∧ code e838110064046 = 9634203086254 := by decide
theorem cert_e838110064046 : check e838110064046 [] .sourceHead = true := by decide
def e838110064058 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e838110064058 : Closed e838110064058 ∧ code e838110064058 = 9634203086266 := by decide
theorem cert_e838110064058 : check e838110064058 [] .sourceHead = true := by decide
def e838110064086 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e838110064086 : Closed e838110064086 ∧ code e838110064086 = 9634203086294 := by decide
theorem cert_e838110064086 : check e838110064086 [] .sourceHead = true := by decide
def e838110064090 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e838110064090 : Closed e838110064090 ∧ code e838110064090 = 9634203086298 := by decide
theorem cert_e838110064090 : check e838110064090 [] .sourceHead = true := by decide
def e838110064302 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e838110064302 : Closed e838110064302 ∧ code e838110064302 = 9634203086510 := by decide
theorem cert_e838110064302 : check e838110064302 [] .sourceHead = true := by decide
def e838110064314 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e838110064314 : Closed e838110064314 ∧ code e838110064314 = 9634203086522 := by decide
theorem cert_e838110064314 : check e838110064314 [] .sourceHead = true := by decide
def e838110064362 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e838110064362 : Closed e838110064362 ∧ code e838110064362 = 9634203086570 := by decide
theorem cert_e838110064362 : check e838110064362 [] .sourceHead = true := by decide
def e838110064470 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e838110064470 : Closed e838110064470 ∧ code e838110064470 = 9634203086678 := by decide
theorem cert_e838110064470 : check e838110064470 [] .sourceHead = true := by decide
def e838110064474 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e838110064474 : Closed e838110064474 ∧ code e838110064474 = 9634203086682 := by decide
theorem cert_e838110064474 : check e838110064474 [] .sourceHead = true := by decide
def e838110064490 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e838110064490 : Closed e838110064490 ∧ code e838110064490 = 9634203086698 := by decide
theorem cert_e838110064490 : check e838110064490 [] .sourceHead = true := by decide
def e838110065518 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e838110065518 : Closed e838110065518 ∧ code e838110065518 = 9634203087726 := by decide
theorem cert_e838110065518 : check e838110065518 [] .sourceHead = true := by decide
def e838110065526 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e838110065526 : Closed e838110065526 ∧ code e838110065526 = 9634203087734 := by decide
theorem cert_e838110065526 : check e838110065526 [] .sourceHead = true := by decide
def e838110065582 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e838110065582 : Closed e838110065582 ∧ code e838110065582 = 9634203087790 := by decide
theorem cert_e838110065582 : check e838110065582 [] .sourceHead = true := by decide
def e838110065594 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e838110065594 : Closed e838110065594 ∧ code e838110065594 = 9634203087802 := by decide
theorem cert_e838110065594 : check e838110065594 [] .sourceHead = true := by decide
def e838110065622 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e838110065622 : Closed e838110065622 ∧ code e838110065622 = 9634203087830 := by decide
theorem cert_e838110065622 : check e838110065622 [] .sourceHead = true := by decide
def e838110065626 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e838110065626 : Closed e838110065626 ∧ code e838110065626 = 9634203087834 := by decide
theorem cert_e838110065626 : check e838110065626 [] .sourceHead = true := by decide
def e838110065902 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e838110065902 : Closed e838110065902 ∧ code e838110065902 = 9634203088110 := by decide
theorem cert_e838110065902 : check e838110065902 [] .sourceHead = true := by decide
def e838110065910 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e838110065910 : Closed e838110065910 ∧ code e838110065910 = 9634203088118 := by decide
theorem cert_e838110065910 : check e838110065910 [] .sourceHead = true := by decide
def e838110066286 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e838110066286 : Closed e838110066286 ∧ code e838110066286 = 9634203088494 := by decide
theorem cert_e838110066286 : check e838110066286 [] .sourceHead = true := by decide
def e838110066298 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e838110066298 : Closed e838110066298 ∧ code e838110066298 = 9634203088506 := by decide
theorem cert_e838110066298 : check e838110066298 [] .sourceHead = true := by decide
def e838110066486 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e838110066486 : Closed e838110066486 ∧ code e838110066486 = 9634203088694 := by decide
theorem cert_e838110066486 : check e838110066486 [] .sourceHead = true := by decide
def e838110066490 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e838110066490 : Closed e838110066490 ∧ code e838110066490 = 9634203088698 := by decide
theorem cert_e838110066490 : check e838110066490 [] .sourceHead = true := by decide
def e838110067118 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e838110067118 : Closed e838110067118 ∧ code e838110067118 = 9634203089326 := by decide
theorem cert_e838110067118 : check e838110067118 [] .sourceHead = true := by decide
def e838110067130 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e838110067130 : Closed e838110067130 ∧ code e838110067130 = 9634203089338 := by decide
theorem cert_e838110067130 : check e838110067130 [] .sourceHead = true := by decide
def e838110067178 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e838110067178 : Closed e838110067178 ∧ code e838110067178 = 9634203089386 := by decide
theorem cert_e838110067178 : check e838110067178 [] .sourceHead = true := by decide
def e838110067310 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e838110067310 : Closed e838110067310 ∧ code e838110067310 = 9634203089518 := by decide
theorem cert_e838110067310 : check e838110067310 [] .sourceHead = true := by decide
def e838110067322 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e838110067322 : Closed e838110067322 ∧ code e838110067322 = 9634203089530 := by decide
theorem cert_e838110067322 : check e838110067322 [] .sourceHead = true := by decide
def e838110067610 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e838110067610 : Closed e838110067610 ∧ code e838110067610 = 9634203089818 := by decide
theorem cert_e838110067610 : check e838110067610 [] .sourceHead = true := by decide
def e838110067926 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e838110067926 : Closed e838110067926 ∧ code e838110067926 = 9634203090134 := by decide
theorem cert_e838110067926 : check e838110067926 [] .sourceHead = true := by decide
def e838110067930 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e838110067930 : Closed e838110067930 ∧ code e838110067930 = 9634203090138 := by decide
theorem cert_e838110067930 : check e838110067930 [] .sourceHead = true := by decide
def e838110067946 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e838110067946 : Closed e838110067946 ∧ code e838110067946 = 9634203090154 := by decide
theorem cert_e838110067946 : check e838110067946 [] .sourceHead = true := by decide
def e838110068022 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e838110068022 : Closed e838110068022 ∧ code e838110068022 = 9634203090230 := by decide
theorem cert_e838110068022 : check e838110068022 [] .sourceHead = true := by decide
def e838110068026 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e838110068026 : Closed e838110068026 ∧ code e838110068026 = 9634203090234 := by decide
theorem cert_e838110068026 : check e838110068026 [] .sourceHead = true := by decide
def e838110068122 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e838110068122 : Closed e838110068122 ∧ code e838110068122 = 9634203090330 := by decide
theorem cert_e838110068122 : check e838110068122 [] .sourceHead = true := by decide
def e838110071662 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e838110071662 : Closed e838110071662 ∧ code e838110071662 = 9634203093870 := by decide
theorem cert_e838110071662 : check e838110071662 [] .sourceHead = true := by decide
def e838110071670 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e838110071670 : Closed e838110071670 ∧ code e838110071670 = 9634203093878 := by decide
theorem cert_e838110071670 : check e838110071670 [] .sourceHead = true := by decide
def e838110071726 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e838110071726 : Closed e838110071726 ∧ code e838110071726 = 9634203093934 := by decide
theorem cert_e838110071726 : check e838110071726 [] .sourceHead = true := by decide
def e838110071738 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e838110071738 : Closed e838110071738 ∧ code e838110071738 = 9634203093946 := by decide
theorem cert_e838110071738 : check e838110071738 [] .sourceHead = true := by decide
def e838110071766 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e838110071766 : Closed e838110071766 ∧ code e838110071766 = 9634203093974 := by decide
theorem cert_e838110071766 : check e838110071766 [] .sourceHead = true := by decide
def e838110071770 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e838110071770 : Closed e838110071770 ∧ code e838110071770 = 9634203093978 := by decide
theorem cert_e838110071770 : check e838110071770 [] .sourceHead = true := by decide
def e838110072046 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e838110072046 : Closed e838110072046 ∧ code e838110072046 = 9634203094254 := by decide
theorem cert_e838110072046 : check e838110072046 [] .sourceHead = true := by decide
def e838110072054 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e838110072054 : Closed e838110072054 ∧ code e838110072054 = 9634203094262 := by decide
theorem cert_e838110072054 : check e838110072054 [] .sourceHead = true := by decide
def e838110072430 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e838110072430 : Closed e838110072430 ∧ code e838110072430 = 9634203094638 := by decide
theorem cert_e838110072430 : check e838110072430 [] .sourceHead = true := by decide
def e838110072442 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e838110072442 : Closed e838110072442 ∧ code e838110072442 = 9634203094650 := by decide
theorem cert_e838110072442 : check e838110072442 [] .sourceHead = true := by decide
def e838110072630 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e838110072630 : Closed e838110072630 ∧ code e838110072630 = 9634203094838 := by decide
theorem cert_e838110072630 : check e838110072630 [] .sourceHead = true := by decide
def e838110072634 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e838110072634 : Closed e838110072634 ∧ code e838110072634 = 9634203094842 := by decide
theorem cert_e838110072634 : check e838110072634 [] .sourceHead = true := by decide
def e838110078382 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e838110078382 : Closed e838110078382 ∧ code e838110078382 = 9634203100590 := by decide
theorem cert_e838110078382 : check e838110078382 [] .sourceHead = true := by decide
def e838110078394 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e838110078394 : Closed e838110078394 ∧ code e838110078394 = 9634203100602 := by decide
theorem cert_e838110078394 : check e838110078394 [] .sourceHead = true := by decide
def e838110078442 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e838110078442 : Closed e838110078442 ∧ code e838110078442 = 9634203100650 := by decide
theorem cert_e838110078442 : check e838110078442 [] .sourceHead = true := by decide
def e838110078574 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e838110078574 : Closed e838110078574 ∧ code e838110078574 = 9634203100782 := by decide
theorem cert_e838110078574 : check e838110078574 [] .sourceHead = true := by decide
def e838110078586 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e838110078586 : Closed e838110078586 ∧ code e838110078586 = 9634203100794 := by decide
theorem cert_e838110078586 : check e838110078586 [] .sourceHead = true := by decide
def e838110078874 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e838110078874 : Closed e838110078874 ∧ code e838110078874 = 9634203101082 := by decide
theorem cert_e838110078874 : check e838110078874 [] .sourceHead = true := by decide
def e838110081750 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e838110081750 : Closed e838110081750 ∧ code e838110081750 = 9634203103958 := by decide
theorem cert_e838110081750 : check e838110081750 [] .sourceHead = true := by decide
def e838110081754 : Term := (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e838110081754 : Closed e838110081754 ∧ code e838110081754 = 9634203103962 := by decide
theorem cert_e838110081754 : check e838110081754 [] .sourceHead = true := by decide
end Blc.Floor43
