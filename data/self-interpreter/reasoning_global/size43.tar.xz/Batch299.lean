import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411629754582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2411629754582 : Closed e2411629754582 ∧ code e2411629754582 = 11207722776790 := by decide
theorem cert_e2411629754582 : check e2411629754582 [[],[]] .chain = true := by decide
def e2411629754586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2411629754586 : Closed e2411629754586 ∧ code e2411629754586 = 11207722776794 := by decide
theorem cert_e2411629754586 : check e2411629754586 [[],[]] .chain = true := by decide
def e2411629754602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2411629754602 : Closed e2411629754602 ∧ code e2411629754602 = 11207722776810 := by decide
theorem cert_e2411629754602 : check e2411629754602 [[],[]] .chain = true := by decide
def e2411629754934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2411629754934 : Closed e2411629754934 ∧ code e2411629754934 = 11207722777142 := by decide
theorem cert_e2411629754934 : check e2411629754934 [[],[]] .chain = true := by decide
def e2411629754938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2411629754938 : Closed e2411629754938 ∧ code e2411629754938 = 11207722777146 := by decide
theorem cert_e2411629754938 : check e2411629754938 [[],[]] .chain = true := by decide
def e2411629755022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2411629755022 : Closed e2411629755022 ∧ code e2411629755022 = 11207722777230 := by decide
theorem cert_e2411629755022 : check e2411629755022 [[],[]] .chain = true := by decide
def e2411629755078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2411629755078 : Closed e2411629755078 ∧ code e2411629755078 = 11207722777286 := by decide
theorem cert_e2411629755078 : check e2411629755078 [[],[]] .chain = true := by decide
def e2411629755158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629755158 : Closed e2411629755158 ∧ code e2411629755158 = 11207722777366 := by decide
theorem cert_e2411629755158 : check e2411629755158 [[],[]] .chain = true := by decide
def e2411629755162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629755162 : Closed e2411629755162 ∧ code e2411629755162 = 11207722777370 := by decide
theorem cert_e2411629755162 : check e2411629755162 [[],[]] .chain = true := by decide
def e2411629755206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629755206 : Closed e2411629755206 ∧ code e2411629755206 = 11207722777414 := by decide
theorem cert_e2411629755206 : check e2411629755206 [[],[]] .chain = true := by decide
def e2411629755234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629755234 : Closed e2411629755234 ∧ code e2411629755234 = 11207722777442 := by decide
theorem cert_e2411629755234 : check e2411629755234 [[],[]] .chain = true := by decide
def e2411629755246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2411629755246 : Closed e2411629755246 ∧ code e2411629755246 = 11207722777454 := by decide
theorem cert_e2411629755246 : check e2411629755246 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2411629755254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2411629755254 : Closed e2411629755254 ∧ code e2411629755254 = 11207722777462 := by decide
theorem cert_e2411629755254 : check e2411629755254 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2411629755318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2411629755318 : Closed e2411629755318 ∧ code e2411629755318 = 11207722777526 := by decide
theorem cert_e2411629755318 : check e2411629755318 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2411629757806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2411629757806 : Closed e2411629757806 ∧ code e2411629757806 = 11207722780014 := by decide
theorem cert_e2411629757806 : check e2411629757806 [[],[]] .chain = true := by decide
def e2411629757814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2411629757814 : Closed e2411629757814 ∧ code e2411629757814 = 11207722780022 := by decide
theorem cert_e2411629757814 : check e2411629757814 [[],[]] .chain = true := by decide
def e2411629757870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2411629757870 : Closed e2411629757870 ∧ code e2411629757870 = 11207722780078 := by decide
theorem cert_e2411629757870 : check e2411629757870 [[],[]] .chain = true := by decide
def e2411629757882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2411629757882 : Closed e2411629757882 ∧ code e2411629757882 = 11207722780090 := by decide
theorem cert_e2411629757882 : check e2411629757882 [[],[]] .chain = true := by decide
def e2411629757910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2411629757910 : Closed e2411629757910 ∧ code e2411629757910 = 11207722780118 := by decide
theorem cert_e2411629757910 : check e2411629757910 [[],[]] .chain = true := by decide
def e2411629757914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2411629757914 : Closed e2411629757914 ∧ code e2411629757914 = 11207722780122 := by decide
theorem cert_e2411629757914 : check e2411629757914 [[],[]] .chain = true := by decide
def e2411629758126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2411629758126 : Closed e2411629758126 ∧ code e2411629758126 = 11207722780334 := by decide
theorem cert_e2411629758126 : check e2411629758126 [[],[]] .chain = true := by decide
def e2411629758138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2411629758138 : Closed e2411629758138 ∧ code e2411629758138 = 11207722780346 := by decide
theorem cert_e2411629758138 : check e2411629758138 [[],[]] .chain = true := by decide
def e2411629758186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2411629758186 : Closed e2411629758186 ∧ code e2411629758186 = 11207722780394 := by decide
theorem cert_e2411629758186 : check e2411629758186 [[],[]] .chain = true := by decide
def e2411629758378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2411629758378 : Closed e2411629758378 ∧ code e2411629758378 = 11207722780586 := by decide
theorem cert_e2411629758378 : check e2411629758378 [[],[]] .chain = true := by decide
def e2411629760878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2411629760878 : Closed e2411629760878 ∧ code e2411629760878 = 11207722783086 := by decide
theorem cert_e2411629760878 : check e2411629760878 [[],[]] .chain = true := by decide
def e2411629760886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2411629760886 : Closed e2411629760886 ∧ code e2411629760886 = 11207722783094 := by decide
theorem cert_e2411629760886 : check e2411629760886 [[],[]] .chain = true := by decide
def e2411629760942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2411629760942 : Closed e2411629760942 ∧ code e2411629760942 = 11207722783150 := by decide
theorem cert_e2411629760942 : check e2411629760942 [[],[]] .chain = true := by decide
def e2411629760954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2411629760954 : Closed e2411629760954 ∧ code e2411629760954 = 11207722783162 := by decide
theorem cert_e2411629760954 : check e2411629760954 [[],[]] .chain = true := by decide
def e2411629761002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2411629761002 : Closed e2411629761002 ∧ code e2411629761002 = 11207722783210 := by decide
theorem cert_e2411629761002 : check e2411629761002 [[],[]] .chain = true := by decide
def e2411629761646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2411629761646 : Closed e2411629761646 ∧ code e2411629761646 = 11207722783854 := by decide
theorem cert_e2411629761646 : check e2411629761646 [[],[]] .chain = true := by decide
def e2411629761658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2411629761658 : Closed e2411629761658 ∧ code e2411629761658 = 11207722783866 := by decide
theorem cert_e2411629761658 : check e2411629761658 [[],[]] .chain = true := by decide
def e2411629761822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2411629761822 : Closed e2411629761822 ∧ code e2411629761822 = 11207722784030 := by decide
theorem cert_e2411629761822 : check e2411629761822 [[],[]] .chain = true := by decide
def e2411629761990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2411629761990 : Closed e2411629761990 ∧ code e2411629761990 = 11207722784198 := by decide
theorem cert_e2411629761990 : check e2411629761990 [[],[]] .chain = true := by decide
def e2411629762094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2411629762094 : Closed e2411629762094 ∧ code e2411629762094 = 11207722784302 := by decide
theorem cert_e2411629762094 : check e2411629762094 [[],[]] .chain = true := by decide
def e2411629762274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2411629762274 : Closed e2411629762274 ∧ code e2411629762274 = 11207722784482 := by decide
theorem cert_e2411629762274 : check e2411629762274 [[],[]] .chain = true := by decide
def e2411629762286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2411629762286 : Closed e2411629762286 ∧ code e2411629762286 = 11207722784494 := by decide
theorem cert_e2411629762286 : check e2411629762286 [[],[]] .sourceHead = true := by decide
def e2411629762326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629762326 : Closed e2411629762326 ∧ code e2411629762326 = 11207722784534 := by decide
theorem cert_e2411629762326 : check e2411629762326 [[],[]] .chain = true := by decide
def e2411629762330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629762330 : Closed e2411629762330 ∧ code e2411629762330 = 11207722784538 := by decide
theorem cert_e2411629762330 : check e2411629762330 [[],[]] .chain = true := by decide
def e2411629762374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629762374 : Closed e2411629762374 ∧ code e2411629762374 = 11207722784582 := by decide
theorem cert_e2411629762374 : check e2411629762374 [[],[]] .chain = true := by decide
def e2411629762402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629762402 : Closed e2411629762402 ∧ code e2411629762402 = 11207722784610 := by decide
theorem cert_e2411629762402 : check e2411629762402 [[],[]] .chain = true := by decide
def e2411629762414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2411629762414 : Closed e2411629762414 ∧ code e2411629762414 = 11207722784622 := by decide
theorem cert_e2411629762414 : check e2411629762414 [[],[]] .sourceHead = true := by decide
def e2411629762422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2411629762422 : Closed e2411629762422 ∧ code e2411629762422 = 11207722784630 := by decide
theorem cert_e2411629762422 : check e2411629762422 [[],[]] .sourceHead = true := by decide
def e2411629762734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2411629762734 : Closed e2411629762734 ∧ code e2411629762734 = 11207722784942 := by decide
theorem cert_e2411629762734 : check e2411629762734 [[],[]] .chain = true := by decide
def e2411629762746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2411629762746 : Closed e2411629762746 ∧ code e2411629762746 = 11207722784954 := by decide
theorem cert_e2411629762746 : check e2411629762746 [[],[]] .chain = true := by decide
def e2411629763118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2411629763118 : Closed e2411629763118 ∧ code e2411629763118 = 11207722785326 := by decide
theorem cert_e2411629763118 : check e2411629763118 [[],[]] .chain = true := by decide
def e2411629763298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2411629763298 : Closed e2411629763298 ∧ code e2411629763298 = 11207722785506 := by decide
theorem cert_e2411629763298 : check e2411629763298 [[],[]] .chain = true := by decide
def e2411629763310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2411629763310 : Closed e2411629763310 ∧ code e2411629763310 = 11207722785518 := by decide
theorem cert_e2411629763310 : check e2411629763310 [[],[]] .sourceHead = true := by decide
def e2411629763466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2411629763466 : Closed e2411629763466 ∧ code e2411629763466 = 11207722785674 := by decide
theorem cert_e2411629763466 : check e2411629763466 [[],[]] .chain = true := by decide
def e2411629763490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2411629763490 : Closed e2411629763490 ∧ code e2411629763490 = 11207722785698 := by decide
theorem cert_e2411629763490 : check e2411629763490 [[],[]] .chain = true := by decide
def e2411629763502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2411629763502 : Closed e2411629763502 ∧ code e2411629763502 = 11207722785710 := by decide
theorem cert_e2411629763502 : check e2411629763502 [[],[]] .sourceHead = true := by decide
def e2411629763514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2411629763514 : Closed e2411629763514 ∧ code e2411629763514 = 11207722785722 := by decide
theorem cert_e2411629763514 : check e2411629763514 [[],[]] .sourceHead = true := by decide
def e2411629763670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2411629763670 : Closed e2411629763670 ∧ code e2411629763670 = 11207722785878 := by decide
theorem cert_e2411629763670 : check e2411629763670 [[],[]] .chain = true := by decide
def e2411629763674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2411629763674 : Closed e2411629763674 ∧ code e2411629763674 = 11207722785882 := by decide
theorem cert_e2411629763674 : check e2411629763674 [[],[]] .chain = true := by decide
def e2411629763690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2411629763690 : Closed e2411629763690 ∧ code e2411629763690 = 11207722785898 := by decide
theorem cert_e2411629763690 : check e2411629763690 [[],[]] .chain = true := by decide
def e2411629763862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629763862 : Closed e2411629763862 ∧ code e2411629763862 = 11207722786070 := by decide
theorem cert_e2411629763862 : check e2411629763862 [[],[]] .chain = true := by decide
def e2411629763866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629763866 : Closed e2411629763866 ∧ code e2411629763866 = 11207722786074 := by decide
theorem cert_e2411629763866 : check e2411629763866 [[],[]] .chain = true := by decide
def e2411629763910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629763910 : Closed e2411629763910 ∧ code e2411629763910 = 11207722786118 := by decide
theorem cert_e2411629763910 : check e2411629763910 [[],[]] .chain = true := by decide
def e2411629763938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629763938 : Closed e2411629763938 ∧ code e2411629763938 = 11207722786146 := by decide
theorem cert_e2411629763938 : check e2411629763938 [[],[]] .chain = true := by decide
def e2411629763950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2411629763950 : Closed e2411629763950 ∧ code e2411629763950 = 11207722786158 := by decide
theorem cert_e2411629763950 : check e2411629763950 [[],[]] .sourceHead = true := by decide
def e2411629763958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2411629763958 : Closed e2411629763958 ∧ code e2411629763958 = 11207722786166 := by decide
theorem cert_e2411629763958 : check e2411629763958 [[],[]] .sourceHead = true := by decide
def e2411629763978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2411629763978 : Closed e2411629763978 ∧ code e2411629763978 = 11207722786186 := by decide
theorem cert_e2411629763978 : check e2411629763978 [[],[]] .chain = true := by decide
def e2411629764002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2411629764002 : Closed e2411629764002 ∧ code e2411629764002 = 11207722786210 := by decide
theorem cert_e2411629764002 : check e2411629764002 [[],[]] .chain = true := by decide
def e2411629764014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2411629764014 : Closed e2411629764014 ∧ code e2411629764014 = 11207722786222 := by decide
theorem cert_e2411629764014 : check e2411629764014 [[],[]] .sourceHead = true := by decide
def e2411629764026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2411629764026 : Closed e2411629764026 ∧ code e2411629764026 = 11207722786234 := by decide
theorem cert_e2411629764026 : check e2411629764026 [[],[]] .sourceHead = true := by decide
def e2411629764054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2411629764054 : Closed e2411629764054 ∧ code e2411629764054 = 11207722786262 := by decide
theorem cert_e2411629764054 : check e2411629764054 [[],[]] .sourceHead = true := by decide
def e2411629764058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2411629764058 : Closed e2411629764058 ∧ code e2411629764058 = 11207722786266 := by decide
theorem cert_e2411629764058 : check e2411629764058 [[],[]] .sourceHead = true := by decide
def e2411629765302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2411629765302 : Closed e2411629765302 ∧ code e2411629765302 = 11207722787510 := by decide
theorem cert_e2411629765302 : check e2411629765302 [[],[]] .chain = true := by decide
def e2411629765334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2411629765334 : Closed e2411629765334 ∧ code e2411629765334 = 11207722787542 := by decide
theorem cert_e2411629765334 : check e2411629765334 [[],[]] .chain = true := by decide
def e2411629765338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2411629765338 : Closed e2411629765338 ∧ code e2411629765338 = 11207722787546 := by decide
theorem cert_e2411629765338 : check e2411629765338 [[],[]] .chain = true := by decide
def e2411629765462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2411629765462 : Closed e2411629765462 ∧ code e2411629765462 = 11207722787670 := by decide
theorem cert_e2411629765462 : check e2411629765462 [[],[]] .chain = true := by decide
def e2411629765466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2411629765466 : Closed e2411629765466 ∧ code e2411629765466 = 11207722787674 := by decide
theorem cert_e2411629765466 : check e2411629765466 [[],[]] .chain = true := by decide
def e2411629765482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2411629765482 : Closed e2411629765482 ∧ code e2411629765482 = 11207722787690 := by decide
theorem cert_e2411629765482 : check e2411629765482 [[],[]] .chain = true := by decide
def e2411629765546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2411629765546 : Closed e2411629765546 ∧ code e2411629765546 = 11207722787754 := by decide
theorem cert_e2411629765546 : check e2411629765546 [[],[]] .chain = true := by decide
def e2411629766838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2411629766838 : Closed e2411629766838 ∧ code e2411629766838 = 11207722789046 := by decide
theorem cert_e2411629766838 : check e2411629766838 [[],[]] .chain = true := by decide
def e2411629766870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2411629766870 : Closed e2411629766870 ∧ code e2411629766870 = 11207722789078 := by decide
theorem cert_e2411629766870 : check e2411629766870 [[],[]] .chain = true := by decide
def e2411629766874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2411629766874 : Closed e2411629766874 ∧ code e2411629766874 = 11207722789082 := by decide
theorem cert_e2411629766874 : check e2411629766874 [[],[]] .chain = true := by decide
def e2411629766890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2411629766890 : Closed e2411629766890 ∧ code e2411629766890 = 11207722789098 := by decide
theorem cert_e2411629766890 : check e2411629766890 [[],[]] .chain = true := by decide
def e2411629767222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2411629767222 : Closed e2411629767222 ∧ code e2411629767222 = 11207722789430 := by decide
theorem cert_e2411629767222 : check e2411629767222 [[],[]] .chain = true := by decide
def e2411629767226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2411629767226 : Closed e2411629767226 ∧ code e2411629767226 = 11207722789434 := by decide
theorem cert_e2411629767226 : check e2411629767226 [[],[]] .chain = true := by decide
def e2411629767310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2411629767310 : Closed e2411629767310 ∧ code e2411629767310 = 11207722789518 := by decide
theorem cert_e2411629767310 : check e2411629767310 [[],[]] .chain = true := by decide
def e2411629767366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2411629767366 : Closed e2411629767366 ∧ code e2411629767366 = 11207722789574 := by decide
theorem cert_e2411629767366 : check e2411629767366 [[],[]] .chain = true := by decide
def e2411629767446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629767446 : Closed e2411629767446 ∧ code e2411629767446 = 11207722789654 := by decide
theorem cert_e2411629767446 : check e2411629767446 [[],[]] .chain = true := by decide
def e2411629767450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629767450 : Closed e2411629767450 ∧ code e2411629767450 = 11207722789658 := by decide
theorem cert_e2411629767450 : check e2411629767450 [[],[]] .chain = true := by decide
def e2411629767494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629767494 : Closed e2411629767494 ∧ code e2411629767494 = 11207722789702 := by decide
theorem cert_e2411629767494 : check e2411629767494 [[],[]] .chain = true := by decide
def e2411629767522 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629767522 : Closed e2411629767522 ∧ code e2411629767522 = 11207722789730 := by decide
theorem cert_e2411629767522 : check e2411629767522 [[],[]] .chain = true := by decide
def e2411629767534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2411629767534 : Closed e2411629767534 ∧ code e2411629767534 = 11207722789742 := by decide
theorem cert_e2411629767534 : check e2411629767534 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2411629767542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2411629767542 : Closed e2411629767542 ∧ code e2411629767542 = 11207722789750 := by decide
theorem cert_e2411629767542 : check e2411629767542 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2411629767606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2411629767606 : Closed e2411629767606 ∧ code e2411629767606 = 11207722789814 := by decide
def e2411629767766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2411629767766 : Closed e2411629767766 ∧ code e2411629767766 = 11207722789974 := by decide
theorem cert_e2411629767766 : check e2411629767766 [[],[]] .chain = true := by decide
def e2411629767770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2411629767770 : Closed e2411629767770 ∧ code e2411629767770 = 11207722789978 := by decide
theorem cert_e2411629767770 : check e2411629767770 [[],[]] .chain = true := by decide
def e2411629767786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2411629767786 : Closed e2411629767786 ∧ code e2411629767786 = 11207722789994 := by decide
theorem cert_e2411629767786 : check e2411629767786 [[],[]] .chain = true := by decide
def e2411629767958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629767958 : Closed e2411629767958 ∧ code e2411629767958 = 11207722790166 := by decide
theorem cert_e2411629767958 : check e2411629767958 [[],[]] .chain = true := by decide
def e2411629767962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629767962 : Closed e2411629767962 ∧ code e2411629767962 = 11207722790170 := by decide
theorem cert_e2411629767962 : check e2411629767962 [[],[]] .chain = true := by decide
def e2411629768006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629768006 : Closed e2411629768006 ∧ code e2411629768006 = 11207722790214 := by decide
theorem cert_e2411629768006 : check e2411629768006 [[],[]] .chain = true := by decide
def e2411629768034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629768034 : Closed e2411629768034 ∧ code e2411629768034 = 11207722790242 := by decide
theorem cert_e2411629768034 : check e2411629768034 [[],[]] .chain = true := by decide
def e2411629768046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2411629768046 : Closed e2411629768046 ∧ code e2411629768046 = 11207722790254 := by decide
theorem cert_e2411629768046 : check e2411629768046 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2411629768054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2411629768054 : Closed e2411629768054 ∧ code e2411629768054 = 11207722790262 := by decide
theorem cert_e2411629768054 : check e2411629768054 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2411629768074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2411629768074 : Closed e2411629768074 ∧ code e2411629768074 = 11207722790282 := by decide
theorem cert_e2411629768074 : check e2411629768074 [[],[]] .chain = true := by decide
def e2411629768098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2411629768098 : Closed e2411629768098 ∧ code e2411629768098 = 11207722790306 := by decide
theorem cert_e2411629768098 : check e2411629768098 [[],[]] .chain = true := by decide
def e2411629768110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2411629768110 : Closed e2411629768110 ∧ code e2411629768110 = 11207722790318 := by decide
theorem cert_e2411629768110 : check e2411629768110 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2411629768122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2411629768122 : Closed e2411629768122 ∧ code e2411629768122 = 11207722790330 := by decide
theorem cert_e2411629768122 : check e2411629768122 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2411629768150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2411629768150 : Closed e2411629768150 ∧ code e2411629768150 = 11207722790358 := by decide
def e2411629768154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2411629768154 : Closed e2411629768154 ∧ code e2411629768154 = 11207722790362 := by decide
def e2411629768374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2411629768374 : Closed e2411629768374 ∧ code e2411629768374 = 11207722790582 := by decide
theorem cert_e2411629768374 : check e2411629768374 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2411629768406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2411629768406 : Closed e2411629768406 ∧ code e2411629768406 = 11207722790614 := by decide
theorem cert_e2411629768406 : check e2411629768406 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2411629768410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2411629768410 : Closed e2411629768410 ∧ code e2411629768410 = 11207722790618 := by decide
theorem cert_e2411629768410 : check e2411629768410 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2411629776750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 1)) (.var 2))))))
theorem wire_e2411629776750 : Closed e2411629776750 ∧ code e2411629776750 = 11207722798958 := by decide
theorem cert_e2411629776750 : check e2411629776750 [[],[]] .chain = true := by decide
def e2411629776758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 1))))))
theorem wire_e2411629776758 : Closed e2411629776758 ∧ code e2411629776758 = 11207722798966 := by decide
theorem cert_e2411629776758 : check e2411629776758 [[],[]] .chain = true := by decide
def e2411629776822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 1))))))
theorem wire_e2411629776822 : Closed e2411629776822 ∧ code e2411629776822 = 11207722799030 := by decide
theorem cert_e2411629776822 : check e2411629776822 [[],[]] .chain = true := by decide
def e2411629779822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2411629779822 : Closed e2411629779822 ∧ code e2411629779822 = 11207722802030 := by decide
theorem cert_e2411629779822 : check e2411629779822 [[],[]] .chain = true := by decide
def e2411629779830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2411629779830 : Closed e2411629779830 ∧ code e2411629779830 = 11207722802038 := by decide
theorem cert_e2411629779830 : check e2411629779830 [[],[]] .chain = true := by decide
def e2411629779886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2411629779886 : Closed e2411629779886 ∧ code e2411629779886 = 11207722802094 := by decide
theorem cert_e2411629779886 : check e2411629779886 [[],[]] .chain = true := by decide
def e2411629779898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2411629779898 : Closed e2411629779898 ∧ code e2411629779898 = 11207722802106 := by decide
theorem cert_e2411629779898 : check e2411629779898 [[],[]] .chain = true := by decide
def e2411629779926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e2411629779926 : Closed e2411629779926 ∧ code e2411629779926 = 11207722802134 := by decide
theorem cert_e2411629779926 : check e2411629779926 [[],[]] .chain = true := by decide
def e2411629779930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e2411629779930 : Closed e2411629779930 ∧ code e2411629779930 = 11207722802138 := by decide
theorem cert_e2411629779930 : check e2411629779930 [[],[]] .chain = true := by decide
def e2411629780334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2411629780334 : Closed e2411629780334 ∧ code e2411629780334 = 11207722802542 := by decide
theorem cert_e2411629780334 : check e2411629780334 [[],[]] .chain = true := by decide
def e2411629780342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2411629780342 : Closed e2411629780342 ∧ code e2411629780342 = 11207722802550 := by decide
theorem cert_e2411629780342 : check e2411629780342 [[],[]] .chain = true := by decide
def e2411629780654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2411629780654 : Closed e2411629780654 ∧ code e2411629780654 = 11207722802862 := by decide
theorem cert_e2411629780654 : check e2411629780654 [[],[]] .chain = true := by decide
def e2411629780666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2411629780666 : Closed e2411629780666 ∧ code e2411629780666 = 11207722802874 := by decide
theorem cert_e2411629780666 : check e2411629780666 [[],[]] .chain = true := by decide
def e2411629780822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2411629780822 : Closed e2411629780822 ∧ code e2411629780822 = 11207722803030 := by decide
theorem cert_e2411629780822 : check e2411629780822 [[],[]] .chain = true := by decide
def e2411629780826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2411629780826 : Closed e2411629780826 ∧ code e2411629780826 = 11207722803034 := by decide
theorem cert_e2411629780826 : check e2411629780826 [[],[]] .chain = true := by decide
def e2411629782894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2411629782894 : Closed e2411629782894 ∧ code e2411629782894 = 11207722805102 := by decide
theorem cert_e2411629782894 : check e2411629782894 [[],[]] .chain = true := by decide
def e2411629782902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2411629782902 : Closed e2411629782902 ∧ code e2411629782902 = 11207722805110 := by decide
theorem cert_e2411629782902 : check e2411629782902 [[],[]] .chain = true := by decide
def e2411629782966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2411629782966 : Closed e2411629782966 ∧ code e2411629782966 = 11207722805174 := by decide
theorem cert_e2411629782966 : check e2411629782966 [[],[]] .chain = true := by decide
def e2411629784302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629784302 : Closed e2411629784302 ∧ code e2411629784302 = 11207722806510 := by decide
theorem cert_e2411629784302 : check e2411629784302 [[],[]] .chain = true := by decide
def e2411629784310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629784310 : Closed e2411629784310 ∧ code e2411629784310 = 11207722806518 := by decide
theorem cert_e2411629784310 : check e2411629784310 [[],[]] .chain = true := by decide
def e2411629784694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2411629784694 : Closed e2411629784694 ∧ code e2411629784694 = 11207722806902 := by decide
theorem cert_e2411629784694 : check e2411629784694 [[],[]] .chain = true := by decide
def e2411629785966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2411629785966 : Closed e2411629785966 ∧ code e2411629785966 = 11207722808174 := by decide
theorem cert_e2411629785966 : check e2411629785966 [[],[]] .chain = true := by decide
def e2411629785974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2411629785974 : Closed e2411629785974 ∧ code e2411629785974 = 11207722808182 := by decide
theorem cert_e2411629785974 : check e2411629785974 [[],[]] .chain = true := by decide
def e2411629786030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2411629786030 : Closed e2411629786030 ∧ code e2411629786030 = 11207722808238 := by decide
theorem cert_e2411629786030 : check e2411629786030 [[],[]] .chain = true := by decide
def e2411629786042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2411629786042 : Closed e2411629786042 ∧ code e2411629786042 = 11207722808250 := by decide
theorem cert_e2411629786042 : check e2411629786042 [[],[]] .chain = true := by decide
def e2411629786070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2411629786070 : Closed e2411629786070 ∧ code e2411629786070 = 11207722808278 := by decide
theorem cert_e2411629786070 : check e2411629786070 [[],[]] .chain = true := by decide
def e2411629786074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2411629786074 : Closed e2411629786074 ∧ code e2411629786074 = 11207722808282 := by decide
theorem cert_e2411629786074 : check e2411629786074 [[],[]] .chain = true := by decide
def e2411629786350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629786350 : Closed e2411629786350 ∧ code e2411629786350 = 11207722808558 := by decide
theorem cert_e2411629786350 : check e2411629786350 [[],[]] .chain = true := by decide
def e2411629786358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629786358 : Closed e2411629786358 ∧ code e2411629786358 = 11207722808566 := by decide
theorem cert_e2411629786358 : check e2411629786358 [[],[]] .chain = true := by decide
def e2411629786734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629786734 : Closed e2411629786734 ∧ code e2411629786734 = 11207722808942 := by decide
theorem cert_e2411629786734 : check e2411629786734 [[],[]] .chain = true := by decide
def e2411629786746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629786746 : Closed e2411629786746 ∧ code e2411629786746 = 11207722808954 := by decide
theorem cert_e2411629786746 : check e2411629786746 [[],[]] .chain = true := by decide
def e2411629786934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629786934 : Closed e2411629786934 ∧ code e2411629786934 = 11207722809142 := by decide
theorem cert_e2411629786934 : check e2411629786934 [[],[]] .chain = true := by decide
def e2411629786938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629786938 : Closed e2411629786938 ∧ code e2411629786938 = 11207722809146 := by decide
theorem cert_e2411629786938 : check e2411629786938 [[],[]] .chain = true := by decide
def e2411629787374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2411629787374 : Closed e2411629787374 ∧ code e2411629787374 = 11207722809582 := by decide
theorem cert_e2411629787374 : check e2411629787374 [[],[]] .chain = true := by decide
def e2411629787382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2411629787382 : Closed e2411629787382 ∧ code e2411629787382 = 11207722809590 := by decide
theorem cert_e2411629787382 : check e2411629787382 [[],[]] .chain = true := by decide
def e2411629787566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2411629787566 : Closed e2411629787566 ∧ code e2411629787566 = 11207722809774 := by decide
theorem cert_e2411629787566 : check e2411629787566 [[],[]] .chain = true := by decide
def e2411629787578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2411629787578 : Closed e2411629787578 ∧ code e2411629787578 = 11207722809786 := by decide
theorem cert_e2411629787578 : check e2411629787578 [[],[]] .chain = true := by decide
def e2411629787626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2411629787626 : Closed e2411629787626 ∧ code e2411629787626 = 11207722809834 := by decide
theorem cert_e2411629787626 : check e2411629787626 [[],[]] .chain = true := by decide
def e2411629787758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629787758 : Closed e2411629787758 ∧ code e2411629787758 = 11207722809966 := by decide
theorem cert_e2411629787758 : check e2411629787758 [[],[]] .chain = true := by decide
def e2411629787770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629787770 : Closed e2411629787770 ∧ code e2411629787770 = 11207722809978 := by decide
theorem cert_e2411629787770 : check e2411629787770 [[],[]] .chain = true := by decide
def e2411629787934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2411629787934 : Closed e2411629787934 ∧ code e2411629787934 = 11207722810142 := by decide
theorem cert_e2411629787934 : check e2411629787934 [[],[]] .chain = true := by decide
def e2411629788046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2411629788046 : Closed e2411629788046 ∧ code e2411629788046 = 11207722810254 := by decide
theorem cert_e2411629788046 : check e2411629788046 [[],[]] .chain = true := by decide
def e2411629788058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629788058 : Closed e2411629788058 ∧ code e2411629788058 = 11207722810266 := by decide
theorem cert_e2411629788058 : check e2411629788058 [[],[]] .chain = true := by decide
def e2411629788278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2411629788278 : Closed e2411629788278 ∧ code e2411629788278 = 11207722810486 := by decide
theorem cert_e2411629788278 : check e2411629788278 [[],[]] .chain = true := by decide
def e2411629788374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2411629788374 : Closed e2411629788374 ∧ code e2411629788374 = 11207722810582 := by decide
theorem cert_e2411629788374 : check e2411629788374 [[],[]] .chain = true := by decide
def e2411629788378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2411629788378 : Closed e2411629788378 ∧ code e2411629788378 = 11207722810586 := by decide
theorem cert_e2411629788378 : check e2411629788378 [[],[]] .chain = true := by decide
def e2411629788394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2411629788394 : Closed e2411629788394 ∧ code e2411629788394 = 11207722810602 := by decide
theorem cert_e2411629788394 : check e2411629788394 [[],[]] .chain = true := by decide
def e2411629788470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629788470 : Closed e2411629788470 ∧ code e2411629788470 = 11207722810678 := by decide
theorem cert_e2411629788470 : check e2411629788470 [[],[]] .chain = true := by decide
def e2411629788474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629788474 : Closed e2411629788474 ∧ code e2411629788474 = 11207722810682 := by decide
theorem cert_e2411629788474 : check e2411629788474 [[],[]] .chain = true := by decide
def e2411629788558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2411629788558 : Closed e2411629788558 ∧ code e2411629788558 = 11207722810766 := by decide
theorem cert_e2411629788558 : check e2411629788558 [[],[]] .chain = true := by decide
def e2411629788570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629788570 : Closed e2411629788570 ∧ code e2411629788570 = 11207722810778 := by decide
theorem cert_e2411629788570 : check e2411629788570 [[],[]] .chain = true := by decide
def e2411629798254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2411629798254 : Closed e2411629798254 ∧ code e2411629798254 = 11207722820462 := by decide
theorem cert_e2411629798254 : check e2411629798254 [[],[]] .chain = true := by decide
def e2411629798262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2411629798262 : Closed e2411629798262 ∧ code e2411629798262 = 11207722820470 := by decide
theorem cert_e2411629798262 : check e2411629798262 [[],[]] .chain = true := by decide
def e2411629798318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2411629798318 : Closed e2411629798318 ∧ code e2411629798318 = 11207722820526 := by decide
theorem cert_e2411629798318 : check e2411629798318 [[],[]] .chain = true := by decide
end Blc.Floor43
