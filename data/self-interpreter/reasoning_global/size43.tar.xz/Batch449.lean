import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422377518918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422377518918 : Closed e2422377518918 ∧ code e2422377518918 = 11218470541126 := by decide
theorem cert_e2422377518918 : check e2422377518918 [[],[]] .smaller = true := by decide
def e2422377518942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2422377518942 : Closed e2422377518942 ∧ code e2422377518942 = 11218470541150 := by decide
theorem cert_e2422377518942 : check e2422377518942 [[],[]] .three = true := by decide
def e2422377518970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2422377518970 : Closed e2422377518970 ∧ code e2422377518970 = 11218470541178 := by decide
theorem cert_e2422377518970 : check e2422377518970 [[],[]] .three = true := by decide
def e2422377518986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422377518986 : Closed e2422377518986 ∧ code e2422377518986 = 11218470541194 := by decide
theorem cert_e2422377518986 : check e2422377518986 [[],[]] .smaller = true := by decide
def e2422377519010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422377519010 : Closed e2422377519010 ∧ code e2422377519010 = 11218470541218 := by decide
theorem cert_e2422377519010 : check e2422377519010 [[],[]] .smaller = true := by decide
def e2422377519022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e2422377519022 : Closed e2422377519022 ∧ code e2422377519022 = 11218470541230 := by decide
theorem cert_e2422377519022 : check e2422377519022 [[],[]] .smaller = true := by decide
def e2422377519034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e2422377519034 : Closed e2422377519034 ∧ code e2422377519034 = 11218470541242 := by decide
theorem cert_e2422377519034 : check e2422377519034 [[],[]] .smaller = true := by decide
def e2422377519062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2422377519062 : Closed e2422377519062 ∧ code e2422377519062 = 11218470541270 := by decide
theorem cert_e2422377519062 : check e2422377519062 [[],[]] .three = true := by decide
def e2422377519066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2422377519066 : Closed e2422377519066 ∧ code e2422377519066 = 11218470541274 := by decide
theorem cert_e2422377519066 : check e2422377519066 [[],[]] .three = true := by decide
def e2422377519130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422377519130 : Closed e2422377519130 ∧ code e2422377519130 = 11218470541338 := by decide
theorem cert_e2422377519130 : check e2422377519130 [[],[]] .smaller = true := by decide
def e2422377519166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422377519166 : Closed e2422377519166 ∧ code e2422377519166 = 11218470541374 := by decide
theorem cert_e2422377519166 : check e2422377519166 [[],[]] .smaller = true := by decide
def e2422377519214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422377519214 : Closed e2422377519214 ∧ code e2422377519214 = 11218470541422 := by decide
theorem cert_e2422377519214 : check e2422377519214 [[],[]] .smaller = true := by decide
def e2422377519222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422377519222 : Closed e2422377519222 ∧ code e2422377519222 = 11218470541430 := by decide
theorem cert_e2422377519222 : check e2422377519222 [[],[]] .smaller = true := by decide
def e2422377519226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422377519226 : Closed e2422377519226 ∧ code e2422377519226 = 11218470541434 := by decide
theorem cert_e2422377519226 : check e2422377519226 [[],[]] .smaller = true := by decide
def e2422377519466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422377519466 : Closed e2422377519466 ∧ code e2422377519466 = 11218470541674 := by decide
theorem cert_e2422377519466 : check e2422377519466 [[],[]] .smaller = true := by decide
def e2422377519490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422377519490 : Closed e2422377519490 ∧ code e2422377519490 = 11218470541698 := by decide
theorem cert_e2422377519490 : check e2422377519490 [[],[]] .smaller = true := by decide
def e2422377519502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422377519502 : Closed e2422377519502 ∧ code e2422377519502 = 11218470541710 := by decide
theorem cert_e2422377519502 : check e2422377519502 [[],[]] .smaller = true := by decide
def e2422377519514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377519514 : Closed e2422377519514 ∧ code e2422377519514 = 11218470541722 := by decide
theorem cert_e2422377519514 : check e2422377519514 [[],[]] .smaller = true := by decide
def e2422377519558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422377519558 : Closed e2422377519558 ∧ code e2422377519558 = 11218470541766 := by decide
theorem cert_e2422377519558 : check e2422377519558 [[],[]] .smaller = true := by decide
def e2422377519582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422377519582 : Closed e2422377519582 ∧ code e2422377519582 = 11218470541790 := by decide
theorem cert_e2422377519582 : check e2422377519582 [[],[]] .three = true := by decide
def e2422377519586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422377519586 : Closed e2422377519586 ∧ code e2422377519586 = 11218470541794 := by decide
theorem cert_e2422377519586 : check e2422377519586 [[],[]] .smaller = true := by decide
def e2422377519598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422377519598 : Closed e2422377519598 ∧ code e2422377519598 = 11218470541806 := by decide
theorem cert_e2422377519598 : check e2422377519598 [[],[]] .smaller = true := by decide
def e2422377519606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422377519606 : Closed e2422377519606 ∧ code e2422377519606 = 11218470541814 := by decide
theorem cert_e2422377519606 : check e2422377519606 [[],[]] .three = true := by decide
def e2422377520182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377520182 : Closed e2422377520182 ∧ code e2422377520182 = 11218470542390 := by decide
theorem cert_e2422377520182 : check e2422377520182 [[],[]] .smaller = true := by decide
def e2422377520186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377520186 : Closed e2422377520186 ∧ code e2422377520186 = 11218470542394 := by decide
theorem cert_e2422377520186 : check e2422377520186 [[],[]] .smaller = true := by decide
def e2422377520326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422377520326 : Closed e2422377520326 ∧ code e2422377520326 = 11218470542534 := by decide
theorem cert_e2422377520326 : check e2422377520326 [[],[]] .smaller = true := by decide
def e2422377520350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422377520350 : Closed e2422377520350 ∧ code e2422377520350 = 11218470542558 := by decide
theorem cert_e2422377520350 : check e2422377520350 [[],[]] .three = true := by decide
def e2422377520378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422377520378 : Closed e2422377520378 ∧ code e2422377520378 = 11218470542586 := by decide
theorem cert_e2422377520378 : check e2422377520378 [[],[]] .three = true := by decide
def e2422377520654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422377520654 : Closed e2422377520654 ∧ code e2422377520654 = 11218470542862 := by decide
theorem cert_e2422377520654 : check e2422377520654 [[],[]] .smaller = true := by decide
def e2422377520702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2422377520702 : Closed e2422377520702 ∧ code e2422377520702 = 11218470542910 := by decide
theorem cert_e2422377520702 : check e2422377520702 [[],[]] .three = true := by decide
def e2422377520738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422377520738 : Closed e2422377520738 ∧ code e2422377520738 = 11218470542946 := by decide
theorem cert_e2422377520738 : check e2422377520738 [[],[]] .smaller = true := by decide
def e2422377520750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377520750 : Closed e2422377520750 ∧ code e2422377520750 = 11218470542958 := by decide
theorem cert_e2422377520750 : check e2422377520750 [[],[]] .smaller = true := by decide
def e2422377520762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377520762 : Closed e2422377520762 ∧ code e2422377520762 = 11218470542970 := by decide
theorem cert_e2422377520762 : check e2422377520762 [[],[]] .smaller = true := by decide
def e2422377520926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2422377520926 : Closed e2422377520926 ∧ code e2422377520926 = 11218470543134 := by decide
theorem cert_e2422377520926 : check e2422377520926 [[],[]] .three = true := by decide
def e2422377520950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377520950 : Closed e2422377520950 ∧ code e2422377520950 = 11218470543158 := by decide
theorem cert_e2422377520950 : check e2422377520950 [[],[]] .three = true := by decide
def e2422377520954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377520954 : Closed e2422377520954 ∧ code e2422377520954 = 11218470543162 := by decide
theorem cert_e2422377520954 : check e2422377520954 [[],[]] .three = true := by decide
def e2422377530302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2422377530302 : Closed e2422377530302 ∧ code e2422377530302 = 11218470552510 := by decide
theorem cert_e2422377530302 : check e2422377530302 [[],[]] .three = true := by decide
def e2422377530358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2422377530358 : Closed e2422377530358 ∧ code e2422377530358 = 11218470552566 := by decide
theorem cert_e2422377530358 : check e2422377530358 [[],[]] .three = true := by decide
def e2422377532182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422377532182 : Closed e2422377532182 ∧ code e2422377532182 = 11218470554390 := by decide
theorem cert_e2422377532182 : check e2422377532182 [[],[]] .smaller = true := by decide
def e2422377532254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2422377532254 : Closed e2422377532254 ∧ code e2422377532254 = 11218470554462 := by decide
theorem cert_e2422377532254 : check e2422377532254 [[],[]] .three = true := by decide
def e2422377532258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422377532258 : Closed e2422377532258 ∧ code e2422377532258 = 11218470554466 := by decide
theorem cert_e2422377532258 : check e2422377532258 [[],[]] .smaller = true := by decide
def e2422377532270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422377532270 : Closed e2422377532270 ∧ code e2422377532270 = 11218470554478 := by decide
theorem cert_e2422377532270 : check e2422377532270 [[],[]] .smaller = true := by decide
def e2422377532278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422377532278 : Closed e2422377532278 ∧ code e2422377532278 = 11218470554486 := by decide
theorem cert_e2422377532278 : check e2422377532278 [[],[]] .smaller = true := by decide
def e2422377532282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2422377532282 : Closed e2422377532282 ∧ code e2422377532282 = 11218470554490 := by decide
theorem cert_e2422377532282 : check e2422377532282 [[],[]] .three = true := by decide
def e2422377532298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422377532298 : Closed e2422377532298 ∧ code e2422377532298 = 11218470554506 := by decide
theorem cert_e2422377532298 : check e2422377532298 [[],[]] .smaller = true := by decide
def e2422377532322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422377532322 : Closed e2422377532322 ∧ code e2422377532322 = 11218470554530 := by decide
theorem cert_e2422377532322 : check e2422377532322 [[],[]] .smaller = true := by decide
def e2422377532334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422377532334 : Closed e2422377532334 ∧ code e2422377532334 = 11218470554542 := by decide
theorem cert_e2422377532334 : check e2422377532334 [[],[]] .smaller = true := by decide
def e2422377532346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422377532346 : Closed e2422377532346 ∧ code e2422377532346 = 11218470554554 := by decide
theorem cert_e2422377532346 : check e2422377532346 [[],[]] .smaller = true := by decide
def e2422377532374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422377532374 : Closed e2422377532374 ∧ code e2422377532374 = 11218470554582 := by decide
theorem cert_e2422377532374 : check e2422377532374 [[],[]] .smaller = true := by decide
def e2422377532378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422377532378 : Closed e2422377532378 ∧ code e2422377532378 = 11218470554586 := by decide
theorem cert_e2422377532378 : check e2422377532378 [[],[]] .smaller = true := by decide
def e2422377532394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2422377532394 : Closed e2422377532394 ∧ code e2422377532394 = 11218470554602 := by decide
theorem cert_e2422377532394 : check e2422377532394 [[],[]] .three = true := by decide
def e2422377532446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422377532446 : Closed e2422377532446 ∧ code e2422377532446 = 11218470554654 := by decide
theorem cert_e2422377532446 : check e2422377532446 [[],[]] .smaller = true := by decide
def e2422377532638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422377532638 : Closed e2422377532638 ∧ code e2422377532638 = 11218470554846 := by decide
theorem cert_e2422377532638 : check e2422377532638 [[],[]] .three = true := by decide
def e2422377532642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422377532642 : Closed e2422377532642 ∧ code e2422377532642 = 11218470554850 := by decide
theorem cert_e2422377532642 : check e2422377532642 [[],[]] .smaller = true := by decide
def e2422377532654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422377532654 : Closed e2422377532654 ∧ code e2422377532654 = 11218470554862 := by decide
theorem cert_e2422377532654 : check e2422377532654 [[],[]] .smaller = true := by decide
def e2422377532662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422377532662 : Closed e2422377532662 ∧ code e2422377532662 = 11218470554870 := by decide
theorem cert_e2422377532662 : check e2422377532662 [[],[]] .smaller = true := by decide
def e2422377532666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422377532666 : Closed e2422377532666 ∧ code e2422377532666 = 11218470554874 := by decide
theorem cert_e2422377532666 : check e2422377532666 [[],[]] .three = true := by decide
def e2422377532942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422377532942 : Closed e2422377532942 ∧ code e2422377532942 = 11218470555150 := by decide
theorem cert_e2422377532942 : check e2422377532942 [[],[]] .smaller = true := by decide
def e2422377532990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2422377532990 : Closed e2422377532990 ∧ code e2422377532990 = 11218470555198 := by decide
theorem cert_e2422377532990 : check e2422377532990 [[],[]] .three = true := by decide
def e2422377533026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422377533026 : Closed e2422377533026 ∧ code e2422377533026 = 11218470555234 := by decide
theorem cert_e2422377533026 : check e2422377533026 [[],[]] .smaller = true := by decide
def e2422377533038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377533038 : Closed e2422377533038 ∧ code e2422377533038 = 11218470555246 := by decide
theorem cert_e2422377533038 : check e2422377533038 [[],[]] .smaller = true := by decide
def e2422377533050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377533050 : Closed e2422377533050 ∧ code e2422377533050 = 11218470555258 := by decide
theorem cert_e2422377533050 : check e2422377533050 [[],[]] .smaller = true := by decide
def e2422377533238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377533238 : Closed e2422377533238 ∧ code e2422377533238 = 11218470555446 := by decide
theorem cert_e2422377533238 : check e2422377533238 [[],[]] .smaller = true := by decide
def e2422377533242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377533242 : Closed e2422377533242 ∧ code e2422377533242 = 11218470555450 := by decide
theorem cert_e2422377533242 : check e2422377533242 [[],[]] .smaller = true := by decide
def e2422377533326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2422377533326 : Closed e2422377533326 ∧ code e2422377533326 = 11218470555534 := by decide
theorem cert_e2422377533326 : check e2422377533326 [[],[]] .three = true := by decide
def e2422377533338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377533338 : Closed e2422377533338 ∧ code e2422377533338 = 11218470555546 := by decide
theorem cert_e2422377533338 : check e2422377533338 [[],[]] .three = true := by decide
def e2422377538014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422377538014 : Closed e2422377538014 ∧ code e2422377538014 = 11218470560222 := by decide
theorem cert_e2422377538014 : check e2422377538014 [[],[]] .three = true := by decide
def e2422377538030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e2422377538030 : Closed e2422377538030 ∧ code e2422377538030 = 11218470560238 := by decide
theorem cert_e2422377538030 : check e2422377538030 [[],[]] .three = true := by decide
def e2422377538038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422377538038 : Closed e2422377538038 ∧ code e2422377538038 = 11218470560246 := by decide
theorem cert_e2422377538038 : check e2422377538038 [[],[]] .three = true := by decide
def e2422377538954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422377538954 : Closed e2422377538954 ∧ code e2422377538954 = 11218470561162 := by decide
theorem cert_e2422377538954 : check e2422377538954 [[],[]] .three = true := by decide
def e2422377538978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422377538978 : Closed e2422377538978 ∧ code e2422377538978 = 11218470561186 := by decide
theorem cert_e2422377538978 : check e2422377538978 [[],[]] .three = true := by decide
def e2422377538990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422377538990 : Closed e2422377538990 ∧ code e2422377538990 = 11218470561198 := by decide
theorem cert_e2422377538990 : check e2422377538990 [[],[]] .three = true := by decide
def e2422377538998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2422377538998 : Closed e2422377538998 ∧ code e2422377538998 = 11218470561206 := by decide
theorem cert_e2422377538998 : check e2422377538998 [[],[]] .three = true := by decide
def e2422377539002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422377539002 : Closed e2422377539002 ∧ code e2422377539002 = 11218470561210 := by decide
theorem cert_e2422377539002 : check e2422377539002 [[],[]] .three = true := by decide
def e2422377539030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2422377539030 : Closed e2422377539030 ∧ code e2422377539030 = 11218470561238 := by decide
theorem cert_e2422377539030 : check e2422377539030 [[],[]] .three = true := by decide
def e2422377539034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2422377539034 : Closed e2422377539034 ∧ code e2422377539034 = 11218470561242 := by decide
theorem cert_e2422377539034 : check e2422377539034 [[],[]] .three = true := by decide
def e2422377539050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422377539050 : Closed e2422377539050 ∧ code e2422377539050 = 11218470561258 := by decide
theorem cert_e2422377539050 : check e2422377539050 [[],[]] .three = true := by decide
def e2422377539086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422377539086 : Closed e2422377539086 ∧ code e2422377539086 = 11218470561294 := by decide
theorem cert_e2422377539086 : check e2422377539086 [[],[]] .three = true := by decide
def e2422377539098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377539098 : Closed e2422377539098 ∧ code e2422377539098 = 11218470561306 := by decide
theorem cert_e2422377539098 : check e2422377539098 [[],[]] .three = true := by decide
def e2422377539134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2422377539134 : Closed e2422377539134 ∧ code e2422377539134 = 11218470561342 := by decide
theorem cert_e2422377539134 : check e2422377539134 [[],[]] .three = true := by decide
def e2422377539170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422377539170 : Closed e2422377539170 ∧ code e2422377539170 = 11218470561378 := by decide
theorem cert_e2422377539170 : check e2422377539170 [[],[]] .three = true := by decide
def e2422377539182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377539182 : Closed e2422377539182 ∧ code e2422377539182 = 11218470561390 := by decide
theorem cert_e2422377539182 : check e2422377539182 [[],[]] .three = true := by decide
def e2422377539190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422377539190 : Closed e2422377539190 ∧ code e2422377539190 = 11218470561398 := by decide
theorem cert_e2422377539190 : check e2422377539190 [[],[]] .three = true := by decide
def e2422377539194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377539194 : Closed e2422377539194 ∧ code e2422377539194 = 11218470561402 := by decide
theorem cert_e2422377539194 : check e2422377539194 [[],[]] .three = true := by decide
def e2422377539358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422377539358 : Closed e2422377539358 ∧ code e2422377539358 = 11218470561566 := by decide
theorem cert_e2422377539358 : check e2422377539358 [[],[]] .three = true := by decide
def e2422377539382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377539382 : Closed e2422377539382 ∧ code e2422377539382 = 11218470561590 := by decide
theorem cert_e2422377539382 : check e2422377539382 [[],[]] .three = true := by decide
def e2422377539386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377539386 : Closed e2422377539386 ∧ code e2422377539386 = 11218470561594 := by decide
theorem cert_e2422377539386 : check e2422377539386 [[],[]] .three = true := by decide
def e2422377539470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422377539470 : Closed e2422377539470 ∧ code e2422377539470 = 11218470561678 := by decide
theorem cert_e2422377539470 : check e2422377539470 [[],[]] .three = true := by decide
def e2422377539482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377539482 : Closed e2422377539482 ∧ code e2422377539482 = 11218470561690 := by decide
theorem cert_e2422377539482 : check e2422377539482 [[],[]] .three = true := by decide
def e2422377539526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2422377539526 : Closed e2422377539526 ∧ code e2422377539526 = 11218470561734 := by decide
theorem cert_e2422377539526 : check e2422377539526 [[],[]] .three = true := by decide
def e2422377831358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 0) (.var 2)) (.var 4)))))))))
theorem wire_e2422377831358 : Closed e2422377831358 ∧ code e2422377831358 = 11218470853566 := by decide
theorem cert_e2422377831358 : check e2422377831358 [[],[]] .three = true := by decide
def e2422377831406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem wire_e2422377831406 : Closed e2422377831406 ∧ code e2422377831406 = 11218470853614 := by decide
private def t_e2422377831406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 0) (.var 4)) (.var 2)))))))))
theorem cert_e2422377831406 : ¬ IsSelfInterpreter e2422377831406 :=
  wSource (t := t_e2422377831406) (replay_sound (ps := []) (t := e2422377831406) (by decide)) (by decide)
def e2422377832126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 2) (.var 0)) (.var 4)))))))))
theorem wire_e2422377832126 : Closed e2422377832126 ∧ code e2422377832126 = 11218470854334 := by decide
theorem cert_e2422377832126 : check e2422377832126 [[],[]] .three = true := by decide
def e2422377832186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 2) (.var 4)) (.var 0)))))))))
theorem wire_e2422377832186 : Closed e2422377832186 ∧ code e2422377832186 = 11218470854394 := by decide
theorem cert_e2422377832186 : check e2422377832186 [[],[]] .three = true := by decide
def e2422377832366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem wire_e2422377832366 : Closed e2422377832366 ∧ code e2422377832366 = 11218470854574 := by decide
private def t_e2422377832366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 4) (.var 0)) (.var 2)))))))))
theorem cert_e2422377832366 : ¬ IsSelfInterpreter e2422377832366 :=
  wSource (t := t_e2422377832366) (replay_sound (ps := []) (t := e2422377832366) (by decide)) (by decide)
def e2422377832378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 4) (.var 2)) (.var 0)))))))))
theorem wire_e2422377832378 : Closed e2422377832378 ∧ code e2422377832378 = 11218470854586 := by decide
theorem cert_e2422377832378 : check e2422377832378 [[],[]] .three = true := by decide
def e2422377834430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 0) (.app (.var 2) (.var 4))))))))))
theorem wire_e2422377834430 : Closed e2422377834430 ∧ code e2422377834430 = 11218470856638 := by decide
theorem cert_e2422377834430 : check e2422377834430 [[],[]] .three = true := by decide
def e2422377834478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 0) (.app (.var 4) (.var 2))))))))))
theorem wire_e2422377834478 : Closed e2422377834478 ∧ code e2422377834478 = 11218470856686 := by decide
theorem cert_e2422377834478 : check e2422377834478 [[],[]] .three = true := by decide
def e2422377839038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422377839038 : Closed e2422377839038 ∧ code e2422377839038 = 11218470861246 := by decide
theorem cert_e2422377839038 : check e2422377839038 [[],[]] .three = true := by decide
def e2422377839098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422377839098 : Closed e2422377839098 ∧ code e2422377839098 = 11218470861306 := by decide
theorem cert_e2422377839098 : check e2422377839098 [[],[]] .three = true := by decide
def e2422377840238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 4) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377840238 : Closed e2422377840238 ∧ code e2422377840238 = 11218470862446 := by decide
theorem cert_e2422377840238 : check e2422377840238 [[],[]] .three = true := by decide
def e2422377840250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 4) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377840250 : Closed e2422377840250 ∧ code e2422377840250 = 11218470862458 := by decide
theorem cert_e2422377840250 : check e2422377840250 [[],[]] .three = true := by decide
def e2422377880174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422377880174 : Closed e2422377880174 ∧ code e2422377880174 = 11218470902382 := by decide
theorem cert_e2422377880174 : check e2422377880174 [[],[]] .three = true := by decide
def e2422377880186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422377880186 : Closed e2422377880186 ∧ code e2422377880186 = 11218470902394 := by decide
theorem cert_e2422377880186 : check e2422377880186 [[],[]] .three = true := by decide
def e2422377896110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422377896110 : Closed e2422377896110 ∧ code e2422377896110 = 11218470918318 := by decide
theorem cert_e2422377896110 : check e2422377896110 [[],[]] .three = true := by decide
def e2422377896118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e2422377896118 : Closed e2422377896118 ∧ code e2422377896118 = 11218470918326 := by decide
theorem cert_e2422377896118 : check e2422377896118 [[],[]] .three = true := by decide
def e2422377896122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422377896122 : Closed e2422377896122 ∧ code e2422377896122 = 11218470918330 := by decide
theorem cert_e2422377896122 : check e2422377896122 [[],[]] .three = true := by decide
def e2422377896150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e2422377896150 : Closed e2422377896150 ∧ code e2422377896150 = 11218470918358 := by decide
theorem cert_e2422377896150 : check e2422377896150 [[],[]] .three = true := by decide
def e2422377896154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e2422377896154 : Closed e2422377896154 ∧ code e2422377896154 = 11218470918362 := by decide
theorem cert_e2422377896154 : check e2422377896154 [[],[]] .three = true := by decide
def e2422377896170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422377896170 : Closed e2422377896170 ∧ code e2422377896170 = 11218470918378 := by decide
theorem cert_e2422377896170 : check e2422377896170 [[],[]] .three = true := by decide
def e2422377896494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422377896494 : Closed e2422377896494 ∧ code e2422377896494 = 11218470918702 := by decide
theorem cert_e2422377896494 : check e2422377896494 [[],[]] .three = true := by decide
def e2422377896502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422377896502 : Closed e2422377896502 ∧ code e2422377896502 = 11218470918710 := by decide
theorem cert_e2422377896502 : check e2422377896502 [[],[]] .three = true := by decide
def e2422377896506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422377896506 : Closed e2422377896506 ∧ code e2422377896506 = 11218470918714 := by decide
theorem cert_e2422377896506 : check e2422377896506 [[],[]] .three = true := by decide
def e2422377896590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422377896590 : Closed e2422377896590 ∧ code e2422377896590 = 11218470918798 := by decide
theorem cert_e2422377896590 : check e2422377896590 [[],[]] .three = true := by decide
def e2422377896646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422377896646 : Closed e2422377896646 ∧ code e2422377896646 = 11218470918854 := by decide
theorem cert_e2422377896646 : check e2422377896646 [[],[]] .three = true := by decide
def e2422377896670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2422377896670 : Closed e2422377896670 ∧ code e2422377896670 = 11218470918878 := by decide
theorem cert_e2422377896670 : check e2422377896670 [[],[]] .three = true := by decide
def e2422377896674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422377896674 : Closed e2422377896674 ∧ code e2422377896674 = 11218470918882 := by decide
theorem cert_e2422377896674 : check e2422377896674 [[],[]] .three = true := by decide
def e2422377896686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e2422377896686 : Closed e2422377896686 ∧ code e2422377896686 = 11218470918894 := by decide
theorem cert_e2422377896686 : check e2422377896686 [[],[]] .three = true := by decide
def e2422377896694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2422377896694 : Closed e2422377896694 ∧ code e2422377896694 = 11218470918902 := by decide
theorem cert_e2422377896694 : check e2422377896694 [[],[]] .three = true := by decide
def e2422377896726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422377896726 : Closed e2422377896726 ∧ code e2422377896726 = 11218470918934 := by decide
theorem cert_e2422377896726 : check e2422377896726 [[],[]] .three = true := by decide
def e2422377896730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422377896730 : Closed e2422377896730 ∧ code e2422377896730 = 11218470918938 := by decide
theorem cert_e2422377896730 : check e2422377896730 [[],[]] .three = true := by decide
def e2422377896774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422377896774 : Closed e2422377896774 ∧ code e2422377896774 = 11218470918982 := by decide
theorem cert_e2422377896774 : check e2422377896774 [[],[]] .three = true := by decide
def e2422377896798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2422377896798 : Closed e2422377896798 ∧ code e2422377896798 = 11218470919006 := by decide
theorem cert_e2422377896798 : check e2422377896798 [[],[]] .three = true := by decide
def e2422377896802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422377896802 : Closed e2422377896802 ∧ code e2422377896802 = 11218470919010 := by decide
theorem cert_e2422377896802 : check e2422377896802 [[],[]] .three = true := by decide
def e2422377896814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e2422377896814 : Closed e2422377896814 ∧ code e2422377896814 = 11218470919022 := by decide
theorem cert_e2422377896814 : check e2422377896814 [[],[]] .three = true := by decide
def e2422377896822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e2422377896822 : Closed e2422377896822 ∧ code e2422377896822 = 11218470919030 := by decide
theorem cert_e2422377896822 : check e2422377896822 [[],[]] .three = true := by decide
def e2422377896826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2422377896826 : Closed e2422377896826 ∧ code e2422377896826 = 11218470919034 := by decide
theorem cert_e2422377896826 : check e2422377896826 [[],[]] .three = true := by decide
def e2422377896842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422377896842 : Closed e2422377896842 ∧ code e2422377896842 = 11218470919050 := by decide
theorem cert_e2422377896842 : check e2422377896842 [[],[]] .three = true := by decide
def e2422377896866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422377896866 : Closed e2422377896866 ∧ code e2422377896866 = 11218470919074 := by decide
theorem cert_e2422377896866 : check e2422377896866 [[],[]] .three = true := by decide
def e2422377896878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e2422377896878 : Closed e2422377896878 ∧ code e2422377896878 = 11218470919086 := by decide
theorem cert_e2422377896878 : check e2422377896878 [[],[]] .three = true := by decide
def e2422377896886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e2422377896886 : Closed e2422377896886 ∧ code e2422377896886 = 11218470919094 := by decide
theorem cert_e2422377896886 : check e2422377896886 [[],[]] .three = true := by decide
def e2422377896890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e2422377896890 : Closed e2422377896890 ∧ code e2422377896890 = 11218470919098 := by decide
theorem cert_e2422377896890 : check e2422377896890 [[],[]] .three = true := by decide
def e2422377896918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2422377896918 : Closed e2422377896918 ∧ code e2422377896918 = 11218470919126 := by decide
theorem cert_e2422377896918 : check e2422377896918 [[],[]] .three = true := by decide
def e2422377896922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2422377896922 : Closed e2422377896922 ∧ code e2422377896922 = 11218470919130 := by decide
theorem cert_e2422377896922 : check e2422377896922 [[],[]] .three = true := by decide
def e2422377897046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422377897046 : Closed e2422377897046 ∧ code e2422377897046 = 11218470919254 := by decide
theorem cert_e2422377897046 : check e2422377897046 [[],[]] .three = true := by decide
def e2422377897050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422377897050 : Closed e2422377897050 ∧ code e2422377897050 = 11218470919258 := by decide
theorem cert_e2422377897050 : check e2422377897050 [[],[]] .three = true := by decide
def e2422377897066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422377897066 : Closed e2422377897066 ∧ code e2422377897066 = 11218470919274 := by decide
theorem cert_e2422377897066 : check e2422377897066 [[],[]] .three = true := by decide
def e2422377897238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422377897238 : Closed e2422377897238 ∧ code e2422377897238 = 11218470919446 := by decide
theorem cert_e2422377897238 : check e2422377897238 [[],[]] .three = true := by decide
def e2422377897242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422377897242 : Closed e2422377897242 ∧ code e2422377897242 = 11218470919450 := by decide
theorem cert_e2422377897242 : check e2422377897242 [[],[]] .three = true := by decide
def e2422377897286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422377897286 : Closed e2422377897286 ∧ code e2422377897286 = 11218470919494 := by decide
theorem cert_e2422377897286 : check e2422377897286 [[],[]] .three = true := by decide
def e2422377897310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2422377897310 : Closed e2422377897310 ∧ code e2422377897310 = 11218470919518 := by decide
theorem cert_e2422377897310 : check e2422377897310 [[],[]] .three = true := by decide
def e2422377897314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422377897314 : Closed e2422377897314 ∧ code e2422377897314 = 11218470919522 := by decide
theorem cert_e2422377897314 : check e2422377897314 [[],[]] .three = true := by decide
def e2422377897326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422377897326 : Closed e2422377897326 ∧ code e2422377897326 = 11218470919534 := by decide
theorem cert_e2422377897326 : check e2422377897326 [[],[]] .three = true := by decide
def e2422377897334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422377897334 : Closed e2422377897334 ∧ code e2422377897334 = 11218470919542 := by decide
theorem cert_e2422377897334 : check e2422377897334 [[],[]] .three = true := by decide
def e2422377897338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2422377897338 : Closed e2422377897338 ∧ code e2422377897338 = 11218470919546 := by decide
theorem cert_e2422377897338 : check e2422377897338 [[],[]] .three = true := by decide
def e2422377897354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422377897354 : Closed e2422377897354 ∧ code e2422377897354 = 11218470919562 := by decide
theorem cert_e2422377897354 : check e2422377897354 [[],[]] .three = true := by decide
def e2422377897378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422377897378 : Closed e2422377897378 ∧ code e2422377897378 = 11218470919586 := by decide
theorem cert_e2422377897378 : check e2422377897378 [[],[]] .three = true := by decide
def e2422377897390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422377897390 : Closed e2422377897390 ∧ code e2422377897390 = 11218470919598 := by decide
theorem cert_e2422377897390 : check e2422377897390 [[],[]] .three = true := by decide
def e2422377897402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422377897402 : Closed e2422377897402 ∧ code e2422377897402 = 11218470919610 := by decide
theorem cert_e2422377897402 : check e2422377897402 [[],[]] .three = true := by decide
def e2422377897430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422377897430 : Closed e2422377897430 ∧ code e2422377897430 = 11218470919638 := by decide
theorem cert_e2422377897430 : check e2422377897430 [[],[]] .three = true := by decide
def e2422377897434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422377897434 : Closed e2422377897434 ∧ code e2422377897434 = 11218470919642 := by decide
theorem cert_e2422377897434 : check e2422377897434 [[],[]] .three = true := by decide
def e2422377897450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2422377897450 : Closed e2422377897450 ∧ code e2422377897450 = 11218470919658 := by decide
theorem cert_e2422377897450 : check e2422377897450 [[],[]] .three = true := by decide
def e2422377897514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422377897514 : Closed e2422377897514 ∧ code e2422377897514 = 11218470919722 := by decide
theorem cert_e2422377897514 : check e2422377897514 [[],[]] .three = true := by decide
def e2422377897610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422377897610 : Closed e2422377897610 ∧ code e2422377897610 = 11218470919818 := by decide
theorem cert_e2422377897610 : check e2422377897610 [[],[]] .three = true := by decide
def e2422377897634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422377897634 : Closed e2422377897634 ∧ code e2422377897634 = 11218470919842 := by decide
theorem cert_e2422377897634 : check e2422377897634 [[],[]] .three = true := by decide
def e2422377897646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422377897646 : Closed e2422377897646 ∧ code e2422377897646 = 11218470919854 := by decide
theorem cert_e2422377897646 : check e2422377897646 [[],[]] .three = true := by decide
def e2422377897654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2422377897654 : Closed e2422377897654 ∧ code e2422377897654 = 11218470919862 := by decide
theorem cert_e2422377897654 : check e2422377897654 [[],[]] .three = true := by decide
def e2422377897658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422377897658 : Closed e2422377897658 ∧ code e2422377897658 = 11218470919866 := by decide
theorem cert_e2422377897658 : check e2422377897658 [[],[]] .three = true := by decide
def e2422377897686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2422377897686 : Closed e2422377897686 ∧ code e2422377897686 = 11218470919894 := by decide
theorem cert_e2422377897686 : check e2422377897686 [[],[]] .three = true := by decide
def e2422377897690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2422377897690 : Closed e2422377897690 ∧ code e2422377897690 = 11218470919898 := by decide
theorem cert_e2422377897690 : check e2422377897690 [[],[]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422377831406
#print axioms Blc.Floor43.cert_e2422377832366
