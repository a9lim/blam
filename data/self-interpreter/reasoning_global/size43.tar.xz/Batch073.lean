import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e759404638058 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e759404638058 : Closed e759404638058 ∧ code e759404638058 = 9555497660266 := by decide
theorem cert_e759404638058 : check e759404638058 [] .sourceHead = true := by decide
def e759404639086 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e759404639086 : Closed e759404639086 ∧ code e759404639086 = 9555497661294 := by decide
theorem cert_e759404639086 : check e759404639086 [] .sourceHead = true := by decide
def e759404639094 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e759404639094 : Closed e759404639094 ∧ code e759404639094 = 9555497661302 := by decide
theorem cert_e759404639094 : check e759404639094 [] .sourceHead = true := by decide
def e759404639150 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e759404639150 : Closed e759404639150 ∧ code e759404639150 = 9555497661358 := by decide
theorem cert_e759404639150 : check e759404639150 [] .sourceHead = true := by decide
def e759404639162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e759404639162 : Closed e759404639162 ∧ code e759404639162 = 9555497661370 := by decide
theorem cert_e759404639162 : check e759404639162 [] .sourceHead = true := by decide
def e759404639190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e759404639190 : Closed e759404639190 ∧ code e759404639190 = 9555497661398 := by decide
theorem cert_e759404639190 : check e759404639190 [] .sourceHead = true := by decide
def e759404639194 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e759404639194 : Closed e759404639194 ∧ code e759404639194 = 9555497661402 := by decide
theorem cert_e759404639194 : check e759404639194 [] .sourceHead = true := by decide
def e759404639470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e759404639470 : Closed e759404639470 ∧ code e759404639470 = 9555497661678 := by decide
theorem cert_e759404639470 : check e759404639470 [] .sourceHead = true := by decide
def e759404639478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e759404639478 : Closed e759404639478 ∧ code e759404639478 = 9555497661686 := by decide
theorem cert_e759404639478 : check e759404639478 [] .sourceHead = true := by decide
def e759404639854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e759404639854 : Closed e759404639854 ∧ code e759404639854 = 9555497662062 := by decide
theorem cert_e759404639854 : check e759404639854 [] .sourceHead = true := by decide
def e759404639866 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e759404639866 : Closed e759404639866 ∧ code e759404639866 = 9555497662074 := by decide
theorem cert_e759404639866 : check e759404639866 [] .sourceHead = true := by decide
def e759404640054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e759404640054 : Closed e759404640054 ∧ code e759404640054 = 9555497662262 := by decide
theorem cert_e759404640054 : check e759404640054 [] .sourceHead = true := by decide
def e759404640058 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e759404640058 : Closed e759404640058 ∧ code e759404640058 = 9555497662266 := by decide
theorem cert_e759404640058 : check e759404640058 [] .sourceHead = true := by decide
def e759404640494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e759404640494 : Closed e759404640494 ∧ code e759404640494 = 9555497662702 := by decide
theorem cert_e759404640494 : check e759404640494 [] .sourceHead = true := by decide
def e759404640502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e759404640502 : Closed e759404640502 ∧ code e759404640502 = 9555497662710 := by decide
theorem cert_e759404640502 : check e759404640502 [] .sourceHead = true := by decide
def e759404640686 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e759404640686 : Closed e759404640686 ∧ code e759404640686 = 9555497662894 := by decide
theorem cert_e759404640686 : check e759404640686 [] .sourceHead = true := by decide
def e759404640698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e759404640698 : Closed e759404640698 ∧ code e759404640698 = 9555497662906 := by decide
theorem cert_e759404640698 : check e759404640698 [] .sourceHead = true := by decide
def e759404640746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e759404640746 : Closed e759404640746 ∧ code e759404640746 = 9555497662954 := by decide
theorem cert_e759404640746 : check e759404640746 [] .sourceHead = true := by decide
def e759404640878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e759404640878 : Closed e759404640878 ∧ code e759404640878 = 9555497663086 := by decide
theorem cert_e759404640878 : check e759404640878 [] .sourceHead = true := by decide
def e759404640890 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e759404640890 : Closed e759404640890 ∧ code e759404640890 = 9555497663098 := by decide
theorem cert_e759404640890 : check e759404640890 [] .sourceHead = true := by decide
def e759404641054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e759404641054 : Closed e759404641054 ∧ code e759404641054 = 9555497663262 := by decide
theorem cert_e759404641054 : check e759404641054 [] .sourceHead = true := by decide
def e759404641166 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e759404641166 : Closed e759404641166 ∧ code e759404641166 = 9555497663374 := by decide
theorem cert_e759404641166 : check e759404641166 [] .sourceHead = true := by decide
def e759404641178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e759404641178 : Closed e759404641178 ∧ code e759404641178 = 9555497663386 := by decide
theorem cert_e759404641178 : check e759404641178 [] .sourceHead = true := by decide
def e759404641398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e759404641398 : Closed e759404641398 ∧ code e759404641398 = 9555497663606 := by decide
theorem cert_e759404641398 : check e759404641398 [] .sourceHead = true := by decide
def e759404641494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e759404641494 : Closed e759404641494 ∧ code e759404641494 = 9555497663702 := by decide
theorem cert_e759404641494 : check e759404641494 [] .sourceHead = true := by decide
def e759404641498 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e759404641498 : Closed e759404641498 ∧ code e759404641498 = 9555497663706 := by decide
theorem cert_e759404641498 : check e759404641498 [] .sourceHead = true := by decide
def e759404641514 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e759404641514 : Closed e759404641514 ∧ code e759404641514 = 9555497663722 := by decide
theorem cert_e759404641514 : check e759404641514 [] .sourceHead = true := by decide
def e759404641590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e759404641590 : Closed e759404641590 ∧ code e759404641590 = 9555497663798 := by decide
theorem cert_e759404641590 : check e759404641590 [] .sourceHead = true := by decide
def e759404641594 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e759404641594 : Closed e759404641594 ∧ code e759404641594 = 9555497663802 := by decide
theorem cert_e759404641594 : check e759404641594 [] .sourceHead = true := by decide
def e759404641678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e759404641678 : Closed e759404641678 ∧ code e759404641678 = 9555497663886 := by decide
theorem cert_e759404641678 : check e759404641678 [] .sourceHead = true := by decide
def e759404641690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e759404641690 : Closed e759404641690 ∧ code e759404641690 = 9555497663898 := by decide
theorem cert_e759404641690 : check e759404641690 [] .sourceHead = true := by decide
def e759404643294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e759404643294 : Closed e759404643294 ∧ code e759404643294 = 9555497665502 := by decide
theorem cert_e759404643294 : check e759404643294 [] .sourceHead = true := by decide
def e759404643310 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e759404643310 : Closed e759404643310 ∧ code e759404643310 = 9555497665518 := by decide
theorem cert_e759404643310 : check e759404643310 [] .sourceHead = true := by decide
def e759404645230 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e759404645230 : Closed e759404645230 ∧ code e759404645230 = 9555497667438 := by decide
theorem cert_e759404645230 : check e759404645230 [] .sourceHead = true := by decide
def e759404645238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e759404645238 : Closed e759404645238 ∧ code e759404645238 = 9555497667446 := by decide
theorem cert_e759404645238 : check e759404645238 [] .sourceHead = true := by decide
def e759404645294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e759404645294 : Closed e759404645294 ∧ code e759404645294 = 9555497667502 := by decide
theorem cert_e759404645294 : check e759404645294 [] .sourceHead = true := by decide
def e759404645306 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e759404645306 : Closed e759404645306 ∧ code e759404645306 = 9555497667514 := by decide
theorem cert_e759404645306 : check e759404645306 [] .sourceHead = true := by decide
def e759404645334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e759404645334 : Closed e759404645334 ∧ code e759404645334 = 9555497667542 := by decide
theorem cert_e759404645334 : check e759404645334 [] .sourceHead = true := by decide
def e759404645338 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e759404645338 : Closed e759404645338 ∧ code e759404645338 = 9555497667546 := by decide
theorem cert_e759404645338 : check e759404645338 [] .sourceHead = true := by decide
def e759404645614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e759404645614 : Closed e759404645614 ∧ code e759404645614 = 9555497667822 := by decide
theorem cert_e759404645614 : check e759404645614 [] .sourceHead = true := by decide
def e759404645622 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e759404645622 : Closed e759404645622 ∧ code e759404645622 = 9555497667830 := by decide
theorem cert_e759404645622 : check e759404645622 [] .sourceHead = true := by decide
def e759404645998 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404645998 : Closed e759404645998 ∧ code e759404645998 = 9555497668206 := by decide
theorem cert_e759404645998 : check e759404645998 [] .sourceHead = true := by decide
def e759404646010 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404646010 : Closed e759404646010 ∧ code e759404646010 = 9555497668218 := by decide
theorem cert_e759404646010 : check e759404646010 [] .sourceHead = true := by decide
def e759404646198 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e759404646198 : Closed e759404646198 ∧ code e759404646198 = 9555497668406 := by decide
theorem cert_e759404646198 : check e759404646198 [] .sourceHead = true := by decide
def e759404646202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e759404646202 : Closed e759404646202 ∧ code e759404646202 = 9555497668410 := by decide
theorem cert_e759404646202 : check e759404646202 [] .sourceHead = true := by decide
def e759404650974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e759404650974 : Closed e759404650974 ∧ code e759404650974 = 9555497673182 := by decide
theorem cert_e759404650974 : check e759404650974 [] .sourceHead = true := by decide
def e759404650998 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e759404650998 : Closed e759404650998 ∧ code e759404650998 = 9555497673206 := by decide
theorem cert_e759404650998 : check e759404650998 [] .sourceHead = true := by decide
def e759404651950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e759404651950 : Closed e759404651950 ∧ code e759404651950 = 9555497674158 := by decide
theorem cert_e759404651950 : check e759404651950 [] .sourceHead = true := by decide
def e759404651962 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e759404651962 : Closed e759404651962 ∧ code e759404651962 = 9555497674170 := by decide
theorem cert_e759404651962 : check e759404651962 [] .sourceHead = true := by decide
def e759404652010 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e759404652010 : Closed e759404652010 ∧ code e759404652010 = 9555497674218 := by decide
theorem cert_e759404652010 : check e759404652010 [] .sourceHead = true := by decide
def e759404652142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404652142 : Closed e759404652142 ∧ code e759404652142 = 9555497674350 := by decide
theorem cert_e759404652142 : check e759404652142 [] .sourceHead = true := by decide
def e759404652154 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404652154 : Closed e759404652154 ∧ code e759404652154 = 9555497674362 := by decide
theorem cert_e759404652154 : check e759404652154 [] .sourceHead = true := by decide
def e759404652318 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e759404652318 : Closed e759404652318 ∧ code e759404652318 = 9555497674526 := by decide
theorem cert_e759404652318 : check e759404652318 [] .sourceHead = true := by decide
def e759404652430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e759404652430 : Closed e759404652430 ∧ code e759404652430 = 9555497674638 := by decide
theorem cert_e759404652430 : check e759404652430 [] .sourceHead = true := by decide
def e759404652442 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404652442 : Closed e759404652442 ∧ code e759404652442 = 9555497674650 := by decide
theorem cert_e759404652442 : check e759404652442 [] .sourceHead = true := by decide
def e759404654830 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e759404654830 : Closed e759404654830 ∧ code e759404654830 = 9555497677038 := by decide
theorem cert_e759404654830 : check e759404654830 [] .sourceHead = true := by decide
def e759404654838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e759404654838 : Closed e759404654838 ∧ code e759404654838 = 9555497677046 := by decide
theorem cert_e759404654838 : check e759404654838 [] .sourceHead = true := by decide
def e759404655318 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e759404655318 : Closed e759404655318 ∧ code e759404655318 = 9555497677526 := by decide
theorem cert_e759404655318 : check e759404655318 [] .sourceHead = true := by decide
def e759404655322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e759404655322 : Closed e759404655322 ∧ code e759404655322 = 9555497677530 := by decide
theorem cert_e759404655322 : check e759404655322 [] .sourceHead = true := by decide
def e759404655338 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e759404655338 : Closed e759404655338 ∧ code e759404655338 = 9555497677546 := by decide
theorem cert_e759404655338 : check e759404655338 [] .sourceHead = true := by decide
def e759404655414 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e759404655414 : Closed e759404655414 ∧ code e759404655414 = 9555497677622 := by decide
theorem cert_e759404655414 : check e759404655414 [] .sourceHead = true := by decide
def e759404655418 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e759404655418 : Closed e759404655418 ∧ code e759404655418 = 9555497677626 := by decide
theorem cert_e759404655418 : check e759404655418 [] .sourceHead = true := by decide
def e759404655502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e759404655502 : Closed e759404655502 ∧ code e759404655502 = 9555497677710 := by decide
theorem cert_e759404655502 : check e759404655502 [] .sourceHead = true := by decide
def e759404655514 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404655514 : Closed e759404655514 ∧ code e759404655514 = 9555497677722 := by decide
theorem cert_e759404655514 : check e759404655514 [] .sourceHead = true := by decide
def e759404660590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e759404660590 : Closed e759404660590 ∧ code e759404660590 = 9555497682798 := by decide
theorem cert_e759404660590 : check e759404660590 [] .sourceHead = true := by decide
def e759404660602 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e759404660602 : Closed e759404660602 ∧ code e759404660602 = 9555497682810 := by decide
theorem cert_e759404660602 : check e759404660602 [] .sourceHead = true := by decide
def e759404660698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e759404660698 : Closed e759404660698 ∧ code e759404660698 = 9555497682906 := by decide
theorem cert_e759404660698 : check e759404660698 [] .sourceHead = true := by decide
def e759404661998 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e759404661998 : Closed e759404661998 ∧ code e759404661998 = 9555497684206 := by decide
theorem cert_e759404661998 : check e759404661998 [] .sourceHead = true := by decide
def e759404662006 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e759404662006 : Closed e759404662006 ∧ code e759404662006 = 9555497684214 := by decide
theorem cert_e759404662006 : check e759404662006 [] .sourceHead = true := by decide
def e759404662382 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e759404662382 : Closed e759404662382 ∧ code e759404662382 = 9555497684590 := by decide
theorem cert_e759404662382 : check e759404662382 [] .sourceHead = true := by decide
def e759404662394 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e759404662394 : Closed e759404662394 ∧ code e759404662394 = 9555497684602 := by decide
theorem cert_e759404662394 : check e759404662394 [] .sourceHead = true := by decide
def e759404662582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e759404662582 : Closed e759404662582 ∧ code e759404662582 = 9555497684790 := by decide
theorem cert_e759404662582 : check e759404662582 [] .sourceHead = true := by decide
def e759404662586 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e759404662586 : Closed e759404662586 ∧ code e759404662586 = 9555497684794 := by decide
theorem cert_e759404662586 : check e759404662586 [] .sourceHead = true := by decide
def e759404664494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e759404664494 : Closed e759404664494 ∧ code e759404664494 = 9555497686702 := by decide
theorem cert_e759404664494 : check e759404664494 [] .sourceHead = true := by decide
def e759404664506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e759404664506 : Closed e759404664506 ∧ code e759404664506 = 9555497686714 := by decide
theorem cert_e759404664506 : check e759404664506 [] .sourceHead = true := by decide
def e759404664554 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e759404664554 : Closed e759404664554 ∧ code e759404664554 = 9555497686762 := by decide
theorem cert_e759404664554 : check e759404664554 [] .sourceHead = true := by decide
def e759404664746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e759404664746 : Closed e759404664746 ∧ code e759404664746 = 9555497686954 := by decide
theorem cert_e759404664746 : check e759404664746 [] .sourceHead = true := by decide
def e759404665070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e759404665070 : Closed e759404665070 ∧ code e759404665070 = 9555497687278 := by decide
theorem cert_e759404665070 : check e759404665070 [] .sourceHead = true := by decide
def e759404665078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e759404665078 : Closed e759404665078 ∧ code e759404665078 = 9555497687286 := by decide
theorem cert_e759404665078 : check e759404665078 [] .sourceHead = true := by decide
def e759404665262 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e759404665262 : Closed e759404665262 ∧ code e759404665262 = 9555497687470 := by decide
theorem cert_e759404665262 : check e759404665262 [] .sourceHead = true := by decide
def e759404665274 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e759404665274 : Closed e759404665274 ∧ code e759404665274 = 9555497687482 := by decide
theorem cert_e759404665274 : check e759404665274 [] .sourceHead = true := by decide
def e759404665322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e759404665322 : Closed e759404665322 ∧ code e759404665322 = 9555497687530 := by decide
theorem cert_e759404665322 : check e759404665322 [] .sourceHead = true := by decide
def e759404665454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e759404665454 : Closed e759404665454 ∧ code e759404665454 = 9555497687662 := by decide
theorem cert_e759404665454 : check e759404665454 [] .sourceHead = true := by decide
def e759404665466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e759404665466 : Closed e759404665466 ∧ code e759404665466 = 9555497687674 := by decide
theorem cert_e759404665466 : check e759404665466 [] .sourceHead = true := by decide
def e759404665630 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e759404665630 : Closed e759404665630 ∧ code e759404665630 = 9555497687838 := by decide
theorem cert_e759404665630 : check e759404665630 [] .sourceHead = true := by decide
def e759404665742 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e759404665742 : Closed e759404665742 ∧ code e759404665742 = 9555497687950 := by decide
theorem cert_e759404665742 : check e759404665742 [] .sourceHead = true := by decide
def e759404665754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e759404665754 : Closed e759404665754 ∧ code e759404665754 = 9555497687962 := by decide
theorem cert_e759404665754 : check e759404665754 [] .sourceHead = true := by decide
def e759404665966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e759404665966 : Closed e759404665966 ∧ code e759404665966 = 9555497688174 := by decide
theorem cert_e759404665966 : check e759404665966 [] .sourceHead = true := by decide
def e759404665978 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e759404665978 : Closed e759404665978 ∧ code e759404665978 = 9555497688186 := by decide
theorem cert_e759404665978 : check e759404665978 [] .sourceHead = true := by decide
def e759404666142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e759404666142 : Closed e759404666142 ∧ code e759404666142 = 9555497688350 := by decide
theorem cert_e759404666142 : check e759404666142 [] .sourceHead = true := by decide
def e759404666310 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e759404666310 : Closed e759404666310 ∧ code e759404666310 = 9555497688518 := by decide
theorem cert_e759404666310 : check e759404666310 [] .sourceHead = true := by decide
def e759404666422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e759404666422 : Closed e759404666422 ∧ code e759404666422 = 9555497688630 := by decide
theorem cert_e759404666422 : check e759404666422 [] .sourceHead = true := by decide
def e759404666426 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e759404666426 : Closed e759404666426 ∧ code e759404666426 = 9555497688634 := by decide
theorem cert_e759404666426 : check e759404666426 [] .sourceHead = true := by decide
def e759404666474 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e759404666474 : Closed e759404666474 ∧ code e759404666474 = 9555497688682 := by decide
theorem cert_e759404666474 : check e759404666474 [] .sourceHead = true := by decide
def e759404666510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e759404666510 : Closed e759404666510 ∧ code e759404666510 = 9555497688718 := by decide
theorem cert_e759404666510 : check e759404666510 [] .sourceHead = true := by decide
def e759404666522 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e759404666522 : Closed e759404666522 ∧ code e759404666522 = 9555497688730 := by decide
theorem cert_e759404666522 : check e759404666522 [] .sourceHead = true := by decide
def e759404666566 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e759404666566 : Closed e759404666566 ∧ code e759404666566 = 9555497688774 := by decide
theorem cert_e759404666566 : check e759404666566 [] .sourceHead = true := by decide
def e759404667358 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e759404667358 : Closed e759404667358 ∧ code e759404667358 = 9555497689566 := by decide
theorem cert_e759404667358 : check e759404667358 [] .sourceHead = true := by decide
def e759404667382 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e759404667382 : Closed e759404667382 ∧ code e759404667382 = 9555497689590 := by decide
theorem cert_e759404667382 : check e759404667382 [] .sourceHead = true := by decide
def e759404668334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e759404668334 : Closed e759404668334 ∧ code e759404668334 = 9555497690542 := by decide
theorem cert_e759404668334 : check e759404668334 [] .sourceHead = true := by decide
def e759404668346 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e759404668346 : Closed e759404668346 ∧ code e759404668346 = 9555497690554 := by decide
theorem cert_e759404668346 : check e759404668346 [] .sourceHead = true := by decide
def e759404668394 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e759404668394 : Closed e759404668394 ∧ code e759404668394 = 9555497690602 := by decide
theorem cert_e759404668394 : check e759404668394 [] .sourceHead = true := by decide
def e759404668526 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404668526 : Closed e759404668526 ∧ code e759404668526 = 9555497690734 := by decide
theorem cert_e759404668526 : check e759404668526 [] .sourceHead = true := by decide
def e759404668538 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404668538 : Closed e759404668538 ∧ code e759404668538 = 9555497690746 := by decide
theorem cert_e759404668538 : check e759404668538 [] .sourceHead = true := by decide
def e759404668702 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e759404668702 : Closed e759404668702 ∧ code e759404668702 = 9555497690910 := by decide
theorem cert_e759404668702 : check e759404668702 [] .sourceHead = true := by decide
def e759404668814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e759404668814 : Closed e759404668814 ∧ code e759404668814 = 9555497691022 := by decide
theorem cert_e759404668814 : check e759404668814 [] .sourceHead = true := by decide
def e759404668826 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404668826 : Closed e759404668826 ∧ code e759404668826 = 9555497691034 := by decide
theorem cert_e759404668826 : check e759404668826 [] .sourceHead = true := by decide
def e759404671774 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e759404671774 : Closed e759404671774 ∧ code e759404671774 = 9555497693982 := by decide
theorem cert_e759404671774 : check e759404671774 [] .sourceHead = true := by decide
def e759404671942 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e759404671942 : Closed e759404671942 ∧ code e759404671942 = 9555497694150 := by decide
theorem cert_e759404671942 : check e759404671942 [] .sourceHead = true := by decide
def e759404673142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e759404673142 : Closed e759404673142 ∧ code e759404673142 = 9555497695350 := by decide
theorem cert_e759404673142 : check e759404673142 [] .sourceHead = true := by decide
def e759404673386 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e759404673386 : Closed e759404673386 ∧ code e759404673386 = 9555497695594 := by decide
theorem cert_e759404673386 : check e759404673386 [] .sourceHead = true := by decide
def e759404673422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e759404673422 : Closed e759404673422 ∧ code e759404673422 = 9555497695630 := by decide
theorem cert_e759404673422 : check e759404673422 [] .sourceHead = true := by decide
def e759404673434 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404673434 : Closed e759404673434 ∧ code e759404673434 = 9555497695642 := by decide
theorem cert_e759404673434 : check e759404673434 [] .sourceHead = true := by decide
def e759404673478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e759404673478 : Closed e759404673478 ∧ code e759404673478 = 9555497695686 := by decide
theorem cert_e759404673478 : check e759404673478 [] .sourceHead = true := by decide
def e759404676022 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e759404676022 : Closed e759404676022 ∧ code e759404676022 = 9555497698230 := by decide
theorem cert_e759404676022 : check e759404676022 [] .sourceHead = true := by decide
def e759404676026 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e759404676026 : Closed e759404676026 ∧ code e759404676026 = 9555497698234 := by decide
theorem cert_e759404676026 : check e759404676026 [] .sourceHead = true := by decide
def e759404676058 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e759404676058 : Closed e759404676058 ∧ code e759404676058 = 9555497698266 := by decide
theorem cert_e759404676058 : check e759404676058 [] .sourceHead = true := by decide
def e759404676726 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e759404676726 : Closed e759404676726 ∧ code e759404676726 = 9555497698934 := by decide
theorem cert_e759404676726 : check e759404676726 [] .sourceHead = true := by decide
def e759404676918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e759404676918 : Closed e759404676918 ∧ code e759404676918 = 9555497699126 := by decide
theorem cert_e759404676918 : check e759404676918 [] .sourceHead = true := by decide
def e759404676922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e759404676922 : Closed e759404676922 ∧ code e759404676922 = 9555497699130 := by decide
theorem cert_e759404676922 : check e759404676922 [] .sourceHead = true := by decide
def e759404677974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e759404677974 : Closed e759404677974 ∧ code e759404677974 = 9555497700182 := by decide
theorem cert_e759404677974 : check e759404677974 [] .sourceHead = true := by decide
def e759404677978 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e759404677978 : Closed e759404677978 ∧ code e759404677978 = 9555497700186 := by decide
theorem cert_e759404677978 : check e759404677978 [] .sourceHead = true := by decide
def e759404677994 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e759404677994 : Closed e759404677994 ∧ code e759404677994 = 9555497700202 := by decide
theorem cert_e759404677994 : check e759404677994 [] .sourceHead = true := by decide
def e759404678058 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e759404678058 : Closed e759404678058 ∧ code e759404678058 = 9555497700266 := by decide
theorem cert_e759404678058 : check e759404678058 [] .sourceHead = true := by decide
def e759404678262 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e759404678262 : Closed e759404678262 ∧ code e759404678262 = 9555497700470 := by decide
theorem cert_e759404678262 : check e759404678262 [] .sourceHead = true := by decide
def e759404678358 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e759404678358 : Closed e759404678358 ∧ code e759404678358 = 9555497700566 := by decide
theorem cert_e759404678358 : check e759404678358 [] .sourceHead = true := by decide
def e759404678362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e759404678362 : Closed e759404678362 ∧ code e759404678362 = 9555497700570 := by decide
theorem cert_e759404678362 : check e759404678362 [] .sourceHead = true := by decide
def e759404678378 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e759404678378 : Closed e759404678378 ∧ code e759404678378 = 9555497700586 := by decide
theorem cert_e759404678378 : check e759404678378 [] .sourceHead = true := by decide
def e759404678454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e759404678454 : Closed e759404678454 ∧ code e759404678454 = 9555497700662 := by decide
theorem cert_e759404678454 : check e759404678454 [] .sourceHead = true := by decide
def e759404678458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e759404678458 : Closed e759404678458 ∧ code e759404678458 = 9555497700666 := by decide
theorem cert_e759404678458 : check e759404678458 [] .sourceHead = true := by decide
def e759404678542 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e759404678542 : Closed e759404678542 ∧ code e759404678542 = 9555497700750 := by decide
theorem cert_e759404678542 : check e759404678542 [] .sourceHead = true := by decide
def e759404678554 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e759404678554 : Closed e759404678554 ∧ code e759404678554 = 9555497700762 := by decide
theorem cert_e759404678554 : check e759404678554 [] .sourceHead = true := by decide
def e759404678710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e759404678710 : Closed e759404678710 ∧ code e759404678710 = 9555497700918 := by decide
theorem cert_e759404678710 : check e759404678710 [] .sourceHead = true := by decide
def e759404678714 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e759404678714 : Closed e759404678714 ∧ code e759404678714 = 9555497700922 := by decide
theorem cert_e759404678714 : check e759404678714 [] .sourceHead = true := by decide
def e759404678762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e759404678762 : Closed e759404678762 ∧ code e759404678762 = 9555497700970 := by decide
theorem cert_e759404678762 : check e759404678762 [] .sourceHead = true := by decide
def e759404678798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e759404678798 : Closed e759404678798 ∧ code e759404678798 = 9555497701006 := by decide
theorem cert_e759404678798 : check e759404678798 [] .sourceHead = true := by decide
def e759404678810 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e759404678810 : Closed e759404678810 ∧ code e759404678810 = 9555497701018 := by decide
theorem cert_e759404678810 : check e759404678810 [] .sourceHead = true := by decide
def e759404678854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e759404678854 : Closed e759404678854 ∧ code e759404678854 = 9555497701062 := by decide
theorem cert_e759404678854 : check e759404678854 [] .sourceHead = true := by decide
def e759404679406 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e759404679406 : Closed e759404679406 ∧ code e759404679406 = 9555497701614 := by decide
theorem cert_e759404679406 : check e759404679406 [] .sourceHead = true := by decide
def e759404679414 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e759404679414 : Closed e759404679414 ∧ code e759404679414 = 9555497701622 := by decide
theorem cert_e759404679414 : check e759404679414 [] .sourceHead = true := by decide
def e759404679894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e759404679894 : Closed e759404679894 ∧ code e759404679894 = 9555497702102 := by decide
theorem cert_e759404679894 : check e759404679894 [] .sourceHead = true := by decide
def e759404679898 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e759404679898 : Closed e759404679898 ∧ code e759404679898 = 9555497702106 := by decide
theorem cert_e759404679898 : check e759404679898 [] .sourceHead = true := by decide
def e759404679914 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e759404679914 : Closed e759404679914 ∧ code e759404679914 = 9555497702122 := by decide
theorem cert_e759404679914 : check e759404679914 [] .sourceHead = true := by decide
def e759404679990 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e759404679990 : Closed e759404679990 ∧ code e759404679990 = 9555497702198 := by decide
theorem cert_e759404679990 : check e759404679990 [] .sourceHead = true := by decide
def e759404679994 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e759404679994 : Closed e759404679994 ∧ code e759404679994 = 9555497702202 := by decide
theorem cert_e759404679994 : check e759404679994 [] .sourceHead = true := by decide
def e759404680078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e759404680078 : Closed e759404680078 ∧ code e759404680078 = 9555497702286 := by decide
theorem cert_e759404680078 : check e759404680078 [] .sourceHead = true := by decide
def e759404680090 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404680090 : Closed e759404680090 ∧ code e759404680090 = 9555497702298 := by decide
theorem cert_e759404680090 : check e759404680090 [] .sourceHead = true := by decide
def e759404681334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e759404681334 : Closed e759404681334 ∧ code e759404681334 = 9555497703542 := by decide
theorem cert_e759404681334 : check e759404681334 [] .sourceHead = true := by decide
def e759404681578 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e759404681578 : Closed e759404681578 ∧ code e759404681578 = 9555497703786 := by decide
theorem cert_e759404681578 : check e759404681578 [] .sourceHead = true := by decide
def e759404681614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e759404681614 : Closed e759404681614 ∧ code e759404681614 = 9555497703822 := by decide
theorem cert_e759404681614 : check e759404681614 [] .sourceHead = true := by decide
def e759404681626 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404681626 : Closed e759404681626 ∧ code e759404681626 = 9555497703834 := by decide
theorem cert_e759404681626 : check e759404681626 [] .sourceHead = true := by decide
def e759404681670 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e759404681670 : Closed e759404681670 ∧ code e759404681670 = 9555497703878 := by decide
theorem cert_e759404681670 : check e759404681670 [] .sourceHead = true := by decide
def e759404694382 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e759404694382 : Closed e759404694382 ∧ code e759404694382 = 9555497716590 := by decide
theorem cert_e759404694382 : check e759404694382 [] .sourceHead = true := by decide
def e759404694390 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e759404694390 : Closed e759404694390 ∧ code e759404694390 = 9555497716598 := by decide
theorem cert_e759404694390 : check e759404694390 [] .sourceHead = true := by decide
def e759404694446 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e759404694446 : Closed e759404694446 ∧ code e759404694446 = 9555497716654 := by decide
theorem cert_e759404694446 : check e759404694446 [] .sourceHead = true := by decide
def e759404694458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e759404694458 : Closed e759404694458 ∧ code e759404694458 = 9555497716666 := by decide
theorem cert_e759404694458 : check e759404694458 [] .sourceHead = true := by decide
def e759404694486 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e759404694486 : Closed e759404694486 ∧ code e759404694486 = 9555497716694 := by decide
theorem cert_e759404694486 : check e759404694486 [] .sourceHead = true := by decide
def e759404694490 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e759404694490 : Closed e759404694490 ∧ code e759404694490 = 9555497716698 := by decide
theorem cert_e759404694490 : check e759404694490 [] .sourceHead = true := by decide
def e759404694766 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e759404694766 : Closed e759404694766 ∧ code e759404694766 = 9555497716974 := by decide
theorem cert_e759404694766 : check e759404694766 [] .sourceHead = true := by decide
def e759404694774 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e759404694774 : Closed e759404694774 ∧ code e759404694774 = 9555497716982 := by decide
theorem cert_e759404694774 : check e759404694774 [] .sourceHead = true := by decide
end Blc.Floor43
