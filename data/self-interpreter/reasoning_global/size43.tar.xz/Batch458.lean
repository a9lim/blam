import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406495106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406495106 : Closed e2422406495106 ∧ code e2422406495106 = 11218499517314 := by decide
theorem cert_e2422406495106 : check e2422406495106 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406495118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406495118 : Closed e2422406495118 ∧ code e2422406495118 = 11218499517326 := by decide
theorem cert_e2422406495118 : check e2422406495118 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406495130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406495130 : Closed e2422406495130 ∧ code e2422406495130 = 11218499517338 := by decide
theorem cert_e2422406495130 : check e2422406495130 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406496342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422406496342 : Closed e2422406496342 ∧ code e2422406496342 = 11218499518550 := by decide
theorem cert_e2422406496342 : check e2422406496342 [[],[]] .chain = true := by decide
def e2422406496346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422406496346 : Closed e2422406496346 ∧ code e2422406496346 = 11218499518554 := by decide
theorem cert_e2422406496346 : check e2422406496346 [[],[]] .chain = true := by decide
def e2422406496622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422406496622 : Closed e2422406496622 ∧ code e2422406496622 = 11218499518830 := by decide
theorem cert_e2422406496622 : check e2422406496622 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406496630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422406496630 : Closed e2422406496630 ∧ code e2422406496630 = 11218499518838 := by decide
theorem cert_e2422406496630 : check e2422406496630 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406496694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e2422406496694 : Closed e2422406496694 ∧ code e2422406496694 = 11218499518902 := by decide
theorem cert_e2422406496694 : check e2422406496694 [[],[]] .chain = true := by decide
def e2422406496726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422406496726 : Closed e2422406496726 ∧ code e2422406496726 = 11218499518934 := by decide
theorem cert_e2422406496726 : check e2422406496726 [[],[]] .chain = true := by decide
def e2422406496730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422406496730 : Closed e2422406496730 ∧ code e2422406496730 = 11218499518938 := by decide
theorem cert_e2422406496730 : check e2422406496730 [[],[]] .chain = true := by decide
def e2422406496746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2422406496746 : Closed e2422406496746 ∧ code e2422406496746 = 11218499518954 := by decide
theorem cert_e2422406496746 : check e2422406496746 [[],[]] .chain = true := by decide
def e2422406497110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422406497110 : Closed e2422406497110 ∧ code e2422406497110 = 11218499519318 := by decide
theorem cert_e2422406497110 : check e2422406497110 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406497114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422406497114 : Closed e2422406497114 ∧ code e2422406497114 = 11218499519322 := by decide
theorem cert_e2422406497114 : check e2422406497114 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406497398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406497398 : Closed e2422406497398 ∧ code e2422406497398 = 11218499519606 := by decide
theorem cert_e2422406497398 : check e2422406497398 [[],[]] .chain = true := by decide
def e2422406497494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406497494 : Closed e2422406497494 ∧ code e2422406497494 = 11218499519702 := by decide
theorem cert_e2422406497494 : check e2422406497494 [[],[]] .chain = true := by decide
def e2422406497498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406497498 : Closed e2422406497498 ∧ code e2422406497498 = 11218499519706 := by decide
theorem cert_e2422406497498 : check e2422406497498 [[],[]] .chain = true := by decide
def e2422406497514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406497514 : Closed e2422406497514 ∧ code e2422406497514 = 11218499519722 := by decide
theorem cert_e2422406497514 : check e2422406497514 [[],[]] .chain = true := by decide
def e2422406497590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406497590 : Closed e2422406497590 ∧ code e2422406497590 = 11218499519798 := by decide
theorem cert_e2422406497590 : check e2422406497590 [[],[]] .chain = true := by decide
def e2422406497594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406497594 : Closed e2422406497594 ∧ code e2422406497594 = 11218499519802 := by decide
theorem cert_e2422406497594 : check e2422406497594 [[],[]] .chain = true := by decide
def e2422406497678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406497678 : Closed e2422406497678 ∧ code e2422406497678 = 11218499519886 := by decide
theorem cert_e2422406497678 : check e2422406497678 [[],[]] .chain = true := by decide
def e2422406497690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406497690 : Closed e2422406497690 ∧ code e2422406497690 = 11218499519898 := by decide
theorem cert_e2422406497690 : check e2422406497690 [[],[]] .chain = true := by decide
def e2422406497846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406497846 : Closed e2422406497846 ∧ code e2422406497846 = 11218499520054 := by decide
theorem cert_e2422406497846 : check e2422406497846 [[],[]] .chain = true := by decide
def e2422406497850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406497850 : Closed e2422406497850 ∧ code e2422406497850 = 11218499520058 := by decide
theorem cert_e2422406497850 : check e2422406497850 [[],[]] .chain = true := by decide
def e2422406497934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406497934 : Closed e2422406497934 ∧ code e2422406497934 = 11218499520142 := by decide
theorem cert_e2422406497934 : check e2422406497934 [[],[]] .chain = true := by decide
def e2422406497990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406497990 : Closed e2422406497990 ∧ code e2422406497990 = 11218499520198 := by decide
theorem cert_e2422406497990 : check e2422406497990 [[],[]] .chain = true := by decide
def e2422406498070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406498070 : Closed e2422406498070 ∧ code e2422406498070 = 11218499520278 := by decide
theorem cert_e2422406498070 : check e2422406498070 [[],[]] .chain = true := by decide
def e2422406498074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406498074 : Closed e2422406498074 ∧ code e2422406498074 = 11218499520282 := by decide
theorem cert_e2422406498074 : check e2422406498074 [[],[]] .chain = true := by decide
def e2422406498118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406498118 : Closed e2422406498118 ∧ code e2422406498118 = 11218499520326 := by decide
theorem cert_e2422406498118 : check e2422406498118 [[],[]] .chain = true := by decide
def e2422406498146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406498146 : Closed e2422406498146 ∧ code e2422406498146 = 11218499520354 := by decide
theorem cert_e2422406498146 : check e2422406498146 [[],[]] .chain = true := by decide
def e2422406498158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2422406498158 : Closed e2422406498158 ∧ code e2422406498158 = 11218499520366 := by decide
theorem cert_e2422406498158 : check e2422406498158 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406498166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2422406498166 : Closed e2422406498166 ∧ code e2422406498166 = 11218499520374 := by decide
theorem cert_e2422406498166 : check e2422406498166 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406498230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e2422406498230 : Closed e2422406498230 ∧ code e2422406498230 = 11218499520438 := by decide
theorem cert_e2422406498230 : check e2422406498230 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406499414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422406499414 : Closed e2422406499414 ∧ code e2422406499414 = 11218499521622 := by decide
theorem cert_e2422406499414 : check e2422406499414 [[],[]] .chain = true := by decide
def e2422406499418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422406499418 : Closed e2422406499418 ∧ code e2422406499418 = 11218499521626 := by decide
theorem cert_e2422406499418 : check e2422406499418 [[],[]] .chain = true := by decide
def e2422406499606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406499606 : Closed e2422406499606 ∧ code e2422406499606 = 11218499521814 := by decide
theorem cert_e2422406499606 : check e2422406499606 [[],[]] .chain = true := by decide
def e2422406499682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406499682 : Closed e2422406499682 ∧ code e2422406499682 = 11218499521890 := by decide
theorem cert_e2422406499682 : check e2422406499682 [[],[]] .chain = true := by decide
def e2422406499694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406499694 : Closed e2422406499694 ∧ code e2422406499694 = 11218499521902 := by decide
theorem cert_e2422406499694 : check e2422406499694 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406499702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406499702 : Closed e2422406499702 ∧ code e2422406499702 = 11218499521910 := by decide
theorem cert_e2422406499702 : check e2422406499702 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406499722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406499722 : Closed e2422406499722 ∧ code e2422406499722 = 11218499521930 := by decide
theorem cert_e2422406499722 : check e2422406499722 [[],[]] .chain = true := by decide
def e2422406499746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406499746 : Closed e2422406499746 ∧ code e2422406499746 = 11218499521954 := by decide
theorem cert_e2422406499746 : check e2422406499746 [[],[]] .chain = true := by decide
def e2422406499758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406499758 : Closed e2422406499758 ∧ code e2422406499758 = 11218499521966 := by decide
theorem cert_e2422406499758 : check e2422406499758 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406499766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2422406499766 : Closed e2422406499766 ∧ code e2422406499766 = 11218499521974 := by decide
theorem cert_e2422406499766 : check e2422406499766 [[],[]] .chain = true := by decide
def e2422406499770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406499770 : Closed e2422406499770 ∧ code e2422406499770 = 11218499521978 := by decide
theorem cert_e2422406499770 : check e2422406499770 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406499798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406499798 : Closed e2422406499798 ∧ code e2422406499798 = 11218499522006 := by decide
theorem cert_e2422406499798 : checkPay e2422406499798 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406499802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406499802 : Closed e2422406499802 ∧ code e2422406499802 = 11218499522010 := by decide
theorem cert_e2422406499802 : check e2422406499802 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406499882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406499882 : Closed e2422406499882 ∧ code e2422406499882 = 11218499522090 := by decide
theorem cert_e2422406499882 : check e2422406499882 [[],[]] .chain = true := by decide
def e2422406499978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406499978 : Closed e2422406499978 ∧ code e2422406499978 = 11218499522186 := by decide
theorem cert_e2422406499978 : check e2422406499978 [[],[]] .chain = true := by decide
def e2422406500002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406500002 : Closed e2422406500002 ∧ code e2422406500002 = 11218499522210 := by decide
theorem cert_e2422406500002 : check e2422406500002 [[],[]] .chain = true := by decide
def e2422406500014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406500014 : Closed e2422406500014 ∧ code e2422406500014 = 11218499522222 := by decide
theorem cert_e2422406500014 : check e2422406500014 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406500022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406500022 : Closed e2422406500022 ∧ code e2422406500022 = 11218499522230 := by decide
theorem cert_e2422406500022 : check e2422406500022 [[],[]] .chain = true := by decide
def e2422406500026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406500026 : Closed e2422406500026 ∧ code e2422406500026 = 11218499522234 := by decide
theorem cert_e2422406500026 : check e2422406500026 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406500054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406500054 : Closed e2422406500054 ∧ code e2422406500054 = 11218499522262 := by decide
theorem cert_e2422406500054 : check e2422406500054 [[],[]] .chain = true := by decide
def e2422406500058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406500058 : Closed e2422406500058 ∧ code e2422406500058 = 11218499522266 := by decide
theorem cert_e2422406500058 : check e2422406500058 [[],[]] .chain = true := by decide
def e2422406500074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406500074 : Closed e2422406500074 ∧ code e2422406500074 = 11218499522282 := by decide
theorem cert_e2422406500074 : check e2422406500074 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406500182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406500182 : Closed e2422406500182 ∧ code e2422406500182 = 11218499522390 := by decide
def e2422406500186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406500186 : Closed e2422406500186 ∧ code e2422406500186 = 11218499522394 := by decide
def e2422406500202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406500202 : Closed e2422406500202 ∧ code e2422406500202 = 11218499522410 := by decide
theorem cert_e2422406500202 : check e2422406500202 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406500374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422406500374 : Closed e2422406500374 ∧ code e2422406500374 = 11218499522582 := by decide
theorem cert_e2422406500374 : check e2422406500374 [[],[]] .chain = true := by decide
def e2422406500470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422406500470 : Closed e2422406500470 ∧ code e2422406500470 = 11218499522678 := by decide
theorem cert_e2422406500470 : check e2422406500470 [[],[]] .chain = true := by decide
def e2422406500474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422406500474 : Closed e2422406500474 ∧ code e2422406500474 = 11218499522682 := by decide
theorem cert_e2422406500474 : check e2422406500474 [[],[]] .chain = true := by decide
def e2422406500566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422406500566 : Closed e2422406500566 ∧ code e2422406500566 = 11218499522774 := by decide
theorem cert_e2422406500566 : checkPay e2422406500566 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406500662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406500662 : Closed e2422406500662 ∧ code e2422406500662 = 11218499522870 := by decide
theorem cert_e2422406500662 : check e2422406500662 [[],[]] .chain = true := by decide
def e2422406500666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406500666 : Closed e2422406500666 ∧ code e2422406500666 = 11218499522874 := by decide
theorem cert_e2422406500666 : check e2422406500666 [[],[]] .chain = true := by decide
def e2422406500750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422406500750 : Closed e2422406500750 ∧ code e2422406500750 = 11218499522958 := by decide
theorem cert_e2422406500750 : check e2422406500750 [[],[]] .chain = true := by decide
def e2422406500806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422406500806 : Closed e2422406500806 ∧ code e2422406500806 = 11218499523014 := by decide
theorem cert_e2422406500806 : check e2422406500806 [[],[]] .chain = true := by decide
def e2422406501142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406501142 : Closed e2422406501142 ∧ code e2422406501142 = 11218499523350 := by decide
theorem cert_e2422406501142 : check e2422406501142 [[],[]] .chain = true := by decide
def e2422406501218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406501218 : Closed e2422406501218 ∧ code e2422406501218 = 11218499523426 := by decide
theorem cert_e2422406501218 : check e2422406501218 [[],[]] .chain = true := by decide
def e2422406501230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406501230 : Closed e2422406501230 ∧ code e2422406501230 = 11218499523438 := by decide
theorem cert_e2422406501230 : checkPay e2422406501230 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] 0 [] = true := by decide
def e2422406501238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406501238 : Closed e2422406501238 ∧ code e2422406501238 = 11218499523446 := by decide
theorem cert_e2422406501238 : checkPay e2422406501238 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406501258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406501258 : Closed e2422406501258 ∧ code e2422406501258 = 11218499523466 := by decide
theorem cert_e2422406501258 : check e2422406501258 [[],[]] .chain = true := by decide
def e2422406501282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406501282 : Closed e2422406501282 ∧ code e2422406501282 = 11218499523490 := by decide
theorem cert_e2422406501282 : check e2422406501282 [[],[]] .chain = true := by decide
def e2422406501294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406501294 : Closed e2422406501294 ∧ code e2422406501294 = 11218499523502 := by decide
theorem cert_e2422406501294 : check e2422406501294 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406501302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2422406501302 : Closed e2422406501302 ∧ code e2422406501302 = 11218499523510 := by decide
theorem cert_e2422406501302 : check e2422406501302 [[],[]] .chain = true := by decide
def e2422406501306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406501306 : Closed e2422406501306 ∧ code e2422406501306 = 11218499523514 := by decide
theorem cert_e2422406501306 : check e2422406501306 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406501334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406501334 : Closed e2422406501334 ∧ code e2422406501334 = 11218499523542 := by decide
theorem cert_e2422406501334 : checkPay e2422406501334 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406501338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406501338 : Closed e2422406501338 ∧ code e2422406501338 = 11218499523546 := by decide
theorem cert_e2422406501338 : check e2422406501338 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406501406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2422406501406 : Closed e2422406501406 ∧ code e2422406501406 = 11218499523614 := by decide
theorem cert_e2422406501406 : check e2422406501406 [[],[]] .chain = true := by decide
def e2422406501602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406501602 : Closed e2422406501602 ∧ code e2422406501602 = 11218499523810 := by decide
theorem cert_e2422406501602 : check e2422406501602 [[],[]] .chain = true := by decide
def e2422406501614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406501614 : Closed e2422406501614 ∧ code e2422406501614 = 11218499523822 := by decide
theorem cert_e2422406501614 : check e2422406501614 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406501622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406501622 : Closed e2422406501622 ∧ code e2422406501622 = 11218499523830 := by decide
theorem cert_e2422406501622 : check e2422406501622 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406501890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406501890 : Closed e2422406501890 ∧ code e2422406501890 = 11218499524098 := by decide
theorem cert_e2422406501890 : check e2422406501890 [[],[]] .chain = true := by decide
def e2422406501902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406501902 : Closed e2422406501902 ∧ code e2422406501902 = 11218499524110 := by decide
theorem cert_e2422406501902 : check e2422406501902 [[],[]] .chain = true := by decide
def e2422406501914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406501914 : Closed e2422406501914 ∧ code e2422406501914 = 11218499524122 := by decide
theorem cert_e2422406501914 : check e2422406501914 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406501986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406501986 : Closed e2422406501986 ∧ code e2422406501986 = 11218499524194 := by decide
theorem cert_e2422406501986 : check e2422406501986 [[],[]] .chain = true := by decide
def e2422406501998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406501998 : Closed e2422406501998 ∧ code e2422406501998 = 11218499524206 := by decide
theorem cert_e2422406501998 : check e2422406501998 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406502006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406502006 : Closed e2422406502006 ∧ code e2422406502006 = 11218499524214 := by decide
theorem cert_e2422406502006 : check e2422406502006 [[],[]] .chain = true := by decide
def e2422406502010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406502010 : Closed e2422406502010 ∧ code e2422406502010 = 11218499524218 := by decide
theorem cert_e2422406502010 : check e2422406502010 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406502198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406502198 : Closed e2422406502198 ∧ code e2422406502198 = 11218499524406 := by decide
theorem cert_e2422406502198 : check e2422406502198 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406502202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406502202 : Closed e2422406502202 ∧ code e2422406502202 = 11218499524410 := by decide
theorem cert_e2422406502202 : check e2422406502202 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406502410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406502410 : Closed e2422406502410 ∧ code e2422406502410 = 11218499524618 := by decide
theorem cert_e2422406502410 : check e2422406502410 [[],[]] .chain = true := by decide
def e2422406502446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406502446 : Closed e2422406502446 ∧ code e2422406502446 = 11218499524654 := by decide
theorem cert_e2422406502446 : check e2422406502446 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406502454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406502454 : Closed e2422406502454 ∧ code e2422406502454 = 11218499524662 := by decide
theorem cert_e2422406502454 : check e2422406502454 [[],[]] .chain = true := by decide
def e2422406502458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406502458 : Closed e2422406502458 ∧ code e2422406502458 = 11218499524666 := by decide
theorem cert_e2422406502458 : check e2422406502458 [[],[]] .chain = true := by decide
def e2422406502506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422406502506 : Closed e2422406502506 ∧ code e2422406502506 = 11218499524714 := by decide
theorem cert_e2422406502506 : check e2422406502506 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406502542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406502542 : Closed e2422406502542 ∧ code e2422406502542 = 11218499524750 := by decide
theorem cert_e2422406502542 : check e2422406502542 [[],[]] .chain = true := by decide
def e2422406502554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406502554 : Closed e2422406502554 ∧ code e2422406502554 = 11218499524762 := by decide
theorem cert_e2422406502554 : check e2422406502554 [[],[]] .chain = true := by decide
def e2422406502598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406502598 : Closed e2422406502598 ∧ code e2422406502598 = 11218499524806 := by decide
theorem cert_e2422406502598 : check e2422406502598 [[],[]] .chain = true := by decide
def e2422406502626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406502626 : Closed e2422406502626 ∧ code e2422406502626 = 11218499524834 := by decide
theorem cert_e2422406502626 : check e2422406502626 [[],[]] .chain = true := by decide
def e2422406502638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406502638 : Closed e2422406502638 ∧ code e2422406502638 = 11218499524846 := by decide
theorem cert_e2422406502638 : check e2422406502638 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406502646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406502646 : Closed e2422406502646 ∧ code e2422406502646 = 11218499524854 := by decide
theorem cert_e2422406502646 : check e2422406502646 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406502794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406502794 : Closed e2422406502794 ∧ code e2422406502794 = 11218499525002 := by decide
theorem cert_e2422406502794 : check e2422406502794 [[],[]] .chain = true := by decide
def e2422406502818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406502818 : Closed e2422406502818 ∧ code e2422406502818 = 11218499525026 := by decide
theorem cert_e2422406502818 : check e2422406502818 [[],[]] .chain = true := by decide
def e2422406502830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406502830 : Closed e2422406502830 ∧ code e2422406502830 = 11218499525038 := by decide
theorem cert_e2422406502830 : check e2422406502830 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406502838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422406502838 : Closed e2422406502838 ∧ code e2422406502838 = 11218499525046 := by decide
theorem cert_e2422406502838 : check e2422406502838 [[],[]] .chain = true := by decide
def e2422406502842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406502842 : Closed e2422406502842 ∧ code e2422406502842 = 11218499525050 := by decide
theorem cert_e2422406502842 : check e2422406502842 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406502870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422406502870 : Closed e2422406502870 ∧ code e2422406502870 = 11218499525078 := by decide
theorem cert_e2422406502870 : check e2422406502870 [[],[]] .chain = true := by decide
def e2422406502874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422406502874 : Closed e2422406502874 ∧ code e2422406502874 = 11218499525082 := by decide
theorem cert_e2422406502874 : check e2422406502874 [[],[]] .chain = true := by decide
def e2422406502890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406502890 : Closed e2422406502890 ∧ code e2422406502890 = 11218499525098 := by decide
theorem cert_e2422406502890 : check e2422406502890 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406502914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406502914 : Closed e2422406502914 ∧ code e2422406502914 = 11218499525122 := by decide
theorem cert_e2422406502914 : check e2422406502914 [[],[]] .chain = true := by decide
def e2422406502926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406502926 : Closed e2422406502926 ∧ code e2422406502926 = 11218499525134 := by decide
theorem cert_e2422406502926 : check e2422406502926 [[],[]] .chain = true := by decide
def e2422406502938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406502938 : Closed e2422406502938 ∧ code e2422406502938 = 11218499525146 := by decide
theorem cert_e2422406502938 : check e2422406502938 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406503010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406503010 : Closed e2422406503010 ∧ code e2422406503010 = 11218499525218 := by decide
theorem cert_e2422406503010 : check e2422406503010 [[],[]] .chain = true := by decide
def e2422406503022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406503022 : Closed e2422406503022 ∧ code e2422406503022 = 11218499525230 := by decide
theorem cert_e2422406503022 : check e2422406503022 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406503030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406503030 : Closed e2422406503030 ∧ code e2422406503030 = 11218499525238 := by decide
theorem cert_e2422406503030 : check e2422406503030 [[],[]] .chain = true := by decide
def e2422406503034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406503034 : Closed e2422406503034 ∧ code e2422406503034 = 11218499525242 := by decide
theorem cert_e2422406503034 : check e2422406503034 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406503174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406503174 : Closed e2422406503174 ∧ code e2422406503174 = 11218499525382 := by decide
theorem cert_e2422406503174 : check e2422406503174 [[],[]] .chain = true := by decide
def e2422406503198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406503198 : Closed e2422406503198 ∧ code e2422406503198 = 11218499525406 := by decide
theorem cert_e2422406503198 : check e2422406503198 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406503222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406503222 : Closed e2422406503222 ∧ code e2422406503222 = 11218499525430 := by decide
theorem cert_e2422406503222 : check e2422406503222 [[],[]] .chain = true := by decide
def e2422406503226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406503226 : Closed e2422406503226 ∧ code e2422406503226 = 11218499525434 := by decide
theorem cert_e2422406503226 : check e2422406503226 [[],[]] .chain = true := by decide
def e2422406503298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406503298 : Closed e2422406503298 ∧ code e2422406503298 = 11218499525506 := by decide
theorem cert_e2422406503298 : check e2422406503298 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406503310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406503310 : Closed e2422406503310 ∧ code e2422406503310 = 11218499525518 := by decide
theorem cert_e2422406503310 : check e2422406503310 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406503322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406503322 : Closed e2422406503322 ∧ code e2422406503322 = 11218499525530 := by decide
theorem cert_e2422406503322 : check e2422406503322 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406503446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406503446 : Closed e2422406503446 ∧ code e2422406503446 = 11218499525654 := by decide
theorem cert_e2422406503446 : check e2422406503446 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406503542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406503542 : Closed e2422406503542 ∧ code e2422406503542 = 11218499525750 := by decide
theorem cert_e2422406503542 : check e2422406503542 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406503638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406503638 : Closed e2422406503638 ∧ code e2422406503638 = 11218499525846 := by decide
def e2422406503642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406503642 : Closed e2422406503642 ∧ code e2422406503642 = 11218499525850 := by decide
theorem cert_e2422406503642 : check e2422406503642 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406503658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406503658 : Closed e2422406503658 ∧ code e2422406503658 = 11218499525866 := by decide
theorem cert_e2422406503658 : check e2422406503658 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406503734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406503734 : Closed e2422406503734 ∧ code e2422406503734 = 11218499525942 := by decide
def e2422406503738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406503738 : Closed e2422406503738 ∧ code e2422406503738 = 11218499525946 := by decide
def e2422406503810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406503810 : Closed e2422406503810 ∧ code e2422406503810 = 11218499526018 := by decide
theorem cert_e2422406503810 : check e2422406503810 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406503822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406503822 : Closed e2422406503822 ∧ code e2422406503822 = 11218499526030 := by decide
theorem cert_e2422406503822 : check e2422406503822 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406503834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406503834 : Closed e2422406503834 ∧ code e2422406503834 = 11218499526042 := by decide
theorem cert_e2422406503834 : check e2422406503834 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406513326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406513326 : Closed e2422406513326 ∧ code e2422406513326 = 11218499535534 := by decide
theorem cert_e2422406513326 : check e2422406513326 [[],[]] .chain = true := by decide
def e2422406513338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406513338 : Closed e2422406513338 ∧ code e2422406513338 = 11218499535546 := by decide
theorem cert_e2422406513338 : check e2422406513338 [[],[]] .chain = true := by decide
def e2422406513386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406513386 : Closed e2422406513386 ∧ code e2422406513386 = 11218499535594 := by decide
theorem cert_e2422406513386 : check e2422406513386 [[],[]] .chain = true := by decide
def e2422406515438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2422406515438 : Closed e2422406515438 ∧ code e2422406515438 = 11218499537646 := by decide
theorem cert_e2422406515438 : check e2422406515438 [[],[]] .sourceHead = true := by decide
def e2422406515630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2422406515630 : Closed e2422406515630 ∧ code e2422406515630 = 11218499537838 := by decide
theorem cert_e2422406515630 : check e2422406515630 [[],[]] .sourceHead = true := by decide
def e2422406515642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2422406515642 : Closed e2422406515642 ∧ code e2422406515642 = 11218499537850 := by decide
theorem cert_e2422406515642 : check e2422406515642 [[],[]] .sourceHead = true := by decide
def e2422406516078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406516078 : Closed e2422406516078 ∧ code e2422406516078 = 11218499538286 := by decide
theorem cert_e2422406516078 : check e2422406516078 [[],[]] .chain = true := by decide
def e2422406516086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406516086 : Closed e2422406516086 ∧ code e2422406516086 = 11218499538294 := by decide
theorem cert_e2422406516086 : check e2422406516086 [[],[]] .chain = true := by decide
def e2422406516142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406516142 : Closed e2422406516142 ∧ code e2422406516142 = 11218499538350 := by decide
theorem cert_e2422406516142 : check e2422406516142 [[],[]] .chain = true := by decide
def e2422406516154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406516154 : Closed e2422406516154 ∧ code e2422406516154 = 11218499538362 := by decide
theorem cert_e2422406516154 : check e2422406516154 [[],[]] .chain = true := by decide
def e2422406516182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406516182 : Closed e2422406516182 ∧ code e2422406516182 = 11218499538390 := by decide
theorem cert_e2422406516182 : check e2422406516182 [[],[]] .chain = true := by decide
def e2422406516186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406516186 : Closed e2422406516186 ∧ code e2422406516186 = 11218499538394 := by decide
theorem cert_e2422406516186 : check e2422406516186 [[],[]] .chain = true := by decide
def e2422406516398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406516398 : Closed e2422406516398 ∧ code e2422406516398 = 11218499538606 := by decide
theorem cert_e2422406516398 : check e2422406516398 [[],[]] .chain = true := by decide
def e2422406516410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406516410 : Closed e2422406516410 ∧ code e2422406516410 = 11218499538618 := by decide
theorem cert_e2422406516410 : check e2422406516410 [[],[]] .chain = true := by decide
def e2422406516458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406516458 : Closed e2422406516458 ∧ code e2422406516458 = 11218499538666 := by decide
theorem cert_e2422406516458 : check e2422406516458 [[],[]] .chain = true := by decide
def e2422406516650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406516650 : Closed e2422406516650 ∧ code e2422406516650 = 11218499538858 := by decide
theorem cert_e2422406516650 : check e2422406516650 [[],[]] .chain = true := by decide
def e2422406519470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406519470 : Closed e2422406519470 ∧ code e2422406519470 = 11218499541678 := by decide
theorem cert_e2422406519470 : check e2422406519470 [[],[]] .sourceHead = true := by decide
def e2422406519482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406519482 : Closed e2422406519482 ∧ code e2422406519482 = 11218499541690 := by decide
theorem cert_e2422406519482 : check e2422406519482 [[],[]] .sourceHead = true := by decide
def e2422406519530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406519530 : Closed e2422406519530 ∧ code e2422406519530 = 11218499541738 := by decide
theorem cert_e2422406519530 : check e2422406519530 [[],[]] .sourceHead = true := by decide
def e2422406521710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422406521710 : Closed e2422406521710 ∧ code e2422406521710 = 11218499543918 := by decide
theorem cert_e2422406521710 : check e2422406521710 [[],[]] .chain = true := by decide
def e2422406521718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422406521718 : Closed e2422406521718 ∧ code e2422406521718 = 11218499543926 := by decide
theorem cert_e2422406521718 : check e2422406521718 [[],[]] .chain = true := by decide
def e2422406521774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422406521774 : Closed e2422406521774 ∧ code e2422406521774 = 11218499543982 := by decide
theorem cert_e2422406521774 : check e2422406521774 [[],[]] .chain = true := by decide
def e2422406521786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422406521786 : Closed e2422406521786 ∧ code e2422406521786 = 11218499543994 := by decide
theorem cert_e2422406521786 : check e2422406521786 [[],[]] .chain = true := by decide
def e2422406521814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2422406521814 : Closed e2422406521814 ∧ code e2422406521814 = 11218499544022 := by decide
theorem cert_e2422406521814 : check e2422406521814 [[],[]] .chain = true := by decide
def e2422406521818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2422406521818 : Closed e2422406521818 ∧ code e2422406521818 = 11218499544026 := by decide
theorem cert_e2422406521818 : check e2422406521818 [[],[]] .chain = true := by decide
def e2422406522542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406522542 : Closed e2422406522542 ∧ code e2422406522542 = 11218499544750 := by decide
theorem cert_e2422406522542 : check e2422406522542 [[],[]] .chain = true := by decide
def e2422406522554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406522554 : Closed e2422406522554 ∧ code e2422406522554 = 11218499544762 := by decide
theorem cert_e2422406522554 : check e2422406522554 [[],[]] .chain = true := by decide
def e2422406522602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406522602 : Closed e2422406522602 ∧ code e2422406522602 = 11218499544810 := by decide
theorem cert_e2422406522602 : check e2422406522602 [[],[]] .chain = true := by decide
end Blc.Floor43
