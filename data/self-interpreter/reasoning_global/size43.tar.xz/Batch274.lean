import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2407060946550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2407060946550 : Closed e2407060946550 ∧ code e2407060946550 = 11203153968758 := by decide
theorem cert_e2407060946550 : check e2407060946550 [[],[]] .three = true := by decide
def e2407060946554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407060946554 : Closed e2407060946554 ∧ code e2407060946554 = 11203153968762 := by decide
theorem cert_e2407060946554 : check e2407060946554 [[],[]] .three = true := by decide
def e2407060969182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2407060969182 : Closed e2407060969182 ∧ code e2407060969182 = 11203153991390 := by decide
theorem cert_e2407060969182 : check e2407060969182 [[],[]] .three = true := by decide
def e2407060969198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2407060969198 : Closed e2407060969198 ∧ code e2407060969198 = 11203153991406 := by decide
theorem cert_e2407060969198 : check e2407060969198 [[],[]] .smaller = true := by decide
def e2407060969206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2407060969206 : Closed e2407060969206 ∧ code e2407060969206 = 11203153991414 := by decide
theorem cert_e2407060969206 : check e2407060969206 [[],[]] .three = true := by decide
def e2407060969310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2407060969310 : Closed e2407060969310 ∧ code e2407060969310 = 11203153991518 := by decide
theorem cert_e2407060969310 : check e2407060969310 [[],[]] .three = true := by decide
def e2407060969338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2407060969338 : Closed e2407060969338 ∧ code e2407060969338 = 11203153991546 := by decide
theorem cert_e2407060969338 : check e2407060969338 [[],[]] .three = true := by decide
def e2407060969390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2407060969390 : Closed e2407060969390 ∧ code e2407060969390 = 11203153991598 := by decide
theorem cert_e2407060969390 : check e2407060969390 [[],[]] .smaller = true := by decide
def e2407060969402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2407060969402 : Closed e2407060969402 ∧ code e2407060969402 = 11203153991610 := by decide
theorem cert_e2407060969402 : check e2407060969402 [[],[]] .smaller = true := by decide
def e2407060969430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2407060969430 : Closed e2407060969430 ∧ code e2407060969430 = 11203153991638 := by decide
theorem cert_e2407060969430 : check e2407060969430 [[],[]] .three = true := by decide
def e2407060969434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2407060969434 : Closed e2407060969434 ∧ code e2407060969434 = 11203153991642 := by decide
theorem cert_e2407060969434 : check e2407060969434 [[],[]] .three = true := by decide
def e2407060969950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2407060969950 : Closed e2407060969950 ∧ code e2407060969950 = 11203153992158 := by decide
theorem cert_e2407060969950 : check e2407060969950 [[],[]] .three = true := by decide
def e2407060969966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2407060969966 : Closed e2407060969966 ∧ code e2407060969966 = 11203153992174 := by decide
theorem cert_e2407060969966 : check e2407060969966 [[],[]] .smaller = true := by decide
def e2407060969974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2407060969974 : Closed e2407060969974 ∧ code e2407060969974 = 11203153992182 := by decide
theorem cert_e2407060969974 : check e2407060969974 [[],[]] .three = true := by decide
def e2407060970718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2407060970718 : Closed e2407060970718 ∧ code e2407060970718 = 11203153992926 := by decide
theorem cert_e2407060970718 : check e2407060970718 [[],[]] .three = true := by decide
def e2407060970746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2407060970746 : Closed e2407060970746 ∧ code e2407060970746 = 11203153992954 := by decide
theorem cert_e2407060970746 : check e2407060970746 [[],[]] .three = true := by decide
def e2407060971118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407060971118 : Closed e2407060971118 ∧ code e2407060971118 = 11203153993326 := by decide
theorem cert_e2407060971118 : check e2407060971118 [[],[]] .smaller = true := by decide
def e2407060971130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407060971130 : Closed e2407060971130 ∧ code e2407060971130 = 11203153993338 := by decide
theorem cert_e2407060971130 : check e2407060971130 [[],[]] .smaller = true := by decide
def e2407060971318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407060971318 : Closed e2407060971318 ∧ code e2407060971318 = 11203153993526 := by decide
theorem cert_e2407060971318 : check e2407060971318 [[],[]] .three = true := by decide
def e2407060971322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407060971322 : Closed e2407060971322 ∧ code e2407060971322 = 11203153993530 := by decide
theorem cert_e2407060971322 : check e2407060971322 [[],[]] .three = true := by decide
def e2407060982622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2407060982622 : Closed e2407060982622 ∧ code e2407060982622 = 11203154004830 := by decide
theorem cert_e2407060982622 : check e2407060982622 [[],[]] .three = true := by decide
def e2407060982638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2407060982638 : Closed e2407060982638 ∧ code e2407060982638 = 11203154004846 := by decide
theorem cert_e2407060982638 : check e2407060982638 [[],[]] .smaller = true := by decide
def e2407060982646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2407060982646 : Closed e2407060982646 ∧ code e2407060982646 = 11203154004854 := by decide
theorem cert_e2407060982646 : check e2407060982646 [[],[]] .smaller = true := by decide
def e2407060982650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2407060982650 : Closed e2407060982650 ∧ code e2407060982650 = 11203154004858 := by decide
theorem cert_e2407060982650 : check e2407060982650 [[],[]] .three = true := by decide
def e2407060982702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2407060982702 : Closed e2407060982702 ∧ code e2407060982702 = 11203154004910 := by decide
theorem cert_e2407060982702 : check e2407060982702 [[],[]] .smaller = true := by decide
def e2407060982714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2407060982714 : Closed e2407060982714 ∧ code e2407060982714 = 11203154004922 := by decide
theorem cert_e2407060982714 : check e2407060982714 [[],[]] .smaller = true := by decide
def e2407060982742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2407060982742 : Closed e2407060982742 ∧ code e2407060982742 = 11203154004950 := by decide
theorem cert_e2407060982742 : check e2407060982742 [[],[]] .smaller = true := by decide
def e2407060982746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2407060982746 : Closed e2407060982746 ∧ code e2407060982746 = 11203154004954 := by decide
theorem cert_e2407060982746 : check e2407060982746 [[],[]] .smaller = true := by decide
def e2407060982762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2407060982762 : Closed e2407060982762 ∧ code e2407060982762 = 11203154004970 := by decide
theorem cert_e2407060982762 : check e2407060982762 [[],[]] .three = true := by decide
def e2407060983006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2407060983006 : Closed e2407060983006 ∧ code e2407060983006 = 11203154005214 := by decide
theorem cert_e2407060983006 : check e2407060983006 [[],[]] .three = true := by decide
def e2407060983022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2407060983022 : Closed e2407060983022 ∧ code e2407060983022 = 11203154005230 := by decide
theorem cert_e2407060983022 : check e2407060983022 [[],[]] .smaller = true := by decide
def e2407060983030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2407060983030 : Closed e2407060983030 ∧ code e2407060983030 = 11203154005238 := by decide
theorem cert_e2407060983030 : check e2407060983030 [[],[]] .smaller = true := by decide
def e2407060983034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2407060983034 : Closed e2407060983034 ∧ code e2407060983034 = 11203154005242 := by decide
theorem cert_e2407060983034 : check e2407060983034 [[],[]] .three = true := by decide
def e2407060983406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407060983406 : Closed e2407060983406 ∧ code e2407060983406 = 11203154005614 := by decide
theorem cert_e2407060983406 : check e2407060983406 [[],[]] .smaller = true := by decide
def e2407060983418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407060983418 : Closed e2407060983418 ∧ code e2407060983418 = 11203154005626 := by decide
theorem cert_e2407060983418 : check e2407060983418 [[],[]] .smaller = true := by decide
def e2407060983606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407060983606 : Closed e2407060983606 ∧ code e2407060983606 = 11203154005814 := by decide
theorem cert_e2407060983606 : check e2407060983606 [[],[]] .smaller = true := by decide
def e2407060983610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407060983610 : Closed e2407060983610 ∧ code e2407060983610 = 11203154005818 := by decide
theorem cert_e2407060983610 : check e2407060983610 [[],[]] .smaller = true := by decide
def e2407060983706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407060983706 : Closed e2407060983706 ∧ code e2407060983706 = 11203154005914 := by decide
theorem cert_e2407060983706 : check e2407060983706 [[],[]] .three = true := by decide
def e2407060989358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2407060989358 : Closed e2407060989358 ∧ code e2407060989358 = 11203154011566 := by decide
theorem cert_e2407060989358 : check e2407060989358 [[],[]] .three = true := by decide
def e2407060989366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2407060989366 : Closed e2407060989366 ∧ code e2407060989366 = 11203154011574 := by decide
theorem cert_e2407060989366 : check e2407060989366 [[],[]] .three = true := by decide
def e2407060989370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2407060989370 : Closed e2407060989370 ∧ code e2407060989370 = 11203154011578 := by decide
theorem cert_e2407060989370 : check e2407060989370 [[],[]] .three = true := by decide
def e2407060989398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2407060989398 : Closed e2407060989398 ∧ code e2407060989398 = 11203154011606 := by decide
theorem cert_e2407060989398 : check e2407060989398 [[],[]] .three = true := by decide
def e2407060989402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2407060989402 : Closed e2407060989402 ∧ code e2407060989402 = 11203154011610 := by decide
theorem cert_e2407060989402 : check e2407060989402 [[],[]] .three = true := by decide
def e2407060989418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2407060989418 : Closed e2407060989418 ∧ code e2407060989418 = 11203154011626 := by decide
theorem cert_e2407060989418 : check e2407060989418 [[],[]] .three = true := by decide
def e2407060989550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407060989550 : Closed e2407060989550 ∧ code e2407060989550 = 11203154011758 := by decide
theorem cert_e2407060989550 : check e2407060989550 [[],[]] .three = true := by decide
def e2407060989558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2407060989558 : Closed e2407060989558 ∧ code e2407060989558 = 11203154011766 := by decide
theorem cert_e2407060989558 : check e2407060989558 [[],[]] .three = true := by decide
def e2407060989562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407060989562 : Closed e2407060989562 ∧ code e2407060989562 = 11203154011770 := by decide
theorem cert_e2407060989562 : check e2407060989562 [[],[]] .three = true := by decide
def e2407060989750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407060989750 : Closed e2407060989750 ∧ code e2407060989750 = 11203154011958 := by decide
theorem cert_e2407060989750 : check e2407060989750 [[],[]] .three = true := by decide
def e2407060989754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407060989754 : Closed e2407060989754 ∧ code e2407060989754 = 11203154011962 := by decide
theorem cert_e2407060989754 : check e2407060989754 [[],[]] .three = true := by decide
def e2407060989850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407060989850 : Closed e2407060989850 ∧ code e2407060989850 = 11203154012058 := by decide
theorem cert_e2407060989850 : check e2407060989850 [[],[]] .three = true := by decide
def e2407061435758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2407061435758 : Closed e2407061435758 ∧ code e2407061435758 = 11203154457966 := by decide
theorem cert_e2407061435758 : check e2407061435758 [[],[]] .chain = true := by decide
def e2407061435766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2407061435766 : Closed e2407061435766 ∧ code e2407061435766 = 11203154457974 := by decide
theorem cert_e2407061435766 : check e2407061435766 [[],[]] .chain = true := by decide
def e2407061435822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2407061435822 : Closed e2407061435822 ∧ code e2407061435822 = 11203154458030 := by decide
theorem cert_e2407061435822 : check e2407061435822 [[],[]] .chain = true := by decide
def e2407061435834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2407061435834 : Closed e2407061435834 ∧ code e2407061435834 = 11203154458042 := by decide
theorem cert_e2407061435834 : check e2407061435834 [[],[]] .chain = true := by decide
def e2407061435862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2407061435862 : Closed e2407061435862 ∧ code e2407061435862 = 11203154458070 := by decide
theorem cert_e2407061435862 : check e2407061435862 [[],[]] .chain = true := by decide
def e2407061435866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2407061435866 : Closed e2407061435866 ∧ code e2407061435866 = 11203154458074 := by decide
theorem cert_e2407061435866 : check e2407061435866 [[],[]] .chain = true := by decide
def e2407061436078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2407061436078 : Closed e2407061436078 ∧ code e2407061436078 = 11203154458286 := by decide
theorem cert_e2407061436078 : check e2407061436078 [[],[]] .chain = true := by decide
def e2407061436090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2407061436090 : Closed e2407061436090 ∧ code e2407061436090 = 11203154458298 := by decide
theorem cert_e2407061436090 : check e2407061436090 [[],[]] .chain = true := by decide
def e2407061436138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2407061436138 : Closed e2407061436138 ∧ code e2407061436138 = 11203154458346 := by decide
theorem cert_e2407061436138 : check e2407061436138 [[],[]] .chain = true := by decide
def e2407061436246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2407061436246 : Closed e2407061436246 ∧ code e2407061436246 = 11203154458454 := by decide
theorem cert_e2407061436246 : check e2407061436246 [[],[]] .chain = true := by decide
def e2407061436250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2407061436250 : Closed e2407061436250 ∧ code e2407061436250 = 11203154458458 := by decide
theorem cert_e2407061436250 : check e2407061436250 [[],[]] .chain = true := by decide
def e2407061436266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2407061436266 : Closed e2407061436266 ∧ code e2407061436266 = 11203154458474 := by decide
theorem cert_e2407061436266 : check e2407061436266 [[],[]] .chain = true := by decide
def e2407061437102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2407061437102 : Closed e2407061437102 ∧ code e2407061437102 = 11203154459310 := by decide
theorem cert_e2407061437102 : check e2407061437102 [[],[]] .chain = true := by decide
def e2407061437114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2407061437114 : Closed e2407061437114 ∧ code e2407061437114 = 11203154459322 := by decide
theorem cert_e2407061437114 : check e2407061437114 [[],[]] .chain = true := by decide
def e2407061437162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2407061437162 : Closed e2407061437162 ∧ code e2407061437162 = 11203154459370 := by decide
theorem cert_e2407061437162 : check e2407061437162 [[],[]] .chain = true := by decide
def e2407061437354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2407061437354 : Closed e2407061437354 ∧ code e2407061437354 = 11203154459562 := by decide
theorem cert_e2407061437354 : check e2407061437354 [[],[]] .chain = true := by decide
def e2407061437782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2407061437782 : Closed e2407061437782 ∧ code e2407061437782 = 11203154459990 := by decide
theorem cert_e2407061437782 : check e2407061437782 [[],[]] .chain = true := by decide
def e2407061437786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2407061437786 : Closed e2407061437786 ∧ code e2407061437786 = 11203154459994 := by decide
theorem cert_e2407061437786 : check e2407061437786 [[],[]] .chain = true := by decide
def e2407061437802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2407061437802 : Closed e2407061437802 ∧ code e2407061437802 = 11203154460010 := by decide
theorem cert_e2407061437802 : check e2407061437802 [[],[]] .chain = true := by decide
def e2407061437866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2407061437866 : Closed e2407061437866 ∧ code e2407061437866 = 11203154460074 := by decide
theorem cert_e2407061437866 : check e2407061437866 [[],[]] .chain = true := by decide
def e2407061440366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2407061440366 : Closed e2407061440366 ∧ code e2407061440366 = 11203154462574 := by decide
theorem cert_e2407061440366 : check e2407061440366 [[],[]] .chain = true := by decide
def e2407061440374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2407061440374 : Closed e2407061440374 ∧ code e2407061440374 = 11203154462582 := by decide
theorem cert_e2407061440374 : check e2407061440374 [[],[]] .chain = true := by decide
def e2407061440438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e2407061440438 : Closed e2407061440438 ∧ code e2407061440438 = 11203154462646 := by decide
theorem cert_e2407061440438 : check e2407061440438 [[],[]] .chain = true := by decide
def e2407061441902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2407061441902 : Closed e2407061441902 ∧ code e2407061441902 = 11203154464110 := by decide
theorem cert_e2407061441902 : check e2407061441902 [[],[]] .chain = true := by decide
def e2407061441910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2407061441910 : Closed e2407061441910 ∧ code e2407061441910 = 11203154464118 := by decide
theorem cert_e2407061441910 : check e2407061441910 [[],[]] .chain = true := by decide
def e2407061441966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2407061441966 : Closed e2407061441966 ∧ code e2407061441966 = 11203154464174 := by decide
theorem cert_e2407061441966 : check e2407061441966 [[],[]] .chain = true := by decide
def e2407061441978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2407061441978 : Closed e2407061441978 ∧ code e2407061441978 = 11203154464186 := by decide
theorem cert_e2407061441978 : check e2407061441978 [[],[]] .chain = true := by decide
def e2407061442006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2407061442006 : Closed e2407061442006 ∧ code e2407061442006 = 11203154464214 := by decide
theorem cert_e2407061442006 : check e2407061442006 [[],[]] .chain = true := by decide
def e2407061442010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2407061442010 : Closed e2407061442010 ∧ code e2407061442010 = 11203154464218 := by decide
theorem cert_e2407061442010 : check e2407061442010 [[],[]] .chain = true := by decide
def e2407061442222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2407061442222 : Closed e2407061442222 ∧ code e2407061442222 = 11203154464430 := by decide
theorem cert_e2407061442222 : check e2407061442222 [[],[]] .chain = true := by decide
def e2407061442234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2407061442234 : Closed e2407061442234 ∧ code e2407061442234 = 11203154464442 := by decide
theorem cert_e2407061442234 : check e2407061442234 [[],[]] .chain = true := by decide
def e2407061442282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2407061442282 : Closed e2407061442282 ∧ code e2407061442282 = 11203154464490 := by decide
theorem cert_e2407061442282 : check e2407061442282 [[],[]] .chain = true := by decide
def e2407061442390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2407061442390 : Closed e2407061442390 ∧ code e2407061442390 = 11203154464598 := by decide
theorem cert_e2407061442390 : check e2407061442390 [[],[]] .chain = true := by decide
def e2407061442394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2407061442394 : Closed e2407061442394 ∧ code e2407061442394 = 11203154464602 := by decide
theorem cert_e2407061442394 : check e2407061442394 [[],[]] .chain = true := by decide
def e2407061442410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2407061442410 : Closed e2407061442410 ∧ code e2407061442410 = 11203154464618 := by decide
theorem cert_e2407061442410 : check e2407061442410 [[],[]] .chain = true := by decide
def e2407061443438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2407061443438 : Closed e2407061443438 ∧ code e2407061443438 = 11203154465646 := by decide
theorem cert_e2407061443438 : check e2407061443438 [[],[]] .chain = true := by decide
def e2407061443446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2407061443446 : Closed e2407061443446 ∧ code e2407061443446 = 11203154465654 := by decide
theorem cert_e2407061443446 : check e2407061443446 [[],[]] .chain = true := by decide
def e2407061443502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2407061443502 : Closed e2407061443502 ∧ code e2407061443502 = 11203154465710 := by decide
theorem cert_e2407061443502 : check e2407061443502 [[],[]] .chain = true := by decide
def e2407061443514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2407061443514 : Closed e2407061443514 ∧ code e2407061443514 = 11203154465722 := by decide
theorem cert_e2407061443514 : check e2407061443514 [[],[]] .chain = true := by decide
def e2407061443542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2407061443542 : Closed e2407061443542 ∧ code e2407061443542 = 11203154465750 := by decide
theorem cert_e2407061443542 : check e2407061443542 [[],[]] .chain = true := by decide
def e2407061443546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2407061443546 : Closed e2407061443546 ∧ code e2407061443546 = 11203154465754 := by decide
theorem cert_e2407061443546 : check e2407061443546 [[],[]] .chain = true := by decide
def e2407061443822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2407061443822 : Closed e2407061443822 ∧ code e2407061443822 = 11203154466030 := by decide
theorem cert_e2407061443822 : check e2407061443822 [[],[]] .chain = true := by decide
def e2407061443830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2407061443830 : Closed e2407061443830 ∧ code e2407061443830 = 11203154466038 := by decide
theorem cert_e2407061443830 : check e2407061443830 [[],[]] .chain = true := by decide
def e2407061444206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2407061444206 : Closed e2407061444206 ∧ code e2407061444206 = 11203154466414 := by decide
theorem cert_e2407061444206 : check e2407061444206 [[],[]] .chain = true := by decide
def e2407061444218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2407061444218 : Closed e2407061444218 ∧ code e2407061444218 = 11203154466426 := by decide
theorem cert_e2407061444218 : check e2407061444218 [[],[]] .chain = true := by decide
def e2407061444406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2407061444406 : Closed e2407061444406 ∧ code e2407061444406 = 11203154466614 := by decide
theorem cert_e2407061444406 : check e2407061444406 [[],[]] .chain = true := by decide
def e2407061444410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2407061444410 : Closed e2407061444410 ∧ code e2407061444410 = 11203154466618 := by decide
theorem cert_e2407061444410 : check e2407061444410 [[],[]] .chain = true := by decide
def e2407061444846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2407061444846 : Closed e2407061444846 ∧ code e2407061444846 = 11203154467054 := by decide
theorem cert_e2407061444846 : check e2407061444846 [[],[]] .chain = true := by decide
def e2407061444854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2407061444854 : Closed e2407061444854 ∧ code e2407061444854 = 11203154467062 := by decide
theorem cert_e2407061444854 : check e2407061444854 [[],[]] .chain = true := by decide
def e2407061445038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2407061445038 : Closed e2407061445038 ∧ code e2407061445038 = 11203154467246 := by decide
theorem cert_e2407061445038 : check e2407061445038 [[],[]] .chain = true := by decide
def e2407061445050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2407061445050 : Closed e2407061445050 ∧ code e2407061445050 = 11203154467258 := by decide
theorem cert_e2407061445050 : check e2407061445050 [[],[]] .chain = true := by decide
def e2407061445098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2407061445098 : Closed e2407061445098 ∧ code e2407061445098 = 11203154467306 := by decide
theorem cert_e2407061445098 : check e2407061445098 [[],[]] .chain = true := by decide
def e2407061445230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2407061445230 : Closed e2407061445230 ∧ code e2407061445230 = 11203154467438 := by decide
theorem cert_e2407061445230 : check e2407061445230 [[],[]] .chain = true := by decide
def e2407061445242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2407061445242 : Closed e2407061445242 ∧ code e2407061445242 = 11203154467450 := by decide
theorem cert_e2407061445242 : check e2407061445242 [[],[]] .chain = true := by decide
def e2407061445406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2407061445406 : Closed e2407061445406 ∧ code e2407061445406 = 11203154467614 := by decide
theorem cert_e2407061445406 : check e2407061445406 [[],[]] .chain = true := by decide
def e2407061445518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2407061445518 : Closed e2407061445518 ∧ code e2407061445518 = 11203154467726 := by decide
theorem cert_e2407061445518 : check e2407061445518 [[],[]] .chain = true := by decide
def e2407061445530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061445530 : Closed e2407061445530 ∧ code e2407061445530 = 11203154467738 := by decide
theorem cert_e2407061445530 : check e2407061445530 [[],[]] .chain = true := by decide
def e2407061445750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2407061445750 : Closed e2407061445750 ∧ code e2407061445750 = 11203154467958 := by decide
theorem cert_e2407061445750 : check e2407061445750 [[],[]] .chain = true := by decide
def e2407061445846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2407061445846 : Closed e2407061445846 ∧ code e2407061445846 = 11203154468054 := by decide
theorem cert_e2407061445846 : check e2407061445846 [[],[]] .chain = true := by decide
def e2407061445850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2407061445850 : Closed e2407061445850 ∧ code e2407061445850 = 11203154468058 := by decide
theorem cert_e2407061445850 : check e2407061445850 [[],[]] .chain = true := by decide
def e2407061445866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2407061445866 : Closed e2407061445866 ∧ code e2407061445866 = 11203154468074 := by decide
theorem cert_e2407061445866 : check e2407061445866 [[],[]] .chain = true := by decide
def e2407061445942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2407061445942 : Closed e2407061445942 ∧ code e2407061445942 = 11203154468150 := by decide
theorem cert_e2407061445942 : check e2407061445942 [[],[]] .chain = true := by decide
def e2407061445946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2407061445946 : Closed e2407061445946 ∧ code e2407061445946 = 11203154468154 := by decide
theorem cert_e2407061445946 : check e2407061445946 [[],[]] .chain = true := by decide
def e2407061446030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2407061446030 : Closed e2407061446030 ∧ code e2407061446030 = 11203154468238 := by decide
theorem cert_e2407061446030 : check e2407061446030 [[],[]] .chain = true := by decide
def e2407061446042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061446042 : Closed e2407061446042 ∧ code e2407061446042 = 11203154468250 := by decide
theorem cert_e2407061446042 : check e2407061446042 [[],[]] .chain = true := by decide
def e2407061447534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2407061447534 : Closed e2407061447534 ∧ code e2407061447534 = 11203154469742 := by decide
theorem cert_e2407061447534 : check e2407061447534 [[],[]] .chain = true := by decide
def e2407061447542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2407061447542 : Closed e2407061447542 ∧ code e2407061447542 = 11203154469750 := by decide
theorem cert_e2407061447542 : check e2407061447542 [[],[]] .chain = true := by decide
def e2407061447598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2407061447598 : Closed e2407061447598 ∧ code e2407061447598 = 11203154469806 := by decide
theorem cert_e2407061447598 : check e2407061447598 [[],[]] .chain = true := by decide
def e2407061447610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2407061447610 : Closed e2407061447610 ∧ code e2407061447610 = 11203154469818 := by decide
theorem cert_e2407061447610 : check e2407061447610 [[],[]] .chain = true := by decide
def e2407061447638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2407061447638 : Closed e2407061447638 ∧ code e2407061447638 = 11203154469846 := by decide
theorem cert_e2407061447638 : check e2407061447638 [[],[]] .chain = true := by decide
def e2407061447642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2407061447642 : Closed e2407061447642 ∧ code e2407061447642 = 11203154469850 := by decide
theorem cert_e2407061447642 : check e2407061447642 [[],[]] .chain = true := by decide
def e2407061448366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2407061448366 : Closed e2407061448366 ∧ code e2407061448366 = 11203154470574 := by decide
theorem cert_e2407061448366 : check e2407061448366 [[],[]] .chain = true := by decide
def e2407061448378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2407061448378 : Closed e2407061448378 ∧ code e2407061448378 = 11203154470586 := by decide
theorem cert_e2407061448378 : check e2407061448378 [[],[]] .chain = true := by decide
def e2407061448426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2407061448426 : Closed e2407061448426 ∧ code e2407061448426 = 11203154470634 := by decide
theorem cert_e2407061448426 : check e2407061448426 [[],[]] .chain = true := by decide
def e2407061448618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2407061448618 : Closed e2407061448618 ∧ code e2407061448618 = 11203154470826 := by decide
theorem cert_e2407061448618 : check e2407061448618 [[],[]] .chain = true := by decide
def e2407061448942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2407061448942 : Closed e2407061448942 ∧ code e2407061448942 = 11203154471150 := by decide
theorem cert_e2407061448942 : check e2407061448942 [[],[]] .chain = true := by decide
def e2407061448950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2407061448950 : Closed e2407061448950 ∧ code e2407061448950 = 11203154471158 := by decide
theorem cert_e2407061448950 : check e2407061448950 [[],[]] .chain = true := by decide
def e2407061449134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2407061449134 : Closed e2407061449134 ∧ code e2407061449134 = 11203154471342 := by decide
theorem cert_e2407061449134 : check e2407061449134 [[],[]] .chain = true := by decide
def e2407061449146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2407061449146 : Closed e2407061449146 ∧ code e2407061449146 = 11203154471354 := by decide
theorem cert_e2407061449146 : check e2407061449146 [[],[]] .chain = true := by decide
def e2407061449194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2407061449194 : Closed e2407061449194 ∧ code e2407061449194 = 11203154471402 := by decide
theorem cert_e2407061449194 : check e2407061449194 [[],[]] .chain = true := by decide
def e2407061449326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2407061449326 : Closed e2407061449326 ∧ code e2407061449326 = 11203154471534 := by decide
theorem cert_e2407061449326 : check e2407061449326 [[],[]] .chain = true := by decide
def e2407061449338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2407061449338 : Closed e2407061449338 ∧ code e2407061449338 = 11203154471546 := by decide
theorem cert_e2407061449338 : check e2407061449338 [[],[]] .chain = true := by decide
def e2407061449502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2407061449502 : Closed e2407061449502 ∧ code e2407061449502 = 11203154471710 := by decide
theorem cert_e2407061449502 : check e2407061449502 [[],[]] .chain = true := by decide
def e2407061449614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2407061449614 : Closed e2407061449614 ∧ code e2407061449614 = 11203154471822 := by decide
theorem cert_e2407061449614 : check e2407061449614 [[],[]] .chain = true := by decide
def e2407061449626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061449626 : Closed e2407061449626 ∧ code e2407061449626 = 11203154471834 := by decide
theorem cert_e2407061449626 : check e2407061449626 [[],[]] .chain = true := by decide
def e2407061449838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2407061449838 : Closed e2407061449838 ∧ code e2407061449838 = 11203154472046 := by decide
theorem cert_e2407061449838 : check e2407061449838 [[],[]] .chain = true := by decide
def e2407061449850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2407061449850 : Closed e2407061449850 ∧ code e2407061449850 = 11203154472058 := by decide
theorem cert_e2407061449850 : check e2407061449850 [[],[]] .chain = true := by decide
def e2407061450014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2407061450014 : Closed e2407061450014 ∧ code e2407061450014 = 11203154472222 := by decide
theorem cert_e2407061450014 : check e2407061450014 [[],[]] .chain = true := by decide
def e2407061450182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2407061450182 : Closed e2407061450182 ∧ code e2407061450182 = 11203154472390 := by decide
theorem cert_e2407061450182 : check e2407061450182 [[],[]] .chain = true := by decide
def e2407061450294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2407061450294 : Closed e2407061450294 ∧ code e2407061450294 = 11203154472502 := by decide
theorem cert_e2407061450294 : check e2407061450294 [[],[]] .chain = true := by decide
def e2407061450298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2407061450298 : Closed e2407061450298 ∧ code e2407061450298 = 11203154472506 := by decide
theorem cert_e2407061450298 : check e2407061450298 [[],[]] .chain = true := by decide
def e2407061450346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2407061450346 : Closed e2407061450346 ∧ code e2407061450346 = 11203154472554 := by decide
theorem cert_e2407061450346 : check e2407061450346 [[],[]] .chain = true := by decide
def e2407061450382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2407061450382 : Closed e2407061450382 ∧ code e2407061450382 = 11203154472590 := by decide
theorem cert_e2407061450382 : check e2407061450382 [[],[]] .chain = true := by decide
def e2407061450394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061450394 : Closed e2407061450394 ∧ code e2407061450394 = 11203154472602 := by decide
theorem cert_e2407061450394 : check e2407061450394 [[],[]] .chain = true := by decide
def e2407061450438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2407061450438 : Closed e2407061450438 ∧ code e2407061450438 = 11203154472646 := by decide
theorem cert_e2407061450438 : check e2407061450438 [[],[]] .chain = true := by decide
def e2407061451190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2407061451190 : Closed e2407061451190 ∧ code e2407061451190 = 11203154473398 := by decide
theorem cert_e2407061451190 : check e2407061451190 [[],[]] .chain = true := by decide
def e2407061451222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2407061451222 : Closed e2407061451222 ∧ code e2407061451222 = 11203154473430 := by decide
theorem cert_e2407061451222 : check e2407061451222 [[],[]] .chain = true := by decide
def e2407061451226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2407061451226 : Closed e2407061451226 ∧ code e2407061451226 = 11203154473434 := by decide
theorem cert_e2407061451226 : check e2407061451226 [[],[]] .chain = true := by decide
def e2407061451606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2407061451606 : Closed e2407061451606 ∧ code e2407061451606 = 11203154473814 := by decide
theorem cert_e2407061451606 : check e2407061451606 [[],[]] .chain = true := by decide
def e2407061451610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2407061451610 : Closed e2407061451610 ∧ code e2407061451610 = 11203154473818 := by decide
theorem cert_e2407061451610 : check e2407061451610 [[],[]] .chain = true := by decide
def e2407061451626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2407061451626 : Closed e2407061451626 ∧ code e2407061451626 = 11203154473834 := by decide
theorem cert_e2407061451626 : check e2407061451626 [[],[]] .chain = true := by decide
def e2407061451690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2407061451690 : Closed e2407061451690 ∧ code e2407061451690 = 11203154473898 := by decide
theorem cert_e2407061451690 : check e2407061451690 [[],[]] .chain = true := by decide
def e2407061451894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2407061451894 : Closed e2407061451894 ∧ code e2407061451894 = 11203154474102 := by decide
theorem cert_e2407061451894 : check e2407061451894 [[],[]] .chain = true := by decide
def e2407061451990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2407061451990 : Closed e2407061451990 ∧ code e2407061451990 = 11203154474198 := by decide
theorem cert_e2407061451990 : check e2407061451990 [[],[]] .chain = true := by decide
def e2407061451994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2407061451994 : Closed e2407061451994 ∧ code e2407061451994 = 11203154474202 := by decide
theorem cert_e2407061451994 : check e2407061451994 [[],[]] .chain = true := by decide
def e2407061452010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2407061452010 : Closed e2407061452010 ∧ code e2407061452010 = 11203154474218 := by decide
theorem cert_e2407061452010 : check e2407061452010 [[],[]] .chain = true := by decide
def e2407061452086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2407061452086 : Closed e2407061452086 ∧ code e2407061452086 = 11203154474294 := by decide
theorem cert_e2407061452086 : check e2407061452086 [[],[]] .chain = true := by decide
def e2407061452090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2407061452090 : Closed e2407061452090 ∧ code e2407061452090 = 11203154474298 := by decide
theorem cert_e2407061452090 : check e2407061452090 [[],[]] .chain = true := by decide
def e2407061452174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2407061452174 : Closed e2407061452174 ∧ code e2407061452174 = 11203154474382 := by decide
theorem cert_e2407061452174 : check e2407061452174 [[],[]] .chain = true := by decide
def e2407061452186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061452186 : Closed e2407061452186 ∧ code e2407061452186 = 11203154474394 := by decide
theorem cert_e2407061452186 : check e2407061452186 [[],[]] .chain = true := by decide
end Blc.Floor43
