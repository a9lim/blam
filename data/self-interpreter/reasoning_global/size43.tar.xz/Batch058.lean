import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e755977906202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755977906202 : Closed e755977906202 ∧ code e755977906202 = 9552070928410 := by decide
theorem cert_e755977906202 : check e755977906202 [] .sourceHead = true := by decide
def e755977907738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755977907738 : Closed e755977907738 ∧ code e755977907738 = 9552070929946 := by decide
theorem cert_e755977907738 : check e755977907738 [] .sourceHead = true := by decide
def e755977909786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755977909786 : Closed e755977909786 ∧ code e755977909786 = 9552070931994 := by decide
theorem cert_e755977909786 : check e755977909786 [] .sourceHead = true := by decide
def e755977910810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755977910810 : Closed e755977910810 ∧ code e755977910810 = 9552070933018 := by decide
theorem cert_e755977910810 : check e755977910810 [] .sourceHead = true := by decide
def e755977922586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755977922586 : Closed e755977922586 ∧ code e755977922586 = 9552070944794 := by decide
theorem cert_e755977922586 : check e755977922586 [] .sourceHead = true := by decide
def e755977924122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755977924122 : Closed e755977924122 ∧ code e755977924122 = 9552070946330 := by decide
theorem cert_e755977924122 : check e755977924122 [] .sourceHead = true := by decide
def e755977927194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755977927194 : Closed e755977927194 ∧ code e755977927194 = 9552070949402 := by decide
theorem cert_e755977927194 : check e755977927194 [] .sourceHead = true := by decide
def e755977934362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755977934362 : Closed e755977934362 ∧ code e755977934362 = 9552070956570 := by decide
theorem cert_e755977934362 : check e755977934362 [] .sourceHead = true := by decide
def e755977935386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755977935386 : Closed e755977935386 ∧ code e755977935386 = 9552070957594 := by decide
theorem cert_e755977935386 : check e755977935386 [] .sourceHead = true := by decide
def e755977939482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755977939482 : Closed e755977939482 ∧ code e755977939482 = 9552070961690 := by decide
theorem cert_e755977939482 : check e755977939482 [] .sourceHead = true := by decide
def e755978000410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755978000410 : Closed e755978000410 ∧ code e755978000410 = 9552071022618 := by decide
theorem cert_e755978000410 : check e755978000410 [] .sourceHead = true := by decide
def e755978001946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755978001946 : Closed e755978001946 ∧ code e755978001946 = 9552071024154 := by decide
theorem cert_e755978001946 : check e755978001946 [] .sourceHead = true := by decide
def e755978004506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755978004506 : Closed e755978004506 ∧ code e755978004506 = 9552071026714 := by decide
theorem cert_e755978004506 : check e755978004506 [] .sourceHead = true := by decide
def e755978006042 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755978006042 : Closed e755978006042 ∧ code e755978006042 = 9552071028250 := by decide
theorem cert_e755978006042 : check e755978006042 [] .sourceHead = true := by decide
def e755978008090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755978008090 : Closed e755978008090 ∧ code e755978008090 = 9552071030298 := by decide
theorem cert_e755978008090 : check e755978008090 [] .sourceHead = true := by decide
def e755978009114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755978009114 : Closed e755978009114 ∧ code e755978009114 = 9552071031322 := by decide
theorem cert_e755978009114 : check e755978009114 [] .sourceHead = true := by decide
def e755978102810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755978102810 : Closed e755978102810 ∧ code e755978102810 = 9552071125018 := by decide
theorem cert_e755978102810 : check e755978102810 [] .sourceHead = true := by decide
def e755978104346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755978104346 : Closed e755978104346 ∧ code e755978104346 = 9552071126554 := by decide
theorem cert_e755978104346 : check e755978104346 [] .sourceHead = true := by decide
def e755978107418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755978107418 : Closed e755978107418 ∧ code e755978107418 = 9552071129626 := by decide
theorem cert_e755978107418 : check e755978107418 [] .sourceHead = true := by decide
def e755978155546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755978155546 : Closed e755978155546 ∧ code e755978155546 = 9552071177754 := by decide
theorem cert_e755978155546 : check e755978155546 [] .sourceHead = true := by decide
def e755978156570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755978156570 : Closed e755978156570 ∧ code e755978156570 = 9552071178778 := by decide
theorem cert_e755978156570 : check e755978156570 [] .sourceHead = true := by decide
def e755978181146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755978181146 : Closed e755978181146 ∧ code e755978181146 = 9552071203354 := by decide
theorem cert_e755978181146 : check e755978181146 [] .sourceHead = true := by decide
def e755979628058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979628058 : Closed e755979628058 ∧ code e755979628058 = 9552072650266 := by decide
theorem cert_e755979628058 : check e755979628058 [] .sourceHead = true := by decide
def e755979630106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979630106 : Closed e755979630106 ∧ code e755979630106 = 9552072652314 := by decide
theorem cert_e755979630106 : check e755979630106 [] .sourceHead = true := by decide
def e755979631130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979631130 : Closed e755979631130 ∧ code e755979631130 = 9552072653338 := by decide
theorem cert_e755979631130 : check e755979631130 [] .sourceHead = true := by decide
def e755979638298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979638298 : Closed e755979638298 ∧ code e755979638298 = 9552072660506 := by decide
theorem cert_e755979638298 : check e755979638298 [] .sourceHead = true := by decide
def e755979639322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979639322 : Closed e755979639322 ∧ code e755979639322 = 9552072661530 := by decide
theorem cert_e755979639322 : check e755979639322 [] .sourceHead = true := by decide
def e755979643418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979643418 : Closed e755979643418 ∧ code e755979643418 = 9552072665626 := by decide
theorem cert_e755979643418 : check e755979643418 [] .sourceHead = true := by decide
def e755979677210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979677210 : Closed e755979677210 ∧ code e755979677210 = 9552072699418 := by decide
theorem cert_e755979677210 : check e755979677210 [] .sourceHead = true := by decide
def e755979679258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979679258 : Closed e755979679258 ∧ code e755979679258 = 9552072701466 := by decide
theorem cert_e755979679258 : check e755979679258 [] .sourceHead = true := by decide
def e755979680282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979680282 : Closed e755979680282 ∧ code e755979680282 = 9552072702490 := by decide
theorem cert_e755979680282 : check e755979680282 [] .sourceHead = true := by decide
def e755979728410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979728410 : Closed e755979728410 ∧ code e755979728410 = 9552072750618 := by decide
theorem cert_e755979728410 : check e755979728410 [] .sourceHead = true := by decide
def e755979729434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979729434 : Closed e755979729434 ∧ code e755979729434 = 9552072751642 := by decide
theorem cert_e755979729434 : check e755979729434 [] .sourceHead = true := by decide
def e755979754010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755979754010 : Closed e755979754010 ∧ code e755979754010 = 9552072776218 := by decide
theorem cert_e755979754010 : check e755979754010 [] .sourceHead = true := by decide
def e756093906458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756093906458 : Closed e756093906458 ∧ code e756093906458 = 9552186928666 := by decide
theorem cert_e756093906458 : check e756093906458 [] .sourceHead = true := by decide
def e756093908506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756093908506 : Closed e756093908506 ∧ code e756093908506 = 9552186930714 := by decide
theorem cert_e756093908506 : check e756093908506 [] .sourceHead = true := by decide
def e756093922842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756093922842 : Closed e756093922842 ∧ code e756093922842 = 9552186945050 := by decide
theorem cert_e756093922842 : check e756093922842 [] .sourceHead = true := by decide
def e756093925914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756093925914 : Closed e756093925914 ∧ code e756093925914 = 9552186948122 := by decide
theorem cert_e756093925914 : check e756093925914 [] .sourceHead = true := by decide
def e756093933082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756093933082 : Closed e756093933082 ∧ code e756093933082 = 9552186955290 := by decide
theorem cert_e756093933082 : check e756093933082 [] .sourceHead = true := by decide
def e756093934106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756093934106 : Closed e756093934106 ∧ code e756093934106 = 9552186956314 := by decide
theorem cert_e756093934106 : check e756093934106 [] .sourceHead = true := by decide
def e756093988378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756093988378 : Closed e756093988378 ∧ code e756093988378 = 9552187010586 := by decide
theorem cert_e756093988378 : check e756093988378 [] .sourceHead = true := by decide
def e756093991450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756093991450 : Closed e756093991450 ∧ code e756093991450 = 9552187013658 := by decide
theorem cert_e756093991450 : check e756093991450 [] .sourceHead = true := by decide
def e756094003738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094003738 : Closed e756094003738 ∧ code e756094003738 = 9552187025946 := by decide
theorem cert_e756094003738 : check e756094003738 [] .sourceHead = true := by decide
def e756094031386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094031386 : Closed e756094031386 ∧ code e756094031386 = 9552187053594 := by decide
theorem cert_e756094031386 : check e756094031386 [] .sourceHead = true := by decide
def e756094032410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094032410 : Closed e756094032410 ∧ code e756094032410 = 9552187054618 := by decide
theorem cert_e756094032410 : check e756094032410 [] .sourceHead = true := by decide
def e756094036506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094036506 : Closed e756094036506 ∧ code e756094036506 = 9552187058714 := by decide
theorem cert_e756094036506 : check e756094036506 [] .sourceHead = true := by decide
def e756094250522 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094250522 : Closed e756094250522 ∧ code e756094250522 = 9552187272730 := by decide
theorem cert_e756094250522 : check e756094250522 [] .sourceHead = true := by decide
def e756094253594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094253594 : Closed e756094253594 ∧ code e756094253594 = 9552187275802 := by decide
theorem cert_e756094253594 : check e756094253594 [] .sourceHead = true := by decide
def e756094265882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094265882 : Closed e756094265882 ∧ code e756094265882 = 9552187288090 := by decide
theorem cert_e756094265882 : check e756094265882 [] .sourceHead = true := by decide
def e756094315034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094315034 : Closed e756094315034 ∧ code e756094315034 = 9552187337242 := by decide
theorem cert_e756094315034 : check e756094315034 [] .sourceHead = true := by decide
def e756094424602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094424602 : Closed e756094424602 ∧ code e756094424602 = 9552187446810 := by decide
theorem cert_e756094424602 : check e756094424602 [] .sourceHead = true := by decide
def e756094425626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094425626 : Closed e756094425626 ∧ code e756094425626 = 9552187447834 := by decide
theorem cert_e756094425626 : check e756094425626 [] .sourceHead = true := by decide
def e756094429722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094429722 : Closed e756094429722 ∧ code e756094429722 = 9552187451930 := by decide
theorem cert_e756094429722 : check e756094429722 [] .sourceHead = true := by decide
def e756094446106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756094446106 : Closed e756094446106 ∧ code e756094446106 = 9552187468314 := by decide
theorem cert_e756094446106 : check e756094446106 [] .sourceHead = true := by decide
def e756095086106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095086106 : Closed e756095086106 ∧ code e756095086106 = 9552188108314 := by decide
theorem cert_e756095086106 : check e756095086106 [] .sourceHead = true := by decide
def e756095088154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095088154 : Closed e756095088154 ∧ code e756095088154 = 9552188110362 := by decide
theorem cert_e756095088154 : check e756095088154 [] .sourceHead = true := by decide
def e756095104538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095104538 : Closed e756095104538 ∧ code e756095104538 = 9552188126746 := by decide
theorem cert_e756095104538 : check e756095104538 [] .sourceHead = true := by decide
def e756095479322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095479322 : Closed e756095479322 ∧ code e756095479322 = 9552188501530 := by decide
theorem cert_e756095479322 : check e756095479322 [] .sourceHead = true := by decide
def e756095481370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095481370 : Closed e756095481370 ∧ code e756095481370 = 9552188503578 := by decide
theorem cert_e756095481370 : check e756095481370 [] .sourceHead = true := by decide
def e756095495706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095495706 : Closed e756095495706 ∧ code e756095495706 = 9552188517914 := by decide
theorem cert_e756095495706 : check e756095495706 [] .sourceHead = true := by decide
def e756095498778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095498778 : Closed e756095498778 ∧ code e756095498778 = 9552188520986 := by decide
theorem cert_e756095498778 : check e756095498778 [] .sourceHead = true := by decide
def e756095505946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095505946 : Closed e756095505946 ∧ code e756095505946 = 9552188528154 := by decide
theorem cert_e756095505946 : check e756095505946 [] .sourceHead = true := by decide
def e756095506970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095506970 : Closed e756095506970 ∧ code e756095506970 = 9552188529178 := by decide
theorem cert_e756095506970 : check e756095506970 [] .sourceHead = true := by decide
def e756095561242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095561242 : Closed e756095561242 ∧ code e756095561242 = 9552188583450 := by decide
theorem cert_e756095561242 : check e756095561242 [] .sourceHead = true := by decide
def e756095564314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095564314 : Closed e756095564314 ∧ code e756095564314 = 9552188586522 := by decide
theorem cert_e756095564314 : check e756095564314 [] .sourceHead = true := by decide
def e756095576602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095576602 : Closed e756095576602 ∧ code e756095576602 = 9552188598810 := by decide
theorem cert_e756095576602 : check e756095576602 [] .sourceHead = true := by decide
def e756095604250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095604250 : Closed e756095604250 ∧ code e756095604250 = 9552188626458 := by decide
theorem cert_e756095604250 : check e756095604250 [] .sourceHead = true := by decide
def e756095605274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095605274 : Closed e756095605274 ∧ code e756095605274 = 9552188627482 := by decide
theorem cert_e756095605274 : check e756095605274 [] .sourceHead = true := by decide
def e756095609370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095609370 : Closed e756095609370 ∧ code e756095609370 = 9552188631578 := by decide
theorem cert_e756095609370 : check e756095609370 [] .sourceHead = true := by decide
def e756095872538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095872538 : Closed e756095872538 ∧ code e756095872538 = 9552188894746 := by decide
theorem cert_e756095872538 : check e756095872538 [] .sourceHead = true := by decide
def e756095874586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095874586 : Closed e756095874586 ∧ code e756095874586 = 9552188896794 := by decide
theorem cert_e756095874586 : check e756095874586 [] .sourceHead = true := by decide
def e756095888922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095888922 : Closed e756095888922 ∧ code e756095888922 = 9552188911130 := by decide
theorem cert_e756095888922 : check e756095888922 [] .sourceHead = true := by decide
def e756095891994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095891994 : Closed e756095891994 ∧ code e756095891994 = 9552188914202 := by decide
theorem cert_e756095891994 : check e756095891994 [] .sourceHead = true := by decide
def e756095899162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095899162 : Closed e756095899162 ∧ code e756095899162 = 9552188921370 := by decide
theorem cert_e756095899162 : check e756095899162 [] .sourceHead = true := by decide
def e756095900186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095900186 : Closed e756095900186 ∧ code e756095900186 = 9552188922394 := by decide
theorem cert_e756095900186 : check e756095900186 [] .sourceHead = true := by decide
def e756095970842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095970842 : Closed e756095970842 ∧ code e756095970842 = 9552188993050 := by decide
theorem cert_e756095970842 : check e756095970842 [] .sourceHead = true := by decide
def e756095972890 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756095972890 : Closed e756095972890 ∧ code e756095972890 = 9552188995098 := by decide
theorem cert_e756095972890 : check e756095972890 [] .sourceHead = true := by decide
def e756096069146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096069146 : Closed e756096069146 ∧ code e756096069146 = 9552189091354 := by decide
theorem cert_e756096069146 : check e756096069146 [] .sourceHead = true := by decide
def e756096072218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096072218 : Closed e756096072218 ∧ code e756096072218 = 9552189094426 := by decide
theorem cert_e756096072218 : check e756096072218 [] .sourceHead = true := by decide
def e756096098330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756096098330 : Closed e756096098330 ∧ code e756096098330 = 9552189120538 := by decide
theorem cert_e756096098330 : check e756096098330 [] .sourceHead = true := by decide
def e756096098422 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756096098422 : Closed e756096098422 ∧ code e756096098422 = 9552189120630 := by decide
theorem cert_e756096098422 : check e756096098422 [] .sourceHead = true := by decide
def e756096098666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756096098666 : Closed e756096098666 ∧ code e756096098666 = 9552189120874 := by decide
theorem cert_e756096098666 : check e756096098666 [] .sourceHead = true := by decide
def e756096098714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756096098714 : Closed e756096098714 ∧ code e756096098714 = 9552189120922 := by decide
theorem cert_e756096098714 : check e756096098714 [] .sourceHead = true := by decide
def e756096099866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756096099866 : Closed e756096099866 ∧ code e756096099866 = 9552189122074 := by decide
theorem cert_e756096099866 : check e756096099866 [] .sourceHead = true := by decide
def e756096120346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096120346 : Closed e756096120346 ∧ code e756096120346 = 9552189142554 := by decide
theorem cert_e756096120346 : check e756096120346 [] .sourceHead = true := by decide
def e756096121370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096121370 : Closed e756096121370 ∧ code e756096121370 = 9552189143578 := by decide
theorem cert_e756096121370 : check e756096121370 [] .sourceHead = true := by decide
def e756096131098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756096131098 : Closed e756096131098 ∧ code e756096131098 = 9552189153306 := by decide
theorem cert_e756096131098 : check e756096131098 [] .sourceHead = true := by decide
def e756096131190 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756096131190 : Closed e756096131190 ∧ code e756096131190 = 9552189153398 := by decide
theorem cert_e756096131190 : check e756096131190 [] .sourceHead = true := by decide
def e756096131434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756096131434 : Closed e756096131434 ∧ code e756096131434 = 9552189153642 := by decide
theorem cert_e756096131434 : check e756096131434 [] .sourceHead = true := by decide
def e756096131482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756096131482 : Closed e756096131482 ∧ code e756096131482 = 9552189153690 := by decide
theorem cert_e756096131482 : check e756096131482 [] .sourceHead = true := by decide
def e756096132634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756096132634 : Closed e756096132634 ∧ code e756096132634 = 9552189154842 := by decide
theorem cert_e756096132634 : check e756096132634 [] .sourceHead = true := by decide
def e756096232986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096232986 : Closed e756096232986 ∧ code e756096232986 = 9552189255194 := by decide
theorem cert_e756096232986 : check e756096232986 [] .sourceHead = true := by decide
def e756096235034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096235034 : Closed e756096235034 ∧ code e756096235034 = 9552189257242 := by decide
theorem cert_e756096235034 : check e756096235034 [] .sourceHead = true := by decide
def e756096282138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096282138 : Closed e756096282138 ∧ code e756096282138 = 9552189304346 := by decide
theorem cert_e756096282138 : check e756096282138 [] .sourceHead = true := by decide
def e756096285210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096285210 : Closed e756096285210 ∧ code e756096285210 = 9552189307418 := by decide
theorem cert_e756096285210 : check e756096285210 [] .sourceHead = true := by decide
def e756096297498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096297498 : Closed e756096297498 ∧ code e756096297498 = 9552189319706 := by decide
theorem cert_e756096297498 : check e756096297498 [] .sourceHead = true := by decide
def e756096331290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096331290 : Closed e756096331290 ∧ code e756096331290 = 9552189353498 := by decide
theorem cert_e756096331290 : check e756096331290 [] .sourceHead = true := by decide
def e756096334362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096334362 : Closed e756096334362 ∧ code e756096334362 = 9552189356570 := by decide
theorem cert_e756096334362 : check e756096334362 [] .sourceHead = true := by decide
def e756096360474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756096360474 : Closed e756096360474 ∧ code e756096360474 = 9552189382682 := by decide
theorem cert_e756096360474 : check e756096360474 [] .sourceHead = true := by decide
def e756096360566 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756096360566 : Closed e756096360566 ∧ code e756096360566 = 9552189382774 := by decide
theorem cert_e756096360566 : check e756096360566 [] .sourceHead = true := by decide
def e756096360810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756096360810 : Closed e756096360810 ∧ code e756096360810 = 9552189383018 := by decide
theorem cert_e756096360810 : check e756096360810 [] .sourceHead = true := by decide
def e756096360858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756096360858 : Closed e756096360858 ∧ code e756096360858 = 9552189383066 := by decide
theorem cert_e756096360858 : check e756096360858 [] .sourceHead = true := by decide
def e756096362010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756096362010 : Closed e756096362010 ∧ code e756096362010 = 9552189384218 := by decide
theorem cert_e756096362010 : check e756096362010 [] .sourceHead = true := by decide
def e756096376346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096376346 : Closed e756096376346 ∧ code e756096376346 = 9552189398554 := by decide
theorem cert_e756096376346 : check e756096376346 [] .sourceHead = true := by decide
def e756096397510 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756096397510 : Closed e756096397510 ∧ code e756096397510 = 9552189419718 := by decide
theorem cert_e756096397510 : check e756096397510 [] .sourceHead = true := by decide
def e756096405018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096405018 : Closed e756096405018 ∧ code e756096405018 = 9552189427226 := by decide
theorem cert_e756096405018 : check e756096405018 [] .sourceHead = true := by decide
def e756096408090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096408090 : Closed e756096408090 ∧ code e756096408090 = 9552189430298 := by decide
theorem cert_e756096408090 : check e756096408090 [] .sourceHead = true := by decide
def e756096409626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756096409626 : Closed e756096409626 ∧ code e756096409626 = 9552189431834 := by decide
theorem cert_e756096409626 : check e756096409626 [] .sourceHead = true := by decide
def e756096409718 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756096409718 : Closed e756096409718 ∧ code e756096409718 = 9552189431926 := by decide
theorem cert_e756096409718 : check e756096409718 [] .sourceHead = true := by decide
def e756096409962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756096409962 : Closed e756096409962 ∧ code e756096409962 = 9552189432170 := by decide
theorem cert_e756096409962 : check e756096409962 [] .sourceHead = true := by decide
def e756096410010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756096410010 : Closed e756096410010 ∧ code e756096410010 = 9552189432218 := by decide
theorem cert_e756096410010 : check e756096410010 [] .sourceHead = true := by decide
def e756096411162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756096411162 : Closed e756096411162 ∧ code e756096411162 = 9552189433370 := by decide
theorem cert_e756096411162 : check e756096411162 [] .sourceHead = true := by decide
def e756096413894 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756096413894 : Closed e756096413894 ∧ code e756096413894 = 9552189436102 := by decide
theorem cert_e756096413894 : check e756096413894 [] .sourceHead = true := by decide
def e756096415770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756096415770 : Closed e756096415770 ∧ code e756096415770 = 9552189437978 := by decide
theorem cert_e756096415770 : check e756096415770 [] .sourceHead = true := by decide
def e756096464410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096464410 : Closed e756096464410 ∧ code e756096464410 = 9552189486618 := by decide
theorem cert_e756096464410 : check e756096464410 [] .sourceHead = true := by decide
def e756096488986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096488986 : Closed e756096488986 ∧ code e756096488986 = 9552189511194 := by decide
theorem cert_e756096488986 : check e756096488986 [] .sourceHead = true := by decide
def e756096490010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096490010 : Closed e756096490010 ∧ code e756096490010 = 9552189512218 := by decide
theorem cert_e756096490010 : check e756096490010 [] .sourceHead = true := by decide
def e756096494106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096494106 : Closed e756096494106 ∧ code e756096494106 = 9552189516314 := by decide
theorem cert_e756096494106 : check e756096494106 [] .sourceHead = true := by decide
def e756096513562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096513562 : Closed e756096513562 ∧ code e756096513562 = 9552189535770 := by decide
theorem cert_e756096513562 : check e756096513562 [] .sourceHead = true := by decide
def e756096514586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096514586 : Closed e756096514586 ∧ code e756096514586 = 9552189536794 := by decide
theorem cert_e756096514586 : check e756096514586 [] .sourceHead = true := by decide
def e756096524314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756096524314 : Closed e756096524314 ∧ code e756096524314 = 9552189546522 := by decide
theorem cert_e756096524314 : check e756096524314 [] .sourceHead = true := by decide
def e756096524406 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756096524406 : Closed e756096524406 ∧ code e756096524406 = 9552189546614 := by decide
theorem cert_e756096524406 : check e756096524406 [] .sourceHead = true := by decide
def e756096524650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756096524650 : Closed e756096524650 ∧ code e756096524650 = 9552189546858 := by decide
theorem cert_e756096524650 : check e756096524650 [] .sourceHead = true := by decide
def e756096524698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756096524698 : Closed e756096524698 ∧ code e756096524698 = 9552189546906 := by decide
theorem cert_e756096524698 : check e756096524698 [] .sourceHead = true := by decide
def e756096525850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756096525850 : Closed e756096525850 ∧ code e756096525850 = 9552189548058 := by decide
theorem cert_e756096525850 : check e756096525850 [] .sourceHead = true := by decide
def e756096536090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096536090 : Closed e756096536090 ∧ code e756096536090 = 9552189558298 := by decide
theorem cert_e756096536090 : check e756096536090 [] .sourceHead = true := by decide
def e756096539162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096539162 : Closed e756096539162 ∧ code e756096539162 = 9552189561370 := by decide
theorem cert_e756096539162 : check e756096539162 [] .sourceHead = true := by decide
def e756096540698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756096540698 : Closed e756096540698 ∧ code e756096540698 = 9552189562906 := by decide
theorem cert_e756096540698 : check e756096540698 [] .sourceHead = true := by decide
def e756096540790 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756096540790 : Closed e756096540790 ∧ code e756096540790 = 9552189562998 := by decide
theorem cert_e756096540790 : check e756096540790 [] .sourceHead = true := by decide
def e756096541034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756096541034 : Closed e756096541034 ∧ code e756096541034 = 9552189563242 := by decide
theorem cert_e756096541034 : check e756096541034 [] .sourceHead = true := by decide
def e756096541082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756096541082 : Closed e756096541082 ∧ code e756096541082 = 9552189563290 := by decide
theorem cert_e756096541082 : check e756096541082 [] .sourceHead = true := by decide
def e756096542234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756096542234 : Closed e756096542234 ∧ code e756096542234 = 9552189564442 := by decide
theorem cert_e756096542234 : check e756096542234 [] .sourceHead = true := by decide
def e756096544966 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756096544966 : Closed e756096544966 ∧ code e756096544966 = 9552189567174 := by decide
theorem cert_e756096544966 : check e756096544966 [] .sourceHead = true := by decide
def e756096546842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756096546842 : Closed e756096546842 ∧ code e756096546842 = 9552189569050 := by decide
theorem cert_e756096546842 : check e756096546842 [] .sourceHead = true := by decide
def e756096555034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756096555034 : Closed e756096555034 ∧ code e756096555034 = 9552189577242 := by decide
theorem cert_e756096555034 : check e756096555034 [] .sourceHead = true := by decide
def e756096921114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096921114 : Closed e756096921114 ∧ code e756096921114 = 9552189943322 := by decide
theorem cert_e756096921114 : check e756096921114 [] .sourceHead = true := by decide
def e756096923162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096923162 : Closed e756096923162 ∧ code e756096923162 = 9552189945370 := by decide
theorem cert_e756096923162 : check e756096923162 [] .sourceHead = true := by decide
def e756096937498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096937498 : Closed e756096937498 ∧ code e756096937498 = 9552189959706 := by decide
theorem cert_e756096937498 : check e756096937498 [] .sourceHead = true := by decide
def e756096940570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096940570 : Closed e756096940570 ∧ code e756096940570 = 9552189962778 := by decide
theorem cert_e756096940570 : check e756096940570 [] .sourceHead = true := by decide
def e756096947738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096947738 : Closed e756096947738 ∧ code e756096947738 = 9552189969946 := by decide
theorem cert_e756096947738 : check e756096947738 [] .sourceHead = true := by decide
def e756096948762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756096948762 : Closed e756096948762 ∧ code e756096948762 = 9552189970970 := by decide
theorem cert_e756096948762 : check e756096948762 [] .sourceHead = true := by decide
def e756097134106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097134106 : Closed e756097134106 ∧ code e756097134106 = 9552190156314 := by decide
theorem cert_e756097134106 : check e756097134106 [] .sourceHead = true := by decide
def e756097137178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097137178 : Closed e756097137178 ∧ code e756097137178 = 9552190159386 := by decide
theorem cert_e756097137178 : check e756097137178 [] .sourceHead = true := by decide
def e756097149466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097149466 : Closed e756097149466 ∧ code e756097149466 = 9552190171674 := by decide
theorem cert_e756097149466 : check e756097149466 [] .sourceHead = true := by decide
def e756097198618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097198618 : Closed e756097198618 ∧ code e756097198618 = 9552190220826 := by decide
theorem cert_e756097198618 : check e756097198618 [] .sourceHead = true := by decide
def e756097281562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097281562 : Closed e756097281562 ∧ code e756097281562 = 9552190303770 := by decide
theorem cert_e756097281562 : check e756097281562 [] .sourceHead = true := by decide
def e756097283610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097283610 : Closed e756097283610 ∧ code e756097283610 = 9552190305818 := by decide
theorem cert_e756097283610 : check e756097283610 [] .sourceHead = true := by decide
def e756097330714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097330714 : Closed e756097330714 ∧ code e756097330714 = 9552190352922 := by decide
theorem cert_e756097330714 : check e756097330714 [] .sourceHead = true := by decide
def e756097333786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097333786 : Closed e756097333786 ∧ code e756097333786 = 9552190355994 := by decide
theorem cert_e756097333786 : check e756097333786 [] .sourceHead = true := by decide
def e756097346074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097346074 : Closed e756097346074 ∧ code e756097346074 = 9552190368282 := by decide
theorem cert_e756097346074 : check e756097346074 [] .sourceHead = true := by decide
def e756097379866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097379866 : Closed e756097379866 ∧ code e756097379866 = 9552190402074 := by decide
theorem cert_e756097379866 : check e756097379866 [] .sourceHead = true := by decide
def e756097382938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097382938 : Closed e756097382938 ∧ code e756097382938 = 9552190405146 := by decide
theorem cert_e756097382938 : check e756097382938 [] .sourceHead = true := by decide
def e756097409050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756097409050 : Closed e756097409050 ∧ code e756097409050 = 9552190431258 := by decide
theorem cert_e756097409050 : check e756097409050 [] .sourceHead = true := by decide
def e756097409142 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756097409142 : Closed e756097409142 ∧ code e756097409142 = 9552190431350 := by decide
theorem cert_e756097409142 : check e756097409142 [] .sourceHead = true := by decide
def e756097409386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756097409386 : Closed e756097409386 ∧ code e756097409386 = 9552190431594 := by decide
theorem cert_e756097409386 : check e756097409386 [] .sourceHead = true := by decide
def e756097409434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756097409434 : Closed e756097409434 ∧ code e756097409434 = 9552190431642 := by decide
theorem cert_e756097409434 : check e756097409434 [] .sourceHead = true := by decide
def e756097410586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756097410586 : Closed e756097410586 ∧ code e756097410586 = 9552190432794 := by decide
theorem cert_e756097410586 : check e756097410586 [] .sourceHead = true := by decide
def e756097424922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097424922 : Closed e756097424922 ∧ code e756097424922 = 9552190447130 := by decide
theorem cert_e756097424922 : check e756097424922 [] .sourceHead = true := by decide
def e756097446086 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756097446086 : Closed e756097446086 ∧ code e756097446086 = 9552190468294 := by decide
theorem cert_e756097446086 : check e756097446086 [] .sourceHead = true := by decide
def e756097453594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756097453594 : Closed e756097453594 ∧ code e756097453594 = 9552190475802 := by decide
theorem cert_e756097453594 : check e756097453594 [] .sourceHead = true := by decide
end Blc.Floor43
