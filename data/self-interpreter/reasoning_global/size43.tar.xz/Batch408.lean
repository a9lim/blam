import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373069730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373069730 : Closed e2422373069730 ∧ code e2422373069730 = 11218466091938 := by decide
theorem cert_e2422373069730 : check e2422373069730 [[],[]] .three = true := by decide
def e2422373069742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422373069742 : Closed e2422373069742 ∧ code e2422373069742 = 11218466091950 := by decide
theorem cert_e2422373069742 : check e2422373069742 [[],[]] .three = true := by decide
def e2422373069754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422373069754 : Closed e2422373069754 ∧ code e2422373069754 = 11218466091962 := by decide
theorem cert_e2422373069754 : check e2422373069754 [[],[]] .three = true := by decide
def e2422373069782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422373069782 : Closed e2422373069782 ∧ code e2422373069782 = 11218466091990 := by decide
theorem cert_e2422373069782 : check e2422373069782 [[],[]] .three = true := by decide
def e2422373069786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422373069786 : Closed e2422373069786 ∧ code e2422373069786 = 11218466091994 := by decide
theorem cert_e2422373069786 : check e2422373069786 [[],[]] .three = true := by decide
def e2422373069802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2422373069802 : Closed e2422373069802 ∧ code e2422373069802 = 11218466092010 := by decide
theorem cert_e2422373069802 : check e2422373069802 [[],[]] .three = true := by decide
def e2422373069854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373069854 : Closed e2422373069854 ∧ code e2422373069854 = 11218466092062 := by decide
theorem cert_e2422373069854 : check e2422373069854 [[],[]] .three = true := by decide
def e2422373069878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373069878 : Closed e2422373069878 ∧ code e2422373069878 = 11218466092086 := by decide
theorem cert_e2422373069878 : check e2422373069878 [[],[]] .three = true := by decide
def e2422373069882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373069882 : Closed e2422373069882 ∧ code e2422373069882 = 11218466092090 := by decide
theorem cert_e2422373069882 : check e2422373069882 [[],[]] .three = true := by decide
def e2422373070022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373070022 : Closed e2422373070022 ∧ code e2422373070022 = 11218466092230 := by decide
theorem cert_e2422373070022 : check e2422373070022 [[],[]] .three = true := by decide
def e2422373070046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373070046 : Closed e2422373070046 ∧ code e2422373070046 = 11218466092254 := by decide
theorem cert_e2422373070046 : check e2422373070046 [[],[]] .three = true := by decide
def e2422373070050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373070050 : Closed e2422373070050 ∧ code e2422373070050 = 11218466092258 := by decide
theorem cert_e2422373070050 : check e2422373070050 [[],[]] .three = true := by decide
def e2422373070062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373070062 : Closed e2422373070062 ∧ code e2422373070062 = 11218466092270 := by decide
theorem cert_e2422373070062 : check e2422373070062 [[],[]] .three = true := by decide
def e2422373070070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373070070 : Closed e2422373070070 ∧ code e2422373070070 = 11218466092278 := by decide
theorem cert_e2422373070070 : check e2422373070070 [[],[]] .three = true := by decide
def e2422373070074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373070074 : Closed e2422373070074 ∧ code e2422373070074 = 11218466092282 := by decide
theorem cert_e2422373070074 : check e2422373070074 [[],[]] .three = true := by decide
def e2422373070350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373070350 : Closed e2422373070350 ∧ code e2422373070350 = 11218466092558 := by decide
theorem cert_e2422373070350 : check e2422373070350 [[],[]] .three = true := by decide
def e2422373070434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373070434 : Closed e2422373070434 ∧ code e2422373070434 = 11218466092642 := by decide
theorem cert_e2422373070434 : check e2422373070434 [[],[]] .three = true := by decide
def e2422373070446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373070446 : Closed e2422373070446 ∧ code e2422373070446 = 11218466092654 := by decide
theorem cert_e2422373070446 : check e2422373070446 [[],[]] .three = true := by decide
def e2422373070458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373070458 : Closed e2422373070458 ∧ code e2422373070458 = 11218466092666 := by decide
theorem cert_e2422373070458 : check e2422373070458 [[],[]] .three = true := by decide
def e2422373070622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e2422373070622 : Closed e2422373070622 ∧ code e2422373070622 = 11218466092830 := by decide
theorem cert_e2422373070622 : check e2422373070622 [[],[]] .three = true := by decide
def e2422373070646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373070646 : Closed e2422373070646 ∧ code e2422373070646 = 11218466092854 := by decide
theorem cert_e2422373070646 : check e2422373070646 [[],[]] .three = true := by decide
def e2422373070650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373070650 : Closed e2422373070650 ∧ code e2422373070650 = 11218466092858 := by decide
theorem cert_e2422373070650 : check e2422373070650 [[],[]] .three = true := by decide
def e2422373070746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373070746 : Closed e2422373070746 ∧ code e2422373070746 = 11218466092954 := by decide
theorem cert_e2422373070746 : check e2422373070746 [[],[]] .three = true := by decide
def e2422373070906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373070906 : Closed e2422373070906 ∧ code e2422373070906 = 11218466093114 := by decide
theorem cert_e2422373070906 : check e2422373070906 [[],[]] .three = true := by decide
def e2422373070954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373070954 : Closed e2422373070954 ∧ code e2422373070954 = 11218466093162 := by decide
theorem cert_e2422373070954 : check e2422373070954 [[],[]] .three = true := by decide
def e2422373071002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373071002 : Closed e2422373071002 ∧ code e2422373071002 = 11218466093210 := by decide
theorem cert_e2422373071002 : check e2422373071002 [[],[]] .three = true := by decide
def e2422373071046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373071046 : Closed e2422373071046 ∧ code e2422373071046 = 11218466093254 := by decide
theorem cert_e2422373071046 : check e2422373071046 [[],[]] .three = true := by decide
def e2422373071070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422373071070 : Closed e2422373071070 ∧ code e2422373071070 = 11218466093278 := by decide
theorem cert_e2422373071070 : check e2422373071070 [[],[]] .three = true := by decide
def e2422373071086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422373071086 : Closed e2422373071086 ∧ code e2422373071086 = 11218466093294 := by decide
theorem cert_e2422373071086 : check e2422373071086 [[],[]] .three = true := by decide
def e2422373071094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422373071094 : Closed e2422373071094 ∧ code e2422373071094 = 11218466093302 := by decide
theorem cert_e2422373071094 : check e2422373071094 [[],[]] .three = true := by decide
def e2422373071098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422373071098 : Closed e2422373071098 ∧ code e2422373071098 = 11218466093306 := by decide
theorem cert_e2422373071098 : check e2422373071098 [[],[]] .three = true := by decide
def e2422373071242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373071242 : Closed e2422373071242 ∧ code e2422373071242 = 11218466093450 := by decide
theorem cert_e2422373071242 : check e2422373071242 [[],[]] .three = true := by decide
def e2422373071266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373071266 : Closed e2422373071266 ∧ code e2422373071266 = 11218466093474 := by decide
theorem cert_e2422373071266 : check e2422373071266 [[],[]] .three = true := by decide
def e2422373071278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422373071278 : Closed e2422373071278 ∧ code e2422373071278 = 11218466093486 := by decide
theorem cert_e2422373071278 : check e2422373071278 [[],[]] .three = true := by decide
def e2422373071286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2422373071286 : Closed e2422373071286 ∧ code e2422373071286 = 11218466093494 := by decide
theorem cert_e2422373071286 : check e2422373071286 [[],[]] .three = true := by decide
def e2422373071290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422373071290 : Closed e2422373071290 ∧ code e2422373071290 = 11218466093498 := by decide
theorem cert_e2422373071290 : check e2422373071290 [[],[]] .three = true := by decide
def e2422373071318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2422373071318 : Closed e2422373071318 ∧ code e2422373071318 = 11218466093526 := by decide
theorem cert_e2422373071318 : check e2422373071318 [[],[]] .three = true := by decide
def e2422373071322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2422373071322 : Closed e2422373071322 ∧ code e2422373071322 = 11218466093530 := by decide
theorem cert_e2422373071322 : check e2422373071322 [[],[]] .three = true := by decide
def e2422373071338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422373071338 : Closed e2422373071338 ∧ code e2422373071338 = 11218466093546 := by decide
theorem cert_e2422373071338 : check e2422373071338 [[],[]] .three = true := by decide
def e2422373071374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373071374 : Closed e2422373071374 ∧ code e2422373071374 = 11218466093582 := by decide
theorem cert_e2422373071374 : check e2422373071374 [[],[]] .three = true := by decide
def e2422373071386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373071386 : Closed e2422373071386 ∧ code e2422373071386 = 11218466093594 := by decide
theorem cert_e2422373071386 : check e2422373071386 [[],[]] .three = true := by decide
def e2422373071422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422373071422 : Closed e2422373071422 ∧ code e2422373071422 = 11218466093630 := by decide
theorem cert_e2422373071422 : check e2422373071422 [[],[]] .three = true := by decide
def e2422373071458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373071458 : Closed e2422373071458 ∧ code e2422373071458 = 11218466093666 := by decide
theorem cert_e2422373071458 : check e2422373071458 [[],[]] .three = true := by decide
def e2422373071470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373071470 : Closed e2422373071470 ∧ code e2422373071470 = 11218466093678 := by decide
theorem cert_e2422373071470 : check e2422373071470 [[],[]] .three = true := by decide
def e2422373071478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373071478 : Closed e2422373071478 ∧ code e2422373071478 = 11218466093686 := by decide
theorem cert_e2422373071478 : check e2422373071478 [[],[]] .three = true := by decide
def e2422373071482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373071482 : Closed e2422373071482 ∧ code e2422373071482 = 11218466093690 := by decide
theorem cert_e2422373071482 : check e2422373071482 [[],[]] .three = true := by decide
def e2422373071646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422373071646 : Closed e2422373071646 ∧ code e2422373071646 = 11218466093854 := by decide
theorem cert_e2422373071646 : check e2422373071646 [[],[]] .three = true := by decide
def e2422373071670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373071670 : Closed e2422373071670 ∧ code e2422373071670 = 11218466093878 := by decide
theorem cert_e2422373071670 : check e2422373071670 [[],[]] .three = true := by decide
def e2422373071674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373071674 : Closed e2422373071674 ∧ code e2422373071674 = 11218466093882 := by decide
theorem cert_e2422373071674 : check e2422373071674 [[],[]] .three = true := by decide
def e2422373071758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422373071758 : Closed e2422373071758 ∧ code e2422373071758 = 11218466093966 := by decide
theorem cert_e2422373071758 : check e2422373071758 [[],[]] .three = true := by decide
def e2422373071770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373071770 : Closed e2422373071770 ∧ code e2422373071770 = 11218466093978 := by decide
theorem cert_e2422373071770 : check e2422373071770 [[],[]] .three = true := by decide
def e2422373071814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422373071814 : Closed e2422373071814 ∧ code e2422373071814 = 11218466094022 := by decide
theorem cert_e2422373071814 : check e2422373071814 [[],[]] .three = true := by decide
def e2422373071982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422373071982 : Closed e2422373071982 ∧ code e2422373071982 = 11218466094190 := by decide
private def t_e2422373071982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.lam (.var 1))) (.var 2)))))))
theorem cert_e2422373071982 : ¬ IsSelfInterpreter e2422373071982 :=
  wSource (t := t_e2422373071982) (replay_sound (ps := []) (t := e2422373071982) (by decide)) (by decide)
def e2422373071994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422373071994 : Closed e2422373071994 ∧ code e2422373071994 = 11218466094202 := by decide
private def t_e2422373071994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.lam (.var 3))) (.var 0)))))))
theorem cert_e2422373071994 : ¬ IsSelfInterpreter e2422373071994 :=
  wSource (t := t_e2422373071994) (replay_sound (ps := []) (t := e2422373071994) (by decide)) (by decide)
def e2422373072086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422373072086 : Closed e2422373072086 ∧ code e2422373072086 = 11218466094294 := by decide
private def t_e2422373072086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem cert_e2422373072086 : ¬ IsSelfInterpreter e2422373072086 :=
  wSource (t := t_e2422373072086) (replay_sound (ps := []) (t := e2422373072086) (by decide)) (by decide)
def e2422373072090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422373072090 : Closed e2422373072090 ∧ code e2422373072090 = 11218466094298 := by decide
private def t_e2422373072090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem cert_e2422373072090 : ¬ IsSelfInterpreter e2422373072090 :=
  wSource (t := t_e2422373072090) (replay_sound (ps := []) (t := e2422373072090) (by decide)) (by decide)
def e2422373072106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422373072106 : Closed e2422373072106 ∧ code e2422373072106 = 11218466094314 := by decide
private def t_e2422373072106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem cert_e2422373072106 : ¬ IsSelfInterpreter e2422373072106 :=
  wSource (t := t_e2422373072106) (replay_sound (ps := []) (t := e2422373072106) (by decide)) (by decide)
def e2422373072158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422373072158 : Closed e2422373072158 ∧ code e2422373072158 = 11218466094366 := by decide
private def t_e2422373072158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.lam (.var 3))))))))
theorem cert_e2422373072158 : ¬ IsSelfInterpreter e2422373072158 :=
  wSource (t := t_e2422373072158) (replay_sound (ps := []) (t := e2422373072158) (by decide)) (by decide)
def e2422373072182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373072182 : Closed e2422373072182 ∧ code e2422373072182 = 11218466094390 := by decide
private def t_e2422373072182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem cert_e2422373072182 : ¬ IsSelfInterpreter e2422373072182 :=
  wSource (t := t_e2422373072182) (replay_sound (ps := []) (t := e2422373072182) (by decide)) (by decide)
def e2422373072186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373072186 : Closed e2422373072186 ∧ code e2422373072186 = 11218466094394 := by decide
private def t_e2422373072186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem cert_e2422373072186 : ¬ IsSelfInterpreter e2422373072186 :=
  wSource (t := t_e2422373072186) (replay_sound (ps := []) (t := e2422373072186) (by decide)) (by decide)
def e2422373072282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373072282 : Closed e2422373072282 ∧ code e2422373072282 = 11218466094490 := by decide
private def t_e2422373072282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e2422373072282 : ¬ IsSelfInterpreter e2422373072282 :=
  wSource (t := t_e2422373072282) (replay_sound (ps := []) (t := e2422373072282) (by decide)) (by decide)
def e2422373072326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422373072326 : Closed e2422373072326 ∧ code e2422373072326 = 11218466094534 := by decide
private def t_e2422373072326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 2)) (.lam (.var 1))))))))
theorem cert_e2422373072326 : ¬ IsSelfInterpreter e2422373072326 :=
  wSource (t := t_e2422373072326) (replay_sound (ps := []) (t := e2422373072326) (by decide)) (by decide)
def e2422373100986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))))
theorem wire_e2422373100986 : Closed e2422373100986 ∧ code e2422373100986 = 11218466123194 := by decide
theorem cert_e2422373100986 : check e2422373100986 [[],[]] .smaller = true := by decide
def e2422373101018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))))
theorem wire_e2422373101018 : Closed e2422373101018 ∧ code e2422373101018 = 11218466123226 := by decide
theorem cert_e2422373101018 : check e2422373101018 [[],[]] .smaller = true := by decide
def e2422373101242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))))
theorem wire_e2422373101242 : Closed e2422373101242 ∧ code e2422373101242 = 11218466123450 := by decide
theorem cert_e2422373101242 : check e2422373101242 [[],[]] .smaller = true := by decide
def e2422373101290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))))
theorem wire_e2422373101290 : Closed e2422373101290 ∧ code e2422373101290 = 11218466123498 := by decide
theorem cert_e2422373101290 : check e2422373101290 [[],[]] .smaller = true := by decide
def e2422373101402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))))
theorem wire_e2422373101402 : Closed e2422373101402 ∧ code e2422373101402 = 11218466123610 := by decide
theorem cert_e2422373101402 : check e2422373101402 [[],[]] .smaller = true := by decide
def e2422373101418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))))
theorem wire_e2422373101418 : Closed e2422373101418 ∧ code e2422373101418 = 11218466123626 := by decide
theorem cert_e2422373101418 : check e2422373101418 [[],[]] .smaller = true := by decide
def e2422373102522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))))
theorem wire_e2422373102522 : Closed e2422373102522 ∧ code e2422373102522 = 11218466124730 := by decide
theorem cert_e2422373102522 : check e2422373102522 [[],[]] .smaller = true := by decide
def e2422373102554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))))
theorem wire_e2422373102554 : Closed e2422373102554 ∧ code e2422373102554 = 11218466124762 := by decide
theorem cert_e2422373102554 : check e2422373102554 [[],[]] .smaller = true := by decide
def e2422373102830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373102830 : Closed e2422373102830 ∧ code e2422373102830 = 11218466125038 := by decide
theorem cert_e2422373102830 : check e2422373102830 [[],[]] .smaller = true := by decide
def e2422373102838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373102838 : Closed e2422373102838 ∧ code e2422373102838 = 11218466125046 := by decide
theorem cert_e2422373102838 : check e2422373102838 [[],[]] .smaller = true := by decide
def e2422373104058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))))
theorem wire_e2422373104058 : Closed e2422373104058 ∧ code e2422373104058 = 11218466126266 := by decide
theorem cert_e2422373104058 : check e2422373104058 [[],[]] .smaller = true := by decide
def e2422373104106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))))
theorem wire_e2422373104106 : Closed e2422373104106 ∧ code e2422373104106 = 11218466126314 := by decide
theorem cert_e2422373104106 : check e2422373104106 [[],[]] .smaller = true := by decide
def e2422373104858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))))
theorem wire_e2422373104858 : Closed e2422373104858 ∧ code e2422373104858 = 11218466127066 := by decide
theorem cert_e2422373104858 : check e2422373104858 [[],[]] .smaller = true := by decide
def e2422373104874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))))
theorem wire_e2422373104874 : Closed e2422373104874 ∧ code e2422373104874 = 11218466127082 := by decide
theorem cert_e2422373104874 : check e2422373104874 [[],[]] .smaller = true := by decide
def e2422373105134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 2)))))))
theorem wire_e2422373105134 : Closed e2422373105134 ∧ code e2422373105134 = 11218466127342 := by decide
theorem cert_e2422373105134 : check e2422373105134 [[],[]] .smaller = true := by decide
def e2422373105142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 4))))) (.var 1)))))))
theorem wire_e2422373105142 : Closed e2422373105142 ∧ code e2422373105142 = 11218466127350 := by decide
theorem cert_e2422373105142 : check e2422373105142 [[],[]] .smaller = true := by decide
def e2422373105390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 2))))) (.var 2)))))))
theorem wire_e2422373105390 : Closed e2422373105390 ∧ code e2422373105390 = 11218466127598 := by decide
theorem cert_e2422373105390 : check e2422373105390 [[],[]] .smaller = true := by decide
def e2422373105402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4))))) (.var 0)))))))
theorem wire_e2422373105402 : Closed e2422373105402 ∧ code e2422373105402 = 11218466127610 := by decide
theorem cert_e2422373105402 : check e2422373105402 [[],[]] .smaller = true := by decide
def e2422373105526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 2))))) (.var 1)))))))
theorem wire_e2422373105526 : Closed e2422373105526 ∧ code e2422373105526 = 11218466127734 := by decide
theorem cert_e2422373105526 : check e2422373105526 [[],[]] .smaller = true := by decide
def e2422373105530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3))))) (.var 0)))))))
theorem wire_e2422373105530 : Closed e2422373105530 ∧ code e2422373105530 = 11218466127738 := by decide
theorem cert_e2422373105530 : check e2422373105530 [[],[]] .smaller = true := by decide
def e2422373108590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422373108590 : Closed e2422373108590 ∧ code e2422373108590 = 11218466130798 := by decide
theorem cert_e2422373108590 : check e2422373108590 [[],[]] .smaller = true := by decide
def e2422373108598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422373108598 : Closed e2422373108598 ∧ code e2422373108598 = 11218466130806 := by decide
theorem cert_e2422373108598 : check e2422373108598 [[],[]] .smaller = true := by decide
def e2422373108654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422373108654 : Closed e2422373108654 ∧ code e2422373108654 = 11218466130862 := by decide
theorem cert_e2422373108654 : check e2422373108654 [[],[]] .smaller = true := by decide
def e2422373108666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422373108666 : Closed e2422373108666 ∧ code e2422373108666 = 11218466130874 := by decide
theorem cert_e2422373108666 : check e2422373108666 [[],[]] .smaller = true := by decide
def e2422373108694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422373108694 : Closed e2422373108694 ∧ code e2422373108694 = 11218466130902 := by decide
theorem cert_e2422373108694 : check e2422373108694 [[],[]] .smaller = true := by decide
def e2422373108698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422373108698 : Closed e2422373108698 ∧ code e2422373108698 = 11218466130906 := by decide
theorem cert_e2422373108698 : check e2422373108698 [[],[]] .smaller = true := by decide
def e2422373108974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373108974 : Closed e2422373108974 ∧ code e2422373108974 = 11218466131182 := by decide
theorem cert_e2422373108974 : check e2422373108974 [[],[]] .smaller = true := by decide
def e2422373108982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373108982 : Closed e2422373108982 ∧ code e2422373108982 = 11218466131190 := by decide
theorem cert_e2422373108982 : check e2422373108982 [[],[]] .smaller = true := by decide
def e2422373109358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373109358 : Closed e2422373109358 ∧ code e2422373109358 = 11218466131566 := by decide
theorem cert_e2422373109358 : check e2422373109358 [[],[]] .smaller = true := by decide
def e2422373109370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373109370 : Closed e2422373109370 ∧ code e2422373109370 = 11218466131578 := by decide
theorem cert_e2422373109370 : check e2422373109370 [[],[]] .smaller = true := by decide
def e2422373109558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373109558 : Closed e2422373109558 ∧ code e2422373109558 = 11218466131766 := by decide
theorem cert_e2422373109558 : check e2422373109558 [[],[]] .smaller = true := by decide
def e2422373109562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373109562 : Closed e2422373109562 ∧ code e2422373109562 = 11218466131770 := by decide
theorem cert_e2422373109562 : check e2422373109562 [[],[]] .smaller = true := by decide
def e2422373118942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373118942 : Closed e2422373118942 ∧ code e2422373118942 = 11218466141150 := by decide
theorem cert_e2422373118942 : check e2422373118942 [[],[]] .three = true := by decide
def e2422373118958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373118958 : Closed e2422373118958 ∧ code e2422373118958 = 11218466141166 := by decide
theorem cert_e2422373118958 : check e2422373118958 [[],[]] .three = true := by decide
def e2422373120478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373120478 : Closed e2422373120478 ∧ code e2422373120478 = 11218466142686 := by decide
theorem cert_e2422373120478 : check e2422373120478 [[],[]] .three = true := by decide
def e2422373120494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373120494 : Closed e2422373120494 ∧ code e2422373120494 = 11218466142702 := by decide
theorem cert_e2422373120494 : check e2422373120494 [[],[]] .smaller = true := by decide
def e2422373120502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373120502 : Closed e2422373120502 ∧ code e2422373120502 = 11218466142710 := by decide
theorem cert_e2422373120502 : check e2422373120502 [[],[]] .three = true := by decide
def e2422373121246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373121246 : Closed e2422373121246 ∧ code e2422373121246 = 11218466143454 := by decide
theorem cert_e2422373121246 : check e2422373121246 [[],[]] .three = true := by decide
def e2422373121262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373121262 : Closed e2422373121262 ∧ code e2422373121262 = 11218466143470 := by decide
theorem cert_e2422373121262 : check e2422373121262 [[],[]] .smaller = true := by decide
def e2422373121270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373121270 : Closed e2422373121270 ∧ code e2422373121270 = 11218466143478 := by decide
theorem cert_e2422373121270 : check e2422373121270 [[],[]] .smaller = true := by decide
def e2422373121274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373121274 : Closed e2422373121274 ∧ code e2422373121274 = 11218466143482 := by decide
theorem cert_e2422373121274 : check e2422373121274 [[],[]] .three = true := by decide
def e2422373121646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373121646 : Closed e2422373121646 ∧ code e2422373121646 = 11218466143854 := by decide
theorem cert_e2422373121646 : check e2422373121646 [[],[]] .three = true := by decide
def e2422373121654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373121654 : Closed e2422373121654 ∧ code e2422373121654 = 11218466143862 := by decide
theorem cert_e2422373121654 : check e2422373121654 [[],[]] .three = true := by decide
def e2422373121658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373121658 : Closed e2422373121658 ∧ code e2422373121658 = 11218466143866 := by decide
theorem cert_e2422373121658 : check e2422373121658 [[],[]] .three = true := by decide
def e2422373135838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 3)))))))
theorem wire_e2422373135838 : Closed e2422373135838 ∧ code e2422373135838 = 11218466158046 := by decide
theorem cert_e2422373135838 : check e2422373135838 [[],[]] .three = true := by decide
def e2422373135862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 4)))) (.var 1)))))))
theorem wire_e2422373135862 : Closed e2422373135862 ∧ code e2422373135862 = 11218466158070 := by decide
theorem cert_e2422373135862 : check e2422373135862 [[],[]] .three = true := by decide
def e2422373136098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373136098 : Closed e2422373136098 ∧ code e2422373136098 = 11218466158306 := by decide
theorem cert_e2422373136098 : check e2422373136098 [[],[]] .smaller = true := by decide
def e2422373136110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 2)))))))
theorem wire_e2422373136110 : Closed e2422373136110 ∧ code e2422373136110 = 11218466158318 := by decide
theorem cert_e2422373136110 : check e2422373136110 [[],[]] .smaller = true := by decide
def e2422373136118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 1)))))))
theorem wire_e2422373136118 : Closed e2422373136118 ∧ code e2422373136118 = 11218466158326 := by decide
theorem cert_e2422373136118 : check e2422373136118 [[],[]] .smaller = true := by decide
def e2422373136122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))) (.var 0)))))))
theorem wire_e2422373136122 : Closed e2422373136122 ∧ code e2422373136122 = 11218466158330 := by decide
theorem cert_e2422373136122 : check e2422373136122 [[],[]] .three = true := by decide
def e2422373136222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 3)))))))
theorem wire_e2422373136222 : Closed e2422373136222 ∧ code e2422373136222 = 11218466158430 := by decide
theorem cert_e2422373136222 : check e2422373136222 [[],[]] .three = true := by decide
def e2422373136226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422373136226 : Closed e2422373136226 ∧ code e2422373136226 = 11218466158434 := by decide
theorem cert_e2422373136226 : check e2422373136226 [[],[]] .smaller = true := by decide
def e2422373136238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 2)))))))
theorem wire_e2422373136238 : Closed e2422373136238 ∧ code e2422373136238 = 11218466158446 := by decide
theorem cert_e2422373136238 : check e2422373136238 [[],[]] .smaller = true := by decide
def e2422373136250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))) (.var 0)))))))
theorem wire_e2422373136250 : Closed e2422373136250 ∧ code e2422373136250 = 11218466158458 := by decide
theorem cert_e2422373136250 : check e2422373136250 [[],[]] .smaller = true := by decide
def e2422373136310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 1)))))))
theorem wire_e2422373136310 : Closed e2422373136310 ∧ code e2422373136310 = 11218466158518 := by decide
theorem cert_e2422373136310 : check e2422373136310 [[],[]] .smaller = true := by decide
def e2422373136314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))) (.var 0)))))))
theorem wire_e2422373136314 : Closed e2422373136314 ∧ code e2422373136314 = 11218466158522 := by decide
theorem cert_e2422373136314 : check e2422373136314 [[],[]] .smaller = true := by decide
def e2422373136342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373136342 : Closed e2422373136342 ∧ code e2422373136342 = 11218466158550 := by decide
theorem cert_e2422373136342 : check e2422373136342 [[],[]] .three = true := by decide
def e2422373136346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373136346 : Closed e2422373136346 ∧ code e2422373136346 = 11218466158554 := by decide
theorem cert_e2422373136346 : check e2422373136346 [[],[]] .three = true := by decide
def e2422373137122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373137122 : Closed e2422373137122 ∧ code e2422373137122 = 11218466159330 := by decide
theorem cert_e2422373137122 : check e2422373137122 [[],[]] .smaller = true := by decide
def e2422373137134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 2)))))))
theorem wire_e2422373137134 : Closed e2422373137134 ∧ code e2422373137134 = 11218466159342 := by decide
theorem cert_e2422373137134 : check e2422373137134 [[],[]] .smaller = true := by decide
def e2422373137142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 1)))))))
theorem wire_e2422373137142 : Closed e2422373137142 ∧ code e2422373137142 = 11218466159350 := by decide
theorem cert_e2422373137142 : check e2422373137142 [[],[]] .smaller = true := by decide
def e2422373137146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))) (.var 0)))))))
theorem wire_e2422373137146 : Closed e2422373137146 ∧ code e2422373137146 = 11218466159354 := by decide
theorem cert_e2422373137146 : check e2422373137146 [[],[]] .three = true := by decide
def e2422373137314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373137314 : Closed e2422373137314 ∧ code e2422373137314 = 11218466159522 := by decide
theorem cert_e2422373137314 : check e2422373137314 [[],[]] .smaller = true := by decide
def e2422373137326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 2)))))))
theorem wire_e2422373137326 : Closed e2422373137326 ∧ code e2422373137326 = 11218466159534 := by decide
theorem cert_e2422373137326 : check e2422373137326 [[],[]] .smaller = true := by decide
def e2422373137366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373137366 : Closed e2422373137366 ∧ code e2422373137366 = 11218466159574 := by decide
theorem cert_e2422373137366 : check e2422373137366 [[],[]] .smaller = true := by decide
def e2422373137386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373137386 : Closed e2422373137386 ∧ code e2422373137386 = 11218466159594 := by decide
theorem cert_e2422373137386 : check e2422373137386 [[],[]] .three = true := by decide
def e2422373137758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 3)))))))
theorem wire_e2422373137758 : Closed e2422373137758 ∧ code e2422373137758 = 11218466159966 := by decide
theorem cert_e2422373137758 : check e2422373137758 [[],[]] .three = true := by decide
def e2422373137762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422373137762 : Closed e2422373137762 ∧ code e2422373137762 = 11218466159970 := by decide
theorem cert_e2422373137762 : check e2422373137762 [[],[]] .smaller = true := by decide
def e2422373137774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 2)))))))
theorem wire_e2422373137774 : Closed e2422373137774 ∧ code e2422373137774 = 11218466159982 := by decide
theorem cert_e2422373137774 : check e2422373137774 [[],[]] .smaller = true := by decide
def e2422373137786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))) (.var 0)))))))
theorem wire_e2422373137786 : Closed e2422373137786 ∧ code e2422373137786 = 11218466159994 := by decide
theorem cert_e2422373137786 : check e2422373137786 [[],[]] .smaller = true := by decide
def e2422373137826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373137826 : Closed e2422373137826 ∧ code e2422373137826 = 11218466160034 := by decide
theorem cert_e2422373137826 : check e2422373137826 [[],[]] .smaller = true := by decide
def e2422373137838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 2)))))))
theorem wire_e2422373137838 : Closed e2422373137838 ∧ code e2422373137838 = 11218466160046 := by decide
theorem cert_e2422373137838 : check e2422373137838 [[],[]] .smaller = true := by decide
def e2422373137898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373137898 : Closed e2422373137898 ∧ code e2422373137898 = 11218466160106 := by decide
theorem cert_e2422373137898 : check e2422373137898 [[],[]] .smaller = true := by decide
def e2422373138102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 1)))))))
theorem wire_e2422373138102 : Closed e2422373138102 ∧ code e2422373138102 = 11218466160310 := by decide
theorem cert_e2422373138102 : check e2422373138102 [[],[]] .smaller = true := by decide
def e2422373138106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e2422373138106 : Closed e2422373138106 ∧ code e2422373138106 = 11218466160314 := by decide
theorem cert_e2422373138106 : check e2422373138106 [[],[]] .smaller = true := by decide
def e2422373138134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373138134 : Closed e2422373138134 ∧ code e2422373138134 = 11218466160342 := by decide
theorem cert_e2422373138134 : check e2422373138134 [[],[]] .smaller = true := by decide
def e2422373138154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373138154 : Closed e2422373138154 ∧ code e2422373138154 = 11218466160362 := by decide
theorem cert_e2422373138154 : check e2422373138154 [[],[]] .smaller = true := by decide
def e2422373138262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373138262 : Closed e2422373138262 ∧ code e2422373138262 = 11218466160470 := by decide
theorem cert_e2422373138262 : check e2422373138262 [[],[]] .three = true := by decide
def e2422373138266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373138266 : Closed e2422373138266 ∧ code e2422373138266 = 11218466160474 := by decide
theorem cert_e2422373138266 : check e2422373138266 [[],[]] .three = true := by decide
def e2422373138282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373138282 : Closed e2422373138282 ∧ code e2422373138282 = 11218466160490 := by decide
theorem cert_e2422373138282 : check e2422373138282 [[],[]] .three = true := by decide
def e2422373141982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 3)))))))
theorem wire_e2422373141982 : Closed e2422373141982 ∧ code e2422373141982 = 11218466164190 := by decide
theorem cert_e2422373141982 : check e2422373141982 [[],[]] .three = true := by decide
def e2422373142006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 4))))) (.var 1)))))))
theorem wire_e2422373142006 : Closed e2422373142006 ∧ code e2422373142006 = 11218466164214 := by decide
theorem cert_e2422373142006 : check e2422373142006 [[],[]] .three = true := by decide
def e2422373142242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0))))))))
theorem wire_e2422373142242 : Closed e2422373142242 ∧ code e2422373142242 = 11218466164450 := by decide
theorem cert_e2422373142242 : check e2422373142242 [[],[]] .smaller = true := by decide
def e2422373142254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 2)))))))
theorem wire_e2422373142254 : Closed e2422373142254 ∧ code e2422373142254 = 11218466164462 := by decide
theorem cert_e2422373142254 : check e2422373142254 [[],[]] .smaller = true := by decide
def e2422373142262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 1)))))))
theorem wire_e2422373142262 : Closed e2422373142262 ∧ code e2422373142262 = 11218466164470 := by decide
theorem cert_e2422373142262 : check e2422373142262 [[],[]] .smaller = true := by decide
def e2422373142266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 4))))) (.var 0)))))))
theorem wire_e2422373142266 : Closed e2422373142266 ∧ code e2422373142266 = 11218466164474 := by decide
theorem cert_e2422373142266 : check e2422373142266 [[],[]] .three = true := by decide
def e2422373142366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 3)))))))
theorem wire_e2422373142366 : Closed e2422373142366 ∧ code e2422373142366 = 11218466164574 := by decide
theorem cert_e2422373142366 : check e2422373142366 [[],[]] .three = true := by decide
def e2422373142370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0))))))))
theorem wire_e2422373142370 : Closed e2422373142370 ∧ code e2422373142370 = 11218466164578 := by decide
theorem cert_e2422373142370 : check e2422373142370 [[],[]] .smaller = true := by decide
def e2422373142382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 2)))))))
theorem wire_e2422373142382 : Closed e2422373142382 ∧ code e2422373142382 = 11218466164590 := by decide
theorem cert_e2422373142382 : check e2422373142382 [[],[]] .smaller = true := by decide
def e2422373142394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))) (.var 0)))))))
theorem wire_e2422373142394 : Closed e2422373142394 ∧ code e2422373142394 = 11218466164602 := by decide
theorem cert_e2422373142394 : check e2422373142394 [[],[]] .smaller = true := by decide
def e2422373142454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 1)))))))
theorem wire_e2422373142454 : Closed e2422373142454 ∧ code e2422373142454 = 11218466164662 := by decide
theorem cert_e2422373142454 : check e2422373142454 [[],[]] .smaller = true := by decide
def e2422373142458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))) (.var 0)))))))
theorem wire_e2422373142458 : Closed e2422373142458 ∧ code e2422373142458 = 11218466164666 := by decide
theorem cert_e2422373142458 : check e2422373142458 [[],[]] .smaller = true := by decide
def e2422373142486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 0))))) (.var 1)))))))
theorem wire_e2422373142486 : Closed e2422373142486 ∧ code e2422373142486 = 11218466164694 := by decide
theorem cert_e2422373142486 : check e2422373142486 [[],[]] .three = true := by decide
def e2422373142490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 1))))) (.var 0)))))))
theorem wire_e2422373142490 : Closed e2422373142490 ∧ code e2422373142490 = 11218466164698 := by decide
theorem cert_e2422373142490 : check e2422373142490 [[],[]] .three = true := by decide
def e2422373143518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373143518 : Closed e2422373143518 ∧ code e2422373143518 = 11218466165726 := by decide
theorem cert_e2422373143518 : check e2422373143518 [[],[]] .three = true := by decide
def e2422373143534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373143534 : Closed e2422373143534 ∧ code e2422373143534 = 11218466165742 := by decide
theorem cert_e2422373143534 : check e2422373143534 [[],[]] .three = true := by decide
def e2422373145054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373145054 : Closed e2422373145054 ∧ code e2422373145054 = 11218466167262 := by decide
theorem cert_e2422373145054 : check e2422373145054 [[],[]] .three = true := by decide
def e2422373145078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373145078 : Closed e2422373145078 ∧ code e2422373145078 = 11218466167286 := by decide
theorem cert_e2422373145078 : check e2422373145078 [[],[]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422373071982
#print axioms Blc.Floor43.cert_e2422373071994
#print axioms Blc.Floor43.cert_e2422373072086
#print axioms Blc.Floor43.cert_e2422373072090
#print axioms Blc.Floor43.cert_e2422373072106
#print axioms Blc.Floor43.cert_e2422373072158
#print axioms Blc.Floor43.cert_e2422373072182
#print axioms Blc.Floor43.cert_e2422373072186
#print axioms Blc.Floor43.cert_e2422373072282
#print axioms Blc.Floor43.cert_e2422373072326
