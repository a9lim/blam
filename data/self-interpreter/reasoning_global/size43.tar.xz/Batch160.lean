import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2260964986478 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2260964986478 : Closed e2260964986478 ∧ code e2260964986478 = 11057058008686 := by decide
theorem cert_e2260964986478 : check e2260964986478 [[],[.under]] .three = true := by decide
def e2260964986490 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2260964986490 : Closed e2260964986490 ∧ code e2260964986490 = 11057058008698 := by decide
theorem cert_e2260964986490 : check e2260964986490 [[],[.under]] .three = true := by decide
def e2260964986678 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2260964986678 : Closed e2260964986678 ∧ code e2260964986678 = 11057058008886 := by decide
theorem cert_e2260964986678 : check e2260964986678 [[],[.under]] .three = true := by decide
def e2260964986682 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2260964986682 : Closed e2260964986682 ∧ code e2260964986682 = 11057058008890 := by decide
theorem cert_e2260964986682 : check e2260964986682 [[],[.under]] .three = true := by decide
def e2260965526382 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2260965526382 : Closed e2260965526382 ∧ code e2260965526382 = 11057058548590 := by decide
theorem cert_e2260965526382 : check e2260965526382 [[],[.under]] .smaller = true := by decide
def e2260965526390 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2260965526390 : Closed e2260965526390 ∧ code e2260965526390 = 11057058548598 := by decide
theorem cert_e2260965526390 : check e2260965526390 [[],[.under]] .smaller = true := by decide
def e2260965526446 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2260965526446 : Closed e2260965526446 ∧ code e2260965526446 = 11057058548654 := by decide
theorem cert_e2260965526446 : check e2260965526446 [[],[.under]] .smaller = true := by decide
def e2260965526458 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2260965526458 : Closed e2260965526458 ∧ code e2260965526458 = 11057058548666 := by decide
theorem cert_e2260965526458 : check e2260965526458 [[],[.under]] .smaller = true := by decide
def e2260965526486 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2260965526486 : Closed e2260965526486 ∧ code e2260965526486 = 11057058548694 := by decide
theorem cert_e2260965526486 : check e2260965526486 [[],[.under]] .smaller = true := by decide
def e2260965526490 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2260965526490 : Closed e2260965526490 ∧ code e2260965526490 = 11057058548698 := by decide
theorem cert_e2260965526490 : check e2260965526490 [[],[.under]] .smaller = true := by decide
def e2260965526766 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2260965526766 : Closed e2260965526766 ∧ code e2260965526766 = 11057058548974 := by decide
theorem cert_e2260965526766 : check e2260965526766 [[],[.under]] .smaller = true := by decide
def e2260965526774 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2260965526774 : Closed e2260965526774 ∧ code e2260965526774 = 11057058548982 := by decide
theorem cert_e2260965526774 : check e2260965526774 [[],[.under]] .smaller = true := by decide
def e2260965527150 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2260965527150 : Closed e2260965527150 ∧ code e2260965527150 = 11057058549358 := by decide
theorem cert_e2260965527150 : check e2260965527150 [[],[.under]] .smaller = true := by decide
def e2260965527162 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2260965527162 : Closed e2260965527162 ∧ code e2260965527162 = 11057058549370 := by decide
theorem cert_e2260965527162 : check e2260965527162 [[],[.under]] .smaller = true := by decide
def e2260965527350 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260965527350 : Closed e2260965527350 ∧ code e2260965527350 = 11057058549558 := by decide
theorem cert_e2260965527350 : check e2260965527350 [[],[.under]] .smaller = true := by decide
def e2260965527354 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260965527354 : Closed e2260965527354 ∧ code e2260965527354 = 11057058549562 := by decide
theorem cert_e2260965527354 : check e2260965527354 [[],[.under]] .smaller = true := by decide
def e2261034842138 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261034842138 : Closed e2261034842138 ∧ code e2261034842138 = 11057127864346 := by decide
theorem cert_e2261034842138 : check e2261034842138 [[]] .width = true := by decide
def e2261034850330 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261034850330 : Closed e2261034850330 ∧ code e2261034850330 = 11057127872538 := by decide
theorem cert_e2261034850330 : check e2261034850330 [[]] .width = true := by decide
def e2261034851866 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261034851866 : Closed e2261034851866 ∧ code e2261034851866 = 11057127874074 := by decide
theorem cert_e2261034851866 : check e2261034851866 [[]] .width = true := by decide
def e2261034855962 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261034855962 : Closed e2261034855962 ∧ code e2261034855962 = 11057127878170 := by decide
theorem cert_e2261034855962 : check e2261034855962 [[]] .width = true := by decide
def e2261034907674 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261034907674 : Closed e2261034907674 ∧ code e2261034907674 = 11057127929882 := by decide
theorem cert_e2261034907674 : check e2261034907674 [[]] .width = true := by decide
def e2261034919962 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261034919962 : Closed e2261034919962 ∧ code e2261034919962 = 11057127942170 := by decide
theorem cert_e2261034919962 : check e2261034919962 [[]] .width = true := by decide
def e2261034948634 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261034948634 : Closed e2261034948634 ∧ code e2261034948634 = 11057127970842 := by decide
theorem cert_e2261034948634 : check e2261034948634 [[]] .width = true := by decide
def e2261034950170 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261034950170 : Closed e2261034950170 ∧ code e2261034950170 = 11057127972378 := by decide
theorem cert_e2261034950170 : check e2261034950170 [[]] .width = true := by decide
def e2261034952730 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261034952730 : Closed e2261034952730 ∧ code e2261034952730 = 11057127974938 := by decide
theorem cert_e2261034952730 : check e2261034952730 [[]] .width = true := by decide
def e2261034957338 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261034957338 : Closed e2261034957338 ∧ code e2261034957338 = 11057127979546 := by decide
theorem cert_e2261034957338 : check e2261034957338 [[]] .width = true := by decide
def e2261034970650 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261034970650 : Closed e2261034970650 ∧ code e2261034970650 = 11057127992858 := by decide
theorem cert_e2261034970650 : check e2261034970650 [[]] .width = true := by decide
def e2261034973722 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261034973722 : Closed e2261034973722 ∧ code e2261034973722 = 11057127995930 := by decide
theorem cert_e2261034973722 : check e2261034973722 [[]] .width = true := by decide
def e2261035235354 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261035235354 : Closed e2261035235354 ∧ code e2261035235354 = 11057128257562 := by decide
theorem cert_e2261035235354 : check e2261035235354 [[]] .width = true := by decide
def e2261035243546 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261035243546 : Closed e2261035243546 ∧ code e2261035243546 = 11057128265754 := by decide
theorem cert_e2261035243546 : check e2261035243546 [[]] .width = true := by decide
def e2261035245082 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261035245082 : Closed e2261035245082 ∧ code e2261035245082 = 11057128267290 := by decide
theorem cert_e2261035245082 : check e2261035245082 [[]] .width = true := by decide
def e2261035249178 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261035249178 : Closed e2261035249178 ∧ code e2261035249178 = 11057128271386 := by decide
theorem cert_e2261035249178 : check e2261035249178 [[]] .width = true := by decide
def e2261035628570 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261035628570 : Closed e2261035628570 ∧ code e2261035628570 = 11057128650778 := by decide
theorem cert_e2261035628570 : check e2261035628570 [[]] .width = true := by decide
def e2261035640858 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261035640858 : Closed e2261035640858 ∧ code e2261035640858 = 11057128663066 := by decide
theorem cert_e2261035640858 : check e2261035640858 [[]] .width = true := by decide
def e2261035833370 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261035833370 : Closed e2261035833370 ∧ code e2261035833370 = 11057128855578 := by decide
theorem cert_e2261035833370 : check e2261035833370 [[]] .width = true := by decide
def e2261035834906 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261035834906 : Closed e2261035834906 ∧ code e2261035834906 = 11057128857114 := by decide
theorem cert_e2261035834906 : check e2261035834906 [[]] .width = true := by decide
def e2261035837466 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2261035837466 : Closed e2261035837466 ∧ code e2261035837466 = 11057128859674 := by decide
theorem cert_e2261035837466 : check e2261035837466 [[]] .width = true := by decide
def e2261035842074 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261035842074 : Closed e2261035842074 ∧ code e2261035842074 = 11057128864282 := by decide
theorem cert_e2261035842074 : check e2261035842074 [[]] .width = true := by decide
def e2261035937306 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261035937306 : Closed e2261035937306 ∧ code e2261035937306 = 11057128959514 := by decide
theorem cert_e2261035937306 : check e2261035937306 [[]] .width = true := by decide
def e2261035940378 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261035940378 : Closed e2261035940378 ∧ code e2261035940378 = 11057128962586 := by decide
theorem cert_e2261035940378 : check e2261035940378 [[]] .width = true := by decide
def e2261043211802 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043211802 : Closed e2261043211802 ∧ code e2261043211802 = 11057136234010 := by decide
private def t_e2261043211802 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043211802 : ¬ IsSelfInterpreter e2261043211802 :=
  wSource (t := t_e2261043211802) (replay_sound (ps := []) (t := e2261043211802) (by decide)) (by decide)
def e2261043213850 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043213850 : Closed e2261043213850 ∧ code e2261043213850 = 11057136236058 := by decide
private def t_e2261043213850 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043213850 : ¬ IsSelfInterpreter e2261043213850 :=
  wSource (t := t_e2261043213850) (replay_sound (ps := []) (t := e2261043213850) (by decide)) (by decide)
def e2261043228186 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043228186 : Closed e2261043228186 ∧ code e2261043228186 = 11057136250394 := by decide
theorem cert_e2261043228186 : check e2261043228186 [[]] .width = true := by decide
def e2261043231258 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043231258 : Closed e2261043231258 ∧ code e2261043231258 = 11057136253466 := by decide
theorem cert_e2261043231258 : check e2261043231258 [[]] .width = true := by decide
def e2261043238426 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043238426 : Closed e2261043238426 ∧ code e2261043238426 = 11057136260634 := by decide
private def t_e2261043238426 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043238426 : ¬ IsSelfInterpreter e2261043238426 :=
  wSource (t := t_e2261043238426) (replay_sound (ps := []) (t := e2261043238426) (by decide)) (by decide)
def e2261043239450 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043239450 : Closed e2261043239450 ∧ code e2261043239450 = 11057136261658 := by decide
private def t_e2261043239450 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043239450 : ¬ IsSelfInterpreter e2261043239450 :=
  wSource (t := t_e2261043239450) (replay_sound (ps := []) (t := e2261043239450) (by decide)) (by decide)
def e2261043293722 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043293722 : Closed e2261043293722 ∧ code e2261043293722 = 11057136315930 := by decide
theorem cert_e2261043293722 : check e2261043293722 [[]] .width = true := by decide
def e2261043296794 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043296794 : Closed e2261043296794 ∧ code e2261043296794 = 11057136319002 := by decide
theorem cert_e2261043296794 : check e2261043296794 [[]] .width = true := by decide
def e2261043309082 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043309082 : Closed e2261043309082 ∧ code e2261043309082 = 11057136331290 := by decide
theorem cert_e2261043309082 : check e2261043309082 [[]] .width = true := by decide
def e2261043336730 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043336730 : Closed e2261043336730 ∧ code e2261043336730 = 11057136358938 := by decide
private def t_e2261043336730 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043336730 : ¬ IsSelfInterpreter e2261043336730 :=
  wSource (t := t_e2261043336730) (replay_sound (ps := []) (t := e2261043336730) (by decide)) (by decide)
def e2261043337754 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043337754 : Closed e2261043337754 ∧ code e2261043337754 = 11057136359962 := by decide
private def t_e2261043337754 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043337754 : ¬ IsSelfInterpreter e2261043337754 :=
  wSource (t := t_e2261043337754) (replay_sound (ps := []) (t := e2261043337754) (by decide)) (by decide)
def e2261043341850 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043341850 : Closed e2261043341850 ∧ code e2261043341850 = 11057136364058 := by decide
theorem cert_e2261043341850 : check e2261043341850 [[]] .width = true := by decide
def e2261043605018 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043605018 : Closed e2261043605018 ∧ code e2261043605018 = 11057136627226 := by decide
theorem cert_e2261043605018 : check e2261043605018 [[]] .width = true := by decide
def e2261043607066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043607066 : Closed e2261043607066 ∧ code e2261043607066 = 11057136629274 := by decide
private def t_e2261043607066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043607066 : ¬ IsSelfInterpreter e2261043607066 :=
  wSource (t := t_e2261043607066) (replay_sound (ps := []) (t := e2261043607066) (by decide)) (by decide)
def e2261043621402 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043621402 : Closed e2261043621402 ∧ code e2261043621402 = 11057136643610 := by decide
theorem cert_e2261043621402 : check e2261043621402 [[]] .width = true := by decide
def e2261043624474 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043624474 : Closed e2261043624474 ∧ code e2261043624474 = 11057136646682 := by decide
theorem cert_e2261043624474 : check e2261043624474 [[]] .width = true := by decide
def e2261043631642 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043631642 : Closed e2261043631642 ∧ code e2261043631642 = 11057136653850 := by decide
private def t_e2261043631642 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043631642 : ¬ IsSelfInterpreter e2261043631642 :=
  wSource (t := t_e2261043631642) (replay_sound (ps := []) (t := e2261043631642) (by decide)) (by decide)
def e2261043632666 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043632666 : Closed e2261043632666 ∧ code e2261043632666 = 11057136654874 := by decide
theorem cert_e2261043632666 : check e2261043632666 [[]] .width = true := by decide
def e2261043703322 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043703322 : Closed e2261043703322 ∧ code e2261043703322 = 11057136725530 := by decide
private def t_e2261043703322 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043703322 : ¬ IsSelfInterpreter e2261043703322 :=
  wSource (t := t_e2261043703322) (replay_sound (ps := []) (t := e2261043703322) (by decide)) (by decide)
def e2261043705370 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043705370 : Closed e2261043705370 ∧ code e2261043705370 = 11057136727578 := by decide
private def t_e2261043705370 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043705370 : ¬ IsSelfInterpreter e2261043705370 :=
  wSource (t := t_e2261043705370) (replay_sound (ps := []) (t := e2261043705370) (by decide)) (by decide)
def e2261043801626 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043801626 : Closed e2261043801626 ∧ code e2261043801626 = 11057136823834 := by decide
theorem cert_e2261043801626 : check e2261043801626 [[]] .width = true := by decide
def e2261043804698 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043804698 : Closed e2261043804698 ∧ code e2261043804698 = 11057136826906 := by decide
theorem cert_e2261043804698 : check e2261043804698 [[]] .width = true := by decide
def e2261043830810 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261043830810 : Closed e2261043830810 ∧ code e2261043830810 = 11057136853018 := by decide
theorem cert_e2261043830810 : check e2261043830810 [[]] .width = true := by decide
def e2261043830902 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261043830902 : Closed e2261043830902 ∧ code e2261043830902 = 11057136853110 := by decide
theorem cert_e2261043830902 : check e2261043830902 [[]] .width = true := by decide
def e2261043831146 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261043831146 : Closed e2261043831146 ∧ code e2261043831146 = 11057136853354 := by decide
theorem cert_e2261043831146 : check e2261043831146 [[]] .width = true := by decide
def e2261043831194 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261043831194 : Closed e2261043831194 ∧ code e2261043831194 = 11057136853402 := by decide
theorem cert_e2261043831194 : check e2261043831194 [[]] .width = true := by decide
def e2261043852826 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043852826 : Closed e2261043852826 ∧ code e2261043852826 = 11057136875034 := by decide
private def t_e2261043852826 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043852826 : ¬ IsSelfInterpreter e2261043852826 :=
  wSource (t := t_e2261043852826) (replay_sound (ps := []) (t := e2261043852826) (by decide)) (by decide)
def e2261043853850 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261043853850 : Closed e2261043853850 ∧ code e2261043853850 = 11057136876058 := by decide
private def t_e2261043853850 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261043853850 : ¬ IsSelfInterpreter e2261043853850 :=
  wSource (t := t_e2261043853850) (replay_sound (ps := []) (t := e2261043853850) (by decide)) (by decide)
def e2261043863578 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261043863578 : Closed e2261043863578 ∧ code e2261043863578 = 11057136885786 := by decide
theorem cert_e2261043863578 : check e2261043863578 [[]] .width = true := by decide
def e2261043863670 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261043863670 : Closed e2261043863670 ∧ code e2261043863670 = 11057136885878 := by decide
private def t_e2261043863670 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2261043863670 : ¬ IsSelfInterpreter e2261043863670 :=
  wSource (t := t_e2261043863670) (replay_sound (ps := []) (t := e2261043863670) (by decide)) (by decide)
def e2261043863914 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261043863914 : Closed e2261043863914 ∧ code e2261043863914 = 11057136886122 := by decide
private def t_e2261043863914 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2261043863914 : ¬ IsSelfInterpreter e2261043863914 :=
  wSource (t := t_e2261043863914) (replay_sound (ps := []) (t := e2261043863914) (by decide)) (by decide)
def e2261043863962 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261043863962 : Closed e2261043863962 ∧ code e2261043863962 = 11057136886170 := by decide
private def t_e2261043863962 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2261043863962 : ¬ IsSelfInterpreter e2261043863962 :=
  wSource (t := t_e2261043863962) (replay_sound (ps := []) (t := e2261043863962) (by decide)) (by decide)
def e2261044014618 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044014618 : Closed e2261044014618 ∧ code e2261044014618 = 11057137036826 := by decide
theorem cert_e2261044014618 : check e2261044014618 [[]] .width = true := by decide
def e2261044017690 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044017690 : Closed e2261044017690 ∧ code e2261044017690 = 11057137039898 := by decide
theorem cert_e2261044017690 : check e2261044017690 [[]] .width = true := by decide
def e2261044029978 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044029978 : Closed e2261044029978 ∧ code e2261044029978 = 11057137052186 := by decide
theorem cert_e2261044029978 : check e2261044029978 [[]] .width = true := by decide
def e2261044063770 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044063770 : Closed e2261044063770 ∧ code e2261044063770 = 11057137085978 := by decide
theorem cert_e2261044063770 : check e2261044063770 [[]] .width = true := by decide
def e2261044066842 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044066842 : Closed e2261044066842 ∧ code e2261044066842 = 11057137089050 := by decide
theorem cert_e2261044066842 : check e2261044066842 [[]] .width = true := by decide
def e2261044092954 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261044092954 : Closed e2261044092954 ∧ code e2261044092954 = 11057137115162 := by decide
theorem cert_e2261044092954 : check e2261044092954 [[]] .width = true := by decide
def e2261044093046 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261044093046 : Closed e2261044093046 ∧ code e2261044093046 = 11057137115254 := by decide
theorem cert_e2261044093046 : check e2261044093046 [[]] .width = true := by decide
def e2261044093290 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261044093290 : Closed e2261044093290 ∧ code e2261044093290 = 11057137115498 := by decide
theorem cert_e2261044093290 : check e2261044093290 [[]] .width = true := by decide
def e2261044093338 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261044093338 : Closed e2261044093338 ∧ code e2261044093338 = 11057137115546 := by decide
theorem cert_e2261044093338 : check e2261044093338 [[]] .width = true := by decide
def e2261044140570 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044140570 : Closed e2261044140570 ∧ code e2261044140570 = 11057137162778 := by decide
theorem cert_e2261044140570 : check e2261044140570 [[]] .width = true := by decide
def e2261044142106 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261044142106 : Closed e2261044142106 ∧ code e2261044142106 = 11057137164314 := by decide
theorem cert_e2261044142106 : check e2261044142106 [[]] .width = true := by decide
def e2261044142198 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261044142198 : Closed e2261044142198 ∧ code e2261044142198 = 11057137164406 := by decide
theorem cert_e2261044142198 : check e2261044142198 [[]] .width = true := by decide
def e2261044142442 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261044142442 : Closed e2261044142442 ∧ code e2261044142442 = 11057137164650 := by decide
theorem cert_e2261044142442 : check e2261044142442 [[]] .width = true := by decide
def e2261044142490 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261044142490 : Closed e2261044142490 ∧ code e2261044142490 = 11057137164698 := by decide
theorem cert_e2261044142490 : check e2261044142490 [[]] .width = true := by decide
def e2261044221466 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044221466 : Closed e2261044221466 ∧ code e2261044221466 = 11057137243674 := by decide
private def t_e2261044221466 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261044221466 : ¬ IsSelfInterpreter e2261044221466 :=
  wSource (t := t_e2261044221466) (replay_sound (ps := []) (t := e2261044221466) (by decide)) (by decide)
def e2261044222490 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044222490 : Closed e2261044222490 ∧ code e2261044222490 = 11057137244698 := by decide
theorem cert_e2261044222490 : check e2261044222490 [[]] .width = true := by decide
def e2261044226586 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044226586 : Closed e2261044226586 ∧ code e2261044226586 = 11057137248794 := by decide
theorem cert_e2261044226586 : check e2261044226586 [[]] .width = true := by decide
def e2261044246042 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044246042 : Closed e2261044246042 ∧ code e2261044246042 = 11057137268250 := by decide
private def t_e2261044246042 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261044246042 : ¬ IsSelfInterpreter e2261044246042 :=
  wSource (t := t_e2261044246042) (replay_sound (ps := []) (t := e2261044246042) (by decide)) (by decide)
def e2261044247066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044247066 : Closed e2261044247066 ∧ code e2261044247066 = 11057137269274 := by decide
private def t_e2261044247066 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261044247066 : ¬ IsSelfInterpreter e2261044247066 :=
  wSource (t := t_e2261044247066) (replay_sound (ps := []) (t := e2261044247066) (by decide)) (by decide)
def e2261044256794 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261044256794 : Closed e2261044256794 ∧ code e2261044256794 = 11057137279002 := by decide
theorem cert_e2261044256794 : check e2261044256794 [[]] .width = true := by decide
def e2261044256886 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261044256886 : Closed e2261044256886 ∧ code e2261044256886 = 11057137279094 := by decide
private def t_e2261044256886 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2261044256886 : ¬ IsSelfInterpreter e2261044256886 :=
  wSource (t := t_e2261044256886) (replay_sound (ps := []) (t := e2261044256886) (by decide)) (by decide)
def e2261044257130 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261044257130 : Closed e2261044257130 ∧ code e2261044257130 = 11057137279338 := by decide
private def t_e2261044257130 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2261044257130 : ¬ IsSelfInterpreter e2261044257130 :=
  wSource (t := t_e2261044257130) (replay_sound (ps := []) (t := e2261044257130) (by decide)) (by decide)
def e2261044257178 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261044257178 : Closed e2261044257178 ∧ code e2261044257178 = 11057137279386 := by decide
private def t_e2261044257178 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2261044257178 : ¬ IsSelfInterpreter e2261044257178 :=
  wSource (t := t_e2261044257178) (replay_sound (ps := []) (t := e2261044257178) (by decide)) (by decide)
def e2261044271642 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044271642 : Closed e2261044271642 ∧ code e2261044271642 = 11057137293850 := by decide
theorem cert_e2261044271642 : check e2261044271642 [[]] .width = true := by decide
def e2261044273178 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261044273178 : Closed e2261044273178 ∧ code e2261044273178 = 11057137295386 := by decide
theorem cert_e2261044273178 : check e2261044273178 [[]] .width = true := by decide
def e2261044273270 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261044273270 : Closed e2261044273270 ∧ code e2261044273270 = 11057137295478 := by decide
theorem cert_e2261044273270 : check e2261044273270 [[]] .width = true := by decide
def e2261044273514 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261044273514 : Closed e2261044273514 ∧ code e2261044273514 = 11057137295722 := by decide
theorem cert_e2261044273514 : check e2261044273514 [[]] .width = true := by decide
def e2261044273562 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261044273562 : Closed e2261044273562 ∧ code e2261044273562 = 11057137295770 := by decide
theorem cert_e2261044273562 : check e2261044273562 [[]] .width = true := by decide
def e2261044682266 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044682266 : Closed e2261044682266 ∧ code e2261044682266 = 11057137704474 := by decide
theorem cert_e2261044682266 : check e2261044682266 [[]] .width = true := by decide
def e2261044686362 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261044686362 : Closed e2261044686362 ∧ code e2261044686362 = 11057137708570 := by decide
theorem cert_e2261044686362 : check e2261044686362 [[]] .width = true := by decide
def e2261045177882 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045177882 : Closed e2261045177882 ∧ code e2261045177882 = 11057138200090 := by decide
theorem cert_e2261045177882 : check e2261045177882 [[]] .width = true := by decide
def e2261045179930 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045179930 : Closed e2261045179930 ∧ code e2261045179930 = 11057138202138 := by decide
private def t_e2261045179930 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261045179930 : ¬ IsSelfInterpreter e2261045179930 :=
  wSource (t := t_e2261045179930) (replay_sound (ps := []) (t := e2261045179930) (by decide)) (by decide)
def e2261045194266 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045194266 : Closed e2261045194266 ∧ code e2261045194266 = 11057138216474 := by decide
theorem cert_e2261045194266 : check e2261045194266 [[]] .width = true := by decide
def e2261045197338 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045197338 : Closed e2261045197338 ∧ code e2261045197338 = 11057138219546 := by decide
theorem cert_e2261045197338 : check e2261045197338 [[]] .width = true := by decide
def e2261045204506 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045204506 : Closed e2261045204506 ∧ code e2261045204506 = 11057138226714 := by decide
private def t_e2261045204506 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261045204506 : ¬ IsSelfInterpreter e2261045204506 :=
  wSource (t := t_e2261045204506) (replay_sound (ps := []) (t := e2261045204506) (by decide)) (by decide)
def e2261045205530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045205530 : Closed e2261045205530 ∧ code e2261045205530 = 11057138227738 := by decide
theorem cert_e2261045205530 : check e2261045205530 [[]] .width = true := by decide
def e2261045276186 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045276186 : Closed e2261045276186 ∧ code e2261045276186 = 11057138298394 := by decide
theorem cert_e2261045276186 : check e2261045276186 [[]] .width = true := by decide
def e2261045278234 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045278234 : Closed e2261045278234 ∧ code e2261045278234 = 11057138300442 := by decide
theorem cert_e2261045278234 : check e2261045278234 [[]] .width = true := by decide
def e2261045374490 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045374490 : Closed e2261045374490 ∧ code e2261045374490 = 11057138396698 := by decide
theorem cert_e2261045374490 : check e2261045374490 [[]] .width = true := by decide
def e2261045377562 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045377562 : Closed e2261045377562 ∧ code e2261045377562 = 11057138399770 := by decide
theorem cert_e2261045377562 : check e2261045377562 [[]] .width = true := by decide
def e2261045403674 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261045403674 : Closed e2261045403674 ∧ code e2261045403674 = 11057138425882 := by decide
theorem cert_e2261045403674 : check e2261045403674 [[]] .width = true := by decide
def e2261045403766 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261045403766 : Closed e2261045403766 ∧ code e2261045403766 = 11057138425974 := by decide
theorem cert_e2261045403766 : check e2261045403766 [[]] .width = true := by decide
def e2261045404010 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261045404010 : Closed e2261045404010 ∧ code e2261045404010 = 11057138426218 := by decide
theorem cert_e2261045404010 : check e2261045404010 [[]] .width = true := by decide
def e2261045404058 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261045404058 : Closed e2261045404058 ∧ code e2261045404058 = 11057138426266 := by decide
theorem cert_e2261045404058 : check e2261045404058 [[]] .width = true := by decide
def e2261045425690 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045425690 : Closed e2261045425690 ∧ code e2261045425690 = 11057138447898 := by decide
theorem cert_e2261045425690 : check e2261045425690 [[]] .width = true := by decide
def e2261045426714 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261045426714 : Closed e2261045426714 ∧ code e2261045426714 = 11057138448922 := by decide
theorem cert_e2261045426714 : check e2261045426714 [[]] .width = true := by decide
def e2261045436442 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261045436442 : Closed e2261045436442 ∧ code e2261045436442 = 11057138458650 := by decide
theorem cert_e2261045436442 : check e2261045436442 [[]] .width = true := by decide
def e2261045436534 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261045436534 : Closed e2261045436534 ∧ code e2261045436534 = 11057138458742 := by decide
theorem cert_e2261045436534 : check e2261045436534 [[]] .width = true := by decide
def e2261045436778 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261045436778 : Closed e2261045436778 ∧ code e2261045436778 = 11057138458986 := by decide
theorem cert_e2261045436778 : check e2261045436778 [[]] .width = true := by decide
def e2261045436826 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261045436826 : Closed e2261045436826 ∧ code e2261045436826 = 11057138459034 := by decide
theorem cert_e2261045436826 : check e2261045436826 [[]] .width = true := by decide
def e2261046648346 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261046648346 : Closed e2261046648346 ∧ code e2261046648346 = 11057139670554 := by decide
theorem cert_e2261046648346 : check e2261046648346 [[]] .width = true := by decide
def e2261046654490 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261046654490 : Closed e2261046654490 ∧ code e2261046654490 = 11057139676698 := by decide
theorem cert_e2261046654490 : check e2261046654490 [[]] .width = true := by decide
def e2261046898202 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261046898202 : Closed e2261046898202 ∧ code e2261046898202 = 11057139920410 := by decide
theorem cert_e2261046898202 : check e2261046898202 [[]] .width = true := by decide
def e2261046901274 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261046901274 : Closed e2261046901274 ∧ code e2261046901274 = 11057139923482 := by decide
theorem cert_e2261046901274 : check e2261046901274 [[]] .width = true := by decide
def e2261046913562 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261046913562 : Closed e2261046913562 ∧ code e2261046913562 = 11057139935770 := by decide
theorem cert_e2261046913562 : check e2261046913562 [[]] .width = true := by decide
def e2261046947354 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261046947354 : Closed e2261046947354 ∧ code e2261046947354 = 11057139969562 := by decide
theorem cert_e2261046947354 : check e2261046947354 [[]] .width = true := by decide
def e2261046950426 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261046950426 : Closed e2261046950426 ∧ code e2261046950426 = 11057139972634 := by decide
theorem cert_e2261046950426 : check e2261046950426 [[]] .width = true := by decide
def e2261046976538 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261046976538 : Closed e2261046976538 ∧ code e2261046976538 = 11057139998746 := by decide
theorem cert_e2261046976538 : check e2261046976538 [[]] .width = true := by decide
def e2261046976630 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261046976630 : Closed e2261046976630 ∧ code e2261046976630 = 11057139998838 := by decide
theorem cert_e2261046976630 : check e2261046976630 [[]] .width = true := by decide
def e2261046976874 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261046976874 : Closed e2261046976874 ∧ code e2261046976874 = 11057139999082 := by decide
theorem cert_e2261046976874 : check e2261046976874 [[]] .width = true := by decide
def e2261046976922 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261046976922 : Closed e2261046976922 ∧ code e2261046976922 = 11057139999130 := by decide
theorem cert_e2261046976922 : check e2261046976922 [[]] .width = true := by decide
def e2261047024154 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261047024154 : Closed e2261047024154 ∧ code e2261047024154 = 11057140046362 := by decide
theorem cert_e2261047024154 : check e2261047024154 [[]] .width = true := by decide
def e2261047025690 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261047025690 : Closed e2261047025690 ∧ code e2261047025690 = 11057140047898 := by decide
theorem cert_e2261047025690 : check e2261047025690 [[]] .width = true := by decide
def e2261047025782 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261047025782 : Closed e2261047025782 ∧ code e2261047025782 = 11057140047990 := by decide
theorem cert_e2261047025782 : check e2261047025782 [[]] .width = true := by decide
def e2261047026026 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261047026026 : Closed e2261047026026 ∧ code e2261047026026 = 11057140048234 := by decide
theorem cert_e2261047026026 : check e2261047026026 [[]] .width = true := by decide
def e2261047026074 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261047026074 : Closed e2261047026074 ∧ code e2261047026074 = 11057140048282 := by decide
theorem cert_e2261047026074 : check e2261047026074 [[]] .width = true := by decide
def e2261047635482 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261047635482 : Closed e2261047635482 ∧ code e2261047635482 = 11057140657690 := by decide
theorem cert_e2261047635482 : check e2261047635482 [[]] .width = true := by decide
def e2261047637530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261047637530 : Closed e2261047637530 ∧ code e2261047637530 = 11057140659738 := by decide
theorem cert_e2261047637530 : check e2261047637530 [[]] .width = true := by decide
def e2261047760410 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261047760410 : Closed e2261047760410 ∧ code e2261047760410 = 11057140782618 := by decide
private def t_e2261047760410 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2261047760410 : ¬ IsSelfInterpreter e2261047760410 :=
  wSource (t := t_e2261047760410) (replay_sound (ps := []) (t := e2261047760410) (by decide)) (by decide)
def e2261047761434 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261047761434 : Closed e2261047761434 ∧ code e2261047761434 = 11057140783642 := by decide
theorem cert_e2261047761434 : check e2261047761434 [[]] .width = true := by decide
def e2261047765530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261047765530 : Closed e2261047765530 ∧ code e2261047765530 = 11057140787738 := by decide
theorem cert_e2261047765530 : check e2261047765530 [[]] .width = true := by decide
def e2261047784986 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261047784986 : Closed e2261047784986 ∧ code e2261047784986 = 11057140807194 := by decide
theorem cert_e2261047784986 : check e2261047784986 [[]] .width = true := by decide
def e2261047786010 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261047786010 : Closed e2261047786010 ∧ code e2261047786010 = 11057140808218 := by decide
theorem cert_e2261047786010 : check e2261047786010 [[]] .width = true := by decide
def e2261047795738 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261047795738 : Closed e2261047795738 ∧ code e2261047795738 = 11057140817946 := by decide
theorem cert_e2261047795738 : check e2261047795738 [[]] .width = true := by decide
def e2261047795830 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261047795830 : Closed e2261047795830 ∧ code e2261047795830 = 11057140818038 := by decide
theorem cert_e2261047795830 : check e2261047795830 [[]] .width = true := by decide
def e2261047796074 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261047796074 : Closed e2261047796074 ∧ code e2261047796074 = 11057140818282 := by decide
theorem cert_e2261047796074 : check e2261047796074 [[]] .width = true := by decide
def e2261047796122 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261047796122 : Closed e2261047796122 ∧ code e2261047796122 = 11057140818330 := by decide
theorem cert_e2261047796122 : check e2261047796122 [[]] .width = true := by decide
def e2261047810586 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2261047810586 : Closed e2261047810586 ∧ code e2261047810586 = 11057140832794 := by decide
theorem cert_e2261047810586 : check e2261047810586 [[]] .width = true := by decide
def e2261047812122 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2261047812122 : Closed e2261047812122 ∧ code e2261047812122 = 11057140834330 := by decide
theorem cert_e2261047812122 : check e2261047812122 [[]] .width = true := by decide
def e2261047812214 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2261047812214 : Closed e2261047812214 ∧ code e2261047812214 = 11057140834422 := by decide
theorem cert_e2261047812214 : check e2261047812214 [[]] .width = true := by decide
def e2261047812458 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2261047812458 : Closed e2261047812458 ∧ code e2261047812458 = 11057140834666 := by decide
theorem cert_e2261047812458 : check e2261047812458 [[]] .width = true := by decide
def e2261047812506 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2261047812506 : Closed e2261047812506 ∧ code e2261047812506 = 11057140834714 := by decide
theorem cert_e2261047812506 : check e2261047812506 [[]] .width = true := by decide
def e2261048667502 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2261048667502 : Closed e2261048667502 ∧ code e2261048667502 = 11057141689710 := by decide
theorem cert_e2261048667502 : check e2261048667502 [[],[.under]] .three = true := by decide
def e2261048667510 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2261048667510 : Closed e2261048667510 ∧ code e2261048667510 = 11057141689718 := by decide
theorem cert_e2261048667510 : check e2261048667510 [[],[.under]] .three = true := by decide
def e2261048667566 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2261048667566 : Closed e2261048667566 ∧ code e2261048667566 = 11057141689774 := by decide
theorem cert_e2261048667566 : check e2261048667566 [[],[.under]] .three = true := by decide
def e2261048667578 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2261048667578 : Closed e2261048667578 ∧ code e2261048667578 = 11057141689786 := by decide
theorem cert_e2261048667578 : check e2261048667578 [[],[.under]] .three = true := by decide
def e2261048667606 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2261048667606 : Closed e2261048667606 ∧ code e2261048667606 = 11057141689814 := by decide
theorem cert_e2261048667606 : check e2261048667606 [[],[.under]] .three = true := by decide
def e2261048667610 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2261048667610 : Closed e2261048667610 ∧ code e2261048667610 = 11057141689818 := by decide
theorem cert_e2261048667610 : check e2261048667610 [[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2261043211802
#print axioms Blc.Floor43.cert_e2261043213850
#print axioms Blc.Floor43.cert_e2261043238426
#print axioms Blc.Floor43.cert_e2261043239450
#print axioms Blc.Floor43.cert_e2261043336730
#print axioms Blc.Floor43.cert_e2261043337754
#print axioms Blc.Floor43.cert_e2261043607066
#print axioms Blc.Floor43.cert_e2261043631642
#print axioms Blc.Floor43.cert_e2261043703322
#print axioms Blc.Floor43.cert_e2261043705370
#print axioms Blc.Floor43.cert_e2261043852826
#print axioms Blc.Floor43.cert_e2261043853850
#print axioms Blc.Floor43.cert_e2261043863670
#print axioms Blc.Floor43.cert_e2261043863914
#print axioms Blc.Floor43.cert_e2261043863962
#print axioms Blc.Floor43.cert_e2261044221466
#print axioms Blc.Floor43.cert_e2261044246042
#print axioms Blc.Floor43.cert_e2261044247066
#print axioms Blc.Floor43.cert_e2261044256886
#print axioms Blc.Floor43.cert_e2261044257130
#print axioms Blc.Floor43.cert_e2261044257178
#print axioms Blc.Floor43.cert_e2261045179930
#print axioms Blc.Floor43.cert_e2261045204506
#print axioms Blc.Floor43.cert_e2261047760410
