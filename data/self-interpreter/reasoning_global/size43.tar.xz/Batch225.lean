import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393370584698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2393370584698 : Closed e2393370584698 ∧ code e2393370584698 = 11189463606906 := by decide
theorem cert_e2393370584698 : check e2393370584698 [[],[.left],[]] .smaller = true := by decide
def e2393370584986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2393370584986 : Closed e2393370584986 ∧ code e2393370584986 = 11189463607194 := by decide
theorem cert_e2393370584986 : check e2393370584986 [[],[.left],[]] .smaller = true := by decide
def e2393370587862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2393370587862 : Closed e2393370587862 ∧ code e2393370587862 = 11189463610070 := by decide
theorem cert_e2393370587862 : check e2393370587862 [[],[.left],[]] .smaller = true := by decide
def e2393370587866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2393370587866 : Closed e2393370587866 ∧ code e2393370587866 = 11189463610074 := by decide
theorem cert_e2393370587866 : check e2393370587866 [[],[.left],[]] .smaller = true := by decide
def e2393370587882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2393370587882 : Closed e2393370587882 ∧ code e2393370587882 = 11189463610090 := by decide
theorem cert_e2393370587882 : check e2393370587882 [[],[.left],[]] .smaller = true := by decide
def e2393370587958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2393370587958 : Closed e2393370587958 ∧ code e2393370587958 = 11189463610166 := by decide
theorem cert_e2393370587958 : check e2393370587958 [[],[.left],[]] .smaller = true := by decide
def e2393370587962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2393370587962 : Closed e2393370587962 ∧ code e2393370587962 = 11189463610170 := by decide
theorem cert_e2393370587962 : check e2393370587962 [[],[.left],[]] .smaller = true := by decide
def e2393370588058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2393370588058 : Closed e2393370588058 ∧ code e2393370588058 = 11189463610266 := by decide
theorem cert_e2393370588058 : check e2393370588058 [[],[.left],[]] .smaller = true := by decide
def e2393370703294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 4))))))))
theorem wire_e2393370703294 : Closed e2393370703294 ∧ code e2393370703294 = 11189463725502 := by decide
theorem cert_e2393370703294 : check e2393370703294 [[],[.left],[]] .three = true := by decide
def e2393370703326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e2393370703326 : Closed e2393370703326 ∧ code e2393370703326 = 11189463725534 := by decide
theorem cert_e2393370703326 : check e2393370703326 [[],[.left],[]] .three = true := by decide
def e2393370703342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e2393370703342 : Closed e2393370703342 ∧ code e2393370703342 = 11189463725550 := by decide
theorem cert_e2393370703342 : check e2393370703342 [[],[.left],[]] .three = true := by decide
def e2393370703350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 1))))))))
theorem wire_e2393370703350 : Closed e2393370703350 ∧ code e2393370703350 = 11189463725558 := by decide
theorem cert_e2393370703350 : check e2393370703350 [[],[.left],[]] .three = true := by decide
def e2393370703550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 4))))))))
theorem wire_e2393370703550 : Closed e2393370703550 ∧ code e2393370703550 = 11189463725758 := by decide
theorem cert_e2393370703550 : check e2393370703550 [[],[.left],[]] .three = true := by decide
def e2393370703582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e2393370703582 : Closed e2393370703582 ∧ code e2393370703582 = 11189463725790 := by decide
theorem cert_e2393370703582 : check e2393370703582 [[],[.left],[]] .three = true := by decide
def e2393370703598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e2393370703598 : Closed e2393370703598 ∧ code e2393370703598 = 11189463725806 := by decide
theorem cert_e2393370703598 : check e2393370703598 [[],[.left],[]] .smaller = true := by decide
def e2393370703606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e2393370703606 : Closed e2393370703606 ∧ code e2393370703606 = 11189463725814 := by decide
theorem cert_e2393370703606 : check e2393370703606 [[],[.left],[]] .three = true := by decide
def e2393370703610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 0))))))))
theorem wire_e2393370703610 : Closed e2393370703610 ∧ code e2393370703610 = 11189463725818 := by decide
theorem cert_e2393370703610 : check e2393370703610 [[],[.left],[]] .three = true := by decide
def e2393370703710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e2393370703710 : Closed e2393370703710 ∧ code e2393370703710 = 11189463725918 := by decide
theorem cert_e2393370703710 : check e2393370703710 [[],[.left],[]] .three = true := by decide
def e2393370703726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e2393370703726 : Closed e2393370703726 ∧ code e2393370703726 = 11189463725934 := by decide
theorem cert_e2393370703726 : check e2393370703726 [[],[.left],[]] .smaller = true := by decide
def e2393370703734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e2393370703734 : Closed e2393370703734 ∧ code e2393370703734 = 11189463725942 := by decide
theorem cert_e2393370703734 : check e2393370703734 [[],[.left],[]] .smaller = true := by decide
def e2393370703738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e2393370703738 : Closed e2393370703738 ∧ code e2393370703738 = 11189463725946 := by decide
theorem cert_e2393370703738 : check e2393370703738 [[],[.left],[]] .three = true := by decide
def e2393370703790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e2393370703790 : Closed e2393370703790 ∧ code e2393370703790 = 11189463725998 := by decide
theorem cert_e2393370703790 : check e2393370703790 [[],[.left],[]] .three = true := by decide
def e2393370703798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e2393370703798 : Closed e2393370703798 ∧ code e2393370703798 = 11189463726006 := by decide
theorem cert_e2393370703798 : check e2393370703798 [[],[.left],[]] .three = true := by decide
def e2393370703802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e2393370703802 : Closed e2393370703802 ∧ code e2393370703802 = 11189463726010 := by decide
theorem cert_e2393370703802 : check e2393370703802 [[],[.left],[]] .three = true := by decide
def e2393370703830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 1))))))))
theorem wire_e2393370703830 : Closed e2393370703830 ∧ code e2393370703830 = 11189463726038 := by decide
theorem cert_e2393370703830 : check e2393370703830 [[],[.left],[]] .three = true := by decide
def e2393370703834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 0))))))))
theorem wire_e2393370703834 : Closed e2393370703834 ∧ code e2393370703834 = 11189463726042 := by decide
theorem cert_e2393370703834 : check e2393370703834 [[],[.left],[]] .three = true := by decide
def e2393370704574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 4))))))))
theorem wire_e2393370704574 : Closed e2393370704574 ∧ code e2393370704574 = 11189463726782 := by decide
theorem cert_e2393370704574 : check e2393370704574 [[],[.left],[]] .three = true := by decide
def e2393370704606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2393370704606 : Closed e2393370704606 ∧ code e2393370704606 = 11189463726814 := by decide
theorem cert_e2393370704606 : check e2393370704606 [[],[.left],[]] .three = true := by decide
def e2393370704622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e2393370704622 : Closed e2393370704622 ∧ code e2393370704622 = 11189463726830 := by decide
theorem cert_e2393370704622 : check e2393370704622 [[],[.left],[]] .smaller = true := by decide
def e2393370704630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2393370704630 : Closed e2393370704630 ∧ code e2393370704630 = 11189463726838 := by decide
theorem cert_e2393370704630 : check e2393370704630 [[],[.left],[]] .three = true := by decide
def e2393370704634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 0))))))))
theorem wire_e2393370704634 : Closed e2393370704634 ∧ code e2393370704634 = 11189463726842 := by decide
theorem cert_e2393370704634 : check e2393370704634 [[],[.left],[]] .three = true := by decide
def e2393370704734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2393370704734 : Closed e2393370704734 ∧ code e2393370704734 = 11189463726942 := by decide
theorem cert_e2393370704734 : check e2393370704734 [[],[.left],[]] .three = true := by decide
def e2393370704762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2393370704762 : Closed e2393370704762 ∧ code e2393370704762 = 11189463726970 := by decide
theorem cert_e2393370704762 : check e2393370704762 [[],[.left],[]] .three = true := by decide
def e2393370704814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e2393370704814 : Closed e2393370704814 ∧ code e2393370704814 = 11189463727022 := by decide
theorem cert_e2393370704814 : check e2393370704814 [[],[.left],[]] .smaller = true := by decide
def e2393370704826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e2393370704826 : Closed e2393370704826 ∧ code e2393370704826 = 11189463727034 := by decide
theorem cert_e2393370704826 : check e2393370704826 [[],[.left],[]] .smaller = true := by decide
def e2393370704854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2393370704854 : Closed e2393370704854 ∧ code e2393370704854 = 11189463727062 := by decide
theorem cert_e2393370704854 : check e2393370704854 [[],[.left],[]] .three = true := by decide
def e2393370704858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2393370704858 : Closed e2393370704858 ∧ code e2393370704858 = 11189463727066 := by decide
theorem cert_e2393370704858 : check e2393370704858 [[],[.left],[]] .three = true := by decide
def e2393370704874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 0))))))))
theorem wire_e2393370704874 : Closed e2393370704874 ∧ code e2393370704874 = 11189463727082 := by decide
theorem cert_e2393370704874 : check e2393370704874 [[],[.left],[]] .three = true := by decide
def e2393370705246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2393370705246 : Closed e2393370705246 ∧ code e2393370705246 = 11189463727454 := by decide
theorem cert_e2393370705246 : check e2393370705246 [[],[.left],[]] .three = true := by decide
def e2393370705262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2393370705262 : Closed e2393370705262 ∧ code e2393370705262 = 11189463727470 := by decide
theorem cert_e2393370705262 : check e2393370705262 [[],[.left],[]] .smaller = true := by decide
def e2393370705270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2393370705270 : Closed e2393370705270 ∧ code e2393370705270 = 11189463727478 := by decide
theorem cert_e2393370705270 : check e2393370705270 [[],[.left],[]] .smaller = true := by decide
def e2393370705274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2393370705274 : Closed e2393370705274 ∧ code e2393370705274 = 11189463727482 := by decide
theorem cert_e2393370705274 : check e2393370705274 [[],[.left],[]] .three = true := by decide
def e2393370705326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2393370705326 : Closed e2393370705326 ∧ code e2393370705326 = 11189463727534 := by decide
theorem cert_e2393370705326 : check e2393370705326 [[],[.left],[]] .smaller = true := by decide
def e2393370705338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2393370705338 : Closed e2393370705338 ∧ code e2393370705338 = 11189463727546 := by decide
theorem cert_e2393370705338 : check e2393370705338 [[],[.left],[]] .smaller = true := by decide
def e2393370705366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2393370705366 : Closed e2393370705366 ∧ code e2393370705366 = 11189463727574 := by decide
theorem cert_e2393370705366 : check e2393370705366 [[],[.left],[]] .smaller = true := by decide
def e2393370705370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2393370705370 : Closed e2393370705370 ∧ code e2393370705370 = 11189463727578 := by decide
theorem cert_e2393370705370 : check e2393370705370 [[],[.left],[]] .smaller = true := by decide
def e2393370705386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2393370705386 : Closed e2393370705386 ∧ code e2393370705386 = 11189463727594 := by decide
theorem cert_e2393370705386 : check e2393370705386 [[],[.left],[]] .three = true := by decide
def e2393370705582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2393370705582 : Closed e2393370705582 ∧ code e2393370705582 = 11189463727790 := by decide
theorem cert_e2393370705582 : check e2393370705582 [[],[.left],[]] .three = true := by decide
def e2393370705590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2393370705590 : Closed e2393370705590 ∧ code e2393370705590 = 11189463727798 := by decide
theorem cert_e2393370705590 : check e2393370705590 [[],[.left],[]] .three = true := by decide
def e2393370705594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2393370705594 : Closed e2393370705594 ∧ code e2393370705594 = 11189463727802 := by decide
theorem cert_e2393370705594 : check e2393370705594 [[],[.left],[]] .three = true := by decide
def e2393370705622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2393370705622 : Closed e2393370705622 ∧ code e2393370705622 = 11189463727830 := by decide
theorem cert_e2393370705622 : check e2393370705622 [[],[.left],[]] .three = true := by decide
def e2393370705626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2393370705626 : Closed e2393370705626 ∧ code e2393370705626 = 11189463727834 := by decide
theorem cert_e2393370705626 : check e2393370705626 [[],[.left],[]] .three = true := by decide
def e2393370705642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2393370705642 : Closed e2393370705642 ∧ code e2393370705642 = 11189463727850 := by decide
theorem cert_e2393370705642 : check e2393370705642 [[],[.left],[]] .three = true := by decide
def e2393370705750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2393370705750 : Closed e2393370705750 ∧ code e2393370705750 = 11189463727958 := by decide
theorem cert_e2393370705750 : check e2393370705750 [[],[.left],[]] .three = true := by decide
def e2393370705754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2393370705754 : Closed e2393370705754 ∧ code e2393370705754 = 11189463727962 := by decide
theorem cert_e2393370705754 : check e2393370705754 [[],[.left],[]] .three = true := by decide
def e2393370705770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2393370705770 : Closed e2393370705770 ∧ code e2393370705770 = 11189463727978 := by decide
theorem cert_e2393370705770 : check e2393370705770 [[],[.left],[]] .three = true := by decide
def e2393370709438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 4))))))))
theorem wire_e2393370709438 : Closed e2393370709438 ∧ code e2393370709438 = 11189463731646 := by decide
theorem cert_e2393370709438 : check e2393370709438 [[],[.left],[]] .three = true := by decide
def e2393370709470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e2393370709470 : Closed e2393370709470 ∧ code e2393370709470 = 11189463731678 := by decide
theorem cert_e2393370709470 : check e2393370709470 [[],[.left],[]] .three = true := by decide
def e2393370709486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e2393370709486 : Closed e2393370709486 ∧ code e2393370709486 = 11189463731694 := by decide
theorem cert_e2393370709486 : check e2393370709486 [[],[.left],[]] .three = true := by decide
def e2393370709494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 1))))))))
theorem wire_e2393370709494 : Closed e2393370709494 ∧ code e2393370709494 = 11189463731702 := by decide
theorem cert_e2393370709494 : check e2393370709494 [[],[.left],[]] .three = true := by decide
def e2393370709694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 4))))))))
theorem wire_e2393370709694 : Closed e2393370709694 ∧ code e2393370709694 = 11189463731902 := by decide
theorem cert_e2393370709694 : check e2393370709694 [[],[.left],[]] .three = true := by decide
def e2393370709726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e2393370709726 : Closed e2393370709726 ∧ code e2393370709726 = 11189463731934 := by decide
theorem cert_e2393370709726 : check e2393370709726 [[],[.left],[]] .three = true := by decide
def e2393370709742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e2393370709742 : Closed e2393370709742 ∧ code e2393370709742 = 11189463731950 := by decide
theorem cert_e2393370709742 : check e2393370709742 [[],[.left],[]] .smaller = true := by decide
def e2393370709750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e2393370709750 : Closed e2393370709750 ∧ code e2393370709750 = 11189463731958 := by decide
theorem cert_e2393370709750 : check e2393370709750 [[],[.left],[]] .three = true := by decide
def e2393370709754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 0))))))))
theorem wire_e2393370709754 : Closed e2393370709754 ∧ code e2393370709754 = 11189463731962 := by decide
theorem cert_e2393370709754 : check e2393370709754 [[],[.left],[]] .three = true := by decide
def e2393370709854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e2393370709854 : Closed e2393370709854 ∧ code e2393370709854 = 11189463732062 := by decide
theorem cert_e2393370709854 : check e2393370709854 [[],[.left],[]] .three = true := by decide
def e2393370709870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e2393370709870 : Closed e2393370709870 ∧ code e2393370709870 = 11189463732078 := by decide
theorem cert_e2393370709870 : check e2393370709870 [[],[.left],[]] .smaller = true := by decide
def e2393370709878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e2393370709878 : Closed e2393370709878 ∧ code e2393370709878 = 11189463732086 := by decide
theorem cert_e2393370709878 : check e2393370709878 [[],[.left],[]] .smaller = true := by decide
def e2393370709882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e2393370709882 : Closed e2393370709882 ∧ code e2393370709882 = 11189463732090 := by decide
theorem cert_e2393370709882 : check e2393370709882 [[],[.left],[]] .three = true := by decide
def e2393370709934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e2393370709934 : Closed e2393370709934 ∧ code e2393370709934 = 11189463732142 := by decide
theorem cert_e2393370709934 : check e2393370709934 [[],[.left],[]] .three = true := by decide
def e2393370709942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e2393370709942 : Closed e2393370709942 ∧ code e2393370709942 = 11189463732150 := by decide
theorem cert_e2393370709942 : check e2393370709942 [[],[.left],[]] .three = true := by decide
def e2393370709946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e2393370709946 : Closed e2393370709946 ∧ code e2393370709946 = 11189463732154 := by decide
theorem cert_e2393370709946 : check e2393370709946 [[],[.left],[]] .three = true := by decide
def e2393370709974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 1))))))))
theorem wire_e2393370709974 : Closed e2393370709974 ∧ code e2393370709974 = 11189463732182 := by decide
theorem cert_e2393370709974 : check e2393370709974 [[],[.left],[]] .three = true := by decide
def e2393370709978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 0))))))))
theorem wire_e2393370709978 : Closed e2393370709978 ∧ code e2393370709978 = 11189463732186 := by decide
theorem cert_e2393370709978 : check e2393370709978 [[],[.left],[]] .three = true := by decide
def e2393370710974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2393370710974 : Closed e2393370710974 ∧ code e2393370710974 = 11189463733182 := by decide
theorem cert_e2393370710974 : check e2393370710974 [[],[.left],[]] .three = true := by decide
def e2393370711006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2393370711006 : Closed e2393370711006 ∧ code e2393370711006 = 11189463733214 := by decide
theorem cert_e2393370711006 : check e2393370711006 [[],[.left],[]] .three = true := by decide
def e2393370711022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2393370711022 : Closed e2393370711022 ∧ code e2393370711022 = 11189463733230 := by decide
theorem cert_e2393370711022 : check e2393370711022 [[],[.left],[]] .three = true := by decide
def e2393370711030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2393370711030 : Closed e2393370711030 ∧ code e2393370711030 = 11189463733238 := by decide
theorem cert_e2393370711030 : check e2393370711030 [[],[.left],[]] .three = true := by decide
def e2393370712510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2393370712510 : Closed e2393370712510 ∧ code e2393370712510 = 11189463734718 := by decide
theorem cert_e2393370712510 : check e2393370712510 [[],[.left],[]] .three = true := by decide
def e2393370712542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2393370712542 : Closed e2393370712542 ∧ code e2393370712542 = 11189463734750 := by decide
theorem cert_e2393370712542 : check e2393370712542 [[],[.left],[]] .three = true := by decide
def e2393370712558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393370712558 : Closed e2393370712558 ∧ code e2393370712558 = 11189463734766 := by decide
theorem cert_e2393370712558 : check e2393370712558 [[],[.left],[]] .smaller = true := by decide
def e2393370712566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2393370712566 : Closed e2393370712566 ∧ code e2393370712566 = 11189463734774 := by decide
theorem cert_e2393370712566 : check e2393370712566 [[],[.left],[]] .three = true := by decide
def e2393370712570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2393370712570 : Closed e2393370712570 ∧ code e2393370712570 = 11189463734778 := by decide
theorem cert_e2393370712570 : check e2393370712570 [[],[.left],[]] .three = true := by decide
def e2393370713310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2393370713310 : Closed e2393370713310 ∧ code e2393370713310 = 11189463735518 := by decide
theorem cert_e2393370713310 : check e2393370713310 [[],[.left],[]] .three = true := by decide
def e2393370713326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393370713326 : Closed e2393370713326 ∧ code e2393370713326 = 11189463735534 := by decide
theorem cert_e2393370713326 : check e2393370713326 [[],[.left],[]] .smaller = true := by decide
def e2393370713334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393370713334 : Closed e2393370713334 ∧ code e2393370713334 = 11189463735542 := by decide
theorem cert_e2393370713334 : check e2393370713334 [[],[.left],[]] .smaller = true := by decide
def e2393370713338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2393370713338 : Closed e2393370713338 ∧ code e2393370713338 = 11189463735546 := by decide
theorem cert_e2393370713338 : check e2393370713338 [[],[.left],[]] .three = true := by decide
def e2393370713710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393370713710 : Closed e2393370713710 ∧ code e2393370713710 = 11189463735918 := by decide
theorem cert_e2393370713710 : check e2393370713710 [[],[.left],[]] .three = true := by decide
def e2393370713718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393370713718 : Closed e2393370713718 ∧ code e2393370713718 = 11189463735926 := by decide
theorem cert_e2393370713718 : check e2393370713718 [[],[.left],[]] .three = true := by decide
def e2393370713722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393370713722 : Closed e2393370713722 ∧ code e2393370713722 = 11189463735930 := by decide
theorem cert_e2393370713722 : check e2393370713722 [[],[.left],[]] .three = true := by decide
def e2393370713910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393370713910 : Closed e2393370713910 ∧ code e2393370713910 = 11189463736118 := by decide
theorem cert_e2393370713910 : check e2393370713910 [[],[.left],[]] .three = true := by decide
def e2393370713914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393370713914 : Closed e2393370713914 ∧ code e2393370713914 = 11189463736122 := by decide
theorem cert_e2393370713914 : check e2393370713914 [[],[.left],[]] .three = true := by decide
def e2393370715838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 4))))))))
theorem wire_e2393370715838 : Closed e2393370715838 ∧ code e2393370715838 = 11189463738046 := by decide
theorem cert_e2393370715838 : check e2393370715838 [[],[.left],[]] .three = true := by decide
def e2393370715870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2393370715870 : Closed e2393370715870 ∧ code e2393370715870 = 11189463738078 := by decide
theorem cert_e2393370715870 : check e2393370715870 [[],[.left],[]] .three = true := by decide
def e2393370715886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e2393370715886 : Closed e2393370715886 ∧ code e2393370715886 = 11189463738094 := by decide
theorem cert_e2393370715886 : check e2393370715886 [[],[.left],[]] .smaller = true := by decide
def e2393370715894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2393370715894 : Closed e2393370715894 ∧ code e2393370715894 = 11189463738102 := by decide
theorem cert_e2393370715894 : check e2393370715894 [[],[.left],[]] .three = true := by decide
def e2393370715898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 0))))))))
theorem wire_e2393370715898 : Closed e2393370715898 ∧ code e2393370715898 = 11189463738106 := by decide
theorem cert_e2393370715898 : check e2393370715898 [[],[.left],[]] .three = true := by decide
def e2393370715998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2393370715998 : Closed e2393370715998 ∧ code e2393370715998 = 11189463738206 := by decide
theorem cert_e2393370715998 : check e2393370715998 [[],[.left],[]] .three = true := by decide
def e2393370716026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2393370716026 : Closed e2393370716026 ∧ code e2393370716026 = 11189463738234 := by decide
theorem cert_e2393370716026 : check e2393370716026 [[],[.left],[]] .three = true := by decide
def e2393370716078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e2393370716078 : Closed e2393370716078 ∧ code e2393370716078 = 11189463738286 := by decide
theorem cert_e2393370716078 : check e2393370716078 [[],[.left],[]] .smaller = true := by decide
def e2393370716090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e2393370716090 : Closed e2393370716090 ∧ code e2393370716090 = 11189463738298 := by decide
theorem cert_e2393370716090 : check e2393370716090 [[],[.left],[]] .smaller = true := by decide
def e2393370716118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2393370716118 : Closed e2393370716118 ∧ code e2393370716118 = 11189463738326 := by decide
theorem cert_e2393370716118 : check e2393370716118 [[],[.left],[]] .three = true := by decide
def e2393370716122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2393370716122 : Closed e2393370716122 ∧ code e2393370716122 = 11189463738330 := by decide
theorem cert_e2393370716122 : check e2393370716122 [[],[.left],[]] .three = true := by decide
def e2393370716138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 0))))))))
theorem wire_e2393370716138 : Closed e2393370716138 ∧ code e2393370716138 = 11189463738346 := by decide
theorem cert_e2393370716138 : check e2393370716138 [[],[.left],[]] .three = true := by decide
def e2393370716606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2393370716606 : Closed e2393370716606 ∧ code e2393370716606 = 11189463738814 := by decide
theorem cert_e2393370716606 : check e2393370716606 [[],[.left],[]] .three = true := by decide
def e2393370716638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2393370716638 : Closed e2393370716638 ∧ code e2393370716638 = 11189463738846 := by decide
theorem cert_e2393370716638 : check e2393370716638 [[],[.left],[]] .three = true := by decide
def e2393370716654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393370716654 : Closed e2393370716654 ∧ code e2393370716654 = 11189463738862 := by decide
theorem cert_e2393370716654 : check e2393370716654 [[],[.left],[]] .smaller = true := by decide
def e2393370716662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2393370716662 : Closed e2393370716662 ∧ code e2393370716662 = 11189463738870 := by decide
theorem cert_e2393370716662 : check e2393370716662 [[],[.left],[]] .three = true := by decide
def e2393370716666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2393370716666 : Closed e2393370716666 ∧ code e2393370716666 = 11189463738874 := by decide
theorem cert_e2393370716666 : check e2393370716666 [[],[.left],[]] .three = true := by decide
def e2393370717406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2393370717406 : Closed e2393370717406 ∧ code e2393370717406 = 11189463739614 := by decide
theorem cert_e2393370717406 : check e2393370717406 [[],[.left],[]] .three = true := by decide
def e2393370717434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2393370717434 : Closed e2393370717434 ∧ code e2393370717434 = 11189463739642 := by decide
theorem cert_e2393370717434 : check e2393370717434 [[],[.left],[]] .three = true := by decide
def e2393370717806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393370717806 : Closed e2393370717806 ∧ code e2393370717806 = 11189463740014 := by decide
theorem cert_e2393370717806 : check e2393370717806 [[],[.left],[]] .smaller = true := by decide
def e2393370717818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393370717818 : Closed e2393370717818 ∧ code e2393370717818 = 11189463740026 := by decide
theorem cert_e2393370717818 : check e2393370717818 [[],[.left],[]] .smaller = true := by decide
def e2393370718006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393370718006 : Closed e2393370718006 ∧ code e2393370718006 = 11189463740214 := by decide
theorem cert_e2393370718006 : check e2393370718006 [[],[.left],[]] .three = true := by decide
def e2393370718010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393370718010 : Closed e2393370718010 ∧ code e2393370718010 = 11189463740218 := by decide
theorem cert_e2393370718010 : check e2393370718010 [[],[.left],[]] .three = true := by decide
def e2393370718106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393370718106 : Closed e2393370718106 ∧ code e2393370718106 = 11189463740314 := by decide
theorem cert_e2393370718106 : check e2393370718106 [[],[.left],[]] .three = true := by decide
def e2393370719070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2393370719070 : Closed e2393370719070 ∧ code e2393370719070 = 11189463741278 := by decide
theorem cert_e2393370719070 : check e2393370719070 [[],[.left],[]] .three = true := by decide
def e2393370719086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2393370719086 : Closed e2393370719086 ∧ code e2393370719086 = 11189463741294 := by decide
theorem cert_e2393370719086 : check e2393370719086 [[],[.left],[]] .smaller = true := by decide
def e2393370719094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2393370719094 : Closed e2393370719094 ∧ code e2393370719094 = 11189463741302 := by decide
theorem cert_e2393370719094 : check e2393370719094 [[],[.left],[]] .smaller = true := by decide
def e2393370719098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2393370719098 : Closed e2393370719098 ∧ code e2393370719098 = 11189463741306 := by decide
theorem cert_e2393370719098 : check e2393370719098 [[],[.left],[]] .three = true := by decide
def e2393370719150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2393370719150 : Closed e2393370719150 ∧ code e2393370719150 = 11189463741358 := by decide
theorem cert_e2393370719150 : check e2393370719150 [[],[.left],[]] .smaller = true := by decide
def e2393370719162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2393370719162 : Closed e2393370719162 ∧ code e2393370719162 = 11189463741370 := by decide
theorem cert_e2393370719162 : check e2393370719162 [[],[.left],[]] .smaller = true := by decide
def e2393370719190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2393370719190 : Closed e2393370719190 ∧ code e2393370719190 = 11189463741398 := by decide
theorem cert_e2393370719190 : check e2393370719190 [[],[.left],[]] .smaller = true := by decide
def e2393370719194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2393370719194 : Closed e2393370719194 ∧ code e2393370719194 = 11189463741402 := by decide
theorem cert_e2393370719194 : check e2393370719194 [[],[.left],[]] .smaller = true := by decide
def e2393370719210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2393370719210 : Closed e2393370719210 ∧ code e2393370719210 = 11189463741418 := by decide
theorem cert_e2393370719210 : check e2393370719210 [[],[.left],[]] .three = true := by decide
def e2393370719454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2393370719454 : Closed e2393370719454 ∧ code e2393370719454 = 11189463741662 := by decide
theorem cert_e2393370719454 : check e2393370719454 [[],[.left],[]] .three = true := by decide
def e2393370719470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393370719470 : Closed e2393370719470 ∧ code e2393370719470 = 11189463741678 := by decide
theorem cert_e2393370719470 : check e2393370719470 [[],[.left],[]] .smaller = true := by decide
def e2393370719478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393370719478 : Closed e2393370719478 ∧ code e2393370719478 = 11189463741686 := by decide
theorem cert_e2393370719478 : check e2393370719478 [[],[.left],[]] .smaller = true := by decide
def e2393370719482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2393370719482 : Closed e2393370719482 ∧ code e2393370719482 = 11189463741690 := by decide
theorem cert_e2393370719482 : check e2393370719482 [[],[.left],[]] .three = true := by decide
def e2393370719854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393370719854 : Closed e2393370719854 ∧ code e2393370719854 = 11189463742062 := by decide
theorem cert_e2393370719854 : check e2393370719854 [[],[.left],[]] .smaller = true := by decide
def e2393370719866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393370719866 : Closed e2393370719866 ∧ code e2393370719866 = 11189463742074 := by decide
theorem cert_e2393370719866 : check e2393370719866 [[],[.left],[]] .smaller = true := by decide
def e2393370720054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393370720054 : Closed e2393370720054 ∧ code e2393370720054 = 11189463742262 := by decide
theorem cert_e2393370720054 : check e2393370720054 [[],[.left],[]] .smaller = true := by decide
def e2393370720058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393370720058 : Closed e2393370720058 ∧ code e2393370720058 = 11189463742266 := by decide
theorem cert_e2393370720058 : check e2393370720058 [[],[.left],[]] .smaller = true := by decide
def e2393370720154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393370720154 : Closed e2393370720154 ∧ code e2393370720154 = 11189463742362 := by decide
theorem cert_e2393370720154 : check e2393370720154 [[],[.left],[]] .three = true := by decide
def e2393370720686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2393370720686 : Closed e2393370720686 ∧ code e2393370720686 = 11189463742894 := by decide
theorem cert_e2393370720686 : check e2393370720686 [[],[.left],[]] .three = true := by decide
def e2393370720694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2393370720694 : Closed e2393370720694 ∧ code e2393370720694 = 11189463742902 := by decide
theorem cert_e2393370720694 : check e2393370720694 [[],[.left],[]] .three = true := by decide
def e2393370720698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2393370720698 : Closed e2393370720698 ∧ code e2393370720698 = 11189463742906 := by decide
theorem cert_e2393370720698 : check e2393370720698 [[],[.left],[]] .three = true := by decide
def e2393370720726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2393370720726 : Closed e2393370720726 ∧ code e2393370720726 = 11189463742934 := by decide
theorem cert_e2393370720726 : check e2393370720726 [[],[.left],[]] .three = true := by decide
def e2393370720730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2393370720730 : Closed e2393370720730 ∧ code e2393370720730 = 11189463742938 := by decide
theorem cert_e2393370720730 : check e2393370720730 [[],[.left],[]] .three = true := by decide
def e2393370720746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2393370720746 : Closed e2393370720746 ∧ code e2393370720746 = 11189463742954 := by decide
theorem cert_e2393370720746 : check e2393370720746 [[],[.left],[]] .three = true := by decide
def e2393370720878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393370720878 : Closed e2393370720878 ∧ code e2393370720878 = 11189463743086 := by decide
theorem cert_e2393370720878 : check e2393370720878 [[],[.left],[]] .three = true := by decide
def e2393370720886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393370720886 : Closed e2393370720886 ∧ code e2393370720886 = 11189463743094 := by decide
theorem cert_e2393370720886 : check e2393370720886 [[],[.left],[]] .three = true := by decide
def e2393370720890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393370720890 : Closed e2393370720890 ∧ code e2393370720890 = 11189463743098 := by decide
theorem cert_e2393370720890 : check e2393370720890 [[],[.left],[]] .three = true := by decide
def e2393370721078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393370721078 : Closed e2393370721078 ∧ code e2393370721078 = 11189463743286 := by decide
theorem cert_e2393370721078 : check e2393370721078 [[],[.left],[]] .three = true := by decide
def e2393370721082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393370721082 : Closed e2393370721082 ∧ code e2393370721082 = 11189463743290 := by decide
theorem cert_e2393370721082 : check e2393370721082 [[],[.left],[]] .three = true := by decide
def e2393370721178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393370721178 : Closed e2393370721178 ∧ code e2393370721178 = 11189463743386 := by decide
theorem cert_e2393370721178 : check e2393370721178 [[],[.left],[]] .three = true := by decide
def e2393370721494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2393370721494 : Closed e2393370721494 ∧ code e2393370721494 = 11189463743702 := by decide
theorem cert_e2393370721494 : check e2393370721494 [[],[.left],[]] .three = true := by decide
def e2393370721498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2393370721498 : Closed e2393370721498 ∧ code e2393370721498 = 11189463743706 := by decide
theorem cert_e2393370721498 : check e2393370721498 [[],[.left],[]] .three = true := by decide
def e2393370721514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2393370721514 : Closed e2393370721514 ∧ code e2393370721514 = 11189463743722 := by decide
theorem cert_e2393370721514 : check e2393370721514 [[],[.left],[]] .three = true := by decide
def e2393370721590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393370721590 : Closed e2393370721590 ∧ code e2393370721590 = 11189463743798 := by decide
theorem cert_e2393370721590 : check e2393370721590 [[],[.left],[]] .three = true := by decide
def e2393370721594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393370721594 : Closed e2393370721594 ∧ code e2393370721594 = 11189463743802 := by decide
theorem cert_e2393370721594 : check e2393370721594 [[],[.left],[]] .three = true := by decide
def e2393370721690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393370721690 : Closed e2393370721690 ∧ code e2393370721690 = 11189463743898 := by decide
theorem cert_e2393370721690 : check e2393370721690 [[],[.left],[]] .three = true := by decide
def e2393370725230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2393370725230 : Closed e2393370725230 ∧ code e2393370725230 = 11189463747438 := by decide
theorem cert_e2393370725230 : check e2393370725230 [[],[.left],[]] .smaller = true := by decide
def e2393370725238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2393370725238 : Closed e2393370725238 ∧ code e2393370725238 = 11189463747446 := by decide
theorem cert_e2393370725238 : check e2393370725238 [[],[.left],[]] .smaller = true := by decide
def e2393370725294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2393370725294 : Closed e2393370725294 ∧ code e2393370725294 = 11189463747502 := by decide
theorem cert_e2393370725294 : check e2393370725294 [[],[.left],[]] .smaller = true := by decide
def e2393370725306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2393370725306 : Closed e2393370725306 ∧ code e2393370725306 = 11189463747514 := by decide
theorem cert_e2393370725306 : check e2393370725306 [[],[.left],[]] .smaller = true := by decide
def e2393370725334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2393370725334 : Closed e2393370725334 ∧ code e2393370725334 = 11189463747542 := by decide
theorem cert_e2393370725334 : check e2393370725334 [[],[.left],[]] .smaller = true := by decide
def e2393370725338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2393370725338 : Closed e2393370725338 ∧ code e2393370725338 = 11189463747546 := by decide
theorem cert_e2393370725338 : check e2393370725338 [[],[.left],[]] .smaller = true := by decide
def e2393370725614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2393370725614 : Closed e2393370725614 ∧ code e2393370725614 = 11189463747822 := by decide
theorem cert_e2393370725614 : check e2393370725614 [[],[.left],[]] .smaller = true := by decide
def e2393370725622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2393370725622 : Closed e2393370725622 ∧ code e2393370725622 = 11189463747830 := by decide
theorem cert_e2393370725622 : check e2393370725622 [[],[.left],[]] .smaller = true := by decide
end Blc.Floor43
